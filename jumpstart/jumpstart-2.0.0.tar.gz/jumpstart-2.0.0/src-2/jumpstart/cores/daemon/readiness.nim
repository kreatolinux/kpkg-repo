## Daemon arguments and the user daemon readiness pipe (Kreato extension of
## §7.6 step 4.5 and §20.2).
##
## `jumpstart --user --ready-fd N`: the system daemon passes the write end of
## a pipe as descriptor N when it spawns a user daemon for a PAM session. The
## user daemon marks N close-on-exec at once, so it never reaches a core or
## any other child, and writes the single byte 'R' and closes it when its
## startup completed (checkStartupTail, after the enabled cores were loaded
## and activated, e.g. the systemd core's default.target with the session
## bus). If the daemon fails or exits first the reader just sees EOF.
import std/[os, posix, strutils]

type
  DaemonArgs* = object
    user*: bool          ## --user
    readyFd*: int        ## --ready-fd N, or -1

  ReadyNotifier* = ref object
    fd: cint             ## -1 once notified, closed, or when inactive

const ReadyByte* = 'R'

proc parseDaemonArgs*(args: openArray[string]): DaemonArgs =
  ## Accepts no arguments, `--user`, or `--user --ready-fd N` (N >= 3, in
  ## either order). Anything else raises ValueError; the caller exits 2.
  result.readyFd = -1
  var i = 0
  var sawReady = false
  while i < args.len:
    let arg = args[i]
    if arg == "--user":
      if result.user: raise newException(ValueError, "too many arguments")
      result.user = true
    elif arg == "--ready-fd":
      if sawReady: raise newException(ValueError, "too many arguments")
      if i + 1 >= args.len:
        raise newException(ValueError, "--ready-fd requires a file descriptor")
      inc i
      let value = args[i]
      if value.len == 0 or value.len > 9 or not value.allCharsInSet(Digits):
        raise newException(ValueError, "invalid --ready-fd: " & value)
      let fd = parseInt(value)
      if fd < 3: raise newException(ValueError, "--ready-fd must be 3 or greater")
      result.readyFd = fd
      sawReady = true
    else:
      raise newException(ValueError, "unknown argument: " & arg)
    inc i
  if sawReady and not result.user:
    raise newException(ValueError, "--ready-fd requires --user")

proc newReadyNotifier*(fd: int): ReadyNotifier =
  ## Takes ownership of `fd` (-1: an inactive notifier) and marks it
  ## close-on-exec. A descriptor that is not open raises OSError.
  result = ReadyNotifier(fd: -1)
  if fd < 0: return
  let flags = fcntl(cint(fd), F_GETFD)
  if flags < 0: raiseOSError(osLastError(), "--ready-fd " & $fd)
  if fcntl(cint(fd), F_SETFD, flags or FD_CLOEXEC) < 0:
    raiseOSError(osLastError(), "--ready-fd " & $fd)
  result.fd = cint(fd)

proc active*(n: ReadyNotifier): bool = not n.isNil and n.fd >= 0

proc close*(n: ReadyNotifier) =
  ## Close without notifying (the reader sees EOF).
  if not n.active: return
  discard posix.close(n.fd)
  n.fd = -1

proc notifyReady*(n: ReadyNotifier): bool =
  ## Write 'R' once and close. True when the byte was written; later calls
  ## do nothing. A reader that went away (EPIPE) is not an error.
  if not n.active: return false
  var token = ReadyByte
  var written: int
  while true:
    written = posix.write(n.fd, addr token, 1)
    if written >= 0 or errno != EINTR: break
  n.close()
  written == 1
