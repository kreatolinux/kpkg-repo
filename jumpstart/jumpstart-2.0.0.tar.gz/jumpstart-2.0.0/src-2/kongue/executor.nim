## Executor/Interpreter for Kongue scripting language
## Executes the parsed AST

import sequtils
import strutils
import tables
import ast
import builtins
import variables

const
    # Special exit codes for control flow
    exitContinue* = -100 # Continue to next iteration
    exitBreak* = -101    # Break out of loop

type
    ExecutionError* = object of CatchableError
        ## Runtime execution error
        line*: int

proc executeFunction*(ctx: ExecutionContext, funcBody: seq[AstNode]): int

proc executeNode*(ctx: ExecutionContext, node: AstNode): int =
    ## Execute a single AST node
    ## Returns exit code (0 = success, negative = control flow)

    case node.kind
    of nkExec:
        return ctx.builtinExec(node.execCmd)

    of nkMacro:
        # Use macro hook if available, otherwise report error
        if ctx.macroHook != nil:
            return ctx.macroHook(ctx, node.macroName, node.macroArgs)
        else:
            echo "Error: Macro '" & node.macroName & "' not supported (no macro handler installed)"
            return 1

    of nkPrint:
        ctx.builtinPrint(node.printText)
        return 0

    of nkCd:
        if ctx.builtinCd(node.cdPath):
            return 0
        else:
            return 1

    of nkEnv:
        ctx.builtinEnv(node.envVar, node.envValue)
        return 0

    of nkLocal:
        ctx.builtinLocal(node.localVar, node.localValue)
        return 0

    of nkGlobal:
        ctx.builtinGlobal(node.globalVar, node.globalValue)
        return 0

    of nkWrite:
        ctx.builtinWrite(node.writePath, node.writeContent)
        return 0

    of nkAppend:
        ctx.builtinAppend(node.appendPath, node.appendContent)
        return 0

    of nkContinue:
        return exitContinue

    of nkBreak:
        return exitBreak

    of nkIf:
        if ctx.evaluateCondition(node.condition):
            for stmt in node.thenBranch:
                let exitCode = ctx.executeNode(stmt)
                if exitCode != 0:
                    return exitCode
        else:
            for stmt in node.elseBranch:
                let exitCode = ctx.executeNode(stmt)
                if exitCode != 0:
                    return exitCode
        return 0

    of nkFor:
        # Check if we have an inline list literal
        var items: seq[string] = @[]

        if node.iterListLiteral.len > 0:
            # Use inline list literal directly
            items = node.iterListLiteral
        elif node.iterList.startsWith("$") or node.iterList.startsWith("\""):
            # Variable expression - resolve it first
            let resolved = ctx.resolveVariables(node.iterList).strip()
            # Remove surrounding quotes if present
            var cleanResolved = resolved
            if cleanResolved.startsWith("\"") and cleanResolved.endsWith("\""):
                cleanResolved = cleanResolved[1..^2]
            elif cleanResolved.startsWith("'") and cleanResolved.endsWith("'"):
                cleanResolved = cleanResolved[1..^2]
            # Split by newlines or spaces
            if '\n' in cleanResolved:
                items = cleanResolved.splitLines()
            else:
                items = cleanResolved.split(' ')
            # Filter out empty items
            items = items.filterIt(it.strip().len > 0)
        else:
            # Get the list from a variable by name
            items = ctx.getListVariable(node.iterList)
            if items.len == 0:
                # Try to get as a regular variable and split it
                let varValue = ctx.getVariable(node.iterList)
                if varValue != "":
                    if '\n' in varValue:
                        items = varValue.splitLines()
                    else:
                        items = varValue.split(' ')
                    items = items.filterIt(it.strip().len > 0)

        # Iterate over items
        for item in items:
            ctx.builtinLocal(node.iterVar, item)
            var shouldBreak = false
            for stmt in node.forBody:
                let exitCode = ctx.executeNode(stmt)
                if exitCode == exitContinue:
                    break # Break inner loop, continue outer
                elif exitCode == exitBreak:
                    shouldBreak = true
                    break
                elif exitCode != 0:
                    return exitCode
            if shouldBreak:
                break
        return 0

    of nkFuncCall:
        # Execute custom function call
        if ctx.customFuncs.hasKey(node.callName):
            # Guard before doing any work: recursion here is unbounded by the
            # language (there is no arithmetic to count down with), so a
            # self-calling function would otherwise run the host stack into
            # the ground. See utils.defaultMaxCallDepth.
            # A non-positive ceiling means "no limit". Contexts built directly
            # rather than through initExecutionContext leave maxCallDepth at 0,
            # and 0 must not read as "fail immediately".
            if ctx.maxCallDepth > 0 and ctx.callDepth >= ctx.maxCallDepth:
                var err = newException(ExecutionError,
                    "Maximum call depth (" & $ctx.maxCallDepth &
                    ") exceeded calling: " & node.callName)
                err.line = node.line
                raise err

            # Resolve arguments in current scope
            var resolvedArgs: seq[string] = @[]
            for arg in node.callArgs:
                resolvedArgs.add(stripQuotes(ctx.resolveVariables(arg)))

            # Save current locals
            let parentLocals = ctx.localVars

            # Create new scope
            ctx.localVars = initTable[string, string]()

            # Set arguments
            ctx.localVars["0"] = node.callName
            for i, arg in resolvedArgs:
                ctx.localVars[$(i + 1)] = arg

            # Execute function body. The depth counter must come back down even
            # if the body raises, or a caught error would poison later calls.
            let funcBody = ctx.customFuncs[node.callName]
            ctx.callDepth += 1
            let res =
                try:
                    ctx.executeFunction(funcBody)
                finally:
                    ctx.callDepth -= 1
                    ctx.localVars = parentLocals

            return res
        else:
            var err = newException(ExecutionError, "Unknown function: " & node.callName)
            err.line = node.line
            raise err

    of nkComment:
        # Comments do nothing
        return 0

    of nkObject:
        # Object declaration - store in objectVariables
        var props = initTable[string, VarValue]()
        for (key, value) in node.objectProperties:
            props[key] = newStringValue(stripQuotes(ctx.resolveVariables(value)))
        ctx.setObjectVariable(node.objectName, newObjectValue(props))
        return 0

    of nkBlock:
        for stmt in node.blockBody:
            let exitCode = ctx.executeNode(stmt)
            if exitCode != 0:
                return exitCode
        return 0

    of nkVarManip, nkVarRef:
        # These should be resolved during variable substitution
        return 0

    else:
        echo "Warning: Unhandled node kind: " & $node.kind
        return 0

proc executeFunction*(ctx: ExecutionContext, funcBody: seq[AstNode]): int =
    ## Execute a function body (sequence of statements)
    result = 0
    for node in funcBody:
        result = ctx.executeNode(node)
        if result != 0:
            break

    # Clear local variables when exiting function
    ctx.clearLocalVars()

proc loadVariablesFromParsed*(ctx: ExecutionContext, parsed: ParsedScript) =
    ## Load variables from parsed script into execution context
    ## Variables with qualifiers are stored with combined names (e.g., "depends_test2")
    for varNode in parsed.variables:
        case varNode.kind
        of nkVariable:
            let fullName = getFullVarName(varNode)
            case varNode.varOp
            of opSet:
                ctx.setVariable(fullName, varNode.varValue)
            of opAppend:
                if ctx.hasListVariable(fullName):
                    # If it's a list variable, add to list
                    let current = ctx.getListVariable(fullName)
                    ctx.setListVariable(fullName, current & @[
                            varNode.varValue])
                else:
                    # Treat as string concatenation with space
                    let current = ctx.getVariable(fullName)
                    if current == "":
                        ctx.setVariable(fullName, varNode.varValue)
                    else:
                        ctx.setVariable(fullName, current & " " &
                                varNode.varValue)
            of opRemove:
                # String remove?
                let current = ctx.getVariable(fullName)
                ctx.setVariable(fullName, current.replace(
                        varNode.varValue, "").strip())

        of nkListVariable:
            let fullName = getFullVarName(varNode)
            case varNode.listOp
            of opSet:
                ctx.setListVariable(fullName, varNode.listItems)
            of opAppend:
                let current = ctx.getListVariable(fullName)
                ctx.setListVariable(fullName, current &
                        varNode.listItems)
            of opRemove:
                var current = ctx.getListVariable(fullName)
                for itemToRemove in varNode.listItems:
                    current.keepItIf(it != itemToRemove)
                ctx.setListVariable(fullName, current)

        of nkObject:
            # Object declaration in header - store directly
            var props = initTable[string, VarValue]()
            for (key, value) in varNode.objectProperties:
                props[key] = newStringValue(value)
            ctx.setObjectVariable(varNode.objectName, newObjectValue(props))

        else:
            discard

proc loadAllFunctions*(ctx: ExecutionContext, parsed: ParsedScript) =
    ## Load all callable functions (both regular and custom) from parsed script
    ## Functions with qualifiers are stored with combined names (e.g., "package_foo", "build_foo")
    # Load regular functions (e.g., package foo, build foo)
    for funcNode in parsed.functions:
        if funcNode.kind == nkFunction:
            let fullName = getFullFuncName(funcNode)
            ctx.customFuncs[fullName] = funcNode.funcBody
    # Load custom functions (defined with 'func' keyword)
    for funcNode in parsed.customFuncs:
        if funcNode.kind == nkCustomFunc:
            ctx.customFuncs[funcNode.customFuncName] = funcNode.customFuncBody

proc getFunctionByName*(parsed: ParsedScript, name: string): seq[AstNode] =
    ## Get a function's body by name (searches both regular and custom functions)
    ## Accepts both base name and full name with qualifier (e.g., "build" or "build_test2")
    # First check regular functions
    for funcNode in parsed.functions:
        if funcNode.kind == nkFunction:
            let fullName = getFullFuncName(funcNode)
            if fullName == name:
                return funcNode.funcBody
    # Then check custom functions
    for funcNode in parsed.customFuncs:
        if funcNode.kind == nkCustomFunc and funcNode.customFuncName == name:
            return funcNode.customFuncBody
    return @[]

proc executeFunctionByName*(ctx: ExecutionContext, parsed: ParsedScript,
        functionName: string): int =
    ## Execute a specific function from a parsed Kongue script
    let funcBody = getFunctionByName(parsed, functionName)
    if funcBody.len == 0:
        echo "Warning: Function '" & functionName & "' not found"
        return 0

    return ctx.executeFunction(funcBody)

proc resolveHookFunction*(parsed: ParsedScript, hookName: string,
        packageName: string): string =
    ## Resolve a hook function name, checking package-specific variant first.
    ## Returns the function name if found, or empty string if not.
    ##
    ## Checks in order:
    ## 1. hookName_packagename (with dashes replaced by underscores) - supports both
    ##    "build test2 {}" syntax (stored as "build_test2") and legacy "build_test2 {}" syntax
    ## 2. hookName (generic)
    ##
    ## Example: resolveHookFunction(parsed, "postinstall", "my-pkg")
    ##   checks "postinstall_my_pkg" first, then "postinstall"
    let pkgSpecific = hookName & "_" & replace(packageName, '-', '_')
    if parsed.hasFunction(pkgSpecific):
        return pkgSpecific
    elif parsed.hasFunction(hookName):
        return hookName
    else:
        return ""

proc resolveVarManipulation*(ctx: ExecutionContext, node: AstNode): string =
    ## Resolve a variable manipulation expression to its final value
    if node.kind != nkVarManip:
        return ""

    # Get base variable value
    var baseValue: VarValue
    if ctx.hasObjectVariable(node.baseVar):
        baseValue = ctx.getObjectVariable(node.baseVar)
    elif ctx.hasListVariable(node.baseVar):
        baseValue = newListValue(ctx.getListVariable(node.baseVar))
    else:
        baseValue = newStringValue(ctx.getVariable(node.baseVar))

    # Apply methods (node.methods is already seq[VarManipMethod])
    let methods = node.methods

    try:
        let res = evaluateVarManipulation(baseValue, methods, node.indexExpr)
        return res.toString()
    except ValueError as e:
        echo "Error in variable manipulation: " & e.msg
        return ""

proc initFromParsed*(parsed: ParsedScript, destDir: string = "",
        srcDir: string = "", buildRoot: string = ""): ExecutionContext =
    ## Initialize execution context from a parsed script
    result = initExecutionContext(destDir, srcDir, buildRoot, "")
    result.loadVariablesFromParsed(parsed)
    result.loadAllFunctions(parsed)

    # Set package name if available
    if result.variables.hasKey("name"):
        result.packageName = result.variables["name"]
