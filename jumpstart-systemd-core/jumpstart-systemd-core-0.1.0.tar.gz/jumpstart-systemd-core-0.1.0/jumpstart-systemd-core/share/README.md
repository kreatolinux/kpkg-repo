# systemd core for Jumpstart

Enable with `jumpctl cores enable systemd`. The core reads systemd unit files
from systemd's own directories (`/etc/systemd/system`, `/usr/lib/systemd/system`,
...) and runs them: services of every type, sockets, targets, slices, mounts
(unit files, `/etc/fstab`, and mirrors of `/proc/self/mountinfo`) and the
journal. Use `systemctl` and `journalctl`, or `jumpctl` with the `systemd/`
prefix (`jumpctl start systemd/sshd.service`).

Not in this release: timer, path, swap and automount units (they load, list and
refuse to start with `E_UNSUPPORTED`), the sandboxing directives (`Private*`,
`Protect*`, `Bind*`, `RootDirectory=`, capabilities, seccomp, `Restrict*`,
`DynamicUser=`: a unit that sets them fails closed with exit status 226, 218 or
228 instead of running unconfined), credentials.

`systemd-run`, `systemd-analyze`, `systemd-tmpfiles` and `systemd-sysusers` are
links to the core's multi-call tool. Defaults for the last two live in
`share/tmpfiles.d` and `share/sysusers.d` (lowest priority); the matching
`systemd-sysusers.service`, `systemd-tmpfiles-setup.service` and
`systemd-tmpfiles-clean.timer` are enabled by the shipped preset (a distribution's
own units of the same names take precedence). Executables in the
`system-generators` directories run at every `daemon-reload`.

A native Jumpstart `getty` unit and a `getty@.service` instance on the same
terminal fight over it. Disable one of them.

Recommended: set `mount_fstab = false` in Jumpstart so the fstab generator
mounts everything through `local-fs.target`.
