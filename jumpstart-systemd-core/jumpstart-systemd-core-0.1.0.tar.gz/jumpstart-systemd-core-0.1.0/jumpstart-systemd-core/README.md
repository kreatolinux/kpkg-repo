# jumpstart-systemd-core

A systemd **compatibility core** for [Jumpstart](https://github.com/kreatolinux/src).
It reads real systemd unit files and runs them under Jumpstart: dependencies,
service types, `sd_notify`, socket activation, a journal, and a `systemctl` /
`journalctl` front-end, so that for services and related things there is little
difference between using this core and using systemd directly.

It is **not** real systemd. systemd has to be PID 1 and owns `/run`, the cgroup
tree and device nodes, which Jumpstart owns. This core is a manager that
implements systemd's semantics inside Jumpstart's core framework (the
supervisor-plus-adapter shape of Appendix B of the cores spec).

**Status: first release.** See "What works" and "Not implemented" below.

## Where things are

| | |
|---|---|
| RFC 0002 (`text/0002-jumpstart-systemd-core.md` in the `rfcs` repository) | The specification and the implementation work breakdown. Start with "Scope decisions for the owner". |
| `src/` | Implementation (work packages A to F in spec §18). |
| `tests/` | `unit/` (pure), `process/` (real processes; Linux for some). `scripts/run-tests.sh`, `scripts/linux-test.sh`. |
| `share/` | Files installed with the core (README, example units). |

Spec paths written as `cores/systemd/...` mean the root of this repository.

## Relationship to Jumpstart

Jumpstart discovers a core from `/usr/lib/jumpstart/cores/NAME/` (cores spec
§8). This repository builds the contents of `/usr/lib/jumpstart/cores/systemd/`
(`init.kg`, `bin/...`, `share/...`) and nothing else. Enable it with
`jumpctl cores enable systemd`.

The Jumpstart cores specification (RFC 0001, `text/0001-jumpstart-cores.md` in the
`rfcs` repository) is the source of truth for the manifest, the exec
protocol, the operation registry and the error codes. Where this repository's
spec and that one disagree, that one wins.

## The shared library: `jumpstartcore`

Code that every core needs is **not** copied here. It lives in the Jumpstart
repository as the `jumpstartcore` library (`libs/jumpstartcore`): exec protocol
codec, operation registry and result validation, error codes, environment
builder, process spawn, sandbox, reaper, cgroup helpers, and the adapter-side
protocol loop. The Jumpstart daemon imports the same modules, so there is one
copy.

Pin it to a Jumpstart commit or tag:

```nim
# jumpstart-systemd-core.nimble
requires "https://github.com/kreatolinux/src?subdir=libs/jumpstartcore#<commit>"
```

Local development against a Jumpstart checkout next to this one
(`~/Sources/src-2` here): `nim.cfg` already adds
`--path:"$config/../src-2/libs/jumpstartcore/src"`. Edit it if your checkout
lives elsewhere, or use `nimble develop -a:<checkout>/libs/jumpstartcore`.

Rule: if something would be useful to a second core, it goes into
`jumpstartcore`, not into this repository.

## Testing

Tests drive the real binaries through Jumpstart's public surface, not through
its internals. `jumpctl cores run systemd OPERATION [UNIT] [KEY=VALUE...]` runs
any operation of an installed core locally, without the daemon, which makes it
the end-to-end test seam. Process-level tests need Linux (cgroup v2); use a
privileged Linux container with Nim 2.2, a C compiler and a cgroup v2
hierarchy. `scripts/linux-test.sh`, `scripts/build-jumpstart.sh` and
`scripts/jumpstart-integration.sh` run in one; name the image with
`TEST_IMAGE` (default `jumpstart-dev:latest`).

```sh
scripts/run-tests.sh                    # everything, on this machine
scripts/linux-test.sh 'nim c -r --threads:off --outdir:/tmp/out tests/process/test_e2e.nim'
scripts/linux-user-e2e.sh              # the user-scope end-to-end test, as an unprivileged user
make build                             # the five binaries into out/bin
```

`scripts/jumpstart-integration.sh` (after `scripts/build-jumpstart.sh`) runs the
real Jumpstart daemon as PID 1 of a container with a Debian image's own units and
checks: `jumpctl cores check systemd` is clean, the boot target is reached, the
image's timers are active, and `hello.service` starts, reports `active` through
`systemctl is-active`, and stops. The one failed unit it tolerates is
`e2scrub_reap.service`, which needs the sandbox settings listed below.

## Playing with it in QEMU

A bootable arm64 disk image with Jumpstart as PID 1 and this core enabled (Debian
trixie userland, the `systemd` package present only for its unit files, kernel +
Booster initramfs, GRUB on an ESP, read-only EROFS root with a tmpfs-backed `/etc`
overlay and tmpfs `/var`, `/tmp`, `/root`, `/home`). Needs docker, the
`jumpstart-dev` image (see Testing), the Jumpstart checkout next to this one, and
`qemu-system-aarch64` (hvf on Apple Silicon, kvm on Linux arm64).

```sh
scripts/qemu-image.sh     # builds out/qemu/disk.img (about 2 to 3 minutes the first time)
scripts/qemu-boot.sh      # UEFI boot, serial console on this terminal; leave with Ctrl-a x
```

Log in as `root` / `root` (hostname `kreato-sdc`). Then try `systemctl status`,
`systemctl list-units`, `journalctl -b`, `systemd-run --on-active=2 echo hi`
(timers keep systemd's default `AccuracySec=1min`; add
`--timer-property=AccuracySec=100ms` to see it fire at once), or drop a unit into
`/etc/systemd/system`. `sshd` is up too: `ssh -p 2222 root@localhost`. Power off
with `systemctl poweroff` or `jumpctl poweroff`. Changes to `/etc` and `/var` are
lost at reboot; the disk is copied to `out/qemu/run.img` on every boot.

The serial getty comes from the core's serial-getty generator and `tty1` from a
`getty.target.wants` link; Jumpstart runs no getty of its own. Debian's real
journald, logind and TPM units are removed from the image (the core ships its own
journald; see `scripts/qemu-image-inner.sh`).

### A desktop in the same VM (GNOME on Debian trixie)

```sh
GNOME=1 scripts/qemu-image.sh     # out/qemu-gnome/disk.img (about 880 MB EROFS disk; 6 min cold, 2 min warm)
GNOME=1 GFX=cocoa scripts/qemu-boot.sh          # on macOS; GFX=none + MONITOR_SOCK=/tmp/x/mon.sock
                                                # and `screendump f.ppm` on the monitor for headless runs
```

`dbus`, `polkitd`, `udev` (the stock `systemd-udevd` units), `elogind`, `gdm3`, `gnome-shell`
and `gnome-session` come up with no failed unit and GDM shows its login screen about 20 s
after boot; logging in as `user` / `user` (or typing it into the greeter) reaches the GNOME
overview. Power-off takes about 6 s. `scripts/qemu-image-inner.sh` explains each image-level
workaround next to the code that applies it; the default image is untouched.

### Kreato Linux image

```sh
KPKG_REPO=/path/to/kpkg-repo scripts/kreato-rootfs.sh     # once: the kpkg-installed rootfs, out/qemu-kreato/cache/kreato-root.img
KREATO=1 scripts/qemu-image.sh                            # out/qemu-kreato/disk.img (1.7 GB, about 80 s on top of the rootfs)
KREATO=1 GNOME=1 scripts/qemu-boot.sh                     # virtio-gpu/keyboard/mouse devices; plain KREATO=1 is serial only
```

Same boot chain as above (Booster, GRUB/UEFI, EROFS root, tmpfs `/etc` overlay, Jumpstart as PID 1, this core), but the
userland is [Kreato Linux](https://linux.kreato.dev): the `ghcr.io/kreatolinux/builder:aarch64` image plus
packages installed with `kpkg` (`scripts/kreato-rootfs.sh` documents the steps and the workarounds it needs;
`KPKG_REV` is the recipe commit whose binaries the mirror has, `BUILD_BUDGET` caps the `kpkg build` time). Kernel
(`linux`), `booster`, `eudev`, `dbus`, `util-linux`, `linux-pam`, `openssh` come from the binary mirror; `elogind` is
built from source (about 90 s). Kreato packages ship no systemd units, so `scripts/qemu-files-kreato/` provides
them: `dbus` (plain service: the package is built with `-Dsystemd=disabled`, so no `--address=systemd:`), eudev's
`udevd` + coldplug trigger, `elogind`, `sshd`, and `polkit`, `accounts-daemon`, `upower`, `gdm` for when those
packages are in the rootfs (they are dropped from the image when their binary is missing). The core's own getty,
tmpfiles and sysusers units are enabled by explicit links (there is no systemd package to do it).

Result with the headless set: no failed unit, `systemctl is-system-running` = `running`, `elogind` owns
`org.freedesktop.login1` on the system bus, `root`/`root` and `user`/`user` log in on the serial port and `tty1`
(PAM, elogind session `c1`, `XDG_RUNTIME_DIR=/run/user/1000`), `ssh -p 2222` works, power-off takes about 1 s.
`KREATO_SSH_KEY=file.pub` installs a key for root, `DEBUG_SHELL=1` starts a Jumpstart-native root shell on the serial
port, `DIAG=1 KDIAG_UNITS="a b" KDIAG_EXTRA="cmds"` prints the unit state and journal there 25 s after boot.

The **GNOME desktop is not reached**: the binary mirror has no `gdm`, `gnome-shell`, `mutter`, `polkit`,
`accountsservice`, `gtk4`, `libadwaita`, ... and the source build stops at `polkit`/`accountsservice` (their meson
files need `gobject-introspection-1.0.pc`, which the repository's `gobject-introspection` 1.86 package no longer
ships). The image-level fixes for Kreato's layout (`/usr/var/run`, `/lib64`, `/usr/sbin` vs `/usr/bin`, missing
groups, PAM helper path) are commented in `scripts/qemu-image-kreato-inner.sh`; `make install SBINDIR=/usr/bin`
puts `poweroff`/`reboot`/`halt` in front of busybox's.

### Known gaps with desktop stacks

- No `org.freedesktop.systemd1` on the system bus. `dbus-daemon --systemd-activation` therefore
  cannot hand activations to the core (the image drops that flag and starts `polkit`, `upower`,
  `accounts-daemon`, `udisks2`, `colord` and `elogind` at boot), `gnome-session` falls back to
  its non-systemd startup path, `polkitd` 126 calls `GetUnitByPIDFD` and `gsd-sharing` watches
  units. Smallest useful subset: a bus client in the manager answering `GetUnit*`,
  `StartUnit`/`StopUnit`/`RestartUnit`, `Subscribe`, `ListUnits`, `Get`/`GetAll` of the unit
  and manager properties and the `ActivationRequest` signal (about 1500 to 2500 lines, mostly
  the D-Bus wire protocol, which the core does not have).
- `logind` is provided by Debian's `elogind` run as an ordinary service (Gentoo-style); it only
  needs `org.freedesktop.login1` and the hierarchy it creates itself, so it does not need the
  manager API. Debian's `elogind` package conflicts with `systemd`, so the image unpacks the
  `.deb` payload instead of installing it. Still missing from the core for a clean setup:
  cgroup delegation for session scopes (`Delegate=yes` is accepted; the session processes are
  not in `session-*.scope` units, so `systemctl status` does not show them), `systemd-user-sessions`
  style `nologin` handling is untested.
- `hostnamed`, `timedated`, `localed`, `machined`, `resolved`: absent. GNOME degrades with
  warnings (`hostnamectl` and `timedatectl` fail, the shell shows no locale and the clock still
  works).
- `Type=dbus` is parsed as `exec`: readiness is not tied to the bus name, so ordering
  after a `BusName=` service is only "process started".
- `PrivateUsers=yes` is refused (exit 226); the image adds `PrivateUsers=no` drop-ins.
- No `ConditionVirtualization=`, `ConditionNeedsUpdate=`; no `systemd-hwdb`/`machine-id` setup
  units beyond what the stock files do.

## What works

- Unit files with systemd semantics: parsing, specifiers, drop-ins, templates,
  aliases, masks, `[Install]` symlink farm, presets, conditions, the dependency
  and ordering engine with transactions and job modes.
- Services: `simple`, `exec`, `forking`, `oneshot`, `notify`, `notify-reload`,
  `idle`; restart policy, timeouts, killing, watchdog, reload, `sd_notify`,
  socket activation (`LISTEN_FDS` for every command of a service).
- Socket, mount (with fstab generator and mountinfo mirror), swap (`swapon`/`swapoff`,
  fstab `swap` lines, `/proc/swaps` mirror), path (inotify), automount (autofs direct
  mounts, `TimeoutIdleSec=` expiry, `x-systemd.automount`) and timer units
  (`OnCalendar=` full grammar, `Persistent=`, monotonic timers, `OnClockChange=`,
  `OnTimezoneChange=`, `AccuracySec=` coalescing).
- `sd_notify` `FDSTORE=1`, `FDSTOREREMOVE=1`, `FDNAME=` with `FileDescriptorStoreMax=` and
  `FileDescriptorStorePreserve=`; stored descriptors are passed back through `LISTEN_FDS`
  after the socket descriptors.
- Journal: kernel log intake from `/dev/kmsg` (sequence numbers kept across restarts, boot-time
  conversion), per-source rate limiting with the `Suppressed N messages` entry
  (`RateLimitIntervalSec=`, `RateLimitBurst=`, per-stream overrides), `ForwardToSyslog=`;
  `journalctl --file`, `--header`, `--verify`, `--new-id128`.
- User scope (`JUMPSTART_MODE=user`): per-user roots, the 17-directory user unit search path,
  user services, the `0600` public socket, `systemctl --user`, the user journal
  (`_SYSTEMD_USER_UNIT`), tested in process and end to end as an unprivileged user.
- Unit garbage collection (`CollectMode=inactive` / `inactive-or-failed`, referenced units kept),
  re-run after `daemon-reload`.
- A journal (`systemd-journald` replacement) with `journalctl`; `systemctl`,
  `systemd-notify`, `systemd-escape`, `systemd-run`, `systemd-analyze`,
  `systemd-tmpfiles`, `systemd-sysusers` and the power wrappers as one multi-call
  binary; all 53 routed Jumpstart operations.
- `systemctl edit` (drop-in, `--full`, `--runtime`, `--stdin`), `set-property` (persistent
  and `--runtime` control drop-ins), `clean`, `list-timers`; `systemd-run` transient
  services and timers (`--wait`, `--pty`/`--pipe`, `--collect`); external unit generators
  (`/usr/lib/systemd/system-generators` and the other directories) at boot and
  `daemon-reload`; `tmpfiles.d` and `sysusers.d` with their setup units.

## Not implemented

- The sandbox is applied by the executor (mount/network/IPC/UTS namespaces, `Protect*`,
  `Private*`, path lists, `Bind*`, `RootDirectory=`, capabilities, seccomp-bpf, `DynamicUser=`,
  credentials). Still failing closed with exit 226 (and the reason on standard error):
  `PrivateUsers=yes`, `SystemCallArchitectures=` other than `native`. Not available at all:
  `RootImage=` and the other disk-image settings (not parsed), `PrivatePIDs=`. Gaps: the manager
  does not yet remove `PrivateTmp=` directories (`removePrivateTmp` in `executor/sandbox.nim`) or
  credential directories (`removeCredentials` in `executor/creds.nim`) when a unit stops;
  `MountAPIVFS=` mounts `/proc`, `/sys` and `/dev` but no `/run` view; `RestrictSUIDSGID=` covers the
  `chmod` family only; `~` in `SystemCallFilter=`, `CapabilityBoundingSet=`, `RestrictAddressFamilies=`
  and `RestrictNamespaces=` covers the rest of the (flattened) word list; the user-namespace
  fallback of an unprivileged manager is untested here. Resource control is parsed and shown, not
  applied.
- Path units watch a glob only through the directory of its literal prefix; automount units
  need Linux with `autofs` and run the mount helper of an automounted mount in the manager's
  process group (so no sandbox settings apply to it).
- `systemd-run --scope` (no scope units: the command runs in place, with a warning) and
  `--machine`/`--shell`; `systemd-analyze` `dot`, `plot`, `inspect-elf`, `condition` and the
  rest of the R subcommands (`security` is a reduced check table); `systemd-tmpfiles` ACL
  (`a`, `A`), xattr (`t`, `T`) and chattr (`h`, `H`) lines are skipped with a warning;
  `systemd-sysusers` has no `u+`/credential forms.
- Journal: no compression, sealing (`--setup-keys`, `--verify-key`), namespaces, remote
  journals, catalog (`-x` is accepted and ignored) or audit records; `--file`, `--header`
  and `--verify` read this core's own `SDCJRN01` files, not systemd's binary format;
  `ForwardToKMsg=`, `ForwardToConsole=`, `ForwardToWall=` are parsed and ignored.
- User scope: no `loginctl`/logind (Jumpstart's `jumpctl users linger` replaces
  `enable-linger`); the user journal is started on demand by its socket, never at boot.
- Unit garbage collection unloads inactive units; a unit loaded only by a query is
  dropped by a sweep that runs every 5 seconds, not at once.

## License

This repository is GPL-3.0, like Jumpstart (`LICENSE`). The `jumpstartcore`
library it depends on is LGPL-3.0-or-later.
