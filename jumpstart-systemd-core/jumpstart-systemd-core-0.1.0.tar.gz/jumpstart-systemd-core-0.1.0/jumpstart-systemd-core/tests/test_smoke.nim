## Smoke test: the shared jumpstartcore library resolves and the registry this
## core must implement is the one the spec was written against.
import std/[options, unittest]
import jumpstartcore/registry
import jumpstart_systemd_core

suite "scaffold":
  test "the exec protocol name is the one in the cores spec":
    check ProtocolName == "jumpstart-core/1"

  test "the registry has the 54 operations the systemd spec maps (spec §13)":
    check registeredOperationCount() == 54

  test "unit.translate is a registry operation (the only unsupported one)":
    check findOperation(CurrentManifestVersion, "unit.translate").isSome
