import std/[options, os, strutils, unittest]
import harness
import engine/[types, graph]
import service/service

suite "service lifecycle":
  var h = newHarness()
  teardown: discard
  test "simple service starts and stops":
    h.writeUnit("a.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sh -c 'sleep 30'\n")
    h.reload()
    let o = h.startUnit("a.service")
    check o.isSome and o.get.result == jrDone
    check h.state("a.service") == "active/running"
    let u = h.m.lookup("a.service")
    check sd(u).mainPid > 0
    let stop = h.startUnit("a.service", jtStop)
    check stop.get.result == jrDone
    check h.state("a.service") == "inactive/dead"
  test "oneshot runs and finishes":
    h.writeUnit("o.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/usr/bin/true\n")
    h.reload()
    let o = h.startUnit("o.service")
    check o.get.result == jrDone
    check h.state("o.service") == "inactive/dead"
  test "oneshot with RemainAfterExit stays active":
    h.writeUnit("r.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nRemainAfterExit=yes\nExecStart=/usr/bin/true\nExecStop=/usr/bin/true\n")
    h.reload()
    check h.startUnit("r.service").get.result == jrDone
    check h.state("r.service") == "active/exited"
    check h.startUnit("r.service", jtStop).get.result == jrDone
    check h.state("r.service") == "inactive/dead"
  test "failing oneshot fails with exit-code":
    h.writeUnit("f.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'exit 3'\n")
    h.reload()
    let o = h.startUnit("f.service")
    check o.get.result == jrFailed
    check "exited with status" in o.get.message or "exit" in o.get.message
    check h.state("f.service") == "failed/failed"
    check h.m.lookup("f.service").result == "exit-code"
  test "missing program fails the start (exec type)":
    h.writeUnit("m.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=exec\nExecStart=/nonexistent/prog\n")
    h.reload()
    let o = h.startUnit("m.service")
    check o.get.result == jrFailed
    check h.m.lookup("m.service").result == "exit-code"
  test "ExecStartPre failure prevents the start and ExecStopPost still runs":
    let marker = h.base / "stoppost"
    h.writeUnit("p.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStartPre=/usr/bin/false\nExecStart=/bin/sleep 30\nExecStopPost=/usr/bin/touch " & marker & "\n")
    h.reload()
    check h.startUnit("p.service").get.result == jrFailed
    check fileExists(marker)
  test "Restart=on-failure restarts and counts":
    h.writeUnit("rs.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nRestart=on-failure\nRestartSec=100ms\nExecStart=/bin/sh -c 'sleep 0.2; exit 1'\n")
    h.reload()
    check h.startUnit("rs.service").get.result == jrDone
    let u = h.m.lookup("rs.service")
    check h.pump(proc(): bool = sd(u).nRestarts >= 2, 8000)
    discard h.startUnit("rs.service", jtStop)
    check h.state("rs.service") == "inactive/dead"
  test "start timeout fails a stuck forking service":
    h.writeUnit("t.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=forking\nTimeoutStartSec=500ms\nExecStart=/bin/sleep 30\n")
    h.reload()
    let o = h.startUnit("t.service")
    check o.get.result == jrFailed
    check h.m.lookup("t.service").result == "timeout"
  test "stop timeout escalates to SIGKILL":
    h.writeUnit("k.service", "[Unit]\nDefaultDependencies=no\n[Service]\nTimeoutStopSec=500ms\nExecStart=/bin/sh -c 'trap \"\" TERM; while :; do sleep 1; done'\n")
    h.reload()
    check h.startUnit("k.service").get.result == jrDone
    sleep 300   # let the shell install its trap
    let o = h.startUnit("k.service", jtStop, timeoutMs = 10_000)
    check o.get.result == jrDone
    check h.state("k.service") in ["failed/failed", "inactive/dead"]
    check h.m.lookup("k.service").result == "timeout"
  test "conditions skip the job":
    h.writeUnit("c.service", "[Unit]\nDefaultDependencies=no\nConditionPathExists=/nonexistent\n[Service]\nExecStart=/usr/bin/true\n")
    h.reload()
    let o = h.startUnit("c.service")
    check o.get.result == jrSkipped
    check h.state("c.service") == "inactive/dead"
    check h.m.lookup("c.service").failedCondition == "ConditionPathExists=/nonexistent"
  test "cleanup":
    h.cleanup()
