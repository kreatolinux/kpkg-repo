## Swap units against the real kernel (Linux, root, a loop device).
when defined(linux):
  import std/[options, os, osproc, posix, sequtils, strutils, unittest]
  import harness
  import engine/[types, graph]
  import units/swap

  proc swapListed(dev: string): bool =
    for e in parseProcSwaps(readFile("/proc/swaps")):
      if e.path == dev: return true

  suite "swap units":
    test "start swapon, state follows /proc/swaps, stop swapoff; mirrors for foreign swap areas":
      let img = getTempDir() / "sdc-swap.img"
      var dev = ""
      if geteuid() == 0:
        let f = open(img, fmWrite)
        f.write(newString(4 * 1024 * 1024))
        f.close()
        discard posix.chmod(img.cstring, 0o600)
        if execCmdEx("mkswap " & img).exitCode == 0:
          let r = execCmdEx("losetup -f --show " & img)
          if r.exitCode == 0: dev = r.output.strip
      if dev.len == 0:
        skip()
      else:
        defer:
          discard execCmdEx("swapoff " & dev)
          discard execCmdEx("losetup -d " & dev)
          removeFile(img)
        if execCmdEx("swapon " & dev).exitCode != 0:
          skip()
        else:
          discard execCmdEx("swapoff " & dev)
          let h = newHarness()
          h.m.roots.swaps = "/proc/swaps"
          let name = swapUnitName(dev)
          h.writeUnit(name, "[Unit]\nDefaultDependencies=no\n[Swap]\nWhat=" & dev & "\nPriority=7\nOptions=nofail\n")
          h.reload()
          h.m.watchSwaps()
          check h.state(name) == "inactive/dead"
          check h.startUnit(name).get.result == jrDone
          check h.state(name) == "active/active"
          check swapListed(dev)
          let entry = parseProcSwaps(readFile("/proc/swaps")).filterIt(it.path == dev)[0]
          check entry.priority == 7
          check h.startUnit(name, jtStop).get.result == jrDone
          check h.state(name) == "inactive/dead"
          check not swapListed(dev)
          # a swap area enabled behind the manager's back is noticed
          check execCmdEx("swapon " & dev).exitCode == 0
          check h.waitState(name, "active/active", 5000)
          check execCmdEx("swapoff " & dev).exitCode == 0
          check h.waitState(name, "inactive/dead", 5000)
          h.cleanup()
    test "a failing swapon fails the unit with exit-code":
      if geteuid() != 0: skip()
      else:
        let h = newHarness()
        h.m.roots.swaps = "/proc/swaps"
        h.writeUnit("dev-null.swap", "[Unit]\nDefaultDependencies=no\n[Swap]\nWhat=/dev/null\n")
        h.reload()
        check h.startUnit("dev-null.swap").get.result == jrFailed
        check h.state("dev-null.swap") == "failed/failed"
        check h.m.lookup("dev-null.swap").result == "exit-code"
        h.cleanup()
    test "a What= that does not match the unit name is refused":
      let h = newHarness()
      h.writeUnit("wrong.swap", "[Unit]\nDefaultDependencies=no\n[Swap]\nWhat=/dev/null\n")
      h.reload()
      check h.startUnit("wrong.swap").get.result != jrDone
      h.cleanup()
