## The systemctl front-end against a scripted `sdc/1` manager: the requests it
## sends and the output it prints for the verbs that need a manager.
import std/[json, os, osproc, streams, strtabs, strutils, sequtils, unittest, monotimes, times]
import std/posix
import jumpstartcore/errors
import ipc/sdcproto

type
  Reply = object
    ok: bool
    result: JsonNode
    message: string

  Handler = proc(a: JsonNode): Reply {.closure.}

  Fake = object
    dir, path: string
    listenFd: cint
    requests: seq[SdcRequest]

const repoRoot = currentSourcePath().parentDir.parentDir.parentDir
let tools = getTempDir() / "tools_main_frontend_sdc"

proc buildTools() =
  if not fileExists(tools):
    doAssert execCmd("nim c --threads:off --hints:off -o:" & tools & " " & repoRoot / "src/tools_main.nim") == 0

proc ok(value: JsonNode = nil): Reply =
  Reply(ok: true, result: (if value.isNil: newJObject() else: value))

proc fail(message: string): Reply =
  Reply(ok: false, message: message)

proc writeAllFd(fd: cint; text: string): bool =
  var off = 0
  while off < text.len:
    let n = write(fd, unsafeAddr text[off], text.len - off)
    if n <= 0:
      if errno == EINTR: continue
      return false
    off += n
  true

proc newFake(): Fake =
  ## A listening socket where the front-end expects the user manager's.
  result.dir = getTempDir() / ("sdc-fake-" & $getpid())
  removeDir(result.dir)
  createDir(result.dir / "systemd")
  result.path = result.dir / "systemd" / "compat.sock"
  result.listenFd = cint(socket(AF_UNIX, SOCK_STREAM, 0))
  doAssert result.listenFd >= 0
  var a: Sockaddr_un
  a.sun_family = TSa_Family(AF_UNIX)
  doAssert result.path.len < a.sun_path.len
  copyMem(addr a.sun_path[0], result.path.cstring, result.path.len)
  doAssert bindSocket(SocketHandle(result.listenFd), cast[ptr SockAddr](addr a),
    SockLen(offsetOf(Sockaddr_un, sun_path) + result.path.len)) == 0
  doAssert listen(SocketHandle(result.listenFd), 8) == 0

proc serveOne(f: var Fake; fd: cint; handler: Handler) =
  var buf = ""
  while true:
    var ch: char
    let n = read(fd, addr ch, 1)
    if n <= 0: break
    if ch != '\n':
      buf.add ch
      continue
    let line = buf
    buf.setLen(0)
    var req: SdcRequest
    try: req = parseRequest(line)
    except SdcFailure: break
    f.requests.add req
    let rep = handler(req.args)
    let resp = if rep.ok: okLine(req.id, rep.result) else: errorLine(req.id, ecUnsupported, rep.message)
    if not writeAllFd(fd, resp): break

proc run(f: var Fake; args: seq[string]; handler: Handler;
         timeoutMs = 30000): tuple[output: string, rc: int] =
  ## Runs the tool while this process answers its requests.
  var e = newStringTable()
  for k, v in envPairs(): e[k] = v
  e["XDG_RUNTIME_DIR"] = f.dir
  e["HOME"] = f.dir
  let p = startProcess(tools, args = args, env = e, options = {poStdErrToStdOut, poUsePath})
  let deadline = getMonoTime() + initDuration(milliseconds = timeoutMs)
  while p.running and getMonoTime() < deadline:
    var pfd = TPollfd(fd: f.listenFd, events: POLLIN)
    if poll(addr pfd, 1, 50) > 0:
      let cfd = cint(accept(SocketHandle(f.listenFd), nil, nil))
      if cfd >= 0:
        f.serveOne(cfd, handler)
        discard close(SocketHandle(cfd))
  if p.running: terminate(p)
  result.output = p.outputStream.readAll()
  result.rc = p.waitForExit()
  p.close()

proc last(f: Fake; verb: string): SdcRequest =
  for i in countdown(f.requests.len - 1, 0):
    if f.requests[i].verb == verb: return f.requests[i]
  raise newException(ValueError, "no " & verb & " request was sent")

buildTools()

suite "systemctl against a scripted manager":
  test "clean defaults to cache, runtime and logs":
    var f = newFake()
    let h: Handler = proc(a: JsonNode): Reply = ok(%*{"removed": 1})
    let r = f.run(@["systemctl", "--user", "clean", "sp.service"], h)
    check r.rc == 0
    let q = f.last("clean")
    check q.args["unit"].getStr == "sp.service"
    check q.args["what"].getElems.mapIt(it.getStr) == @["cache", "runtime", "logs"]
    var g = newFake()
    check g.run(@["systemctl", "--user", "clean", "--what=state,fdstore", "sp.service"], h).rc == 0
    check g.last("clean").args["what"].getElems.mapIt(it.getStr) == @["state", "fdstore"]

  test "list-dependencies sends --after and --before":
    var f = newFake()
    let tree = %*{"name": "a.target", "active": "active", "children": [
      {"name": "b.service", "active": "failed", "children": []}]}
    let h: Handler = proc(a: JsonNode): Reply = ok(%*{"tree": tree})
    let r = f.run(@["systemctl", "--user", "list-dependencies", "--after", "--before", "a.target"], h)
    check r.rc == 0
    let q = f.last("unit-deps")
    check q.args["name"].getStr == "a.target"
    check q.args["after"].getBool and q.args["before"].getBool
    check not q.args["reverse"].getBool
    check r.output.contains("a.target")
    check r.output.contains("b.service")

  test "stop names the units that can still activate it":
    var f = newFake()
    let h: Handler = proc(a: JsonNode): Reply =
      ok(%*{"job": 1, "result": "done", "state": "inactive",
            "triggering": ["sshd.socket", "sshd.timer"]})
    let r = f.run(@["systemctl", "--user", "stop", "sshd.service"], h)
    check r.rc == 0
    check "Stopping sshd.service, but it can still be activated by: sshd.socket, sshd.timer." in r.output
    var g = newFake()
    let quiet: Handler = proc(a: JsonNode): Reply = ok(%*{"job": 1, "result": "done", "state": "inactive"})
    let r2 = g.run(@["systemctl", "--user", "stop", "sshd.service"], quiet)
    check r2.rc == 0
    check "can still be activated" notin r2.output

  test "freeze and thaw send the unit list":
    var f = newFake()
    let h: Handler = proc(a: JsonNode): Reply = ok(%*{"changed": 2})
    let r = f.run(@["systemctl", "--user", "freeze", "a.service", "b.service"], h)
    check r.rc == 0
    let q = f.last("freeze")
    check q.args["units"].getElems.mapIt(it.getStr) == @["a.service", "b.service"]
    let t = f.run(@["systemctl", "--user", "thaw", "a.service"], h)
    check t.rc == 0
    check f.last("thaw").args["units"].getElems.mapIt(it.getStr) == @["a.service"]

  test "a refused freeze is reported per unit":
    var f = newFake()
    let h: Handler = proc(a: JsonNode): Reply =
      ok(%*{"changed": 0, "failed": [{"unit": "a.service", "message": "unit is not active"}]})
    let r = f.run(@["systemctl", "--user", "freeze", "a.service"], h)
    check r.rc == 1
    check "Failed to freeze a.service: unit is not active" in r.output

  test "exit is a user-scope power action":
    var f = newFake()
    let h: Handler = proc(a: JsonNode): Reply = ok(%*{"accepted": true})
    let r = f.run(@["systemctl", "--user", "exit"], h)
    check r.rc == 0
    let q = f.last("power")
    check q.args["action"].getStr == "exit"
    var g = newFake()
    let refused: Handler = proc(a: JsonNode): Reply = ok(%*{"accepted": false})
    let r2 = g.run(@["systemctl", "--user", "exit"], refused)
    check r2.rc == 1
    check "Failed to exit the user manager." in r2.output

  test "exit in system scope is refused without a manager":
    var f = newFake()
    var asked = 0
    let h: Handler = proc(a: JsonNode): Reply = (inc asked; ok(%*{"accepted": true}))
    let r = f.run(@["systemctl", "--system", "exit"], h)
    check r.rc == 1
    check "Operation not supported by the systemd core." in r.output
    check asked == 0

  test "runlevel reports the active target":
    var f = newFake()
    let h: Handler = proc(a: JsonNode): Reply =
      ok(%*{"units": [{"name": "graphical.target", "properties": {"ActiveState": "active"}},
                      {"name": "multi-user.target", "properties": {"ActiveState": "active"}},
                      {"name": "rescue.target", "properties": {"ActiveState": "inactive"}},
                      {"name": "emergency.target", "properties": {"ActiveState": "inactive"}}]})
    let r = f.run(@["runlevel"], h)
    check r.rc == 0
    check r.output.strip == "N 5"
    var g = newFake()
    let multi: Handler = proc(a: JsonNode): Reply =
      ok(%*{"units": [{"name": "graphical.target", "properties": {"ActiveState": "inactive"}},
                      {"name": "multi-user.target", "properties": {"ActiveState": "active"}},
                      {"name": "rescue.target", "properties": {"ActiveState": "inactive"}},
                      {"name": "emergency.target", "properties": {"ActiveState": "inactive"}}]})
    check g.run(@["runlevel"], multi).output.strip == "N 3"

suite "shutdown and telinit":
  test "a scheduled shutdown is refused":
    let (o, rc) = execCmdEx(tools & " shutdown +5 now")
    check rc == 1
    check "Scheduled shutdown is not supported by the systemd core." in o
    check execCmdEx(tools & " shutdown -c").exitCode == 0
    check execCmdEx(tools & " telinit 9").exitCode == 1
