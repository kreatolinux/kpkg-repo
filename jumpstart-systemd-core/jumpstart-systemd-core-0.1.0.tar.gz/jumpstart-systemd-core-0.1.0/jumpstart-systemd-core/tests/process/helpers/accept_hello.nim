## Socket-activation test helper: accepts one connection on descriptor 3
## (LISTEN_FDS=1) and answers "hello <LISTEN_FDNAMES>".
import std/[os, posix]
doAssert getEnv("LISTEN_PID") == $getpid() and getEnv("LISTEN_FDS") == "1"
let c = accept(SocketHandle(3), nil, nil)
let msg = "hello " & getEnv("LISTEN_FDNAMES")
discard write(cint(c), msg.cstring, msg.len)
discard close(cint(c))
