## How the Jumpstart daemon assembles a streamed reply (jumpstart protocol
## §17.4; jumpstart/cores/backends/adapter_runtime.nim `mergeItems`): `item`
## events are appended to the named result field in the order received, before
## any elements the final response itself contains. Tests use this to check
## what a client (`jumpctl`) actually sees.
import std/[json, tables]

proc daemonMerge*(value: JsonNode; items: seq[(string, JsonNode)]): JsonNode =
  ## `items` are (field, data) pairs in arrival order.
  result = value.copy
  var byField = initOrderedTable[string, seq[JsonNode]]()
  for (field, data) in items: byField.mgetOrPut(field, @[]).add data
  for field, values in byField:
    var combined = newJArray()
    for v in values: combined.add v
    if result.hasKey(field):
      doAssert result[field].kind == JArray, field & " is not a list"
      for v in result[field]: combined.add v
    result[field] = combined
