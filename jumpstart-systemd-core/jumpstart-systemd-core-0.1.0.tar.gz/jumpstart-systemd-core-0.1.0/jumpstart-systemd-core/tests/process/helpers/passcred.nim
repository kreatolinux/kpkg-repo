## Socket-activation helper: writes SO_PASSCRED and SO_TYPE of descriptor 3 to argv[1].
import std/[os, posix]
var v: cint
var l = SockLen(sizeof(v))
var cred = -1
var typ = -1
if getsockopt(SocketHandle(3), SOL_SOCKET, 16, addr v, addr l) == 0: cred = int(v)
l = SockLen(sizeof(v))
if getsockopt(SocketHandle(3), SOL_SOCKET, SO_TYPE, addr v, addr l) == 0: typ = int(v)
writeFile(paramStr(1), "passcred=" & $cred & " type=" & $typ & "\n")
