#!/bin/sh
# FDSTORE test helper: records LISTEN_* of this run, then idles.
echo "$LISTEN_FDS:$LISTEN_FDNAMES" >> "$1"
sleep 30
