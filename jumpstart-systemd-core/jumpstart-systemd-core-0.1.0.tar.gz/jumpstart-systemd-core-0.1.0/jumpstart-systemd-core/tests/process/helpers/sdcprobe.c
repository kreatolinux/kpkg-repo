/* Calls one system call and prints "ok" or "errno N": the oracle for the
 * seccomp tests (tests/process/test_sandbox.nim). */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/personality.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/sysmacros.h>
#include <unistd.h>

static int report(long r) {
  if (r < 0) printf("errno %d\n", errno); else printf("ok\n");
  return 0;
}

int main(int argc, char **argv) {
  if (argc < 3) return 2;
  const char *c = argv[1];
  long v = strtol(argv[2], 0, 0);
  if (!strcmp(c, "socket")) { int s = socket((int)v, SOCK_DGRAM, 0); return report(s); }
  if (!strcmp(c, "unshare")) return report(unshare((int)v));
  if (!strcmp(c, "setns")) return report(setns(-1, (int)v));
  if (!strcmp(c, "chmod")) {
    char t[] = "/tmp/sdcprobeXXXXXX"; int fd = mkstemp(t); close(fd);
    long r = chmod(t, (mode_t)v); int e = errno; unlink(t); errno = e; return report(r);
  }
  if (!strcmp(c, "personality")) return report(personality((unsigned long)v));
  if (!strcmp(c, "mmap")) { /* v: protection bits */
    void *p = mmap(0, 4096, (int)v, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    return report(p == MAP_FAILED ? -1 : 0);
  }
  if (!strcmp(c, "mprotect")) {
    void *p = mmap(0, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    return report(mprotect(p, 4096, (int)v));
  }
  if (!strcmp(c, "sched")) { struct sched_param sp = { v ? 1 : 0 }; return report(sched_setscheduler(0, (int)v, &sp)); }
  if (!strcmp(c, "mknod")) {
    long r = mknod("/tmp/sdc-probe-node", (mode_t)v, makedev(1, 3)); int e = errno;
    unlink("/tmp/sdc-probe-node"); errno = e; return report(r);
  }
  if (!strcmp(c, "getpid")) return report(syscall(SYS_getpid));
  if (!strcmp(c, "mount")) { long r = syscall(SYS_mount, 0, 0, 0, 0, 0); return report(r); }
  if (!strcmp(c, "syslog")) return report(syscall(SYS_syslog, 10, 0, 0));
  if (!strcmp(c, "sethostname")) return report(sethostname("sdc-probe", 9));
  return 2;
}
