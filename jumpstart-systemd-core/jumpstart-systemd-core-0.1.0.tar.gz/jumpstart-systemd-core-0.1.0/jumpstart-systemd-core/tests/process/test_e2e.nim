## End to end on Linux as root: the real manager, adapter, executor, journald
## and tools, started the way Jumpstart starts them (spawn layer, protocol
## descriptors, cgroups), driven through the adapter protocol and `systemctl`.
## Writes below /etc/systemd/system and /run/systemd: run in a throwaway
## container only (scripts/linux-test.sh).
# needs cgroups, root and a throwaway container: the body exists on Linux only
when defined(linux):
  import std/[json, options, os, osproc, posix, strutils, unittest]
  import std/sequtils
  import jumpstartcore/[spawn, reaper, protocol, jsonlines, environment]
  import ./helpers/daemonmerge


  const root = currentSourcePath().parentDir.parentDir.parentDir
  let work = "/tmp/sdc-e2e"
  let core = work / "core"
  let rt = work / "rt"
  let st = work / "st"
  let cgBase = "/sys/fs/cgroup/sdc-e2e/cores/systemd"

  proc sh(cmd: string): (string, int) = execCmdEx(cmd, options = {poStdErrToStdOut, poUsePath})

  suite "end to end":
    var rp = newReaper()
    rp.installSigChldHandler()
    var managerPid, adapterPid: Pid
    var adIn, adOut: cint
    var logFd: cint

    setup:
      discard
    test "build and install the core tree":
      check geteuid() == 0
      removeDir(work)
      createDir(core / "bin"); createDir(rt); createDir(st)
      discard sh("make -C " & root & " build NIMFLAGS='-d:debug --threads:off' BIN=" & core / "bin")
      for n in ["systemd-compat-manager", "systemd-compat", "systemd-compat-exec", "systemd-compat-journald", "systemd-compat-tools"]:
        check fileExists(core / "bin" / n)
      copyDir(root / "share", core / "share")
      for f in walkFiles(core / "share/units/*.service"):
        writeFile(f, readFile(f).replace("@COREDIR@", core))
      discard sh("chmod -R go-w " & core)
      # unit files under test
      createDir("/etc/systemd/system")
      writeFile("/etc/systemd/system/e2e.target", "[Unit]\nDescription=E2E\nRequires=basic.target\nAfter=basic.target\nWants=hello.service\nAllowIsolate=yes\n")
      removeFile("/etc/systemd/system/default.target")
      if getEnv("SDC_E2E_REAL_DEFAULT").len == 0:
        createSymlink("/etc/systemd/system/e2e.target", "/etc/systemd/system/default.target")
      writeFile("/etc/systemd/system/hello.service", "[Unit]\nDescription=Hello\nAfter=basic.target\n[Service]\nExecStart=/bin/sh -c 'echo hello-from-hello; exec sleep 300'\n[Install]\nWantedBy=e2e.target\n")
      writeFile("/etc/systemd/system/oneshot.service", "[Service]\nType=oneshot\nExecStart=/bin/sh -c 'echo oneshot-ran'\nStandardOutput=journal\n")
    test "cgroup layout and manager start":
      createDir(cgBase / "control"); createDir(cgBase / "units")
      check dirExists(cgBase / "units")
      logFd = open((work / "manager.log").cstring, O_WRONLY or O_CREAT or O_TRUNC, 0o644)
      let nul = open("/dev/null", O_RDWR)
      var env: seq[EnvPair] = @[("PATH", SystemPath), ("JUMPSTART_CORE_NAME", "systemd"),
        ("JUMPSTART_CORE_ROOT", core), ("JUMPSTART_CORE_STATE_DIR", st),
        ("JUMPSTART_CORE_RUNTIME_DIR", rt), ("JUMPSTART_MODE", "system")]
      let exe = openVerifiedExecutable(core / "bin/systemd-compat-manager", 0, core)
      let spec = ProcessSpec(executable: core / "bin/systemd-compat-manager", executableFd: some(exe.fd),
        environment: env, workingDirectory: "/", protocol: true, supervisorSubreaper: true,
        cgroupProcs: cgBase / "control/cgroup.procs", explicitStdio: some([nul, logFd, logFd]))
      let sp = spawn.spawn(spec, rp, "manager")
      managerPid = sp.pid
      let offer = helloOffer(crSupervisor, "systemd", "system", "2.0.0")
      writeAllFd(sp.protocolWriteFd, encodeLine(offer))
      let reply = parseLine(readLineFd(sp.protocolReadFd))
      check reply.kind == pmHelloReply and reply.role == crSupervisor
      check access("/run/systemd/compat.sock", F_OK) == 0 and access((rt / "manager.sock").cstring, F_OK) == 0
    test "adapter handshake lists 53 operations":
      var env: seq[EnvPair] = @[("PATH", SystemPath), ("JUMPSTART_CORE_NAME", "systemd"),
        ("JUMPSTART_CORE_ROOT", core), ("JUMPSTART_CORE_STATE_DIR", st),
        ("JUMPSTART_CORE_RUNTIME_DIR", rt), ("JUMPSTART_MODE", "system")]
      let nul = open("/dev/null", O_RDWR)
      let exe = openVerifiedExecutable(core / "bin/systemd-compat", 0, core)
      let spec = ProcessSpec(executable: core / "bin/systemd-compat", executableFd: some(exe.fd),
        environment: env, workingDirectory: "/", protocol: true,
        cgroupProcs: cgBase / "control/cgroup.procs", explicitStdio: some([nul, logFd, logFd]))
      let sp = spawn.spawn(spec, rp, "adapter")
      adapterPid = sp.pid
      adIn = sp.protocolWriteFd
      adOut = sp.protocolReadFd
      writeAllFd(adIn, encodeLine(helloOffer(crAdapter, "systemd", "system", "2.0.0")))
      let reply = parseLine(readLineFd(adOut))
      check reply.kind == pmHelloReply
      check reply.operations.len == 53
    proc ask(id, op, unit: string; args: JsonNode = newJObject()): (JsonNode, seq[JsonNode], string, string) =
      ## The result as a client sees it: item events merged into the final
      ## result the way the Jumpstart daemon does (§17.4).
      writeAllFd(adIn, encodeLine(request(id, op, unit, args, deadlineAfter(30_000))))
      var items: seq[JsonNode]
      var fielded: seq[(string, JsonNode)]
      while true:
        let m = parseLine(readLineFd(adOut))
        case m.kind
        of pmEventItem:
          items.add m.data
          fielded.add (m.field, m.data)
        of pmResponseOk: return (daemonMerge(m.result, fielded), items, "", "")
        of pmResponseError: return (nil, items, m.error.code, m.error.message)
        else: discard
    test "unit.list, unit.resolve through the adapter":
      let (r, items, code, msg) = ask("1", "unit.list", "")
      if code.len > 0: echo code, " ", msg
      check code == "" and items.len > 5
      check "hello.service" in items.mapIt(it["name"].getStr)
      # each unit exactly once in what `jumpctl unit list` gets
      let names = r["units"].getElems.mapIt(it["name"].getStr)
      check names == items.mapIt(it["name"].getStr)
      check names.deduplicate.len == names.len
      let (r2, _, c2, _) = ask("2", "unit.resolve", "", %*{"name": "hello"})
      check r2["owned"].getBool and r2["name"].getStr == "hello.service" and r2["subsystem"].getStr == "service"
      let (r3, _, _, _) = ask("3", "unit.resolve", "", %*{"name": "nonexistent"})
      check not r3["owned"].getBool
    test "unit.activate boots the default target and starts journald":
      let (r, _, code, msg) = ask("4", "unit.activate", "")
      check code == ""
      if code.len > 0: echo msg
      check r["started"].getInt >= 3
      let (s, _, _, _) = ask("5", "service.status", "hello.service")
      check s["state"].getStr == "active"
      check s["pids"].len >= 1
      sleep 1500
      let (j, _, _, _) = ask("6", "service.status", "systemd-journald.service")
      check j["state"].getStr == "active"
    test "systemctl front-end":
      let tools = core / "bin/systemd-compat-tools"
      var (o, rc) = sh(tools & " systemctl is-active hello.service")
      check o.strip == "active" and rc == 0
      (o, rc) = sh(tools & " systemctl start oneshot.service")
      check rc == 0
      (o, rc) = sh(tools & " systemctl stop hello.service")
      check rc == 0
      (o, rc) = sh(tools & " systemctl is-active hello.service")
      check o.strip == "inactive" and rc == 3
      (o, rc) = sh(tools & " systemctl start hello.service")
      check rc == 0
      (o, rc) = sh(tools & " systemctl status hello.service --no-pager")
      check "hello.service" in o and "active (running)" in o
      (o, rc) = sh(tools & " systemctl enable hello.service")
      check rc == 0
      (o, rc) = sh(tools & " systemctl list-units --no-legend")
      check "hello.service" in o
      (o, rc) = sh(tools & " systemctl start nonexistent.service")
      check rc == 1
    test "installed multi-call symlink dispatches on its own name":
      let tools = core / "bin/systemd-compat-tools"
      let link = core / "bin/systemctl"
      removeFile(link)
      createSymlink(tools, link)
      let (o, rc) = sh(link & " is-active hello.service")
      check o.strip == "active" and rc == 0
      removeFile(link)
    test "journal received service output":
      sleep 500
      let tools = core / "bin/systemd-compat-tools"
      let (o, rc) = sh("JUMPSTART_CORE_RUNTIME_DIR=" & rt & " JUMPSTART_CORE_STATE_DIR=" & st & " " & tools & " journalctl -u hello.service --no-pager -q")
      check "hello-from-hello" in o
      let (o2, _) = sh("JUMPSTART_CORE_RUNTIME_DIR=" & rt & " JUMPSTART_CORE_STATE_DIR=" & st & " " & tools & " journalctl -u oneshot.service --no-pager -q")
      check "oneshot-ran" in o2
    test "service.stop and service.kill through the adapter":
      let (r, _, code, msg) = ask("7", "service.stop", "hello.service")
      check code == "" and r["state"].getStr == "inactive"
      let (r2, _, c2, m2) = ask("8", "service.start", "hello.service")
      check c2 == "" and r2["state"].getStr == "active"
      let (_, _, c3, _) = ask("9", "service.kill", "hello.service", %*{"signal": "TERM"})
      check c3 == ""
    test "log.read through the adapter":
      let (r, items, code, msg) = ask("10", "log.read", "hello.service", %*{"lines": 5})
      check code == ""
      check r["entries"].len >= 1
      # streamed entries are not repeated in the final result
      check r["entries"].len == items.len
    test "unit.deactivate stops everything":
      let (r, _, code, msg) = ask("11", "unit.deactivate", "")
      check code == ""
      let (s, _, _, _) = ask("12", "service.status", "hello.service")
      check s["state"].getStr in ["inactive", "failed"]
    test "teardown":
      discard close(adIn)
      discard kill(managerPid, SIGTERM)
      sleep 500
      discard sh("echo manager log; tail -30 " & work / "manager.log")
