## A manager over a temporary directory tree for process-level tests: real
## unit files, the real executor, cgroup-less (no cgroup placement), driven by
## stepping the event loop.
import std/[os, osproc, options, strutils, times, posix]
import common/[roots, clock]
import unitfile/model
import engine/[types, graph, jobs, manager, eventloop]
import units/[socket, mount, timer, path, swap, automount]

const repoRoot = currentSourcePath().parentDir.parentDir.parentDir
let builtExec* = getTempDir() / "sdc-harness-exec"
var built = false

type Harness* = ref object
  m*: Manager
  base*: string

proc buildExecutor*() =
  if built: return
  doAssert execCmd("nim c --threads:off --hints:off -o:" & builtExec & " " &
    repoRoot / "src/executor_main.nim") == 0
  built = true

proc newHarness*(clock: clock.Clock = nil): Harness =
  buildExecutor()
  let base = "/tmp/sdc-h-" & $getpid() & "-" & $(epochTime().int mod 100000)
  removeDir(base)
  let roots = testRoots(base, scSystem)
  createDir(roots.coreRoot / "bin")
  copyFile(builtExec, roots.coreRoot / "bin/systemd-compat-exec")
  setFilePermissions(roots.coreRoot / "bin/systemd-compat-exec",
    {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec, fpOthersRead, fpOthersExec})
  createDir(roots.etc / "systemd/system")
  installSocketSupport()
  installMountSupport()
  installTimerSupport()
  installPathSupport()
  installSwapSupport()
  installAutomountSupport()
  let m = newManager(roots, clock)
  m.hookReaper()
  Harness(m: m, base: base)

proc unitDir*(h: Harness): string = h.m.roots.etc / "systemd/system"

proc writeUnit*(h: Harness; name, text: string; journal = false) =
  ## Services get `StandardOutput=null` unless `journal`: the default output is
  ## the journal, which pulls in systemd-journald.socket (§7.2).
  var body = text
  if not journal:
    for sec in ["[Service]\n", "[Socket]\n", "[Mount]\n", "[Swap]\n"]:
      var extra = ""
      if "StandardOutput=" notin text: extra.add "StandardOutput=null\n"
      if "StandardError=" notin text: extra.add "StandardError=null\n"
      body = body.replace(sec, sec & extra)
  writeFile(h.unitDir / name, body)

proc reload*(h: Harness) = discard h.m.daemonReload()

proc pump*(h: Harness; cond: proc(): bool; timeoutMs = 10_000): bool =
  ## Steps the loop until `cond` or the timeout.
  let end0 = epochTime() + timeoutMs.float / 1000
  while epochTime() < end0:
    if cond(): return true
    h.m.loop.runOnce(20)
  cond()

proc startUnit*(h: Harness; name: string; typ = jtStart; mode = jmReplace;
                timeoutMs = 10_000): Option[JobOutcome] =
  ## Submits a job and runs the loop until it completes.
  let u = h.m.lookup(name)
  doAssert u != nil, "no unit " & name
  var outcome: Option[JobOutcome]
  let job = submitJob(h.m, u, typ, mode, joManual, proc(o: JobOutcome) = outcome = some(o))
  discard h.pump(proc(): bool = outcome.isSome, timeoutMs)
  outcome

proc state*(h: Harness; name: string): string =
  let u = h.m.lookup(name)
  if u == nil: "not-found" else: $u.active & "/" & u.sub

proc waitState*(h: Harness; name, want: string; timeoutMs = 10_000): bool =
  h.pump(proc(): bool = h.state(name) == want, timeoutMs)

proc cleanup*(h: Harness) =
  for u in h.m.allUnits:
    if u.ops.kill != nil: discard u.ops.kill(h.m, u, kwAll, SIGKILL)
  removeDir(h.base)
