
when defined(linux):
  import std/[os, posix, options, strutils, unittest]
  import harness
  import engine/[types, graph]
  import units/mount

  suite "mount units":
    test "start mounts, stop unmounts, state follows the kernel":
      if geteuid() != 0: skip()
      else:
        let h = newHarness()
        h.m.roots.mountinfo = "/proc/self/mountinfo"
        let where = "/tmp/sdcmnt"
        createDir(where)
        h.writeUnit("tmp-sdcmnt.mount", "[Unit]\nDefaultDependencies=no\n[Mount]\nWhat=tmpfs\nWhere=" & where & "\nType=tmpfs\nOptions=size=1m\n")
        h.reload()
        h.m.watchMountinfo()
        check h.state("tmp-sdcmnt.mount") in ["inactive/dead"]
        check h.startUnit("tmp-sdcmnt.mount").get.result == jrDone
        check h.state("tmp-sdcmnt.mount") == "active/mounted"
        check "tmpfs" in readFile("/proc/self/mountinfo") and where in readFile("/proc/self/mountinfo")
        check h.startUnit("tmp-sdcmnt.mount", jtStop).get.result == jrDone
        check h.state("tmp-sdcmnt.mount") == "inactive/dead"
        h.cleanup()
    test "mirror units exist for kernel mounts":
      let h = newHarness()
      h.m.roots.mountinfo = "/proc/self/mountinfo"
      h.m.watchMountinfo()
      let u = h.m.lookup("proc.mount")
      check u != nil and u.active == asActive and u.perpetual
      h.cleanup()
