## Dependencies, ordering, conflicts, transactions and lifecycle settings
## through real unit files (spec §7).
import std/[options, os, strutils, sequtils, unittest]
import harness
import unitfile/model
import jumpstartcore/errors
import engine/[types, graph]

proc svc(h: Harness; name: string; extra = ""; unitExtra = ""; exec = "/bin/sleep 30") =
  h.writeUnit(name, "[Unit]\nDefaultDependencies=no\n" & unitExtra & "\n[Service]\nExecStart=" & exec & "\n" & extra)

proc target(h: Harness; name: string; unitExtra = "") =
  h.writeUnit(name, "[Unit]\nDefaultDependencies=no\n" & unitExtra & "\n")

suite "dependencies":
  test "Requires pulls in and Wants is weak":
    let h = newHarness()
    h.svc("a.service", unitExtra = "Requires=b.service\nWants=c.service\nAfter=b.service c.service")
    h.svc("b.service")
    h.svc("c.service", exec = "/usr/bin/false", extra = "Type=oneshot\n")
    h.reload()
    check h.startUnit("a.service").get.result == jrDone
    check h.state("a.service") == "active/running"
    check h.state("b.service") == "active/running"
    check h.state("c.service") == "failed/failed"     # weak: its failure does not fail a
    h.cleanup()
  test "Requires failure fails the start with dependency":
    let h = newHarness()
    h.svc("a.service", unitExtra = "Requires=bad.service\nAfter=bad.service")
    h.svc("bad.service", exec = "/usr/bin/false", extra = "Type=oneshot\n")
    h.reload()
    let o = h.startUnit("a.service")
    check o.get.result == jrDependency
    check h.state("a.service") == "inactive/dead"
    h.cleanup()
  test "ordering: After makes the dependency finish first":
    let h = newHarness()
    let log = h.base / "order"
    h.writeUnit("first.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'sleep 0.3; echo first >> " & log & "'\n")
    h.writeUnit("second.service", "[Unit]\nDefaultDependencies=no\nWants=first.service\nAfter=first.service\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'echo second >> " & log & "'\n")
    h.reload()
    check h.startUnit("second.service").get.result == jrDone
    check readFile(log).splitLines.filterIt(it.len > 0) == @["first", "second"]
    h.cleanup()
  test "Requires without After starts in parallel":
    let h = newHarness()
    let log = h.base / "par"
    h.writeUnit("x.service", "[Unit]\nDefaultDependencies=no\nRequires=y.service\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'echo x >> " & log & "'\n")
    h.writeUnit("y.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'echo y >> " & log & "'\n")
    h.reload()
    check h.startUnit("x.service").get.result == jrDone
    check h.pump(proc(): bool = fileExists(log) and readFile(log).splitLines.filterIt(it.len > 0).len == 2, 5000)
    h.cleanup()
  test "stopping a required unit stops its dependents":
    let h = newHarness()
    h.svc("a.service", unitExtra = "Requires=b.service\nAfter=b.service")
    h.svc("b.service")
    h.reload()
    discard h.startUnit("a.service")
    check h.startUnit("b.service", jtStop).get.result == jrDone
    check h.state("a.service") == "inactive/dead"
    h.cleanup()
  test "BindsTo stops the unit when the other exits on its own":
    let h = newHarness()
    h.svc("a.service", unitExtra = "BindsTo=b.service\nAfter=b.service")
    h.svc("b.service", exec = "/bin/sh -c 'sleep 0.5'")
    h.reload()
    discard h.startUnit("a.service")
    check h.waitState("a.service", "inactive/dead", 8000)
    h.cleanup()
  test "Conflicts stops the other unit":
    let h = newHarness()
    h.svc("a.service", unitExtra = "Conflicts=b.service")
    h.svc("b.service")
    h.reload()
    discard h.startUnit("b.service")
    check h.state("b.service") == "active/running"
    check h.startUnit("a.service").get.result == jrDone
    check h.waitState("b.service", "inactive/dead", 5000)     # no ordering: stop runs in parallel
    check h.state("a.service") == "active/running"
    h.cleanup()
  test "target start pulls members through Wants":
    let h = newHarness()
    h.target("t.target", "Wants=m1.service m2.service")
    h.svc("m1.service", unitExtra = "")
    h.svc("m2.service")
    h.reload()
    check h.startUnit("t.target").get.result == jrDone
    check h.state("t.target") == "active/active"
    check h.state("m1.service") == "active/running" and h.state("m2.service") == "active/running"
    check h.startUnit("t.target", jtStop).get.result == jrDone
    h.cleanup()
  test "ordering cycle between weak jobs is broken, strong cycle fails":
    let h = newHarness()
    h.svc("a.service", unitExtra = "Wants=b.service\nAfter=b.service")
    h.svc("b.service", unitExtra = "Wants=a.service\nAfter=a.service")
    h.reload()
    check h.startUnit("a.service").get.result == jrDone      # the weak job of b is dropped
    h.cleanup()
    let h2 = newHarness()
    h2.svc("a.service", unitExtra = "Requires=b.service\nAfter=b.service")
    h2.svc("b.service", unitExtra = "Requires=a.service\nAfter=a.service")
    h2.reload()
    expect CoreError: discard h2.startUnit("a.service")
    h2.cleanup()
  test "missing Requires fails, missing Wants is ignored":
    let h = newHarness()
    h.svc("a.service", unitExtra = "Requires=nope.service")
    h.svc("w.service", unitExtra = "Wants=nope.service")
    h.reload()
    expect CoreError: discard h.startUnit("a.service")
    check h.startUnit("w.service").get.result == jrDone
    h.cleanup()
  test "isolate stops everything else":
    let h = newHarness()
    h.target("iso.target", "AllowIsolate=yes\nWants=keep.service")
    h.svc("keep.service")
    h.svc("other.service")
    h.reload()
    discard h.startUnit("other.service")
    check h.state("other.service") == "active/running"
    check h.startUnit("iso.target", jtStart, jmIsolate).get.result == jrDone
    check h.waitState("other.service", "inactive/dead", 5000)
    check h.state("keep.service") == "active/running"
    h.cleanup()
  test "StopWhenUnneeded stops a unit nothing needs anymore":
    let h = newHarness()
    h.svc("dep.service", unitExtra = "StopWhenUnneeded=yes")
    h.svc("user.service", unitExtra = "Requires=dep.service\nAfter=dep.service")
    h.reload()
    discard h.startUnit("user.service")
    check h.state("dep.service") == "active/running"
    discard h.startUnit("user.service", jtStop)
    check h.waitState("dep.service", "inactive/dead", 5000)
    h.cleanup()
  test "OnFailure starts the handler":
    let h = newHarness()
    let marker = h.base / "onfail"
    h.svc("bad.service", exec = "/usr/bin/false", extra = "Type=oneshot\n", unitExtra = "OnFailure=handler.service")
    h.writeUnit("handler.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'echo $MONITOR_SERVICE_RESULT $MONITOR_UNIT > " & marker & "'\n")
    h.reload()
    discard h.startUnit("bad.service")
    check h.pump(proc(): bool = fileExists(marker), 8000)
    check readFile(marker).strip == "exit-code bad.service"
    h.cleanup()
  test "RefuseManualStart":
    let h = newHarness()
    h.svc("r.service", unitExtra = "RefuseManualStart=yes")
    h.reload()
    expect CoreError: discard h.startUnit("r.service")
    h.cleanup()
  test "start limit":
    let h = newHarness()
    h.svc("l.service", unitExtra = "StartLimitIntervalSec=10\nStartLimitBurst=2", exec = "/usr/bin/true", extra = "Type=oneshot\n")
    h.reload()
    check h.startUnit("l.service").get.result == jrDone
    check h.startUnit("l.service").get.result == jrDone
    let o = h.startUnit("l.service")
    check o.get.result == jrFailed and "repeated too quickly" in o.get.message
    check h.m.lookup("l.service").result == "start-limit-hit"
    h.cleanup()
  test "restart job restarts a running unit":
    let h = newHarness()
    h.svc("a.service")
    h.reload()
    discard h.startUnit("a.service")
    let u = h.m.lookup("a.service")
    let before = h.m.lookup("a.service").data
    check h.startUnit("a.service", jtRestart).get.result == jrDone
    check h.state("a.service") == "active/running"
    h.cleanup()
