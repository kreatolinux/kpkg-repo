import std/[options, os, strutils, unittest, times, json]
import harness
import common/clock
import engine/[types, eventloop, api, graph]

proc touchCount(path: string): int =
  if fileExists(path): readFile(path).count('x') else: 0

suite "timer units":
  test "OnActiveSec starts the triggered service once and the timer stays elapsed":
    let h = newHarness()
    let marker = h.base / "m1"
    h.writeUnit("t1.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker & "'\n")
    h.writeUnit("t1.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnActiveSec=300ms\n")
    h.reload()
    check h.startUnit("t1.timer").get.result == jrDone
    check h.state("t1.timer") == "active/waiting"
    check h.pump(proc(): bool = touchCount(marker) == 1, 8000)
    check h.waitState("t1.timer", "active/elapsed", 5000)
    check h.waitState("t1.service", "inactive/dead", 5000)
    sleep 500
    h.m.loop.runOnce(20)
    check touchCount(marker) == 1
    check h.startUnit("t1.timer", jtStop).get.result == jrDone
    check h.state("t1.timer") == "inactive/dead"
    h.cleanup()
  test "OnUnitActiveSec repeats; stopping the timer ends it; RemainAfterElapse=no goes inactive":
    let h = newHarness()
    let marker = h.base / "m2"
    h.writeUnit("t2.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker & "'\n")
    h.writeUnit("t2.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnActiveSec=200ms\nOnUnitActiveSec=300ms\n")
    h.reload()
    check h.startUnit("t2.timer").get.result == jrDone
    check h.pump(proc(): bool = touchCount(marker) >= 3, 10000)
    check h.startUnit("t2.timer", jtStop).get.result == jrDone
    let n = touchCount(marker)
    discard h.pump(proc(): bool = false, 700)
    check touchCount(marker) == n
    h.writeUnit("t3.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/true\n")
    h.writeUnit("t3.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnActiveSec=100ms\nRemainAfterElapse=no\n")
    h.reload()
    check h.startUnit("t3.timer").get.result == jrDone
    check h.waitState("t3.timer", "inactive/dead", 5000)
    h.cleanup()
  test "OnBootSec in the past elapses at once; OnCalendar fires at the next matching second":
    let h = newHarness()
    let marker = h.base / "m4"
    let marker2 = h.base / "m5"
    h.writeUnit("t4.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker & "'\n")
    h.writeUnit("t4.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnBootSec=1s\n")
    h.writeUnit("t5.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker2 & "'\n")
    h.writeUnit("t5.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnCalendar=*-*-* *:*:0/2 UTC\n")
    h.reload()
    check h.startUnit("t4.timer").get.result == jrDone
    check h.pump(proc(): bool = touchCount(marker) == 1, 5000)
    check h.startUnit("t5.timer").get.result == jrDone
    check h.pump(proc(): bool = touchCount(marker2) >= 2, 10000)
    check h.state("t5.timer") in ["active/waiting", "active/running"]
    h.cleanup()
  test "Persistent=yes elapses at start when the stamp is older than the last calendar elapse; the stamp is touched":
    let h = newHarness()
    let marker = h.base / "m6"
    h.writeUnit("t6.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker & "'\n")
    h.writeUnit("t6.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnCalendar=daily UTC\nPersistent=yes\n")
    h.reload()
    let stamp = h.m.roots.st / "timers" / "stamp-t6.timer"
    createDir(stamp.parentDir)
    writeFile(stamp, "")
    setLastModificationTime(stamp, getTime() - initDuration(days = 3))
    check h.startUnit("t6.timer").get.result == jrDone
    check h.pump(proc(): bool = touchCount(marker) == 1, 8000)
    check (getTime() - getLastModificationTime(stamp)).inSeconds < 60
    check h.state("t6.timer") in ["active/waiting", "active/running"]
    # a fresh stamp: nothing elapses at start
    h.cleanup()
    let h2 = newHarness()
    h2.writeUnit("t7.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/true\n")
    h2.writeUnit("t7.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnCalendar=daily UTC\nPersistent=yes\n")
    h2.reload()
    let stamp2 = h2.m.roots.st / "timers" / "stamp-t7.timer"
    createDir(stamp2.parentDir)
    writeFile(stamp2, "")
    check h2.startUnit("t7.timer").get.result == jrDone
    check h2.state("t7.timer") == "active/waiting"
    check h2.state("t7.service") == "inactive/dead"
    h2.cleanup()
  test "a timer whose service is missing fails with resources; no running service is started twice":
    let h = newHarness()
    h.writeUnit("t8.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnActiveSec=1s\n")
    h.reload()
    discard h.startUnit("t8.timer")
    check h.state("t8.timer") == "failed/failed"
    let marker = h.base / "m9"
    h.writeUnit("t9.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sh -c 'printf x >> " & marker & "; exec sleep 30'\n")
    h.writeUnit("t9.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnActiveSec=100ms\nOnUnitActiveSec=200ms\n")
    h.reload()
    check h.startUnit("t9.timer").get.result == jrDone
    check h.pump(proc(): bool = touchCount(marker) == 1, 5000)
    discard h.pump(proc(): bool = false, 800)
    check touchCount(marker) == 1
    check h.state("t9.timer") == "active/running"
    h.cleanup()
  test "status reports next_run while waiting and last_run after an elapse":
    let h = newHarness()
    h.writeUnit("s1.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/true\n")
    h.writeUnit("s1.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnActiveSec=600ms\nOnCalendar=yearly UTC\n")
    h.reload()
    check h.startUnit("s1.timer").get.result == jrDone
    let u = h.m.lookup("s1.timer")
    var st = statusJson(h.m, u)
    check st.hasKey("next_run") and not st.hasKey("last_run")
    check st["substate"].getStr == "waiting"
    check h.pump(proc(): bool = statusJson(h.m, u).hasKey("last_run"), 5000)
    check h.waitState("s1.timer", "active/waiting", 5000)
    check statusJson(h.m, u)["next_run"].getStr.startsWith("20")
    h.cleanup()

suite "timer clock and zone events, accuracy":
  test "OnClockChange elapses when the realtime clock jumps (injected clock)":
    let fake = FakeClock(mono: 5_000_000_000_000'i64, real: 1_800_000_000_000_000'i64)
    let h = newHarness(fake)
    let marker = h.base / "c1"
    h.writeUnit("c1.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker & "'\n")
    h.writeUnit("c1.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nOnClockChange=yes\n")
    h.reload()
    check h.startUnit("c1.timer").get.result == jrDone
    check h.state("c1.timer") == "active/waiting"
    # time passes normally: nothing happens
    fake.mono += 2_000_000
    fake.real += 2_000_000
    h.m.loop.runOnce(20)
    discard h.pump(proc(): bool = false, 200)
    check touchCount(marker) == 0
    # the wall clock is set forward by an hour
    fake.mono += 2_000_000
    fake.real += 2_000_000 + 3_600_000_000'i64
    check h.pump(proc(): bool = touchCount(marker) == 1, 8000)
    check h.waitState("c1.timer", "active/waiting", 5000)
    h.cleanup()
  test "OnTimezoneChange elapses when /etc/localtime is replaced":
    let h = newHarness()
    let marker = h.base / "z1"
    h.writeUnit("z1.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker & "'\n")
    h.writeUnit("z1.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nOnTimezoneChange=yes\n")
    h.reload()
    let link = h.m.roots.etc / "localtime"
    createDir(h.base / "zi")
    writeFile(h.base / "zi/UTC", "x")
    writeFile(h.base / "zi/Berlin", "y")
    createSymlink(h.base / "zi/UTC", link)
    check h.startUnit("z1.timer").get.result == jrDone
    discard h.pump(proc(): bool = false, 400)
    check touchCount(marker) == 0
    removeFile(link)
    createSymlink(h.base / "zi/Berlin", link)
    check h.pump(proc(): bool = touchCount(marker) == 1, 8000)
    check h.startUnit("z1.timer", jtStop).get.result == jrDone
    h.cleanup()
  test "AccuracySec lets the elapse slip within its window, never earlier":
    let h = newHarness()
    let marker = h.base / "a1"
    h.writeUnit("a1.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'printf x >> " & marker & "'\n")
    h.writeUnit("a1.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nOnActiveSec=1s\nAccuracySec=3s\n")
    h.reload()
    let t0 = epochTime()
    check h.startUnit("a1.timer").get.result == jrDone
    check h.pump(proc(): bool = touchCount(marker) == 1, 10_000)
    let dt = epochTime() - t0
    check dt >= 0.95 and dt <= 4.9
    h.cleanup()
