## unit.activate / unit.deactivate semantics (spec §8.1, §8.8) on a small tree.
import std/[unittest]
import harness
import engine/[types, boot]

suite "boot":
  test "activate reports started and failed units":
    let h = newHarness()
    h.writeUnit("default.target", "[Unit]\nDefaultDependencies=no\nWants=ok.service bad.service skipme.service\n")
    h.writeUnit("ok.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 30\n")
    h.writeUnit("bad.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/usr/bin/false\n")
    h.writeUnit("skipme.service", "[Unit]\nDefaultDependencies=no\nConditionPathExists=/nonexistent\n[Service]\nExecStart=/bin/sleep 30\n")
    h.reload()
    var started = -1
    var failed: seq[FailedUnit]
    var done = false
    h.m.bootTarget = "default.target"
    h.m.activate(proc(s: int; f: seq[FailedUnit]) = (started = s; failed = f; done = true))
    check h.pump(proc(): bool = done, 10_000)
    check started >= 2 and h.state("ok.service") == "active/running"   # plus the implicit slices
    check failed.len == 1 and failed[0].unit == "bad.service" and failed[0].result == "failed"
    check not h.m.booting
    h.cleanup()
  test "deactivate stops running units within the budget":
    let h = newHarness()
    h.writeUnit("a.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 30\n")
    h.writeUnit("b.service", "[Unit]\nDefaultDependencies=no\nAfter=a.service\nRequires=a.service\n[Service]\nExecStart=/bin/sleep 30\n")
    h.reload()
    discard h.startUnit("b.service")
    var stopped = -1
    var done = false
    h.m.deactivate(proc(s: int; f: seq[FailedUnit]) = (stopped = s; done = true))
    check h.pump(proc(): bool = done, 15_000)
    check stopped >= 2
    check h.state("a.service") == "inactive/dead" and h.state("b.service") == "inactive/dead"
    h.cleanup()
