## notify, forking, reload, watchdog, STATUS/MAINPID via the real handler.
import std/[options, os, strutils, unittest]
import harness
import unitfile/model
import engine/[types, graph, jobs]
import service/service

proc unitText(svc: string): string = "[Unit]\nDefaultDependencies=no\n[Service]\n" & svc

suite "service types":
  test "Type=notify waits for READY=1 from the main pid":
    let h = newHarness()
    h.writeUnit("n.service", unitText("Type=notify\nExecStart=/bin/sleep 30\n"))
    h.reload()
    var outcome: Option[JobOutcome]
    let u = h.m.lookup("n.service")
    discard submitJob(h.m, u, jtStart, jmReplace, joManual, proc(o: JobOutcome) = outcome = some(o))
    check h.pump(proc(): bool = sd(u).mainPid > 0, 5000)
    sleep 200
    check outcome.isNone and h.state("n.service") == "activating/start"
    handleNotify(h.m, u, 99999, "READY=1", @[])           # not the main pid: ignored
    check outcome.isNone
    handleNotify(h.m, u, sd(u).mainPid, "STATUS=up and running\nREADY=1", @[])
    check h.pump(proc(): bool = outcome.isSome, 3000)
    check outcome.get.result == jrDone and h.state("n.service") == "active/running"
    check sd(u).statusText == "up and running"
    discard h.startUnit("n.service", jtStop)
    h.cleanup()
  test "notify service that exits before READY fails":
    let h = newHarness()
    h.writeUnit("n.service", unitText("Type=notify\nExecStart=/bin/sh -c 'exit 2'\n"))
    h.reload()
    check h.startUnit("n.service").get.result == jrFailed
    h.cleanup()
  test "Type=exec waits for the exec":
    let h = newHarness()
    h.writeUnit("e.service", unitText("Type=exec\nExecStart=/bin/sleep 30\n"))
    h.reload()
    check h.startUnit("e.service").get.result == jrDone
    check h.state("e.service") == "active/running"
    discard h.startUnit("e.service", jtStop)
    h.cleanup()
  when defined(linux):   # needs the child subreaper to adopt the daemonized process
   test "Type=forking with PIDFile":
      let h = newHarness()
      let pidf = h.base / "d.pid"
      h.writeUnit("d.service", unitText("Type=forking\nPIDFile=" & pidf &
        "\nExecStart=/bin/sh -c 'sleep 30 & echo $! > " & pidf & "'\n"))
      h.reload()
      let o = h.startUnit("d.service")
      check o.get.result == jrDone
      check h.state("d.service") == "active/running"
      let u = h.m.lookup("d.service")
      check sd(u).mainPid > 0
      check h.startUnit("d.service", jtStop).get.result == jrDone
      h.cleanup()
  test "reload runs ExecReload with MAINPID":
    let h = newHarness()
    let marker = h.base / "reloaded"
    h.writeUnit("r.service", unitText("ExecStart=/bin/sleep 30\nExecReload=/bin/sh -c 'echo $MAINPID > " & marker & "'\n"))
    h.reload()
    discard h.startUnit("r.service")
    check h.startUnit("r.service", jtReload).get.result == jrDone
    check readFile(marker).strip == $sd(h.m.lookup("r.service")).mainPid
    check h.state("r.service") == "active/running"
    h.cleanup()
  test "reload of a unit without a reload mechanism is refused":
    let h = newHarness()
    h.writeUnit("r.service", unitText("ExecStart=/bin/sleep 30\n"))
    h.reload()
    discard h.startUnit("r.service")
    expect CatchableError: discard h.startUnit("r.service", jtReload)
    h.cleanup()
  test "watchdog expiry fails the unit with result watchdog":
    let h = newHarness()
    h.writeUnit("w.service", unitText("Type=notify\nWatchdogSec=1\nTimeoutStopSec=1\nExecStart=/bin/sleep 30\n"))
    h.reload()
    let u = h.m.lookup("w.service")
    discard submitJob(h.m, u, jtStart, jmReplace, joManual)
    check h.pump(proc(): bool = sd(u).mainPid > 0, 5000)
    handleNotify(h.m, u, sd(u).mainPid, "READY=1", @[])
    check h.waitState("w.service", "failed/failed", 8000)
    check u.result == "watchdog"
    h.cleanup()
  test "RuntimeMaxSec stops with timeout":
    let h = newHarness()
    h.writeUnit("m.service", unitText("RuntimeMaxSec=1\nExecStart=/bin/sleep 30\n"))
    h.reload()
    discard h.startUnit("m.service")
    check h.waitState("m.service", "failed/failed", 8000)
    check h.m.lookup("m.service").result == "timeout"
    h.cleanup()
  test "STOPPING=1 and MAINPID":
    let h = newHarness()
    h.writeUnit("s.service", unitText("Type=notify\nNotifyAccess=all\nExecStart=/bin/sleep 30\n"))
    h.reload()
    let u = h.m.lookup("s.service")
    discard submitJob(h.m, u, jtStart, jmReplace, joManual)
    check h.pump(proc(): bool = sd(u).mainPid > 0, 5000)
    handleNotify(h.m, u, sd(u).mainPid, "READY=1", @[])
    check h.waitState("s.service", "active/running", 3000)
    handleNotify(h.m, u, sd(u).mainPid, "STOPPING=1", @[])
    check h.state("s.service") == "deactivating/stop-sigterm"
    discard h.startUnit("s.service", jtStop, timeoutMs = 15_000)
    h.cleanup()
  test "ExecStop runs on stop, SuccessExitStatus":
    let h = newHarness()
    let marker = h.base / "stopped"
    h.writeUnit("x.service", unitText("ExecStart=/bin/sleep 30\nExecStop=/usr/bin/touch " & marker & "\n"))
    h.reload()
    discard h.startUnit("x.service")
    discard h.startUnit("x.service", jtStop)
    check fileExists(marker)
    h.cleanup()
