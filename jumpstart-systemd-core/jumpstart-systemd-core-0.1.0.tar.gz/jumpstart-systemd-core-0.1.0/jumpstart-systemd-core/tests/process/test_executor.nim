## Process-level tests of the executor through the real spawn path.
## Linux only for the privileged parts (cgroups are not used here).
import std/[options, os, osproc, posix, strutils, unittest]
import jumpstartcore/[reaper]
import executor/context
import service/spawnexec

const root = currentSourcePath().parentDir.parentDir.parentDir
let exePath = getTempDir() / "sdc-test-executor"
doAssert execCmd("nim c --threads:off --hints:off -o:" & exePath & " " &
  root / "src/executor_main.nim") == 0

type Outcome = object
  status: int
  text: string
  failure: Option[(int, string)]

let r = newReaper()
r.installSigChldHandler()

proc run(spec: ExecSpec; stdinFd: cint = -1): Outcome =
  let outPath = getTempDir() / "sdc-exec-out-" & $getpid()
  let outFd = open(outPath.cstring, O_RDWR or O_CREAT or O_TRUNC, 0o600)
  let nullFd = open("/dev/null", O_RDONLY)
  var done = false
  var st: int
  let h = spawnExec(r, exePath, geteuid(), "", spec, [nullFd, outFd, outFd], @[], "",
    "test", proc(s: ChildStatus) = st = s.code; done = true)
  while not done:
    var pfd = TPollfd(fd: r.wakeupFd, events: POLLIN)
    discard poll(addr pfd, 1, 2000)
    discard r.drainWakeup()
  result.failure = readExecFailure(h)
  h.closeStatus()
  result.status = st
  result.text = readFile(outPath)
  discard close(outFd); discard close(nullFd)
  removeFile(outPath)

proc base(path: string; args: varargs[string]): ExecSpec =
  ExecSpec(version: ContextVersion, unit: "t.service", path: path, args: @args, umask: -1,
    ignoreSigpipe: true)

suite "executor":
  test "runs the program with the environment and expands arguments":
    var s = base("/bin/sh", "-c", "echo $0 \"$X\" \"$@\"", "${X}", "$LIST")
    s.environment = @[("X", "a b"), ("LIST", "1 2")]
    check run(s).text.strip == "a b a b 1 2"
  test "environment layers: files, pass, unset, protected":
    let f = getTempDir() / "sdc-env-test"
    writeFile(f, "A=fromfile\nP=nope\n")
    var s = base("/usr/bin/env")
    s.environment = @[("A", "unit"), ("P", "manager"), ("U", "x")]
    s.environmentFiles = @[f, "-/nonexistent"]
    s.passEnvironment = @["PASSED"]
    s.managerEnvironment = @[("PASSED", "yes")]
    s.unsetEnvironment = @["U"]
    s.protectedEnv = @["P"]
    let o = run(s)
    check "A=fromfile" in o.text
    check "P=manager" in o.text
    check "PASSED=yes" in o.text
    check "U=" notin o.text
    removeFile(f)
  test "missing environment file fails with 202":
    var s = base("/usr/bin/true")
    s.environmentFiles = @["/nonexistent-env-file"]
    let o = run(s)
    check o.status == 202
    check o.failure.get[1] == "FDS"
  test "missing program fails with 203":
    let o = run(base("/nonexistent/prog"))
    check o.status == 203 and o.failure.get[0] == 203
    check "Failed at step EXEC" in o.text
  test "successful exec leaves the status pipe empty":
    let o = run(base("/usr/bin/true"))
    check o.failure.isNone
  test "working directory, umask":
    var s = base("/bin/sh", "-c", "pwd; umask")
    s.workingDirectory = "/tmp"
    s.umask = 0o027
    check run(s).text.splitLines[0 .. 1] == @[expandFilename("/tmp"), "0027"]
    s.workingDirectory = "/nonexistent-dir"
    check run(s).status == 200
    s.workingDirectory = "-/nonexistent-dir"
    check run(s).status == 0
  test "rlimit and nice":
    when defined(linux):
      var s = base("/bin/sh", "-c", "ulimit -n; nice")
      s.limits = @[LimitSpec(resource: "NOFILE", soft: 77, hard: 77)]
      s.nice = some(7)
      check run(s).text.splitLines[0 .. 1] == @["77", "7"]
  test "stdio null and file":
    let f = getTempDir() / "sdc-stdio-test"
    var s = base("/bin/sh", "-c", "echo hello; echo err >&2")
    s.stdout = StdioSpec(kind: "truncate", path: f)
    s.stderr = StdioSpec(kind: "null")
    check run(s).status == 0
    check readFile(f) == "hello\n"
    removeFile(f)
  test "unsupported sandbox settings fail closed":
    var s = base("/usr/bin/true")
    s.unsupported = @["NAMESPACE:PrivateTmp=yes"]
    let o = run(s)
    check o.status == 226 and "NAMESPACE" in o.text
    s.unsupported = @["SECCOMP:SystemCallFilter=@system-service"]
    check run(s).status == 228
  test "runtime directory is created with the mode":
    let d = getTempDir() / "sdc-rtdir-test"
    removeDir(d)
    var s = base("/bin/sh", "-c", "echo $RUNTIME_DIRECTORY")
    s.runtimeRoot = d
    s.runtimeDirectory = DirSpec(names: @["svc"], mode: 0o750)
    check run(s).text.strip == d / "svc"
    check (getFilePermissions(d / "svc") == {fpUserExec, fpUserRead, fpUserWrite, fpGroupRead, fpGroupExec})
    removeDir(d)
  when defined(linux):
    test "identity: runs as nobody":
      if geteuid() == 0:
        var s = base("/usr/bin/id", "-u")
        s.user = "nobody"
        check run(s).text.strip == $getpwnam("nobody").pw_uid
      else: skip()
    test "listen fds environment":
      var s = base("/usr/bin/env")
      s.listenFds = true
      s.fds = @[FdSpec(name: "a")]
      let o = run(s)
      check "LISTEN_FDS=1" in o.text and "LISTEN_FDNAMES=a" in o.text
