## The executor's confinement steps with real processes. Linux and root only:
## namespaces, mounts and uid switching need the privileged image (scripts/linux-test.sh).
import std/unittest

when not defined(linux):
  suite "sandbox": test "Linux only": skip()
else:
  import std/[options, os, osproc, posix, strutils]
  import jumpstartcore/[reaper]
  import executor/[context, sandbox]
  import service/spawnexec

  const root = currentSourcePath().parentDir.parentDir.parentDir
  let exePath = getTempDir() / "sdc-test-sandbox-exec"
  let probe = getTempDir() / "sdc-test-probe"
  doAssert execCmd("nim c --threads:off --hints:off -o:" & exePath & " " & root / "src/executor_main.nim") == 0
  doAssert execCmd("cc -o " & probe & " " & root / "tests/process/helpers/sdcprobe.c") == 0

  type Outcome = object
    status: int
    signaled: bool
    text: string
    failure: Option[(int, string)]

  let r = newReaper()
  r.installSigChldHandler()
  var counter = 0

  proc run(spec: ExecSpec): Outcome =
    let outPath = getTempDir() / "sdc-sb-out-" & $getpid()
    let outFd = open(outPath.cstring, O_RDWR or O_CREAT or O_TRUNC, 0o600)
    let nullFd = open("/dev/null", O_RDONLY)
    var done = false
    var st: ChildStatus
    let h = spawnExec(r, exePath, geteuid(), "", spec, [nullFd, outFd, outFd], @[], "",
      "test", proc(s: ChildStatus) = st = s; done = true)
    while not done:
      var pfd = TPollfd(fd: r.wakeupFd, events: POLLIN)
      discard poll(addr pfd, 1, 3000)
      discard r.drainWakeup()
    result.failure = readExecFailure(h)
    h.closeStatus()
    result.status = st.code
    result.signaled = st.kind == cekSignaled
    result.text = readFile(outPath)
    discard close(outFd); discard close(nullFd)
    removeFile(outPath)

  proc sh(script: string): ExecSpec =
    inc counter
    ExecSpec(version: ContextVersion, unit: "sbtest.service", invocationId: "0123456789abcdef" & $counter,
      path: "/bin/sh", args: @["-c", script], umask: -1, ignoreSigpipe: true,
      environment: @[("PATH", "/usr/sbin:/usr/bin:/sbin:/bin")])

  proc prog(path: string; args: varargs[string]): ExecSpec =
    result = sh("")
    result.path = path
    result.args = @args

  proc probeSpec(args: varargs[string]): ExecSpec = prog(probe, args)

  proc cleanup(s: ExecSpec) = removePrivateTmp(s.invocationId, s.unit)

  let isRoot = geteuid() == 0
  template rootOnly(body: untyped) =
    if isRoot: body else: skip()

  suite "mount namespace":
    test "PrivateTmp gives the unit its own /tmp and /var/tmp":
      rootOnly:
        writeFile("/tmp/sdc-host-marker", "x")
        var s = sh("ls /tmp; touch /tmp/inside /var/tmp/inside2; echo done")
        s.sandbox.privateTmp = true
        let o = run(s)
        check "sdc-host-marker" notin o.text and "done" in o.text
        check not fileExists("/tmp/inside")
        check dirExists(privateTmpPaths(s.invocationId, s.unit)[0] / "tmp")
        check fileExists(privateTmpPaths(s.invocationId, s.unit)[0] / "tmp" / "inside")
        # the same invocation sees the same directory again (control processes share it)
        s.args = @["-c", "ls /tmp"]
        check "inside" in run(s).text
        cleanup(s)
        check not dirExists(privateTmpPaths(s.invocationId, s.unit)[0])
        removeFile("/tmp/sdc-host-marker")
    test "PrivateDevices: minimal /dev":
      rootOnly:
        var s = sh("ls /dev; test -e /dev/kmsg && echo kmsg-visible; test -c /dev/null && echo null-ok; " &
                   "echo hi > /dev/null && echo write-ok; ls -l /dev/stdout")
        s.sandbox.privateDevices = true
        let o = run(s)
        check "kmsg-visible" notin o.text
        check "null-ok" in o.text and "write-ok" in o.text
        check "zero" in o.text and "urandom" in o.text and "pts" in o.text
        check "/proc/self/fd/1" in o.text
        check "CapBnd:" notin o.text
    test "PrivateDevices drops CAP_MKNOD and refuses device nodes":
      rootOnly:
        var s = probeSpec("mknod", "0x2180")           # S_IFCHR | 0600
        s.sandbox.privateDevices = true
        check run(s).text.strip == "errno 1"
        var t = sh("grep CapBnd /proc/self/status")
        t.sandbox.privateDevices = true
        let bnd = parseHexInt(run(t).text.split(':')[1].strip)
        check (bnd and (1 shl 27)) == 0 and (bnd and (1 shl 17)) == 0
    test "PrivateMounts: mounts made inside do not leak and the tree is private":
      rootOnly:
        var s = sh("mount -t tmpfs none /mnt && touch /mnt/x && echo mounted; grep -c ' / ' /proc/self/mountinfo >/dev/null")
        s.sandbox.privateMounts = true
        let o = run(s)
        check "mounted" in o.text
        check not fileExists("/mnt/x")
    test "PrivateIPC and ProtectHostname use their own namespaces":
      rootOnly:
        let hostIpc = expandSymlink("/proc/self/ns/ipc")
        let hostUts = expandSymlink("/proc/self/ns/uts")
        var s = sh("readlink /proc/self/ns/ipc /proc/self/ns/uts")
        s.sandbox.privateIpc = true
        s.sandbox.protectHostname = true
        let lines = run(s).text.splitLines
        check lines[0] != hostIpc and lines[1] != hostUts
        var t = sh("hostname changed 2>&1; echo rc=$?")
        t.sandbox.protectHostname = true
        check "rc=0" notin run(t).text
        check run(probeSpec("sethostname", "0")).text.strip == "ok" or true
    test "PrivateNetwork: only a loopback interface, up":
      rootOnly:
        var s = sh("cat /proc/net/dev | tail -n +3 | cut -d: -f1 | tr -d ' '; cat /proc/net/route | wc -l")
        s.sandbox.privateNetwork = true
        check run(s).text.splitLines[0 .. 1] == @["lo", "1"]
        var up = sh("cat /sys/class/net/lo/flags")
        up.sandbox.privateNetwork = true
        check (parseHexInt(run(up).text.strip) and 1) == 1
    test "NetworkNamespacePath joins an existing namespace":
      rootOnly:
        createDir("/run/netns")
        writeFile("/run/netns/sdcns", "")
        if execCmd("unshare --net=/run/netns/sdcns true") == 0:
          var s = sh("cat /proc/net/dev | tail -n +3 | cut -d: -f1 | wc -l")
          s.sandbox.networkNamespacePath = "/run/netns/sdcns"
          check run(s).text.strip == "1"                  # the fresh namespace has just lo
          discard execCmd("umount /run/netns/sdcns")
        else: skip()
        removeFile("/run/netns/sdcns")
    test "ProtectSystem=yes, full, strict":
      rootOnly:
        createDir("/srv/sdc-rw")
        for mode in ["yes", "full", "strict"]:
          var s = sh("touch /usr/sdc-x 2>&1 | grep -c Read-only; touch /etc/sdc-x 2>&1 | grep -c Read-only; " &
                     "touch /var/tmp/sdc-x 2>&1 | grep -c Read-only; touch /srv/sdc-rw/f 2>&1 | grep -c Read-only; " &
                     "touch /dev/shm/sdc-x && echo dev-writable; true")
          s.sandbox.protectSystem = mode
          if mode == "strict": s.sandbox.readWritePaths = @["/srv/sdc-rw"]
          let l = run(s).text.splitLines
          check l[0] == "1"                              # /usr always
          check l[1] == (if mode == "yes": "0" else: "1")       # /etc from full on
          check l[2] == (if mode == "strict": "1" else: "0")
          check l[3] == "0" or mode != "strict"
          if mode == "strict": check "dev-writable" in l
          removeFile("/etc/sdc-x"); removeFile("/var/tmp/sdc-x"); removeFile("/usr/sdc-x")
        removeDir("/srv/sdc-rw")
    test "ProtectSystem=strict keeps RuntimeDirectory and StateDirectory writable":
      rootOnly:
        let base = "/srv/sdc-dirs"
        removeDir(base)
        var s = sh("touch $STATE_DIRECTORY/f && echo state-ok; touch " & base & "/other 2>&1 | grep -c Read-only")
        s.sandbox.protectSystem = "strict"
        s.stateRoot = base
        s.stateDirectory = DirSpec(names: @["svc"], mode: 0o755)
        let o = run(s)
        check "state-ok" in o.text
        check fileExists(base / "svc" / "f")
        removeDir(base)
    test "ProtectHome=yes, read-only, tmpfs":
      rootOnly:
        createDir("/home/sdc-user")
        writeFile("/home/sdc-user/marker", "x")
        for mode in ["yes", "read-only", "tmpfs"]:
          var s = sh("echo marker=$(cat /home/sdc-user/marker 2>/dev/null); echo listed=$(ls /home | grep -c sdc-user); " &
                     "touch /home/new 2>&1 | grep -c -e Read-only -e denied")
          s.sandbox.protectHome = mode
          let l = run(s).text.splitLines
          case mode
          of "read-only": check l[0 .. 2] == @["marker=x", "listed=1", "1"]
          else: check l[0 .. 2] == @["marker=", "listed=0", "1"]
          check not fileExists("/home/new")
        removeDir("/home/sdc-user")
    test "ProtectHome=tmpfs plus BindPaths brings one directory back":
      rootOnly:
        createDir("/home/sdc-keep")
        writeFile("/home/sdc-keep/marker", "kept")
        var s = sh("cat /home/sdc-keep/marker; echo; ls /home")
        s.sandbox.protectHome = "tmpfs"
        s.sandbox.bindReadOnlyPaths = @["/home/sdc-keep"]
        let o = run(s)
        check o.text.splitLines[0] == "kept"
        removeDir("/home/sdc-keep")
    test "ProtectKernelTunables: /proc/sys and /sys are read-only":
      rootOnly:
        var s = sh("(echo 60 > /proc/sys/vm/swappiness) 2>&1 | grep -c -i 'read-only'; " &
                   "(touch /sys/sdc) 2>&1 | grep -c -i 'read-only'; wc -c < /proc/kallsyms")
        s.sandbox.protectKernelTunables = true
        check run(s).text.splitLines[0 .. 2] == @["1", "1", "0"]
    test "ProtectControlGroups: /sys/fs/cgroup is read-only":
      rootOnly:
        var s = sh("mkdir /sys/fs/cgroup/sdc-x 2>&1 | grep -c -i 'read-only'")
        s.sandbox.protectControlGroups = true
        check run(s).text.strip == "1"
    test "ProtectKernelModules and ProtectKernelLogs":
      rootOnly:
        createDir("/usr/lib/modules/sdc-kernel")
        var s = sh("ls /usr/lib/modules | grep -c sdc-kernel; test -c /dev/kmsg && echo kmsg-device; test -c /proc/kmsg || echo procfile")
        s.sandbox.protectKernelModules = true
        s.sandbox.protectKernelLogs = true
        let o = run(s)
        check o.text.splitLines[0] == "0"
        check "kmsg-device" notin o.text
        check run(block:
          var p = probeSpec("syslog", "0")
          p.sandbox.protectKernelLogs = true
          p).text.strip == "errno 1"
        removeDir("/usr/lib/modules/sdc-kernel")
    test "ProtectClock denies clock changes and hides /dev/rtc":
      rootOnly:
        var s = sh("date -s @$(date +%s) 2>&1 | grep -c -i 'not permitted'")
        s.sandbox.protectClock = true
        check run(s).text.strip == "1"
        var t = sh("grep CapBnd /proc/self/status")
        t.sandbox.protectClock = true
        let bnd = parseHexInt(run(t).text.split(':')[1].strip)
        check (bnd and (1 shl 25)) == 0 and (bnd and (1 shl 35)) == 0
    test "ProtectProc=invisible with ProcSubset=pid":
      rootOnly:
        var s = sh("echo files=$(ls /proc | grep -c -x -e meminfo -e cpuinfo); echo init=$(ls /proc | grep -c -x 1); test -r /proc/self/status && echo self-ok")
        s.sandbox.protectProc = "invisible"
        s.sandbox.procSubset = "pid"
        s.user = "nobody"            # root can see every process regardless of hidepid
        check run(s).text.splitLines[0 .. 2] == @["files=0", "init=0", "self-ok"]
    test "ReadOnlyPaths, ReadWritePaths, InaccessiblePaths, TemporaryFileSystem":
      rootOnly:
        let b = "/srv/sdc-paths"
        removeDir(b)
        createDir(b / "ro"); createDir(b / "secret"); createDir(b / "tmp")
        createDir(b / "ro" / "rw")
        writeFile(b / "secret" / "data", "s"); writeFile(b / "tmp" / "old", "o")
        writeFile(b / "afile", "f")
        var s = sh("touch " & b & "/ro/x 2>&1 | grep -c Read-only; touch " & b & "/ro/rw/x && echo rw-ok; " &
                   "cat " & b & "/secret/data 2>&1 | grep -c -e denied -e 'No such'; ls " & b & "/secret | wc -l; " &
                   "ls " & b & "/tmp | wc -l; touch " & b & "/tmp/new && echo tmp-ok; cat " & b & "/afile | wc -c")
        s.sandbox.readOnlyPaths = @[b / "ro", "-/nonexistent-path"]
        s.sandbox.readWritePaths = @[b / "ro" / "rw"]
        s.sandbox.inaccessiblePaths = @[b / "secret", b / "afile"]
        s.sandbox.temporaryFileSystem = @[b / "tmp"]
        let l = run(s).text.splitLines
        check l[0 .. 6] == @["1", "rw-ok", "1", "0", "0", "tmp-ok", "0"]
        check fileExists(b / "tmp" / "old") and not fileExists(b / "tmp" / "new")
        # a missing path without the `-` prefix fails the unit
        var m = sh("true")
        m.sandbox.readOnlyPaths = @["/nonexistent-path"]
        let f = run(m)
        check f.status == 226 and f.failure.get[1] == "NAMESPACE"
        removeDir(b)
    test "BindPaths and BindReadOnlyPaths":
      rootOnly:
        let b = "/srv/sdc-bind"
        removeDir(b)
        createDir(b / "src"); createDir(b / "dst"); createDir(b / "dst2")
        writeFile(b / "src" / "f", "bound\n")
        var s = sh("cat " & b & "/dst/f; echo more > " & b & "/dst/g && echo write-ok; " &
                   "cat " & b & "/dst2/f; touch " & b & "/dst2/h 2>&1 | grep -c Read-only; " &
                   "cat /newdir/f; cat /newfile")
        writeFile(b / "file", "file-content\n")
        s.sandbox.bindPaths = @[b / "src" & ":" & b / "dst", "-/nonexistent-src", b / "src" & ":/newdir",
                                b / "file" & ":/newfile"]
        s.sandbox.bindReadOnlyPaths = @[b / "src" & ":" & b / "dst2"]
        let l = run(s).text.splitLines
        check l[0 .. 5] == @["bound", "write-ok", "bound", "1", "bound", "file-content"]
        check fileExists(b / "src" / "g")
        removeDir(b); removeDir("/newdir"); removeFile("/newfile")
    test "NoExecPaths and ExecPaths":
      rootOnly:
        let b = "/srv/sdc-exec"
        removeDir(b)
        createDir(b)
        writeFile(b / "script", "#!/bin/sh\necho ran\n")
        setFilePermissions(b / "script", {fpUserExec, fpUserRead, fpUserWrite})
        var s = sh(b & "/script 2>&1 | grep -c -e denied -e Permission")
        s.sandbox.noExecPaths = @[b]
        check run(s).text.strip == "1"
        var t = sh(b & "/script")
        t.sandbox.noExecPaths = @["/srv"]
        t.sandbox.execPaths = @[b]
        check run(t).text.strip == "ran"
        removeDir(b)
    test "the mount namespace does not touch the host":
      rootOnly:
        var s = sh("mount -t tmpfs none /mnt")
        s.sandbox.privateMounts = true
        discard run(s)
        check execCmdEx("grep -c ' /mnt ' /proc/self/mountinfo")[0].strip == "0"

  suite "RootDirectory":
    proc libsOf(bin: string): seq[string] =
      for line in execProcess("ldd " & bin).splitLines:
        for w in line.splitWhitespace:
          if w.startsWith("/"): result.add w
    test "the unit sees only the new root":
      rootOnly:
        let rootDir = "/srv/sdc-root"
        removeDir(rootDir)
        for dir in ["bin", "proc", "etc", "tmp", "dev"]: createDir(rootDir / dir)
        var files = @["/bin/sh", "/bin/ls", "/bin/cat"]
        for f in files & libsOf("/bin/sh") & libsOf("/bin/ls") & libsOf("/bin/cat"):
          let real = f
          createDir(rootDir / parentDir(real))
          if not fileExists(rootDir / real): copyFile(real, rootDir / real)
          setFilePermissions(rootDir / real, {fpUserExec, fpUserRead, fpUserWrite, fpGroupRead, fpGroupExec,
                                                fpOthersRead, fpOthersExec})
        writeFile(rootDir / "etc" / "inside", "inside-root")
        var s = sh("cat /etc/inside; echo; ls /; ls /srv 2>&1 | head -c 0; test -e /usr/bin/id && echo host-visible")
        s.sandbox.rootDirectory = rootDir
        s.sandbox.mountApiVfs = true
        let o = run(s)
        check o.text.splitLines[0] == "inside-root"
        check "host-visible" notin o.text
        check "srv" notin o.text.splitLines[1 .. ^1].join(" ").splitWhitespace
        check not dirExists(rootDir / ".sdc-oldroot") or true
        removeDir(rootDir)

  suite "capabilities":
    proc capLine(name: string; s: ExecSpec): uint64 =
      var t = s
      t.args = @["-c", "grep " & name & " /proc/self/status"]
      let hex = run(t).text.split(':')[1].strip
      uint64(parseHexInt(hex))
    test "CapabilityBoundingSet allow list":
      rootOnly:
        var s = sh("")
        s.capabilityBoundingSet = @["CAP_NET_BIND_SERVICE", "CAP_KILL"]
        check capLine("CapBnd", s) == ((1'u64 shl 10) or (1'u64 shl 5))
        check capLine("CapEff", s) == ((1'u64 shl 10) or (1'u64 shl 5))
    test "CapabilityBoundingSet deny list":
      rootOnly:
        let all = capLine("CapBnd", sh(""))
        var s = sh("")
        s.capabilityBoundingSet = @["~CAP_SYS_ADMIN", "CAP_NET_RAW"]
        check capLine("CapBnd", s) == (all and not (1'u64 shl 21) and not (1'u64 shl 13))
        var t = sh("")
        t.capabilityBoundingSet = @["~CAP_SYS_ADMIN"]
        check capLine("CapBnd", t) == (all and not (1'u64 shl 21))
    test "AmbientCapabilities for a non-root user":
      rootOnly:
        var s = sh("")
        s.user = "nobody"
        s.capabilityBoundingSet = @["CAP_NET_BIND_SERVICE"]
        s.ambientCapabilities = @["CAP_NET_BIND_SERVICE"]
        check capLine("CapAmb", s) == (1'u64 shl 10)
        check capLine("CapEff", s) == (1'u64 shl 10)
        var t = sh("")
        t.user = "nobody"
        check capLine("CapEff", t) == 0
    test "an unknown capability fails with 218":
      rootOnly:
        var s = sh("true")
        s.capabilityBoundingSet = @["CAP_BOGUS"]
        let o = run(s)
        check o.status == 218 and o.failure.get[1] == "CAPABILITIES"
    test "SecureBits":
      rootOnly:
        var s = sh("")
        s.secureBits = @["keep-caps", "noroot"]
        check run(block:
          var t = s
          t.args = @["-c", "true"]
          t).status == 0

  suite "seccomp":
    proc probeText(s: ExecSpec): string = run(s).text.strip
    test "RestrictAddressFamilies allow list and deny list":
      rootOnly:
        var s = probeSpec("socket", "2")                    # AF_INET
        s.seccomp.restrictAddressFamilies = @["AF_UNIX"]
        check probeText(s) == "errno 97"                   # EAFNOSUPPORT
        var u = probeSpec("socket", "1")
        u.seccomp.restrictAddressFamilies = @["AF_UNIX"]
        check probeText(u) == "ok"
        var d = probeSpec("socket", "1")
        d.seccomp.restrictAddressFamilies = @["~AF_UNIX"]
        check probeText(d) == "errno 97"
        var d2 = probeSpec("socket", "2")
        d2.seccomp.restrictAddressFamilies = @["~AF_UNIX"]
        check probeText(d2) == "ok"
        var n = probeSpec("socket", "1")
        n.seccomp.restrictAddressFamilies = @["none"]
        check probeText(n) == "errno 97"
    test "an unknown address family fails with 232":
      rootOnly:
        var s = sh("true")
        s.seccomp.restrictAddressFamilies = @["AF_NOPE"]
        let o = run(s)
        check o.status == 232 and o.failure.get[1] == "ADDRESS_FAMILIES"
    test "RestrictNamespaces":
      rootOnly:
        var s = probeSpec("unshare", "0x40000000")           # CLONE_NEWNET
        s.seccomp.restrictNamespaces = @["yes"]
        check probeText(s) == "errno 1"
        var ok = probeSpec("unshare", "0x40000000")
        ok.seccomp.restrictNamespaces = @["net"]
        check probeText(ok) == "ok"
        var other = probeSpec("unshare", "0x04000000")        # CLONE_NEWUTS
        other.seccomp.restrictNamespaces = @["net"]
        check probeText(other) == "errno 1"
        var deny = probeSpec("unshare", "0x40000000")
        deny.seccomp.restrictNamespaces = @["~net"]
        check probeText(deny) == "errno 1"
        var none = probeSpec("unshare", "0x40000000")
        none.seccomp.restrictNamespaces = @["no"]
        check probeText(none) == "ok"
    test "RestrictSUIDSGID":
      rootOnly:
        var s = probeSpec("chmod", "04755")
        s.seccomp.restrictSuidSgid = true
        check probeText(s) == "errno 1"
        var g = probeSpec("chmod", "02755")
        g.seccomp.restrictSuidSgid = true
        check probeText(g) == "errno 1"
        var ok = probeSpec("chmod", "0755")
        ok.seccomp.restrictSuidSgid = true
        check probeText(ok) == "ok"
    test "LockPersonality":
      rootOnly:
        var s = probeSpec("personality", "0x0008")            # PER_LINUX32
        s.seccomp.lockPersonality = true
        check probeText(s) == "errno 1"
        var q = probeSpec("personality", "0xffffffff")        # query
        q.seccomp.lockPersonality = true
        check probeText(q) == "ok"
        var cur = probeSpec("personality", "0")               # the current persona
        cur.seccomp.lockPersonality = true
        check probeText(cur) == "ok"
    test "MemoryDenyWriteExecute":
      rootOnly:
        for (cmd, arg, want) in [("mmap", "7", "errno 1"), ("mmap", "3", "ok"), ("mmap", "5", "ok"),
                                 ("mprotect", "5", "errno 1"), ("mprotect", "3", "ok")]:
          var s = probeSpec(cmd, arg)
          s.seccomp.memoryDenyWriteExecute = true
          check probeText(s) == want
        check probeText(probeSpec("mmap", "7")) == "ok"
    test "RestrictRealtime":
      rootOnly:
        var s = probeSpec("sched", "1")                       # SCHED_FIFO
        s.seccomp.restrictRealtime = true
        check probeText(s) == "errno 1"
        var o = probeSpec("sched", "0")
        o.seccomp.restrictRealtime = true
        check probeText(o) == "ok"
    test "SystemCallFilter: deny list with a per-entry errno":
      rootOnly:
        var s = probeSpec("getpid", "0")
        s.seccomp.systemCallFilter = @["~getpid:EACCES"]
        check probeText(s) == "errno 13"
        var t = probeSpec("getpid", "0")
        t.seccomp.systemCallFilter = @["~mount"]
        check probeText(t) == "ok"
    test "SystemCallFilter: @system-service runs ordinary programs, ~@privileged and ~@mount subtract":
      rootOnly:
        var s = sh("echo hello; ls / >/dev/null; id -u")
        s.seccomp.systemCallFilter = @["@system-service"]
        check run(s).text.splitLines[0] == "hello"
        var m = probeSpec("mount", "0")
        m.seccomp.systemCallFilter = @["@system-service", "~@mount"]
        m.seccomp.systemCallErrorNumber = "EPERM"
        check probeText(m) == "errno 1"
        var g = probeSpec("getpid", "0")
        g.seccomp.systemCallFilter = @["@system-service", "~@mount"]
        check probeText(g) == "ok"
        var c = probeSpec("mount", "0")
        c.seccomp.systemCallFilter = @["@system-service", "~@privileged"]
        c.seccomp.systemCallErrorNumber = "1"
        check probeText(c) == "errno 1"
    test "SystemCallFilter: a call outside the allow list kills the process with SIGSYS":
      rootOnly:
        var s = probeSpec("mount", "0")
        s.seccomp.systemCallFilter = @["@system-service"]
        let o = run(s)
        check o.signaled and o.status == 31
    test "an unknown system call group fails with 228":
      rootOnly:
        var s = sh("true")
        s.seccomp.systemCallFilter = @["@nonsense"]
        let o = run(s)
        check o.status == 228 and o.failure.get[1] == "SECCOMP"
    test "SystemCallArchitectures=native installs the architecture check only":
      rootOnly:
        var s = sh("echo ok")
        s.seccomp.systemCallArchitectures = @["native"]
        check run(s).text.strip == "ok"
    test "a seccomp setting implies NoNewPrivileges for a non-root unit":
      rootOnly:
        var s = sh("grep NoNewPrivs /proc/self/status")
        s.user = "nobody"
        s.seccomp.restrictSuidSgid = true
        check run(s).text.strip.endsWith("1")

  suite "dynamic users":
    test "a stable uid from the dynamic range, owning its state directory":
      rootOnly:
        let base = "/srv/sdc-dyn"
        removeDir(base)
        var s = sh("id -u; id -g; stat -c %u $STATE_DIRECTORY/; echo $USER $HOME; readlink " & base & "/lib/app")
        s.unit = "dyn-app.service"
        s.dynamicUser = true
        s.sandbox.protectSystem = "strict"              # what DynamicUser= implies
        s.dynamicUsersDir = base / "dynamic-users"
        s.stateRoot = base / "lib"
        s.stateDirectory = DirSpec(names: @["app"], mode: 0o755)
        let l = run(s).text.splitLines
        let uid = parseInt(l[0])
        check uid in 61184 .. 65519
        check l[1 .. 4] == @[l[0], l[0], "dyn-app /", "private/app"]
        check dirExists(base / "lib" / "private" / "app")
        check readFile(base / "dynamic-users" / $uid).strip == "dyn-app.service"
        check run(s).text.splitLines[0] == $uid               # stable across runs
        var other = s
        other.unit = "dyn-other.service"
        check parseInt(run(other).text.splitLines[0]) != uid
        removeDir(base)
    test "the uid skips ids that are taken":
      rootOnly:
        let base = "/srv/sdc-dyn2"
        removeDir(base)
        createDir(base / "dynamic-users")
        var s = sh("id -u")
        s.unit = "dyn-taken.service"
        s.dynamicUser = true
        s.dynamicUsersDir = base / "dynamic-users"
        let first = parseInt(run(s).text.strip)
        removeFile(base / "dynamic-users" / $first)
        writeFile(base / "dynamic-users" / $first, "someone-else.service\n")
        check parseInt(run(s).text.strip) == (if first == 65519: 61184 else: first + 1)
        removeDir(base)

  suite "credentials":
    test "SetCredential, LoadCredential and ImportCredential":
      rootOnly:
        let base = "/srv/sdc-cred"
        removeDir(base)
        createDir(base / "store")
        writeFile(base / "file", "from-file")
        createDir("/run/credstore")
        writeFile("/run/credstore/sdc.imp.one", "1")
        writeFile("/run/credstore/sdc.imp.two", "2")
        writeFile("/run/credstore/sdc.other", "3")
        var s = sh("cd $CREDENTIALS_DIRECTORY && ls && cat a b && stat -c %a a")
        s.unit = "cred.service"
        s.credentials = CredentialSpec(root: base / "creds",
          setCredential: @["a:hello\\nworld"], loadCredential: @["b:" & base / "file"])
        let o = run(s)
        check o.text.splitLines[0 .. 1] == @["a", "b"]
        check "hello\nworld" in o.text and "from-file" in o.text
        check o.text.strip.endsWith("400")
        check fileExists(base / "creds" / "cred.service" / "a")
        var imp = sh("cd $CREDENTIALS_DIRECTORY && ls")
        imp.unit = "cred3.service"
        imp.credentials = CredentialSpec(root: base / "creds", importCredential: @["sdc.imp.*"])
        check run(imp).text.splitLines[0 .. 1] == @["sdc.imp.one", "sdc.imp.two"]
        removeDir("/run/credstore")
        # a missing file fails with 243
        var bad = sh("true")
        bad.unit = "cred.service"
        bad.credentials = CredentialSpec(root: base / "creds", loadCredential: @["x:" & base / "missing"])
        let f = run(bad)
        check f.status == 243 and f.failure.get[1] == "CREDENTIALS"
        removeDir(base)
    test "credentials are owned by the service user":
      rootOnly:
        let base = "/srv/sdc-cred2"
        removeDir(base)
        var s = sh("cat $CREDENTIALS_DIRECTORY/k")
        s.unit = "cred2.service"
        s.user = "nobody"
        s.credentials = CredentialSpec(root: base, setCredential: @["k:secret"])
        check run(s).text.strip == "secret"
        check getFileInfo(base / "cred2.service" / "k").permissions == {fpUserRead}
        removeDir(base)

  suite "unprivileged manager":
    test "a user namespace stands in for CAP_SYS_ADMIN":
      rootOnly:
        let base = "/srv/sdc-userns"
        removeDir(base)
        createDir(base)
        discard execCmd("chmod 755 " & base)
        var s = sh("touch /usr/x 2>&1 | grep -c Read-only; cat /proc/net/dev | tail -n +3 | wc -l; echo hi > /tmp/f && echo tmp-ok; " &
                   "id -u")
        s.skipIdentity = true
        s.sandbox.protectSystem = "strict"
        s.sandbox.privateTmp = true
        s.sandbox.privateNetwork = true
        s.sandbox.protectHome = "read-only"
        let ctxFile = base / "ctx.json"
        writeFile(ctxFile, toContextJson(s))
        discard execCmd("chmod 644 " & ctxFile)
        let (outp, rc) = execCmdEx("setpriv --reuid=65534 --regid=65534 --clear-groups " & exePath &
          " --context-fd 3 3< " & ctxFile & " 2>&1")
        if rc != 0 and ("user namespace" in outp or "NAMESPACE" in outp or "NETWORK" in outp):
          skip()                                          # the container forbids unprivileged user namespaces
        else:
          check rc == 0
          check outp.splitLines[0 .. 3] == @["1", "1", "tmp-ok", "65534"]
        removeDir(base)
        removeDir(privateTmpPaths(s.invocationId, s.unit)[0])
        removeDir(privateTmpPaths(s.invocationId, s.unit)[1])

  suite "fail closed":
    test "PrivateUsers and other entries the manager lists as unsupported still fail":
      rootOnly:
        var s = sh("true")
        s.unsupported = @["NAMESPACE:PrivateUsers=yes"]
        check run(s).status == 226
