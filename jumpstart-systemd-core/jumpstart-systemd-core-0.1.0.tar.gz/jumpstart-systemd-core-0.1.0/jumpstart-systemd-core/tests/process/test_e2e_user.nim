## End to end in user scope on Linux: the real manager, adapter, executor, journald and
## tools started the way a per-user Jumpstart daemon starts them (`JUMPSTART_MODE=user`,
## unprivileged, a delegated cgroup subtree), driven through `systemctl --user`
## and `journalctl --user`. Needs the prepared tree of scripts/linux-user-e2e.sh
## (SDC_E2E_USER_CORE, SDC_E2E_USER_CG); without it the suite skips.
when defined(linux):
  import std/[json, options, os, osproc, posix, strutils, unittest]
  import jumpstartcore/[spawn, reaper, protocol, jsonlines, environment]

  let core = getEnv("SDC_E2E_USER_CORE")
  let cgBase = getEnv("SDC_E2E_USER_CG")
  let work = "/tmp/sdc-eu"
  let home = work / "home"
  let xdg = work / "xdg"
  let rt = work / "rt"
  let st = work / "st"

  proc sh(cmd: string): (string, int) = execCmdEx(cmd, options = {poStdErrToStdOut, poUsePath})

  suite "end to end, user scope":
    var rp = newReaper()
    rp.installSigChldHandler()
    var managerPid: Pid
    var adIn, adOut: cint
    var logFd: cint
    let enabled = core.len > 0 and cgBase.len > 0
    let tools = core / "bin/systemd-compat-tools"
    let envPrefix = "HOME=" & home & " XDG_RUNTIME_DIR=" & xdg & " JUMPSTART_CORE_RUNTIME_DIR=" & rt &
                    " JUMPSTART_CORE_STATE_DIR=" & st & " "
    proc ctl(args: string): (string, int) = sh(envPrefix & tools & " systemctl --user --no-pager " & args)
    proc env(): seq[EnvPair] =
      @[("PATH", SystemPath), ("JUMPSTART_CORE_NAME", "systemd"), ("JUMPSTART_CORE_ROOT", core),
        ("JUMPSTART_CORE_STATE_DIR", st), ("JUMPSTART_CORE_RUNTIME_DIR", rt),
        ("JUMPSTART_MODE", "user"), ("HOME", home), ("USER", "nobody"), ("XDG_RUNTIME_DIR", xdg)]

    test "the manager starts unprivileged and binds the user sockets":
      if not enabled: skip()
      else:
        check geteuid() != 0
        createDir(home / ".config/systemd/user")
        writeFile(home / ".config/systemd/user/hello.service",
          "[Unit]\nDescription=Hello user\n[Service]\nExecStart=/bin/sh -c 'echo hello-from-user; exec sleep 300'\n[Install]\nWantedBy=default.target\n")
        writeFile(home / ".config/systemd/user/once.service",
          "[Unit]\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nUser=root\nExecStart=/bin/sh -c 'echo user-oneshot-ran-as-$(id -u)'\n")
        logFd = open((work / "manager.log").cstring, O_WRONLY or O_CREAT or O_TRUNC, 0o644)
        let nul = open("/dev/null", O_RDWR)
        let exe = openVerifiedExecutable(core / "bin/systemd-compat-manager", 0, core)
        let spec = ProcessSpec(executable: core / "bin/systemd-compat-manager", executableFd: some(exe.fd),
          environment: env(), workingDirectory: "/", protocol: true, supervisorSubreaper: true,
          cgroupProcs: cgBase / "control/cgroup.procs", explicitStdio: some([nul, logFd, logFd]))
        let sp = spawn.spawn(spec, rp, "manager")
        managerPid = sp.pid
        writeAllFd(sp.protocolWriteFd, encodeLine(helloOffer(crSupervisor, "systemd", "user", "2.0.0")))
        let reply = parseLine(readLineFd(sp.protocolReadFd))
        check reply.kind == pmHelloReply and reply.role == crSupervisor
        var st0: Stat
        check stat((xdg / "systemd/compat.sock").cstring, st0) == 0 and (int(st0.st_mode) and 0o777) == 0o600
        check access((rt / "manager.sock").cstring, F_OK) == 0
    test "unit.activate boots the user default.target":
      if not enabled: skip()
      else:
        let nul = open("/dev/null", O_RDWR)
        let exe = openVerifiedExecutable(core / "bin/systemd-compat", 0, core)
        let spec = ProcessSpec(executable: core / "bin/systemd-compat", executableFd: some(exe.fd),
          environment: env(), workingDirectory: "/", protocol: true,
          cgroupProcs: cgBase / "control/cgroup.procs", explicitStdio: some([nul, logFd, logFd]))
        let sp = spawn.spawn(spec, rp, "adapter")
        adIn = sp.protocolWriteFd
        adOut = sp.protocolReadFd
        writeAllFd(adIn, encodeLine(helloOffer(crAdapter, "systemd", "user", "2.0.0")))
        let reply = parseLine(readLineFd(adOut))
        check reply.kind == pmHelloReply
        writeAllFd(adIn, encodeLine(request("1", "unit.activate", "", newJObject(), deadlineAfter(60_000))))
        var code = ""
        var res: JsonNode
        while true:
          let m = parseLine(readLineFd(adOut))
          if m.kind == pmResponseOk: res = m.result; break
          if m.kind == pmResponseError: code = m.error.code & ": " & m.error.message; break
        check code == ""
        let (o, rc) = ctl("is-active default.target")
        check o.strip == "active" and rc == 0
    test "systemctl --user: start, status, stop, enable, list-units":
      if not enabled: skip()
      else:
        var (o, rc) = ctl("start hello.service")
        check rc == 0
        (o, rc) = ctl("is-active hello.service")
        check o.strip == "active" and rc == 0
        (o, rc) = ctl("status hello.service")
        check "hello.service - Hello user" in o and "active (running)" in o
        (o, rc) = ctl("show -p MainPID --value hello.service")
        check o.strip.parseInt > 0
        (o, rc) = ctl("list-units --no-legend")
        check "hello.service" in o and "default.target" in o
        (o, rc) = ctl("stop hello.service")
        check rc == 0
        (o, rc) = ctl("is-active hello.service")
        check o.strip == "inactive" and rc == 3
        (o, rc) = ctl("enable hello.service")
        check rc == 0 and symlinkExists(home / ".config/systemd/user/default.target.wants/hello.service")
        (o, rc) = ctl("is-enabled hello.service")
        check o.strip == "enabled"
        (o, rc) = ctl("disable hello.service")
        check rc == 0 and not symlinkExists(home / ".config/systemd/user/default.target.wants/hello.service")
        (o, rc) = ctl("start nonexistent.service")
        check rc != 0
    test "daemon-reload picks up a new unit file; User= is ignored":
      if not enabled: skip()
      else:
        writeFile(home / ".config/systemd/user/late.service",
          "[Unit]\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nStandardOutput=journal\nExecStart=/bin/sh -c 'echo late-unit-ran'\n")
        var (o, rc) = ctl("daemon-reload")
        check rc == 0
        (o, rc) = ctl("start late.service")
        check rc == 0
        (o, rc) = ctl("start once.service")
        check rc == 0
    test "the user journal holds the output, tagged with the user unit":
      if not enabled: skip()
      else:
        sleep 800
        let jctl = envPrefix & tools & " journalctl --user --no-pager -q "
        var (o, rc) = sh(jctl & "-u hello.service")
        check "hello-from-user" in o
        (o, rc) = sh(jctl & "-u once.service")
        check "user-oneshot-ran-as-" & $geteuid() in o
        (o, rc) = sh(jctl & "-u late.service -o verbose")
        check "late-unit-ran" in o and "_SYSTEMD_USER_UNIT=late.service" in o
        check "_SYSTEMD_UNIT=" notin o
        (o, rc) = sh(jctl & "--verify")
        check rc == 0 and "PASS:" in o
        check dirExists(st / "journal") or dirExists(rt / "journal")
    test "a finished oneshot is garbage collected, a running unit is not":
      if not enabled: skip()
      else:
        var (o, rc) = ctl("start hello.service")
        check rc == 0
        proc loadedInactive(): string = ctl("list-units --state=inactive --no-legend")[0]
        # queries load units again; the periodic sweep drops them
        var gone = false
        for _ in 0 ..< 40:
          o = loadedInactive()
          if "once.service" notin o and "late.service" notin o: gone = true; break
          sleep 500
        check gone
        (o, rc) = ctl("is-active hello.service")
        check o.strip == "active"
        (o, rc) = ctl("stop hello.service")
    test "teardown":
      if not enabled: skip()
      else:
        let (o, rc) = ctl("exit")
        discard rc
        sleep 500
        discard close(adIn)
        discard kill(managerPid, SIGTERM)
        sleep 500
        discard sh("echo manager log; tail -30 " & work / "manager.log")
else:
  import std/unittest
  suite "end to end, user scope":
    test "Linux only":
      skip()
