## Confinement settings of real unit files, through the manager and the executor
## Requires Linux and root: mount namespaces and uid switching.
import std/unittest

when not defined(linux):
  suite "service sandbox": test "Linux only": skip()
else:
  import std/[options, os, posix, strutils]
  import harness
  import engine/types

  suite "service sandbox":
    var h = newHarness()
    let isRoot = geteuid() == 0
    let outDir = "/srv/sdc-svc-out"              # outside /tmp, which PrivateTmp= replaces
    removeDir(outDir)
    createDir(outDir)
    setFilePermissions(outDir, {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupWrite, fpGroupExec,
                                fpOthersRead, fpOthersWrite, fpOthersExec})
    proc unit(body: string): string = "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nStandardError=file:/tmp/sdc-svc-err\n" & body
    proc output(name: string): string =
      try: readFile(outDir / name).strip except IOError: "(missing)"
    test "PrivateTmp, ProtectSystem=strict and ReadWritePaths from a unit file":
      if not isRoot: skip()
      else:
        writeFile("/tmp/sdc-svc-host-marker", "x")
        h.writeUnit("sb1.service", unit("PrivateTmp=yes\nProtectSystem=strict\nReadWritePaths=" & outDir & "\n" &
          "ExecStart=/bin/sh -c 'ls /tmp > " & outDir & "/tmp.out; touch /usr/sdc-nope 2> " & outDir & "/ro.out; echo ok > " & outDir & "/ok.out'\n"))
        h.reload()
        let o = h.startUnit("sb1.service")
        check o.get.result == jrDone
        check output("ok.out") == "ok"
        check "sdc-svc-host-marker" notin output("tmp.out")
        check "Read-only" in output("ro.out")
        removeFile("/tmp/sdc-svc-host-marker")
    test "a mount under /dev hidden by PrivateDevices= is skipped by the read-only remount":
      if not isRoot: skip()
      else:
        # PrivateDevices= hides /dev/sdc-hp, so the read-only remount must skip it
        createDir("/dev/sdc-hp")
        if execShellCmd("mount -t tmpfs tmpfs /dev/sdc-hp") != 0: skip()
        else:
          h.writeUnit("hp.service", unit("PrivateDevices=yes\nProtectSystem=strict\nReadWritePaths=" & outDir & "\n" &
            "ExecStart=/bin/sh -c 'echo ok > " & outDir & "/hp.out'\n"))
          h.reload()
          check h.startUnit("hp.service").get.result == jrDone
          check output("hp.out") == "ok"
          discard execShellCmd("umount /dev/sdc-hp; rmdir /dev/sdc-hp")
    test "DynamicUser= gets a dynamic uid and implied confinement":
      if not isRoot: skip()
      else:
        h.writeUnit("dyn.service", unit("DynamicUser=yes\nReadWritePaths=" & outDir & "\n" &
          "ExecStart=/bin/sh -c 'id -u > " & outDir & "/dyn.uid; touch /usr/x 2> " & outDir & "/dyn.ro; grep NoNewPrivs /proc/self/status > " & outDir & "/dyn.nnp'\n"))
        h.reload()
        check h.startUnit("dyn.service").get.result == jrDone
        let uid = parseInt(output("dyn.uid"))
        check uid in 61184 .. 65519
        check "Read-only" in output("dyn.ro")
        check output("dyn.nnp").endsWith("1")
        check dirExists(h.m.roots.st / "dynamic-users")
    test "credentials reach the unit through $CREDENTIALS_DIRECTORY":
      if not isRoot: skip()
      else:
        writeFile(outDir / "secret.txt", "from-file\n")
        h.writeUnit("cred.service", unit("SetCredential=greeting:hello\nLoadCredential=filecred:" & outDir & "/secret.txt\n" &
          "ExecStart=/bin/sh -c 'cat $CREDENTIALS_DIRECTORY/greeting $CREDENTIALS_DIRECTORY/filecred > " & outDir & "/cred.out'\n"))
        h.reload()
        check h.startUnit("cred.service").get.result == jrDone
        check output("cred.out") == "hellofrom-file"
    test "RestrictAddressFamilies, CapabilityBoundingSet and SystemCallFilter from a unit file":
      if not isRoot: skip()
      else:
        h.writeUnit("sec.service", unit("CapabilityBoundingSet=~CAP_SYS_ADMIN\nRestrictAddressFamilies=AF_UNIX\n" &
          "SystemCallFilter=@system-service\nSystemCallFilter=~@privileged @resources\nSystemCallErrorNumber=EPERM\n" &
          "NoNewPrivileges=yes\nLockPersonality=yes\nMemoryDenyWriteExecute=yes\nRestrictNamespaces=yes\n" &
          "ExecStart=/bin/sh -c 'grep CapBnd /proc/self/status > " & outDir & "/sec.cap; echo ran > " & outDir & "/sec.ran'\n"))
        h.reload()
        check h.startUnit("sec.service").get.result == jrDone
        check output("sec.ran") == "ran"
        let bnd = parseHexInt(output("sec.cap").split(':')[1].strip)
        check (bnd and (1 shl 21)) == 0 and (bnd and (1 shl 12)) != 0
    test "PrivateUsers= is still refused, with the step and a reason":
      h.writeUnit("pu.service", unit("PrivateUsers=yes\nExecStart=/usr/bin/true\n"))
      h.reload()
      let o = h.startUnit("pu.service")
      check o.get.result == jrFailed
      check h.state("pu.service") == "failed/failed"
    test "cleanup":
      removeDir(outDir)
