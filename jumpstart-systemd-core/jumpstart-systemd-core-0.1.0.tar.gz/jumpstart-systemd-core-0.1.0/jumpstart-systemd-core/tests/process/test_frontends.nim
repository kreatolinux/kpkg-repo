## The new front-ends as real processes: systemctl edit/set-property/clean/list-timers,
## systemd-run and systemd-analyze. Socket-backed ones need uid 0, the owner of a
## system manager.
import std/[os, osproc, strutils, unittest, streams, strtabs]
when defined(linux): import std/posix
import harness
import engine/[types, timing]
import ipc/[server, verbs]
import common/clock

const repoRoot = currentSourcePath().parentDir.parentDir.parentDir
let tools = getTempDir() / "systemd-compat-tools"      # dispatches on argv[0] or the first argument
var built = false

proc buildTools() =
  if built: return
  doAssert execCmd("nim c --threads:off --hints:off -o:" & tools & " " & repoRoot / "src/tools_main.nim") == 0
  built = true

proc runTool(h: Harness; args: seq[string]; env: openArray[(string, string)] = []; timeoutMs = 20_000): tuple[output: string, rc: int] =
  ## Runs the tool while the harness manager keeps serving its socket.
  var e = newStringTable()
  for k, v in envPairs(): e[k] = v
  e["XDG_RUNTIME_DIR"] = h.base / "run"
  e["HOME"] = h.base / "home"
  for (k, v) in env: e[k] = v
  let p = startProcess(tools, args = args, env = e, options = {poStdErrToStdOut, poUsePath})
  discard h.pump(proc(): bool = not p.running, timeoutMs)
  result.output = p.outputStream.readAll()
  result.rc = p.waitForExit()
  p.close()

suite "front-ends":
  buildTools()
  let h = newHarness()
  installTiming(h.m)
  createDir(h.base / "home")
  let ctx = VerbCtx(m: h.m, startedUsec: h.m.clock.realUsec)
  let srv = startControlServers(ctx)
  let editor = h.base / "editor.sh"
  writeFile(editor, "#!/bin/sh\nprintf '[Service]\\nNice=4\\n' > \"$1\"\n")
  setFilePermissions(editor, {fpUserRead, fpUserWrite, fpUserExec})

  test "edit offline writes a drop-in and --full copies the unit":
    let root = h.base
    h.writeUnit("ed.service", "[Service]\nExecStart=/bin/true\n")
    createDir(root / "usr/lib/systemd/system")
    writeFile(root / "usr/lib/systemd/system/vend.service", "[Service]\nExecStart=/bin/false\n")
    let r = h.runTool(@["systemctl", "edit", "--root=" & root, "ed.service"], {"SYSTEMD_EDITOR": editor})
    checkpoint r.output
    check r.rc == 0
    check readFile(root / "etc/systemd/system/ed.service.d/override.conf") == "[Service]\nNice=4\n"
    let f = h.runTool(@["systemctl", "edit", "--full", "--root=" & root, "vend.service"], {"SYSTEMD_EDITOR": editor})
    check f.rc == 0 and readFile(root / "etc/systemd/system/vend.service") == "[Service]\nNice=4\n"
    let missing = h.runTool(@["systemctl", "edit", "--root=" & root, "nope.service"], {"SYSTEMD_EDITOR": editor})
    check missing.rc == 1 and "does not exist" in missing.output

  test "offline file operations see the core's own units under --root":
    # the core's share/units is a unit search directory; offline systemctl
    # (package postinstalls, image builds) must find units that live only there
    let root = h.base / "coreroot"
    let units = root / "usr/lib/jumpstart/cores/systemd/share/units"
    createDir(units)
    writeFile(units / "coreonly.service", "[Service]\nExecStart=/bin/true\n[Install]\nWantedBy=multi-user.target\n")
    let r = h.runTool(@["systemctl", "enable", "--root=" & root, "coreonly.service"])
    checkpoint r.output
    check r.rc == 0
    check symlinkExists(root / "etc/systemd/system/multi-user.target.wants/coreonly.service")
    check h.runTool(@["systemctl", "is-enabled", "--root=" & root, "coreonly.service"]).output.strip == "enabled"

  test "systemd-analyze offline subcommands":
    check h.runTool(@["systemd-analyze", "calendar", "daily"]).output.contains("Normalized form: *-*-* 00:00:00")
    check h.runTool(@["systemd-analyze", "timespan", "90s"]).output.contains("Human: 1min 30s")
    check h.runTool(@["systemd-analyze", "calendar", "bogus bogus"]).rc == 1
    let f = h.base / "v.service"
    writeFile(f, "[Service]\nType=simple\nBogusKey=1\n")
    let v = h.runTool(@["systemd-analyze", "verify", f])
    checkpoint v.output
    check v.rc == 1 and "v.service" in v.output
    writeFile(h.base / "etc/zz.conf", "a=1\n")
    check h.runTool(@["systemd-analyze", "unit-paths"]).output.contains("/etc/systemd/system")

  test "tmpfiles and sysusers as commands":
    let root = h.base / "tr"
    createDir(root / "etc/tmpfiles.d")
    createDir(root / "etc/sysusers.d")
    writeFile(root / "etc/tmpfiles.d/x.conf", "d /made 0755\n")
    writeFile(root / "etc/sysusers.d/x.conf", "u svc - \"Service\"\n")
    check h.runTool(@["systemd-tmpfiles", "--root=" & root, "--create"]).rc == 0
    check dirExists(root / "made")
    check h.runTool(@["systemd-sysusers", "--root=" & root]).rc == 0
    check "svc:x:" in readFile(root / "etc/passwd")
    check h.runTool(@["systemd-tmpfiles", "--root=" & root]).rc == 1

  when defined(linux):
    if geteuid() == 0:
      test "systemd-run --wait runs a transient service and reports its status":
        let r = h.runTool(@["systemd-run", "--user", "--wait", "--unit=sdr1", "-p", "StandardOutput=null", "-p", "StandardError=null",
                            "-p", "DefaultDependencies=no", "/bin/sh", "-c", "exit 4"])
        check r.rc == 4
        check "Running as unit: sdr1.service" in r.output and "Finished with result: exit-code" in r.output
      test "systemd-run with a timer, list-timers, set-property, clean":
        let r = h.runTool(@["systemd-run", "--user", "--on-active=1h", "--unit=sdr2", "--timer-property=DefaultDependencies=no", "-p", "StandardOutput=null",
                            "-p", "StandardError=null", "-p", "DefaultDependencies=no", "/bin/true"])
        checkpoint r.output
        check r.rc == 0 and "Running timer as unit: sdr2.timer" in r.output
        let l = h.runTool(@["systemctl", "--user", "list-timers"])
        checkpoint l.output
        check l.rc == 0 and "sdr2.timer" in l.output and "sdr2.service" in l.output and "1 timers listed." in l.output
        h.writeUnit("sp.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/true\nCacheDirectory=sdc-fe-sp\n")
        h.reload()
        let sp = h.runTool(@["systemctl", "--user", "set-property", "--runtime", "sp.service", "CPUWeight=300"])
        check sp.rc == 0
        check fileExists(h.m.roots.sysrun / "system.control/sp.service.d/50-CPUWeight.conf")
        check h.runTool(@["systemctl", "--user", "set-property", "sp.service", "Bogus=1"]).rc == 1
        createDir(h.m.roots.varCache / "sdc-fe-sp")
        check h.runTool(@["systemctl", "--user", "clean", "sp.service"]).rc == 0
        check not dirExists(h.m.roots.varCache / "sdc-fe-sp")
      test "systemd-analyze blame and critical-chain read the manager":
        let b = h.runTool(@["systemd-analyze", "--user", "blame"])
        check b.rc == 0
        let c = h.runTool(@["systemd-analyze", "--user", "critical-chain", "sdr1.service"])
        check c.rc == 0 and "sdr1.service" in c.output
