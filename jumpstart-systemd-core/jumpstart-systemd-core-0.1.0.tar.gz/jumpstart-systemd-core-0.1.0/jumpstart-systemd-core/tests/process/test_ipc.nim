## The control socket server with the real verbs, over a harness manager.
import std/[json, os, posix, strutils, sequtils, unittest]
import harness
import jumpstartcore/errors
import ipc/[server, verbs, client]
import engine/[types, eventloop]
import service/cgroupmgr
import journal/storage
import common/[clock, roots]
import ../unit/journal/jtest

proc callVerb(h: Harness; path, verb: string; args: JsonNode = nil): SdcReply =
  ## Runs one blocking client call in a child process while the parent pumps the
  ## manager's loop; `item` events come back under `items`.
  var fds: array[2, cint]
  discard pipe(fds)
  let pid = fork()
  if pid == 0:
    var items = newJArray()
    let cl = connect(path)
    let r = cl.request(verb, args, proc(x: JsonNode) = items.add x)
    let line = $(%*{"ok": r.ok, "result": (if r.ok: r.result else: newJNull()),
                    "code": ord(r.code), "message": r.message, "items": items}) & "\n"
    discard write(fds[1], line.cstring, line.len)
    quit(0)
  discard close(fds[1])
  var buf = ""
  var pfd = TPollfd(fd: fds[0], events: POLLIN)
  while true:
    h.m.loop.runOnce(20)
    if poll(addr pfd, 1, 0) > 0:
      var b = newString(65536)
      let n = read(fds[0], addr b[0], b.len)
      if n <= 0: break
      buf.add b[0 ..< n]
      if '\n' in buf: break
  var st: cint
  discard waitpid(pid, st, 0)
  discard close(fds[0])
  let j = parseJson(buf)
  result = SdcReply(ok: j["ok"].getBool, result: j["result"], code: CoreErrorCode(j["code"].getInt),
                    message: j["message"].getStr)
  if result.ok and j["items"].len > 0: result.result["items"] = j["items"]

proc unitNames(tree: JsonNode): seq[string] =
  if tree.kind == JArray: tree.getElems.mapIt(it["name"].getStr) else: @[]

suite "control protocol":
  let h = newHarness()
  h.writeUnit("a.service", "[Unit]\nDefaultDependencies=no\nDescription=A thing\n[Service]\nExecStart=/bin/sleep 30\n")
  h.writeUnit("t.target", "[Unit]\nDefaultDependencies=no\nWants=a.service\n")
  h.reload()
  h.m.roots.scope = scUser          # the test user is the owner of the manager
  let ctx = VerbCtx(m: h.m, startedUsec: h.m.clock.realUsec)
  let srv = startControlServers(ctx)
  let path = h.m.roots.sysrun / "compat.sock"

  # the server lives in this thread: run client calls while stepping the loop
  proc call(c: SdcClient; verb: string; args: JsonNode = nil): SdcReply =
    callVerb(h, path, verb, args)

  test "hello and ping":
    let r = call(nil, "hello")
    check r.ok and r.result["protocol"].getStr == "sdc/1" and r.result["scope"].getStr == "user"
  test "resolve, start, status, stop":
    check call(nil, "unit-resolve", %*{"name": "a"}).result["name"].getStr == "a.service"
    let s = call(nil, "job-submit", %*{"unit": "a.service", "type": "start"})
    check s.ok and s.result["result"].getStr == "done" and s.result["state"].getStr == "active"
    let st = call(nil, "unit-status", %*{"name": "a.service"})
    check st.result["state"].getStr == "active" and st.result["main_pid"].getInt > 0
    check "sub=running" in st.result["detail"].getStr
    let stop = call(nil, "job-submit", %*{"unit": "a.service", "type": "stop"})
    check stop.ok and stop.result["state"].getStr == "inactive"
  test "timing reports a monotonic userspace time (it once subtracted the wall clock from the monotonic one)":
    let r = call(nil, "timing")
    check r.ok
    check r.result["userspace_usec"].getBiggestInt in 0'i64 .. 3_600_000_000'i64
  test "errors map to codes":
    let r = call(nil, "job-submit", %*{"unit": "nope.service", "type": "start"})
    check not r.ok and r.code == ecNotFound
    check call(nil, "bogus").code == ecProtocol
  test "unit-show and cat":
    let r = call(nil, "unit-show", %*{"names": ["a.service"], "properties": ["Id", "ActiveState"]})
    check r.result["units"][0]["properties"]["Id"].getStr == "a.service"
    let c = call(nil, "unit-cat", %*{"names": ["a.service"]})
    check "ExecStart=/bin/sleep 30" in c.result["units"][0]["files"][0]["text"].getStr
  test "cleanup":
    shutdownServers(srv)
    h.cleanup()

suite "control protocol: triggering, ordering, preset, journal, freeze, power":
  let h = newHarness()
  h.writeUnit("b.service", "[Unit]\nDefaultDependencies=no\nBefore=c.service\n[Service]\nExecStart=/bin/sleep 30\n")
  h.writeUnit("c.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 30\n")
  h.writeUnit("a.service", "[Unit]\nDefaultDependencies=no\nAfter=b.service\n[Service]\nExecStart=/bin/sleep 30\n")
  h.writeUnit("a.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenStream=" & h.base & "/a.sock\n")
  h.writeUnit("t.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 30\n")
  h.writeUnit("t.timer", "[Unit]\nDefaultDependencies=no\n[Timer]\nOnActiveSec=1h\nUnit=t.service\n")
  h.reload()
  h.m.roots.scope = scUser
  let ctx = VerbCtx(m: h.m, startedUsec: h.m.clock.realUsec)
  let srv = startControlServers(ctx)
  let path = h.m.roots.sysrun / "compat.sock"

  test "a stop names the active socket that can activate the unit again":
    check callVerb(h, path, "job-submit", %*{"unit": "a.socket", "type": "start"}).result["state"].getStr == "active"
    check callVerb(h, path, "job-submit", %*{"unit": "a.service", "type": "start"}).result["state"].getStr == "active"
    let stop = callVerb(h, path, "job-submit", %*{"unit": "a.service", "type": "stop"})
    check stop.ok and stop.result["state"].getStr == "inactive"
    check stop.result["triggering"].getElems.mapIt(it.getStr) == @["a.socket"]
    check callVerb(h, path, "job-submit", %*{"unit": "a.socket", "type": "stop"}).ok
    discard callVerb(h, path, "job-submit", %*{"unit": "a.service", "type": "start"})
    let quiet = callVerb(h, path, "job-submit", %*{"unit": "a.service", "type": "stop"})
    check quiet.ok and not quiet.result.hasKey("triggering")

  test "a stop names the active timer that can activate the unit again":
    check callVerb(h, path, "job-submit", %*{"unit": "t.timer", "type": "start"}).result["state"].getStr == "active"
    check callVerb(h, path, "job-submit", %*{"unit": "t.service", "type": "start"}).ok
    let stop = callVerb(h, path, "job-submit", %*{"unit": "t.service", "type": "stop"})
    check stop.ok and stop.result["triggering"].getElems.mapIt(it.getStr) == @["t.timer"]
    check callVerb(h, path, "job-submit", %*{"unit": "t.timer", "type": "stop"}).ok

  test "unit-deps follows After= with after and Before= with before":
    let after = callVerb(h, path, "unit-deps", %*{"name": "a.service", "after": true})
    check "b.service" in unitNames(after.result["tree"]["children"])
    let before = callVerb(h, path, "unit-deps", %*{"name": "b.service", "before": true})
    check unitNames(before.result["tree"]["children"]) == @["c.service"]
    let reversed = callVerb(h, path, "unit-deps", %*{"name": "b.service", "after": true, "reverse": true})
    check unitNames(reversed.result["tree"]["children"]) == @["a.service"]
    let pullin = callVerb(h, path, "unit-deps", %*{"name": "b.service"})
    check not ("c.service" in unitNames(pullin.result["tree"]["children"]))

  test "unit-list-files reports the preset decision when asked":
    createDir(h.m.roots.etc / "systemd/user-preset")
    writeFile(h.m.roots.etc / "systemd/user-preset/50-test.preset", "disable a.service\n")
    let rows = callVerb(h, path, "unit-list-files", %*{"patterns": ["a.service", "b.service"], "preset": true})
    check rows.ok
    let items = rows.result["items"].getElems
    check items.len == 2
    for it in items:
      if it["name"].getStr == "a.service": check it["preset"].getStr == "disabled"
      elif it["name"].getStr == "b.service": check it["preset"].getStr == "enabled"
    let plainRows = callVerb(h, path, "unit-list-files", %*{"patterns": ["a.service"]})
    check not plainRows.result["items"][0].hasKey("preset")

  test "unit-status returns the last journal lines it is asked for":
    let js = openStorage(h.m.roots.rt / "journal", bootId(2), StorageLimits(), testClock(), newRng(1))
    var entry = mk(1_700_000_000_000_000, "hello from a.service", unit = "a.service",
      extra = @[("_SYSTEMD_USER_UNIT", "a.service")])
    check js.store(entry)
    let st = callVerb(h, path, "unit-status", %*{"name": "a.service", "journal_lines": 5})
    check st.ok and st.result["journal"].len == 1
    check st.result["journal"][0]["message"].getStr == "hello from a.service"
    check st.result["journal"][0]["level"].getStr == "info"
    check callVerb(h, path, "unit-status", %*{"name": "a.service"}).result["journal"].len == 1
    check not callVerb(h, path, "unit-status", %*{"name": "a.service", "journal_lines": 0}).result.hasKey("journal")
    check not callVerb(h, path, "unit-status", %*{"name": "a.service", "journal_lines": 1001}).ok

  test "freeze and thaw need an active unit with a cgroup":
    check callVerb(h, path, "job-submit", %*{"unit": "a.service", "type": "start"}).ok
    let fr = callVerb(h, path, "freeze", %*{"units": ["a.service", "b.service", "nope.service"]})
    check fr.ok and fr.result["changed"].getInt == 0
    check fr.result["failed"].getElems.mapIt(it["unit"].getStr) == @["a.service", "b.service", "nope.service"]
    check "no cgroup" in fr.result["failed"][0]["message"].getStr
    check "not active" in fr.result["failed"][1]["message"].getStr
    check "not found" in fr.result["failed"][2]["message"].getStr
    discard callVerb(h, path, "job-submit", %*{"unit": "a.service", "type": "stop"})

  test "setCgroupFrozen writes cgroup.freeze":
    let dir = h.base / "cg/a.service"
    createDir(dir)
    check not setCgroupFrozen(dir, true)                  # no cgroup.freeze there
    writeFile(dir / "cgroup.freeze", "0")
    check setCgroupFrozen(dir, true) and readFile(dir / "cgroup.freeze") == "1"
    check setCgroupFrozen(dir, false) and readFile(dir / "cgroup.freeze") == "0"
    let bad = h.base / "cg/b.service"
    createDir(bad / "cgroup.freeze")
    var raised = false
    try: discard setCgroupFrozen(bad, true)
    except OSError: raised = true
    check raised

  test "power exit reaches the manager hook":
    var seen = paPoweroff
    h.m.powerHook = proc(a: PowerAction): bool = (seen = a; true)
    let r = callVerb(h, path, "power", %*{"action": "exit"})
    h.m.powerHook = nil
    check r.ok and r.result["accepted"].getBool and seen == paExit
    check not callVerb(h, path, "power", %*{"action": "suspend"}).ok

  test "cleanup":
    shutdownServers(srv)
    h.cleanup()
