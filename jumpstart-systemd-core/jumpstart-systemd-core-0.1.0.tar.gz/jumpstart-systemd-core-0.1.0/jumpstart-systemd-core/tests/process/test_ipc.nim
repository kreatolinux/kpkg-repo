## The control socket server with the real verbs, over a harness manager.
import std/[json, os, posix, strutils, unittest]
import harness
import jumpstartcore/errors
import ipc/[server, verbs, client]
import engine/[types, eventloop]
import common/[clock, roots]

suite "control protocol":
  let h = newHarness()
  h.writeUnit("a.service", "[Unit]\nDefaultDependencies=no\nDescription=A thing\n[Service]\nExecStart=/bin/sleep 30\n")
  h.writeUnit("t.target", "[Unit]\nDefaultDependencies=no\nWants=a.service\n")
  h.reload()
  h.m.roots.scope = scUser          # the test user is the owner of the manager
  let ctx = VerbCtx(m: h.m, startedUsec: h.m.clock.realUsec)
  let srv = startControlServers(ctx)
  let path = h.m.roots.sysrun / "compat.sock"

  # the server lives in this thread: run client calls while stepping the loop
  proc call(c: SdcClient; verb: string; args: JsonNode = nil): SdcReply =
    var done = false
    var reply: SdcReply
    # run the blocking client in a forked child? Simpler: pump in a helper by
    # making the socket non-blocking is not possible; use a short-lived fork.
    var fds: array[2, cint]
    discard pipe(fds)
    let pid = fork()
    if pid == 0:
      let cl = connect(path)
      let r = cl.request(verb, args)
      let line = $(%*{"ok": r.ok, "result": (if r.ok: r.result else: newJNull()), "code": ord(r.code), "message": r.message}) & "\n"
      discard write(fds[1], line.cstring, line.len)
      quit(0)
    discard close(fds[1])
    var buf = ""
    var pfd = TPollfd(fd: fds[0], events: POLLIN)
    while true:
      h.m.loop.runOnce(20)
      if poll(addr pfd, 1, 0) > 0:
        var b = newString(65536)
        let n = read(fds[0], addr b[0], b.len)
        if n <= 0: break
        buf.add b[0 ..< n]
        if '\n' in buf: break
    var st: cint
    discard waitpid(pid, st, 0)
    discard close(fds[0])
    let j = parseJson(buf)
    SdcReply(ok: j["ok"].getBool, result: j["result"], code: CoreErrorCode(j["code"].getInt), message: j["message"].getStr)

  test "hello and ping":
    let r = call(nil, "hello")
    check r.ok and r.result["protocol"].getStr == "sdc/1" and r.result["scope"].getStr == "user"
  test "resolve, start, status, stop":
    check call(nil, "unit-resolve", %*{"name": "a"}).result["name"].getStr == "a.service"
    let s = call(nil, "job-submit", %*{"unit": "a.service", "type": "start"})
    check s.ok and s.result["result"].getStr == "done" and s.result["state"].getStr == "active"
    let st = call(nil, "unit-status", %*{"name": "a.service"})
    check st.result["state"].getStr == "active" and st.result["main_pid"].getInt > 0
    check "sub=running" in st.result["detail"].getStr
    let stop = call(nil, "job-submit", %*{"unit": "a.service", "type": "stop"})
    check stop.ok and stop.result["state"].getStr == "inactive"
  test "timing reports a monotonic userspace time (it once subtracted the wall clock from the monotonic one)":
    let r = call(nil, "timing")
    check r.ok
    check r.result["userspace_usec"].getBiggestInt in 0'i64 .. 3_600_000_000'i64
  test "errors map to codes":
    let r = call(nil, "job-submit", %*{"unit": "nope.service", "type": "start"})
    check not r.ok and r.code == ecNotFound
    check call(nil, "bogus").code == ecProtocol
  test "unit-show and cat":
    let r = call(nil, "unit-show", %*{"names": ["a.service"], "properties": ["Id", "ActiveState"]})
    check r.result["units"][0]["properties"]["Id"].getStr == "a.service"
    let c = call(nil, "unit-cat", %*{"names": ["a.service"]})
    check "ExecStart=/bin/sleep 30" in c.result["units"][0]["files"][0]["text"].getStr
  test "cleanup":
    shutdownServers(srv)
    h.cleanup()
