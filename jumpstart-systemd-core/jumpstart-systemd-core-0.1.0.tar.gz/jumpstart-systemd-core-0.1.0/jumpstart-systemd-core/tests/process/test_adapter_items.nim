## `unit.list` and `log.read` stream their elements as `item` events, which the
## daemon appends to the result's own list, so the final result must not repeat
## them. Runs the real adapter binary against a fake manager socket and a seeded
## journal; needs neither root nor cgroups.
import std/[json, os, osproc, posix, sequtils, strutils, unittest]
import jumpstartcore/[protocol, jsonlines]
import journal/[format, storage]
import common/[roots, clock, fdutil]
import ipc/sdcproto
import ./helpers/daemonmerge

const root = currentSourcePath().parentDir.parentDir.parentDir
const UnitNames = ["a.service", "b.socket", "graphical.target"]

proc tmpBase(): string =
  result = getTempDir() / ("sdc-items-" & $getCurrentProcessId())
  removeDir(result)
  createDir(result)

proc seedJournal(r: Roots; n: int) =
  let st = openStorage(r.rt / "journal" / "m", repeat('\x02', 16), StorageLimits(),
                       FakeClock(mono: 1000, real: 1_000_000_000_000'i64), newRng(1))
  for i in 1 .. n:
    let t = 1_760_702_400_000_000'i64 + int64(i) * 1_000_000
    var e = JournalEntry(realtime: t, monotonic: t div 2, bootId: repeat('\x01', 16), priority: 6)
    e.fields.add ("MESSAGE", "line " & $i)
    e.fields.add ("PRIORITY", "6")
    e.fields.add ("_SYSTEMD_UNIT", "hello.service")
    discard st.store(e)
  st.sync

proc fakeManager(sock: string): Pid =
  ## Answers `unit-index` with one item event per unit, then `{"count": n}`,
  ## the way src/ipc/verbs.nim does. Other verbs get an empty ok.
  let lfd = bindUnix(sock, true, 0o600)
  doAssert lfd >= 0, "bind " & sock
  result = fork()
  if result != 0:
    discard close(lfd)
    return
  while true:
    var p = TPollfd(fd: lfd, events: POLLIN)
    if poll(addr p, 1, 10_000) <= 0: quit(0)
    let c = accept(SocketHandle(lfd), nil, nil)
    if c.int < 0: continue
    let fd = cint(c)
    # BSD accept() inherits the listener's O_NONBLOCK; Linux does not
    discard fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) and not O_NONBLOCK)
    var line = ""
    var ch: char
    while read(fd, addr ch, 1) == 1 and ch != '\n': line.add ch
    let req = parseRequest(line)
    var reply = ""
    if req.verb == "unit-index":
      for n in UnitNames:
        reply.add eventLine(req.id, "item",
          %*{"name": n, "subsystem": n.split('.')[1], "enablement": "enabled"}, "units")
      reply.add okLine(req.id, %*{"count": UnitNames.len})
    else:
      reply.add okLine(req.id)
    discard writeAll(fd, reply)
    discard close(fd)

proc startAdapter(bin: string; r: Roots; reqW, respR: var cint): Pid =
  var toAd, fromAd: array[2, cint]
  doAssert pipe(toAd) == 0 and pipe(fromAd) == 0
  result = fork()
  if result == 0:
    # move both ends above 4 first so the dup2s below cannot clobber them
    let a = fcntl(toAd[0], F_DUPFD, 10)
    let b = fcntl(fromAd[1], F_DUPFD, 10)
    discard dup2(a, 3)
    discard dup2(b, 4)
    for fd in 5 .. 255: discard close(cint(fd))
    putEnv("JUMPSTART_CORE_NAME", "systemd")
    putEnv("JUMPSTART_CORE_ROOT", r.coreRoot)
    putEnv("JUMPSTART_CORE_RUNTIME_DIR", r.rt)
    putEnv("JUMPSTART_CORE_STATE_DIR", r.st)
    putEnv("JUMPSTART_MODE", "system")
    let args = allocCStringArray([bin])
    discard execv(bin.cstring, args)
    quit(127)
  discard close(toAd[0])
  discard close(fromAd[1])
  reqW = toAd[1]
  respR = fromAd[0]

suite "adapter item streams are not duplicated":
  let base = tmpBase()
  let bin = base / "systemd-compat"
  check execCmd("nim c --threads:off --hints:off -o:" & bin & " " & root / "src/adapter_main.nim") == 0
  let r = testRoots(base, scSystem)
  for d in [r.coreRoot, r.rt, r.st]: createDir(d)
  seedJournal(r, 4)
  let mgr = fakeManager(r.rt / "manager.sock")
  var adIn, adOut: cint
  let ad = startAdapter(bin, r, adIn, adOut)
  writeAllFd(adIn, encodeLine(helloOffer(crAdapter, "systemd", "system", "2.0.0")))
  let hello = parseLine(readLineFd(adOut))

  proc ask(id, op, unit: string; args: JsonNode = newJObject()):
      tuple[raw: JsonNode, items: seq[(string, JsonNode)], code: string] =
    writeAllFd(adIn, encodeLine(request(id, op, unit, args, deadlineAfter(10_000))))
    while true:
      let m = parseLine(readLineFd(adOut))
      if m.id != id: continue
      case m.kind
      of pmEventItem: result.items.add (m.field, m.data)
      of pmResponseOk:
        result.raw = m.result
        return
      of pmResponseError:
        result.code = m.error.code & ": " & m.error.message
        return
      else: discard

  test "handshake":
    check hello.kind == pmHelloReply

  test "unit.list: each unit exactly once in the merged reply":
    let (raw, items, code) = ask("1", "unit.list", "")
    require code == ""
    check items.len == UnitNames.len
    check raw["units"].len == 0                       # everything went out as items
    let merged = daemonMerge(raw, items)
    let names = merged["units"].getElems.mapIt(it["name"].getStr)
    check names == @UnitNames
    check names.deduplicate.len == names.len

  test "log.read: each entry exactly once in the merged reply":
    let (raw, items, code) = ask("2", "log.read", "hello.service", %*{"lines": 10})
    require code == ""
    check items.len == 4
    check raw["entries"].len == 0
    let merged = daemonMerge(raw, items)
    let msgs = merged["entries"].getElems.mapIt(it["message"].getStr)
    check msgs == @["line 1", "line 2", "line 3", "line 4"]

  test "teardown":
    discard close(adIn)
    var st: cint
    discard waitpid(ad, st, 0)
    check WIFEXITED(st) and WEXITSTATUS(st) == 0
    discard kill(mgr, SIGTERM)
    discard waitpid(mgr, st, 0)
    discard close(adOut)
    removeDir(base)
