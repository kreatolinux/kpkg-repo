## Transient units, set-property, clean and external generators over a harness manager.
import std/[options, os, strutils, unittest]
import harness
import jumpstartcore/errors
import engine/[types, graph, setprop, transient]
import common/roots
import generators/external

proc runTransient(h: Harness; units: seq[TransientUnit]; start: string; collect = true; waitExit = true;
                  timeoutMs = 10_000): Option[TransientResult] =
  var res: Option[TransientResult]
  startTransient(h.m, units, start, collect, true, waitExit, proc(r: TransientResult) = res = some(r))
  discard h.pump(proc(): bool = res.isSome, timeoutMs)
  res

suite "transient units":
  let h = newHarness()
  test "a service runs to completion and is collected":
    let r = h.runTransient(@[TransientUnit(name: "run-t1.service",
      text: "[Unit]\nDefaultDependencies=no\nCollectMode=inactive-or-failed\n[Service]\nStandardOutput=null\nStandardError=null\nExecStart=/bin/sh -c 'exit 0'\n")],
      "run-t1.service")
    check r.isSome and r.get.ok and r.get.result == "success"
    check h.pump(proc(): bool = not fileExists(h.m.roots.sysrun / "transient/run-t1.service"), 5000)
  test "a failing service reports its exit status and result":
    let r = h.runTransient(@[TransientUnit(name: "run-t2.service",
      text: "[Unit]\nDefaultDependencies=no\nCollectMode=inactive-or-failed\n[Service]\nStandardOutput=null\nStandardError=null\nExecStart=/bin/sh -c 'exit 3'\n")],
      "run-t2.service")
    check r.isSome and r.get.ok
    check r.get.result == "exit-code" and r.get.execStatus == 3
    check h.pump(proc(): bool = not fileExists(h.m.roots.sysrun / "transient/run-t2.service"), 5000)
  test "an existing name is refused":
    h.writeUnit("run-t3.service", "[Service]\nExecStart=/bin/true\n")
    h.reload()
    var raised = false
    try:
      startTransient(h.m, @[TransientUnit(name: "run-t3.service", text: "[Service]\nExecStart=/bin/true\n")],
        "run-t3.service", false, true, false, proc(r: TransientResult) = discard)
    except CoreError: raised = true
    check raised
  test "a timer starts its service":
    let marker = h.base / "tm"
    let r = h.runTransient(@[
      TransientUnit(name: "run-t4.service", text: "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nStandardOutput=null\nStandardError=null\nExecStart=/bin/sh -c 'echo x > " & marker & "'\n"),
      TransientUnit(name: "run-t4.timer", text: "[Unit]\nDefaultDependencies=no\n[Timer]\nAccuracySec=1ms\nOnActiveSec=200ms\nRemainAfterElapse=no\n")],
      "run-t4.timer", true, false)
    check r.isSome and r.get.ok
    check h.pump(proc(): bool = fileExists(marker), 8000)

suite "set-property and clean":
  let h = newHarness()
  h.writeUnit("sp.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 30\nStateDirectory=sdc-test-sp\nCacheDirectory=sdc-test-sp\nLogsDirectory=sdc-test-logs\n")
  h.reload()
  test "persistent and runtime drop-ins":
    let r = setProperties(h.m, "sp.service", false, @["CPUWeight=200", "Description=hi"])
    check r.dropins.len == 2
    let p = h.m.roots.etc / "systemd/system.control/sp.service.d/50-CPUWeight.conf"
    check fileExists(p) and readFile(p) == "[Service]\nCPUWeight=200\n"
    check readFile(h.m.roots.etc / "systemd/system.control/sp.service.d/50-Description.conf").startsWith("[Unit]")
    check h.m.lookup("sp.service").def.common.description == "hi"
    discard setProperties(h.m, "sp.service", true, @["Nice=5"])
    check fileExists(h.m.roots.sysrun / "system.control/sp.service.d/50-Nice.conf")
  test "unknown properties are rolled back":
    var raised = false
    try: discard setProperties(h.m, "sp.service", false, @["NoSuchProperty=1"])
    except CoreError: raised = true
    check raised
    check not fileExists(h.m.roots.etc / "systemd/system.control/sp.service.d/50-NoSuchProperty.conf")
  test "clean removes the per-unit directories of an inactive unit":
    createDir(h.m.roots.varLib / "sdc-test-sp")
    writeFile(h.m.roots.varLib / "sdc-test-sp/f", "x")
    createDir(h.m.roots.varCache / "sdc-test-sp")
    createDir(h.m.roots.varLog / "sdc-test-logs")
    check cleanUnit(h.m, "sp.service", @["state"]) == 1
    check not dirExists(h.m.roots.varLib / "sdc-test-sp") and dirExists(h.m.roots.varCache / "sdc-test-sp")
    check dirExists(h.m.roots.varLog / "sdc-test-logs")
    check cleanUnit(h.m, "sp.service", @[]) == 2       # default: cache, runtime and logs
    check not dirExists(h.m.roots.varCache / "sdc-test-sp")
    check not dirExists(h.m.roots.varLog / "sdc-test-logs")
  test "clean uses the user-scope logs root":
    createDir(h.m.roots.varLog / "log/sdc-test-logs")
    h.m.roots.scope = scUser
    check cleanUnit(h.m, "sp.service", @["logs"]) == 1
    h.m.roots.scope = scSystem
    check not dirExists(h.m.roots.varLog / "log/sdc-test-logs")
  test "a running unit cannot be cleaned":
    check h.startUnit("sp.service").get.result == jrDone
    var raised = false
    try: discard cleanUnit(h.m, "sp.service", @["all"])
    except CoreError: raised = true
    check raised
    discard h.startUnit("sp.service", jtStop)

suite "external generators":
  test "generator output takes part in the reload":
    let h = newHarness()
    installExternalGenerators()
    let dir = h.m.roots.usrLib / "systemd/system-generators"
    createDir(dir)
    let gen = dir / "gen1"
    writeFile(gen, "#!/bin/sh\nprintf '[Service]\\nExecStart=/bin/true\\n' > \"$1/gen-a.service\"\nprintf '[Service]\\nExecStart=/bin/true\\n' > \"$3/gen-late.service\"\necho \"$SYSTEMD_SCOPE $SYSTEMD_RELOAD\" > " & h.base & "/genenv\n")
    setFilePermissions(gen, {fpUserRead, fpUserWrite, fpUserExec})
    writeFile(dir / "bad", "#!/bin/sh\nexit 3\n")
    setFilePermissions(dir / "bad", {fpUserRead, fpUserWrite, fpUserExec})
    h.reload()
    check h.m.lookup("gen-a.service") != nil
    check h.m.lookup("gen-late.service") != nil
    check readFile(h.base / "genenv").strip == "system 1"
    # stale output is removed at the next run
    writeFile(gen, "#!/bin/sh\n")
    h.reload()
    check not fileExists(h.m.roots.sysrun / "generator/gen-a.service")
    check generatorList(h.m.roots).len == 2
