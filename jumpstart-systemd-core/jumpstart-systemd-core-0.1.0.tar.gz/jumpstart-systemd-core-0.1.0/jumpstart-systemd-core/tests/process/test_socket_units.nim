import std/[options, os, osproc, posix, unittest]
when defined(linux):
  import std/strutils
import harness
import common/fdutil
import engine/[types]

const root = currentSourcePath().parentDir.parentDir.parentDir
let helper = getTempDir() / "sdc-accept-hello"
doAssert execCmd("nim c --threads:off --hints:off -o:" & helper & " " &
  root / "tests/process/helpers/accept_hello.nim") == 0

proc readAll(fd: cint; ms = 5000): string =
  var buf = newString(256)
  var pfd = TPollfd(fd: fd, events: POLLIN)
  while poll(addr pfd, 1, cint(ms)) > 0:
    let n = read(fd, addr buf[0], buf.len)
    if n <= 0: break
    result.add buf[0 ..< n]

suite "socket units":
  test "Accept=no: connection starts the service with LISTEN_FDS":
    let h = newHarness()
    let path = h.base / "act.sock"
    h.writeUnit("act.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenStream=" & path & "\nFileDescriptorName=web\n")
    h.writeUnit("act.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=" & helper & "\n")
    h.reload()
    check h.startUnit("act.socket").get.result == jrDone
    check h.state("act.socket") == "active/listening"
    check h.state("act.service") == "inactive/dead"
    let cfd = connectUnix(path, true)
    check cfd >= 0
    var reply = ""
    # the manager loop must run while the client waits
    discard h.pump(proc(): bool =
      var pfd = TPollfd(fd: cfd, events: POLLIN)
      if poll(addr pfd, 1, 0) > 0:
        var b = newString(128)
        let n = read(cfd, addr b[0], b.len)
        if n > 0: reply = b[0 ..< n]
        return true, 8000)
    check reply == "hello web"
    check h.waitState("act.service", "inactive/dead", 5000)
    check h.waitState("act.socket", "active/listening", 5000)    # polling resumed
    check h.startUnit("act.socket", jtStop).get.result == jrDone
    check not fileExists(path)
    check h.state("act.service") == "inactive/dead"
    h.cleanup()
  when defined(linux):
    test "ListenNetlink=kobject-uevent 1 (systemd-udevd-kernel.socket) listens":
      let h = newHarness()
      h.writeUnit("nl.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenNetlink=kobject-uevent 1\n")
      h.writeUnit("nl.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sh -c 'ls -l /proc/self/fd/3 > " &
        h.base / "nl.out"  & "'\n")
      h.reload()
      check h.startUnit("nl.socket").get.result == jrDone
      check h.state("nl.socket") == "active/listening"
      check h.startUnit("nl.socket", jtStop).get.result == jrDone
      # PassCredentials=yes must reach the netlink socket (udevd ignores uevents without credentials),
      # and netlink sockets are SOCK_RAW
      let pc = getTempDir() / "sdc-passcred"
      doAssert execCmd("nim c --threads:off --hints:off -o:" & pc & " " & root / "tests/process/helpers/passcred.nim") == 0
      let outf = h.base / "pc.out"
      h.writeUnit("nlc.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenNetlink=kobject-uevent 1\nPassCredentials=yes\nReceiveBuffer=1M\nService=nlc.service\n")
      h.writeUnit("nlc.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=" & pc & " " & outf & "\n")
      h.reload()
      check h.startUnit("nlc.socket").get.result == jrDone
      writeFile("/sys/class/net/lo/uevent", "change")     # a kernel uevent wakes the socket
      check h.pump(proc(): bool = fileExists(outf), 8000)
      check readFile(outf).strip == "passcred=1 type=3"   # SOCK_RAW == 3
      check h.startUnit("nlc.socket", jtStop).get.result == jrDone
      h.writeUnit("nlbad.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenNetlink=nonsense 1\n")
      h.reload()
      check h.startUnit("nlbad.socket").get.result != jrDone
      h.cleanup()
    test "three listeners arrive contiguously at 3, 4 and 5 (past the spawn layer's old reserved 5)":
      let h = newHarness()
      let out1 = h.base / "fds.out"
      h.writeUnit("multi.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenStream=" & h.base / "m1.sock" &
        "\nListenStream=" & h.base / "m2.sock" & "\nListenStream=" & h.base / "m3.sock" & "\nFileDescriptorName=web\n")
      let script = h.base / "chk.sh"
      writeFile(script, "echo $LISTEN_FDS $LISTEN_FDNAMES > " & out1 & "\nfor n in 3 4 5; do [ -S /dev/fd/$n ] && echo sock$n >> " & out1 & "; done\nexit 0\n")
      h.writeUnit("multi.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sh " & script & "\n")
      h.reload()
      check h.startUnit("multi.socket").get.result == jrDone
      let cfd = connectUnix(h.base / "m3.sock", true)
      check cfd >= 0
      check h.pump(proc(): bool = fileExists(out1) and readFile(out1).count('\n') >= 4, 8000)
      check readFile(out1).splitLines()[0] == "3 web:web:web"
      check readFile(out1).contains("sock3") and readFile(out1).contains("sock4") and readFile(out1).contains("sock5")
      discard close(cfd)
      h.cleanup()
  when defined(linux):
    test "LISTEN_FDS also reaches Type=oneshot ExecStart and the Pre/Post/Stop helpers (systemd 255)":
      let h = newHarness()
      let out1 = h.base / "phases.out"
      h.writeUnit("shot.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenStream=" & h.base / "shot.sock" & "\nFileDescriptorName=web\n")
      let script = h.base / "phase.sh"
      writeFile(script, "s=no; [ -S /dev/fd/3 ] && s=yes\necho \"$1 fds=$LISTEN_FDS names=$LISTEN_FDNAMES sock=$s pid=$([ \"$LISTEN_PID\" = \"$$\" ] && echo ok)\" >> " & out1 & "\n")
      h.writeUnit("shot.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nRemainAfterExit=yes\n" &
        "ExecStartPre=/bin/sh " & script & " pre\nExecStart=/bin/sh " & script & " start\nExecStartPost=/bin/sh " & script & " post\n" &
        "ExecStop=/bin/sh " & script & " stop\n")
      h.reload()
      check h.startUnit("shot.socket").get.result == jrDone
      let cfd = connectUnix(h.base / "shot.sock", true)
      check cfd >= 0
      check h.pump(proc(): bool = h.state("shot.service") == "active/exited", 8000)
      check h.startUnit("shot.service", jtStop).get.result == jrDone
      let lines = readFile(out1).splitLines()
      for ph in ["pre", "start", "post", "stop"]:
        check (ph & " fds=1 names=web sock=yes pid=ok") in lines
      discard close(cfd)
      h.cleanup()
  test "Accept=yes starts an instance per connection":
    let h = newHarness()
    let path = h.base / "acc.sock"
    h.writeUnit("acc.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenStream=" & path & "\nAccept=yes\n")
    h.writeUnit("acc@.service", "[Unit]\nDefaultDependencies=no\n[Service]\nStandardInput=socket\nStandardOutput=socket\nExecStart=/bin/cat\n")
    h.reload()
    check h.startUnit("acc.socket").get.result == jrDone
    let cfd = connectUnix(path, true)
    check cfd >= 0
    discard write(cfd, "ping\n".cstring, 5)
    var reply = ""
    discard h.pump(proc(): bool =
      var pfd = TPollfd(fd: cfd, events: POLLIN)
      if poll(addr pfd, 1, 0) > 0:
        var b = newString(16)
        let n = read(cfd, addr b[0], b.len)
        if n > 0: reply = b[0 ..< n]
        return true, 8000)
    check reply == "ping\n"
    discard close(cfd)
    h.cleanup()
  test "listening on a busy path fails the socket":
    let h = newHarness()
    let path = h.base / "busy.sock"
    let first = bindUnix(path, true, 0o600)
    check first >= 0
    h.writeUnit("busy.socket", "[Unit]\nDefaultDependencies=no\n[Socket]\nListenStream=" & path & "\n")
    h.reload()
    let o = h.startUnit("busy.socket")
    check h.state("busy.socket") == "failed/failed"
    discard close(first)
    h.cleanup()
