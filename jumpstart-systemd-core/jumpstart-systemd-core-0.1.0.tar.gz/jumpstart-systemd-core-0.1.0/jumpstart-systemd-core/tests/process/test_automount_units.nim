## Automount units against the real kernel (Linux, root, autofs): a lookup starts
## the .mount, idle mounts are expired, stopping removes the autofs mount.
when defined(linux):
  import std/[options, os, osproc, posix, strutils, unittest]
  import harness
  import engine/[types]
  import units/mount

  proc mountedAs(where, fstype: string): bool =
    for e in parseMountinfo(readFile("/proc/self/mountinfo")):
      if e.mountPoint == where and e.fstype == fstype: return true

  proc autofsAvailable(): bool =
    geteuid() == 0 and "autofs" in readFile("/proc/filesystems")

  suite "automount units":
    test "lookup triggers the mount, TimeoutIdleSec expires it, stop unmounts the autofs":
      if not autofsAvailable(): skip()
      else:
        let h = newHarness()
        h.m.roots.mountinfo = "/proc/self/mountinfo"
        let where = "/tmp/sdc-am1"
        removeDir(where)
        h.writeUnit("tmp-sdc\\x2dam1.mount", "[Unit]\nDefaultDependencies=no\n[Mount]\nWhat=tmpfs\nWhere=" & where & "\nType=tmpfs\nOptions=size=1m\n")
        h.writeUnit("tmp-sdc\\x2dam1.automount", "[Unit]\nDefaultDependencies=no\n[Automount]\nWhere=" & where & "\nTimeoutIdleSec=2\nDirectoryMode=0711\n")
        h.reload()
        h.m.watchMountinfo()
        let mnt = "tmp-sdc\\x2dam1.mount"
        let auto = "tmp-sdc\\x2dam1.automount"
        check h.startUnit(auto).get.result == jrDone
        check h.state(auto) == "active/waiting"
        check mountedAs(where, "autofs")
        check h.state(mnt) == "inactive/dead"
        # a process outside the manager's process group looks the directory up
        let p = startProcess("/usr/bin/setsid", args = ["/bin/sh", "-c", "echo hi > " & where & "/f && cat " & where & "/f"],
                             options = {poStdErrToStdOut, poUsePath})
        check h.waitState(mnt, "active/mounted", 15_000)
        check h.state(auto) == "active/running"
        check mountedAs(where, "tmpfs")
        check h.pump(proc(): bool = not p.running, 10_000)
        check p.waitForExit(1000) == 0
        close(p)
        # nothing touches it any more: the idle timeout expires the mount
        check h.waitState(mnt, "inactive/dead", 30_000)
        check h.waitState(auto, "active/waiting", 5000)
        check mountedAs(where, "autofs") and not mountedAs(where, "tmpfs")
        check h.startUnit(auto, jtStop).get.result == jrDone
        check h.state(auto) == "inactive/dead"
        check not mountedAs(where, "autofs")
        h.cleanup()
        removeDir(where)
    test "a failing mount answers the lookup with an error and the automount keeps waiting":
      if not autofsAvailable(): skip()
      else:
        let h = newHarness()
        h.m.roots.mountinfo = "/proc/self/mountinfo"
        let where = "/tmp/sdc-am2"
        removeDir(where)
        h.writeUnit("tmp-sdc\\x2dam2.mount", "[Unit]\nDefaultDependencies=no\n[Mount]\nWhat=nothing\nWhere=" & where & "\nType=nonexistentfs\n")
        h.writeUnit("tmp-sdc\\x2dam2.automount", "[Unit]\nDefaultDependencies=no\n[Automount]\nWhere=" & where & "\n")
        h.reload()
        h.m.watchMountinfo()
        check h.startUnit("tmp-sdc\\x2dam2.automount").get.result == jrDone
        let p = startProcess("/usr/bin/setsid", args = ["/bin/sh", "-c", "ls " & where & "/x"],
                             options = {poStdErrToStdOut, poUsePath})
        check h.pump(proc(): bool = not p.running, 20_000)
        check p.waitForExit(1000) != 0
        close(p)
        check h.waitState("tmp-sdc\\x2dam2.mount", "failed/failed", 10_000) or
              h.state("tmp-sdc\\x2dam2.mount") == "inactive/dead"
        check h.waitState("tmp-sdc\\x2dam2.automount", "active/waiting", 5000)
        discard h.startUnit("tmp-sdc\\x2dam2.automount", jtStop)
        check not mountedAs(where, "autofs")
        h.cleanup()
        removeDir(where)
    test "starting over an existing mount point is refused":
      if not autofsAvailable(): skip()
      else:
        let h = newHarness()
        h.m.roots.mountinfo = "/proc/self/mountinfo"
        h.writeUnit("proc.mount", "[Unit]\nDefaultDependencies=no\n[Mount]\nWhat=proc\nWhere=/proc\nType=proc\n")
        h.writeUnit("proc.automount", "[Unit]\nDefaultDependencies=no\n[Automount]\nWhere=/proc\n")
        h.reload()
        discard h.startUnit("proc.automount")
        check h.state("proc.automount") == "failed/failed"
        h.cleanup()
