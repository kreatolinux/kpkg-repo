## org.freedesktop.systemd1 on a real session bus (src/dbus/sd1api.nim): a
## private dbus-daemon (with --systemd-activation), a user-scope manager that
## owns the name, and gdbus as an independent client. Needs dbus-daemon and
## gdbus (GLib) on PATH; skipped otherwise.
import std/[os, osproc, posix, strutils, tables, times, unittest, streams]
import harness
import common/roots
import unitfile/model
import engine/[types, graph, manager, eventloop]
import units/[socket, mount, timer, path, swap, automount]
import dbus/sd1api

const repoRoot = currentSourcePath().parentDir.parentDir.parentDir
let haveTools = findExe("dbus-daemon").len > 0 and findExe("gdbus").len > 0

type Env = ref object
  h: Harness
  base, xdg: string
  bus: Process
  api: BusApi

proc userRoots(base: string): Roots =
  putEnv("JUMPSTART_MODE", "user")
  putEnv("HOME", base / "home")
  putEnv("XDG_RUNTIME_DIR", base / "xdg")
  putEnv("JUMPSTART_CORE_ROOT", base / "core")
  putEnv("JUMPSTART_CORE_RUNTIME_DIR", base / "rt")
  putEnv("JUMPSTART_CORE_STATE_DIR", base / "st")
  result = rootsFromEnvironment()
  let sys = testRoots(base, scUser)
  result.usrLib = sys.usrLib; result.usrShare = sys.usrShare; result.run = sys.run
  result.cgroupMount = sys.cgroupMount; result.procfs = sys.procfs; result.sysfs = sys.sysfs
  result.devfs = sys.devfs; result.cmdline = sys.cmdline; result.mountinfo = sys.mountinfo
  result.swaps = sys.swaps; result.osRelease = sys.osRelease; result.machineId = sys.machineId
  result.fstab = sys.fstab; result.controlCgroup = ""; result.unitsCgroup = ""

proc busAddress(e: Env): string = "unix:path=" & e.xdg / "bus"

proc startBus(e: Env) =
  let conf = e.base / "bus.conf"
  writeFile(conf, """<!DOCTYPE busconfig PUBLIC "-//freedesktop//DTD D-Bus Bus Configuration 1.0//EN"
 "http://www.freedesktop.org/standards/dbus/1.0/busconfig.dtd">
<busconfig>
  <type>session</type>
  <listen>""" & e.busAddress & """</listen>
  <auth>EXTERNAL</auth>
  <servicedir>""" & e.base / "usr/share/dbus-1/services" & """</servicedir>
  <policy context="default">
    <allow send_destination="*" eavesdrop="true"/>
    <allow eavesdrop="true"/>
    <allow own="*"/>
  </policy>
</busconfig>
""")
  e.bus = startProcess("dbus-daemon", args = ["--config-file=" & conf, "--nofork",
    "--nopidfile", "--systemd-activation"], options = {poUsePath, poStdErrToStdOut})
  let deadline = epochTime() + 5
  while epochTime() < deadline and not fileExists(e.xdg / "bus") and not symlinkExists(e.xdg / "bus"):
    var st: Stat
    if lstat(cstring(e.xdg / "bus"), st) == 0: break
    sleep(20)

proc stopBus(e: Env) =
  if e.bus != nil:
    e.bus.terminate()
    discard e.bus.waitForExit()
    e.bus.close()
    e.bus = nil

proc newEnv(): Env =
  buildExecutor()
  let base = "/tmp/sdc-dbus-" & $getpid()
  removeDir(base)
  for d in ["home", "xdg", "core/bin", "core/share", "rt", "st", "etc", "proc", "usr/lib", "run", "usr/share/dbus-1/services"]:
    createDir(base / d)
  discard chmod(cstring(base / "xdg"), 0o700)
  let roots = userRoots(base)
  copyFile(builtExec, roots.coreRoot / "bin/systemd-compat-exec")
  setFilePermissions(roots.coreRoot / "bin/systemd-compat-exec",
    {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec, fpOthersRead, fpOthersExec})
  copyDir(repoRoot / "share/units-user", roots.coreRoot / "share/units-user")
  createDir(roots.etc / "systemd/user")
  createDir(roots.sysrun)
  installSocketSupport()
  installMountSupport()
  installTimerSupport()
  installPathSupport()
  installSwapSupport()
  installAutomountSupport()
  let m = newManager(roots)
  m.hookReaper()
  result = Env(h: Harness(m: m, base: base), base: base, xdg: roots.runtime)

proc unit(e: Env; name, text: string) =
  var body = text
  if "[Service]\n" in body and "StandardOutput=" notin body:
    body = body.replace("[Service]\n", "[Service]\nStandardOutput=null\nStandardError=null\n")
  writeFile(e.h.m.roots.etc / "systemd/user" / name, body)

proc run(e: Env; args: seq[string]; timeoutMs = 8000): tuple[code: int, output: string] =
  ## Runs a client while the manager's loop keeps running.
  putEnv("DBUS_SESSION_BUS_ADDRESS", e.busAddress)
  let p = startProcess(args[0], args = args[1 .. ^1], options = {poUsePath, poStdErrToStdOut})
  let deadline = epochTime() + timeoutMs / 1000
  while p.running and epochTime() < deadline:
    e.h.m.loop.runOnce(10)
  if p.running:
    p.terminate()
  let code = p.waitForExit()
  result = (code, p.outputStream.readAll())
  p.close()

proc gcall(e: Env; path, meth: string; args: varargs[string]): tuple[code: int, output: string] =
  e.run(@["gdbus", "call", "--session", "--dest", "org.freedesktop.systemd1",
          "--object-path", path, "--method", meth] & @args)

if not haveTools:
  echo "dbus-daemon or gdbus not found; skipping"
  quit 0

suite "org.freedesktop.systemd1 on the session bus":
  let e = newEnv()
  e.unit("a.service", "[Unit]\nDescription=Test A\n[Service]\nExecStart=/bin/sleep 1000\n")
  e.unit("b.target", "[Unit]\nDescription=B\nWants=a.service\n")
  e.unit("act.service", "[Service]\nExecStart=/bin/sleep 1000\n")
  e.unit("refused.service", "[Unit]\nRefuseManualStart=yes\n[Service]\nExecStart=/bin/sleep 1000\n")
  e.unit("fails.service", "[Service]\nExecStart=/bin/false\n")
  let svcDir = e.base / "usr/share/dbus-1/services"
  writeFile(svcDir / "org.example.Act.service",
    "[D-BUS Service]\nName=org.example.Act\nExec=/bin/false\nSystemdService=act.service\n")
  writeFile(svcDir / "org.example.Missing.service",
    "[D-BUS Service]\nName=org.example.Missing\nExec=/bin/false\nSystemdService=missing@.service\n")
  writeFile(svcDir / "org.example.Dies.service",
    "[D-BUS Service]\nName=org.example.Dies\nExec=/bin/false\nSystemdService=dies.service\n")
  writeFile(svcDir / "org.example.NoUnit.service",
    "[D-BUS Service]\nName=org.example.NoUnit\nExec=/bin/sleep 1000\nSystemdService=nounit.service\n")
  discard e.h.m.daemonReload()
  e.startBus()
  e.api = installBusApi(e.h.m)

  test "the manager owns the name and the session bus address is exported":
    check e.api != nil and e.api.conn != nil
    check e.h.m.env.getOrDefault("DBUS_SESSION_BUS_ADDRESS") == e.busAddress
    let r = e.run(@["gdbus", "call", "--session", "--dest", "org.freedesktop.DBus",
      "--object-path", "/org/freedesktop/DBus", "--method", "org.freedesktop.DBus.NameHasOwner",
      "org.freedesktop.systemd1"])
    check r.code == 0 and "true" in r.output

  test "GetUnit of a unit that is not loaded is NoSuchUnit":
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.GetUnit", "graphical-session.target")
    check r.code != 0 and "org.freedesktop.systemd1.NoSuchUnit" in r.output

  test "StartUnit returns a job; JobRemoved and PropertiesChanged are signalled":
    putEnv("DBUS_SESSION_BUS_ADDRESS", e.busAddress)
    let mon = startProcess("gdbus", args = ["monitor", "--session", "--dest", "org.freedesktop.systemd1"],
      options = {poUsePath, poStdErrToStdOut})
    let t0 = epochTime()
    while epochTime() - t0 < 0.5: e.h.m.loop.runOnce(10)
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.StartUnit", "b.target", "fail")
    check r.code == 0 and "/org/freedesktop/systemd1/job/" in r.output
    check e.h.pump(proc(): bool = e.h.state("a.service") == "active/running")
    let t1 = epochTime()
    while epochTime() - t1 < 0.7: e.h.m.loop.runOnce(10)
    mon.terminate()
    discard mon.waitForExit()
    let seen = mon.outputStream.readAll()
    mon.close()
    check "JobNew" in seen and "JobRemoved" in seen and "'b.target', 'done'" in seen
    check "UnitNew" notin seen and "UnitRemoved" notin seen     # described, never emitted
    check "/org/freedesktop/systemd1/unit/a_2eservice: org.freedesktop.DBus.Properties.PropertiesChanged" in seen
    check "'ActiveState': <'active'>" in seen

  test "GetUnit, Properties.Get and GetAll on the unit object":
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.GetUnit", "a.service")
    check r.code == 0 and "/org/freedesktop/systemd1/unit/a_2eservice" in r.output
    let g = e.gcall("/org/freedesktop/systemd1/unit/a_2eservice", "org.freedesktop.DBus.Properties.Get",
      "org.freedesktop.systemd1.Unit", "ActiveState")
    check g.code == 0 and g.output.strip == "(<'active'>,)"
    let all = e.gcall("/org/freedesktop/systemd1/unit/a_2eservice", "org.freedesktop.DBus.Properties.GetAll",
      "org.freedesktop.systemd1.Service")
    check all.code == 0 and "'MainPID': <uint32 " in all.output and "'Type': <'simple'>" in all.output
    let u = e.gcall("/org/freedesktop/systemd1/unit/a_2eservice", "org.freedesktop.DBus.Properties.GetAll",
      "org.freedesktop.systemd1.Unit")
    check u.code == 0 and "'Description': <'Test A'>" in u.output and "'WantedBy': <['b.target']>" in u.output

  test "Unit.Stop on the object path":
    let r = e.gcall("/org/freedesktop/systemd1/unit/a_2eservice", "org.freedesktop.systemd1.Unit.Stop", "replace")
    check r.code == 0 and "/job/" in r.output
    check e.h.pump(proc(): bool = e.h.state("a.service") == "inactive/dead")

  test "RefuseManualStart is enforced; unknown units and bad modes are errors":
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.StartUnit", "refused.service", "replace")
    check r.code != 0 and "org.freedesktop.systemd1.OnlyByDependency" in r.output
    let n = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.StartUnit", "nope.service", "replace")
    check n.code != 0 and "org.freedesktop.systemd1.NoSuchUnit" in n.output
    let b = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.StartUnit", "a.service", "sideways")
    check b.code != 0 and "InvalidArgs" in b.output

  test "a failed unit is reset by ResetFailed":
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.StartUnit", "fails.service", "replace")
    check r.code == 0
    check e.h.pump(proc(): bool = e.h.state("fails.service").startsWith("failed"))
    let rf = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.ResetFailed")
    check rf.code == 0
    check e.h.state("fails.service") != "failed/failed"

  test "UnsetAndSetEnvironment and the Environment property":
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.UnsetAndSetEnvironment",
      "['GONE']", "['XDG_SESSION_TYPE=wayland', 'FOO=bar baz']")
    check r.code == 0
    check e.h.m.env.getOrDefault("XDG_SESSION_TYPE") == "wayland"
    check e.h.m.env.getOrDefault("FOO") == "bar baz"
    let g = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.DBus.Properties.Get",
      "org.freedesktop.systemd1.Manager", "Environment")
    check g.code == 0 and g.output.startsWith("(<[") and "'XDG_SESSION_TYPE=wayland'" in g.output
    let bad = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.SetEnvironment", "['=x']")
    check bad.code != 0 and "InvalidArgs" in bad.output

  test "ListUnits and ListJobs":
    discard e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.StartUnit", "a.service", "replace")
    check e.h.pump(proc(): bool = e.h.state("a.service") == "active/running")
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.ListUnits")
    check r.code == 0 and "('a.service', 'Test A', 'loaded', 'active', 'running'" in r.output
    let j = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager.ListJobs")
    check j.code == 0

  test "introspection":
    let r = e.run(@["gdbus", "introspect", "--session", "--dest", "org.freedesktop.systemd1",
      "--object-path", "/org/freedesktop/systemd1"])
    check r.code == 0 and "StartUnit" in r.output and "JobRemoved" in r.output
    # Both signals are part of the interface description although this core
    # never emits them (RFC 0002 §16.1 row 41).
    check "UnitNew" in r.output and "UnitRemoved" in r.output
    let u = e.run(@["gdbus", "introspect", "--session", "--dest", "org.freedesktop.systemd1",
      "--object-path", "/org/freedesktop/systemd1/unit/a_2eservice"])
    check u.code == 0 and "org.freedesktop.systemd1.Service" in u.output and "ActiveState" in u.output

  test "bus activation starts the unit named by SystemdService=":
    putEnv("DBUS_SESSION_BUS_ADDRESS", e.busAddress)
    let p = startProcess("gdbus", args = ["call", "--session", "--dest", "org.example.Act",
      "--object-path", "/", "--method", "org.freedesktop.DBus.Peer.Ping", "--timeout", "3"],
      options = {poUsePath, poStdErrToStdOut})
    check e.h.pump(proc(): bool = e.h.state("act.service") == "active/running", 4000)
    p.terminate()
    discard p.waitForExit()
    p.close()

  test "bus activation of a missing unit fails at once with ActivationFailure":
    let t0 = epochTime()
    let r = e.run(@["gdbus", "call", "--session", "--dest", "org.example.Missing",
      "--object-path", "/", "--method", "org.freedesktop.DBus.Peer.Ping", "--timeout", "10"])
    check r.code != 0 and "org.freedesktop.systemd1.NoSuchUnit" in r.output
    check epochTime() - t0 < 5

  test "a bus-activated service that dies before taking its name fails the activation at once":
    let t0 = epochTime()
    let r = e.run(@["gdbus", "call", "--session", "--dest", "org.example.Dies",
      "--object-path", "/", "--method", "org.freedesktop.DBus.Peer.Ping", "--timeout", "20"])
    check r.code != 0 and "dies.service" in r.output
    check epochTime() - t0 < 5

  test "a SystemdService= without a unit file runs the service file's Exec= as a transient unit":
    putEnv("DBUS_SESSION_BUS_ADDRESS", e.busAddress)
    let p = startProcess("gdbus", args = ["call", "--session", "--dest", "org.example.NoUnit",
      "--object-path", "/", "--method", "org.freedesktop.DBus.Peer.Ping", "--timeout", "3"],
      options = {poUsePath, poStdErrToStdOut})
    check e.h.pump(proc(): bool = e.h.state("nounit.service") == "active/running", 4000)
    let u = e.h.m.lookup("nounit.service")
    check u != nil and u.def.common.source == usTransient
    check u.def.service.busName == "org.example.NoUnit"
    p.terminate()
    discard p.waitForExit()
    p.close()
    discard e.h.startUnit("nounit.service", jtStop)

  test "the name is taken again when the bus restarts":
    e.stopBus()
    check e.h.pump(proc(): bool = e.api.conn == nil, 3000)
    e.startBus()
    check e.h.pump(proc(): bool = e.api.conn != nil, 4000)
    let r = e.gcall("/org/freedesktop/systemd1", "org.freedesktop.DBus.Peer.Ping")
    check r.code == 0

  e.stopBus()
  for u in ["a.service", "act.service"]:
    discard e.h.startUnit(u, jtStop)
  removeDir(e.base)
