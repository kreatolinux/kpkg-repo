## User scope (spec §14.1): the manager built from `JUMPSTART_MODE=user` roots (HOME,
## XDG_RUNTIME_DIR), the user unit search path, user units starting and stopping,
## the public socket and the shipped user units.
import std/[json, options, os, osproc, posix, sequtils, strutils, unittest]
import tools/journalctl
import harness
import common/roots
import unitfile/[model, paths]
import engine/[types, graph, manager, boot, eventloop]
import service/service
import units/[socket, mount, timer, path, swap, automount]
import generators/xdgautostart
import common/clock
when defined(linux):
  import common/fdutil
import ipc/[server, verbs, client]
import jumpstartcore/errors

const repoRoot = currentSourcePath().parentDir.parentDir.parentDir
var counter = 0
let builtJournald = getTempDir() / "sdc-harness-journald"
var journaldBuilt = false

proc buildJournald() =
  if journaldBuilt: return
  doAssert execCmd("nim c --threads:off --hints:off -o:" & builtJournald & " " &
    repoRoot / "src/journald_main.nim") == 0
  journaldBuilt = true

type UserEnv = ref object
  h: Harness
  home, xdg, core: string

proc userRoots(base: string): Roots =
  ## Exactly what the manager derives at start, then the machine-wide locations
  ## moved below `base` so the test does not read the real /etc and /usr.
  putEnv("JUMPSTART_MODE", "user")
  putEnv("HOME", base / "home")
  putEnv("XDG_RUNTIME_DIR", base / "xdg")
  putEnv("JUMPSTART_CORE_ROOT", base / "core")
  putEnv("JUMPSTART_CORE_RUNTIME_DIR", base / "rt")
  putEnv("JUMPSTART_CORE_STATE_DIR", base / "st")
  result = rootsFromEnvironment()
  let sys = testRoots(base, scUser)
  result.usrLib = sys.usrLib; result.usrShare = sys.usrShare; result.run = sys.run
  result.cgroupMount = sys.cgroupMount; result.procfs = sys.procfs; result.sysfs = sys.sysfs
  result.devfs = sys.devfs; result.cmdline = sys.cmdline; result.mountinfo = sys.mountinfo
  result.swaps = sys.swaps; result.osRelease = sys.osRelease; result.machineId = sys.machineId
  result.fstab = sys.fstab; result.controlCgroup = ""; result.unitsCgroup = ""

proc newUserEnv(): UserEnv =
  buildExecutor()
  inc counter
  let base = "/tmp/sdc-u-" & $getpid() & "-" & $counter
  removeDir(base)
  for d in ["home", "xdg", "core/bin", "core/share", "rt", "st", "etc", "proc", "usr/lib", "run"]:
    createDir(base / d)
  let roots = userRoots(base)
  copyFile(builtExec, roots.coreRoot / "bin/systemd-compat-exec")
  setFilePermissions(roots.coreRoot / "bin/systemd-compat-exec",
    {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec, fpOthersRead, fpOthersExec})
  copyDir(repoRoot / "share/units-user", roots.coreRoot / "share/units-user")
  buildJournald()
  copyFile(builtJournald, roots.coreRoot / "bin/systemd-compat-journald")
  setFilePermissions(roots.coreRoot / "bin/systemd-compat-journald",
    {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec, fpOthersRead, fpOthersExec})
  for f in walkFiles(roots.coreRoot / "share/units-user/*.service"):
    writeFile(f, readFile(f).replace("@COREDIR@", roots.coreRoot))
  createDir(roots.etc / "systemd/user")
  createDir(roots.sysrun)
  installSocketSupport()
  installMountSupport()
  installTimerSupport()
  installPathSupport()
  installSwapSupport()
  installAutomountSupport()
  let m = newManager(roots)
  m.hookReaper()
  UserEnv(h: Harness(m: m, base: base), home: roots.home, xdg: roots.runtime, core: roots.coreRoot)

proc userDir(e: UserEnv): string = e.h.m.roots.etc / "systemd/user"

proc writeUser(e: UserEnv; name, text: string; dir = "") =
  var body = text
  for sec in ["[Service]\n", "[Socket]\n"]:
    if "StandardOutput=" notin text: body = body.replace(sec, sec & "StandardOutput=null\n")
    if "StandardError=" notin text: body = body.replace(sec, sec & "StandardError=null\n")
  let d = if dir.len > 0: dir else: e.userDir
  createDir(d)
  writeFile(d / name, body)

suite "user roots and search path":
  let e = newUserEnv()
  let r = e.h.m.roots
  test "roots follow HOME and XDG_RUNTIME_DIR":
    check r.scope == scUser and r.uid == geteuid()
    check r.home == e.home and r.runtime == e.xdg
    check r.sysrun == e.xdg / "systemd"
    check r.etc == e.home / ".config"
    check r.varLib == e.home / ".local/state"
    check r.limits.deactivateBudgetMs == 15_000
  test "unit search path is the 17 directories of the specification, in order":
    let b = e.h.base
    let want = [
      e.home / ".config/systemd/user.control", e.xdg / "systemd/user.control",
      e.xdg / "systemd/transient", e.xdg / "systemd/generator.early",
      e.home / ".config/systemd/user", b / "etc/xdg/systemd/user", b / "etc/systemd/user",
      e.xdg / "systemd/user", b / "run/systemd/user", e.xdg / "systemd/generator",
      e.home / ".local/share/systemd/user", b / "usr/local/share/systemd/user",
      b / "usr/share/systemd/user", b / "usr/local/lib/systemd/user", b / "usr/lib/systemd/user",
      e.xdg / "systemd/generator.late", e.core / "share/units-user"]
    check unitSearchPath(r).mapIt(it.path) == @want
  test "a unit is found in the user directories; the first directory wins":
    let b = e.h.base
    e.writeUser("p.service", "[Service]\nExecStart=/bin/true\n[Unit]\nDescription=lib\n", b / "usr/lib/systemd/user")
    e.writeUser("p.service", "[Unit]\nDescription=etc\n[Service]\nExecStart=/bin/true\n", b / "etc/systemd/user")
    e.h.reload()
    check e.h.m.lookup("p.service").def.common.description == "etc"
    e.writeUser("p.service", "[Unit]\nDescription=home\n[Service]\nExecStart=/bin/true\n")
    e.h.reload()
    check e.h.m.lookup("p.service").def.common.description == "home"
    e.writeUser("p.service", "[Unit]\nDescription=ctl\n[Service]\nExecStart=/bin/true\n", e.home / ".config/systemd/user.control")
    e.h.reload()
    check e.h.m.lookup("p.service").def.common.description == "ctl"
  test "system unit directories are not searched":
    e.writeUser("sysonly.service", "[Service]\nExecStart=/bin/true\n", e.h.base / "etc/systemd/system")
    e.h.reload()
    check e.h.m.lookup("sysonly.service") == nil
  test "shipped user units are found":
    for n in ["default.target", "basic.target", "sockets.target", "timers.target", "paths.target",
              "exit.target", "shutdown.target", "graphical-session.target", "app.slice",
              "session.slice", "background.slice"]:
      check e.h.m.lookup(n) != nil and e.h.m.lookup(n).loadOk
    check e.h.m.lookup("multi-user.target") == nil     # system targets are not shipped for users
  test "unit types an unprivileged manager cannot run":
    e.writeUser("home-x.mount", "[Mount]\nWhat=tmpfs\nWhere=/tmp/x\nType=tmpfs\n")
    e.h.reload()
    let u = e.h.m.lookup("home-x.mount")
    if u != nil and u.loadOk:
      let o = e.h.startUnit("home-x.mount")
      check o.isNone or o.get.result != jrDone
  test "cleanup":
    e.h.cleanup()

suite "user services":
  let e = newUserEnv()
  test "boot starts default.target and its dependencies":
    e.writeUser("auto.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 30\n[Install]\nWantedBy=default.target\n")
    createDir(e.userDir / "default.target.wants")
    createSymlink(e.userDir / "auto.service", e.userDir / "default.target.wants/auto.service")
    e.h.reload()
    var done = false
    var started = 0
    var failed: seq[FailedUnit]
    e.h.m.activate(proc(s: int; f: seq[FailedUnit]) =
      done = true
      started = s
      failed = f)
    check e.h.pump(proc(): bool = done)
    check failed.len == 0
    check started >= 4                                  # default, basic, sockets/timers/paths, auto.service
    check e.h.state("default.target") == "active/active"
    check e.h.state("basic.target") == "active/active"
    check e.h.state("auto.service") == "active/running"
    discard e.h.startUnit("auto.service", jtStop)
  test "a service runs as the user, with XDG_RUNTIME_DIR and the user notify socket; User= is ignored":
    let outp = e.h.base / "env.out"
    e.writeUser("who.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nUser=nobody\nGroup=nobody\n" &
      "ExecStart=/bin/sh -c 'echo $(id -u):$XDG_RUNTIME_DIR:$NOTIFY_SOCKET:$HOME > " & outp & "'\n")
    e.h.reload()
    let o = e.h.startUnit("who.service")
    check o.isSome and o.get.result == jrDone
    let line = readFile(outp).strip
    check line.startsWith($getuid() & ":" & e.xdg & ":" & e.xdg / "systemd/notify:")
  test "start, status and stop of a simple user service; the stop kills its processes":
    e.writeUser("sleepy.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 60\n")
    e.h.reload()
    check e.h.startUnit("sleepy.service").get.result == jrDone
    check e.h.state("sleepy.service") == "active/running"
    let pid = sd(e.h.m.lookup("sleepy.service")).mainPid
    check pid > 0 and kill(Pid(pid), 0) == 0
    check e.h.startUnit("sleepy.service", jtStop).get.result == jrDone
    check e.h.state("sleepy.service") == "inactive/dead"
    check e.h.pump(proc(): bool = kill(Pid(pid), 0) != 0)
  test "Restart= works in user scope":
    e.writeUser("again.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nRestart=always\nRestartSec=50ms\nExecStart=/bin/sh -c 'sleep 0.2'\n")
    e.h.reload()
    check e.h.startUnit("again.service").get.result == jrDone
    let u = e.h.m.lookup("again.service")
    check e.h.pump(proc(): bool = sd(u).nRestarts >= 2, 8000)
    discard e.h.startUnit("again.service", jtStop)
  test "a service with the default (journal) output is logged to the user journal with _SYSTEMD_USER_UNIT":
    writeFile(e.userDir / "logs.service", "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\n" &
      "ExecStart=/bin/sh -c 'echo hello-user-journal; echo oops >&2'\n")
    e.h.reload()
    let svc = e.h.m.lookup("logs.service")
    check "systemd-journald.socket" in svc.def.common.deps[dkRequires] & svc.def.common.implicitDeps[dkRequires]
    let sock = e.h.m.lookup("systemd-journald.socket")
    check sock != nil and sock.loadOk
    check e.h.startUnit("logs.service").get.result == jrDone
    check access((e.xdg / "systemd/journal/stdout").cstring, F_OK) == 0
    var text = ""
    proc grab(): string =
      var o, er: string
      proc out1(s: string) = o.add s
      proc err1(s: string) = er.add s
      discard journalctlRun(@["--user", "-u", "logs.service", "-o", "cat", "--no-pager"], e.h.m.roots, out1, err1)
      o
    check e.h.pump(proc(): bool =
      text = grab()
      "hello-user-journal" in text and "oops" in text, 10_000)
    check e.h.m.roots.st.len > 0 and dirExists(e.h.m.roots.st / "journal")
    # the daemon is the user's own: its files are private
    for f in walkDirRec(e.h.m.roots.st / "journal"):
      if f.endsWith(".jrn"):
        var st: Stat
        check stat(f.cstring, st) == 0 and (int(st.st_mode) and 0o077) == 0
    discard e.h.startUnit("systemd-journald.service", jtStop)
  test "exit.target requests the end of the user daemon; power targets are refused":
    var requested: seq[PowerAction]
    e.h.m.powerHook = proc(a: PowerAction): bool =
      requested.add a
      true
    let bad = e.h.m.lookup("poweroff.target")
    if bad != nil:
      let o = e.h.startUnit("poweroff.target")
      check o.isNone or o.get.result != jrDone
    check requested.len == 0
    check e.h.startUnit("exit.target").get.result == jrDone
    check requested == @[paExit]
  test "cleanup":
    e.h.cleanup()

suite "user control socket":
  let e = newUserEnv()
  e.writeUser("a.service", "[Unit]\nDefaultDependencies=no\n[Service]\nExecStart=/bin/sleep 30\n")
  e.h.reload()
  let ctx = VerbCtx(m: e.h.m, startedUsec: e.h.m.clock.realUsec)
  let srv = startControlServers(ctx)
  let path = e.xdg / "systemd/compat.sock"
  proc call(verb: string; args: JsonNode = nil): SdcReply =
    var fds: array[2, cint]
    discard pipe(fds)
    let pid = fork()
    if pid == 0:
      let cl = connect(path)
      let r = cl.request(verb, args)
      let line = $(%*{"ok": r.ok, "result": (if r.ok: r.result else: newJNull()), "code": ord(r.code), "message": r.message}) & "\n"
      discard write(fds[1], line.cstring, line.len)
      quit(0)
    discard close(fds[1])
    var buf = ""
    var pfd = TPollfd(fd: fds[0], events: POLLIN)
    while true:
      e.h.m.loop.runOnce(20)
      if poll(addr pfd, 1, 0) > 0:
        var b = newString(65536)
        let n = read(fds[0], addr b[0], b.len)
        if n <= 0: break
        buf.add b[0 ..< n]
        if '\n' in buf: break
    var st: cint
    discard waitpid(pid, st, 0)
    discard close(fds[0])
    let j = parseJson(buf)
    SdcReply(ok: j["ok"].getBool, result: j["result"], code: CoreErrorCode(j["code"].getInt), message: j["message"].getStr)
  test "the public socket is 0600 below XDG_RUNTIME_DIR/systemd and reports the user scope":
    var st: Stat
    check stat(path.cstring, st) == 0 and (int(st.st_mode) and 0o777) == 0o600
    check call("hello").result["scope"].getStr == "user"
  test "start and stop through the socket":
    let s = call("job-submit", %*{"unit": "a.service", "type": "start"})
    check s.ok and s.result["state"].getStr == "active"
    check call("job-submit", %*{"unit": "a.service", "type": "stop"}).result["state"].getStr == "inactive"
  when defined(linux):
    test "another user cannot connect":
      if geteuid() == 0:
        let pid = fork()
        if pid == 0:
          discard setgid(Gid(65534)); discard setuid(Uid(65534))
          let fd = connectUnix(path, true)
          quit(if fd < 0: 0 else: 1)
        var st: cint
        discard waitpid(pid, st, 0)
        check WEXITSTATUS(st) == 0
  test "cleanup":
    shutdownServers(srv)
    e.h.cleanup()

suite "xdg autostart end to end":
  ## An autostart entry of the user becomes a unit that really runs its command.
  let e = newUserEnv()
  test "an entry with a phase is started by the core, one without by the session":
    let saved = generatorHook
    defer: generatorHook = saved
    installXdgAutostart()
    # The generator looks `Exec=` up below the fake root, and the unit keeps the
    # unprefixed path the executor then runs: /bin/sh exists for real, so this
    # placeholder is only there for the lookup.
    createDir(e.h.base / "bin")
    writeFile(e.h.base / "bin/sh", "#!/bin/sh\n")
    setFilePermissions(e.h.base / "bin/sh", {fpUserRead, fpUserWrite, fpUserExec})
    let marker = e.h.base / "autostart-ran"
    let autostartDir = e.home / ".config/autostart"
    createDir(autostartDir)
    writeFile(autostartDir / "probe.desktop", "[Desktop Entry]\nType=Application\nName=Probe\n" &
      "Exec=/bin/sh -c \"echo ran > " & marker & "; sleep 30\"\nX-GNOME-Autostart-Phase=Initialization\n")
    writeFile(autostartDir / "session-owned.desktop", "[Desktop Entry]\nType=Application\n" &
      "Exec=/bin/sh -c \"echo no > " & marker & "\"\n")
    e.h.reload()
    let name = "app-probe@autostart.service"
    let u = e.h.m.lookup(name)
    check u != nil and u.loadOk
    check u.def.common.description == "Probe"
    check u.def.common.deps[dkPartOf] == @["graphical-session.target"]
    check u.def.service.typ == stExec and u.def.service.exitType == etCgroup
    # gnome-session still starts entries without a phase itself: no unit
    check e.h.m.lookup("app-session\\x2downed@autostart.service") == nil
    # the target wants it
    let target = e.h.m.lookup("xdg-desktop-autostart.target")
    check target != nil and target.loadOk
    check name in target.def.common.deps[dkWants]
    # the target refuses manual starts (systemd's unit does), so the entry is
    # started by the session: graphical-session.target wants the target
    var refused = false
    try: discard e.h.startUnit("xdg-desktop-autostart.target")
    except CoreError as err: refused = err.msg.contains("dependency only")
    check refused
    check e.h.startUnit("graphical-session.target").get.result == jrDone
    check e.h.pump(proc(): bool = fileExists(marker) and readFile(marker).strip == "ran", 10_000)
    check e.h.waitState(name, "active/running")
    discard e.h.startUnit(name, jtStop)
    check e.h.state(name) == "inactive/dead"
  test "cleanup":
    e.h.cleanup()
