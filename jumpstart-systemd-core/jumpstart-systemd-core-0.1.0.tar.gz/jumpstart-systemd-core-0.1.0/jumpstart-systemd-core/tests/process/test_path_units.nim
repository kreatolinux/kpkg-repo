## Path units: level and edge conditions, MakeDirectory, trigger limit, events while running.
import std/[options, os, posix, strutils, unittest]
import harness
import engine/[types, graph, eventloop]

proc runs(path: string): int =
  if fileExists(path): readFile(path).count('x') else: 0

proc svc(h: Harness; name, body: string) =
  h.writeUnit(name, "[Unit]\nDefaultDependencies=no\n[Service]\nType=oneshot\nExecStart=/bin/sh -c '" & body & "'\n")

proc pathUnit(h: Harness; name, body: string) =
  h.writeUnit(name, "[Unit]\nDefaultDependencies=no\n[Path]\n" & body)

suite "path units":
  test "PathExists triggers when the file appears; level condition is re-checked after the service":
    let h = newHarness()
    let marker = h.base / "m1"
    let watched = h.base / "watched1"
    h.svc("p1.service", "printf x >> " & marker & "; rm -f " & watched)
    h.pathUnit("p1.path", "PathExists=" & watched & "\n")
    h.reload()
    check h.startUnit("p1.path").get.result == jrDone
    check h.state("p1.path") == "active/waiting"
    check runs(marker) == 0
    writeFile(watched, "")
    check h.pump(proc(): bool = runs(marker) == 1, 8000)
    check h.waitState("p1.path", "active/waiting", 5000)
    sleep 300
    h.m.loop.runOnce(20)
    check runs(marker) == 1
    writeFile(watched, "")
    check h.pump(proc(): bool = runs(marker) == 2, 8000)
    check h.startUnit("p1.path", jtStop).get.result == jrDone
    check h.state("p1.path") == "inactive/dead"
    h.cleanup()
  test "PathExists already true at start triggers at once":
    let h = newHarness()
    let marker = h.base / "m2"
    let watched = h.base / "watched2"
    writeFile(watched, "")
    h.svc("p2.service", "printf x >> " & marker & "; rm -f " & watched)
    h.pathUnit("p2.path", "PathExists=" & watched & "\n")
    h.reload()
    check h.startUnit("p2.path").get.result == jrDone
    check h.pump(proc(): bool = runs(marker) == 1, 8000)
    h.cleanup()
  test "PathChanged and PathModified are edge triggered; an existing file does not trigger":
    let h = newHarness()
    let m3 = h.base / "m3"
    let m4 = h.base / "m4"
    let f3 = h.base / "f3"
    let f4 = h.base / "f4"
    writeFile(f3, "a")
    writeFile(f4, "a")
    h.svc("p3.service", "printf x >> " & m3)
    h.svc("p4.service", "printf x >> " & m4)
    h.pathUnit("p3.path", "PathChanged=" & f3 & "\n")
    h.pathUnit("p4.path", "PathModified=" & f4 & "\n")
    h.reload()
    check h.startUnit("p3.path").get.result == jrDone
    check h.startUnit("p4.path").get.result == jrDone
    discard h.pump(proc(): bool = false, 600)
    check runs(m3) == 0 and runs(m4) == 0
    let fd = open(f3.cstring, O_WRONLY or O_APPEND)
    discard write(fd, "b".cstring, 1)
    discard close(fd)                           # close after write: a change
    check h.pump(proc(): bool = runs(m3) == 1, 8000)
    let fd4 = open(f4.cstring, O_WRONLY or O_APPEND)
    discard write(fd4, "b".cstring, 1)          # still open: a modification, not yet a close
    check h.pump(proc(): bool = runs(m4) == 1, 8000)
    discard close(fd4)
    h.cleanup()
  test "DirectoryNotEmpty and PathExistsGlob":
    let h = newHarness()
    let m5 = h.base / "m5"
    let m6 = h.base / "m6"
    let d5 = h.base / "d5"
    let d6 = h.base / "d6"
    createDir(d5)
    createDir(d6)
    h.svc("p5.service", "printf x >> " & m5 & "; rm -f " & d5 & "/*")
    h.svc("p6.service", "printf x >> " & m6 & "; rm -f " & d6 & "/*")
    h.pathUnit("p5.path", "DirectoryNotEmpty=" & d5 & "\n")
    h.pathUnit("p6.path", "PathExistsGlob=" & d6 & "/*.job\n")
    h.reload()
    check h.startUnit("p5.path").get.result == jrDone
    check h.startUnit("p6.path").get.result == jrDone
    writeFile(d5 / "x", "")
    writeFile(d6 / "other.txt", "")
    check h.pump(proc(): bool = runs(m5) == 1, 8000)
    check runs(m6) == 0
    writeFile(d6 / "a.job", "")
    check h.pump(proc(): bool = runs(m6) == 1, 8000)
    h.cleanup()
  test "a path below a missing directory is noticed when the directories appear":
    let h = newHarness()
    let marker = h.base / "m7"
    let deep = h.base / "no/such/dir/file"
    h.svc("p7.service", "printf x >> " & marker & "; rm -f " & deep)
    h.pathUnit("p7.path", "PathExists=" & deep & "\n")
    h.reload()
    check h.startUnit("p7.path").get.result == jrDone
    createDir(h.base / "no/such/dir")
    discard h.pump(proc(): bool = false, 300)
    check runs(marker) == 0
    writeFile(deep, "")
    check h.pump(proc(): bool = runs(marker) == 1, 8000)
    h.cleanup()
  test "MakeDirectory creates the watched directory with DirectoryMode":
    let h = newHarness()
    let d = h.base / "made/sub"
    h.svc("p8.service", "true")
    h.pathUnit("p8.path", "DirectoryNotEmpty=" & d & "\nMakeDirectory=yes\nDirectoryMode=0700\n")
    h.reload()
    check h.startUnit("p8.path").get.result == jrDone
    check dirExists(d)
    var st: Stat
    check stat(d.cstring, st) == 0 and (int(st.st_mode) and 0o777) == 0o700
    h.cleanup()
  test "an event while the service runs triggers once more afterwards":
    let h = newHarness()
    let marker = h.base / "m9"
    let f = h.base / "f9"
    writeFile(f, "")
    h.svc("p9.service", "printf x >> " & marker & "; sleep 1")
    h.pathUnit("p9.path", "PathChanged=" & f & "\n")
    h.reload()
    check h.startUnit("p9.path").get.result == jrDone
    writeFile(f, "1")
    check h.pump(proc(): bool = runs(marker) == 1, 8000)
    check h.state("p9.path") == "active/running"
    writeFile(f, "2")
    discard h.pump(proc(): bool = false, 200)
    writeFile(f, "3")
    check h.pump(proc(): bool = runs(marker) == 2, 10000)
    check h.waitState("p9.service", "inactive/dead", 8000)
    discard h.pump(proc(): bool = false, 400)
    check runs(marker) == 2
    h.cleanup()
  test "the trigger limit fails the path unit":
    let h = newHarness()
    let marker = h.base / "m10"
    let f = h.base / "f10"
    writeFile(f, "")
    h.svc("p10.service", "printf x >> " & marker)
    h.pathUnit("p10.path", "PathExists=" & f & "\nTriggerLimitIntervalSec=30\nTriggerLimitBurst=3\n")
    h.reload()
    check h.startUnit("p10.path").get.result == jrDone
    check h.waitState("p10.path", "failed/failed", 15_000)
    check h.m.lookup("p10.path").result == "trigger-limit-hit"
    check runs(marker) == 3
    h.cleanup()
  test "a missing triggered unit fails the start":
    let h = newHarness()
    h.pathUnit("p11.path", "PathExists=/nonexistent-x\n")
    h.reload()
    discard h.startUnit("p11.path")
    check h.state("p11.path") == "failed/failed"
    h.cleanup()
