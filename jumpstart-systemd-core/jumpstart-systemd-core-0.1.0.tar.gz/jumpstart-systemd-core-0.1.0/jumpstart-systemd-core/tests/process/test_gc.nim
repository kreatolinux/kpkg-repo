## Unit garbage collection with real services: finished and stopped units leave
## memory, running ones and the ones others depend on stay, and a long series of
## transient starts does not grow the manager.
import std/[options, os, tables, unittest]
import harness
import engine/[types, graph, gc, transient]

proc loaded(h: Harness; name: string): bool = h.m.units.hasKey(name)

proc stable(h: Harness; ms = 300) =
  discard h.pump(proc(): bool = false, ms)

suite "garbage collection of services":
  let h = newHarness()
  test "a finished oneshot is collected; a unit that runs is not":
    h.writeUnit("once.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nExecStart=/usr/bin/true\n")
    h.writeUnit("run.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nExecStart=/bin/sleep 60\n")
    h.reload()
    check h.startUnit("once.service").get.result == jrDone
    check h.pump(proc(): bool = not h.loaded("once.service"))
    check h.startUnit("run.service").get.result == jrDone
    h.stable()
    check h.loaded("run.service")
    check h.startUnit("run.service", jtStop).get.result == jrDone
    check h.pump(proc(): bool = not h.loaded("run.service"))
    check h.state("run.service") == "inactive/dead"          # loads again from disk
  test "a failed service stays until reset-failed, unless CollectMode=inactive-or-failed":
    h.writeUnit("bad.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'exit 3'\n")
    h.writeUnit("badc.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\nCollectMode=inactive-or-failed\n[Service]\nType=oneshot\nExecStart=/bin/sh -c 'exit 3'\n")
    h.reload()
    check h.startUnit("bad.service").get.result == jrFailed
    check h.startUnit("badc.service").get.result == jrFailed
    check h.pump(proc(): bool = not h.loaded("badc.service"))
    h.stable()
    check h.loaded("bad.service") and h.m.units["bad.service"].active == asFailed
    let u = h.m.units["bad.service"]
    u.ops.resetFailed(h.m, u)
    check h.pump(proc(): bool = not h.loaded("bad.service"))
  test "a dependency of a running unit stays loaded after it stopped":
    h.writeUnit("dep.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nExecStart=/usr/bin/true\n")
    h.writeUnit("top.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\nWants=dep.service\nAfter=dep.service\n[Service]\nExecStart=/bin/sleep 60\n")
    h.reload()
    check h.startUnit("top.service").get.result == jrDone
    h.stable()
    check h.loaded("top.service") and h.loaded("dep.service")   # dep finished but is wanted by a unit that stays
    check h.startUnit("top.service", jtStop).get.result == jrDone
    check h.pump(proc(): bool = not h.loaded("top.service") and not h.loaded("dep.service"))
  test "daemon-reload with a running unit keeps it; a collected unit is re-read":
    h.writeUnit("keep.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\nDescription=v1\n[Service]\nExecStart=/bin/sleep 60\n")
    h.writeUnit("gone.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\nDescription=v1\n[Service]\nType=oneshot\nExecStart=/usr/bin/true\n")
    h.reload()
    check h.startUnit("keep.service").get.result == jrDone
    check h.startUnit("gone.service").get.result == jrDone
    check h.pump(proc(): bool = not h.loaded("gone.service"))
    h.writeUnit("keep.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\nDescription=v2\n[Service]\nExecStart=/bin/sleep 60\n")
    h.writeUnit("gone.service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\nDescription=v2\n[Service]\nType=oneshot\nExecStart=/usr/bin/true\n")
    h.reload()
    check h.m.units["keep.service"].def.common.description == "v2"
    check h.m.units["keep.service"].active == asActive
    check h.m.lookup("gone.service").def.common.description == "v2"
    discard h.startUnit("keep.service", jtStop)
  test "cleanup":
    h.cleanup()

suite "many starts of unit files":
  let h = newHarness()
  test "finished oneshots leave memory; the collector, not the reload, is what frees them":
    for i in 0 ..< 120:
      h.writeUnit("f" & $i & ".service", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nExecStart=/usr/bin/true\n")
    h.reload()
    var peak = 0
    for i in 0 ..< 120:
      check h.startUnit("f" & $i & ".service").get.result == jrDone
      peak = max(peak, h.m.units.len)
    h.stable(500)
    check peak < 30
    check h.m.units.len < 10
    check h.m.collected >= 100
    check h.m.jobs.len == 0
  test "cleanup":
    h.cleanup()

suite "many transient starts":
  let h = newHarness()
  proc runBatch(n: int; offset: int) =
    for i in offset ..< offset + n:
      var finished = false
      let name = "tr-" & $i & ".service"
      startTransient(h.m, @[TransientUnit(name: name, text:
        "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nStandardOutput=null\nStandardError=null\nExecStart=/usr/bin/true\n")],
        name, collect = true, waitStart = true, waitExit = true, done = proc(r: TransientResult) =
          finished = true)
      doAssert h.pump(proc(): bool = finished)
  test "the unit table, jobs and transient files do not grow":
    runBatch(40, 0)                         # warm up
    GC_fullCollect()
    let base = getOccupiedMem()
    let units0 = h.m.units.len
    runBatch(150, 100)
    h.stable(500)
    GC_fullCollect()
    check h.m.units.len <= units0 + 2
    check h.m.jobs.len == 0
    check h.m.pids.len == 0
    check h.m.aliases.len < 10
    var files = 0
    for f in walkFiles(h.m.roots.sysrun / "transient/*"): inc files
    check files == 0
    check getOccupiedMem() - base < 4 * 1024 * 1024        # 150 more starts, a few MiB of slack at most
  test "cleanup":
    h.cleanup()
