## FDSTORE=1 / FDSTOREREMOVE=1 / FDNAME= with FileDescriptorStoreMax=, and the stored
## descriptors passed back through LISTEN_FDS on the next start.
import std/[os, posix, sequtils, strutils, unittest]
import harness
import unitfile/model
import engine/[types, graph, jobs]
import service/service

const helper = currentSourcePath().parentDir / "helpers/fdstore_service.sh"

proc unitText(svc: string): string = "[Unit]\nDefaultDependencies=no\n[Service]\n" & svc

proc runsOf(path: string): seq[string] =
  if fileExists(path): readFile(path).splitLines.filterIt(it.len > 0) else: @[]

proc newPipe(): (cint, cint) =
  var p: array[2, cint]
  doAssert pipe(p) == 0
  (p[0], p[1])

proc startRunning(h: Harness; name: string): Unit =
  let u = h.m.lookup(name)
  discard submitJob(h.m, u, jtStart, jmReplace, joManual)
  doAssert h.pump(proc(): bool = sd(u).mainPid > 0, 5000)
  doAssert h.waitState(name, "active/running", 5000)
  u

suite "descriptor store":
  test "stored descriptors come back on restart with their names, in order":
    let h = newHarness()
    let marker = h.base / "r1"
    h.writeUnit("f1.service", unitText("FileDescriptorStoreMax=4\nNotifyAccess=all\nRestart=always\nRestartSec=100ms\n" &
      "ExecStart=/bin/sh " & helper & " " & marker & "\n"))
    h.reload()
    let u = h.startRunning("f1.service")
    check h.pump(proc(): bool = runsOf(marker).len == 1, 5000)
    check runsOf(marker)[0] == ":"
    let (r1, w1) = newPipe()
    let (r2, w2) = newPipe()
    handleNotify(h.m, u, sd(u).mainPid, "FDSTORE=1\nFDNAME=alpha", @[w1])
    handleNotify(h.m, u, sd(u).mainPid, "FDSTORE=1", @[w2])
    check storedFds(u).len == 2
    check storedFds(u)[0].name == "alpha" and storedFds(u)[1].name == "stored"
    discard kill(Pid(sd(u).mainPid), SIGKILL)
    check h.pump(proc(): bool = runsOf(marker).len == 2, 10_000)
    check runsOf(marker)[1] == "2:alpha:stored"
    discard close(r1); discard close(r2)
    discard h.startUnit("f1.service", jtStop)
    h.cleanup()
  test "the descriptor handed back is the same open file":
    let h = newHarness()
    let marker = h.base / "r2"
    # the service writes a word to descriptor 3 (the pipe stored before) and idles
    h.writeUnit("f2.service", unitText("FileDescriptorStoreMax=1\nNotifyAccess=all\nRestart=always\nRestartSec=100ms\n" &
      "ExecStart=/bin/sh -c 'if [ -n \"$LISTEN_FDS\" ]; then echo through-the-store >&3; echo ok >> " & marker &
      "; fi; sleep 30'\n"))
    h.reload()
    let u = h.startRunning("f2.service")
    let (r, w) = newPipe()
    handleNotify(h.m, u, sd(u).mainPid, "FDSTORE=1\nFDNAME=pipe", @[w])
    discard kill(Pid(sd(u).mainPid), SIGKILL)
    check h.pump(proc(): bool = runsOf(marker).len == 1, 10_000)
    var buf = newString(64)
    let n = read(r, addr buf[0], buf.len)
    check n > 0 and buf[0 ..< n].strip == "through-the-store"
    discard close(r)
    discard h.startUnit("f2.service", jtStop)
    h.cleanup()
  test "FDSTOREREMOVE removes by name; the limit is enforced; FDSTORE without room is refused":
    let h = newHarness()
    h.writeUnit("f3.service", unitText("FileDescriptorStoreMax=2\nNotifyAccess=main\nExecStart=/bin/sleep 30\n"))
    h.writeUnit("f4.service", unitText("NotifyAccess=all\nExecStart=/bin/sleep 30\n"))
    h.reload()
    let u = h.startRunning("f3.service")
    var fds: seq[(cint, cint)]
    for i in 0 ..< 4: fds.add newPipe()
    handleNotify(h.m, u, sd(u).mainPid, "FDSTORE=1\nFDNAME=a", @[fds[0][1]])
    handleNotify(h.m, u, sd(u).mainPid, "FDSTORE=1\nFDNAME=b", @[fds[1][1]])
    handleNotify(h.m, u, sd(u).mainPid, "FDSTORE=1\nFDNAME=c", @[fds[2][1]])    # over the limit: closed
    check storedFds(u).len == 2
    check read(fds[2][0], addr fds[3][0], 1) == 0                              # write end closed: EOF
    handleNotify(h.m, u, sd(u).mainPid, "FDSTOREREMOVE=1\nFDNAME=a", @[])
    check storedFds(u).len == 1 and storedFds(u)[0].name == "b"
    # a sender that is not allowed stores nothing
    handleNotify(h.m, u, 99999, "FDSTORE=1\nFDNAME=x", @[fds[3][1]])
    check storedFds(u).len == 1
    # the default FileDescriptorStoreMax=0 refuses
    let v = h.startRunning("f4.service")
    let (r5, w5) = newPipe()
    handleNotify(h.m, v, sd(v).mainPid, "FDSTORE=1", @[w5])
    check storedFds(v).len == 0
    var c: char
    check read(r5, addr c, 1) == 0
    discard h.startUnit("f3.service", jtStop)
    discard h.startUnit("f4.service", jtStop)
    check storedFds(u).len == 0                                                  # FileDescriptorStorePreserve=no
    h.cleanup()
  test "FileDescriptorStorePreserve=yes keeps them while inactive; restart keeps them across a restart job only":
    let h = newHarness()
    h.writeUnit("f5.service", unitText("FileDescriptorStoreMax=2\nFileDescriptorStorePreserve=yes\nNotifyAccess=all\nExecStart=/bin/sleep 30\n"))
    h.writeUnit("f6.service", unitText("FileDescriptorStoreMax=2\nFileDescriptorStorePreserve=restart\nNotifyAccess=all\nExecStart=/bin/sleep 30\n"))
    h.reload()
    let a = h.startRunning("f5.service")
    let (_, w1) = newPipe()
    handleNotify(h.m, a, sd(a).mainPid, "FDSTORE=1", @[w1])
    discard h.startUnit("f5.service", jtStop)
    check h.state("f5.service") == "inactive/dead" and storedFds(a).len == 1
    let b = h.startRunning("f6.service")
    let (_, w2) = newPipe()
    handleNotify(h.m, b, sd(b).mainPid, "FDSTORE=1", @[w2])
    discard h.startUnit("f6.service", jtRestart)
    check h.waitState("f6.service", "active/running", 8000)
    check storedFds(b).len == 1
    discard h.startUnit("f6.service", jtStop)
    check storedFds(b).len == 0
    h.cleanup()
