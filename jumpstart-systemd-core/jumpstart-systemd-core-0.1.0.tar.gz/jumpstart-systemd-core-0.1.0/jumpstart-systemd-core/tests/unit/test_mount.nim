import std/[unittest]
import common/roots
import unitfile/[model, index]
import units/mount

suite "mountinfo":
  test "parse with optional fields and octal escapes":
    let text = "36 35 98:0 /mnt1 /mnt/with\\040space rw,noatime master:1 - ext4 /dev/root rw,errors=continue\n" &
               "37 35 0:30 / /proc rw - proc proc rw\n" &
               "garbage line\n"
    let e = parseMountinfo(text)
    check e.len == 2
    check e[0].mountPoint == "/mnt/with space" and e[0].fstype == "ext4" and e[0].source == "/dev/root"
    check e[1].mountPoint == "/proc" and e[1].fstype == "proc"
  test "unit names":
    check mountUnitName("/var/lib") == "var-lib.mount"
    check mountUnitName("/") == "-.mount"

suite "fstab generator":
  let roots = systemRoots()
  test "entries become units wired to local-fs.target":
    let text = "# comment\n/dev/sda1 / ext4 defaults 0 1\nUUID=abcd /boot ext4 defaults,nofail 0 2\n" &
      "/dev/sdb1 /data xfs noauto,x-systemd.automount 0 0\n//srv/share /mnt/net cifs _netdev,rw 0 0\n" &
      "/dev/sdc swap swap sw 0 0\nshort line\n"
    let g = generateFstab(text, roots)
    var byName: seq[string]
    for u in g: byName.add u.name
    check byName == @["boot.mount", "data.automount", "data.mount", "mnt-net.mount"]
    check g[0].def.mount.what == "/dev/disk/by-uuid/abcd"
    check g[0].extraDeps == @[(dkWants, "local-fs.target", "boot.mount")]
    check g[1].def.kind == ukAutomount and g[1].def.mount.where == "/data"
    check g[1].extraDeps[0] == (dkRequires, "local-fs.target", "data.automount")
    check g[2].extraDeps.len == 0                       # noauto / automount: not pulled by the target
    check g[3].extraDeps[0][1] == "remote-fs.target"
    check g[3].def.mount.options == "_netdev,rw"
  test "x-systemd.automount with an idle timeout":
    let g = generateFstab("/dev/sdb1 /data xfs defaults,nofail,x-systemd.automount,x-systemd.idle-timeout=30 0 0\n", roots)
    check g.len == 2 and g[0].name == "data.automount"
    check g[0].def.mount.timeoutIdleSec == 30_000_000
    check g[0].extraDeps[0] == (dkWants, "local-fs.target", "data.automount")
    check g[1].def.mount.options == "defaults"
