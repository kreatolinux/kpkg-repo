import std/[unittest, os]
import unitfile/[model, managerconf, loader]
import helpers

suite "manager conf":
  test "defaults":
    let r = sysRoots("mc1")
    var d: seq[Diag]
    let c = parseManagerConf(r, d)
    check d.len == 0
    check c.defaultTimeoutStartUsec == 90_000_000 and c.defaultTimeoutStopUsec == 90_000_000
    check c.defaultRestartUsec == 100_000 and c.defaultStartLimitIntervalUsec == 10_000_000
    check c.defaultStartLimitBurst == 5 and c.defaultTimeoutAbortUsec == UnsetInt
    check c.defaultStandardOutput.kind == sioJournal and c.defaultStandardError.kind == sioInherit
    check c.defaultOOMPolicy == opStop
    check c.defaultLimits == @[LimitSpec(resource: "NOFILE", soft: 1024, hard: 524288)]
  test "tasks max from pid_max":
    let r = sysRoots("mc2")
    put(r.procfs / "sys/kernel/pid_max", "4194304\n")
    var d: seq[Diag]
    check parseManagerConf(r, d).defaultTasksMax == ResLimit(set: true, value: 629145)
  test "file, drop-ins, ordering and shadowing":
    let r = sysRoots("mc3")
    put(r.etc / "systemd/system.conf", "[Manager]\nDefaultTimeoutStartSec=30s\nDefaultRestartSec=1s\nDefaultEnvironment=A=1 \"B=2 3\"\nDefaultLimitNOFILE=2048\nDefaultLimitCORE=infinity\n")
    put(r.usrLib / "systemd/system.conf.d/10-v.conf", "[Manager]\nDefaultTimeoutStopSec=5\nDefaultStartLimitBurst=7\n")
    put(r.etc / "systemd/system.conf.d/10-v.conf", "[Manager]\nDefaultTimeoutStopSec=6\n")
    put(r.run / "systemd/system.conf.d/20-r.conf", "[Manager]\nDefaultStandardOutput=null\nDefaultOOMPolicy=kill\nDefaultTimeoutAbortSec=3\n")
    var d: seq[Diag]
    let c = parseManagerConf(r, d)
    check d.len == 0
    check c.defaultTimeoutStartUsec == 30_000_000 and c.defaultRestartUsec == 1_000_000
    check c.defaultTimeoutStopUsec == 6_000_000 and c.defaultStartLimitBurst == 90 - 90 + 5
    check c.defaultEnvironment == @["A=1", "B=2 3"]
    check c.defaultLimits[0].soft == 2048 and c.defaultLimits[1] == LimitSpec(resource: "CORE", soft: Infinity, hard: Infinity)
    check c.defaultStandardOutput.kind == sioNull and c.defaultOOMPolicy == opKill
    check c.defaultTimeoutAbortUsec == 3_000_000
  test "ignored and unknown keys warn once, bad values warn":
    let r = sysRoots("mc4")
    put(r.etc / "systemd/system.conf", "[Manager]\nLogLevel=debug\nLogLevel=info\nFoo=1\nDefaultRestartSec=bogus\nDefaultCPUAccounting=yes\n[Other]\nA=1\n")
    var d: seq[Diag]
    let c = parseManagerConf(r, d)
    check c.ignoredKeys == @["LogLevel"]
    check d.len == 4          # LogLevel once, Foo, bad timespan, unknown section [Other]
    check c.defaultRestartUsec == 100_000
  test "loaded units use the manager defaults":
    let r = sysRoots("mc5")
    put(r.etc / "systemd/system.conf", "[Manager]\nDefaultTimeoutStartSec=7s\nDefaultStandardOutput=null\nDefaultTimeoutAbortSec=11s\n")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    var d: seq[Diag]
    let idx = buildIndex(r, @[], d)
    idx.conf = parseManagerConf(r, d)
    let u = loadUnit(idx, "a.service", testEnv())
    check u.service.timeoutStartUsec == 7_000_000 and u.service.exec.standardOutput.kind == sioNull
    check u.service.timeoutAbortUsec == 11_000_000
  test "user scope reads user.conf":
    let r = userRoots("mc6")
    put(r.etc / "systemd/user.conf", "[Manager]\nDefaultRestartSec=2s\n")
    var d: seq[Diag]
    check parseManagerConf(r, d).defaultRestartUsec == 2_000_000
