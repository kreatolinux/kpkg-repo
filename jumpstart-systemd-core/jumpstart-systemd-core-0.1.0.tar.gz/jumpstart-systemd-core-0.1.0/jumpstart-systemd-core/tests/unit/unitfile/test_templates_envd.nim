## Template dependencies (systemd's resolve_template) and environment.d(5).
import std/[unittest, os, tables]
import common/roots
import unitfile/model
import engine/envd
import helpers

suite "dependencies on templates":
  test "an instance's template dependency takes its instance":
    let r = userRoots("tmpldeps")
    put(r.etc / "systemd/user/sess@.target", "[Unit]\nRequires=mgr@.service\nAfter=mgr@.service other.service\nWants=fixed@x.service\n")
    put(r.etc / "systemd/user/mgr@.service", "[Service]\nExecStart=/bin/true\n")
    let d = index(r).load("sess@gnome.target")
    check d.common.deps[dkRequires] == @["mgr@gnome.service"]
    check d.common.deps[dkAfter] == @["mgr@gnome.service", "other.service"]
    check d.common.deps[dkWants] == @["fixed@x.service"]
  test "a plain unit's template dependency takes its prefix":
    let r = userRoots("tmpldeps2")
    put(r.etc / "systemd/user/foo.service", "[Unit]\nWants=helper@.service\n[Service]\nExecStart=/bin/true\n")
    let d = index(r).load("foo.service")
    check d.common.deps[dkWants] == @["helper@foo.service"]
  test "the template itself is left alone":
    let r = userRoots("tmpldeps3")
    put(r.etc / "systemd/user/sess@.target", "[Unit]\nRequires=mgr@.service\n")
    let d = index(r).load("sess@.target")
    check d.common.deps[dkRequires] == @["mgr@.service"]

suite "environment.d":
  test "expansion and quoting":
    var env = {"HOME": "/home/a", "EMPTY": ""}.toTable
    applyEnvironmentFile("""
# comment
A=$HOME/x
B=${HOME}/y
C=${UNSET:-dflt}
D=${HOME:+set}
E=${EMPTY:+never}
F="quoted value"
G='$HOME'
bad-key=1
H = spaced
""", env)
    check env["A"] == "/home/a/x" and env["B"] == "/home/a/y"
    check env["C"] == "dflt" and env["D"] == "set" and env["E"] == ""
    check env["F"] == "quoted value" and env["G"] == "$HOME" and env["H"] == "spaced"
    check not env.hasKey("bad-key")
  test "user directory overrides the system one by file name; files in name order":
    let r = userRoots("envd")
    let top = r.usrLib.parentDir.parentDir
    put(r.usrLib / "environment.d/10-a.conf", "X=lib\nY=lib\n")
    put(top / "etc/environment.d/10-a.conf", "X=etc\n")
    put(r.etc / "environment.d/20-gdm.conf", "DCONF_PROFILE=gdm\nY=${X}-user\n")
    put(r.etc / "environment.d/ignored.txt", "Z=1\n")
    var env = initTable[string, string]()
    loadEnvironmentD(r, env)
    check env["X"] == "etc"                 # /usr/lib/.../10-a.conf is hidden by /etc's
    check env["Y"] == "etc-user"
    check env["DCONF_PROFILE"] == "gdm"
    check not env.hasKey("Z")
  test "system scope ignores environment.d":
    let r = sysRoots("envdsys")
    put(r.usrLib / "environment.d/10-a.conf", "X=lib\n")
    var env = initTable[string, string]()
    loadEnvironmentD(r, env)
    check env.len == 0
