import std/[unittest, os, sequtils]
import unitfile/[model, dropins]
import helpers

suite "drop-ins":
  test "directory names":
    check dropInDirNames("foo-bar@baz.service") == @["service.d", "foo-.service.d", "foo-bar@.service.d", "foo-bar@baz.service.d"]
    check dropInDirNames("foo-bar.service") == @["service.d", "foo-.service.d", "foo-bar.service.d"]
    check dropInDirNames("a-b-c.service") == @["service.d", "a-.service.d", "a-b-.service.d", "a-b-c.service.d"]
    check dropInDirNames("getty@.service") == @["service.d", "getty@.service.d"]
    check dropInDirNames("x.socket") == @["socket.d", "x.socket.d"]
  test "applied in file name order across directories":
    let r = sysRoots("di1")
    libUnit(r, "foo-bar@.service", "[Unit]\nDescription=base\n[Service]\nExecStart=/bin/a %i\nEnvironment=A=0\n")
    put(r.etc / "systemd/system/service.d/50-all.conf", "[Service]\nEnvironment=A=1\n")
    put(r.usrLib / "systemd/system/foo-.service.d/10-pre.conf", "[Service]\nEnvironment=A=2\n")
    put(r.etc / "systemd/system/foo-bar@.service.d/20-t.conf", "[Service]\nEnvironment=A=3\n")
    put(r.etc / "systemd/system/foo-bar@baz.service.d/05-first.conf", "[Service]\nEnvironment=A=4\n[Unit]\nDescription=dropin\n")
    let d = index(r).load("foo-bar@baz.service")
    check d.service.exec.environment == @["A=0", "A=4", "A=2", "A=3", "A=1"]
    check d.common.description == "dropin"
    check d.common.dropInPaths.mapIt(it.extractFilename) == @["05-first.conf", "10-pre.conf", "20-t.conf", "50-all.conf"]
  test "shadowing by file name: higher priority directory wins":
    let r = sysRoots("di2")
    libUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    put(r.usrLib / "systemd/system/a.service.d/o.conf", "[Service]\nEnvironment=X=lib\n")
    put(r.etc / "systemd/system/a.service.d/o.conf", "[Service]\nEnvironment=X=etc\n")
    put(r.sysrun / "system/a.service.d/o.conf", "[Service]\nEnvironment=X=run\n")
    let d = index(r).load("a.service")
    check d.service.exec.environment == @["X=etc"]
    check d.common.dropInPaths == @[r.etc / "systemd/system/a.service.d/o.conf"]
  test "same directory: more specific name wins":
    let r = sysRoots("di3")
    libUnit(r, "a-b.service", "[Service]\nExecStart=/bin/a\n")
    put(r.etc / "systemd/system/service.d/o.conf", "[Service]\nEnvironment=X=type\n")
    put(r.etc / "systemd/system/a-b.service.d/o.conf", "[Service]\nEnvironment=X=name\n")
    put(r.etc / "systemd/system/a-.service.d/o.conf", "[Service]\nEnvironment=X=dash\n")
    check index(r).load("a-b.service").service.exec.environment == @["X=name"]
  test "dev null drop-in masks":
    let r = sysRoots("di4")
    libUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    put(r.usrLib / "systemd/system/a.service.d/o.conf", "[Service]\nEnvironment=X=lib\n")
    createDir r.etc / "systemd/system/a.service.d"
    createSymlink("/dev/null", r.etc / "systemd/system/a.service.d/o.conf")
    let d = index(r).load("a.service")
    check d.service.exec.environment.len == 0 and d.common.dropInPaths.len == 0
  test "only .conf regular files":
    let r = sysRoots("di5")
    libUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    put(r.etc / "systemd/system/a.service.d/a.txt", "[Service]\nEnvironment=X=1\n")
    put(r.etc / "systemd/system/a.service.d/b.conf", "[Service]\nEnvironment=X=2\n")
    createDir r.etc / "systemd/system/a.service.d/c.conf"
    check index(r).load("a.service").service.exec.environment == @["X=2"]
  test "drop-ins for aliases":
    let r = sysRoots("di6")
    libUnit(r, "real.service", "[Service]\nExecStart=/bin/a\n")
    createDir r.etc / "systemd/system"
    createSymlink(r.usrLib / "systemd/system/real.service", r.etc / "systemd/system/alias.service")
    put(r.etc / "systemd/system/alias.service.d/o.conf", "[Service]\nEnvironment=X=alias\n")
    check index(r).load("real.service").service.exec.environment == @["X=alias"]
  test "drop-ins may carry other sections":
    let r = sysRoots("di7")
    libUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    put(r.etc / "systemd/system/a.service.d/o.conf", "[Unit]\nAfter=x.target\n[Install]\nWantedBy=y.target\n")
    let d = index(r).load("a.service")
    check d.common.deps[dkAfter] == @["x.target"] and d.common.install.wantedBy == @["y.target"]
  test "control dirs are drop-in directories too":
    let r = sysRoots("di8")
    libUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    put(r.etc / "systemd/system.control/a.service.d/50-set.conf", "[Service]\nMemoryMax=10M\n")
    check index(r).load("a.service").service.res.memoryMax.value == 10 shl 20
