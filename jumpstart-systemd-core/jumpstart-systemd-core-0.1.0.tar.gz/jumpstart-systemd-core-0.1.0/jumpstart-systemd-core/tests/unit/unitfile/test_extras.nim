import std/[unittest, os, strutils, sequtils, options]
when defined(linux):
  import std/posix
  import unitfile/trust
import common/roots
import unitfile/[model, loader, install, properties]
import helpers

const Svc = "[Service]\nExecStart=-/bin/x\n"

suite "condition grammar":
  test "every kind parses and resets per kind":
    let r = sysRoots("ex-c1")
    var text = "[Unit]\n"
    for k in ConditionKind: text.add "Condition" & $k & "=x\nAssert" & $k & "=!y\n"
    text.add "ConditionPathExists=\nAssertHost=\n"
    etcUnit(r, "a.service", text & "[Service]\nExecStart=-/bin/x\n")
    let d = index(r).load("a.service")
    check d.common.conditions.len == (ConditionKind.high.ord + 1) * 2 - 2
    check d.warnings.len == 0
    check not d.common.conditions.anyIt(it.kind == ckPathExists and not it.isAssert)
    check not d.common.conditions.anyIt(it.kind == ckHost and it.isAssert)
    check d.common.conditions.anyIt(it.kind == ckHost and not it.isAssert)
  test "prefix forms and specifiers":
    let r = sysRoots("ex-c2")
    etcUnit(r, "a@.service", "[Unit]\nConditionPathExists=|!/x/%i\nConditionKernelCommandLine=!quiet\nAssertFirstBoot=yes\n[Service]\nExecStart=-/bin/x\n")
    let c = index(r).load("a@b.service").common.conditions
    check c[0] == Condition(kind: ckPathExists, value: "/x/b", negate: true, trigger: true, file: c[0].file, line: 2)
    check c[1].negate and not c[1].trigger and c[1].value == "quiet"
    check c[2].isAssert and c[2].kind == ckFirstBoot
  test "unknown condition is a warning":
    let r = sysRoots("ex-c3")
    etcUnit(r, "a.service", "[Unit]\nConditionBogus=1\n[Service]\nExecStart=-/bin/x\n")
    check index(r).load("a.service").warnings.len == 1

suite "reload support":
  test "fileChanged":
    let r = sysRoots("ex-f1")
    etcUnit(r, "a.service", Svc)
    let idx = index(r)
    let d = idx.load("a.service")
    check not idx.fileChanged(d)
    sleep 20
    etcUnit(r, "a.service", Svc & "# changed\n")
    check idx.fileChanged(d)
    let d2 = idx.load("a.service")
    check not idx.fileChanged(d2)
    put(r.etc / "systemd/system/a.service.d/x.conf", "[Service]\nNice=1\n")
    check idx.fileChanged(d2)
    let d3 = idx.load("a.service")
    check not idx.fileChanged(d3)
    removeFile r.etc / "systemd/system/a.service.d/x.conf"
    check idx.fileChanged(d3)
    removeFile r.etc / "systemd/system/a.service"
    check idx.fileChanged(d3)
  test "loadAll":
    let r = sysRoots("ex-f2")
    etcUnit(r, "a.service", Svc)
    etcUnit(r, "b.service", Svc & "Bogus=1\n")
    createSymlink("a.service", r.etc / "systemd/system/al.service")
    createSymlink("/dev/null", r.etc / "systemd/system/m.service")
    let all = loadAll(index(r), testEnv())
    check all.mapIt(it.common.id) == @["a.service", "b.service"]

suite "targets and implicit dependencies":
  test "target gets After= its members that have default dependencies":
    let r = sysRoots("ex-t1")
    etcUnit(r, "m.target", "[Unit]\nWants=a.service\nRequires=b.service c.service nonexistent.service\n")
    etcUnit(r, "a.service", Svc)
    etcUnit(r, "b.service", "[Unit]\nDefaultDependencies=no\n" & Svc)
    etcUnit(r, "c.service", Svc)
    put(r.etc / "systemd/system/m.target.wants/d.service", "")
    etcUnit(r, "d.service", Svc)
    let d = index(r).load("m.target")
    check d.common.implicitDeps[dkAfter] == @["a.service", "d.service", "c.service"]
    check d.common.implicitDeps[dkBefore] == @["shutdown.target"] and d.common.implicitDeps[dkConflicts] == @["shutdown.target"]
  test "link farm dependencies":
    let r = sysRoots("ex-t2")
    etcUnit(r, "m.target", "[Unit]\nDescription=m\n")
    etcUnit(r, "a.service", Svc & "[Install]\nWantedBy=m.target\nRequiredBy=m.target\nUpheldBy=m.target\n")
    discard fileOp(r, foEnable, @["a"], FileOpOptions())
    let d = index(r).load("m.target")
    check d.common.deps[dkWants] == @["a.service"] and d.common.deps[dkRequires] == @["a.service"] and d.common.deps[dkUpholds] == @["a.service"]
    check d.common.implicitDeps[dkAfter] == @["a.service"]
  test "farm directories for a unit also feed instances":
    let r = sysRoots("ex-t3")
    etcUnit(r, "m@.target", "[Unit]\nDescription=m\n")
    etcUnit(r, "a.service", Svc)
    put(r.etc / "systemd/system/m@.target.wants/placeholder", "")
    removeFile r.etc / "systemd/system/m@.target.wants/placeholder"
    createSymlink("../a.service", r.etc / "systemd/system/m@.target.wants/a.service")
    check index(r).load("m@x.target").common.deps[dkWants] == @["a.service"]
  test "socket service timer path mount slice rules":
    let r = sysRoots("ex-t4")
    etcUnit(r, "s.socket", "[Socket]\nListenStream=/run/s/sock\nListenFIFO=/run/f\nBindToDevice=eth0\n")
    etcUnit(r, "s.service", "[Service]\nExecStart=-/bin/x\nSockets=s.socket\nWorkingDirectory=/srv/x\nPrivateTmp=yes\nStandardOutput=journal+console\nSlice=my.slice\nPIDFile=/run/s.pid\n")
    etcUnit(r, "t.timer", "[Timer]\nOnCalendar=daily\nUnit=other.service\n")
    etcUnit(r, "p.path", "[Path]\nPathExists=/var/spool/x\n")
    etcUnit(r, "mnt-nas.mount", "[Mount]\nWhat=//nas/share\nWhere=/mnt/nas\nType=cifs\n")
    etcUnit(r, "mnt-loc.mount", "[Mount]\nWhat=/dev/sdb1\nWhere=/mnt/loc\n")
    etcUnit(r, "a-b.slice", "[Slice]\nMemoryMax=1G\n")
    put(r.run / "udev/control", "")
    let idx = index(r)
    let s = idx.load("s.socket")
    check s.common.implicitDeps[dkBefore] == @["sockets.target", "shutdown.target", "s.service"]
    check s.common.implicitDeps[dkTriggers] == @["s.service"]
    check "sysinit.target" in s.common.implicitDeps[dkRequires]
    check s.common.implicitMountsFor == @["/run/s", "/run"]
    check s.common.implicitDeps[dkBindsTo] == @["sys-subsystem-net-devices-eth0.device"]
    let v = idx.load("s.service")
    check "s.socket" in v.common.implicitDeps[dkAfter] and "my.slice" in v.common.implicitDeps[dkRequires]
    check "systemd-journald.socket" in v.common.implicitDeps[dkAfter]
    check v.common.implicitMountsFor.contains("/srv/x") and v.common.implicitMountsFor.contains("/tmp") and v.common.implicitMountsFor.contains("/var/tmp")
    check v.common.implicitMountsFor.contains("/run/s.pid")
    let t = idx.load("t.timer")
    check t.common.implicitDeps[dkTriggers] == @["other.service"]
    check t.common.implicitDeps[dkAfter] == @["sysinit.target", "time-set.target", "time-sync.target"]
    check idx.load("p.path").common.implicitDeps[dkTriggers] == @["p.service"]
    let n = idx.load("mnt-nas.mount")
    check n.common.implicitDeps[dkBefore] == @["remote-fs.target", "umount.target"]
    check n.common.implicitDeps[dkWants] == @["network-online.target"]
    check n.common.implicitDeps[dkAfter] == @["systemd-journald.socket", "network.target", "network-online.target"]
    let l = idx.load("mnt-loc.mount")
    check l.common.implicitDeps[dkBefore] == @["local-fs.target", "umount.target"]
    check l.common.implicitDeps[dkAfter] == @["systemd-journald.socket", "local-fs-pre.target", "dev-sdb1.device"]
    check l.common.implicitDeps[dkBindsTo] == @["dev-sdb1.device"]
    check l.common.implicitMountsFor == @["/mnt"]
    let sl = idx.load("a-b.slice")
    check sl.common.implicitDeps[dkRequires] == @["a.slice"] and sl.slice.res.memoryMax.value == 1 shl 30
  test "root mount has no default dependencies; user scope differs":
    let r = sysRoots("ex-t5")
    etcUnit(r, "-.mount", "[Mount]\nWhat=/dev/sda\nWhere=/\n")
    check index(r).load("-.mount").common.implicitDeps[dkBefore].len == 0
    let u = userRoots("ex-t6")
    put(u.etc / "systemd/user/a.service", Svc & "User=bob\n")
    put(u.etc / "systemd/user/b.socket", "[Socket]\nListenStream=/run/b\n")
    put(u.etc / "systemd/user/m.target", "[Unit]\nDescription=x\n")
    var dd: seq[Diag]
    let idx = buildIndex(u, @[], dd)
    let a = loadUnit(idx, "a.service", testEnv())
    check a.common.implicitDeps[dkAfter].contains("basic.target") and a.warnings.anyIt("ignored in user scope" in it)
    let b = loadUnit(idx, "b.socket", testEnv())
    check "sysinit.target" notin b.common.implicitDeps[dkRequires]
    check loadUnit(idx, "m.target", testEnv()).common.implicitDeps[dkBefore].len == 0
  test "timer values and units":
    let r = sysRoots("ex-t7")
    etcUnit(r, "t.timer", "[Timer]\nOnBootSec=15min\nOnUnitActiveSec=1d\nOnCalendar=*-*-* 03:00\nOnClockChange=yes\nOnTimezoneChange=no\nRandomizedDelaySec=5m\nFixedRandomDelay=yes\nRemainAfterElapse=no\nWakeSystem=yes\n")
    let t = index(r).load("t.timer")
    check t.timer.values.mapIt(it.base) == @[tbBoot, tbUnitActive, tbCalendar, tbClockChange]
    check t.timer.values[0].usec == 900_000_000 and t.timer.values[1].usec == 86_400_000_000'i64
    check t.timer.randomizedDelaySec == 300_000_000 and t.timer.fixedRandomDelay and not t.timer.remainAfterElapse
    check t.warnings.anyIt("WakeSystem" in it)
  test "path and socket directive details":
    let r = sysRoots("ex-t8")
    etcUnit(r, "p.path", "[Path]\nPathExistsGlob=/a/*\nPathChanged=/b\nPathModified=/c\nDirectoryNotEmpty=/d\nMakeDirectory=yes\nDirectoryMode=0700\nPathExists=rel\n")
    let p = index(r).load("p.path")
    check p.path.paths.mapIt(it.kind) == @[pkExistsGlob, pkChanged, pkModified, pkDirectoryNotEmpty]
    check p.path.makeDirectory and p.path.directoryMode == 0o700 and p.warnings.len == 1
    etcUnit(r, "s.socket", "[Socket]\nListenStream=80\nListenDatagram=/run/d\nListenNetlink=route 1\nAccept=yes\nMaxConnections=10\nSocketMode=0600\nKeepAlive=yes\nKeepAliveTimeSec=1min\nReceiveBuffer=8M\nBacklog=128\nBindIPv6Only=ipv6-only\nSymlinks=/dev/a /dev/b\nFileDescriptorName=x\nTimeoutSec=5\nExecStartPre=-/bin/a\nExecStopPost=/bin/b\nExecStopPre=/bin/c\nPassCredentials=yes\n")
    let s = index(r).load("s.socket").socket
    check s.listen.mapIt($it.kind) == @["ListenStream", "ListenDatagram", "ListenNetlink"]
    check s.accept and s.maxConnections == 10 and s.socketMode == 0o600 and s.keepAliveTimeSec == 60_000_000
    check s.receiveBuffer == 8 shl 20 and s.backlog == 128 and s.bindIPv6Only == biIpv6Only
    check s.symlinks == @["/dev/a", "/dev/b"] and s.fileDescriptorName == "x" and s.timeoutSec == 5_000_000
    check s.commands[ekStartPre].len == 1 and s.commands[ekStopPost].len == 1 and s.commands[ekStop][0].path == "/bin/c"
  test "mount, swap, slice, target directives":
    let r = sysRoots("ex-t9")
    etcUnit(r, "mnt-x.mount", "[Mount]\nWhat=/dev/sda1\nWhere=/mnt/x\nType=ext4\nOptions=ro,noatime\nSloppyOptions=yes\nLazyUnmount=yes\nTimeoutSec=0\nDirectoryMode=0700\nPrivateTmp=yes\n")
    let m = index(r).load("mnt-x.mount").mount
    check m.what == "/dev/sda1" and m.where == "/mnt/x" and m.typ == "ext4" and m.options == "ro,noatime"
    check m.sloppyOptions and m.lazyUnmount and m.timeoutSec == Infinity and m.directoryMode == 0o700 and m.exec.privateTmp
    etcUnit(r, "dev-sdb2.swap", "[Swap]\nWhat=/dev/sdb2\nPriority=5\nOptions=discard\n")
    let sw = index(r).load("dev-sdb2.swap").swap
    check sw.what == "/dev/sdb2" and sw.priority == some(5) and sw.options == "discard"

suite "files and properties":
  test "cat":
    let r = sysRoots("ex-p1")
    etcUnit(r, "a.service", Svc)
    put(r.etc / "systemd/system/a.service.d/o.conf", "[Service]\nNice=1")
    let d = index(r).load("a.service")
    check catUnit(d) == "# " & d.common.fragmentPath & "\n" & Svc & "\n# " & d.common.dropInPaths[0] & "\n[Service]\nNice=1\n"
  test "unit file properties":
    let r = sysRoots("ex-p2")
    libUnit(r, "a.service", Svc & "[Install]\nWantedBy=m.target\n")
    put(r.coreRoot / "share/presets/99-default.preset", "disable *\n")
    let idx = index(r)
    let d = idx.load("a.service")
    check idx.fileProperties(d) == @[("UnitFileState", "disabled"), ("UnitFilePreset", "disabled"), ("NeedDaemonReload", "no")]
  test "default target":
    let r = sysRoots("ex-p3")
    check defaultTarget(index(r)) == "multi-user.target"
    libUnit(r, "graphical.target", "[Unit]\nDescription=g\n")
    discard fileOp(r, foSetDefault, @["graphical"], FileOpOptions())
    check defaultTarget(index(r)) == "graphical.target"
  test "property formats":
    let r = sysRoots("ex-p4")
    etcUnit(r, "a.service", "[Service]\nExecStart=-/bin/x a b\nExecStartPre=/bin/p\nEnvironment=\"A=b c\" D=e\nRestartSec=1500ms\nTimeoutStopSec=1h 30min\nRestart=on-abort\nLimitCORE=infinity\nMemoryMax=50%\nCPUQuota=150%\nRuntimeDirectory=a\nRuntimeDirectoryMode=0750\nUMask=0077\nStandardOutput=file:/x\nCPUSchedulingPolicy=rr\nSuccessExitStatus=3 TERM\nDeviceAllow=/dev/null rw\nIODeviceWeight=/dev/sda 300\n")
    let props = definitionProperties(index(r).load("a.service"))
    let m = proc(k: string): string = propertyValue(props, k)
    check m("RestartUSec") == "1s 500ms" and m("TimeoutStopUSec") == "1h 30min" and m("Restart") == "on-abort"
    check m("ExecStart") == "{ path=/bin/x ; argv[]=/bin/x a b ; ignore_errors=yes ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    check m("Environment") == "\"A=b c\" D=e" and m("LimitCORE") == "infinity" and m("LimitCORESoft") == "infinity"
    check m("MemoryMax") == "50%" and m("CPUQuotaPerSecUSec") == "1s 500ms"
    check m("RuntimeDirectoryMode") == "0750" and m("UMask") == "0077" and m("StandardOutput") == "file:/x"
    check m("CPUSchedulingPolicy") == "2" and m("SuccessExitStatus") == "3 TERM"
    check m("DeviceAllow") == "/dev/null rw" and m("IODeviceWeight") == "/dev/sda 300"
    check props.filterIt(it[0] == "ExecStartPre").len == 1

when defined(linux):
  suite "linux ownership":
    test "owner uid other than root or the manager is untrusted":
      if geteuid() != 0:
        skip()
      else:
        let r = sysRoots("ex-l1")
        etcUnit(r, "a.service", Svc)
        let p = r.etc / "systemd/system/a.service"
        check isTrusted(newTrustPolicy(r), r.etc / "systemd/system", p)
        discard chown(p.cstring, 1000, 1000)
        let bad = untrustedReason(newTrustPolicy(r), r.etc / "systemd/system", p)
        check bad.isSome and "owned by uid 1000" in bad.get
        var d: seq[Diag]
        let idx = buildIndex(r, @[], d)
        check idx.load("a.service").common.loadState == lsError
        check d.anyIt(it.code == "E_PERMISSION")
        # user scope trusts its own uid
        var ur = r
        ur.uid = 1000
        check isTrusted(newTrustPolicy(ur), r.etc / "systemd/system", p)
