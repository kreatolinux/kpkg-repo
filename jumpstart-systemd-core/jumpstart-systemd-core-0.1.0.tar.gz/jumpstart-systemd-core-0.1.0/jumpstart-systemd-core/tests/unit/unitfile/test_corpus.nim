## The Appendix B fixture corpus: every file loads, validates, and round-trips
## through `definitionProperties` with the documented results.
import std/[unittest, os, strutils, sequtils, options]
import common/roots
import unitfile/[model, loader, validate, properties, install, specifiers]
import helpers

const FixtureDir = currentSourcePath().parentDir / "fixtures"

proc prop(d: UnitDef; k: string): string = propertyValue(definitionProperties(d), k)

suite "appendix B corpus":
  let (r, idx) = block:
    let r = sysRoots("corpus")
    createDir r.usrLib / "systemd/system"
    for f in walkFiles(FixtureDir / "*"): copyFile(f, r.usrLib / "systemd/system" / f.extractFilename)
    (r, index(r))
  test "every fixture loads and validates":
    for f in walkFiles(FixtureDir / "*"):
      let n = f.extractFilename
      let d = idx.load(n)
      check d.common.loadState == lsLoaded
      let res = validateUnit(r, n, testEnv())
      let errs = res.diagnostics.filterIt(it.severity == sevError and it.code != "E_SETTING" or (it.code == "E_SETTING" and "not found in the executable" notin it.message))
      if errs.len > 0 and n notin ["serial-getty@.service", "postgresql@.service", "getty@.service"]:
        checkpoint n & ": " & errs.mapIt(it.message).join("; ")
      let props = definitionProperties(d)
      check props.len > 20
      check propertyValue(props, "Id") == n
  test "sshd":
    let d = idx.load("sshd.service")
    check d.prop("Type") == "notify" and d.prop("NotifyAccess") == "main"
    check d.prop("KillMode") == "process" and d.prop("RestartUSec") == "42s"
    check d.prop("ExecStart") == "{ path=/usr/sbin/sshd ; argv[]=/usr/sbin/sshd -D $OPTIONS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    check d.prop("TimeoutStartUSec") == "1min 30s"
    check d.prop("Restart") == "on-failure" and d.prop("Documentation") == "man:sshd(8) man:sshd_config(5)"
    check d.prop("Description") == "OpenSSH server daemon"
    check d.prop("Wants") == "sshd-keygen.target"
    check d.prop("After").startsWith("network.target sshd-keygen.target")
    check d.prop("EnvironmentFile") == "-/etc/sysconfig/sshd"
    check d.prop("LimitNOFILE") == "524288" and d.prop("LimitNOFILESoft") == "1024"
    check d.prop("StandardOutput") == "journal" and d.prop("StandardInput") == "null"
    check d.prop("UMask") == "0022" and d.prop("Slice") == "system.slice"
    check d.prop("MemoryMax") == "infinity" and d.prop("CPUWeight") == "[not set]"
  test "getty template":
    let d = idx.load("getty@tty1.service")
    check d.common.description == "Getty on tty1" and d.service.exec.ttyPath == "/dev/tty1"
    check d.service.commands[ekStart][0].flags == {efMinus}
    check d.service.commands[ekStart][0].args[1] == "-p -- \\u"
    check d.service.typ == stIdle and d.common.ignoreOnIsolate
    check d.service.kill.sendSigHup and not d.service.exec.ignoreSIGPIPE
    check d.service.exec.ttyReset and d.service.exec.standardOutput.kind == sioTty
    check d.common.conditions.len == 1 and d.common.conditions[0].value == "/dev/tty0"
    check d.warnings.anyIt("UtmpIdentifier" in it)
    check d.prop("TTYPath") == "/dev/tty1"
    check enablementOf(idx, "getty@.service") == esDisabled
    let res = fileOp(r, foEnable, @["getty@.service"], FileOpOptions())
    check res.ok and symlinkExists(r.etc / "systemd/system/getty.target.wants/getty@tty1.service")
    check resolveName(idx, "getty@tty9.service").isSome
  test "serial getty":
    let d = idx.load("serial-getty@ttyAMA0.service")
    check d.common.deps[dkBindsTo] == @["dev-ttyAMA0.device"]
    check d.common.deps[dkConflicts] == @["getty@ttyAMA0.service"]
  test "cron":
    let d = idx.load("cron.service")
    check not d.service.exec.ignoreSIGPIPE
    check d.warnings.len == 0
  test "nginx":
    let d = idx.load("nginx.service")
    check d.service.typ == stForking and d.service.pidFile == "/run/nginx.pid"
    check d.service.commands[ekStart][0].args == @["-g", "daemon on; master_process on;"]
    check d.service.commands[ekReload][0].args == @["-g", "daemon on; master_process on;", "-s", "reload"]
    check d.service.commands[ekStop][0].flags == {efMinus}
    check d.service.timeoutStopUsec == 5_000_000 and d.service.kill.killMode == kmMixed
  test "postgresql template":
    let d = idx.load("postgresql@14-main.service")
    check d.common.conditions[0].isAssert and d.common.conditions[0].value == "/etc/postgresql/14/main"
    check d.service.pidFile == "/run/postgresql/14-main.pid"
    check d.service.timeoutStartUsec == Infinity and d.service.timeoutStopUsec == Infinity
    check d.service.exec.limits == @[LimitSpec(resource: "NOFILE", soft: 1024, hard: 524288)]
    check d.service.exec.runtimeDirectory == @["postgresql"] and d.service.exec.runtimeDirectoryPreserve == dpYes
    check d.service.exec.user == "postgres" and d.service.exec.oomScoreAdjust == some(-900)
    check d.common.implicitMountsFor.contains(r.run / "postgresql")
  test "NetworkManager":
    let d = idx.load("NetworkManager.service")
    check d.service.typ == stDbus and d.service.busName == "org.freedesktop.NetworkManager"
    check d.warnings.anyIt("Type=dbus" in it) and d.warnings.anyIt("BusName" in it)
    check d.service.exec.capabilityBoundingSet.len == 10
    check d.service.exec.protectSystem == psYes and d.service.exec.protectHome == phReadOnly
    check d.common.install.alias == @["dbus-org.freedesktop.nm-dispatcher.service"]
    check d.prop("Alias") == "dbus-org.freedesktop.nm-dispatcher.service"
    check d.prop("CapabilityBoundingSet").startsWith("cap_net_admin cap_dac_override")
  test "docker":
    let d = idx.load("docker.service")
    check d.common.startLimitIntervalUsec == 60_000_000 and d.common.startLimitBurst == 3
    check d.service.timeoutStartUsec == Infinity
    check d.service.res.delegate.enabled and d.service.res.tasksMax.infinity
    check d.service.exec.limits.len == 3
    check d.common.deps[dkRequires] == @["docker.socket"]
    check d.prop("StartLimitIntervalUSec") == "1min" and d.prop("Delegate") == "yes"
    check d.prop("LimitNPROC") == "infinity"
    let s = idx.load("docker.socket")
    check s.socket.listen == @[ListenSpec(kind: lkStream, address: "/run/docker.sock")]
    check s.socket.socketMode == 0o660 and s.socket.socketGroup == "docker"
    check s.prop("Listen") == "/run/docker.sock (Stream)" and s.prop("SocketMode") == "0660"
    check s.common.implicitDeps[dkBefore].contains("docker.service")
    check s.common.implicitDeps[dkTriggers] == @["docker.service"]
  test "tmpfiles setup":
    let d = idx.load("systemd-tmpfiles-setup.service")
    check d.service.successExit.statuses == {65'u8, 73'u8}
    check d.service.typ == stOneshot and d.service.remainAfterExit
    check d.common.refuseManualStop and not d.common.defaultDependencies
    check d.common.implicitDeps[dkAfter] == @["systemd-journald.socket", "system.slice"]   # no default dependencies
    check d.prop("SuccessExitStatus") == "65 73"
  test "chronyd, rsyslog, containerd, dbus":
    let c = idx.load("chronyd.service")
    check c.service.exec.privateTmp and c.service.exec.protectHome == phYes and c.service.exec.protectSystem == psFull
    check c.common.conditions[0].kind == ckCapability and c.common.deps[dkConflicts].len == 2
    let rs = idx.load("rsyslog.service")
    check rs.service.exec.umask == 0o066 and rs.service.exec.standardOutput.kind == sioNull
    check rs.common.install.alias == @["syslog.service"]
    let co = idx.load("containerd.service")
    check co.service.commands[ekStartPre][0].flags == {efMinus}
    check co.service.exec.limits.len == 3
    let db = idx.load("dbus.service")
    check db.service.typ == stSimple and db.service.exec.oomScoreAdjust == some(-900)
  test "logrotate timer and service":
    let t = idx.load("logrotate.timer")
    check t.timer.values == @[TimerValue(base: tbCalendar, calendar: "daily", raw: "daily")]
    check t.timer.accuracySec == 3_600_000_000 and t.timer.persistent
    check t.prop("AccuracyUSec") == "1h" and t.prop("Persistent") == "yes"
    check t.common.implicitDeps[dkTriggers] == @["logrotate.service"]
    check t.common.implicitDeps[dkAfter].contains("time-sync.target")
    let s = idx.load("logrotate.service")
    check s.service.typ == stOneshot and s.service.exec.nice == some(19)
    check s.service.exec.ioSchedulingClass == "best-effort" and s.service.exec.ioSchedulingPriority == some(7)
    check s.common.conditions[0].kind == ckACPower
    check s.prop("IOSchedulingClass") == "2" and s.prop("Nice") == "19"
  test "user unit":
    var ur = userRoots("corpus-user")
    var e = fixedSystemEnv()
    e.scope = scUser; e.runtimeRoot = "/run/user/1000"
    put(ur.etc / "systemd/user/ssh-agent.service", readFile(FixtureDir / "user/ssh-agent.service"))
    var d: seq[Diag]
    let uidx = buildIndex(ur, @[], d)
    let u = loadUnit(uidx, "ssh-agent.service", e)
    check u.service.exec.environment == @["SSH_AUTH_SOCK=/run/user/1000/ssh-agent.socket"]
    check u.service.commands[ekStart][0].args == @["-D", "-a", "$SSH_AUTH_SOCK"]
    check "sysinit.target" notin u.common.implicitDeps[dkRequires]       # no sysinit.target in user scope
    check u.common.implicitDeps[dkAfter].contains("basic.target") and u.common.slice == "app.slice"
