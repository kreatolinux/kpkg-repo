import std/[unittest, os, options, sequtils, strutils]
import common/roots
import unitfile/[model, apply]
import helpers

suite "loader":
  test "sshd fixture":
    let r = sysRoots("sshd")
    libUnit(r, "sshd.service", Sshd)
    let d = index(r).load("sshd.service")
    check d.common.loadState == lsLoaded
    check d.kind == ukService
    check d.warnings.len == 0
    let s = d.service
    check s.typ == stNotify and s.notifyAccess == naMain
    check s.kill.killMode == kmProcess
    check s.restart == rpOnFailure and s.restartUsec == 42_000_000
    check s.commands[ekStart][0].path == "/usr/sbin/sshd"
    check s.commands[ekStart][0].args == @["-D", "$OPTIONS"]
    check s.commands[ekStartPre].len == 1 and s.commands[ekReload].len == 1
    check s.exec.environmentFile == @["-/etc/sysconfig/sshd"]
    check d.common.description == "OpenSSH server daemon"
    check d.common.documentation == @["man:sshd(8)", "man:sshd_config(5)"]
    check d.common.deps[dkAfter] == @["network.target", "sshd-keygen.target"]
    check d.common.deps[dkWants] == @["sshd-keygen.target"]
    check "sysinit.target" in d.common.implicitDeps[dkRequires]
    check d.common.implicitDeps[dkAfter] == @["systemd-journald.socket", "system.slice", "sysinit.target", "basic.target"]
    check d.common.install.wantedBy == @["multi-user.target"]
    check d.common.fragmentPath == r.usrLib / "systemd/system/sshd.service"
    check d.common.stamps.len == 1
  test "service defaults":
    let r = sysRoots("defaults")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    etcUnit(r, "b.service", "[Service]\nType=oneshot\nExecStart=/bin/b\n")
    etcUnit(r, "c.service", "[Unit]\nDescription=x\n[Service]\nExecStart=\n")
    etcUnit(r, "d.service", "[Service]\nExecStart=/bin/d\nBusName=org.x\n")
    let idx = index(r)
    let a = idx.load("a.service").service
    check a.typ == stSimple and a.restart == rpNo and a.restartUsec == 100_000
    check a.timeoutStartUsec == 90_000_000 and a.timeoutStopUsec == 90_000_000 and a.timeoutAbortUsec == 90_000_000
    check a.notifyAccess == naNone and a.guessMainPid and a.oomPolicy == opStop
    check a.kill.killSignal == 15 and a.kill.sendSigKill and a.kill.finalKillSignal == 9
    check a.exec.umask == -1 and a.exec.ignoreSIGPIPE and a.exec.ttyPath == "/dev/console"
    check a.exec.standardOutput.kind == sioJournal and a.exec.standardInput.kind == sioNull
    check a.exec.runtimeDirectoryMode == 0o755 and a.reloadSignal == 1
    check a.runtimeMaxUsec == Infinity
    check idx.load("b.service").service.typ == stOneshot
    check idx.load("b.service").service.timeoutStartUsec == Infinity
    check idx.load("c.service").service.typ == stOneshot
    check idx.load("d.service").service.typ == stDbus
    check effectiveType(idx.load("d.service").service) == stExec
  test "manager defaults flow in":
    let r = sysRoots("mgrdef")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    let idx = index(r)
    idx.conf.defaultTimeoutStartUsec = 5_000_000
    idx.conf.defaultRestartUsec = 1_000_000
    idx.conf.defaultStartLimitBurst = 9
    let d = idx.load("a.service")
    check d.service.timeoutStartUsec == 5_000_000 and d.service.restartUsec == 1_000_000
    check d.common.startLimitBurst == 9
  test "resets and last wins":
    let r = sysRoots("reset")
    etcUnit(r, "a.service", "[Unit]\nAfter=x.target\nAfter=y.target\nWants=z.service\n[Service]\nExecStart=/bin/a\nRestartSec=5\nEnvironment=A=1\nEnvironment=B=2\nTimeoutSec=10\n")
    put(r.etc / "systemd/system/a.service.d/10-o.conf", "[Unit]\nAfter=\nAfter=q.target\n[Service]\nRestartSec=\nEnvironment=\nEnvironment=C=3\nExecStart=\nExecStart=/bin/b\nTimeoutStopSec=20\n")
    let d = index(r).load("a.service")
    check d.common.deps[dkAfter] == @["q.target"]
    check d.service.restartUsec == 100_000
    check d.service.exec.environment == @["C=3"]
    check d.service.commands[ekStart].len == 1 and d.service.commands[ekStart][0].path == "/bin/b"
    check d.service.timeoutStartUsec == 10_000_000 and d.service.timeoutStopUsec == 20_000_000
    check d.common.dropInPaths.len == 1
  test "dependency names are mangled and validated":
    let r = sysRoots("depnames")
    etcUnit(r, "a.service", "[Unit]\nWants=sshd foo.socket bad/name\n[Service]\nExecStart=/bin/a\n")
    let d = index(r).load("a.service")
    check d.common.deps[dkWants] == @["sshd.service", "foo.socket"]
    check d.warnings.len == 1
  test "conditions":
    let r = sysRoots("cond")
    etcUnit(r, "a.service", "[Unit]\nConditionPathExists=/a\nConditionPathExists=|!/b\nAssertPathExists=/c\nConditionHost=x\nConditionHost=\nConditionUser=|root\n[Service]\nExecStart=/bin/a\n")
    let c = index(r).load("a.service").common.conditions
    check c.len == 4
    check c[0].kind == ckPathExists and c[0].value == "/a" and not c[0].trigger and not c[0].negate
    check c[1].value == "/b" and c[1].trigger and c[1].negate
    check c[2].isAssert
    check c[3].kind == ckUser and c[3].trigger
  test "specifiers in values":
    let r = sysRoots("spec")
    libUnit(r, "getty@.service", "[Unit]\nDescription=Getty on %I\nConditionPathExists=/dev/tty0\n[Service]\nExecStart=-/sbin/agetty -o '-p -- \\\\u' --noclear - $TERM\nTTYPath=/dev/%I\nType=idle\nRestartSec=0\n[Install]\nWantedBy=getty.target\nDefaultInstance=tty1\n")
    let d = index(r).load("getty@tty1.service")
    check d.common.description == "Getty on tty1"
    check d.service.exec.ttyPath == "/dev/tty1"
    check d.common.isTemplate == false and d.common.instance == "tty1"
    let c = d.service.commands[ekStart][0]
    check c.flags == {efMinus} and c.path == "/sbin/agetty"
    check c.args == @["-o", "-p -- \\u", "--noclear", "-", "$TERM"]
    check d.service.typ == stIdle and d.service.restartUsec == 0
    check d.common.install.defaultInstance == "tty1"
    check d.common.templatePath == r.usrLib / "systemd/system/getty@.service"
    let t = index(r).load("getty@.service")
    check t.common.isTemplate and t.common.description == "Getty on "
  test "unknown and ignored directives":
    let r = sysRoots("unk")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\nFooBar=1\nUtmpIdentifier=x\nX-Foo=1\nPrivateTmp=maybe\nRestart=bogus\n")
    let d = index(r).load("a.service")
    check d.common.loadState == lsLoaded
    check d.warnings.len == 4
  test "deprecated directives warn, RemoveIPC does not":
    let r = sysRoots("depr")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\nMemoryLimit=1G\nRemoveIPC=yes\n")
    let d = index(r).load("a.service")
    check d.common.loadState == lsLoaded
    check DeprecatedKeys == @["MemoryLimit", "CPUShares", "StartupCPUShares", "BlockIOWeight",
      "StartupBlockIOWeight", "BlockIODeviceWeight", "BlockIOReadBandwidth", "BlockIOWriteBandwidth",
      "PermissionsStartOnly", "SysVStartPriority", "SysVMode"]
    let dep = d.warnings.filterIt("deprecated" in it)
    check dep.len == 1 and "MemoryLimit" in dep[0]
    check not d.warnings.anyIt("RemoveIPC" in it)
    check d.service.exec.removeIPC
  test "rejected directives make the unit bad-setting":
    let r = sysRoots("rej")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\nRootImage=/x.img\n")
    let d = index(r).load("a.service")
    check d.common.loadState == lsBadSetting
    check d.errors.len == 1 and d.common.diagnostics[0].code == "E_UNSUPPORTED"
  test "not found, masked":
    let r = sysRoots("nf")
    put(r.etc / "systemd/system/m.service", "")
    createSymlink("/dev/null", r.etc / "systemd/system/n.service")
    let idx = index(r)
    check idx.load("zzz.service").common.loadState == lsNotFound
    check idx.load("m.service").common.loadState == lsMasked
    check idx.load("n.service").common.loadState == lsMasked
  test "bad file":
    let r = sysRoots("badfile")
    etcUnit(r, "a.service", "[Service]\nExecStart=\xff\n")
    let d = index(r).load("a.service")
    check d.common.loadState == lsError
  test "exec context directives":
    let r = sysRoots("exec")
    etcUnit(r, "a.service", """
[Service]
ExecStart=/bin/a
User=nobody
Group=nogroup
SupplementaryGroups=a b
WorkingDirectory=-/srv
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=/var/lib/x /var/log/x
RuntimeDirectory=foo bar:baz
RuntimeDirectoryMode=0700
StateDirectory=../bad
LimitNOFILE=1024:524288
LimitCORE=infinity
LimitCPU=10min
CapabilityBoundingSet=CAP_NET_ADMIN CAP_KILL
AmbientCapabilities=CAP_NET_BIND_SERVICE
NoNewPrivileges=yes
Nice=-5
OOMScoreAdjust=-900
UMask=0027
IOSchedulingClass=idle
CPUSchedulingPolicy=fifo
StandardOutput=append:/var/log/x.log
StandardError=inherit
StandardInput=tty
Environment="A=b c" D=e 1BAD=x
UnsetEnvironment=D
TimerSlackNSec=50us
SyslogIdentifier=zz
LogRateLimitIntervalSec=1min
KeyringMode=private
DynamicUser=yes
SystemCallFilter=@system-service ~@privileged
RestrictAddressFamilies=AF_UNIX AF_INET
""")
    let x = index(r).load("a.service").service.exec
    check x.user == "nobody" and x.supplementaryGroups == @["a", "b"]
    check x.workingDirectory == "-/srv" and x.privateTmp and x.protectSystem == psStrict
    check x.protectHome == phReadOnly
    check x.readWritePaths == @["/var/lib/x", "/var/log/x"]
    check x.runtimeDirectory == @["foo", "bar:baz"] and x.runtimeDirectoryMode == 0o700
    check x.stateDirectory.len == 0
    check x.limits.len == 3
    check x.limits[0] == LimitSpec(resource: "NOFILE", soft: 1024, hard: 524288)
    check x.limits[1].soft == Infinity and x.limits[2] == LimitSpec(resource: "CPU", soft: 600, hard: 600)
    check x.capabilityBoundingSet == @["CAP_NET_ADMIN", "CAP_KILL"] and x.noNewPrivileges
    check x.nice == some(-5) and x.oomScoreAdjust == some(-900) and x.umask == 0o027
    check x.ioSchedulingClass == "idle" and x.cpuSchedulingPolicy == some(spFifo)
    check x.standardOutput == StdioSpec(kind: sioAppend, path: "/var/log/x.log")
    check x.standardInput.kind == sioTty and x.standardError.kind == sioInherit
    check x.environment == @["A=b c", "D=e"] and x.unsetEnvironment == @["D"]
    check x.timerSlackNSec == 50_000 and x.syslogIdentifier == "zz"
    check x.logRateLimitIntervalSec == 60_000_000 and x.keyringMode == kmPrivate and x.dynamicUser
    check x.systemCallFilter == @["@system-service", "~@privileged"]
    check x.restrictAddressFamilies == @["AF_UNIX", "AF_INET"]
  test "resource control":
    let r = sysRoots("res")
    etcUnit(r, "a.service", """
[Service]
ExecStart=/bin/a
Slice=foo.slice
Delegate=cpu memory
CPUWeight=idle
CPUQuota=20%
MemoryMax=1G
MemoryHigh=50%
MemorySwapMax=infinity
TasksMax=512
IOWeight=200
IODeviceWeight=/dev/sda 300
IOReadBandwidthMax=/dev/sda 1M
DeviceAllow=/dev/null rwm
DevicePolicy=closed
AllowedCPUs=0-3
""")
    let d = index(r).load("a.service")
    let res = d.service.res
    check res.slice == "foo.slice" and d.common.slice == "foo.slice"
    check res.delegate == DelegateSpec(enabled: true, controllers: @["cpu", "memory"])
    check res.cpuWeight == 0 and res.cpuQuota == 200_000
    check res.memoryMax == ResLimit(set: true, value: 1 shl 30)
    check res.memoryHigh == ResLimit(set: true, percent: true, value: 500)
    check res.memorySwapMax.infinity and res.tasksMax.value == 512
    check res.ioWeight == 200 and res.ioDeviceWeight == @[DeviceValue(path: "/dev/sda", value: 300)]
    check res.ioReadBandwidthMax[0].value == 1 shl 20
    check res.deviceAllow == @[DeviceRule(path: "/dev/null", access: "rwm")] and res.devicePolicy == dvClosed
    check res.allowedCPUs == "0-3"
    check d.common.implicitDeps[dkRequires].contains("foo.slice")
  test "kill and restart directives":
    let r = sysRoots("kill")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\nKillSignal=SIGINT\nSendSIGHUP=yes\nFinalKillSignal=KILL\nWatchdogSignal=SIGABRT\nSuccessExitStatus=1 2 SIGUSR1\nRestartPreventExitStatus=3\nRestartSteps=3\nRestartMaxDelaySec=1min\nRestart=always\nWatchdogSec=30\nFileDescriptorStoreMax=10\nExitType=cgroup\nOOMPolicy=kill\nNotifyAccess=all\nSockets=a.socket\nReloadSignal=SIGUSR2\nTimeoutStartFailureMode=abort\nRemainAfterExit=yes\nPIDFile=/run/a.pid\n")
    let s = index(r).load("a.service").service
    check s.kill.killSignal == 2 and s.kill.sendSigHup and s.kill.finalKillSignal == 9 and s.kill.watchdogSignal == 6
    check 1'u8 in s.successExit.statuses and 10'u8 in s.successExit.signals
    check 3'u8 in s.restartPreventExit.statuses
    check s.restartSteps == 3 and s.restartMaxDelayUsec == 60_000_000 and s.restart == rpAlways
    check s.watchdogUsec == 30_000_000 and s.fdStoreMax == 10 and s.exitType == etCgroup
    check s.oomPolicy == opKill and s.notifyAccess == naAll and s.sockets == @["a.socket"]
    check s.reloadSignal == 12 and s.timeoutStartFailure == fmAbort and s.remainAfterExit
    check s.pidFile == "/run/a.pid"
  test "notify access defaults":
    let r = sysRoots("notify")
    etcUnit(r, "w.service", "[Service]\nExecStart=/bin/a\nWatchdogSec=5\n")
    etcUnit(r, "n.service", "[Service]\nType=notify\nNotifyAccess=none\nExecStart=/bin/a\n")
    let idx = index(r)
    check idx.load("w.service").service.notifyAccess == naMain
    let n = idx.load("n.service")
    check n.service.notifyAccess == naMain and n.warnings.len == 1
