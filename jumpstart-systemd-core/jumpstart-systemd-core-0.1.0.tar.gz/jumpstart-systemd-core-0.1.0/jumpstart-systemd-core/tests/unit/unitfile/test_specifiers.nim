import std/[unittest, options, tables, os]
import common/roots
import unitfile/specifiers

proc x(e: SpecifierEnv; unit, s: string): string = e.expandSpecifiers(unit, s).get("<none>")

suite "specifiers":
  var e = fixedSystemEnv()
  e.osRelease = {"ID": "debian", "VERSION_ID": "12", "BUILD_ID": "b1", "IMAGE_ID": "img", "IMAGE_VERSION": "7", "VARIANT_ID": "srv"}.toTable
  e.prettyHostname = "Pretty"
  let u = "foo-bar@a\\x2db.service"
  test "unit name specifiers":
    check x(e, u, "%n") == u
    check x(e, u, "%N") == "foo-bar@a\\x2db"
    check x(e, u, "%p") == "foo-bar"
    check x(e, u, "%P") == "foo/bar"
    check x(e, u, "%i") == "a\\x2db"
    check x(e, u, "%I") == "a-b"
    check x(e, u, "%f") == "/a-b"
    check x(e, u, "%j") == "bar"
    check x(e, u, "%J") == "bar"
    check x(e, u, "%d") == "/run/credentials/" & u
  test "non instance":
    check x(e, "foo.service", "%n %N %p %i|%f|%j") == "foo.service foo foo |/foo|foo"
    check x(e, "foo.service", "%i") == ""
    check x(e, "foo-bar.service", "%j %J %P") == "bar bar foo/bar"
  test "environment":
    check x(e, u, "%t %S %C %L %E %D %T %V") == "/run /var/lib /var/cache /var/log /etc /usr/share /tmp /var/tmp"
    check x(e, u, "%u %U %g %G %h %s") == "root 0 root 0 /root /bin/sh"
    check x(e, u, "%H %l %m %b %v %a") == "host.example.org host 0123456789abcdef0123456789abcdef fedcba9876543210fedcba9876543210 6.1.0 x86-64"
    check x(e, u, "%o %w %W %B %M %A %q") == "debian 12 srv b1 img 7 Pretty"
  test "percent and errors":
    check x(e, u, "100%%") == "100%"
    check x(e, u, "%z") == "<none>"
    check x(e, u, "abc%") == "<none>"
    check x(e, u, "plain") == "plain"
  test "user scope":
    var ue = e
    ue.scope = scUser; ue.runtimeRoot = "/run/user/1000"; ue.user = "alice"; ue.uid = 1000; ue.home = "/home/alice"
    check x(ue, "a.service", "%t %u %U %h") == "/run/user/1000 alice 1000 /home/alice"
  test "os-release parsing":
    let t = parseOsRelease("# c\nID=debian\nNAME=\"Debian \\\"x\\\"\"\nVERSION_ID='12'\n")
    check t["ID"] == "debian" and t["NAME"] == "Debian \"x\"" and t["VERSION_ID"] == "12"
  test "newSpecifierEnv reads roots":
    let d = getTempDir() / "spec-test"
    removeDir d
    let r = testRoots(d, scSystem)
    writeFile(r.machineId, "abcd\n")
    writeFile(r.osRelease, "ID=zz\n")
    let env = newSpecifierEnv(r)
    check env.machineId == "abcd" and env.osRelease["ID"] == "zz" and env.runtimeRoot == r.run
    removeDir d
