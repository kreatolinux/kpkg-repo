import std/[unittest, os, strutils, sequtils, algorithm, options]
import common/roots
import unitfile/[model, install, loader]
import helpers

const Svc = "[Service]\nExecStart=/bin/x\n"

proc links(r: Roots): seq[string] =
  ## Every symlink below etc and run as `relpath -> target`, sorted.
  let base = r.etc.parentDir
  for d in [r.etc, r.run]:
    if not dirExists(d): continue
    for p in walkDirRec(d, yieldFilter = {pcLinkToFile, pcLinkToDir, pcFile}, followFilter = {pcDir}):
      if symlinkExists(p): result.add p.replace(base, "") & " -> " & expandSymlink(p)
  result.sort

proc op(r: Roots; o: FileOp; names: varargs[string]; opts = FileOpOptions()): FileOpResult =
  fileOp(r, o, @names, opts)

suite "enable":
  test "WantedBy RequiredBy UpheldBy Alias":
    let r = sysRoots("in1")
    libUnit(r, "foo.service", Svc & "[Install]\nWantedBy=multi-user.target\nRequiredBy=a.target\nUpheldBy=b.target\nAlias=bar.service\n")
    let res = op(r, foEnable, "foo")
    check res.ok
    check links(r) == @["/etc/systemd/system/a.target.requires/foo.service -> /usr/lib/systemd/system/foo.service",
      "/etc/systemd/system/b.target.upholds/foo.service -> /usr/lib/systemd/system/foo.service",
      "/etc/systemd/system/bar.service -> /usr/lib/systemd/system/foo.service",
      "/etc/systemd/system/multi-user.target.wants/foo.service -> /usr/lib/systemd/system/foo.service"]
    check res.changes.filterIt(it.kind == fcSymlink).len == 4
    check res.changes.filterIt(it.kind == fcSymlink)[0].link == r.etc / "systemd/system/bar.service"
    check res.changes.filterIt(it.kind == fcSymlink)[0].target == "/usr/lib/systemd/system/foo.service"
    check enablementOf(index(r), "foo.service") == esEnabled
    check dirExists(r.etc / "systemd/system/multi-user.target.wants")
    check getFilePermissions(r.etc / "systemd/system/multi-user.target.wants").contains(fpOthersRead)
  test "idempotent, force, conflict":
    let r = sysRoots("in2")
    libUnit(r, "foo.service", Svc & "[Install]\nWantedBy=m.target\n")
    check op(r, foEnable, "foo.service").changes.len > 0
    let again = op(r, foEnable, "foo.service")
    check again.ok and again.changes.len == 0
    let link = r.etc / "systemd/system/m.target.wants/foo.service"
    removeFile link
    createSymlink("/somewhere/else.service", link)
    let bad = op(r, foEnable, "foo.service")
    check not bad.ok and "already exists and is a symlink" in bad.error
    check expandSymlink(link) == "/somewhere/else.service"
    let forced = op(r, foEnable, "foo.service", opts = FileOpOptions(force: true))
    check forced.ok and expandSymlink(link) == "/usr/lib/systemd/system/foo.service"
  test "unit not found, masked, static":
    let r = sysRoots("in3")
    libUnit(r, "s.service", Svc)
    libUnit(r, "m.service", Svc & "[Install]\nWantedBy=x.target\n")
    createDir r.etc / "systemd/system"
    createSymlink("/dev/null", r.etc / "systemd/system/m.service")
    check not op(r, foEnable, "zzz").ok
    let m = op(r, foEnable, "m.service")
    check not m.ok and "masked" in m.error
    let s = op(r, foEnable, "s.service")
    check s.ok and s.changes.len == 0 and s.diags.len == 1 and s.diags[0].code == "W_NO_INSTALL"
  test "Also with cycle":
    let r = sysRoots("in4")
    libUnit(r, "a.service", Svc & "[Install]\nWantedBy=x.target\nAlso=b.service\n")
    libUnit(r, "b.service", Svc & "[Install]\nWantedBy=y.target\nAlso=a.service c.socket\n")
    libUnit(r, "c.socket", "[Socket]\nListenStream=/x\n[Install]\nWantedBy=sockets.target\n")
    check op(r, foEnable, "a.service").ok
    check links(r).len == 3
    check "/etc/systemd/system/sockets.target.wants/c.socket -> /usr/lib/systemd/system/c.socket" in links(r)
  test "DefaultInstance and instances":
    let r = sysRoots("in5")
    libUnit(r, "getty@.service", Svc & "[Install]\nWantedBy=getty.target\nDefaultInstance=tty1\n")
    libUnit(r, "plain@.service", Svc & "[Install]\nWantedBy=x.target\n")
    check op(r, foEnable, "getty@.service").ok
    check links(r) == @["/etc/systemd/system/getty.target.wants/getty@tty1.service -> /usr/lib/systemd/system/getty@.service"]
    check op(r, foEnable, "getty@tty2.service").ok
    check links(r).len == 2
    let miss = op(r, foEnable, "plain@.service")
    check not miss.ok and "instance name missing" in miss.error
    check op(r, foEnable, "plain@x.service").ok
  test "specifiers in install values":
    let r = sysRoots("in6")
    libUnit(r, "w@.service", Svc & "[Install]\nWantedBy=w-%i.target\nAlias=wa-%i.service\n")
    check op(r, foEnable, "w@a.service").ok
    check links(r) == @["/etc/systemd/system/w-a.target.wants/w@a.service -> /usr/lib/systemd/system/w@.service",
                        "/etc/systemd/system/wa-a.service -> /usr/lib/systemd/system/w@.service"]
  test "--runtime":
    let r = sysRoots("in7")
    libUnit(r, "foo.service", Svc & "[Install]\nWantedBy=m.target\n")
    check op(r, foEnable, "foo", opts = FileOpOptions(runtime: true)).ok
    check links(r) == @["/run/systemd/system/m.target.wants/foo.service -> /usr/lib/systemd/system/foo.service"]
    check enablementOf(index(r), "foo.service") == esEnabledRuntime
  test "user scope and --global":
    let r = userRoots("in8")
    put(r.usrLib / "systemd/user/foo.service", Svc & "[Install]\nWantedBy=default.target\n")
    check op(r, foEnable, "foo").ok
    check symlinkExists(r.home / ".config/systemd/user/default.target.wants/foo.service")
    check expandSymlink(r.home / ".config/systemd/user/default.target.wants/foo.service") == "/usr/lib/systemd/user/foo.service"
    check op(r, foEnable, "foo", opts = FileOpOptions(global: true)).ok
    check symlinkExists(r.usrLib.parentDir.parentDir / "etc/systemd/user/default.target.wants/foo.service")
  test "unit file by path":
    let r = sysRoots("in9")
    let f = "/opt/x.service"
    put(r.etc.parentDir / "opt/x.service", Svc & "[Install]\nWantedBy=m.target\n")
    check op(r, foEnable, f).ok
    check links(r) == @["/etc/systemd/system/m.target.wants/x.service -> /opt/x.service",
                        "/etc/systemd/system/x.service -> /opt/x.service"]

suite "disable and states":
  test "disable removes links, aliases, Also and empty directories":
    let r = sysRoots("di1")
    libUnit(r, "a.service", Svc & "[Install]\nWantedBy=x.target\nAlias=aa.service\nAlso=b.service\n")
    libUnit(r, "b.service", Svc & "[Install]\nWantedBy=y.target\n")
    discard op(r, foEnable, "a")
    check links(r).len == 3
    let res = op(r, foDisable, "a.service")
    check res.ok and links(r).len == 0
    check not dirExists(r.etc / "systemd/system/x.target.wants")
    check dirExists(r.etc / "systemd/system")
    check res.changes.filterIt(it.kind == fcUnlink).len == 3
    check res.changes.filterIt(it.kind == fcRmdir).len == 2
  test "disable in runtime directory too":
    let r = sysRoots("di2")
    libUnit(r, "a.service", Svc & "[Install]\nWantedBy=x.target\n")
    discard op(r, foEnable, "a", opts = FileOpOptions(runtime: true))
    discard op(r, foEnable, "a")
    check links(r).len == 2
    check op(r, foDisable, "a").ok and links(r).len == 0
  test "vendor links stay and warn":
    let r = sysRoots("di3")
    libUnit(r, "a.service", Svc & "[Install]\nWantedBy=x.target\n")
    createDir r.usrLib / "systemd/system/x.target.wants"
    createSymlink("../a.service", r.usrLib / "systemd/system/x.target.wants/a.service")
    let idx = index(r)
    check enablementOf(idx, "a.service") == esEnabled
    let res = op(r, foDisable, "a")
    check res.ok and symlinkExists(r.usrLib / "systemd/system/x.target.wants/a.service")
    check res.diags.len == 1 and res.diags[0].message == "Unit a.service is enabled by a vendor link; use mask to prevent it from starting."
  test "disable of a removed unit cleans dangling links; unknown unit errors":
    let r = sysRoots("di4")
    createDir r.etc / "systemd/system/x.target.wants"
    createSymlink("/usr/lib/systemd/system/gone.service", r.etc / "systemd/system/x.target.wants/gone.service")
    check op(r, foDisable, "gone").ok
    check links(r).len == 0
    check not op(r, foDisable, "never").ok
  test "reenable":
    let r = sysRoots("di5")
    libUnit(r, "a.service", Svc & "[Install]\nWantedBy=x.target\n")
    discard op(r, foEnable, "a")
    removeFile r.etc / "systemd/system/x.target.wants/a.service"
    createSymlink("/stale/a.service", r.etc / "systemd/system/x.target.wants/a.service")
    check op(r, foReenable, "a").ok
    check links(r) == @["/etc/systemd/system/x.target.wants/a.service -> /usr/lib/systemd/system/a.service"]
  test "mask and unmask":
    let r = sysRoots("di6")
    libUnit(r, "a.service", Svc)
    check op(r, foMask, "a").ok
    check expandSymlink(r.etc / "systemd/system/a.service") == "/dev/null"
    check op(r, foMask, "a").changes.len == 0
    check enablementOf(index(r), "a.service") == esMasked
    check not op(r, foEnable, "a").ok
    check op(r, foUnmask, "a").ok and not symlinkExists(r.etc / "systemd/system/a.service")
    check op(r, foMask, "b", opts = FileOpOptions(runtime: true)).ok
    check enablementOf(index(r), "b.service") == esMaskedRuntime
    check op(r, foUnmask, "b").ok and not symlinkExists(r.sysrun / "system/b.service")
    etcUnit(r, "c.service", Svc)
    check not op(r, foMask, "c").ok
    check op(r, foMask, "c", opts = FileOpOptions(force: true)).ok
    check expandSymlink(r.etc / "systemd/system/c.service") == "/dev/null"
  test "link":
    let r = sysRoots("di7")
    let base = r.etc.parentDir
    put(base / "opt/x.service", Svc & "[Install]\nWantedBy=m.target\n")
    check not op(r, foLink, "opt/x.service").ok
    check not op(r, foLink, "/opt/missing.service").ok
    check op(r, foLink, "/opt/x.service").ok
    check links(r) == @["/etc/systemd/system/x.service -> /opt/x.service"]
    let idx = index(r)
    check enablementOf(idx, "x.service") == esLinked
    check op(r, foEnable, "x.service").ok
    check links(r).len == 2
    check expandSymlink(r.etc / "systemd/system/m.target.wants/x.service") == "/etc/systemd/system/x.service"
    check enablementOf(index(r), "x.service") == esEnabled
  test "revert":
    let r = sysRoots("di8")
    libUnit(r, "a.service", Svc)
    etcUnit(r, "a.service", Svc & "# override\n")
    put(r.etc / "systemd/system/a.service.d/o.conf", "[Service]\nNice=1\n")
    put(r.sysrun / "system/a.service.d/o.conf", "[Service]\nNice=2\n")
    put(r.etc / "systemd/system.control/a.service.d/50.conf", "[Service]\nNice=3\n")
    check op(r, foRevert, "a").ok
    check not fileExists(r.etc / "systemd/system/a.service")
    check not dirExists(r.etc / "systemd/system/a.service.d")
    check not dirExists(r.sysrun / "system/a.service.d")
    check not dirExists(r.etc / "systemd/system.control/a.service.d")
    check fileExists(r.usrLib / "systemd/system/a.service")
  test "add-wants and add-requires":
    let r = sysRoots("di9")
    libUnit(r, "a.service", Svc)
    check op(r, foAddWants, "a.service", opts = FileOpOptions(target: "m.target")).ok
    check op(r, foAddRequires, "a.service", opts = FileOpOptions(target: "m.target")).ok
    check links(r) == @["/etc/systemd/system/m.target.requires/a.service -> /usr/lib/systemd/system/a.service",
                        "/etc/systemd/system/m.target.wants/a.service -> /usr/lib/systemd/system/a.service"]
    check enablementOf(index(r), "a.service") == esEnabled
  test "set-default":
    let r = sysRoots("di10")
    libUnit(r, "graphical.target", "[Unit]\nDescription=g\n")
    libUnit(r, "multi-user.target", "[Unit]\nDescription=m\n")
    check not op(r, foSetDefault, "rescue").ok
    check op(r, foSetDefault, "graphical").ok
    check expandSymlink(r.etc / "systemd/system/default.target") == "/usr/lib/systemd/system/graphical.target"
    check op(r, foSetDefault, "multi-user.target").ok
    check expandSymlink(r.etc / "systemd/system/default.target") == "/usr/lib/systemd/system/multi-user.target"
    check resolveName(index(r), "default.target").get.id == "multi-user.target"
  test "states of 6.9":
    let r = sysRoots("di11")
    libUnit(r, "dis.service", Svc & "[Install]\nWantedBy=x.target\n")
    libUnit(r, "sta.service", Svc)
    libUnit(r, "sta2.service", Svc & "[Install]\n")
    libUnit(r, "ind.service", Svc & "[Install]\nAlso=dis.service\n")
    put(r.sysrun / "transient/tr.service", Svc)
    put(r.sysrun / "generator/gen.service", Svc)
    libUnit(r, "ena.service", Svc & "[Install]\nWantedBy=x.target\n")
    discard op(r, foEnable, "ena")
    let idx = index(r)
    check enablementOf(idx, "dis.service") == esDisabled
    check enablementOf(idx, "sta.service") == esStatic
    check enablementOf(idx, "sta2.service") == esStatic
    check enablementOf(idx, "ind.service") == esIndirect
    check enablementOf(idx, "ena.service") == esEnabled
    check enablementOf(idx, "tr.service") == esTransient
    check enablementOf(idx, "gen.service") == esGenerated
    check enablementOf(idx, "nope.service") == esNotFound
  test "is-enabled via fileOp":
    let r = sysRoots("di12")
    libUnit(r, "dis.service", Svc & "[Install]\nWantedBy=x.target\n")
    let res = op(r, foIsEnabled, "dis")
    check res.states == @[("dis.service", esDisabled)]
