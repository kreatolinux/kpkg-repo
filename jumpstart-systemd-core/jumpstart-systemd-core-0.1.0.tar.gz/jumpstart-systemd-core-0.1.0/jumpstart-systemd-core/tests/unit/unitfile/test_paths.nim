import std/[unittest, os, options, strutils, sequtils]
import common/roots
import unitfile/[model, paths, trust, loader]
import helpers

proc paths(r: Roots): seq[string] =
  for d in unitSearchPath(r): result.add d.path

suite "search paths":
  test "system list order":
    let r = sysRoots("sp1")
    let p = paths(r).mapIt(it.replace(r.etc.parentDir, "").replace("//", "/"))
    check p[0] == "/etc/systemd/system.control"
    check p[1] == "/run/systemd/system.control"
    check p[2] == "/run/systemd/transient"
    check p[3] == "/run/systemd/generator.early"
    check p[4] == "/etc/systemd/system"
    check p[5] == "/run/systemd/system"
    check p[6] == "/run/systemd/generator"
    check p[7] == "/usr/local/lib/systemd/system"
    check p[8] == "/usr/lib/systemd/system"
    check p[^2] == "/run/systemd/generator.late"
    check p[^1].endsWith("core/share/units") and p.len == 11
  test "non merged usr adds /lib":
    let r = sysRoots("sp2")
    createDir(r.etc.parentDir / "lib")
    check paths(r).len == 12
    check (r.etc.parentDir / "lib/systemd/system") in paths(r)
  test "merged usr symlink skips /lib":
    let r = sysRoots("sp3")
    createSymlink("usr/lib", r.etc.parentDir / "lib")
    check paths(r).len == 11
  test "user list":
    let r = userRoots("sp4")
    let p = paths(r)
    check p.len == 17
    check p[0] == r.home / ".config/systemd/user.control"
    check p[4] == r.home / ".config/systemd/user"
    check p[5].endsWith("etc/xdg/systemd/user") and p[6].endsWith("etc/systemd/user")
    check p[7] == r.runtime / "systemd/user"
    check p[10] == r.home / ".local/share/systemd/user"
    check p[16].endsWith("share/units-user")
  test "config dirs":
    let r = sysRoots("sp5")
    check configDir(r) == r.etc / "systemd/system"
    check configDir(r, runtime = true) == r.sysrun / "system"
    let u = userRoots("sp6")
    check configDir(u) == u.home / ".config/systemd/user"
    check configDir(u, global = true).endsWith("etc/systemd/user")
    check configDir(u, runtime = true, global = true).endsWith("run/systemd/user")
  test "first directory wins":
    let r = sysRoots("sp7")
    libUnit(r, "a.service", "[Unit]\nDescription=lib\n[Service]\nExecStart=/bin/a\n")
    etcUnit(r, "a.service", "[Unit]\nDescription=etc\n[Service]\nExecStart=/bin/a\n")
    put(r.sysrun / "system/a.service", "[Unit]\nDescription=run\n")
    check index(r).load("a.service").common.description == "etc"
  test "masks":
    let r = sysRoots("sp8")
    libUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    createDir r.etc / "systemd/system"
    createSymlink("/dev/null", r.etc / "systemd/system/a.service")
    libUnit(r, "b.service", "[Service]\nExecStart=/bin/a\n")
    put(r.etc / "systemd/system/b.service", "")
    libUnit(r, "c.service", "[Service]\nExecStart=/bin/a\n")
    createDir r.sysrun / "system"
    createSymlink("/dev/null", r.sysrun / "system/c.service")     # /run mask below /etc: shadowed by nothing, wins over /usr
    libUnit(r, "d.service", "[Service]\nExecStart=/bin/a\n")
    createSymlink("/dev/null", r.sysrun / "system/d.service")
    etcUnit(r, "d.service", "[Service]\nExecStart=/bin/d\n")
    let idx = index(r)
    check idx.load("a.service").common.loadState == lsMasked
    check idx.load("b.service").common.loadState == lsMasked
    check idx.load("c.service").common.loadState == lsMasked
    check idx.load("d.service").common.loadState == lsLoaded
    check enablementOf(idx, "a.service") == esMasked
    check enablementOf(idx, "c.service") == esMaskedRuntime
    check enablementOf(idx, "d.service") == esStatic
  test "symlink chains":
    let r = sysRoots("sp9")
    libUnit(r, "real.service", "[Service]\nExecStart=/bin/a\n")
    createDir r.etc / "systemd/system"
    createSymlink(r.usrLib / "systemd/system/real.service", r.etc / "systemd/system/same.service")
    let idx = index(r)
    check idx.load("real.service").common.loadState == lsLoaded

suite "trust":
  test "mode and owner":
    let r = sysRoots("tr1")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    let p = r.etc / "systemd/system/a.service"
    let sd = r.etc / "systemd/system"
    let pol = newTrustPolicy(r)
    check isTrusted(pol, sd, p)
    setFilePermissions(p, {fpUserRead, fpUserWrite, fpGroupWrite, fpGroupRead})
    let bad = untrustedReason(pol, sd, p)
    check bad.isSome and "mode 0660" in bad.get
    var d: seq[Diag]
    let idx = buildIndex(r, @[], d)
    check idx.load("a.service").common.loadState == lsError
    check d.len >= 1 and d[0].code == "E_PERMISSION" and d[0].file == p
    setFilePermissions(p, {fpUserRead, fpUserWrite, fpGroupRead, fpOthersRead})
    setFilePermissions(sd, {fpUserRead, fpUserWrite, fpUserExec, fpOthersWrite, fpOthersRead, fpOthersExec})
    check not isTrusted(pol, sd, p)
  test "untrusted owner by injected stat":
    let r = sysRoots("tr2")
    etcUnit(r, "a.service", "[Service]\nExecStart=/bin/a\n")
    var pol = newTrustPolicy(r)
    pol.stat = proc(path: string; follow: bool): Option[StatInfo] =
      var s = realStat(path, follow)
      if s.isSome and path.endsWith("etc/systemd/system/a.service"): s.get.uid = 1000
      s
    let bad = untrustedReason(pol, r.etc / "systemd/system", r.etc / "systemd/system/a.service")
    check bad.isSome and bad.get == "ignored: owned by uid 1000, mode 0644"
    var d: seq[Diag]
    let idx = buildIndex(r, @[], d, pol)
    check idx.load("a.service").common.loadState == lsError
    # a lower-priority trusted copy wins over an ignored one
    libUnit(r, "a.service", "[Unit]\nDescription=lib\n[Service]\nExecStart=/bin/a\n")
    let idx2 = buildIndex(r, @[], d, pol)
    check idx2.load("a.service").common.description == "lib"
  test "dev null is trusted":
    let r = sysRoots("tr3")
    createDir r.etc / "systemd/system"
    createSymlink("/dev/null", r.etc / "systemd/system/a.service")
    check isTrusted(newTrustPolicy(r), r.etc / "systemd/system", r.etc / "systemd/system/a.service")
