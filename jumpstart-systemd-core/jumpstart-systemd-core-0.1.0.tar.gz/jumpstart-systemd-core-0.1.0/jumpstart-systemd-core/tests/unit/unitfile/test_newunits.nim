## Path, swap, automount and the extra timer settings as the loader sees them.
import std/[unittest, options, sequtils]
import unitfile/model
import helpers

suite "path units":
  test "every directive":
    let r = sysRoots("np1")
    etcUnit(r, "w.path", "[Path]\nPathExists=/a\nPathExistsGlob=/b/*.x\nPathChanged=/c\nPathModified=/d\n" &
      "DirectoryNotEmpty=/e\nMakeDirectory=yes\nDirectoryMode=0700\nTriggerLimitIntervalSec=10\nTriggerLimitBurst=5\nUnit=other.service\n")
    let d = index(r).load("w.path")
    check d.common.loadState == lsLoaded
    let p = d.path
    check p.paths.mapIt($it.kind) == @["PathExists", "PathExistsGlob", "PathChanged", "PathModified", "DirectoryNotEmpty"]
    check p.paths[1].path == "/b/*.x"
    check p.makeDirectory and p.directoryMode == 0o700
    check p.triggerLimitIntervalSec == 10_000_000 and p.triggerLimitBurst == 5
    check p.unit == "other.service"
    check "other.service" in d.common.implicitDeps[dkTriggers]
    check d.warnings.len == 0
  test "defaults":
    let r = sysRoots("np2")
    etcUnit(r, "w.path", "[Path]\nPathExists=/a\n")
    let p = index(r).load("w.path").path
    check p.directoryMode == 0o755 and p.triggerLimitBurst == 200 and p.triggerLimitIntervalSec == 2_000_000

suite "swap units":
  test "settings":
    let r = sysRoots("ns1")
    etcUnit(r, "dev-sdb2.swap", "[Swap]\nWhat=/dev/sdb2\nPriority=10\nOptions=discard=once,nofail\nTimeoutSec=30\n")
    let d = index(r).load("dev-sdb2.swap")
    check d.common.loadState == lsLoaded
    check d.swap.what == "/dev/sdb2" and d.swap.priority == some(10)
    check d.swap.options == "discard=once,nofail" and d.swap.timeoutSec == 30_000_000
    check "swap.target" in d.common.implicitDeps[dkBefore]

suite "automount units":
  test "load and implicit edges":
    let r = sysRoots("na1")
    etcUnit(r, "mnt-x.automount", "[Automount]\nWhere=/mnt/x\nDirectoryMode=0711\nTimeoutIdleSec=2min\nExtraOptions=foo\n")
    let d = index(r).load("mnt-x.automount")
    check d.common.loadState == lsLoaded and d.kind == ukAutomount
    check d.mount.where == "/mnt/x" and d.mount.directoryMode == 0o711
    check d.mount.timeoutIdleSec == 120_000_000 and d.mount.extraOptions == "foo"
    check "mnt-x.mount" in d.common.implicitDeps[dkBefore]
    check "mnt-x.mount" in d.common.implicitDeps[dkTriggers]
    check "umount.target" in d.common.implicitDeps[dkConflicts]

suite "timer settings":
  test "event values and accuracy":
    let r = sysRoots("nt1")
    etcUnit(r, "t.timer", "[Timer]\nOnClockChange=yes\nOnTimezoneChange=yes\nAccuracySec=5s\n")
    let d = index(r).load("t.timer")
    check d.common.loadState == lsLoaded
    check d.timer.values.mapIt(it.base) == @[tbClockChange, tbTimezoneChange]
    check d.timer.accuracySec == 5_000_000
    etcUnit(r, "u.timer", "[Timer]\nOnClockChange=no\nOnActiveSec=1\n")
    check index(r).load("u.timer").timer.values.len == 1
