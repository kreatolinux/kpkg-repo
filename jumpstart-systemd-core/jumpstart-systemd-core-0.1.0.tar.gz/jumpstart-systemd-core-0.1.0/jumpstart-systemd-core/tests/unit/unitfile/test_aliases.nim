import std/[unittest, os, options]
import unitfile/[model, loader]
import helpers

suite "aliases, links, instances":
  test "alias symlink":
    let r = sysRoots("al1")
    libUnit(r, "b.service", "[Service]\nExecStart=/bin/b\n[Install]\nAlias=a.service\n")
    createDir r.etc / "systemd/system"
    createSymlink(r.usrLib / "systemd/system/b.service", r.etc / "systemd/system/a.service")
    let idx = index(r)
    let res = resolveName(idx, "a.service").get
    check res.id == "b.service" and res.isAlias and "a.service" in res.names and "b.service" in res.names
    let b = resolveName(idx, "b.service").get
    check not b.isAlias and b.names == @["b.service", "a.service"]
    check idx.load("a.service").common.id == "b.service"
    check enablementOf(idx, "b.service") == esEnabled        # alias link in a persistent dir
  test "relative alias target":
    let r = sysRoots("al2")
    etcUnit(r, "b.service", "[Service]\nExecStart=/bin/b\n")
    createSymlink("b.service", r.etc / "systemd/system/a.service")
    check resolveName(index(r), "a.service").get.id == "b.service"
  test "alias through a merged-/usr symlinked directory (/lib -> usr/lib)":
    # Debian: /etc/systemd/system/display-manager.service -> /lib/systemd/system/gdm3.service,
    # itself a link to gdm.service
    let r = sysRoots("al2m")
    libUnit(r, "gdm.service", "[Service]\nExecStart=/bin/b\n")
    createSymlink("gdm.service", r.usrLib / "systemd/system/gdm3.service")
    let root = r.usrLib.parentDir.parentDir
    createSymlink("usr/lib", root / "lib")
    createDir r.etc / "systemd/system"
    createSymlink("/lib/systemd/system/gdm3.service", r.etc / "systemd/system/display-manager.service")
    let idx = index(r)
    let res = resolveName(idx, "display-manager.service").get
    check res.id == "gdm.service" and res.isAlias
    check "display-manager.service" in resolveName(idx, "gdm.service").get.names
  test "alias to another suffix is ignored":
    let r = sysRoots("al3")
    etcUnit(r, "b.socket", "[Socket]\nListenStream=/x\n")
    createSymlink("b.socket", r.etc / "systemd/system/a.service")
    check resolveName(index(r), "a.service").isNone
  test "alias chains and loops":
    let r = sysRoots("al4")
    etcUnit(r, "c.service", "[Service]\nExecStart=/bin/b\n")
    let d = r.etc / "systemd/system"
    createSymlink("c.service", d / "b.service")
    createSymlink("b.service", d / "a.service")
    check resolveName(index(r), "a.service").get.id == "c.service"
    createSymlink("y.service", d / "x.service")
    createSymlink("x.service", d / "y.service")
    let idx = index(r)
    check idx.load("x.service").common.loadState == lsError
  test "linked unit":
    let r = sysRoots("al5")
    let ext = r.etc.parentDir / "opt/x.service"
    put(ext, "[Service]\nExecStart=/bin/x\n")
    createDir r.etc / "systemd/system"
    createSymlink(ext, r.etc / "systemd/system/x.service")
    let idx = index(r)
    let d = idx.load("x.service")
    check d.common.loadState == lsLoaded and d.common.fragmentPath == ext
    check enablementOf(idx, "x.service") == esLinked
  test "template instance lookup":
    let r = sysRoots("al6")
    libUnit(r, "getty@.service", "[Service]\nExecStart=/bin/g %i\n")
    let idx = index(r)
    let res = resolveName(idx, "getty@tty1.service").get
    check res.id == "getty@tty1.service" and res.isTemplateInstance
    check idx.load("getty@tty1.service").service.commands[ekStart][0].args == @["tty1"]
    check resolveName(idx, "other@x.service").isNone
    libUnit(r, "getty@tty2.service", "[Service]\nExecStart=/bin/special\n")
    let idx2 = index(r)
    check idx2.load("getty@tty2.service").service.commands[ekStart][0].path == "/bin/special"
  test "template alias gives canonical instance":
    let r = sysRoots("al7")
    libUnit(r, "getty@.service", "[Service]\nExecStart=/bin/g %i\n")
    createDir r.etc / "systemd/system"
    createSymlink(r.usrLib / "systemd/system/getty@.service", r.etc / "systemd/system/autovt@.service")
    let idx = index(r)
    let res = resolveName(idx, "autovt@tty2.service").get
    check res.id == "getty@tty2.service" and res.isAlias
    check "autovt@tty2.service" in res.names
    check idx.load("autovt@tty2.service").common.id == "getty@tty2.service"
  test "built-in aliases and slices":
    let r = sysRoots("al8")
    let idx = index(r)
    check resolveName(idx, "default.target").get.id == "multi-user.target"
    check resolveName(idx, "runlevel5.target").get.id == "graphical.target"
    check resolveName(idx, "ctrl-alt-del.target").get.id == "reboot.target"
    let s = idx.load("system.slice")
    check s.kind == ukSlice and s.common.loadState == lsLoaded and s.common.implicitDeps[dkRequires] == @["-.slice"]
    check idx.load("a-b-c.slice").common.implicitDeps[dkRequires] == @["a-b.slice"]
    etcUnit(r, "default.target", "[Unit]\nDescription=mine\n")
    check resolveName(index(r), "default.target").get.id == "default.target"
  test "generated units":
    let r = sysRoots("al9")
    let d = newUnitDef(ukMount, "mnt-data.mount")
    d.mount.what = "/dev/sda1"; d.mount.where = "/mnt/data"
    let g = GeneratedUnit(name: "mnt-data.mount", def: d, extraDeps: @[(dkRequires, "local-fs.target", "mnt-data.mount")])
    etcUnit(r, "local-fs.target", "[Unit]\nDescription=lfs\n")
    let idx = index(r, @[g])
    let m = idx.load("mnt-data.mount")
    check m.common.source == usGenerated and m.mount.where == "/mnt/data"
    check m.common.implicitDeps[dkBefore].contains("local-fs.target")
    check idx.load("local-fs.target").common.deps[dkRequires] == @["mnt-data.mount"]
    check enablementOf(idx, "mnt-data.mount") == esGenerated
  test "listNames":
    let r = sysRoots("al10")
    etcUnit(r, "b.service", "[Service]\nExecStart=/bin/b\n[Install]\nWantedBy=x.target\n")
    createSymlink("b.service", r.etc / "systemd/system/a.service")
    libUnit(r, "c.service", "[Service]\nExecStart=/bin/c\n")
    var names: seq[string]
    for e in listNames(index(r)): names.add e.name & ":" & $e.state
    check names == @["a.service:alias", "b.service:disabled", "c.service:static"]
