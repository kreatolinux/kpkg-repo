import std/[unittest, os, strutils]
import unitfile/[model, presets, install, loader, values]
import helpers

const Svc = "[Service]\nExecStart=/bin/x\n"

suite "presets":
  test "parse":
    let rs = parsePresetText("# c\n; c\n\nenable a.service b*.socket\ndisable *\nignore x.service\nbogus y\nenable\n", "f")
    check rs.len == 3 and rs[0].patterns == @["a.service", "b*.socket"] and rs[2].action == paIgnore
  test "first match decides, default is enable":
    let rs = parsePresetText("disable foo.service\nenable foo*\nenable getty@tty1.service\ndisable getty@*\nignore ign.service\n", "f")
    check presetAction(rs, "foo.service") == paDisable
    check presetAction(rs, "foobar.service") == paEnable
    check presetAction(rs, "getty@tty1.service") == paEnable
    check presetAction(rs, "getty@tty2.service") == paDisable
    check presetAction(rs, "ign.service") == paIgnore
    check presetAction(rs, "other.service") == paEnable
    check presetAction(@[], "x.service") == paEnable
  test "instance falls back to template rule":
    let rs = parsePresetText("disable getty@.service\n", "f")
    check presetAction(rs, "getty@tty3.service") == paDisable
  test "shadowing by file name and order":
    let r = sysRoots("pr1")
    put(r.usrLib / "systemd/system-preset/10-a.preset", "disable a.service\n")
    put(r.etc / "systemd/system-preset/10-a.preset", "enable a.service\n")
    put(r.usrLib / "systemd/system-preset/20-b.preset", "disable b.service\n")
    put(r.coreRoot / "share/presets/99-default.preset", "disable *\n")
    let rs = loadPresets(r)
    check rs.len == 3
    check presetAction(rs, "a.service") == paEnable
    check presetAction(rs, "b.service") == paDisable
    check presetAction(rs, "c.service") == paDisable
  test "preset and preset-all":
    let r = sysRoots("pr2")
    for n in ["a", "b", "c"]:
      libUnit(r, n & ".service", Svc & "[Install]\nWantedBy=m.target\n")
    libUnit(r, "s.service", Svc)
    put(r.etc / "systemd/system-preset/50.preset", "enable a.service\ndisable b.service\n")
    put(r.coreRoot / "share/presets/99-default.preset", "disable *\n")
    discard fileOp(r, foEnable, @["b", "c"], FileOpOptions())
    let one = fileOp(r, foPreset, @["a", "b"], FileOpOptions())
    check one.ok
    let idx = index(r)
    check enablementOf(idx, "a.service") == esEnabled
    check enablementOf(idx, "b.service") == esDisabled
    check enablementOf(idx, "c.service") == esEnabled
    discard fileOp(r, foPresetAll, @[], FileOpOptions())
    let idx2 = index(r)
    check enablementOf(idx2, "c.service") == esDisabled
    check enablementOf(idx2, "a.service") == esEnabled
  test "preset modes":
    let r = sysRoots("pr3")
    libUnit(r, "a.service", Svc & "[Install]\nWantedBy=m.target\n")
    put(r.etc / "systemd/system-preset/50.preset", "disable a.service\n")
    discard fileOp(r, foEnable, @["a"], FileOpOptions())
    discard fileOp(r, foPreset, @["a"], FileOpOptions(presetMode: pmEnableOnly))
    check enablementOf(index(r), "a.service") == esEnabled
    discard fileOp(r, foPreset, @["a"], FileOpOptions(presetMode: pmDisableOnly))
    check enablementOf(index(r), "a.service") == esDisabled
  test "shipped preset file":
    check readFile("share/presets/99-default.preset").strip == "disable *"
  test "glob":
    check globMatch("*", "anything.service")
    check globMatch("a?c", "abc") and not globMatch("a?c", "ac")
    check globMatch("[a-c]x*", "bxyz") and not globMatch("[!a-c]x", "bx")
    check globMatch("sshd@*.service", "sshd@1.service")
    check not globMatch("foo", "foobar")
    check globMatch("*.service", "a.b.service")
