## Shared fixtures for the unitfile tests.
import std/[os, exitprocs]
import common/roots
import unitfile/[model, specifiers, loader]

proc runDir(): string = getTempDir() / ("jscore-" & $getCurrentProcessId())

proc cleanup() {.noconv.} =
  try: removeDir runDir() except CatchableError: discard
addExitProc(cleanup)

proc tmpBase*(name: string): string =
  result = runDir() / name
  removeDir result
  createDir result

proc put*(path, text: string) =
  createDir path.parentDir
  writeFile(path, text)

proc sysRoots*(name: string): Roots = testRoots(tmpBase(name), scSystem)
proc userRoots*(name: string): Roots =
  result = testRoots(tmpBase(name), scUser)
  result.home = result.etc.parentDir / "home/alice"
  result.runtime = result.etc.parentDir / "runtime"
  result.etc = result.home / ".config"
  result.sysrun = result.runtime / "systemd"
  createDir result.etc
  createDir result.runtime

proc etcUnit*(r: Roots; name, text: string) = put(r.etc / "systemd/system" / name, text)
proc libUnit*(r: Roots; name, text: string) = put(r.usrLib / "systemd/system" / name, text)

proc testEnv*(): SpecifierEnv = fixedSystemEnv()

proc index*(r: Roots; gen: seq[GeneratedUnit] = @[]): UnitIndex =
  var d: seq[Diag]
  result = buildIndex(r, gen, d)

proc load*(idx: UnitIndex; id: string): UnitDef = loadUnit(idx, id, testEnv())

proc warnings*(d: UnitDef): seq[string] =
  for x in d.common.diagnostics:
    if x.severity == sevWarning and x.code != "W_NOT_RUN": result.add x.key & ": " & x.message
proc errors*(d: UnitDef): seq[string] =
  for x in d.common.diagnostics:
    if x.severity == sevError: result.add x.message

const Sshd* = """
[Unit]
Description=OpenSSH server daemon
Documentation=man:sshd(8) man:sshd_config(5)
After=network.target sshd-keygen.target
Wants=sshd-keygen.target

[Service]
Type=notify
EnvironmentFile=-/etc/sysconfig/sshd
ExecStartPre=/usr/sbin/sshd -t
ExecStart=/usr/sbin/sshd -D $OPTIONS
ExecReload=/bin/kill -HUP $MAINPID
KillMode=process
Restart=on-failure
RestartSec=42s

[Install]
WantedBy=multi-user.target
"""
