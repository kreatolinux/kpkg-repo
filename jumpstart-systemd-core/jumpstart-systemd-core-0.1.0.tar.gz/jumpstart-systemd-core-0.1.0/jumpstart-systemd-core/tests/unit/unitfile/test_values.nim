import std/[unittest, options]
import unitfile/[model, values]

suite "values":
  test "bool":
    for s in ["1", "yes", "TRUE", "On"]: check parseBoolVal(s) == some(true)
    for s in ["0", "no", "False", "OFF"]: check parseBoolVal(s) == some(false)
    check parseBoolVal("maybe").isNone and parseBoolVal("").isNone
  test "timespan":
    check parseTimespan("90") == some(90_000_000'i64)
    check parseTimespan("5min") == some(300_000_000'i64)
    check parseTimespan("1h 30min") == some(5_400_000_000'i64)
    check parseTimespan("1h30min") == some(5_400_000_000'i64)
    check parseTimespan("2.5s") == some(2_500_000'i64)
    check parseTimespan("100ms") == some(100_000'i64)
    check parseTimespan("1y 2month") == some((31557600 + 2 * 2629800) * 1_000_000'i64)
    check parseTimespan("infinity") == some(Infinity)
    check parseTimespan("1w") == some(604_800_000_000'i64)
    check parseTimespan("5 min 3") == some(303_000_000'i64)
    check parseTimespan("0") == some(0'i64)
    check parseTimespan("10", 1) == some(10'i64)
    check parseTimespan("5parsecs").isNone
    check parseTimespan("").isNone and parseTimespan("-5s").isNone and parseTimespan("s").isNone
    check parseTimespan("999999999999999999y").isNone
  test "format timespan":
    check formatTimespan(90_000_000) == "1min 30s"
    check formatTimespan(100_000) == "100ms"
    check formatTimespan(1_500_000) == "1s 500ms"
    check formatTimespan(0) == "0"
    check formatTimespan(Infinity) == "infinity"
    check formatTimespan(5_400_000_000'i64) == "1h 30min"
  test "size":
    check parseSize("1K") == some(1024'i64)
    check parseSize("4M") == some(4194304'i64)
    check parseSize("1.5G") == some(1610612736'i64)
    check parseSize("2KB") == some(2048'i64)
    check parseSize("infinity") == some(Infinity)
    check parseSize("100") == some(100'i64)
    check parseSize("1X").isNone and parseSize("").isNone
    check parseSize("99999999999E").isNone
  test "percent":
    check parsePermille("50%") == some(500'i64)
    check parsePermille("12.5%") == some(125'i64)
    check parsePermille("20\xE2\x80\xB0") == some(20'i64)
    check parsePermille("50").isNone
  test "words":
    check splitWords("a b  c") == @["a", "b", "c"]
    check splitWords("a 'b c' \"d e\" f") == @["a", "b c", "d e", "f"]
    check splitWords("a\"b c\"d") == @["ab cd"]
    check splitWords("'-p -- \\\\u'") == @["-p -- \\u"]
    check splitWords("\\a\\b\\f\\n\\r\\t\\v\\\\\\\"\\'\\s") == @["\a\b\f\n\r\t\v\\\"' "]
    check splitWords("\\x41\\102\\u00e9\\U0001F600") == @["AB\xC3\xA9\xF0\x9F\x98\x80"]
    check splitWords("a\\;b") == @["a\\;b"]
    var ok: bool
    discard splitWords("'unterminated", ok)
    check not ok
    var ws: seq[Word]
    check splitWordsEx("; ';'", ws)
    check ws[0].text == ";" and not ws[0].quoted and ws[1].quoted
  test "signals":
    check parseSignal("SIGTERM") == some(15)
    check parseSignal("TERM") == some(15)
    check parseSignal("9") == some(9)
    check parseSignal("sigterm").isNone
    check parseSignal("0").isNone and parseSignal("65").isNone
    check parseSignal("RTMIN+3") == some(37)
    check parseSignal("SIGRTMAX") == some(64)
    check signalName(15) == "SIGTERM"
  test "exit sets":
    var e: ExitSet
    check parseExitSet("1 2 SIGUSR1 200", e)
    check 1'u8 in e.statuses and 200'u8 in e.statuses and 10'u8 in e.signals
    check not parseExitSet("256", e)
    check not parseExitSet("FOO", e)
    check formatExitSet(e) == "1 2 200 SIGUSR1"
