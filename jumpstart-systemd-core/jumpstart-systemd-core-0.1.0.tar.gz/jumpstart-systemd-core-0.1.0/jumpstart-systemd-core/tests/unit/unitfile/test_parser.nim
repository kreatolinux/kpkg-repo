import std/[unittest, strutils]
import unitfile/[model, syntax]

proc get(r: SyntaxResult; key: string): seq[string] =
  for s in r.settings:
    if s.key == key: result.add s.value

suite "syntax":
  test "basic sections and keys":
    let r = parseSyntax("[Unit]\nDescription = Hello world \n# c\n; c\n\n[Service]\nExecStart=/bin/x\n", "a.service")
    check r.diags.len == 0
    check r.settings.len == 2
    check r.settings[0].section == "Unit" and r.settings[0].value == "Hello world" and r.settings[0].line == 2
    check r.settings[1].line == 7
  test "continuation":
    let r = parseSyntax("[Service]\nExecStart=/bin/a \\\n  b \\\n# comment\n  c\nX=1\n", "a")
    check r.get("ExecStart") == @["/bin/a    b    c".replace("    ", "  ")] or r.get("ExecStart")[0].startsWith("/bin/a")
    check r.get("ExecStart")[0].splitWhitespace == @["/bin/a", "b", "c"]
    check r.get("X") == @["1"]
    check r.settings[0].line == 2
  test "blank line inside continuation ends it":
    let r = parseSyntax("[S]\nA=x \\\n\nB=y\n", "a")
    check r.get("A") == @["x"] and r.get("B") == @["y"]
  test "comment never continues":
    let r = parseSyntax("[S]\n# foo \\\nA=1\n", "a")
    check r.get("A") == @["1"]
  test "CRLF tabs trailing whitespace":
    let r = parseSyntax("[Unit]\r\n\tDescription=\tD  \t\r\n", "a")
    check r.get("Description") == @["D"]
    check r.diags.len == 0
  test "repeated sections and keys accumulate":
    let r = parseSyntax("[S]\nA=1\n[T]\nB=2\n[S]\nA=3\n", "a")
    check r.get("A") == @["1", "3"]
    check r.sections == @["S", "T", "S"]
  test "unknown section and X-":
    let r = parseSyntax("[Foo]\nA=1\n[X-Bar]\nB=1\n[S]\nX-Key=1\nC=1\n", "a", known = @["S"])
    check r.diags.len == 1 and r.diags[0].severity == sevWarning and r.diags[0].line == 1
    check r.settings.len == 1 and r.settings[0].key == "C"
  test "warnings":
    let r = parseSyntax("A=1\n[S]\nnoequals\n[S] junk\nB=1\n[Unclosed\n", "f.service", "f.service")
    check r.diags.len == 4
    check r.diags[0].line == 1 and r.diags[0].file == "f.service" and r.diags[0].unit == "f.service"
    check r.get("B") == @["1"]
  test "invalid utf-8":
    let r = parseSyntax("[S]\nA=\xff\n", "a")
    check r.fatal and r.diags[0].severity == sevError
  test "oversize":
    let r = parseSyntax("[S]\n" & repeat("A=1\n", 400_000), "a")
    check r.fatal
    let r2 = parseSyntax("[S]\n" & repeat("A=1\n", 9000), "a")
    check r2.fatal
  test "empty value kept":
    let r = parseSyntax("[S]\nA=\n", "a")
    check r.get("A") == @[""]
