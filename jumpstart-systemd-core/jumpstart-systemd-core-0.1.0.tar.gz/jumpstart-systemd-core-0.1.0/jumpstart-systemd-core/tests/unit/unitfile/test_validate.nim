import std/[unittest, os, strutils, sequtils]
import common/roots
import unitfile/[model, validate]
import helpers

proc v(r: Roots; name: string): ValidationResult = validateUnit(r, name, testEnv())
proc has(res: ValidationResult; sev: Severity; sub: string): bool =
  res.diagnostics.anyIt(it.severity == sev and sub in it.message)

proc execBaseOf(r: Roots): string = r.usrLib.parentDir.parentDir

proc exe(r: Roots; p: string) =
  let f = execBaseOf(r) / p
  put(f, "#!/bin/sh\n")
  setFilePermissions(f, {fpUserExec, fpUserRead, fpUserWrite})

suite "validation errors":
  test "valid unit":
    let r = sysRoots("va1")
    exe(r, "usr/bin/a")
    etcUnit(r, "a.service", "[Unit]\nDescription=x\n[Service]\nExecStart=/usr/bin/a\n")
    let res = v(r, "a.service")
    check res.valid
    check res.diagnostics.filterIt(it.severity == sevError).len == 0
  test "not found, masked, invalid name":
    let r = sysRoots("va2")
    createDir r.etc / "systemd/system"
    createSymlink("/dev/null", r.etc / "systemd/system/m.service")
    check not v(r, "zz.service").valid
    check v(r, "m.service").has(sevError, "masked")
    check not v(r, "bad name.service").valid
  test "service without ExecStart":
    let r = sysRoots("va3")
    etcUnit(r, "a.service", "[Service]\nRemainAfterExit=yes\n")
    check v(r, "a.service").has(sevError, "no ExecStart=")
    etcUnit(r, "b.service", "[Unit]\nSuccessAction=exit\n[Service]\nRemainAfterExit=yes\n")
    check v(r, "b.service").valid
    etcUnit(r, "c.service", "[Service]\nExecStop=/bin/true\n")
    check not v(r, "c.service").has(sevError, "no ExecStart=")
  test "oneshot with Restart":
    let r = sysRoots("va4")
    exe(r, "bin/true")
    for rs in ["always", "on-success"]:
      etcUnit(r, "o.service", "[Service]\nType=oneshot\nExecStart=/bin/true\nRestart=" & rs & "\n")
      check v(r, "o.service").has(sevError, "Type=oneshot")
    etcUnit(r, "o.service", "[Service]\nType=oneshot\nExecStart=/bin/true\nRestart=on-failure\n")
    check v(r, "o.service").valid
  test "notify with NotifyAccess=none is a warning":
    let r = sysRoots("va5")
    exe(r, "bin/true")
    etcUnit(r, "n.service", "[Service]\nType=notify\nNotifyAccess=none\nExecStart=/bin/true\n")
    let res = v(r, "n.service")
    check res.valid and res.has(sevWarning, "raised to main")
  test "executables":
    let r = sysRoots("va6")
    exe(r, "usr/bin/real")
    etcUnit(r, "a.service", "[Service]\nExecStart=/usr/bin/missing\n")
    let a = v(r, "a.service")
    check a.valid and a.has(sevWarning, "/usr/bin/missing is not executable")
    etcUnit(r, "b.service", "[Service]\nExecStart=-/usr/bin/missing\n")
    check v(r, "b.service").diagnostics.len == 0
    etcUnit(r, "c.service", "[Service]\nExecStart=nosuchprog\n")
    check v(r, "c.service").has(sevError, "nosuchprog is not found")
    etcUnit(r, "d.service", "[Service]\nExecStart=real\n")
    check v(r, "d.service").valid
    etcUnit(r, "e.service", "[Service]\nExecStart=rel/path\n")
    check v(r, "e.service").has(sevError, "not absolute")
  test "more than one ExecStart outside oneshot":
    let r = sysRoots("va7")
    etcUnit(r, "a.service", "[Service]\nExecStart=-/bin/a\nExecStart=-/bin/b\n")
    check v(r, "a.service").has(sevError, "more than one ExecStart")
  test "dbus without BusName":
    let r = sysRoots("va8")
    etcUnit(r, "a.service", "[Service]\nType=dbus\nExecStart=-/bin/a\n")
    check v(r, "a.service").has(sevError, "BusName")
  test "socket":
    let r = sysRoots("va9")
    etcUnit(r, "a.socket", "[Socket]\nSocketMode=0600\n")
    check v(r, "a.socket").has(sevError, "no Listen")
    etcUnit(r, "b.socket", "[Socket]\nListenStream=/run/b\nService=b.socket\n")
    check v(r, "b.socket").has(sevError, "must name a .service")
    etcUnit(r, "c.socket", "[Socket]\nListenStream=/run/c\nAccept=yes\nService=c.service\n")
    check v(r, "c.socket").has(sevError, "Accept=yes")
    etcUnit(r, "d.socket", "[Socket]\nListenStream=/run/d\nAccept=yes\n")
    check not v(r, "d.socket").has(sevError, "Accept=yes")
    etcUnit(r, "e.socket", "[Socket]\nListenStream=/run/e\n")
    check not v(r, "e.socket").has(sevError, "Listen")
  test "timer and path":
    let r = sysRoots("va10")
    etcUnit(r, "a.timer", "[Timer]\nPersistent=yes\n")
    check v(r, "a.timer").has(sevError, "lacks value setting")
    etcUnit(r, "b.timer", "[Timer]\nOnClockChange=yes\n")
    check v(r, "b.timer").valid
    etcUnit(r, "c.timer", "[Timer]\nOnCalendar=daily\nAccuracySec=bogus\n")
    let c = v(r, "c.timer")
    check c.valid and c.has(sevWarning, "Failed to parse timespan")
    calendarValidator = proc(e: string): bool = e != "garbage"
    etcUnit(r, "d.timer", "[Timer]\nOnCalendar=garbage\n")
    check v(r, "d.timer").has(sevError, "calendar")
    calendarValidator = nil
    etcUnit(r, "a.path", "[Path]\nUnit=x.service\n")
    check v(r, "a.path").has(sevError, "lacks path setting")
    etcUnit(r, "b.path", "[Path]\nPathExists=/x\n")
    check v(r, "b.path").valid
  test "mount and swap":
    let r = sysRoots("va11")
    etcUnit(r, "mnt-data.mount", "[Mount]\nWhat=/dev/sda1\nWhere=/mnt/data\n")
    check v(r, "mnt-data.mount").valid
    etcUnit(r, "mnt-x.mount", "[Mount]\nWhat=/dev/sda1\nWhere=/mnt/data\n")
    check v(r, "mnt-x.mount").has(sevError, "doesn't match")
    etcUnit(r, "mnt-y.mount", "[Mount]\nWhat=/dev/sda1\nWhere=mnt/y\n")
    check v(r, "mnt-y.mount").has(sevError, "absolute")
    etcUnit(r, "mnt-z.mount", "[Mount]\nWhere=/mnt/z\n")
    check v(r, "mnt-z.mount").has(sevError, "What=")
    etcUnit(r, "dev-sdb2.swap", "[Swap]\nWhat=/dev/sdb2\n")
    check v(r, "dev-sdb2.swap").valid
    etcUnit(r, "dev-sdb3.swap", "[Swap]\nWhat=/dev/sdb2\n")
    check v(r, "dev-sdb3.swap").has(sevError, "doesn't match")
  test "rejected directive and automount":
    let r = sysRoots("va12")
    etcUnit(r, "a.service", "[Service]\nExecStart=-/bin/a\nPrivatePIDs=yes\n")
    let a = v(r, "a.service")
    check not a.valid and a.def.common.loadState == lsBadSetting
    etcUnit(r, "x.automount", "[Automount]\nWhere=/x\n")
    check v(r, "x.automount").valid
    etcUnit(r, "y.automount", "[Automount]\nWhere=/x\n")
    check v(r, "y.automount").has(sevError, "doesn't match")
    etcUnit(r, "z.automount", "[Automount]\nTimeoutIdleSec=5\n")
    check v(r, "z.automount").has(sevError, "Where=")
  test "alias errors":
    let r = sysRoots("va13")
    etcUnit(r, "a.service", "[Service]\nExecStart=-/bin/a\n[Install]\nAlias=b.socket\nAlias=c@.service\nAlias=ok.service\n")
    let a = v(r, "a.service")
    check a.diagnostics.countIt(it.key == "Alias" and it.severity == sevError) == 2
    etcUnit(r, "t@.service", "[Service]\nExecStart=-/bin/a\n[Install]\nAlias=plain.service\n")
    check v(r, "t@.service").has(sevError, "must be a template")
  test "bad syntax and utf8":
    let r = sysRoots("va14")
    etcUnit(r, "a.service", "[Service]\nExecStart=\xff\n")
    check not v(r, "a.service").valid
  test "from a path":
    let r = sysRoots("va15")
    let f = r.etc.parentDir / "tmp/x.service"
    put(f, "[Service]\nExecStart=-/bin/a\nBogus=1\n")
    let res = v(r, f)
    check res.valid and res.has(sevWarning, "Unknown key 'Bogus'")
    check not v(r, r.etc.parentDir / "tmp/none.service").valid

suite "validation warnings":
  test "unknown section, key, ignored directive":
    let r = sysRoots("vw1")
    etcUnit(r, "a.service", "[Foo]\nA=1\n[Service]\nExecStart=-/bin/a\nBar=1\nPrivateMounts=yes\nUtmpIdentifier=1\nX-A=1\n")
    let a = v(r, "a.service")
    check a.valid and a.has(sevWarning, "Unknown section 'Foo'") and a.has(sevWarning, "Unknown key 'Bar'")
    check a.has(sevWarning, "UtmpIdentifier= is parsed and ignored")
    check not a.has(sevWarning, "X-A")
  test "missing dependencies, self After, install targets":
    let r = sysRoots("vw2")
    etcUnit(r, "a.service", "[Unit]\nWants=nope.service\nRequires=nope2.service\nAfter=a.service\n[Service]\nExecStart=-/bin/a\n[Install]\nWantedBy=nothing.target\n")
    let a = v(r, "a.service")
    check a.has(sevWarning, "nope.service") and a.has(sevWarning, "nope2.service")
    check a.has(sevWarning, "lists itself in After=")
    check a.has(sevWarning, "[Install] target nothing.target does not exist")
  test "documentation scheme":
    let r = sysRoots("vw3")
    etcUnit(r, "a.service", "[Unit]\nDocumentation=man:x(1) https://x ftp://bad\n[Service]\nExecStart=-/bin/a\n")
    let a = v(r, "a.service")
    check a.diagnostics.countIt(it.key == "Documentation") == 1
  test "%i in a non-template":
    let r = sysRoots("vw4")
    etcUnit(r, "a.service", "[Unit]\nDescription=x %i\n[Service]\nExecStart=-/bin/a\n")
    check v(r, "a.service").has(sevWarning, "not a template")
  test "default dependencies interplay":
    let r = sysRoots("vw5")
    etcUnit(r, "a.service", "[Unit]\nBefore=sysinit.target\n[Service]\nExecStart=-/bin/a\n")
    check v(r, "a.service").has(sevWarning, "likely an ordering cycle")
    etcUnit(r, "b.service", "[Unit]\nDefaultDependencies=no\nBefore=sysinit.target\n[Service]\nExecStart=-/bin/a\n")
    check not v(r, "b.service").has(sevWarning, "likely an ordering cycle")
  test "path condition not absolute":
    let r = sysRoots("vw6")
    etcUnit(r, "a.service", "[Unit]\nConditionPathExists=foo\n[Service]\nExecStart=-/bin/a\n")
    check v(r, "a.service").has(sevWarning, "not absolute")
  test "ordering cycle":
    let r = sysRoots("vw7")
    etcUnit(r, "a.service", "[Unit]\nDefaultDependencies=no\nAfter=b.service\n[Service]\nExecStart=-/bin/a\n")
    etcUnit(r, "b.service", "[Unit]\nDefaultDependencies=no\nAfter=c.service\n[Service]\nExecStart=-/bin/a\n")
    etcUnit(r, "c.service", "[Unit]\nDefaultDependencies=no\nAfter=a.service\n[Service]\nExecStart=-/bin/a\n")
    etcUnit(r, "d.service", "[Unit]\nDefaultDependencies=no\nAfter=a.service\n[Service]\nExecStart=-/bin/a\n")
    check v(r, "a.service").has(sevWarning, "Found ordering cycle: a.service -> b.service -> c.service")
    check not v(r, "d.service").has(sevWarning, "ordering cycle")
    let idx = index(r)
    let defs = ["a.service", "b.service", "c.service", "d.service"].mapIt(idx.load(it))
    check orderingCycles(defs) == @[@["a.service", "b.service", "c.service"]]
  test "path, swap and timer units load without the not-run warning":
    let r = sysRoots("vw8")
    etcUnit(r, "a.timer", "[Timer]\nOnCalendar=daily\n")
    etcUnit(r, "a.path", "[Path]\nPathExists=/x\n")
    check not index(r).load("a.timer").common.diagnostics.anyIt(it.code == "W_NOT_RUN")
    check not index(r).load("a.path").common.diagnostics.anyIt(it.code == "W_NOT_RUN")
