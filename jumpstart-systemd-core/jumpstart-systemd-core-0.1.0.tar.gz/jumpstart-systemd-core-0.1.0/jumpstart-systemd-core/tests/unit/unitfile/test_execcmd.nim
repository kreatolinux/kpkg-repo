import std/[unittest, os, options, tables]
import unitfile/[model, execcmd]
import helpers

proc one(s: string): ExecCommand =
  let c = parseExecLine(s)
  doAssert c.len == 1, s
  c[0]

suite "exec lines":
  test "plain":
    let c = one("/usr/bin/foo -a --b=c  d")
    check c.path == "/usr/bin/foo" and c.args == @["-a", "--b=c", "d"] and c.flags == {}
  test "each prefix":
    check one("-/bin/x").flags == {efMinus}
    check one("@/bin/x argv0 a").argv0 == "argv0"
    check one("@/bin/x argv0 a").args == @["a"]
    check one(":/bin/x").flags == {efColon}
    check one("+/bin/x").flags == {efPlus}
    check one("!/bin/x").flags == {efBang}
    check one("!!/bin/x").flags == {efBang, efBangBang}
  test "combinations in any order":
    check one("-+/bin/x").flags == {efMinus, efPlus}
    check one("+-/bin/x").flags == {efMinus, efPlus}
    check one("@-:/bin/x a b").flags == {efAt, efMinus, efColon}
    check one("-!/bin/x").flags == {efMinus, efBang}
    check one("- /bin/x").path == "/bin/x"
  test "more than one of + ! !! is an error":
    var e: seq[string]
    check parseExecLine("+!/bin/x", e).len == 0 and e.len == 1
    e.setLen 0
    check parseExecLine("!+/bin/x", e).len == 0
  test "quoting":
    check one("/bin/x 'a b' \"c d\" e").args == @["a b", "c d", "e"]
    check one("/usr/sbin/nginx -g 'daemon on; master_process on;'").args == @["-g", "daemon on; master_process on;"]
    check one("/bin/x \"a\\tb\"").args == @["a\tb"]
    check one("/sbin/agetty -o '-p -- \\\\u' --noclear - $TERM").args == @["-o", "-p -- \\u", "--noclear", "-", "$TERM"]
  test "multiple commands":
    let c = parseExecLine("/bin/a 1 ; /bin/b 2 ; -/bin/c")
    check c.len == 3 and c[0].path == "/bin/a" and c[1].args == @["2"] and c[2].flags == {efMinus}
    let d = parseExecLine("/bin/a x \x5C; y")
    check d.len == 1 and d[0].args == @["x", ";", "y"]
    check parseExecLine("/bin/a ';'")[0].args == @[";"]
  test "errors":
    var e: seq[string]
    check parseExecLine("relative/path a", e).len == 0 and e.len == 1
    e.setLen 0
    check parseExecLine("/bin/x 'oops", e).len == 0 and e.len == 1
    e.setLen 0
    check parseExecLine("-", e).len == 0 and e.len == 1
    e.setLen 0
    check parseExecLine("@/bin/x", e).len == 0 and e.len == 1
    e.setLen 0
    check parseExecLine("/bin/a ; relative/b ; /bin/c", e).len == 2 and e.len == 1
    check parseExecLine("").len == 0
  test "bare name is kept":
    check one("true").path == "true"
  test "specifier expansion per word":
    var e: seq[string]
    let ex: Expander = proc(s: string): Option[string] =
      if s == "%bad": none(string) else: some(if s == "%i": "tty1" else: s)
    let c = parseExecLine("/bin/x %i %i", e, ex)
    check c[0].args == @["tty1", "tty1"]
    check parseExecLine("/bin/x %bad", e, ex).len == 0
  test "executable lookup":
    let r = sysRoots("ex1")
    let b = execBase(r)
    put(b / "usr/bin/hello", "#!/bin/sh\n")
    setFilePermissions(b / "usr/bin/hello", {fpUserExec, fpUserRead})
    put(b / "usr/bin/plain", "x")
    let dirs = execSearchDirs(r)
    check dirs[3] == b / "usr/bin"
    check lookupExecutable("hello", dirs) == b / "usr/bin/hello"
    check lookupExecutable("plain", dirs) == ""
    check lookupExecutable("nothere", dirs) == ""
    check lookupExecutable("/usr/bin/hello", dirs, b) == "/usr/bin/hello"
    check lookupExecutable("/usr/bin/plain", dirs, b) == ""
  test "exec-time substitution":
    let env = {"A": "x y", "E": "", "B": "one"}.toTable
    check expandExecArgs(@["$A"], env) == @["x", "y"]
    check expandExecArgs(@["${A}"], env) == @["x y"]
    check expandExecArgs(@["$E"], env) == newSeq[string]()
    check expandExecArgs(@["${E}"], env) == @[""]
    check expandExecArgs(@["$UNSET"], env).len == 0
    check expandExecArgs(@["${UNSET}"], env).len == 0
    check expandExecArgs(@["$$"], env) == @["$"]
    check expandExecArgs(@["a$$b"], env) == @["a$b"]
    check expandExecArgs(@["--o=${B}"], env) == @["--o=one"]
    check expandExecArgs(@["--o=$B"], env) == @["--o=one"]
    check expandExecArgs(@["$B", "-x", "${A}"], env) == @["one", "-x", "x y"]
    check expandExecArgs(@["$A"], env, noSubst = true) == @["$A"]
