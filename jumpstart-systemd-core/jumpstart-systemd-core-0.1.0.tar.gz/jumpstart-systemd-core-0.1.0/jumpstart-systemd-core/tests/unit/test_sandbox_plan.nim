## Pure parts of the confinement steps: seccomp programs (checked with a BPF
## interpreter and invented system call numbers, so they run on any host),
## system call groups, capability sets, and the settings the manager refuses.
import std/[strutils, tables, unittest]
import executor/[caps, context, seccomp, syscalls, failure]
import common/roots
import unitfile/model
import service/execcontext

var numbers = initTable[string, int]()
proc fakeNr(name: string): int =
  ## Invented numbers are stable per name; unknown names are absent, as on a real architecture.
  if name notin numbers: numbers[name] = 1000 + numbers.len
  numbers[name]

proc verdict(progs: seq[Program]; name: string; args: array[6, uint64] = [0'u64, 0, 0, 0, 0, 0]): seq[uint32] =
  for p in progs: result.add evaluate(assemble(p), NativeArch, uint32(fakeNr(name)), args)

proc input(s: SeccompSpec): SeccompInput = SeccompInput(spec: s, currentPersonality: 0)

const allow = RetAllow

suite "system call groups":
  test "groups expand recursively and unknown groups raise":
    let sys = expandSyscallEntry("@system-service")
    check "read" in sys and "mmap" in sys and "execve" in sys and "socket" in sys
    check "mount" notin sys and "reboot" notin sys and "setuid" in sys
    check "setuid" in expandSyscallEntry("@privileged") and "reboot" in expandSyscallEntry("@privileged")
    expect KeyError: discard expandSyscallEntry("@nonsense")
    check expandSyscallEntry("openat") == @["openat"]
  test "numbers come from the build architecture":
    when defined(linux):
      check syscallNumber("read") >= 0 and syscallNumber("openat") >= 0
      check syscallNumber("definitely_not_a_syscall") == -1
    else:
      check syscallNumber("read") == -1

suite "seccomp programs":
  test "the architecture is checked first":
    let p = Program(rules: @[], default: allow)
    check evaluate(assemble(p), NativeArch, 1, [0'u64, 0, 0, 0, 0, 0]) == allow
    check evaluate(assemble(p), NativeArch xor 1, 1, [0'u64, 0, 0, 0, 0, 0]) == RetKillProcess
  test "deny list with errno entries":
    var s = SeccompSpec(systemCallFilter: @["~mount:EACCES", "~reboot"], systemCallErrorNumber: "EPERM")
    let progs = buildPrograms(input(s), fakeNr)
    check progs.verdict("mount") == @[errnoAction(13)]
    check progs.verdict("reboot") == @[errnoAction(1)]
    check progs.verdict("read") == @[allow]
    s.systemCallErrorNumber = ""
    check buildPrograms(input(s), fakeNr).verdict("reboot") == @[RetKillProcess]
  test "allow list minus deny list, everything else killed":
    let s = SeccompSpec(systemCallFilter: @["@system-service", "~@privileged"])
    let progs = buildPrograms(input(s), fakeNr)
    check progs.verdict("read") == @[allow]
    check progs.verdict("execve") == @[allow]            # the mandatory @default
    check progs.verdict("setuid") == @[RetKillProcess]    # denied inside the allow list
    check progs.verdict("mount") == @[RetKillProcess]     # never allowed
    let e = SeccompSpec(systemCallFilter: @["@system-service", "~@privileged"], systemCallErrorNumber: "ENOSYS")
    check buildPrograms(input(e), fakeNr).verdict("mount") == @[errnoAction(38)]
  test "an unknown group or errno is an error":
    expect FilterError: discard buildPrograms(input(SeccompSpec(systemCallFilter: @["@nope"])), fakeNr)
    expect FilterError:
      discard buildPrograms(input(SeccompSpec(systemCallFilter: @["~mount"], systemCallErrorNumber: "EBOGUS")), fakeNr)
  test "address families":
    let sockArgs = proc(af: uint64): array[6, uint64] = [af, 0, 0, 0, 0, 0]
    let a = buildPrograms(input(SeccompSpec(restrictAddressFamilies: @["AF_UNIX", "AF_INET"])), fakeNr)
    check a.verdict("socket", sockArgs(1)) == @[allow]
    check a.verdict("socket", sockArgs(10)) == @[errnoAction(97)]
    check a.verdict("read") == @[allow]
    let d = buildPrograms(input(SeccompSpec(restrictAddressFamilies: @["~AF_NETLINK"])), fakeNr)
    check d.verdict("socket", sockArgs(16)) == @[errnoAction(97)]
    check d.verdict("socket", sockArgs(1)) == @[allow]
    let n = buildPrograms(input(SeccompSpec(restrictAddressFamilies: @["none"])), fakeNr)
    check n.verdict("socket", sockArgs(1)) == @[errnoAction(97)]
    expect FilterError: discard buildPrograms(input(SeccompSpec(restrictAddressFamilies: @["AF_BOGUS"])), fakeNr)
  test "namespaces":
    let flags = proc(v: uint64): array[6, uint64] = [v, v, 0, 0, 0, 0]
    let yes = buildPrograms(input(SeccompSpec(restrictNamespaces: @["yes"])), fakeNr)
    check yes.verdict("unshare", flags(0x40000000)) == @[errnoAction(1)]
    check yes.verdict("unshare", flags(0)) == @[allow]
    check yes.verdict("clone", flags(0x00020000 or 17)) == @[errnoAction(1)]
    check yes.verdict("clone3") == @[errnoAction(38)]
    check yes.verdict("setns", [3'u64, 0, 0, 0, 0, 0]) == @[errnoAction(1)]
    let net = buildPrograms(input(SeccompSpec(restrictNamespaces: @["net", "uts"])), fakeNr)
    check net.verdict("unshare", flags(0x40000000)) == @[allow]
    check net.verdict("unshare", flags(0x10000000)) == @[errnoAction(1)]
    check buildPrograms(input(SeccompSpec(restrictNamespaces: @["no"])), fakeNr).len == 0
  test "simple restrictions share one program":
    let s = SeccompSpec(memoryDenyWriteExecute: true, restrictSuidSgid: true, restrictRealtime: true,
                        lockPersonality: true)
    let progs = buildPrograms(input(s), fakeNr)
    check progs.len == 1
    check progs.verdict("mmap", [0'u64, 0, 7, 0, 0, 0]) == @[errnoAction(1)]
    check progs.verdict("mmap", [0'u64, 0, 3, 0, 0, 0]) == @[allow]
    check progs.verdict("mprotect", [0'u64, 0, 4, 0, 0, 0]) == @[errnoAction(1)]
    check progs.verdict("mprotect", [0'u64, 0, 1, 0, 0, 0]) == @[allow]
    check progs.verdict("chmod", [0'u64, 0o4755, 0, 0, 0, 0]) == @[errnoAction(1)]
    check progs.verdict("fchmodat", [0'u64, 0, 0o2755, 0, 0, 0]) == @[errnoAction(1)]
    check progs.verdict("chmod", [0'u64, 0o755, 0, 0, 0, 0]) == @[allow]
    check progs.verdict("sched_setscheduler", [0'u64, 1, 0, 0, 0, 0]) == @[errnoAction(1)]
    check progs.verdict("sched_setscheduler", [0'u64, 0, 0, 0, 0, 0]) == @[allow]
    check progs.verdict("personality", [8'u64, 0, 0, 0, 0, 0]) == @[errnoAction(1)]
    check progs.verdict("personality", [0xffffffff'u64, 0, 0, 0, 0, 0]) == @[allow]
    check progs.verdict("personality", [0'u64, 0, 0, 0, 0, 0]) == @[allow]
  test "implied denials of the Protect* settings":
    var i = input(SeccompSpec())
    i.protectKernelModules = true
    i.protectKernelLogs = true
    i.protectClock = true
    i.protectHostname = true
    i.privateDevices = true
    let progs = buildPrograms(i, fakeNr)
    for n in ["init_module", "delete_module", "syslog", "settimeofday", "clock_settime", "sethostname",
              "setdomainname", "ioperm"]:
      check progs.verdict(n) == @[errnoAction(1)]
    check progs.verdict("mknod", [0'u64, 0o020600, 0, 0, 0, 0]) == @[errnoAction(1)]
    check progs.verdict("mknod", [0'u64, 0o100600, 0, 0, 0, 0]) == @[allow]
    check progs.verdict("read") == @[allow]
  test "programs stay far below the kernel limit":
    let s = SeccompSpec(systemCallFilter: @["@system-service", "~@privileged"])
    check assemble(buildPrograms(input(s), fakeNr)[0]).len < 4096
  test "wantsSeccomp":
    check not wantsSeccomp(ExecSpec())
    check wantsSeccomp(ExecSpec(seccomp: SeccompSpec(lockPersonality: true)))
    check wantsSeccomp(ExecSpec(sandbox: SandboxSpec(protectClock: true)))

suite "capability sets":
  test "names":
    check capNumber("CAP_NET_ADMIN") == 12 and capNumber("cap_sys_admin") == 21
    check capNumber("CAP_CHECKPOINT_RESTORE") == 40 and capNumber("CAP_BOGUS") == -1
  test "allow, deny and mixed lists":
    var bad = ""
    check setOf(@["CAP_KILL", "CAP_CHOWN"], bad) == ((1'u64 shl 5) or 1'u64)
    let all = (1'u64 shl CapNames.len) - 1
    check setOf(@["~CAP_SYS_ADMIN"], bad) == (all and not (1'u64 shl 21))
    check setOf(@["~CAP_SYS_ADMIN", "CAP_KILL"], bad) == (all and not ((1'u64 shl 21) or (1'u64 shl 5)))   # `~` covers its line
    check setOf(@["CAP_KILL", "CAP_CHOWN", "~CAP_CHOWN"], bad) == (1'u64 shl 5)
    check bad == ""
    discard setOf(@["CAP_NOPE"], bad)
    check bad == "CAP_NOPE"
  test "plan: implied drops, subset check":
    var s = ExecSpec(sandbox: SandboxSpec(privateDevices: true, protectClock: true))
    let plan = planCapabilities(s)
    check plan.active
    check (plan.bounding and (1'u64 shl 27)) == 0 and (plan.bounding and (1'u64 shl 25)) == 0
    check (plan.bounding and (1'u64 shl 0)) != 0
    check not planCapabilities(ExecSpec()).active
    s = ExecSpec(capabilityBoundingSet: @["CAP_KILL"], ambientCapabilities: @["CAP_CHOWN"])
    expect StepFailure: discard planCapabilities(s)

suite "settings the manager still refuses":
  test "only what is not implemented is listed":
    var c = ExecContext()
    check unsupportedFor(c, scSystem).len == 0
    c.privateTmp = true
    c.privateDevices = true
    c.protectSystem = psStrict
    c.protectHome = phTmpfs
    c.bindPaths = @["/a:/b"]
    c.capabilityBoundingSet = @["~CAP_SYS_ADMIN"]
    c.systemCallFilter = @["@system-service"]
    c.restrictAddressFamilies = @["AF_UNIX"]
    c.dynamicUser = true
    c.loadCredential = @["x:/y"]
    c.systemCallArchitectures = @["native"]
    check unsupportedFor(c, scSystem).len == 0
    c.privateUsers = true
    check unsupportedFor(c, scSystem).len == 1 and "PrivateUsers" in unsupportedFor(c, scSystem)[0]
    check unsupportedFor(c, scUser).len == 2          # DynamicUser= needs the system scope
    c.systemCallArchitectures = @["native", "x86"]
    check unsupportedFor(c, scSystem).len == 2 and "x86" in unsupportedFor(c, scSystem)[1]
