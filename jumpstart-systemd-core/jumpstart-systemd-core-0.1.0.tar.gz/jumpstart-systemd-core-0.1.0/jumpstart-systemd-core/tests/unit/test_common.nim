from std/strutils import repeat
import std/[options, unittest]
import common/[names, sha1]

suite "names":
  test "parse":
    let p = parseUnitName("getty@tty1.service").get
    check p.prefix == "getty" and p.instance == "tty1" and p.isInstance and p.kind == ukService
    check parseUnitName("getty@.service").get.isTemplate
    check parseUnitName("foo.bar").isNone
    check parseUnitName("a b.service").isNone
    check parseUnitName("@x.service").isNone
  test "escape":
    check escape("a-b") == "a\\x2db"
    check escape("/dev/sda1") == "-dev-sda1"
    check escapePath("/dev/sda1") == "dev-sda1"
    check escapePath("/") == "-"
    check escapePath("/var//lib/") == "var-lib"
    check unescape("a\\x2db").get == "a-b"
    check unescapePath("dev-sda1").get == "/dev/sda1"
    check escape(".hidden") == "\\x2ehidden"
  test "mangle":
    check mangle("sshd") == "sshd.service"
    check mangle("/dev/sda1") == "dev-sda1.device"
    check mangle("/var/lib") == "var-lib.mount"
    check mangle("a.timer") == "a.timer"
  test "templates":
    check instantiate("a@.service", "x") == "a@x.service"
    check templateOf("a@x.service") == "a@.service"
  test "cgroup components":
    check cgroupComponent("a\\x2db%.service") == "a%5cx2db%25.service.unit"
    check unitOfCgroupComponent(cgroupComponent("a\\x2db%.service")).get == "a\\x2db%.service"
    check cgroupComponent('a'.repeat(300)).len < 100
  test "slices":
    check sliceParents("a-b-c.slice") == @["a.slice", "a-b.slice"]
    check sliceParents("-.slice").len == 0
    check sliceParents("system.slice").len == 0
  test "sha1":
    check sha1hex("abc") == "a9993e364706816aba3e25717850c26c9cd0d89d"
