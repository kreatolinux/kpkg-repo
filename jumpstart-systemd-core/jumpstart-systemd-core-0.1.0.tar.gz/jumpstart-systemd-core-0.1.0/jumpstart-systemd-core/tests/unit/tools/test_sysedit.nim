import std/[os, strutils, unittest, posix]
import common/roots
import tools/sysedit

suite "systemctl edit":
  let base = getTempDir() / ("sdc-edit-" & $getpid())
  removeDir(base)
  createDir(base)
  let r = testRoots(base, scSystem)
  let vendor = base / "usr/lib/systemd/system"
  createDir(vendor)
  writeFile(vendor / "foo.service", "[Service]\nExecStart=/bin/true\n")
  proc editor(script: string): string =
    let p = base / "ed.sh"
    writeFile(p, "#!/bin/sh\n" & script & "\n")
    setFilePermissions(p, {fpUserRead, fpUserWrite, fpUserExec})
    putEnv("SYSTEMD_EDITOR", p)
    p
  test "extractEdited":
    check extractEdited("### Editing /x\n### Anything between here and the comment below will become the new contents of the file\n\n[Service]\nA=b\n\n\n### Lines below this comment will be discarded\n\n### f\n# x\n") == "[Service]\nA=b\n"
    check extractEdited("### Lines below this comment will be discarded\nx") == ""
  test "new drop-in with scaffold":
    discard editor("printf '[Service]\\nNice=3\\n' > \"$(dirname $1)/.sdc-out\"; grep -q 'ExecStart' $1 && grep -q '^# \\[Service\\]' $1 && cp \"$(dirname $1)/.sdc-out\" $1")
    var err = ""
    let res = editOne("foo.service", vendor / "foo.service", r, EditOpts(), "", err)
    check res == erChanged
    check readFile(r.etc / "systemd/system/foo.service.d/override.conf") == "[Service]\nNice=3\n"
    removeFile(r.etc / "systemd/system/foo.service.d/.sdc-out") 
  test "unchanged and empty":
    discard editor("true")
    var err = ""
    check editOne("foo.service", vendor / "foo.service", r, EditOpts(), "", err) == erUnchanged
    discard editor(": > $1")
    check editOne("foo.service", vendor / "foo.service", r, EditOpts(dropin: "x"), "", err) == erEmpty
    check not fileExists(r.etc / "systemd/system/foo.service.d/x.conf")
  test "runtime directory and --full copy the original":
    discard editor("echo '# edited' >> $1")
    var err = ""
    check editOne("foo.service", vendor / "foo.service", r, EditOpts(full: true, runtime: true), "", err) == erChanged
    let p = r.sysrun / "system/foo.service"
    check readFile(p) == "[Service]\nExecStart=/bin/true\n# edited\n"
    # editing it again edits in place
    check editOne("foo.service", p, r, EditOpts(full: true, runtime: true), "", err) == erChanged
    check readFile(p).count("# edited") == 2
  test "stdin and editor failure":
    var err = ""
    check editOne("bar.service", "", r, EditOpts(fromStdin: true, force: true), "[Service]\nX=1", err) == erChanged
    check readFile(r.etc / "systemd/system/bar.service.d/override.conf") == "[Service]\nX=1\n"
    discard editor("exit 1")
    check editOne("foo.service", vendor / "foo.service", r, EditOpts(dropin: "y.conf"), "", err) == erFailed
  removeDir(base)
