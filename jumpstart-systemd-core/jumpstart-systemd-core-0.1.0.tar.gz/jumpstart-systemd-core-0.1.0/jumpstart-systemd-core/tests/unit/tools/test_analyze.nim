import std/[unittest, options, json, algorithm, strutils]
import tools/analyze

suite "systemd-analyze helpers":
  test "calendar normalization":
    check normalizeCalendar("daily") == "*-*-* 00:00:00"
    check normalizeCalendar("Mon..Fri 9:00") == "Mon..Fri *-*-* 09:00:00"
    check normalizeCalendar("*-*-1 4:5") == "*-*-01 04:05:00"
    check normalizeCalendar("2026-3-4") == "2026-03-04 00:00:00"
    check normalizeCalendar("monday") == "Mon *-*-* 00:00:00"
    check normalizeCalendar("12:00 UTC") == "*-*-* 12:00:00 UTC"
    check normalizeCalendar("tuesday,mon 10:30:15") == "Tue,Mon *-*-* 10:30:15"
  test "timestamps":
    check parseTimestamp("@100", 5) == some(100'i64)
    check parseTimestamp("now", 5) == some(5'i64)
    check parseTimestamp("+1h", 100) == some(3700'i64)
    check parseTimestamp("1h ago", 7200) == some(3600'i64)
    check parseTimestamp("1970-01-02 00:00:01", 0) == some(86401'i64)
    check parseTimestamp("nonsense", 0).isNone
  test "durations":
    check fmtDur(500) == "500us"
    check fmtDur(1_500) == "1ms"
    check fmtDur(1_234_000) == "1.234s"
    check fmtDur(61_005_000) == "1min 1.005s"

suite "systemd-analyze listings":
  test "capability":
    let lines = capabilityLines()
    check lines.len == 41
    check lines[0] == "cap_chown (0)"
    check lines[12] == "cap_net_admin (12)"
    check lines[40] == "cap_checkpoint_restore (40)"
  test "syscall-filter without names":
    let r = syscallFilterLines(@[])
    check r.error == ""
    check r.lines.len == 2 * 29
    check r.lines[0] == "@aio"
    check r.lines[1] == "    io_cancel io_destroy io_getevents io_pgetevents io_pgetevents_time64 " &
      "io_setup io_submit io_uring_enter io_uring_register io_uring_setup"
    var headers: seq[string]
    for i in countup(0, r.lines.len - 1, 2): headers.add r.lines[i]
    check headers == sorted(headers)
    # A group member stays as a group name.
    let priv = syscallFilterLines(@["privileged"])
    check priv.lines == @["@privileged", "    @chown @clock @module @raw-io @reboot @swap @setuid " &
      "_sysctl acct bpf capset chroot fanotify_init fanotify_mark nfsservctl open_by_handle_at " &
      "pivot_root quotactl quotactl_fd setdomainname setfsuid setfsuid32 sethostname vhangup"]
  test "syscall-filter with names":
    check syscallFilterLines(@["swap"]).lines == @["@swap", "    swapoff swapon"]
    check syscallFilterLines(@["@sync"]).lines == syscallFilterLines(@["sync"]).lines
    check syscallFilterLines(@["@known"]).lines == syscallFilterLines(@[]).lines
    check syscallFilterLines(@["swap", "swap"]).lines == @["@swap", "    swapoff swapon"]
  test "syscall-filter unknown group":
    let r = syscallFilterLines(@["nosuch"])
    check r.lines.len == 0
    check r.error == "Unknown system call group: nosuch"
    let both = syscallFilterLines(@["swap", "@nosuch"])
    check both.lines.len == 0
    check both.error == "Unknown system call group: @nosuch"
  test "exit-status":
    let lines = exitStatusLines()
    check lines.len == 44
    check lines[0] == "200 CHDIR WorkingDirectory= (or RootDirectory= chdir) failed."
    check "201 NICE Nice= failed." in lines
    check "210 CHROOT RootDirectory= pivot_root/chroot failed." in lines
    check "221 CONFIRM Not used." in lines
    check "223" notin lines.join("\n")
    check "245 BPF Not used (device BPF failures are warnings)." in lines
    check lines[^1] == "126 (spawn layer) The spawn layer could not set up the child: reported as resources."

suite "systemd-analyze dot":
  test "edge colours and directions":
    let props = %*{"Requires": "a.service", "Requisite": "r.service",
      "Wants": "b.service c.service", "Conflicts": "d.service",
      "After": "a.service", "Before": "e.service"}
    let lines = dotEdges("x.service", props)
    check "\t\"x.service\" -> \"a.service\" [color=\"green\"];" in lines
    check "\t\"x.service\" -> \"r.service\" [color=\"green\"];" in lines
    check "\t\"x.service\" -> \"b.service\" [color=\"grey\", label=\"wants\"];" in lines
    check "\t\"x.service\" -> \"c.service\" [color=\"grey\", label=\"wants\"];" in lines
    check "\t\"x.service\" -> \"d.service\" [color=\"red\"];" in lines
    # After names the earlier unit, so the edge points at this one.
    check "\t\"a.service\" -> \"x.service\" [style=\"dashed\"];" in lines
    check "\t\"x.service\" -> \"e.service\" [style=\"dashed\"];" in lines
  test "duplicate relations print once":
    let props = %*{"Requires": "a.service a.service", "Requisite": "a.service",
      "After": "a.service a.service"}
    check dotEdges("x.service", props) == @[
      "\t\"x.service\" -> \"a.service\" [color=\"green\"];",
      "\t\"a.service\" -> \"x.service\" [style=\"dashed\"];"]
  test "empty and odd names":
    check dotEdges("x.service", newJObject()) == newSeq[string]()
    let props = %*{"Wants": "weird\"name.service"}
    check dotEdges("x.service", props) == @[
      "\t\"x.service\" -> \"weird\\\"name.service\" [color=\"grey\", label=\"wants\"];"]
