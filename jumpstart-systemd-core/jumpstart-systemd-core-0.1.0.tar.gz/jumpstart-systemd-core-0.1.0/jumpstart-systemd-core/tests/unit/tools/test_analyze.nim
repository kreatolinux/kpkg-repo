import std/[unittest, options]
import tools/analyze

suite "systemd-analyze helpers":
  test "calendar normalization":
    check normalizeCalendar("daily") == "*-*-* 00:00:00"
    check normalizeCalendar("Mon..Fri 9:00") == "Mon..Fri *-*-* 09:00:00"
    check normalizeCalendar("*-*-1 4:5") == "*-*-01 04:05:00"
    check normalizeCalendar("2026-3-4") == "2026-03-04 00:00:00"
    check normalizeCalendar("monday") == "Mon *-*-* 00:00:00"
    check normalizeCalendar("12:00 UTC") == "*-*-* 12:00:00 UTC"
    check normalizeCalendar("tuesday,mon 10:30:15") == "Tue,Mon *-*-* 10:30:15"
  test "timestamps":
    check parseTimestamp("@100", 5) == some(100'i64)
    check parseTimestamp("now", 5) == some(5'i64)
    check parseTimestamp("+1h", 100) == some(3700'i64)
    check parseTimestamp("1h ago", 7200) == some(3600'i64)
    check parseTimestamp("1970-01-02 00:00:01", 0) == some(86401'i64)
    check parseTimestamp("nonsense", 0).isNone
  test "durations":
    check fmtDur(500) == "500us"
    check fmtDur(1_500) == "1ms"
    check fmtDur(1_234_000) == "1.234s"
    check fmtDur(61_005_000) == "1min 1.005s"
