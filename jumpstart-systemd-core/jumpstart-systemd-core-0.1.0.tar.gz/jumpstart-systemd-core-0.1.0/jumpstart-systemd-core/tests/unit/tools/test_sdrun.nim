import std/[unittest, strutils]
import tools/sdrun

suite "systemd-run unit generation":
  test "quoting":
    check quoteWord("plain-word_1/x") == "plain-word_1/x"
    check quoteWord("a b") == "\"a b\""
    check quoteWord("100%$x") == "\"100%%$$x\""
    check execLine(@["/bin/echo", ";", "a\"b"]) == "/bin/echo \\; \"a\\\"b\""
  test "service text":
    var o = RunOpts(command: @["/bin/echo", "hi there"], uid: "nobody", collect: true, remain: true,
                    props: @["MemoryMax=1G", "After=network.target"], env: @["A=b c"], description: "d")
    let u = buildUnits(o, "run-x")
    check u.len == 1 and u[0][0] == "run-x.service"
    let t = u[0][1]
    check "Description=d\n" in t and "CollectMode=inactive-or-failed" in t
    check "After=network.target" in t.split("[Service]")[0]
    check "MemoryMax=1G" in t.split("[Service]")[1] and "User=nobody" in t and "RemainAfterExit=yes" in t
    check "Environment=\"A=b c\"" in t and "ExecStart=/bin/echo \"hi there\"" in t
  test "timer text":
    var o = RunOpts(command: @["/bin/true"], onTimers: @[("OnCalendar", "daily"), ("OnActiveSec", "5s")],
                    timerProps: @["Persistent=yes"])
    let u = buildUnits(o, "run-y")
    check u.len == 2 and u[1][0] == "run-y.timer"
    check "OnCalendar=daily\nOnActiveSec=5s\n" in u[1][1] and "Persistent=yes" in u[1][1]
    check "RemainAfterElapse=no" in u[1][1]
  test "tty and pipe stdio":
    var o = RunOpts(command: @["/bin/true"])
    check "TTYPath=/dev/pts/3" in buildUnits(o, "r", "/dev/pts/3")[0][1]
    check "StandardOutput=append:/proc/42/fd/1" in buildUnits(o, "r", "", true, 42)[0][1]
