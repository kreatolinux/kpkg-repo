import std/[unittest, strutils]
import tools/extra

suite "systemd-cat":
  test "priority names and numbers":
    check parsePriority("emerg") == 0
    check parsePriority("alert") == 1
    check parsePriority("crit") == 2
    check parsePriority("err") == 3
    check parsePriority("error") == 3
    check parsePriority("fatal") == 2
    check parsePriority("warning") == 4
    check parsePriority("warn") == 4
    check parsePriority("notice") == 5
    check parsePriority("info") == 6
    check parsePriority("debug") == 7
    check parsePriority("DEBUG") == 7
    check parsePriority("0") == 0 and parsePriority("7") == 7
    check parsePriority("8") == -1
    check parsePriority("loud") == -1

  test "level prefix":
    let p = splitLevelPrefix("<3>disk full")
    check p.found and p.priority == 3 and p.message == "disk full"
    let empty = splitLevelPrefix("<0>")
    check empty.found and empty.priority == 0 and empty.message == ""
    let kept = splitLevelPrefix("<9>not a priority")
    check not kept.found and kept.message == "<9>not a priority"
    check not splitLevelPrefix("plain line").found
    check not splitLevelPrefix("").found

  test "options, identifier and command":
    var a = CatOpts(identifier: "cat", priority: 6)
    var err = ""
    check parseCatArgs(@[], a, err) and a.identifier == "cat" and a.priority == 6
    check a.command.len == 0 and not a.levelPrefix and not a.stderrPriority
    var b = CatOpts(identifier: "cat", priority: 6)
    check parseCatArgs(@["-t", "web", "-p", "warning", "--level-prefix=yes",
                         "--stderr-priority", "/bin/sh", "-c", "echo hi"], b, err)
    check b.identifier == "web" and b.priority == 4
    check b.levelPrefix and b.stderrPriority
    check b.command == @["/bin/sh", "-c", "echo hi"]      # -c belongs to the command
    var c = CatOpts(identifier: "cat", priority: 6)
    check parseCatArgs(@["--identifier=web2", "--level-prefix", "no", "-tshort", "x"], c, err)
    check c.identifier == "short" and not c.levelPrefix and c.command == @["x"]
    var d = CatOpts(identifier: "cat", priority: 6)
    check parseCatArgs(@["--", "-p", "x"], d, err) and d.command == @["-p", "x"]
    var e = CatOpts(identifier: "cat", priority: 6)
    check not parseCatArgs(@["-p", "loud"], e, err) and err.len > 0
    var f = CatOpts(identifier: "cat", priority: 6)
    check not parseCatArgs(@["--bogus"], f, err) and err.len > 0

  test "entry fields":
    check entryFields("cat", 6, "hello") ==
      @[("MESSAGE", "hello"), ("PRIORITY", "6"), ("SYSLOG_IDENTIFIER", "cat")]

suite "systemd-detect-virt":
  test "decision table":
    check detectVirt(Probe()) == "none"
    check containerId(Probe()) == "" and vmId(Probe()) == ""
    check detectVirt(Probe(hypervisorFlag: true)) == "kvm"
    check detectVirt(Probe(sysVendor: "QEMU")) == "kvm"
    check detectVirt(Probe(sysVendor: "Amazon EC2")) == "amazon"
    check detectVirt(Probe(sysVendor: "Apple Inc.")) == "apple"
    check detectVirt(Probe(productName: "VirtualBox")) == "oracle"
    check detectVirt(Probe(productName: "VMware Virtual Platform")) == "vmware"
    check detectVirt(Probe(biosVendor: "innotek GmbH")) == "oracle"
    check detectVirt(Probe(hypervisorType: "xen")) == "xen"
    check detectVirt(Probe(dockerenv: true)) == "docker"
    check detectVirt(Probe(systemdContainer: "lxc")) == "lxc"
    check detectVirt(Probe(systemdContainer: "lxc-libvirt")) == "lxc-libvirt"
    check detectVirt(Probe(containerEnv: "podman")) == "podman"
    check detectVirt(Probe(systemdContainer: "mystery")) == "container-other"
    check detectVirt(Probe(procVz: true)) == "openvz"
    check detectVirt(Probe(procVz: true, procBc: true)) == "none"
    check detectVirt(Probe(uidMapPrivate: true)) == "container-other"

  test "containers win over VMs, chroot only when nothing else":
    check detectVirt(Probe(dockerenv: true, hypervisorFlag: true, sysVendor: "QEMU")) == "docker"
    check detectVirt(Probe(systemdContainer: "podman", hypervisorFlag: true)) == "podman"
    check detectVirt(Probe(chroot: true)) == "chroot"
    check detectVirt(Probe(chroot: true, sysVendor: "QEMU")) == "kvm"
    check detectVirt(Probe(chroot: true, dockerenv: true)) == "docker"

  test "filesystem markers":
    check not uidMapIsPrivate("")
    check not uidMapIsPrivate("0 0 4294967295\n")
    check uidMapIsPrivate("1000 0 65536\n")
    check uidMapIsPrivate("0 0 65536\n")
    check uidMapIsPrivate("0 0 4294967295\n1000 0 65536\n")
    check cpuInfoHasHypervisor("processor\t: 0\nflags\t\t: fpu vme hypervisor lm\n")
    check not cpuInfoHasHypervisor("processor\t: 0\nflags\t\t: fpu vme lm\n")

suite "systemd-id128":
  test "normalizing and formatting":
    const id = "0123456789abcdef0123456789abcdef"
    const grouped = "01234567-89ab-cdef-0123-456789abcdef"
    check normalizeId(id) == id
    check normalizeId("01234567-89AB-CDEF-0123-456789ABCDEF") == id
    check normalizeId(" 0123456789abcdef0123456789abcdef\n") == id
    check normalizeId("0123456789abcdef0123456789abcde") == ""
    check normalizeId("0123456789abcdef0123456789abcdeg") == ""
    check pretty(id) == grouped
    check pretty("short") == ""
    check uuid("01234567-89AB-CDEF-0123-456789ABCDEF") == grouped
    check uuid(id) == grouped
    check uuid("nope") == ""

  test "new ids are random and lowercase":
    let a = newId()
    check a.len == 32 and a.allCharsInSet({'0' .. '9', 'a' .. 'f'})
    check newId() != a
    check pretty(a) == uuid(a)

suite "systemd-inhibit":
  test "options are accepted and ignored":
    var a: InhibitOpts
    var err = ""
    check parseInhibitArgs(@["--what=sleep", "--who=me", "--why=testing",
                             "--mode=delay", "sleep", "10"], a, err)
    check a.what == "sleep" and a.who == "me" and a.why == "testing" and a.mode == "delay"
    check a.command == @["sleep", "10"] and not a.list
    var b: InhibitOpts
    check parseInhibitArgs(@["--mode=block-weak", "--why", "x", "--", "--list"], b, err)
    check b.mode == "block-weak" and b.why == "x" and not b.list
    check b.command == @["--list"]
    var c: InhibitOpts
    check not parseInhibitArgs(@["--mode=forever"], c, err) and err.len > 0
    var d: InhibitOpts
    check not parseInhibitArgs(@["--bogus"], d, err) and err.len > 0

  test "--list prints nothing, a missing command is an error":
    check inhibitMain(@["--list"]) == 0
    check inhibitMain(@["--list", "sleep", "10"]) == 0
    check inhibitMain(@[]) == 1
    check InhibitWarning.len > 0 and '\n' notin InhibitWarning
