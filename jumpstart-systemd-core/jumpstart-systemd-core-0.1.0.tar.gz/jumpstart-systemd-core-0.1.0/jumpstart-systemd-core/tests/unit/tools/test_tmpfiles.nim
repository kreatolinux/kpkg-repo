import std/[os, strutils, unittest, posix, options, times]
import tools/tmpfiles

proc settings(root: string): Settings =
  Settings(root: root, uid: int(getuid()), gid: int(getgid()), home: "/root", hostname: "h", machineId: "mid",
           userName: "u", groupName: "g")

proc run(root: string; conf: string; create = true; remove = false; clean = false; boot = false;
         prefixes: seq[string] = @[]; excludes: seq[string] = @[]): Settings =
  result = settings(root)
  result.create = create
  result.remove = remove
  result.clean = clean
  result.boot = boot
  result.prefixes = prefixes
  result.excludes = excludes
  var items: seq[TmpLine]
  let f = root / "test.conf"
  writeFile(f, conf)
  readLines(result, @[f], items)
  runItems(result, items)

suite "tmpfiles.d parsing":
  let s = settings("/x")
  test "fields, modifiers and specifiers":
    var err = ""
    let l = parseLine(s, "f+! /run/%m/x 0640 root - 10d \"a b\"", "t", 1, err).get
    check err == "" and l.typ == 'f' and l.replace and l.bootOnly and l.path == "/run/mid/x"
    check l.mode == "0640" and l.age == "10d" and l.arg == "a b"
    check parseLine(s, "# c", "t", 1, err).isNone and err == ""
  test "errors":
    var err = ""
    check parseLine(s, "q2 /x", "t", 1, err).isNone and err.len > 0
    err = ""
    check parseLine(s, "d relative", "t", 1, err).isNone and "absolute" in err
    err = ""
    check parseLine(s, "d /x 09zz", "t", 1, err).isNone and "mode" in err
  test "escapes":
    check unescapeC("a\\nb\\x41\\101\\\\") == "a\nbAA\\"

suite "tmpfiles types":
  let root = getTempDir() / ("sdc-tmpf-" & $getpid())
  removeDir(root)
  createDir(root)
  test "d f F w L p z":
    discard run(root, "d /d1 0750\nf /d1/f 0640 - - - hello\nF /d1/g 0644 - - - one\nf /d1/h\nL /d1/l - - - - /d1/f\np /d1/p 0600\nd /d1/sub/deep\n")
    check dirExists(root / "d1") and (getFilePermissions(root / "d1") == {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec})
    check readFile(root / "d1/f") == "hello"
    check expandSymlink(root / "d1/l") == "/d1/f"
    check dirExists(root / "d1/sub/deep")
    var st: Stat
    check lstat((root / "d1/p").cstring, st) == 0 and S_ISFIFO(st.st_mode)
    # f does not rewrite, F truncates, w writes only to existing files
    discard run(root, "f /d1/f - - - - changed\nF /d1/g - - - - two\nw /d1/f - - - - W\nw /d1/missing - - - - x\nz /d1/f 0600\n")
    check readFile(root / "d1/f") == "W"
    check readFile(root / "d1/g") == "two"
    check not fileExists(root / "d1/missing")
    check getFilePermissions(root / "d1/f") == {fpUserRead, fpUserWrite}
  test "w+ appends, f+ truncates":
    writeFile(root / "ap", "a")
    discard run(root, "w+ /ap - - - - b\nf+ /fp - - - - c\n")
    check readFile(root / "ap") == "ab"
    discard run(root, "f+ /fp - - - - d\n")
    check readFile(root / "fp") == "d"
  test "r R D remove":
    createDir(root / "rm/inner")
    writeFile(root / "rm/inner/x", "")
    writeFile(root / "rm/file", "")
    createDir(root / "dd")
    writeFile(root / "dd/keep", "")
    discard run(root, "r /rm/file\nR /rm/inner\nD /dd\n", create = false, remove = true)
    check not fileExists(root / "rm/file") and not dirExists(root / "rm/inner")
    check dirExists(root / "dd") and not fileExists(root / "dd/keep")
  test "boot only, prefix and exclude":
    discard run(root, "d! /boot1\nd /pre1/a\nd /pre2/b\n", prefixes = @["/pre1", "/boot1"])
    check not dirExists(root / "boot1") and dirExists(root / "pre1/a") and not dirExists(root / "pre2")
    discard run(root, "d! /boot1\nd /ex1\nd /ex2\n", boot = true, excludes = @["/ex1"])
    check dirExists(root / "boot1") and not dirExists(root / "ex1") and dirExists(root / "ex2")
  test "errors set the status, '-' ignores them":
    writeFile(root / "afile", "")
    check run(root, "d /afile\n").errors == 1
    check run(root, "d- /afile\n").errors == 0
  test "duplicate lines are ignored":
    var s = run(root, "d /dup 0700\nd /dup 0755\n")
    check getFilePermissions(root / "dup") == {fpUserRead, fpUserWrite, fpUserExec}
  test "C copies a tree once":
    createDir(root / "src/sub")
    writeFile(root / "src/sub/f", "data")
    discard run(root, "C /cp - - - - /src\n")
    check readFile(root / "cp/sub/f") == "data"
    writeFile(root / "cp/sub/f", "changed")
    discard run(root, "C /cp - - - - /src\n")
    check readFile(root / "cp/sub/f") == "changed"
  test "skipped types do not fail":
    check run(root, "a /afile - - - - u:root:rwx\nt /afile - - - - user.x=1\n").errors == 0
  test "clean by age keeps young and excluded entries":
    createDir(root / "cl/old")
    createDir(root / "cl/keepdir")
    writeFile(root / "cl/old/f", "")
    writeFile(root / "cl/young", "")
    writeFile(root / "cl/keepdir/f", "")
    writeFile(root / "cl/skip", "")
    let past = getTime() - initDuration(days = 3)
    for p in ["cl/old/f", "cl/old", "cl/keepdir/f", "cl/skip"]:
      setLastModificationTime(root / p, past)
      var tv: array[2, Timeval]
      tv[0] = Timeval(tv_sec: posix.Time(past.toUnix), tv_usec: 0)
      tv[1] = tv[0]
      discard utimes((root / p).cstring, addr tv)
    discard run(root, "d /cl 0755 - - m:1d\nx /cl/skip\nX /cl/keepdir\n", create = false, clean = true)
    check not dirExists(root / "cl/old") and fileExists(root / "cl/young")
    check fileExists(root / "cl/skip") and fileExists(root / "cl/keepdir/f")
  removeDir(root)
