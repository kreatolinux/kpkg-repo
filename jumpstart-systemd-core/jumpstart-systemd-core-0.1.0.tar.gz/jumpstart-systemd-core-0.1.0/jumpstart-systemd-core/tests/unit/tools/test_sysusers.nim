import std/[os, strutils, unittest, posix, options]
import tools/sysusers

proc parse(text: string): seq[SuLine] =
  var n = 0
  for l in text.splitLines:
    inc n
    var err = ""
    let p = parseSuLine(l, "t", n, err)
    doAssert err == "", err
    if p.isSome: result.add p.get

suite "sysusers.d":
  let root = getTempDir() / ("sdc-sysu-" & $getpid())
  removeDir(root)
  createDir(root / "etc")
  writeFile(root / "etc/passwd", "root:x:0:0:root:/root:/bin/sh\nold:x:999:998::/:/bin/false\n")
  writeFile(root / "etc/group", "root:x:0:\nold:x:998:\n")
  writeFile(root / "etc/shadow", "root:*:1::::::\nold:!*:1::::::\n")
  writeFile(root / "etc/gshadow", "root:!::\nold:!::\n")
  test "parse":
    let l = parse("u! web 200:300 \"Web server\" /srv/web /bin/sh")[0]
    check l.typ == 'u' and l.locked and l.name == "web" and l.id == "200:300" and l.gecos == "Web server"
    check l.home == "/srv/web" and l.shell == "/bin/sh"
    var err = ""
    check parseSuLine("x foo", "t", 1, err).isNone and err.len > 0
  test "users, groups and members; allocation from SYS_UID_MAX down skips used ids":
    check applyLines(root, parse("g wheel -\nu alpha - \"Alpha\" /var/alpha\nu beta 450 \"Beta\"\nm alpha wheel\nu gamma 460:wheel\n")) == 0
    let pw = readFile(root / "etc/passwd")
    check "alpha:x:997:" in pw          # 999 (old) and 998 (old group) are taken, wheel took 999 as a gid
  test "details":
    let pw = readFile(root / "etc/passwd").splitLines
    var alpha, beta, gamma: string
    for l in pw:
      if l.startsWith("alpha:"): alpha = l
      if l.startsWith("beta:"): beta = l
      if l.startsWith("gamma:"): gamma = l
    check alpha.len > 0 and alpha.endsWith(":Alpha:/var/alpha:/usr/sbin/nologin")
    check beta == "beta:x:450:450:Beta:/:/usr/sbin/nologin"
    let gr = readFile(root / "etc/group")
    check "beta:x:450:" in gr
    check "wheel:x:" in gr and ":alpha" in gr
    check gamma.startsWith("gamma:x:460:")
    check "alpha:!*:" in readFile(root / "etc/shadow")
    check "wheel:!::alpha" in readFile(root / "etc/gshadow")
  test "idempotent; existing entries are never rewritten":
    let before = readFile(root / "etc/passwd")
    check applyLines(root, parse("u alpha 777 \"Different\"\nu old - \"x\"\ng wheel 123\nm alpha wheel\n")) == 0
    check readFile(root / "etc/passwd") == before
  test "conflicting static ids fail":
    check applyLines(root, parse("u clash 450 \"x\"\n")) == 1
  test "reserved ranges are not allocated":
    writeFile(root / "etc/login.defs", "SYS_UID_MIN 100\nSYS_UID_MAX 300\n")
    check applyLines(root, parse("r - 295-300\nu delta - \"D\"\n")) == 0
    check "delta:x:294:" in readFile(root / "etc/passwd")
  removeDir(root)
