import std/unittest
import tools/sysinit

suite "sysctl parsing":
  test "comments, assignments and the -key prefix":
    let s = parseSysctlConf("""
# comment
; another comment
   # an indented one

net.ipv4.ip_forward = 1
-kernel.printk = 4 1 1 7
  net/core/somaxconn=4096
not an assignment
""")
    check s.len == 3
    check s[0].key == "net.ipv4.ip_forward" and s[0].value == "1" and not s[0].ignoreErrors
    check s[1].ignoreErrors and s[1].key == "kernel.printk" and s[1].value == "4 1 1 7"
    check s[2].key == "net/core/somaxconn" and s[2].value == "4096"

  test "duplicates are kept in order, so the last assignment wins":
    let s = parseSysctlConf("net.ipv4.ip_forward = 0\n-net.ipv4.ip_forward=1\n")
    check s.len == 2 and s[0].value == "0" and s[1].value == "1" and s[1].ignoreErrors

  test "glob keys":
    let s = parseSysctlConf("net.ipv4.conf.*.rp_filter = 1\n")
    check s.len == 1 and s[0].key == "net.ipv4.conf.*.rp_filter"
    check hasGlob(s[0].key) and not hasGlob("net.ipv4.ip_forward")
    check matchGlob("*", "eth0") and matchGlob("eth?", "eth0") and not matchGlob("eth?", "eth00")
    check matchGlob("conf.*.rp_filter", "conf.all.rp_filter")
    check matchGlob("*", "") and not matchGlob("?", "")

  test "paths below /proc/sys and below --prefix":
    check sysctlPath("net.ipv4.ip_forward") == "/proc/sys/net/ipv4/ip_forward"
    check sysctlPath("net.ipv4.ip_forward", "/tmp/root") == "/tmp/root/net/ipv4/ip_forward"
    check sysctlPath("net.ipv4.ip_forward", "/tmp/root/") == "/tmp/root/net/ipv4/ip_forward"
    check sysctlPath("net.ipv4.conf.*.rp_filter", "/p") == "/p/net/ipv4/conf/*/rp_filter"

  test "configuration directories are merged-usr aware and sysctl.conf is last":
    let merged = sysctlDirs(true)
    check merged.len == 4 and merged[0] == "/etc/sysctl.d" and "/lib/sysctl.d" notin merged
    check sysctlConfigPaths(true)[^1] == "/etc/sysctl.conf"
    let unmerged = sysctlDirs(false)
    check unmerged.len == 5 and unmerged[^1] == "/lib/sysctl.d"
    check sysctlConfigPaths(false).len == 6

  test "a name found in several directories is taken from the highest priority one":
    let files = mergeConfFiles(@["/etc/sysctl.d", "/run/sysctl.d", "/usr/lib/sysctl.d"],
      @[@["60-a.conf"], @["50-b.conf"], @["60-a.conf", "10-c.conf"]])
    check files == @["/usr/lib/sysctl.d/10-c.conf", "/run/sysctl.d/50-b.conf", "/etc/sysctl.d/60-a.conf"]

suite "modules-load parsing":
  test "comments and blank lines":
    check parseModulesConf("""
# comment
; comment
  # indented

dm_crypt
  loop
""") == @["dm_crypt", "loop"]

  test "the kernel command line":
    check modulesFromCmdline("ro quiet modules_load=dm_crypt,loop modules_load=vfat") ==
      @["dm_crypt", "loop", "vfat"]
    check modulesFromCmdline("root=/dev/sda1 rw systemd.unit=rescue.target").len == 0
    check modulesFromCmdline("rd.modules_load=a,b") == @["a", "b"]

  test "dedupe keeps the first-seen order":
    check dedupeModules(@["loop", "dm-crypt", "dm_crypt", "loop", "vfat"]) == @["loop", "dm-crypt", "vfat"]

  test "directories are merged-usr aware":
    check moduleDirs(true).len == 4 and "/lib/modules-load.d" notin moduleDirs(true)
    check moduleDirs(false).len == 5 and moduleDirs(false)[^1] == "/lib/modules-load.d"

suite "fsck":
  test "command line defaults and overrides":
    check parseFsckCmdline("") == (fmAuto, frPreen)
    check parseFsckCmdline("root=/dev/sda1 rw quiet") == (fmAuto, frPreen)
    check parseFsckCmdline("fsck.mode=force") == (fmForce, frPreen)
    check parseFsckCmdline("fsck.mode=skip fsck.repair=no") == (fmSkip, frNo)
    check parseFsckCmdline("fsck.repair=yes") == (fmAuto, frYes)
    check parseFsckCmdline("fsck.mode=bogus fsck.repair=bogus") == (fmAuto, frPreen)
    check parseFsckCmdline("fastboot") == (fmSkip, frPreen)
    check parseFsckCmdline("forcefsck fsck.mode=auto") == (fmAuto, frPreen)

  test "argv":
    check fsckArgv(fmAuto, frPreen, "/dev/sda1") == @["fsck", "-a", "-T", "-l", "/dev/sda1"]
    check fsckArgv(fmAuto, frNo, "/dev/sda1")[1] == "-n"
    check fsckArgv(fmAuto, frYes, "/dev/sda1")[1] == "-y"
    check "-f" in fsckArgv(fmForce, frPreen, "/dev/sda1")
    check fsckArgv(fmForce, frPreen, "/dev/sda1")[^1] == "/dev/sda1"
    check fsckArgv(fmSkip, frPreen, "/dev/sda1").len == 0

  test "exit status mapping":
    check mapFsckStatus(0) == 0 and mapFsckStatus(1) == 0
    check mapFsckStatus(2) == 0 and needsReboot(2) and not needsReboot(1) and not needsReboot(0)
    check mapFsckStatus(4) == 1 and mapFsckStatus(8) == 1
    check mapFsckStatus(16) == 1 and mapFsckStatus(32) == 1 and mapFsckStatus(128) == 1
    check mapFsckStatus(3) == 0 and needsReboot(3)
    check mapFsckStatus(6) == 1 and needsReboot(6)

suite "remount-fs":
  test "/ and /usr from fstab":
    let plan = remountPlan("""
/dev/vda1 /     ext4 defaults,noatime 0 1
/dev/vda2 /usr  ext4 ro,bind          0 2
/dev/vda3 /home ext4 rw,noatime       0 2
""", "")
    check plan.len == 2
    check plan[0].target == "/" and plan[0].options == "rw"
    check plan[1].target == "/usr" and plan[1].options == "ro,bind"

  test "no fstab entry follows the ro/rw kernel command line":
    let ro = remountPlan("", "root=/dev/sda1 ro quiet")
    check ro.len == 1 and ro[0].target == "/" and ro[0].options == "ro"
    check remountPlan("", "ro rw")[0].options == "rw"
    check remountPlan("", "rw ro")[0].options == "ro"

  test "neither fstab nor command line means read-write":
    let plan = remountPlan("", "")
    check plan.len == 1 and plan[0].target == "/" and plan[0].options == "rw"

  test "/usr is only remounted when fstab mounts it":
    let plan = remountPlan("/dev/x /usr ext4 defaults 0 2\n", "ro")
    check plan.len == 2 and plan[1].target == "/usr" and plan[1].options == "ro"

  test "mount arguments":
    check remountArgv("/", "rw") == @["mount", "-o", "remount,rw", "/"]
    check remountArgv("/usr", "ro,bind") == @["mount", "-o", "remount,ro,bind", "/usr"]
    check remountArgv("/usr", "") == @["mount", "-o", "remount", "/usr"]
