import std/[options, unittest]
import executor/context

suite "exec context":
  test "round trip":
    var s = ExecSpec(version: ContextVersion, unit: "a.service", path: "/bin/true",
      args: @["-c", "$FOO"], environment: @[("FOO", "bar")], umask: 0o27,
      nice: some(5), limits: @[LimitSpec(resource: "NOFILE", soft: 100, hard: -1)])
    s.stdout = StdioSpec(kind: "file", path: "/tmp/x")
    let back = parseContext(toContextJson(s))
    check back == s
  test "sandbox, seccomp, capability and credential settings round trip":
    var s = ExecSpec(version: ContextVersion, unit: "a.service", path: "/bin/true", umask: -1)
    s.sandbox = SandboxSpec(privateTmp: true, protectSystem: "strict", protectHome: "tmpfs",
      bindPaths: @["-/a:/b:ro"], temporaryFileSystem: @["/x:size=1M"], rootDirectory: "/srv/root",
      sysrun: "/run/systemd", extraBinds: @["/run/systemd/notify"])
    s.seccomp = SeccompSpec(systemCallFilter: @["@system-service", "~@privileged:EPERM"],
      restrictAddressFamilies: @["AF_UNIX"], memoryDenyWriteExecute: true)
    s.capabilityBoundingSet = @["~CAP_SYS_ADMIN"]
    s.dynamicUser = true
    s.dynamicUsersDir = "/var/lib/systemd-compat/dynamic-users"
    s.credentials = CredentialSpec(root: "/run/credentials", setCredential: @["k:v"], importCredential: @["foo.*"])
    check parseContext(toContextJson(s)) == s
  test "a context without the new fields still parses":
    let s = parseContext("""{"version": 1, "unit": "a.service", "path": "/bin/true"}""")
    check s.sandbox == SandboxSpec() and s.seccomp == SeccompSpec() and not s.dynamicUser
  test "wrong version rejected":
    expect ValueError: discard parseContext("""{"version": 99}""")
