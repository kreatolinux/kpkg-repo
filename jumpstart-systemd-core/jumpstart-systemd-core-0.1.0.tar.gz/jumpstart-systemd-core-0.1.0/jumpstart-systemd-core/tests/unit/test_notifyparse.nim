import std/[options, unittest]
from std/strutils import repeat
import service/notifyparse

suite "sd_notify parsing":
  test "common keys":
    let m = parseNotify("READY=1\nSTATUS=hello world\nMAINPID=1234\nERRNO=2\nbogus\nX=y")
    check m.ready and m.status.get == "hello world" and m.mainPid.get == 1234 and m.errNo.get == 2
    check not m.stopping and m.watchdog == wdNone
  test "watchdog and timeouts":
    check parseNotify("WATCHDOG=1").watchdog == wdPing
    check parseNotify("WATCHDOG=trigger").watchdog == wdTrigger
    check parseNotify("WATCHDOG_USEC=5000000").watchdogUsec.get == 5_000_000
    check parseNotify("EXTEND_TIMEOUT_USEC=1000").extendTimeoutUsec.get == 1000
    check parseNotify("EXTEND_TIMEOUT_USEC=" & "9".repeat(15)).extendTimeoutUsec.get ==
      MaxTimeoutExtensionUsec
  test "invalid values are ignored":
    check parseNotify("MAINPID=abc").mainPid.isNone
    check parseNotify("MAINPID=-4").mainPid.isNone
    check parseNotify("READY=0").ready == false
    check parseNotify("READY=1\n".repeat(1000)).ready == false   # over 4096 bytes: dropped
  test "status sanitizing":
    check sanitizeStatus("a\nb") == "a b"
    check sanitizeStatus("x".repeat(300)).len == 255
    check sanitizeStatus("\xc3\xa9".repeat(200)).len == 254        # not cut mid-sequence
