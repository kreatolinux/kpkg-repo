import std/[unittest, options, os, times]
import units/calendar

proc utc(y, mo, d, h, mi, s: int): int64 =
  dateTime(y, Month(mo), MonthdayRange(d), h, mi, s, zone = utc()).toTime.toUnix * 1_000_000

proc nxt(expr: string; after: int64): string =
  let p = parseCalendar(expr)
  if p.isNone: return "parse-error"
  let r = nextElapse(p.get, after)
  if r.isNone: return "never"
  fromUnix(r.get div 1_000_000).utc.format("yyyy-MM-dd HH:mm:ss")

suite "calendar events":
  let t0 = utc(2024, 3, 15, 10, 30, 45)     # a Friday
  test "shorthands":
    check nxt("minutely UTC", t0) == "2024-03-15 10:31:00"
    check nxt("hourly UTC", t0) == "2024-03-15 11:00:00"
    check nxt("daily UTC", t0) == "2024-03-16 00:00:00"
    check nxt("weekly UTC", t0) == "2024-03-18 00:00:00"
    check nxt("monthly UTC", t0) == "2024-04-01 00:00:00"
    check nxt("yearly UTC", t0) == "2025-01-01 00:00:00"
    check nxt("annually UTC", t0) == "2025-01-01 00:00:00"
    check nxt("quarterly UTC", t0) == "2024-04-01 00:00:00"
    check nxt("semiannually UTC", t0) == "2024-07-01 00:00:00"
  test "dates and times":
    check nxt("*-*-* 12:00:00 UTC", t0) == "2024-03-15 12:00:00"
    check nxt("12:00 UTC", t0) == "2024-03-15 12:00:00"
    check nxt("10:30 UTC", t0) == "2024-03-16 10:30:00"        # strictly after: 10:30:00 is past
    check nxt("2025-01-01 UTC", t0) == "2025-01-01 00:00:00"
    check nxt("2024-12-24 18:00 UTC", t0) == "2024-12-24 18:00:00"
    check nxt("2024-12-24T18:00:00 UTC", t0) == "2024-12-24 18:00:00"
    check nxt("*:0/15 UTC", t0) == "2024-03-15 10:45:00"
    check nxt("*:00,30:15 UTC", t0) == "2024-03-15 11:00:15"
    check nxt("*-*-* 08..17:00:00 UTC", t0) == "2024-03-15 11:00:00"
    check nxt("*-*-* 22:00/7:00 UTC", t0) == "2024-03-15 22:00:00"
    check nxt("*:*:0/20 UTC", t0) == "2024-03-15 10:31:00"
    check nxt("24-06-01 UTC", t0) == "2024-06-01 00:00:00"    # two-digit year
    check nxt("*-1,6-1 UTC", t0) == "2024-06-01 00:00:00"
  test "weekdays":
    check nxt("Mon UTC", t0) == "2024-03-18 00:00:00"
    check nxt("Sat,Sun 12:00 UTC", t0) == "2024-03-16 12:00:00"
    check nxt("Mon..Fri 09:00 UTC", t0) == "2024-03-18 09:00:00"
    check nxt("fri *-*-* 11:00 UTC", t0) == "2024-03-15 11:00:00"
    check nxt("Friday UTC", t0) == "2024-03-22 00:00:00"
  test "end of month":
    check nxt("*-*~1 UTC", t0) == "2024-03-31 00:00:00"
    check nxt("*-02~1 UTC", t0) == "2025-02-28 00:00:00"
    check nxt("*-02~3 UTC", t0) == "2025-02-26 00:00:00"
    check nxt("*-*-29 UTC", utc(2024, 3, 15, 0, 0, 0)) == "2024-03-29 00:00:00"
    check nxt("*-02-29 UTC", utc(2024, 3, 15, 0, 0, 0)) == "2028-02-29 00:00:00"   # next leap day
  test "fractional seconds":
    let p = parseCalendar("*:*:30.5 UTC").get
    check nextElapse(p, t0).get == utc(2024, 3, 15, 10, 31, 30) + 500_000
  test "errors":
    check not calendarValid("")
    check not calendarValid("nonsense")
    check not calendarValid("2020-02-30")
    check not calendarValid("25:00")
    check not calendarValid("*-13-01")
    check not calendarValid("Funday")
    check not calendarValid("12:00 No/Such_Zone")
    check calendarValid("*-*-* *:*:00")
    check calendarValid("Mon,Tue *-*-01..07 04:00:00")
  test "time zones":
    when not defined(macosx) or true:
      if fileExists("/usr/share/zoneinfo/Europe/Berlin"):
        # 2024-03-15 is CET (UTC+1): 12:00 Berlin is 11:00 UTC
        check nxt("12:00 Europe/Berlin", t0) == "2024-03-15 11:00:00"
        # DST gap 2024-03-31 02:30 does not exist in Berlin: the 02:30 daily elapse is skipped that day
        check nxt("*-*-31 02:30 Europe/Berlin", utc(2024, 3, 30, 12, 0, 0)) == "2024-05-31 00:30:00"
        # the overlap on 2024-10-27: 02:30 elapses once, at the first occurrence (00:30 UTC)
        check nxt("*-10-27 02:30 Europe/Berlin", utc(2024, 10, 26, 12, 0, 0)) == "2024-10-27 00:30:00"
        check nxt("*-10-27 02:30 Europe/Berlin", utc(2024, 10, 27, 0, 30, 0)) == "2025-10-27 01:30:00"
