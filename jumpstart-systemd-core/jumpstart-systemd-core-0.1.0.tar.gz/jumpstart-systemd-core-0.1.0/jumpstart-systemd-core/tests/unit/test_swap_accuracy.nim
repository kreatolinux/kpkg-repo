import std/[unittest, options]
import common/roots
import unitfile/[model, index]
import units/[swap, accuracy]

suite "/proc/swaps":
  test "parse":
    let t = "Filename\t\t\t\tType\t\tSize\t\tUsed\t\tPriority\n/dev/sda2\t\t\t\tpartition\t8388604\t\t0\t\t-2\n" &
            "/swap\\040file\t\t\t\tfile\t\t1024\t\t12\t\t5\nbroken\n"
    let e = parseProcSwaps(t)
    check e.len == 2
    check e[0].path == "/dev/sda2" and e[0].typ == "partition" and e[0].priority == -2 and e[0].size == 8388604
    check e[1].path == "/swap file" and e[1].used == 12 and e[1].priority == 5
  test "unit names and options":
    check swapUnitName("/dev/sda2") == "dev-sda2.swap"
    check swapOptionArgs("nofail,discard=pages,x") == @["--discard=pages"]
    check swapOptionArgs("discard") == @["--discard"]

suite "swap fstab":
  test "entries":
    let roots = testRoots("/tmp/sdc-swap-fstab", scSystem)
    let g = generateSwapFstab("/dev/sda1 / ext4 defaults 0 1\nUUID=ab-cd none swap pri=5,discard,nofail 0 0\n" &
      "/swapfile none swap sw,noauto 0 0\n", roots)
    check g.len == 2
    check g[0].name == "dev-disk-by\\x2duuid-ab\\x2dcd.swap"
    check g[0].def.swap.what == "/dev/disk/by-uuid/ab-cd" and g[0].def.swap.priority == some(5)
    check g[0].def.swap.options == "discard"
    check g[0].extraDeps == @[(dkWants, "swap.target", g[0].name)]
    check g[1].name == "swapfile.swap" and g[1].extraDeps.len == 0

suite "AccuracySec coalescing":
  const Sec = 1_000_000'i64
  test "no window fires at the elapse":
    check coalesce(1234, 0, 0) == 1234
    check coalesce(1234, 1, 0) == 1234
  test "latest minute boundary (plus perturbation) inside the window":
    # window [100 s, 160 s]: the minute grid point 120 s + perturbation 7 s
    check sleepBetween(100 * Sec, 160 * Sec, 7 * Sec) == 127 * Sec
  test "falls back to finer grids":
    # window [61 s, 69 s] holds no minute point; the 10 s grid (perturb 3 s) gives 63 s
    check sleepBetween(61 * Sec, 69 * Sec, 3 * Sec) == 63 * Sec
    # window [61.2 s, 61.8 s]: 1 s grid with perturb 0 has none, 250 ms grid gives 61.75 s
    check sleepBetween(61_200_000, 61_800_000, 0) == 61_750_000
  test "result stays within the window":
    for a in [1'i64, 999, 12_345_678, 987_654_321]:
      for acc in [2'i64, 1000, Sec, 60 * Sec]:
        for p in [0'i64, 17, 59_999_999]:
          let r = coalesce(a, acc, p)
          check r >= a and r <= a + acc
  test "perturbation from the machine id":
    check perturbOf("") == 0
    check perturbOf("00000000000000000000000000000000") == 0
    let p = perturbOf("0123456789abcdef0123456789abcdef")
    check p == 0
    check perturbOf("0123456789abcdef1123456789abcdef") > 0
