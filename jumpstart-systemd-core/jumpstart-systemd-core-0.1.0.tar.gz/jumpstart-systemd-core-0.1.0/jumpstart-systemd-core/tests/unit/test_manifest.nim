## init.kg declares exactly the registry's 54 operations; only unit.translate
## is unsupported; persistent entries share one executable and carry no sandbox
## (cores §11.3, §13.1, §13.3).
import std/[os, strutils, unittest]
import jumpstartcore/registry

const manifest = staticRead(currentSourcePath().parentDir.parentDir.parentDir / "init.kg")

suite "init.kg":
  var names: seq[string]
  for line in manifest.splitLines:
    let l = line.strip
    if l.startsWith("- name: \""): names.add l[9 .. ^2]
  test "completeness":
    var expected: seq[string]
    for s in registry(CurrentManifestVersion): expected.add s.name
    check names == expected and names.len == 54
  test "unit.translate is unsupported, nothing else is":
    check manifest.count("backend: \"unsupported\"") == 1
    check manifest.count("backend: \"exec\"") == 53
  test "persistent adapter entries are uniform":
    check manifest.count("mode: \"persistent\"") == 52
    check manifest.count("mode: \"oneshot\"") == 1 and manifest.count("sandbox: true") == 1
  test "supervisor and activation":
    check "executable: \"bin/systemd-compat-manager\"" in manifest
    check "activation: \"core\"" in manifest
