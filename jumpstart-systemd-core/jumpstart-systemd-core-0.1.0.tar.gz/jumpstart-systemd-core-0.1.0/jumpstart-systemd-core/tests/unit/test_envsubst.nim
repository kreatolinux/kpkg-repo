import std/[tables, unittest]
import executor/envsubst

suite "environment files":
  test "basic lines":
    var bad: seq[string]
    let r = parseEnvFile("# c\nA=1\n; c\nB = two words \nC=\"q\\\"x\"\nD='lit $x'\nE=a\\\nb\n=x\n1X=y\nF", bad)
    check r == @[("A", "1"), ("B", "two words"), ("C", "q\"x"), ("D", "lit $x"), ("E", "a\nb")]
    check bad.len == 3
suite "argument expansion":
  let env = {"A": "x y", "E": "", "P": "/p"}.toTable
  test "whole word split":
    check expandArgs(@["$A", "z"], env) == @["x", "y", "z"]
    check expandArgs(@["$UNSET"], env).len == 0
    check expandArgs(@["$E"], env).len == 0
  test "braces keep one argument":
    check expandArgs(@["${A}"], env) == @["x y"]
    check expandArgs(@["${E}"], env) == @[""]
    check expandArgs(@["${UNSET}"], env).len == 0
    check expandArgs(@["--p=${P}/f"], env) == @["--p=/p/f"]
    check expandArgs(@["--p=${UNSET}"], env) == @["--p="]
  test "dollar dollar and embedded plain":
    check expandArgs(@["$$HOME", "a$A"], env) == @["$HOME", "a$A"]
