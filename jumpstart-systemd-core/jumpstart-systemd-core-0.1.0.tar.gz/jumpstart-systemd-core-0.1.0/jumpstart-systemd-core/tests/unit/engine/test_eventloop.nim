import std/[posix, unittest]
import common/clock
import engine/eventloop

suite "event loop":
  test "timers fire in order and can be cancelled":
    let clock = FakeClock(mono: 1000, real: 0)
    let l = newEventLoop(clock)
    var fired: seq[int]
    discard l.addTimer(1300, proc() = fired.add 3)
    discard l.addTimer(1100, proc() = fired.add 1)
    let c = l.addTimer(1200, proc() = fired.add 2)
    l.cancelTimer(c)
    check l.fireDueTimers() == 0
    clock.advance(150)
    check l.fireDueTimers() == 1
    clock.advance(500)
    check l.fireDueTimers() == 1
    check fired == @[1, 3]
    check l.timerCount == 0

  test "a callback can schedule more work and deferred runs after the event":
    let l = newEventLoop(FakeClock(mono: 0))
    var log: seq[string]
    discard l.addTimer(0, proc() =
      l.afterEvent(proc() = log.add "deferred")
      log.add "timer")
    l.runOnce(0)
    check log == @["timer", "deferred"]

  test "fd watch reports readability":
    var fds: array[2, cint]
    check pipe(fds) == 0
    let l = newEventLoop()
    var got = 0
    let w = l.addFd(fds[0], EvIn, proc(ev: uint32) =
      var buf: array[8, char]
      got += int(read(fds[0], addr buf[0], 8)))
    discard write(fds[1], cstring"x", 1)
    l.runOnce(100)
    check got == 1
    l.delFd(w)
    discard write(fds[1], cstring"y", 1)
    l.runOnce(0)
    check got == 1
    discard close(fds[0]); discard close(fds[1])
