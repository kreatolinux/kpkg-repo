## Unit garbage collection: targets start without processes, so the whole
## mark-and-sweep can be exercised deterministically.
import std/[os, posix, unittest, tables]
import common/[roots, clock]
import unitfile/model
import engine/[types, graph, jobs, manager, eventloop, gc]

type Env = ref object
  m: Manager
  dir: string

var counter = 0

proc newEnv(): Env =
  inc counter
  let base = getTempDir() / ("sdc-gc-" & $getpid() & "-" & $counter)
  removeDir(base)
  let roots = testRoots(base, scSystem)
  createDir(roots.etc / "systemd/system")
  Env(m: newManager(roots), dir: roots.etc / "systemd/system")

proc unit(e: Env; name, text: string) =
  writeFile(e.dir / name, "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=0\n" & text)

proc settle(e: Env) =
  for _ in 0 ..< 6: e.m.loop.runOnce(0)

proc run(e: Env; name: string; typ = jtStart) =
  let u = e.m.lookup(name)
  doAssert u != nil, name
  discard submitJob(e.m, u, typ, jmReplace, joManual)
  e.settle

proc loaded(e: Env; name: string): bool = e.m.units.hasKey(name)

suite "garbage collection":
  test "an inactive unit nobody references is collected, and loads again on demand":
    let e = newEnv()
    e.unit("a.target", "Description=first\n")
    discard e.m.daemonReload()
    e.run("a.target")
    check e.m.units["a.target"].active == asActive      # active: kept
    e.run("a.target", jtStop)
    check not e.loaded("a.target")
    check e.m.lookup("a.target") != nil and e.m.units["a.target"].active == asInactive
    check e.m.collectGarbage() == 1                     # loaded by the query only: the next sweep drops it
    check not e.loaded("a.target")
  test "referenced units stay while a referencing unit stays":
    let e = newEnv()
    e.unit("top.target", "Wants=mid.target\n")
    e.unit("mid.target", "Wants=leaf.target\n")
    e.unit("leaf.target", "")
    discard e.m.daemonReload()
    e.run("top.target")
    check e.loaded("top.target") and e.loaded("mid.target") and e.loaded("leaf.target")
    e.run("leaf.target", jtStop)
    check e.loaded("leaf.target")                       # wanted by a unit that stays loaded
    e.run("mid.target", jtStop)
    check e.loaded("mid.target") and e.loaded("leaf.target")   # top.target is still active
    e.run("top.target", jtStop)
    check not e.loaded("top.target") and not e.loaded("mid.target") and not e.loaded("leaf.target")
    check e.m.aliases.len == 0 or "top.target" notin e.m.aliases
  test "after the referencing unit is collected the referenced one goes too":
    let e = newEnv()
    e.unit("p.target", "Requires=c.target\nAfter=c.target\n")
    e.unit("c.target", "")
    discard e.m.daemonReload()
    e.run("p.target")
    e.run("p.target", jtStop)
    check not e.loaded("p.target") and e.loaded("c.target")     # c.target is still active
    e.run("c.target", jtStop)
    check not e.loaded("c.target")
  test "units with a job are never collected":
    let e = newEnv()
    e.unit("j.target", "")
    discard e.m.daemonReload()
    let u = e.m.lookup("j.target")
    u.job = Job(id: 4242, unit: u, typ: jtStart)
    check e.m.collectGarbage() == 0 and e.loaded("j.target")
    u.job = nil
    check e.m.collectGarbage() == 1
  test "perpetual units are kept":
    let e = newEnv()
    e.unit("pp.target", "")
    discard e.m.daemonReload()
    let u = e.m.lookup("pp.target")
    u.perpetual = true
    e.settle
    check e.m.collectGarbage() == 0 and e.loaded("pp.target")
  test "failed units stay by default and go with CollectMode=inactive-or-failed":
    let e = newEnv()
    e.unit("keep.target", "")
    e.unit("drop.target", "CollectMode=inactive-or-failed\n")
    discard e.m.daemonReload()
    for n in ["keep.target", "drop.target"]:
      let u = e.m.lookup(n)
      e.m.failHook(e.m, u, "exit-code")
    e.settle
    check e.loaded("keep.target") and e.m.units["keep.target"].active == asFailed
    check not e.loaded("drop.target")
    # reset-failed lets the default mode go as well
    let k = e.m.units["keep.target"]
    if k.ops.resetFailed != nil: k.ops.resetFailed(e.m, k)
    else: e.m.units["keep.target"].active = asInactive
    discard e.m.collectGarbage()
    check not e.loaded("keep.target")
  test "aliases of a collected unit are forgotten":
    let e = newEnv()
    e.unit("real.target", "")
    createSymlink("real.target", e.dir / "other.target")
    discard e.m.daemonReload()
    e.run("other.target")
    check e.m.canonical("other.target") == "real.target"
    e.run("real.target", jtStop)
    check not e.loaded("real.target")
    check "other.target" notin e.m.aliases
    check e.m.lookup("other.target") != nil and e.m.units.hasKey("real.target")
  test "daemon-reload picks up changes for units that were collected, and collects newly unreferenced ones":
    let e = newEnv()
    e.unit("w.target", "Description=old\nWants=x.target\n")
    e.unit("x.target", "")
    discard e.m.daemonReload()
    e.run("w.target")
    check e.loaded("x.target")
    e.run("x.target", jtStop)
    check e.loaded("x.target")
    e.unit("w.target", "Description=new\n")             # w no longer wants x
    discard e.m.daemonReload()
    e.settle
    check e.loaded("w.target") and e.m.units["w.target"].def.common.description == "new"
    check not e.loaded("x.target")                      # collected by the sweep scheduled by the reload
    e.run("w.target", jtStop)
    check not e.loaded("w.target")
    e.unit("w.target", "Description=newer\n")
    discard e.m.daemonReload()
    check e.m.lookup("w.target").def.common.description == "newer"
  test "a unit file removed while loaded and inactive disappears with the reload":
    let e = newEnv()
    e.unit("gone.target", "")
    discard e.m.daemonReload()
    discard e.m.lookup("gone.target")
    removeFile(e.dir / "gone.target")
    discard e.m.daemonReload()
    check not e.loaded("gone.target") and e.m.lookup("gone.target") == nil
  test "no collection while the manager is stopping or booting":
    let e = newEnv()
    e.unit("s.target", "")
    discard e.m.daemonReload()
    discard e.m.lookup("s.target")
    e.m.stopping = true
    check e.m.collectGarbage() == 0 and e.loaded("s.target")
    e.m.stopping = false
    e.m.booting = true
    check e.m.collectGarbage() == 0
    e.m.booting = false
    check e.m.collectGarbage() == 1
  test "the periodic sweep collects units that only a query loaded":
    let clk = FakeClock(mono: 1000, real: 1_000_000)
    inc counter
    let base = getTempDir() / ("sdc-gc-" & $getpid() & "-" & $counter)
    removeDir(base)
    let roots = testRoots(base, scSystem)
    createDir(roots.etc / "systemd/system")
    let m = newManager(roots, clk)
    writeFile(roots.etc / "systemd/system/q.target", "[Unit]\nDefaultDependencies=no\n")
    discard m.daemonReload()
    m.loop.runOnce(0)                                    # the reload's sweep: installs the timer
    discard m.lookup("q.target")
    check m.units.hasKey("q.target")
    clk.advance(6_000_000)
    check m.loop.fireDueTimers() >= 1
    check not m.units.hasKey("q.target")
  test "many load/start/stop cycles keep the unit table small":
    let e = newEnv()
    for i in 0 ..< 200:
      e.unit("t" & $i & ".target", "")
    discard e.m.daemonReload()
    var peak = 0
    for i in 0 ..< 200:
      e.run("t" & $i & ".target")
      e.run("t" & $i & ".target", jtStop)
      peak = max(peak, e.m.units.len)
    check peak < 20
    check e.m.jobs.len == 0
    check e.m.collected >= 200
  test "a unit stays while its start rate limit window is open":
    let e = newEnv()
    writeFile(e.dir / "rl.target", "[Unit]\nDefaultDependencies=no\nStartLimitIntervalSec=60\nStartLimitBurst=2\n")
    discard e.m.daemonReload()
    e.run("rl.target")
    e.run("rl.target", jtStop)
    check e.loaded("rl.target") and e.m.units["rl.target"].startLimit.count == 1
    e.m.units["rl.target"].startLimit.begin = e.m.clock.monoUsec - 61_000_000   # the window ended
    check e.m.collectGarbage() == 1
  test "a unit whose state Jumpstart has not been told yet is kept until it was reported":
    let e = newEnv()
    e.unit("n.target", "")
    discard e.m.daemonReload()
    e.m.notifier = proc(unit, state, detail: string) = discard
    e.run("n.target")
    e.run("n.target", jtStop)
    check e.loaded("n.target")                           # the notifier has not reported "inactive"
    e.m.units["n.target"].jumpstartState = "inactive"
    check e.m.collectGarbage() == 1
