import std/[os, tables, unittest]
import common/roots
import unitfile/model
import engine/conditions

proc facts(base: string): Facts =
  Facts(roots: testRoots(base, scSystem), env: {"FOO": "bar"}.toTable, firstBoot: false,
        hostname: "box-01", machineId: "0123456789abcdef0123456789abcdef", uid: 0, gid: 0, username: "root")

proc c(kind: ConditionKind; v: string; neg = false; trig = false; asrt = false): Condition =
  Condition(kind: kind, value: v, negate: neg, trigger: trig, isAssert: asrt)

suite "conditions":
  let base = getTempDir() / "sdc-cond"
  createDir(base)
  let f = facts(base)
  writeFile(base / "file", "x")
  writeFile(base / "empty", "")
  createDir(base / "d"); createDir(base / "e"); writeFile(base / "e/x", "")
  writeFile(f.roots.cmdline, "quiet root=/dev/sda1 systemd.unit=foo.target\n")
  test "paths":
    check holds(f, c(ckPathExists, base / "file"))
    check not holds(f, c(ckPathExists, base / "nope"))
    check holds(f, c(ckPathExists, base / "nope", neg = true))
    check holds(f, c(ckPathIsDirectory, base / "d"))
    check holds(f, c(ckFileNotEmpty, base / "file"))
    check not holds(f, c(ckFileNotEmpty, base / "empty"))
    check holds(f, c(ckDirectoryNotEmpty, base / "e"))
    check not holds(f, c(ckDirectoryNotEmpty, base / "d"))
    check holds(f, c(ckPathExistsGlob, base / "fi*"))
  test "environment, host, cmdline, user, arch":
    check holds(f, c(ckEnvironment, "FOO"))
    check holds(f, c(ckEnvironment, "FOO=bar"))
    check not holds(f, c(ckEnvironment, "FOO=baz"))
    check holds(f, c(ckHost, "box-*"))
    check holds(f, c(ckHost, "0123456789ABCDEF0123456789abcdef"))
    check holds(f, c(ckKernelCommandLine, "quiet"))
    check holds(f, c(ckKernelCommandLine, "root"))
    check holds(f, c(ckKernelCommandLine, "root=/dev/sda1"))
    check not holds(f, c(ckKernelCommandLine, "quie"))
    check holds(f, c(ckUser, "root")) and holds(f, c(ckUser, "0"))
    check holds(f, c(ckArchitecture, "native"))
    check holds(f, c(ckFirstBoot, "no")) and not holds(f, c(ckFirstBoot, "yes"))
  test "kernel version comparisons":
    check holds(f, c(ckKernelVersion, ">= 2.6"))
    check not holds(f, c(ckKernelVersion, "< 2.6"))
  test "trigger groups and assertions":
    let r1 = checkConditions(f, @[c(ckPathExists, "/nope", trig = true), c(ckPathExists, base / "file", trig = true)])
    check r1.ok
    let r2 = checkConditions(f, @[c(ckPathExists, "/nope", trig = true), c(ckPathExists, "/nope2", trig = true)])
    check not r2.ok and r2.failed == "ConditionPathExists=|/nope"
    let r3 = checkConditions(f, @[c(ckPathExists, "/nope", asrt = true)])
    check not r3.ok and r3.isAssert and r3.failed == "AssertPathExists=/nope"
    check checkConditions(f, @[c(ckPathExists, base / "file"), c(ckPathExists, "/nope")]).failed == "ConditionPathExists=/nope"
    check checkConditions(f, @[]).ok
  test "deferred conditions are false":
    check not holds(f, c(ckVirtualization, "vm"))
    check holds(f, c(ckVirtualization, "vm", neg = true))
