import std/unittest
import unitfile/model
import engine/types
import service/states

proc set(statuses: openArray[uint8] = [], signals: openArray[uint8] = []): ExitSet =
  for s in statuses: result.statuses.incl s
  for s in signals: result.signals.incl s

suite "exit classification":
  test "clean exits":
    check classifyExit(xkExited, 0, set()) == xcClean
    check classifyExit(xkExited, 3, set([3'u8])) == xcClean
    check classifyExit(xkKilled, 15, set()) == xcClean
    check classifyExit(xkKilled, 1, set()) == xcClean
    check classifyExit(xkKilled, 13, set()) == xcClean
    check classifyExit(xkKilled, 10, set([], [10'u8])) == xcClean
  test "unclean":
    check classifyExit(xkExited, 1, set()) == xcUncleanExit
    check classifyExit(xkKilled, 9, set()) == xcUncleanSignal
    check classifyExit(xkDumped, 11, set()) == xcCoreDump
  test "results":
    check resultOfExit(xkExited, 2, set()) == "exit-code"
    check resultOfExit(xkKilled, 9, set()) == "signal"
    check resultOfExit(xkDumped, 6, set()) == "core-dump"
    check resultOfExit(xkExited, 0, set()) == "success"

suite "restart decision (§9.6 table)":
  let none = set()
  test "no and always":
    for cls in ExitClass:
      check not shouldRestart(rpNo, cls, xkExited, 1, none, none)
      check shouldRestart(rpAlways, cls, xkExited, 1, none, none)
  test "on-success":
    check shouldRestart(rpOnSuccess, xcClean, xkExited, 0, none, none)
    check not shouldRestart(rpOnSuccess, xcUncleanExit, xkExited, 1, none, none)
  test "on-failure":
    check not shouldRestart(rpOnFailure, xcClean, xkExited, 0, none, none)
    for cls in [xcUncleanExit, xcUncleanSignal, xcCoreDump, xcTimeout, xcWatchdog]:
      check shouldRestart(rpOnFailure, cls, xkExited, 1, none, none)
  test "on-abnormal":
    check not shouldRestart(rpOnAbnormal, xcUncleanExit, xkExited, 1, none, none)
    check shouldRestart(rpOnAbnormal, xcTimeout, xkExited, 1, none, none)
    check shouldRestart(rpOnAbnormal, xcUncleanSignal, xkKilled, 9, none, none)
  test "on-abort":
    check shouldRestart(rpOnAbort, xcCoreDump, xkDumped, 11, none, none)
    check not shouldRestart(rpOnAbort, xcTimeout, xkExited, 1, none, none)
  test "on-watchdog":
    check shouldRestart(rpOnWatchdog, xcWatchdog, xkExited, 1, none, none)
    check not shouldRestart(rpOnWatchdog, xcUncleanExit, xkExited, 1, none, none)
  test "prevent beats force beats policy":
    check not shouldRestart(rpAlways, xcUncleanExit, xkExited, 7, set([7'u8]), set([7'u8]))
    check shouldRestart(rpNo, xcUncleanExit, xkExited, 7, none, set([7'u8]))
    check not shouldRestart(rpOnFailure, xcUncleanSignal, xkKilled, 9, set([], [9'u8]), none)

suite "restart delay":
  test "steps":
    check restartDelayUsec(100_000, 0, 0, 1) == 100_000
    check restartDelayUsec(100_000, 10_000_000, 0, 3) == 100_000
    check restartDelayUsec(1_000_000, 8_000_000, 3, 1) == 2_000_000
    check restartDelayUsec(1_000_000, 8_000_000, 3, 3) == 8_000_000
    check restartDelayUsec(1_000_000, 8_000_000, 3, 9) == 8_000_000
    check restartDelayUsec(2_000_000, 1_000_000, 3, 2) == 2_000_000
  test "states":
    check activeStateOf(svStartPre).jumpstartState == "activating"
    check activeStateOf(svReload).jumpstartState == "active"
    check activeStateOf(svFinalSigterm).jumpstartState == "deactivating"
    check statusWord(xkKilled, 15) == "15/TERM"
