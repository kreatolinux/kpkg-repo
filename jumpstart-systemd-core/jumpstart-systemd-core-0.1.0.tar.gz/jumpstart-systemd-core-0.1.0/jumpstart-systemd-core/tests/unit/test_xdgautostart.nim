## The XDG autostart generator (generators/xdgautostart.nim): desktop file
## fixtures in, generated unit text out, with systemd's
## systemd-xdg-autostart-generator semantics.
import std/[unittest, os, strutils, sequtils, options, tables]
import common/[roots, names]
import unitfile/[model, loader, index]
import engine/[types, manager]
import generators/xdgautostart
import tools/misc
import unitfile/helpers

const
  Bin = "/usr/bin/gnome-keyring-daemon"
  Bin2 = "/usr/bin/at-spi-bus-launcher"

proc rootBase(r: Roots): string = r.usrLib.parentDir.parentDir

proc execDirsFor(r: Roots): seq[string] =
  ## `PATH` for the tests: the fake root's /usr/bin only.
  @["/usr/bin"]

proc fmt(r: Roots; execString: string; home = "/home/a"): Option[string] =
  ## `formatExecStart` with the fake root's PATH and base.
  formatExecStart(execString, home, @[rootBase(r) / "usr/bin"], rootBase(r))

proc touchBin(r: Roots; name: string) =
  let p = rootBase(r) / "usr/bin" / name
  createDir p.parentDir
  writeFile p, "#!/bin/sh\n"
  setFilePermissions p, {fpUserRead, fpUserWrite, fpUserExec}

proc touchAbs(r: Roots; path: string) =
  ## An executable at an absolute path below the fake root.
  let p = rootBase(r) & path
  createDir p.parentDir
  writeFile p, "#!/bin/sh\n"
  setFilePermissions p, {fpUserRead, fpUserWrite, fpUserExec}

proc autostart(r: Roots; name, text: string) =
  put(rootBase(r) / "etc/xdg/autostart" / name, text)

proc userAutostart(r: Roots; name, text: string) =
  put(r.home / ".config/autostart" / name, text)

proc gen(r: Roots): seq[GeneratedUnit] =
  generateXdgAutostart(r, testEnv(), ManagerConf(), execDirsFor(r).join(":"))

proc only(r: Roots): GeneratedUnit =
  let g = gen(r)
  check g.len == 1
  if g.len == 0: GeneratedUnit()
  else: g[0]

proc text(r: Roots): string =
  let g = gen(r)
  if g.len == 0: "" else: g[0].def.common.settings.mapIt(it.section & "." & it.key & "=" & it.value).join("\n")

suite "xdg autostart: names":
  test "unit_name_escape of the file name":
    check autostartUnitName("a-b.blub.desktop") == "app-a\\x2db.blub@autostart.service"
    check autostartUnitName("gnome-keyring-secrets.desktop") == "app-gnome\\x2dkeyring\\x2dsecrets@autostart.service"
    check autostartUnitName("org.gnome.Evolution-alarm-notify.desktop") ==
      "app-org.gnome.Evolution\\x2dalarm\\x2dnotify@autostart.service"
    check autostartUnitName("at-spi-dbus-bus.desktop") == "app-at\\x2dspi\\x2ddbus\\x2dbus@autostart.service"
    check autostartUnitName(".hidden.desktop") == "app-\\x2ehidden@autostart.service"
    check autostartUnitName("a_b.desktop") == "app-a_b@autostart.service"
    check autostartUnitName("a:b.desktop") == "app-a:b@autostart.service"
  test "generated names are valid unit names":
    for n in ["a-b.blub.desktop", "x y.desktop", "ü.desktop", ".a.desktop"]:
      check parseUnitName(autostartUnitName(n)).isSome

suite "xdg autostart: Exec= field codes":
  let base = sysRoots("xdg-exec")
  touchBin(base, "sleep")
  touchBin(base, "ls")

  test "plain command":
    check fmt(base, "/usr/bin/sleep 100").get == "/usr/bin/sleep 100"
  test "standardised field codes are dropped":
    check fmt(base, "/usr/bin/sleep %f \"%F\" %u %U %d %D\t%n %N %i %c %k %v %m").get == "/usr/bin/sleep"
  test "unknown field codes stay, escaped":
    check fmt(base, "/usr/bin/sleep %X \"%Y\"").get == "/usr/bin/sleep %%X %%Y"
  test "quoting is preserved":
    check fmt(base, "/usr/bin/sleep \";\\\"\"").get == "/usr/bin/sleep \";\\\"\""
  test "tilde expansion":
    check fmt(base, "/usr/bin/ls ~").get == "/usr/bin/ls /home/a"
    check fmt(base, "/usr/bin/ls \"~/foo\"").get == "/usr/bin/ls /home/a/foo"
    check fmt(base, "/usr/bin/ls ~foo").get == "/usr/bin/ls ~foo"
    check fmt(base, "/usr/bin/ls foo~").get == "/usr/bin/ls foo~"
  test "bare names are resolved through PATH":
    check fmt(base, "sleep 1").get == rootBase(base) / "usr/bin/sleep" & " 1"
  test "missing executable is no unit":
    check fmt(base, "/usr/bin/definitely-missing --start").isNone
    check fmt(base, "definitely-missing").isNone
  test "empty command":
    check fmt(base, "").isNone
    check fmt(base, "   ").isNone

suite "xdg autostart: desktop file parsing":
  test "values, lists and escapes":
    let e = parseDesktop("[Desktop Entry]\nExec\t =\t /usr/bin/sleep 100\n" &
      "OnlyShowIn = A;B;\nNotShowIn=C;;D\\\\\\;;E\n", "/x/a.desktop")
    check e.execString == "/usr/bin/sleep 100"
    check e.onlyShowIn == @["A", "B"]
    check e.notShowIn == @["C", "D\\;", "E"]
    check not e.hidden
  test "a duplicate key is ignored":
    check parseDesktop("[Desktop Entry]\nExec=a\nExec=b\n", "/x/a.desktop").execString == "a"
  test "booleans":
    check parseDesktop("[Desktop Entry]\nHidden=\t true\n", "/x/a.desktop").hidden
    check parseDesktop("[Desktop Entry]\nHidden=\t True\n", "/x/a.desktop").hidden
    check not parseDesktop("[Desktop Entry]\nHidden=false\n", "/x/a.desktop").hidden
  test "an invalid escape hides the entry":
    let e = parseDesktop("[Desktop Entry]\nExec=/bin/echo \\q\n", "/x/a.desktop")
    check e.hidden and e.parseError.len > 0
  test "only [Desktop Entry] counts":
    let e = parseDesktop("[Desktop Action x]\nExec=/bin/false\n", "/x/a.desktop")
    check e.execString.len == 0

suite "xdg autostart: generation":
  test "a plain entry becomes a unit wanted by xdg-desktop-autostart.target":
    let r = userRoots("xdg-gen1")
    touchBin(r, "gnome-keyring-daemon")
    touchBin(r, "systemd-xdg-autostart-condition")
    autostart(r, "gnome-keyring-secrets.desktop", """
[Desktop Entry]
Type=Application
Name=Secret Storage Service
Exec=/usr/bin/gnome-keyring-daemon --start --components=secrets
OnlyShowIn=GNOME;Unity;MATE;
NoDisplay=true
X-GNOME-Autostart-Phase=PreDisplayServer
X-GNOME-AutoRestart=false
X-GNOME-Autostart-Notify=true
""")
    let g = only(r)
    check g.name == "app-gnome\\x2dkeyring\\x2dsecrets@autostart.service"
    check g.def.kind == ukService
    check g.def.common.source == usGenerated
    check g.extraDeps == @[(dkWants, AutostartTarget, g.name)]
    check g.def.common.description == "Secret Storage Service"
    check g.def.common.deps[dkPartOf] == @["graphical-session.target"]
    check g.def.common.deps[dkAfter] == @["graphical-session.target"]
    check g.def.service.typ == stExec
    check g.def.service.exitType == etCgroup
    check g.def.service.restart == rpNo
    check g.def.service.timeoutStopUsec == 5_000_000
    check g.def.common.slice == "app.slice"
    check g.def.service.commands[ekStart].len == 1
    let c = g.def.service.commands[ekStart][0]
    check c.path == "/usr/bin/gnome-keyring-daemon"
    check c.args == @["--start", "--components=secrets"]
    check efColon in c.flags                     # ExecStart=: no $VAR expansion
    check g.def.common.sourcePath == rootBase(r) / "etc/xdg/autostart/gnome-keyring-secrets.desktop"
    check g.def.common.stamps.len == 0 and g.def.common.fragmentPath.len == 0
    # OnlyShowIn= becomes an ExecCondition= against $XDG_CURRENT_DESKTOP
    let cond = g.def.service.commands[ekCondition]
    check cond.len == 1
    check cond[0].path == rootBase(r) / "usr/bin/systemd-xdg-autostart-condition"
    check cond[0].args == @["--", "GNOME:Unity:MATE", ""]

  test "the phase is recorded in a comment, not used to skip":
    let r = userRoots("xdg-gen2")
    touchBin(r, "gnome-keyring-daemon")
    autostart(r, "k.desktop", "[Desktop Entry]\nType=Application\nExec=/usr/bin/gnome-keyring-daemon\nX-GNOME-Autostart-Phase=PreDisplayServer\n")
    let t = unitText(parseDesktop(readFile(rootBase(r) / "etc/xdg/autostart/k.desktop"),
      rootBase(r) / "etc/xdg/autostart/k.desktop"), "/usr/bin/gnome-keyring-daemon", execDirsFor(r))
    check "# X-GNOME-Autostart-Phase=PreDisplayServer" in t
    check "NotShowIn" notin t

  test "Type= must be Application":
    let r = userRoots("xdg-gen3")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nExec=/bin/true\n")
    check gen(r).len == 0
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Link\nExec=/bin/true\n")
    check gen(r).len == 0
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-Phase=WindowManager\n")
    check gen(r).len == 1

  test "Hidden= and X-systemd-skip= suppress the unit":
    let r = userRoots("xdg-gen4")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nHidden=true\n")
    check gen(r).len == 0
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-systemd-skip=true\n")
    check gen(r).len == 0

  test "X-GNOME-HiddenUnderSystemd= and X-GNOME-Autostart-enabled=false suppress the unit":
    let r = userRoots("xdg-gen5")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-HiddenUnderSystemd=true\n")
    check gen(r).len == 0
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-enabled=false\n")
    check gen(r).len == 0
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-enabled=true\nX-GNOME-Autostart-Phase=WindowManager\n")
    check gen(r).len == 1

  test "an entry without a phase is left to gnome-session":
    let r = userRoots("xdg-gen6")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\n")
    let e = parseDesktop(readFile(rootBase(r) / "etc/xdg/autostart/a.desktop"), "/x/a.desktop")
    check sessionStartsIt(e)
    check skipReason(e).len > 0
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-Phase=Application\n")
    let e2 = parseDesktop(readFile(rootBase(r) / "etc/xdg/autostart/a.desktop"), "/x/a.desktop")
    check sessionStartsIt(e2)
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-Phase=WindowManager\n")
    let e3 = parseDesktop(readFile(rootBase(r) / "etc/xdg/autostart/a.desktop"), "/x/a.desktop")
    check not sessionStartsIt(e3)

  test "TryExec= must be executable":
    let r = userRoots("xdg-gen7")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nTryExec=/usr/bin/missing-thing\n")
    check gen(r).len == 0
    touchBin(r, "present-thing")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nTryExec=present-thing\nX-GNOME-Autostart-Phase=WindowManager\n")
    check gen(r).len == 1

  test "a missing Exec= binary is no unit":
    let r = userRoots("xdg-gen8")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/usr/bin/not-installed --start\n")
    check gen(r).len == 0

  test "Path= becomes WorkingDirectory=-":
    let r = userRoots("xdg-gen9")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nPath=/opt/app\nX-GNOME-Autostart-Phase=WindowManager\n")
    let g = only(r)
    check g.def.service.exec.workingDirectory == "-/opt/app"

  test "AutostartCondition= uses the DE helper when present":
    let r = userRoots("xdg-gen10")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-Phase=Initialization\n" &
      "AutostartCondition=GSettings org.gnome.desktop.interface toolkit-accessibility\n")
    let g1 = only(r)
    check g1.def.service.commands[ekCondition].len == 0     # helper missing: no condition
    touchBin(r, "gnome-systemd-autostart-condition")
    let g2 = only(r)
    check g2.def.service.commands[ekCondition].len == 1
    check g2.def.service.commands[ekCondition][0].args ==
      @["--condition", "GSettings org.gnome.desktop.interface toolkit-accessibility"]

  test "user entries override system ones by file name":
    let r = userRoots("xdg-gen11")
    touchAbs(r, "/bin/true")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nName=system\nExec=/bin/true\nX-GNOME-Autostart-Phase=WindowManager\n")
    let g1 = only(r)
    check g1.def.common.description == "system"
    userAutostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nName=user\nExec=/bin/true\nX-GNOME-Autostart-Phase=WindowManager\n")
    let g2 = only(r)
    check g2.def.common.description == "user"
    check g2.def.common.sourcePath == r.home / ".config/autostart/a.desktop"
    # a hidden user override still masks the system file
    userAutostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nHidden=true\n")
    check gen(r).len == 0

  test "system scope generates nothing":
    let r = userRoots("xdg-gen12")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-Phase=WindowManager\n")
    check generateXdgAutostart(r, testEnv(), ManagerConf()).len == 0

  test "entries are sorted by unit name":
    let r = userRoots("xdg-gen13")
    touchAbs(r, "/bin/true")
    for n in ["c.desktop", "a.desktop", "b.desktop"]:
      autostart(r, n, "[Desktop Entry]\nType=Application\nExec=/bin/true\nX-GNOME-Autostart-Phase=WindowManager\n")
    check gen(r).mapIt(it.name) == @["app-a@autostart.service", "app-b@autostart.service", "app-c@autostart.service"]

  test "the generated unit loads as a service with the expected text":
    let r = userRoots("xdg-gen14")
    touchAbs(r, "/bin/sh")
    autostart(r, "a.desktop", "[Desktop Entry]\nType=Application\nName=A \"quoted\" app\n" &
      "Exec=/bin/sh -c \"echo 100% > /tmp/x\"\nX-GNOME-Autostart-Phase=WindowManager\n")
    let g = only(r)
    check g.def.common.loadState == lsLoaded
    check g.def.common.description == "A \"quoted\" app"
    check g.def.service.commands[ekStart][0].args == @["-c", "echo 100% > /tmp/x"]
    let t = unitText(parseDesktop(readFile(rootBase(r) / "etc/xdg/autostart/a.desktop"),
      rootBase(r) / "etc/xdg/autostart/a.desktop"), "/bin/sh -c \"echo 100%% > /tmp/x\"", execDirsFor(r))
    check "ExecStart=:/bin/sh -c \"echo 100%% > /tmp/x\"" in t
    check "Slice=app.slice" in t
    check "SourcePath=" & rootBase(r) / "etc/xdg/autostart/a.desktop" in t

suite "xdg autostart: the image's entries":
  ## The six entries the live image ships in /etc/xdg/autostart, verbatim.
  const ImageEntries = {
    "at-spi-dbus-bus.desktop": """
[Desktop Entry]
Type=Application
Name=AT-SPI D-Bus Bus
Exec=/usr/libexec/at-spi-bus-launcher --launch-immediately
OnlyShowIn=GNOME;Unity;
NoDisplay=true
AutostartCondition=GSettings org.gnome.desktop.interface toolkit-accessibility
X-GNOME-AutoRestart=true
X-GNOME-Autostart-Phase=Initialization
""",
    "geoclue-demo-agent.desktop": """
[Desktop Entry]
Name=Geoclue Demo agent
Exec=/usr/libexec/geoclue-2.0/demos/agent
NotShowIn=GNOME;
NoDisplay=true
Terminal=false
Type=Application
""",
    "gnome-keyring-secrets.desktop": """
[Desktop Entry]
Type=Application
Name=Secret Storage Service
Exec=/usr/bin/gnome-keyring-daemon --start --components=secrets
OnlyShowIn=GNOME;Unity;MATE;
NoDisplay=true
X-GNOME-Autostart-Phase=PreDisplayServer
X-GNOME-AutoRestart=false
X-GNOME-Autostart-Notify=true
""",
    "gnome-keyring-ssh.desktop": """
[Desktop Entry]
Type=Application
Name=SSH Key Agent
Exec=/usr/bin/gnome-keyring-daemon --start --components=ssh
OnlyShowIn=GNOME;Unity;MATE;
X-GNOME-Autostart-Phase=PreDisplayServer
X-GNOME-AutoRestart=false
X-GNOME-Autostart-Notify=true
""",
    "gnome-keyring-pkcs11.desktop": """
[Desktop Entry]
Type=Application
Name=Certificate and Key Storage
Exec=/usr/bin/gnome-keyring-daemon --start --components=pkcs11
OnlyShowIn=GNOME;Unity;MATE;
NoDisplay=true
X-GNOME-Autostart-Phase=PreDisplayServer
X-GNOME-AutoRestart=false
X-GNOME-Autostart-Notify=true
""",
    "org.gnome.Evolution-alarm-notify.desktop": """
[Desktop Entry]
Type=Application
Name=Events and Tasks Reminders
Icon=org.gnome.Evolution-alarm-notify
Exec=/usr/libexec/evolution-data-server/evolution-alarm-notify --autostart
Terminal=false
Categories=
NoDisplay=true
NotShowIn=GNOME;
X-Meego-Priority=Low
X-GNOME-UsesNotifications=true
X-systemd-skip=true
"""}.toTable

  proc imageRoots(name: string): Roots =
    result = userRoots(name)
    for f, text in ImageEntries: autostart(result, f, text)
    touchAbs(result, "/usr/bin/systemd-xdg-autostart-condition")
    for b in ["/usr/bin/gnome-keyring-daemon", "/usr/libexec/at-spi-bus-launcher",
              "/usr/libexec/geoclue-2.0/demos/agent",
              "/usr/libexec/evolution-data-server/evolution-alarm-notify"]:
      let p = rootBase(result) & b
      createDir p.parentDir
      writeFile p, "#!/bin/sh\n"
      setFilePermissions p, {fpUserRead, fpUserWrite, fpUserExec}

  test "which entries produce which units":
    let r = imageRoots("xdg-img1")
    let names = gen(r).mapIt(it.name)
    # the three keyring components and at-spi set a phase: they get units
    check "app-gnome\\x2dkeyring\\x2dsecrets@autostart.service" in names
    check "app-gnome\\x2dkeyring\\x2dssh@autostart.service" in names
    check "app-gnome\\x2dkeyring\\x2dpkcs11@autostart.service" in names
    check "app-at\\x2dspi\\x2ddbus\\x2dbus@autostart.service" in names
    # geoclue has no phase (the session starts it) and NotShowIn=GNOME;
    # Evolution is marked X-systemd-skip
    check "app-geoclue\\x2ddemo\\x2dagent@autostart.service" notin names
    check "app-org.gnome.Evolution\\x2dalarm\\x2dnotify@autostart.service" notin names
    check names.len == 4

  test "the keyring units run the right commands":
    let r = imageRoots("xdg-img2")
    for g in gen(r):
      check g.def.common.loadState == lsLoaded
      let c = g.def.service.commands[ekStart][0]
      check c.path == "/usr/bin/gnome-keyring-daemon" or c.path == "/usr/libexec/at-spi-bus-launcher"
      check efColon in c.flags
      check g.def.service.typ == stExec
      check g.def.common.slice == "app.slice"
      check g.def.common.deps[dkPartOf] == @["graphical-session.target"]
      check g.extraDeps == @[(dkWants, AutostartTarget, g.name)]
    let secrets = gen(r).filterIt(it.name.contains("secrets"))[0]
    check secrets.def.service.commands[ekStart][0].args == @["--start", "--components=secrets"]

  test "XDG_CURRENT_DESKTOP decides at start time, not at generation time":
    let r = imageRoots("xdg-img3")
    let secrets = gen(r).filterIt(it.name.contains("secrets"))[0]
    let cond = secrets.def.service.commands[ekCondition]
    check cond.len == 1
    check cond[0].args == @["--", "GNOME:Unity:MATE", ""]

suite "xdg autostart: the condition helper":
  test "OnlyShowIn/NotShowIn against XDG_CURRENT_DESKTOP":
    let saved = getEnv("XDG_CURRENT_DESKTOP")
    defer:
      if saved.len == 0: delEnv("XDG_CURRENT_DESKTOP") else: putEnv("XDG_CURRENT_DESKTOP", saved)
    putEnv("XDG_CURRENT_DESKTOP", "GNOME")
    check xdgAutostartConditionMain(@["--", "GNOME:Unity", ""]) == 0
    check xdgAutostartConditionMain(@["--", "", "GNOME"]) == 1
    check xdgAutostartConditionMain(@["--", "", ""]) == 0
    check xdgAutostartConditionMain(@["--", "KDE", ""]) == 1
    putEnv("XDG_CURRENT_DESKTOP", "GNOME:Unity")
    check xdgAutostartConditionMain(@["--", "Unity", ""]) == 0
    check xdgAutostartConditionMain(@["--", "", "Unity"]) == 1
    delEnv("XDG_CURRENT_DESKTOP")
    check xdgAutostartConditionMain(@["--", "", ""]) == 0
    check xdgAutostartConditionMain(@["--", "GNOME", ""]) == 1
    check xdgAutostartConditionMain(@["--"]) == 1

suite "xdg autostart: manager wiring":
  ## The generator is installed as the manager's generator hook, so a
  ## daemon-reload (and manager start) re-generates the units, and the core's
  ## own user units make xdg-desktop-autostart.target reachable from
  ## graphical-session.target.
  proc managerRoots(name: string): Roots =
    result = userRoots(name)
    # the core's share/units-user, as `make install` lays it out
    let core = result.coreRoot
    for f in ["graphical-session.target", "xdg-desktop-autostart.target", "basic.target",
              "app.slice", "sockets.target", "timers.target", "paths.target"]:
      let src = currentSourcePath().parentDir.parentDir.parentDir / "share/units-user" / f
      put(core / "share/units-user" / f, readFile(src))
    touchAbs(result, "/bin/true")
    touchAbs(result, "/usr/bin/systemd-xdg-autostart-condition")
    autostart(result, "a.desktop",
      "[Desktop Entry]\nType=Application\nName=A\nExec=/bin/true --x\nX-GNOME-Autostart-Phase=Initialization\n")

  test "the generator hook feeds the unit index":
    let r = managerRoots("xdg-mgr1")
    let saved = generatorHook
    defer: generatorHook = saved
    installXdgAutostart()
    let m = newManager(r)
    let name = "app-a@autostart.service"
    check m.index.generated.hasKey(name)
    let def = loader.loadUnit(m.index, name, m.specEnv)
    check def.common.loadState == lsLoaded
    check def.common.source == usGenerated
    check def.service.commands[ekStart][0].args == @["--x"]
    # the target the units are wanted by is a real user unit of the core, and
    # it wants every generated unit (the generator's symlink farm, in memory)
    check resolveName(m.index, AutostartTarget).isSome
    check m.index.entries.hasKey(AutostartTarget)
    let target = loader.loadUnit(m.index, AutostartTarget, m.specEnv)
    check target.common.deps[dkWants] == @[name]
    # and the session opts in
    let gs = loader.loadUnit(m.index, "graphical-session.target", m.specEnv)
    check gs.common.deps[dkWants] == @[AutostartTarget]

  test "system scope managers generate nothing":
    let r = sysRoots("xdg-mgr2")
    let saved = generatorHook
    defer: generatorHook = saved
    installXdgAutostart()
    let m = newManager(r)
    check m.index.generated.len == 0

  test "the shipped target unit is systemd's":
    let src = currentSourcePath().parentDir.parentDir.parentDir / "share/units-user/xdg-desktop-autostart.target"
    let text = readFile(src)
    check "Description=Startup of XDG autostart applications" in text
    check "RefuseManualStart=yes" in text
    check "StopWhenUnneeded=yes" in text
