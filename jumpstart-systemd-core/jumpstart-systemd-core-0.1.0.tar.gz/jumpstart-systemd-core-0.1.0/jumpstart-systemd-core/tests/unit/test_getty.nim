## The serial getty generator (§8.6) and its native-unit suppression: a
## terminal a native Jumpstart getty unit serves gets no serial-getty instance.
import std/[os, sets, strutils, sequtils, unittest]
import common/roots
import unitfile/model
import generators/getty
import engine/manager

proc decfile(tty: string; exec = ""): string =
  ## A getty decfile in the shape kreato-fs-essentials ships.
  let cmd = if exec.len > 0: exec else: "/bin/busybox getty 115200 " & tty & " vt100"
  "name: \"getty-" & tty & "\"\ndescription: \"getty on " & tty & "\"\ntype: \"simple\"\n\n" &
    "service {\n  terminal true\n  exec \"" & cmd & "\"\n}\n"

proc link(unit, dir, target: string) =
  ## An enablement link to a decfile, as `jumpctl enable` writes it.
  createDir(dir)
  createSymlink(target, dir / unit & ".kg")

suite "getty generator":
  let base = getTempDir() / "sdc-getty"
  removeDir(base)
  createDir(base)

  test "terminal names":
    check isTerminalName("tty1") and isTerminalName("ttyS0") and isTerminalName("hvc0")
    check isTerminalName("xvc0") and isTerminalName("console")
    check not isTerminalName("t") and not isTerminalName("/dev/ttyS0") and not isTerminalName("tty-1")
    check isTtyName("tty1") and isTtyName("ttyS0") and isTtyName("ttyAMA0")
    check not isTtyName("hvc0") and not isTtyName("console") and not isTtyName("-")
    check isVirtualTerminal("tty12") and not isVirtualTerminal("ttyS0")

  test "command lines name terminals":
    check terminalNames("/bin/busybox getty 115200 ttyAMA0 vt100") == @["ttyAMA0"]
    check terminalNames("/sbin/agetty 115200 /dev/ttyS0 vt100") == @["ttyS0"]
    check terminalNames("/sbin/agetty 115200 /dev/hvc0 vt100") == @["hvc0"]
    check terminalNames("/sbin/agetty -o '-p -- \\u' --keep-baud 115200,57600,38400,9600 - $TERM").len == 0
    check terminalNames("/sbin/agetty --noclear tty1 linux") == @["tty1"]

  test "a getty runs as the command, not as an argument":
    check isGettyCommand("/bin/busybox getty 115200 ttyAMA0 vt100")
    check isGettyCommand("/sbin/agetty 115200 /dev/ttyS0 vt100")
    check isGettyCommand("toybox getty 115200 ttyS0")
    check isGettyCommand("mingetty tty2")
    check not isGettyCommand("/bin/sh -c 'echo getty on ttyS5'")
    check not isGettyCommand("/usr/libexec/kreato-live/accounts")

  test "exec statements only":
    let path = base / "mixed.kg"
    writeFile(path, "name: \"x\"\nservice {\n  exec \"/sbin/agetty 115200 ttyS0 vt100\"\n" &
      "  exec_post \"/bin/sh -c 'agetty ttyS7'\"\n  # exec \"/sbin/agetty ttyS8\"\n}\n")
    check execCommands(path) == @["/sbin/agetty 115200 ttyS0 vt100"]
    check servesTty(path) == @["ttyS0"]

  test "the terminals native getty units serve":
    let root = base / "js"
    createDir(root)
    # Name convention plus exec, a decfile without the getty- name, and one
    # that only mentions a terminal without running a getty on it.
    writeFile(root / "getty-ttyAMA0.kg", decfile("ttyAMA0"))
    link("getty-ttyAMA0", root / "enabled", "../getty-ttyAMA0.kg")
    writeFile(root / "serial-line.kg", "name: \"serial-line\"\nservice {\n  exec \"/sbin/agetty 115200 /dev/hvc0 vt100\"\n}\n")
    link("serial-line", root / "enabled", "../serial-line.kg")
    writeFile(root / "monitor.kg", "name: \"monitor\"\nservice {\n  exec \"/bin/sh -c 'echo getty on ttyS5'\"\n}\n")
    link("monitor", root / "enabled", "../monitor.kg")
    writeFile(root / "getty-ttyS0.kg", decfile("ttyS0"))
    link("getty-ttyS0", root / "targets" / "multi-user", "../../getty-ttyS0.kg")
    writeFile(root / "default-target", "multi-user\n")
    # A getty that is not enabled serves nothing; a dangling link still names
    # its terminal.
    writeFile(root / "getty-ttyS2.kg", decfile("ttyS2"))
    link("getty-tty9", root / "enabled", "../getty-tty9.kg")
    check nativeGettyTtys(root) == toHashSet(["ttyAMA0", "hvc0", "ttyS0", "tty9"])

  test "an enablement marker counts, an inert decfile keeps its name":
    # 0-byte markers and decfiles neutralized to a no-op both declare "this
    # terminal is ours"; the generator does not look behind the name.
    let root = base / "js-marker"
    createDir(root / "enabled")
    createDir(root)
    writeFile(root / "getty-tty1.kg", decfile("tty1", "/bin/true"))
    writeFile(root / "getty-ttyS0.kg", decfile("ttyS0"))
    createSymlink("../getty-tty1.kg", root / "enabled/getty-tty1.kg")
    writeFile(root / "enabled/getty-ttyS0.kg", "")
    check nativeGettyTtys(root) == toHashSet(["tty1", "ttyS0"])

  test "only the boot target's members count":
    let root = base / "js-target"
    createDir(root)
    writeFile(root / "getty-ttyS0.kg", decfile("ttyS0"))
    link("getty-ttyS0", root / "targets" / "graphical", "../../getty-ttyS0.kg")
    check bootTarget(root) == ""                       # no default-target file
    check nativeGettyTtys(root) == initHashSet[string]()   # built-in `default` target
    writeFile(root / "default-target", "graphical\n")
    check bootTarget(root) == "graphical"
    check nativeGettyTtys(root) == toHashSet(["ttyS0"])

  test "consoles come from sysfs, else from the command line":
    let sysfs = base / "sys"
    let cmdline = base / "cmdline"
    createDir(sysfs / "class/tty/console")
    writeFile(cmdline, "quiet console=ttyS0,115200 console=tty1\n")
    check serialConsoles(sysfs, cmdline) == @["ttyS0", "tty1"]
    writeFile(sysfs / "class/tty/console/active", "ttyAMA0\n")
    check serialConsoles(sysfs, cmdline) == @["ttyAMA0"]

  test "serial consoles get one instance, virtual terminals none":
    let r = testRoots(base / "r-serial", scSystem)
    createDir(r.sysfs / "class/tty/console")
    writeFile(r.sysfs / "class/tty/console/active", "ttyAMA0\n")
    writeFile(r.cmdline, "console=ttyAMA0 console=tty1 console=ttyS9\n")
    createDir(r.devfs)
    writeFile(r.devfs / "ttyAMA0", "")
    writeFile(r.devfs / "tty1", "")
    check serialGettyEdges(r) == @[(dkWants, "getty.target", "serial-getty@ttyAMA0.service")]

  test "a native getty unit suppresses the duplicate":
    let r = testRoots(base / "r-native", scSystem)
    createDir(r.sysfs / "class/tty/console")
    writeFile(r.sysfs / "class/tty/console/active", "ttyAMA0\n")
    createDir(r.devfs)
    writeFile(r.devfs / "ttyAMA0", "")
    createDir(r.etc / "jumpstart")
    writeFile(r.etc / "jumpstart/getty-ttyAMA0.kg", decfile("ttyAMA0"))
    check serialGettyEdges(r).len == 1                  # nothing enabled yet
    link("getty-ttyAMA0", r.etc / "jumpstart/enabled", "../getty-ttyAMA0.kg")
    check serialGettyEdges(r).len == 0

  test "no instances in user scope":
    let r = testRoots(base / "r-user", scUser)
    createDir(r.sysfs / "class/tty/console")
    writeFile(r.sysfs / "class/tty/console/active", "ttyS0\n")
    createDir(r.devfs)
    writeFile(r.devfs / "ttyS0", "")
    check serialGettyEdges(r).len == 0

  test "the manager wires the generator into getty.target":
    let r = testRoots(base / "r-manager", scSystem)
    createDir(r.sysfs / "class/tty/console")
    writeFile(r.sysfs / "class/tty/console/active", "ttyAMA0\n")
    createDir(r.devfs)
    writeFile(r.devfs / "ttyAMA0", "")
    let m = newManager(r)
    check m.extraDeps.anyIt(it == (dkWants, "getty.target", "serial-getty@ttyAMA0.service"))
    # A daemon-reload drops the old edge and adds none: the native unit is enabled.
    createDir(r.etc / "jumpstart")
    writeFile(r.etc / "jumpstart/getty-ttyAMA0.kg", decfile("ttyAMA0"))
    link("getty-ttyAMA0", r.etc / "jumpstart/enabled", "../getty-ttyAMA0.kg")
    discard m.daemonReload()
    check not m.extraDeps.anyIt(it[2].startsWith("serial-getty@"))
