## `make install` puts the poweroff/reboot/halt front-ends in $(SBINDIR). Merged-/usr distributions (Kreato Linux:
## /sbin is a link to /usr/bin and busybox ships its own `poweroff` in /usr/bin, found first in PATH) need
## SBINDIR=/usr/bin; otherwise `poweroff` runs busybox's and Jumpstart never sees the signal.
import std/[osproc, strutils, unittest]

proc dryInstall(extra: string): string =
  let (outp, code) = execCmdEx("make -n install PREFIX=/usr DESTDIR=/stage " & extra)
  doAssert code == 0, outp
  outp

suite "make install layout":
  test "front-ends default to PREFIX/sbin":
    let o = dryInstall("")
    check "install -d /stage/usr/bin /stage/usr/sbin" in o
    check "/stage/usr/sbin/$n" in o

  test "SBINDIR=/usr/bin puts them next to the other front-ends":
    let o = dryInstall("SBINDIR=/usr/bin")
    check "install -d /stage/usr/bin /stage/usr/bin" in o
    check "/stage/usr/bin/$n; done" in o
    check "/stage/usr/sbin" notin o
