## journald driven in-process through `Journald.step` over real unix sockets.
import std/[os, posix, json, unittest, strutils, sequtils, algorithm]
import journal/[format, reader, daemon, conf, client, control, intake_stream, sockutil, storage]
import common/[roots, clock]
import ./jtest

proc mkSetup(base: string; scope = scSystem): JournaldSetup =
  let r = testRoots(base, scope)
  result = defaultSetup(r)
  result.conf = defaultConf()
  result.hostname = "testhost"
  result.bootId = bootId(7)
  result.machineId = bootId(9)
  result.notifySocket = ""

proc pump(d: Journald; n = 5) =
  for _ in 0 ..< n: d.step(20)

proc all(d: Journald; q = JournalQuery()): seq[JournalEntry] =
  if d.store != nil: d.store.sync
  openJournal(@[volatileDir(d.setup), persistentDir(d.setup)]).entries(q)

proc waitFor(d: Journald; cond: proc(): bool) =
  for _ in 0 ..< 100:
    if cond(): return
    d.step(20)

suite "daemon intake":
  setup:
    let base = tmpDir("dm")
    let su = mkSetup(base)
    let d = newJournald(su)
  teardown:
    d.shutdown

  test "native datagram becomes an entry with trusted fields":
    check journalSend(su.roots.sysrun, [("MESSAGE", "hello"), ("PRIORITY", "4"),
      ("_PID", "1"), ("FOO", "bar"), ("MULTI", "a\nb")])
    d.waitFor(proc(): bool = d.all.len > 0)
    let es = d.all
    check es.len == 1
    let e = es[0]
    check e.message == "hello" and e.priority == 4 and e.getField("FOO") == "bar"
    check e.getField("MULTI") == "a\nb"
    check e.getField("_TRANSPORT") == "journal" and e.getField("_HOSTNAME") == "testhost"
    check e.getField("_BOOT_ID") == idHex(bootId(7)) and e.bootId == bootId(7)
    check e.getField("_MACHINE_ID") == idHex(bootId(9))
    check e.getField("_SOURCE_REALTIME_TIMESTAMP").len > 10
    when defined(linux):
      check e.getField("_PID") == $getpid()       # the sender's own claim was discarded
      check e.getField("_UID") == $getuid()
    else:
      check e.getField("_PID") == ""
  test "datagram with only invalid fields stores nothing":
    check journalSend(su.roots.sysrun, [("_PID", "1")])
    d.pump
    check d.all.len == 0
  test "syslog datagram":
    check sendDatagram(syslogSocketPath(su.roots.sysrun), "<27>myprog[42]: it broke\n")
    d.waitFor(proc(): bool = d.all.len > 0)
    let e = d.all[0]
    check e.getField("SYSLOG_IDENTIFIER") == "myprog" and e.getField("SYSLOG_PID") == "42"
    check e.priority == 3 and e.getField("SYSLOG_FACILITY") == "3" and e.message == "it broke"
    check e.getField("_TRANSPORT") == "syslog"
    check e.fields.countIt(it.key == "_TRANSPORT") == 1
  test "stream connection: header, level prefixes, partial line at EOF":
    let fd = openStream(su.roots.sysrun, StreamHeader(identifier: "svc", unit: "x.service",
      priority: 6, levelPrefix: true, levelMax: -1, facility: 3,
      extraFields: @[("LOGX", "1")]))
    check fd >= 0
    d.pump
    discard write(fd, "first\n<3>failed\npart".cstring, 20)
    d.pump
    check d.all.len == 2
    discard close(fd)
    d.waitFor(proc(): bool = d.all.len == 3)
    let es = d.all
    check es.mapIt(it.message) == @["first", "failed", "part"]
    check es.mapIt(it.priority) == @[6, 3, 6]
    check es[0].getField("SYSLOG_IDENTIFIER") == "svc" and es[0].getField("_TRANSPORT") == "stdout"
    check es[0].getField("LOGX") == "1" and es[0].getField("SYSLOG_FACILITY") == "3"
    check es[0].getField("_STREAM_ID") == es[1].getField("_STREAM_ID")
    check es[0].getField("_STREAM_ID").len == 32
    # the peer is root-or-us; unit from the header only when the peer is root
    if getuid() == 0: check es[0].getField("_SYSTEMD_UNIT") == "x.service"
  test "stream level max and bad header":
    let fd = openStream(su.roots.sysrun, StreamHeader(identifier: "s", priority: 6,
      levelPrefix: true, levelMax: 4, facility: 3))
    discard write(fd, "<3>keep\n<6>drop\n".cstring, 16)
    discard close(fd)
    d.pump
    check d.all.mapIt(it.message) == @["keep"]
    let bad = connectUnix(streamSocketPath(su.roots.sysrun), true)
    discard write(bad, "x\ny\n9\n1\n0\n0\n0\nline\n".cstring, 19)
    d.pump
    var b: array[8, char]
    check read(bad, addr b[0], 8) <= 0         # closed by the daemon
    discard close(bad)
  test "memfd datagram":
    when defined(linux):
      let body = "MESSAGE=" & repeat('m', 200_000) & "\nBIG=1\n"
      check journalSend(su.roots.sysrun, [("MESSAGE", repeat('m', 200_000)), ("BIG", "1")])
      d.waitFor(proc(): bool = d.all.len > 0)
      check d.all[0].message.len == 200_000 and d.all[0].getField("BIG") == "1"
    else: skip()
  test "MaxLevelStore drops less important entries":
    d.setup.conf.maxLevelStore = 4
    check journalSend(su.roots.sysrun, [("MESSAGE", "dbg"), ("PRIORITY", "7")])
    check journalSend(su.roots.sysrun, [("MESSAGE", "err"), ("PRIORITY", "3")])
    d.pump
    check d.all.mapIt(it.message) == @["err"]

suite "daemon control":
  setup:
    let base = tmpDir("dc")
    var su = mkSetup(base)
    su.conf.systemMaxFileSize = 1 shl 20
    let d = newJournald(su)
  teardown:
    d.shutdown

  proc ctl(d: Journald; req: JsonNode): JsonNode =
    let fd = connectUnix(controlSocketPath(d.setup.roots.rt), true)
    doAssert fd >= 0
    discard fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) or O_NONBLOCK)
    discard write(fd, ($req & "\n").cstring, ($req).len + 1)
    var reply = ""
    for _ in 0 ..< 100:
      d.step(20)
      var buf: array[1024, char]
      let n = recv(SocketHandle(fd), addr buf[0], 1024, 0)
      if n > 0:
        for i in 0 ..< n: reply.add buf[i]
        if '\n' in reply: break
    discard close(fd)
    parseJson(reply)

  test "rotate, vacuum, sync, disk-usage":
    for i in 1 .. 3:
      journalSend(su.roots.sysrun, [("MESSAGE", "m" & $i)])
      d.pump
      check d.ctl(%*{"verb": "rotate"})["ok"].getBool
    check listFiles(persistentDir(su)).len == 3
    check d.ctl(%*{"verb": "sync"})["ok"].getBool
    check d.ctl(%*{"verb": "disk-usage"})["bytes"].getInt > 0
    let v = d.ctl(%*{"verb": "vacuum", "max_size": 0})
    check v["ok"].getBool and v["freed"].getInt > 0
    check listFiles(persistentDir(su)).len == 0 or listFiles(persistentDir(su)).allIt(not it.archived)
  test "vacuum by age":
    journalSend(su.roots.sysrun, [("MESSAGE", "old")])
    d.pump
    discard d.ctl(%*{"verb": "rotate"})
    let r = d.ctl(%*{"verb": "vacuum", "max_age_usec": 0})
    check r["freed"].getInt > 0
  test "errors":
    check not d.ctl(%*{"verb": "explode"})["ok"].getBool
    check d.ctl(%*{"verb": "explode"})["error"].getStr.contains("unknown verb")
  test "flush is a no-op while persistent storage is unavailable":
    check d.ctl(%*{"verb": "flush"})["flushed"].getBool == false

suite "storage selection and flush":
  test "volatile until ST appears, then flush moves entries":
    let base = tmpDir("ds")
    var su = mkSetup(base)
    removeDir(su.roots.st)
    let d = newJournald(su)
    defer: d.shutdown
    check d.volatile
    journalSend(su.roots.sysrun, [("MESSAGE", "early")])
    d.waitFor(proc(): bool = d.all.len == 1)
    createDir(su.roots.st)
    check d.tryFlush()
    check not d.volatile
    check listFiles(volatileDir(su)).len == 0
    journalSend(su.roots.sysrun, [("MESSAGE", "late")])
    d.waitFor(proc(): bool = d.all.len == 2)
    check d.all.mapIt(it.message) == @["early", "late"]
    check listFiles(persistentDir(su)).len == 1
    check not d.tryFlush()
  test "persistent when ST exists, leftovers flushed at start":
    let base = tmpDir("dp")
    var su = mkSetup(base)
    su.conf.storage = smVolatile
    var d = newJournald(su)
    journalSend(su.roots.sysrun, [("MESSAGE", "left")])
    d.waitFor(proc(): bool = d.all.len == 1)
    d.shutdown
    su.conf.storage = smAuto
    d = newJournald(su)
    defer: d.shutdown
    check not d.volatile
    check d.all.mapIt(it.message) == @["left"]
    check listFiles(volatileDir(su)).len == 0
  test "Storage=none stores nothing, Storage=volatile never flushes":
    let base = tmpDir("dn")
    var su = mkSetup(base)
    su.conf.storage = smNone
    let d = newJournald(su)
    defer: d.shutdown
    journalSend(su.roots.sysrun, [("MESSAGE", "x")])
    d.pump
    check d.store == nil and d.all.len == 0
    let base2 = tmpDir("dv")
    var s2 = mkSetup(base2)
    s2.conf.storage = smVolatile
    let d2 = newJournald(s2)
    defer: d2.shutdown
    check d2.volatile and not d2.tryFlush()
  test "persistent mode without ST falls back to volatile with a warning":
    let base = tmpDir("dw")
    var su = mkSetup(base)
    removeDir(su.roots.st)
    su.conf.storage = smPersistent
    let d = newJournald(su)
    defer: d.shutdown
    check d.volatile and d.warnings.len == 1
    check not dirExists(su.roots.st)         # ST is never created

suite "socket activation":
  test "inherited descriptors are classified by path and used":
    let base = tmpDir("da")
    var su = mkSetup(base)
    let nat = bindUnix(nativeSocketPath(su.roots.sysrun), false, 0o666)
    let str = bindUnix(streamSocketPath(su.roots.sysrun), true, 0o666)
    let sys = bindUnix(syslogSocketPath(su.roots.sysrun), false, 0o666)
    su.inherited = @[(str, "stdout"), (nat, "stdout"), (sys, "dev-log")]
    let d = newJournald(su)
    defer: d.shutdown
    journalSend(su.roots.sysrun, [("MESSAGE", "n")])
    sendDatagram(syslogSocketPath(su.roots.sysrun), "<14>t: s")
    let fd = openStream(su.roots.sysrun, StreamHeader(identifier: "i", priority: 6, levelMax: -1, facility: 3))
    discard write(fd, "line\n".cstring, 5)
    discard close(fd)
    d.waitFor(proc(): bool = d.all.len == 3)
    check d.all.mapIt(it.getField("_TRANSPORT")).sorted == @["journal", "stdout", "syslog"]
  test "LISTEN_FDS parsing refuses another pid":
    putEnv("LISTEN_PID", "1")
    putEnv("LISTEN_FDS", "2")
    check inheritedSockets().len == 0
    check not existsEnv("LISTEN_FDS")
    putEnv("LISTEN_PID", $getpid())
    putEnv("LISTEN_FDS", "2")
    putEnv("LISTEN_FDNAMES", "stdout:dev-log")
    check inheritedSockets() == @[(cint(3), "stdout"), (cint(4), "dev-log")]

suite "notify":
  test "READY=1 and watchdog pings go to NOTIFY_SOCKET":
    let base = tmpDir("dy")
    var su = mkSetup(base)
    let nsock = base / "notify"
    let rfd = bindUnix(nsock, false, 0o600, passCreds = false)
    su.notifySocket = nsock
    su.watchdogUsec = 40_000
    let clk = FakeClock(mono: 1000, real: 1_700_000_000_000_000'i64)
    su.clock = clk
    let d = newJournald(su)
    defer: d.shutdown
    d.notify("READY=1")
    var dg: Datagram
    check recvDatagram(rfd, 100, dg) and dg.data == "READY=1"
    clk.advance(21_000)
    d.step(0)
    check recvDatagram(rfd, 100, dg) and dg.data == "WATCHDOG=1"

suite "user scope daemon":
  test "a stream's UNIT is trusted from the daemon's own user and tagged _SYSTEMD_USER_UNIT":
    let base = tmpDir("du")
    let su = mkSetup(base, scUser)
    let d = newJournald(su)
    let fd = openStream(su.roots.sysrun, StreamHeader(identifier: "svc", unit: "u.service",
      priority: 6, levelPrefix: false, levelMax: -1, facility: 3))
    check fd >= 0
    discard write(fd, "from the user unit\n".cstring, 19)
    discard close(fd)
    d.waitFor(proc(): bool = d.all.len == 1)
    let es = d.all
    check es.len == 1
    check es[0].getField("_SYSTEMD_USER_UNIT") == "u.service"
    check es[0].getField("_SYSTEMD_UNIT") == ""
    d.shutdown
  test "kernel messages are not read in user scope":
    let base = tmpDir("du2")
    var su = mkSetup(base, scUser)
    var fds: array[2, cint]
    check socketpair(AF_UNIX, SOCK_DGRAM, 0, fds) == 0
    su.kmsgFd = fds[0]
    let d = newJournald(su)
    check write(fds[1], "6,1,1,-;x\n".cstring, 10) == 10
    d.pump
    check d.all.len == 0
    d.shutdown
    discard close(fds[0]); discard close(fds[1])
