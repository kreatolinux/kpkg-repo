## Kernel log intake, rate limiting and syslog forwarding (sections 12.3, 12.5, 12.8).
import std/[os, posix, unittest, strutils, sequtils]
import journal/[format, reader, daemon, conf, kmsg, ratelimit, sockutil, storage]
import common/[roots, clock]
import ./jtest

proc mkSetup(base: string; clk: clock.Clock = nil): JournaldSetup =
  let r = testRoots(base, scSystem)
  result = defaultSetup(r)
  result.conf = defaultConf()
  result.hostname = "testhost"
  result.bootId = bootId(7)
  result.machineId = bootId(9)
  result.notifySocket = ""
  if clk != nil: result.clock = clk

proc all(d: Journald; q = JournalQuery()): seq[JournalEntry] =
  if d.store != nil: d.store.sync
  openJournal(@[volatileDir(d.setup), persistentDir(d.setup)]).entries(q)

proc kpair(): array[2, cint] =
  var fds: array[2, cint]
  doAssert socketpair(AF_UNIX, SOCK_DGRAM, 0, fds) == 0
  discard fcntl(fds[0], F_SETFL, fcntl(fds[0], F_GETFL) or O_NONBLOCK)
  fds

proc kput(fd: cint; s: string) = doAssert write(fd, s.cstring, s.len) == s.len

suite "kmsg parsing":
  test "record, continuation lines and escapes":
    var r: KmsgRecord
    check parseKmsg("6,339,5140900,-;NET: Registered\\x20protocol\n SUBSYSTEM=net\n DEVICE=+net:eth0\n", r)
    check r.priority == 6 and r.facility == 0 and r.seq == 339 and r.usec == 5140900
    check r.message == "NET: Registered protocol" and r.subsystem == "net" and r.device == "+net:eth0"
    check parseKmsg("30,1,2,-,caller=T1;daemon says hi", r)
    check r.priority == 6 and r.facility == 3
  test "garbage is rejected":
    var r: KmsgRecord
    check not parseKmsg("no semicolon", r)
    check not parseKmsg("x,y,z;msg", r)
    check not parseKmsg("6,1;msg", r)
  test "fields":
    var r: KmsgRecord
    discard parseKmsg("4,7,9,-;boom\n SYSNAME=eth0\n SUBSYSTEM=net\n", r)
    let f = kmsgFields(r)
    check ("SYSLOG_IDENTIFIER", "kernel") in f and ("_TRANSPORT", "kernel") in f
    check ("_UDEV_SYSNAME", "eth0") in f and ("_KERNEL_SUBSYSTEM", "net") in f

suite "kmsg intake":
  test "records become entries with boot-time conversion and dedupe on restart":
    let base = tmpDir("km")
    let clk = testClock()
    var su = mkSetup(base, clk)
    let k1 = kpair()
    su.kmsgFd = k1[0]
    var d = newJournald(su)
    kput(k1[1], "6,1,1000000,-;first\n")
    kput(k1[1], "3,2,2500000,-;second\n SUBSYSTEM=usb\n")
    d.step(20)
    var es = d.all
    check es.mapIt(it.message) == @["first", "second"]
    let off = clk.real - clk.mono
    check es[0].realtime == off + 1_000_000 and es[1].realtime == off + 2_500_000
    check es[1].monotonic == 2_500_000 and es[1].priority == 3
    check es[1].getField("_TRANSPORT") == "kernel" and es[1].getField("_KERNEL_SUBSYSTEM") == "usb"
    check es[1].getField("SYSLOG_IDENTIFIER") == "kernel"
    check loadLastSeq(su.roots.rt, idHex(su.bootId)) == 2
    d.shutdown
    # restart: the kernel ring still holds 1 and 2, plus a new record 3
    let k2 = kpair()
    su.kmsgFd = k2[0]
    kput(k2[1], "6,1,1000000,-;first\n")
    kput(k2[1], "3,2,2500000,-;second\n")
    kput(k2[1], "5,3,3000000,-;third\n")
    d = newJournald(su)
    d.step(20)
    es = d.all
    check es.mapIt(it.message) == @["first", "second", "third"]
    d.shutdown
    check loadLastSeq(su.roots.rt, idHex(su.bootId)) == 3
    # another boot ignores the stored sequence
    check loadLastSeq(su.roots.rt, idHex(bootId(8))) == 0
  test "ReadKMsg=no does not read":
    let base = tmpDir("km2")
    var su = mkSetup(base)
    let k = kpair()
    su.kmsgFd = k[0]
    su.conf.readKmsg = false
    var d = newJournald(su)
    kput(k[1], "6,1,1000000,-;ignored\n")
    d.step(20)
    check d.all.len == 0
    d.shutdown
  test "oversized or torn input does not stop the loop":
    let base = tmpDir("km3")
    var su = mkSetup(base)
    let k = kpair()
    su.kmsgFd = k[0]
    let d = newJournald(su)
    kput(k[1], "garbage\n")
    kput(k[1], "6,5,1,-;ok\n")
    d.step(20)
    check d.all.mapIt(it.message) == @["ok"]
    d.shutdown

suite "rate limiter":
  test "burst per interval, report when the window ends":
    let r = newRateLimiter()
    for i in 0 ..< 3: check r.check("a", 100, 1000, 3).allow
    check not r.check("a", 200, 1000, 3).allow
    check not r.check("a", 300, 1000, 3).allow
    check r.check("b", 300, 1000, 3).allow            # another source
    let v = r.check("a", 1200, 1000, 3)
    check v.allow and v.reportSuppressed == 2
  test "disabled and anonymous":
    let r = newRateLimiter()
    for i in 0 ..< 10: check r.check("a", 1, 0, 3).allow and r.check("a", 1, 10, 0).allow
    for i in 0 ..< 10: check r.check("", 1, 10, 1).allow
    check r.size == 0
  test "sweep reports silent sources and forgets idle ones":
    let r = newRateLimiter()
    discard r.check("a", 0, 100, 1)
    discard r.check("a", 1, 100, 1)
    discard r.check("a", 2, 100, 1)
    discard r.check("idle", 0, 100, 1)
    check r.sweep(50).len == 0
    check r.sweep(200) == @[("a", 2'i64)]
    check r.size == 0

suite "daemon rate limiting":
  test "entries beyond the burst are dropped and one Suppressed entry follows":
    let base = tmpDir("rl")
    let clk = testClock()
    var su = mkSetup(base, clk)
    su.conf.rateIntervalUsec = 10_000_000
    su.conf.rateBurst = 5
    let d = newJournald(su)
    let unit = @[("_SYSTEMD_UNIT", "noisy.service")]
    for i in 0 ..< 20: d.record(@[("MESSAGE", "spam " & $i)], "journal", unit)
    d.record(@[("MESSAGE", "other")], "journal", @[("_SYSTEMD_UNIT", "quiet.service")])
    check d.all.len == 6
    check d.all(JournalQuery(units: @["noisy.service"])).len == 5
    clk.advance(11_000_000)
    d.record(@[("MESSAGE", "later")], "journal", unit)
    let es = d.all(JournalQuery(units: @["noisy.service"]))
    check es.len == 7        # 5 + Suppressed + later
    let sup = es.filterIt(it.message.startsWith("Suppressed"))
    check sup.len == 1 and sup[0].message == "Suppressed 15 messages from noisy.service"
    check sup[0].getField("_TRANSPORT") == "driver"
    d.shutdown
  test "a silent source is reported by the periodic sweep":
    let base = tmpDir("rl2")
    let clk = testClock()
    var su = mkSetup(base, clk)
    su.conf.rateIntervalUsec = 5_000_000
    su.conf.rateBurst = 2
    let d = newJournald(su)
    for i in 0 ..< 5: d.record(@[("MESSAGE", $i)], "journal", @[("_COMM", "chatty"), ("_UID", "1000")])
    check d.all.len == 2
    clk.advance(6_000_000)
    d.step(0)
    let sup = d.all.filterIt(it.message.startsWith("Suppressed"))
    check sup.len == 1 and sup[0].message == "Suppressed 3 messages from chatty"
    d.shutdown
  test "a stream's own limits override the configuration":
    let base = tmpDir("rl3")
    var su = mkSetup(base)
    let d = newJournald(su)
    for i in 0 ..< 6:
      d.record(@[("MESSAGE", $i)], "stdout", @[("_SYSTEMD_UNIT", "s.service")], rate = (1_000_000'i64, 2'i64))
    check d.all.len == 2
    d.shutdown
  test "interval 0 turns limiting off; kernel and driver entries are exempt":
    let base = tmpDir("rl4")
    var su = mkSetup(base)
    su.conf.rateIntervalUsec = 0
    su.conf.rateBurst = 1
    let d = newJournald(su)
    for i in 0 ..< 5: d.record(@[("MESSAGE", $i)], "journal", @[("_SYSTEMD_UNIT", "s.service")])
    check d.all.len == 5
    d.shutdown
  test "conf keys":
    var c = defaultConf()
    check c.rateIntervalUsec == 30_000_000 and c.rateBurst == 10000 and c.readKmsg
    parseJournaldConf("[Journal]\nRateLimitIntervalSec=2min\nRateLimitBurst=7\nForwardToSyslog=yes\nReadKMsg=no\nMaxLevelSyslog=warning\n", c)
    check c.rateIntervalUsec == 120_000_000 and c.rateBurst == 7 and c.forwardToSyslog
    check not c.readKmsg and c.maxLevelSyslog == 4 and c.warnings.len == 0
    parseJournaldConf("[Journal]\nRateLimitBurst=x\nForwardToSyslog=maybe\n", c)
    check c.warnings.len == 2

suite "syslog forwarding":
  test "entries are sent as RFC 3164 datagrams when the socket is bound":
    let base = tmpDir("fw")
    var su = mkSetup(base)
    su.conf.forwardToSyslog = true
    su.conf.maxLevelSyslog = 5
    let d = newJournald(su)
    d.record(@[("MESSAGE", "nobody listens"), ("PRIORITY", "6")], "journal")   # ignored, no socket
    let path = su.roots.sysrun / "journal" / "syslog"
    let sock = bindUnix(path, false, 0o666)
    check sock >= 0
    d.record(@[("MESSAGE", "hello there"), ("PRIORITY", "3"), ("SYSLOG_IDENTIFIER", "prog"),
               ("SYSLOG_PID", "42"), ("SYSLOG_FACILITY", "3")], "journal")
    d.record(@[("MESSAGE", "too chatty"), ("PRIORITY", "6")], "journal")        # above MaxLevelSyslog
    var dg: Datagram
    check recvDatagram(sock, 4096, dg)
    check dg.data.startsWith("<27>") and dg.data.endsWith(" testhost prog[42]: hello there")
    check not recvDatagram(sock, 4096, dg)
    check d.all.len == 3                    # forwarding does not replace storing
    discard close(sock)
    d.shutdown
  test "a stream with forward-to-syslog forwards even with ForwardToSyslog=no":
    let base = tmpDir("fw2")
    let su = mkSetup(base)
    let d = newJournald(su)
    let sock = bindUnix(su.roots.sysrun / "journal" / "syslog", false, 0o666)
    d.record(@[("MESSAGE", "a"), ("PRIORITY", "6")], "stdout", forward = true)
    d.record(@[("MESSAGE", "b"), ("PRIORITY", "6")], "stdout")
    var dg: Datagram
    check recvDatagram(sock, 4096, dg)
    check dg.data.endsWith(" a")
    check not recvDatagram(sock, 4096, dg)
    discard close(sock)
    d.shutdown
