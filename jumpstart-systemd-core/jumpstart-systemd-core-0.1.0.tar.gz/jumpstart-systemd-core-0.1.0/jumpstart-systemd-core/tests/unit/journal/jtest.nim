## Helpers shared by the journal tests.
import std/[os, strutils]
import journal/format
import common/clock

proc tmpDir*(name: string): string =
  result = getTempDir() / ("sdcj-" & name & "-" & $getCurrentProcessId())
  removeDir(result)
  createDir(result)

proc bootId*(n: int): string =
  result = repeat(char(n), 16)

proc mk*(realtime: int64; msg: string; unit = ""; prio = 6; boot = 1;
         extra: seq[Field] = @[]): JournalEntry =
  result = JournalEntry(realtime: realtime, monotonic: realtime div 2, bootId: bootId(boot),
    priority: prio)
  result.fields.add ("MESSAGE", msg)
  if prio != NoPriority: result.fields.add ("PRIORITY", $prio)
  if unit.len > 0: result.fields.add ("_SYSTEMD_UNIT", unit)
  result.fields.add extra

proc testClock*(start = 1_000_000_000_000'i64): FakeClock = FakeClock(mono: 1000, real: start)
