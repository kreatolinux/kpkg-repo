import std/[unittest, strutils, sequtils]
import journal/[format, intake_native, intake_syslog, intake_stream]
when defined(linux):
  import std/[os, posix]
  import journal/sockutil

proc lenBytes(n: int): string =
  for i in 0 ..< 8: result.add char((uint64(n) shr (8 * i)) and 0xFF)

suite "native":
  test "text records":
    check parseNative("MESSAGE=hi\nPRIORITY=3\nFOO=a=b\n") ==
      @[("MESSAGE", "hi"), ("PRIORITY", "3"), ("FOO", "a=b")]
  test "binary and multi-line values":
    let d = "MESSAGE\n" & lenBytes(7) & "a\nb\0c\xffd\n" & "X=1\n"
    check parseNative(d) == @[("MESSAGE", "a\nb\0c\xffd"), ("X", "1")]
  test "empty value and no trailing newline":
    check parseNative("A=\nB=x") == @[("A", ""), ("B", "x")]
  test "trusted and invalid keys are dropped":
    check parseNative("_PID=1\n_TRANSPORT=x\nlower=1\nOK=1\nBAD-KEY=2\n" & repeat('A', 65) & "=1\n") ==
      @[("OK", "1")]
    check parseNative("=novalue\nA=1\n") == @[("A", "1")]
  test "invalid PRIORITY is dropped":
    check parseNative("PRIORITY=9\nPRIORITY=x\nPRIORITY=\nMESSAGE=m\n") == @[("MESSAGE", "m")]
    check parseNative("PRIORITY=0\n") == @[("PRIORITY", "0")]
  test "entry without MESSAGE is kept":
    check parseNative("FOO=bar\n") == @[("FOO", "bar")]
  test "truncated binary record stops parsing":
    check parseNative("A=1\nB\n" & lenBytes(100) & "short") == @[("A", "1")]
    check parseNative("A=1\nB\n\x01\x02") == @[("A", "1")]
  test "encode round trip":
    let f = @[("MESSAGE", "multi\nline"), ("PRIORITY", "4"), ("PLAIN", "x")]
    check parseNative(encodeNative(f)) == f
    check encodeNative([("MESSAGE", "a")]) == "MESSAGE=a\n"
  test "memfd path":
    when defined(linux):
      let payload = "MESSAGE=" & repeat('z', 300_000) & "\n"
      let fd = memfdOf(payload)
      check fd >= 0
      check readSealedFd(fd, 1 shl 24) == payload
      expect OSError: discard readSealedFd(fd, 10)
      discard close(fd)
      let plain = open(getTempDir() / "sdcj-plain", fmReadWrite)    # not a sealed memfd
      expect OSError: discard readSealedFd(cint(plain.getFileHandle), 100)
      plain.close()
    else:
      skip()

suite "syslog":
  proc f(d: string): seq[Field] = parseSyslog(d)
  proc get(fs: seq[Field]; k: string): string =
    for x in fs:
      if x.key == k: return x.value
  test "tag, pid, message":
    let r = f("<13>sshd[1234]: Accepted publickey\n")
    check r.get("PRIORITY") == "5" and r.get("SYSLOG_FACILITY") == "1"
    check r.get("SYSLOG_IDENTIFIER") == "sshd" and r.get("SYSLOG_PID") == "1234"
    check r.get("MESSAGE") == "Accepted publickey" and r.get("_TRANSPORT") == "syslog"
  test "priority and facility":
    let r = f("<38>su: session opened")
    check r.get("PRIORITY") == "6" and r.get("SYSLOG_FACILITY") == "4"
  test "timestamp and host are skipped":
    let r = f("<30>Oct 17 12:00:30 myhost cron[88]: (root) CMD (run)")
    check r.get("SYSLOG_IDENTIFIER") == "cron" and r.get("SYSLOG_PID") == "88"
    check r.get("MESSAGE") == "(root) CMD (run)"
    let r2 = f("<30>Oct  7 12:00:30 kernel: hello")
    check r2.get("SYSLOG_IDENTIFIER") == "kernel" and r2.get("MESSAGE") == "hello"
  test "no tag":
    let r = f("<14>just some text with: a colon later")
    check r.get("SYSLOG_IDENTIFIER") == "" and r.get("MESSAGE") == "just some text with: a colon later"
  test "no PRI: user facility, notice":
    let r = f("tag: msg\n")
    check r.get("PRIORITY") == "5" and r.get("SYSLOG_FACILITY") == "1"
    check r.get("SYSLOG_IDENTIFIER") == "tag" and r.get("MESSAGE") == "msg"
    check f("<999>x: y").get("PRIORITY") == "5"
  test "trailing newlines and NULs are removed":
    check f("<14>t: m\n\n\0\0").get("MESSAGE") == "m"
  test "bad pid bracket":
    let r = f("<14>t[abc]: m")
    check r.get("SYSLOG_PID") == ""

suite "stream":
  proc hdr(ident = "myid", unit = "a.service", prio = 6, prefix = true): string =
    encodeStreamHeader(StreamHeader(identifier: ident, unit: unit, priority: prio,
                       levelPrefix: prefix, levelMax: -1, facility: 3))
  test "header round trip with extensions":
    var h = defaultHeader()
    h.identifier = "id"; h.unit = "u.service"; h.priority = 4; h.levelPrefix = false
    h.forwardKmsg = true
    h.extraFields = @[("FOO", "bar"), ("BAZ", "q=1")]
    h.levelMax = 5; h.rateIntervalUsec = 1000; h.rateBurst = 7; h.facility = 9
    let p = newStreamParser()
    check p.feed(encodeStreamHeader(h)).len == 0
    check p.ready and p.header == h
  test "plain header and lines":
    let p = newStreamParser()
    let r = p.feed(hdr() & "one\ntwo\n")
    check p.header.identifier == "myid" and p.header.unit == "a.service"
    check r.mapIt(it.message) == @["one", "two"] and r.mapIt(it.priority) == @[6, 6]
  test "unknown X-SDC lines ignored; none is fine":
    let p = newStreamParser()
    discard p.feed("X-SDC-Future: 1\n" & hdr())
    check p.ready and p.header.facility == 3 and p.header.levelMax == -1
  test "bytes arriving one at a time":
    let p = newStreamParser()
    var got: seq[StreamLine]
    for c in hdr() & "ab\ncd\n": got.add p.feed($c)
    check got.mapIt(it.message) == @["ab", "cd"]
  test "level prefix":
    let p = newStreamParser()
    let r = p.feed(hdr() & "<3>bad\nplain\n<7>dbg\n<9>odd\n<4>")
    check r.mapIt((it.priority, it.message)) == @[(3, "bad"), (6, "plain"), (7, "dbg"), (6, "<9>odd")]
    check p.finish.len == 0     # "<4>" alone is an empty line after stripping
  test "level prefix off keeps the text":
    let p = newStreamParser()
    let r = p.feed(hdr(prefix = false) & "<3>text\n")
    check r[0].message == "<3>text" and r[0].priority == 6
  test "partial line is held until newline or EOF":
    let p = newStreamParser()
    check p.feed(hdr() & "par").len == 0
    check p.feed("tial").len == 0
    check p.finish.mapIt(it.message) == @["partial"]
    check p.finish.len == 0
  test "LineMax splitting":
    let p = newStreamParser(lineMax = 4)
    let r = p.feed(hdr() & "abcdefghij\nxy\n")
    check r.mapIt(it.message) == @["abcd", "efgh", "ij", "xy"]
    let q = newStreamParser(lineMax = 4)
    check q.feed(hdr() & "abcdef").mapIt(it.message) == @["abcd"]
    check q.finish.mapIt(it.message) == @["ef"]
  test "empty lines are skipped":
    let p = newStreamParser()
    check p.feed(hdr() & "\n\nx\n").mapIt(it.message) == @["x"]
  test "invalid header fails":
    let p = newStreamParser()
    discard p.feed("id\nunit\n9\n1\n0\n0\n0\nrest\n")
    check p.failed
    check p.feed("more").len == 0
    let q = newStreamParser()
    discard q.feed("id\nunit\n6\nx\n0\n0\n0\n")
    check q.failed
  test "extra fields cannot be trusted names":
    let p = newStreamParser()
    var h = defaultHeader()
    h.extraFields = @[("_PID", "1"), ("OK", "1")]
    discard p.feed(encodeStreamHeader(h))
    check p.header.extraFields == @[("OK", "1")]
