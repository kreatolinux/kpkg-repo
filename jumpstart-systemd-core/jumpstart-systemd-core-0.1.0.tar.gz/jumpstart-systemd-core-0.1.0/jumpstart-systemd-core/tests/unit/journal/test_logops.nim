import std/[os, json, unittest, options, strutils, sequtils, posix]
import journal/[format, storage, logops, sockutil, client, intake_native]
import common/[roots, clock, results]
import ./jtest

proc seed(r: Roots; n: int; scope = scSystem) =
  let dir = r.rt / "journal" / "m"
  let st = openStorage(dir, bootId(2), StorageLimits(), testClock(), newRng(1))
  for i in 1 .. n:
    var e = mk(1_760_702_400_000_000'i64 + int64(i) * 1_000_000, "line " & $i,
               unit = (if i mod 2 == 0: "even.service" else: "odd.service"), prio = i mod 8)
    if scope == scUser:
      e.fields.add ("_SYSTEMD_USER_UNIT", "u.service")
    discard st.store(e)
  st.sync

suite "logops":
  test "levels":
    check [0, 1, 2, 3, 4, 5, 6, 7, NoPriority].mapIt(levelOf(it)) ==
      @["fatal", "fatal", "fatal", "error", "warn", "notice", "info", "debug", "info"]
    check priorityOfLevel("warn") == 4 and priorityOfLevel("fatal") == 2 and priorityOfLevel("loud") == -1
  test "rfc3339":
    check rfc3339(1_760_702_400_123_456'i64) == "2025-10-17T12:00:00.123456Z"
    check rfc3339(5) == "1970-01-01T00:00:00.000005Z"
  test "message cleaning":
    check cleanMessage("a\nb\tc\x01d") == "a b c d"
    check cleanMessage("caf\xC3\xA9 ok") == "caf\xC3\xA9 ok"
    check cleanMessage("bad \xff\xfe bytes") == "bad \xEF\xBF\xBD\xEF\xBF\xBD bytes"
    check cleanMessage("trunc \xC3") == "trunc \xEF\xBF\xBD"
    check cleanMessage("\xED\xA0\x80") == "\xEF\xBF\xBD\xEF\xBF\xBD\xEF\xBF\xBD"   # surrogate
    check cleanMessage(repeat('x', 9000)).len == 8192
    check cleanMessage(repeat("\xC3\xA9", 5000)).len <= 8192
  test "readEntries returns the last N oldest first, with unit filter and window":
    let r = testRoots(tmpDir("lo"), scSystem)
    seed(r, 20)
    let es = readEntries(r, "", none(int64), none(int64), 3)
    check es.mapIt(it.message) == @["line 18", "line 19", "line 20"]
    check es[2].level == "warn" and es[2].unit == "even.service"
    check es[0].time == rfc3339(1_760_702_400_000_000'i64 + 18_000_000)
    check readEntries(r, "odd.service", none(int64), none(int64), 100).len == 10
    check readEntries(r, "", none(int64), none(int64), 0).len == 20           # default 1000
    let since = some(1_760_702_400_000_000'i64 + 15_000_000)
    check readEntries(r, "", since, none(int64), 100).len == 6
    check readEntries(r, "", since, some(1_760_702_400_000_000'i64 + 16_000_000), 100).len == 2
    check readEntries(r, "nothing.service", none(int64), none(int64), 5).len == 0
  test "user scope filters _SYSTEMD_USER_UNIT":
    let r = testRoots(tmpDir("lou"), scUser)
    seed(r, 4, scUser)
    check readEntries(r, "u.service", none(int64), none(int64), 100).len == 4
    check readEntries(r, "even.service", none(int64), none(int64), 100).len == 0
  test "message and unit fallbacks":
    let r = testRoots(tmpDir("lof"), scSystem)
    let st = openStorage(r.rt / "journal" / "m", bootId(2), StorageLimits(), testClock(), newRng(1))
    var a = mk(10, "x", extra = @[("UNIT", "from.unit")])
    var b = mk(11, "y", extra = @[("SYSLOG_IDENTIFIER", "ident")])
    var c = mk(12, "z")
    var all = @[a, b, c]
    for e in all.mitems: discard st.store(e)
    st.sync
    check readEntries(r, "", none(int64), none(int64), 10).mapIt(it.unit) == @["from.unit", "ident", ""]
  test "writeEntry sends a native datagram or reports E_BACKEND":
    let r = testRoots(tmpDir("low"), scSystem)
    let res = writeEntry(r, "a.service", "error", "boom")
    check not res.ok and res.error.startsWith("E_BACKEND")
    check not writeEntry(r, "", "loud", "x").ok
    let fd = bindUnix(nativeSocketPath(r.sysrun), false, 0o600, passCreds = false)
    defer: discard close(fd)
    check writeEntry(r, "a.service", "error", "boom").ok
    var dg: Datagram
    check recvDatagram(fd, 4096, dg)
    let f = parseNative(dg.data)
    check ("MESSAGE", "boom") in f and ("PRIORITY", "3") in f and ("UNIT", "a.service") in f
    check ("SYSLOG_IDENTIFIER", "jumpstart") in f
  test "journaldControl without journald":
    let r = testRoots(tmpDir("loc"), scSystem)
    let res = journaldControl(r, %*{"verb": "rotate"})
    check not res.ok and res.error.startsWith("E_BACKEND")
  test "followEntries: initial 10 then new":
    let r = testRoots(tmpDir("lof2"), scSystem)
    seed(r, 25)
    var got: seq[string]
    var rounds = 0
    followEntries(r, "", none(int64), proc(e: LogEntry): bool =
      got.add e.message
      true, proc(): bool =
        inc rounds
        if rounds == 2:
          let st = openStorage(r.rt / "journal" / "m", bootId(2), StorageLimits(), testClock(), newRng(1))
          var e = mk(1_760_702_500_000_000'i64, "fresh")
          discard st.store(e)
          st.sync
        rounds > 4)
    check got.len == 11 and got[0] == "line 16" and got[^1] == "fresh"
