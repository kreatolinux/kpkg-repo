## journalctl against a fixture journal; the time zone is pinned to UTC.
import std/[os, unittest, options, strutils, json, sequtils, algorithm, posix]
import journal/[format, storage]
import tools/journalctl
import common/[roots, clock]
import ./jtest

const T0 = 1_760_702_400_000_000'i64     # Fri 2025-10-17 12:00:00 UTC

type Run = tuple[code: int, outp, err: string]

proc fixture(): Roots =
  putEnv("TZ", "UTC")
  result = testRoots(tmpDir("jc"), scSystem)
  let st = openStorage(result.rt / "journal" / "m", bootId(2), StorageLimits(), testClock(), newRng(1))
  proc put(sec, usec: int64; msg, ident, unit: string; prio, boot: int; extra: seq[Field] = @[]) =
    var e = mk(T0 + sec * 1_000_000 + usec, msg, unit, prio, boot, extra)
    e.monotonic = sec * 1_000_000 + usec
    e.fields.add ("SYSLOG_IDENTIFIER", ident)
    e.fields.add ("_HOSTNAME", "box")
    discard st.store(e)
  put(0, 123456, "Started thing", "systemd", "a.service", 6, 1, @[("_PID", "1"), ("UNIT", "a.service")])
  put(10, 0, "disk failure", "kernel", "", 3, 1, @[("_TRANSPORT", "kernel")])
  put(3600, 5, "boot two begins", "sshd", "sshd.service", 5, 2, @[("_PID", "77")])
  put(3601, 0, "multi\nline", "b", "b.service", 7, 2, @[("_COMM", "bprog")])
  put(7200, 0, "error in b", "b", "b.service", 3, 2)
  st.sync

proc run(r: Roots; args: varargs[string]): Run =
  var o, e: string
  proc out1(s: string) = o.add s
  proc err1(s: string) = e.add s
  result.code = journalctlRun(@args, r, out1, err1, nowUsec = T0 + 86_400 * 1_000_000'i64)
  result.outp = o
  result.err = e

suite "journalctl output":
  let r = fixture()
  test "short is the default":
    let x = r.run("--no-pager", "-u", "a")
    check x.code == 0
    check x.outp == "Oct 17 12:00:00 box systemd[1]: Started thing\n"
  test "formats of one entry":
    let first = @["-n", "1", "-u", "a.service", "--no-pager", "-o"]
    check r.run(first & "short-iso").outp == "2025-10-17T12:00:00+0000 box systemd[1]: Started thing\n"
    check r.run(first & "short-iso-precise").outp ==
      "2025-10-17T12:00:00.123456+0000 box systemd[1]: Started thing\n"
    check r.run(first & "short-precise").outp == "Oct 17 12:00:00.123456 box systemd[1]: Started thing\n"
    check r.run(first & "short-full").outp == "Fri 2025-10-17 12:00:00 UTC box systemd[1]: Started thing\n"
    check r.run(first & "short-unix").outp == "1760702400.123456 box systemd[1]: Started thing\n"
    check r.run(first & "short-monotonic").outp == "[    0.123456] box systemd[1]: Started thing\n"
    check r.run(first & "cat").outp == "Started thing\n"
    check r.run("-n", "1", "-u", "a", "--no-hostname").outp == "Oct 17 12:00:00 systemd[1]: Started thing\n"
  test "verbose":
    let x = r.run("-u", "a", "-o", "verbose").outp.splitLines
    check x[0].startsWith("Fri 2025-10-17 12:00:00.123456 UTC [s=")
    check "    MESSAGE=Started thing" in x and "    _PID=1" in x and "    PRIORITY=6" in x
    check r.run("-u", "a", "-o", "verbose", "--output-fields=MESSAGE").outp.count("    ") == 1
  test "json":
    let line = r.run("-u", "a", "-o", "json").outp.strip
    let j = parseJson(line)
    check j["MESSAGE"].getStr == "Started thing" and j["PRIORITY"].getStr == "6"
    check j["__REALTIME_TIMESTAMP"].getStr == $(T0 + 123456) and j["_BOOT_ID"].getStr == idHex(bootId(1))
    check j["__CURSOR"].getStr.startsWith("s=") and j["__MONOTONIC_TIMESTAMP"].getStr == "123456"
    check line.find("\n") < 0
    check r.run("-u", "a", "-o", "json-pretty").outp.splitLines.len > 5
    check r.run("-u", "a", "-o", "json-sse").outp.startsWith("data: {")
    check r.run("-u", "a", "-o", "json-seq").outp[0] == '\x1e'
    let f = parseJson(r.run("-u", "a", "-o", "json", "--output-fields=MESSAGE").outp)
    check f.hasKey("MESSAGE") and not f.hasKey("PRIORITY") and f.hasKey("__CURSOR")
  test "json multi-line and binary values":
    let rr = testRoots(tmpDir("jcb"), scSystem)
    let st = openStorage(rr.rt / "journal" / "m", bootId(2), StorageLimits(), testClock(), newRng(1))
    var e = mk(5, "bin", extra = @[("BLOB", "\xff\x01"), ("DUP", "a"), ("DUP", "b")])
    discard st.store(e)
    st.sync
    let j = parseJson(rr.run("-o", "json").outp)
    check j["BLOB"] == %*[255, 1] and j["DUP"] == %*["a", "b"]
    check rr.run("-o", "cat").outp == "bin\n"
    check rr.run("-o", "verbose").outp.contains("BLOB=[2B blob data]")
    check rr.run("-o", "verbose", "-a").outp.contains("BLOB=\xff\x01")
  test "export":
    let x = r.run("-n", "1", "-r", "-o", "export", "-u", "a").outp
    check "__REALTIME_TIMESTAMP=" & $(T0 + 123456) & "\n" in x
    check "MESSAGE=Started thing\n" in x and x.endsWith("\n\n")
    let m = r.run("-n", "1", "-u", "b", "-o", "export").outp
    check "MESSAGE\n\x0a\0\0\0\0\0\0\0multi\nline\n" notin m      # last b entry has no newline
    let ml = r.run("-u", "b", "-o", "export").outp
    check "MESSAGE\n\x0a\0\0\0\0\0\0\0multi\nline\n" in ml
  test "unknown format":
    let x = r.run("-o", "fancy")
    check x.code == 1 and x.err == "Unknown output format 'fancy'.\n"

suite "journalctl selection":
  let r = fixture()
  test "no entries":
    check r.run("-u", "nothing").outp == "-- No entries --\n"
    check r.run("-u", "nothing", "-q").outp == ""
    check r.run("-u", "nothing").code == 0
  test "lines, reverse, all":
    check r.run("--no-pager").outp.strip.splitLines.len == 6     # a multi-line message adds one
    check r.run("-n", "2", "-o", "cat").outp == "multi\nline\nerror in b\n"
    check r.run("-n2", "-r", "-o", "cat").outp == "error in b\nmulti\nline\n"
    check r.run("-r", "-n", "all", "-o", "cat").outp.startsWith("error in b\n")
    check r.run("-n", "x").code == 1
  test "units, identifiers, field matches":
    check r.run("-u", "b.service", "-o", "cat").outp == "multi\nline\nerror in b\n"
    check r.run("-u", "a.service", "-u", "sshd", "-o", "cat").outp == "Started thing\nboot two begins\n"
    check r.run("-u", "*.service", "-o", "cat").outp.countLines >= 4
    check r.run("-t", "sshd", "-o", "cat").outp == "boot two begins\n"
    check r.run("_SYSTEMD_UNIT=b.service", "PRIORITY=3", "-o", "cat").outp == "error in b\n"
    check r.run("_SYSTEMD_UNIT=a.service", "+", "_SYSTEMD_UNIT=sshd.service", "-o", "cat").outp ==
      "Started thing\nboot two begins\n"
    check r.run("_COMM=bprog", "-o", "cat").outp == "multi\nline\n"
    check r.run("lowercase=1").code == 1
  test "priority":
    check r.run("-p", "err", "-o", "cat").outp == "disk failure\nerror in b\n"
    check r.run("-p", "3", "-o", "cat").outp == "disk failure\nerror in b\n"
    check r.run("-p", "notice..err", "-o", "cat").outp == "disk failure\nboot two begins\nerror in b\n"
    check r.run("-p", "bogus").code == 1
  test "since and until":
    check r.run("--since", "2025-10-17 12:30:00", "-o", "cat").outp == "boot two begins\nmulti\nline\nerror in b\n"
    check r.run("-S", "2025-10-17 13:00:00.5", "-U", "2025-10-17 13:30", "-o", "cat").outp == "multi\nline\n"
    check r.run("--until", "2025-10-17T12:00:30", "-o", "cat").outp == "Started thing\ndisk failure\n"
    check r.run("--since", "-1h", "-o", "cat").outp == "-- No entries --\n"   # now is T0 + 24h
    check r.run("--since", "@1760702410", "--until", "@1760702410", "-o", "cat").outp == "disk failure\n"
    check r.run("--since", "nonsense").code == 1
    check r.run("--since", "2025-10-18", "--until", "2025-10-17").code == 1
  test "boots":
    let b = r.run("--list-boots").outp.splitLines
    check b[0].startsWith("IDX BOOT ID")
    check b[1].startsWith(" -1 " & idHex(bootId(1))) and b[2].startsWith("  0 " & idHex(bootId(2)))
    check "Fri 2025-10-17 12:00:00 UTC" in b[1]
    check r.run("-b", "-o", "cat").outp.startsWith("boot two begins")
    check r.run("-b", "0", "-o", "cat").outp.startsWith("boot two begins")
    check r.run("-b", "-1", "-o", "cat").outp == "Started thing\ndisk failure\n"
    check r.run("-b", "1", "-o", "cat").outp == "Started thing\ndisk failure\n"
    check r.run("-b", idHex(bootId(1)), "-o", "cat").outp == "Started thing\ndisk failure\n"
    check r.run("-b", "-5").code == 1
    check r.run("-b", "-1", "-u", "a", "-o", "cat").outp == "Started thing\n"
  test "dmesg":
    check r.run("-k", "-o", "cat").outp == "-- No entries --\n"     # current boot has no kernel entries
    check r.run("-b", "-1", "-k", "-o", "cat").outp == "disk failure\n"
  test "grep":
    check r.run("-g", "fail", "-o", "cat").outp == "disk failure\n"
    check r.run("-g", "DISK", "-o", "cat").outp == "-- No entries --\n"        # an upper-case letter: case-sensitive
    check r.run("-g", "DISK", "--case-sensitive=no", "-o", "cat").outp == "disk failure\n"
    check r.run("-g", "disk", "--case-sensitive", "-o", "cat").outp == "disk failure\n"
    check r.run("-g", "Disk", "--case-sensitive", "-o", "cat").outp == "-- No entries --\n"
    check r.run("-g", "fail.*e$", "-o", "cat").outp == "disk failure\n"
    check r.run("-g", "(bad", "-o", "cat").code == 1
  test "fields":
    check r.run("-F", "SYSLOG_IDENTIFIER").outp.splitLines.filterIt(it.len > 0).sorted ==
      @["b", "kernel", "sshd", "systemd"]
    check "MESSAGE" in r.run("-N").outp.splitLines
  test "cursors":
    let cur = r.run("-n", "1", "--show-cursor", "-o", "cat").outp.splitLines
    check cur[1].startsWith("-- cursor: s=")
    let c = cur[1][11 .. ^1]
    check r.run("--cursor", c, "-o", "cat").outp == "error in b\n"
    check r.run("--after-cursor", c, "-o", "cat").outp == "-- No entries --\n"
    check r.run("--cursor", "junk").code == 1
    let file = getTempDir() / "sdcj-cursor"
    removeFile(file)
    check r.run("--cursor-file", file, "-n", "2", "-o", "cat").code == 0
    check readFile(file).strip == c
    check r.run("--cursor-file", file, "-o", "cat").outp == "-- No entries --\n"
  test "directory override":
    let other = testRoots(tmpDir("jcd"), scSystem)
    check other.run("--directory", r.rt / "journal", "-n", "1", "-o", "cat").outp == "error in b\n"
    check other.run("-D" & r.rt / "journal", "-n", "1", "-o", "cat").outp == "error in b\n"
    check other.run("-o", "cat").outp == "-- No entries --\n"
  test "follow prints the last 10 then ends when stopped":
    var n = 0
    var o: string
    proc out1(s: string) = o.add s
    proc err1(s: string) = discard
    proc stop(): bool =
      inc n
      n > 1
    let code = journalctlRun(@["-f", "-n", "2", "-o", "cat"], r, out1, err1, 0, stop)
    check code == 0 and o == "multi\nline\nerror in b\n"
    check r.run("-f", "-r").code == 1
  test "unsupported and unknown options":
    for opt in ["--setup-keys", "--namespace=x", "--list-catalog", "--update-catalog", "--interval=1"]:
      let x = r.run(opt)
      check x.code == 1 and x.err == "Option not supported by the systemd core.\n"
    check r.run("-x", "-a", "-l", "--no-full", "-m", "--system", "--utc", "-o", "cat").code == 0
    check r.run("--bogus").code == 1
    check r.run("-u").code == 1

suite "journalctl control":
  test "needs the daemon":
    let r = fixture()
    for opt in ["--rotate", "--flush", "--sync", "--vacuum-size=1M", "--vacuum-time=1d", "--vacuum-files=2"]:
      let x = r.run(opt)
      check x.code == 1 and x.err.startsWith("Failed to ") and "cannot connect" in x.err
    check r.run("--vacuum-size=lots").code == 1
  test "disk usage falls back to the files":
    let r = fixture()
    let x = r.run("--disk-usage")
    check x.code == 0 and x.outp.startsWith("Archived and active journals take up ")
    check x.outp.endsWith(" in the file system.\n")
  test "byte formatting and time specs":
    check formatBytes(0) == "0B" and formatBytes(1023) == "1023B" and formatBytes(1536) == "1.5K"
    check formatBytes(8 * 1024 * 1024) == "8.0M" and formatBytes(5'i64 shl 30) == "5.0G"
    putEnv("TZ", "UTC")
    let now = T0
    check parseTimeSpec("now", now) == some(now)
    let midnight = T0 - 12 * 3_600_000_000'i64
    check parseTimeSpec("today", now) == some(midnight)
    check parseTimeSpec("yesterday", now) == some(midnight - 86_400_000_000'i64)
    check parseTimeSpec("tomorrow", now) == some(midnight + 86_400_000_000'i64)
    check parseTimeSpec("2025-10-17", now) == some(midnight)
    check parseTimeSpec("12:30", now) == some(T0 + 1_800_000_000'i64)
    check parseTimeSpec("2025-10-17 12:00:01.5", now) == some(T0 + 1_500_000'i64)
    check parseTimeSpec("2025-10-17 12:00:00 UTC", now) == some(T0)
    check parseTimeSpec("-1h", now) == some(T0 - 3_600_000_000'i64)
    check parseTimeSpec("1h ago", now) == some(T0 - 3_600_000_000'i64)
    check parseTimeSpec("+30min", now) == some(T0 + 1_800_000_000'i64)
    check parseTimeSpec("@1760702400", now) == some(T0)
    check parseTimeSpec("2025-13-01", now).isNone and parseTimeSpec("25:00", now).isNone
    check parseTimeSpec("", now).isNone
    putEnv("TZ", "Etc/GMT-2")                     # UTC+2
    check parseTimeSpec("2025-10-17 14:00:00", now) == some(T0)
    check parseTimeSpec("2025-10-17 12:00:00 UTC", now) == some(T0)
    putEnv("TZ", "UTC")
  test "permission errors":
    if getuid() == 0: skip()
    else:
      let r = fixture()
      let dir = r.rt / "journal" / "m"
      setFilePermissions(dir, {})
      defer: setFilePermissions(dir, {fpUserRead, fpUserWrite, fpUserExec})
      let x = r.run("-n", "1")
      check x.code == 1 and x.err == "No journal files were opened due to insufficient permissions.\n"

proc journalPath(r: Roots): string =
  for f in walkDirRec(r.rt / "journal"):
    if f.endsWith("system.jrn"): return f

suite "journalctl --file, --header, --verify":
  let r = fixture()
  let jf = journalPath(r)
  test "--file reads just that file":
    let other = testRoots(tmpDir("jcf"), scSystem)
    check other.run("--file", jf, "-n", "1", "-o", "cat").outp == "error in b\n"
    check other.run("--file=" & jf, "-u", "a", "-o", "cat").outp == "Started thing\n"
    check other.run("--file", r.rt / "journal" / "*" / "*.jrn", "-n", "1", "-o", "cat").outp == "error in b\n"
    check other.run("--file", jf, "--list-boots").outp.count("\n") == 3
    let miss = other.run("--file", "/nonexistent/x.jrn")
    check miss.code == 1 and "/nonexistent/x.jrn" in miss.err
  test "--header prints the file header":
    let x = r.run("--file", jf, "--header")
    check x.code == 0
    check "File path: " & jf & "\n" in x.outp and "State: ONLINE\n" in x.outp
    check "Entry objects: 5\n" in x.outp and "Head sequential number: 1\n" in x.outp
    check "Tail sequential number: 5\n" in x.outp and "Machine ID: " & idHex(bootId(2)) & "\n" in x.outp
    check "Boot ID: " & idHex(bootId(2)) & "\n" in x.outp
    check "Head realtime timestamp: Fri 2025-10-17 12:00:00.123456 UTC\n" in x.outp
    # without --file the journal directories are searched
    check "File path: " & jf & "\n" in r.run("--header").outp
  test "--verify passes a sound file and fails damaged ones":
    check r.run("--verify").outp == "PASS: " & jf & "\n"
    check r.run("--file", jf, "--verify").code == 0
    let dir = tmpDir("jcv")
    let bad = dir / "bad.jrn"
    var data = readFile(jf)
    data[data.len - 30] = char(ord(data[data.len - 30]) xor 0xFF)      # inside the last record
    writeFile(bad, data)
    let x = r.run("--file", bad, "--verify")
    check x.code == 1 and x.outp.startsWith("FAIL: " & bad & " (corrupt or truncated record at offset ")
    writeFile(dir / "cut.jrn", readFile(jf)[0 ..< readFile(jf).len - 7])
    check r.run("--file", dir / "cut.jrn", "--verify").code == 1
    writeFile(dir / "junk.jrn", "this is not a journal\n")
    let j = r.run("--file", dir / "junk.jrn", "--verify")
    check j.code == 1 and "not a journal file" in j.outp
    check r.run("--file", dir / "junk.jrn", "--header").code == 1
    check r.run("--file", jf, "--file", bad, "--verify").code == 1       # one bad file fails the run
    check r.run("-D", tmpDir("jcempty"), "--verify").outp == "No journal files were found.\n"
  test "--verify checks the index against the file":
    let dir = tmpDir("jcvi")
    let f = dir / "system.jrn"
    copyFile(jf, f)
    copyFile(jf & ".idx", f & ".idx")
    check r.run("--file", f, "--verify").code == 0
    var ix = readFile(f & ".idx")
    ix[16] = char(ord(ix[16]) xor 1)                 # the offset of the first indexed record
    writeFile(f & ".idx", ix)
    let x = r.run("--file", f, "--verify")
    check x.code == 1 and "index entry 0" in x.outp

suite "journalctl --new-id128":
  test "prints the four forms":
    let r = fixture()
    let x = r.run("--new-id128")
    check x.code == 0
    let lines = x.outp.splitLines
    check lines[0] == "As string:" and lines[1].len == 32 and lines[1].allCharsInSet(HexDigits)
    check lines[4].len == 36 and lines[4][14] == '4' and lines[4].replace("-", "") == lines[1]
    check lines[7].startsWith("#define MESSAGE_XYZ SD_ID128_MAKE(0x")
    check r.run("--new-id128").outp != x.outp

suite "journalctl boots across files":
  test "list-boots and -b over rotated files":
    putEnv("TZ", "UTC")
    let r = testRoots(tmpDir("jcb"), scSystem)
    let st = openStorage(r.rt / "journal" / "m", bootId(2), StorageLimits(), testClock(), newRng(1))
    proc put(sec: int64; msg: string; boot: int) =
      var e = mk(T0 + sec * 1_000_000, msg, "", 6, boot)
      discard st.store(e)
    put(0, "a1", 1); put(10, "a2", 1); put(100, "b1", 2)
    st.rotate
    put(200, "b2", 2); put(300, "c1", 3); put(310, "c2", 3)
    st.sync
    let b = r.run("--list-boots").outp.splitLines
    check b.len == 5 and b[1].startsWith(" -2 " & idHex(bootId(1))) and b[2].startsWith(" -1 " & idHex(bootId(2)))
    check b[3].startsWith("  0 " & idHex(bootId(3)))
    check "12:01:40" in b[2] and "12:03:20" in b[2]            # first from the archive, last from the active file
    check r.run("-b", "-1", "-o", "cat").outp == "b1\nb2\n"
    check r.run("-b", "1", "-o", "cat").outp == "a1\na2\n"
    check r.run("-b", "3", "-o", "cat").outp == "c1\nc2\n"
    check r.run("-b", "-2", "-o", "cat").outp == "a1\na2\n"
    check r.run("-b", "4").code == 1 and r.run("-b", "-3").code == 1
    check r.run("--list-boots", "-q").code == 0
