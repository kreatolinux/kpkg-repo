## journald as a real process (Linux): handoff environment, sd_notify, signals,
## restart persistence, and journalctl following its output. Run it with
## `scripts/linux-test.sh 'nim c -r --threads:off --outdir:/tmp/out tests/unit/journal/test_daemon_process.nim'`.
when defined(linux):
  import std/[os, osproc, posix, unittest, strutils, json, sequtils, algorithm, strtabs, times]
  import journal/[format, reader, client, control, intake_stream, sockutil]
  import common/roots
  import ./jtest

  proc spawn(r: Roots; bin: string; extraEnv: openArray[(string, string)] = []): Process =
    let env = newStringTable()
    for k, v in envPairs(): env[k] = v
    env["SDC_RUNTIME_DIR"] = r.rt
    env["SDC_STATE_DIR"] = r.st
    env["SDC_SYSRUN"] = r.sysrun
    env["SDC_SCOPE"] = "system"
    env["JUMPSTART_CORE_RUNTIME_DIR"] = r.rt
    env["NOTIFY_SOCKET"] = r.rt / "notify"
    env["WATCHDOG_USEC"] = "400000"
    env["SDC_DEVFS"] = r.devfs                 # not the real /dev/kmsg unless a test asks for it
    for (k, v) in extraEnv: env[k] = v
    startProcess(bin, env = env, options = {poStdErrToStdOut})

  proc present(path: string): bool = access(path.cstring, F_OK) == 0

  proc waitUntil(cond: proc(): bool; ms = 5000): bool =
    for _ in 0 ..< ms div 20:
      if cond(): return true
      sleep 20
    cond()

  proc journalIn(r: Roots): Journal = openJournal(@[r.rt / "journal", r.st / "journal"])

  suite "journald process":
    let bin = getTempDir() / "sdcj-journald-bin"
    check execCmd("nim c --threads:off --hints:off -o:" & bin & " src/journald_main.nim") == 0

    test "ready, intake, flush on SIGUSR1, clean stop, restart keeps entries":
      let r = testRoots(tmpDir("pp"), scSystem)
      removeDir(r.st)                              # not mounted yet: volatile
      let notifyFd = bindUnix(r.rt / "notify", false, 0o600, passCreds = false)
      var p = spawn(r, bin)
      defer: (if p.running: p.kill; p.close)
      var dg: Datagram
      check waitUntil(proc(): bool = recvDatagram(notifyFd, 200, dg))
      check dg.data.startsWith("READY=1")
      check waitUntil(proc(): bool = present(r.sysrun / "journal" / "socket"))
      check journalSend(r.sysrun, [("MESSAGE", "from a client"), ("PRIORITY", "5")])
      let fd = openStream(r.sysrun, StreamHeader(identifier: "proc", unit: "p.service",
        priority: 6, levelPrefix: true, levelMax: -1, facility: 3))
      check fd >= 0
      discard write(fd, "<2>stdout line\n".cstring, 15)
      discard close(fd)
      sendDatagram(r.sysrun / "journal" / "dev-log", "<14>logger: via syslog")
      check waitUntil(proc(): bool = journalIn(r).entries(JournalQuery()).len == 3)
      let es = journalIn(r).entries(JournalQuery())
      check es.mapIt(it.getField("_TRANSPORT")).sorted == @["journal", "stdout", "syslog"]
      check es.allIt(it.getField("_PID") == $p.processID or it.getField("_PID") == $getpid())
      check dirExists(r.rt / "journal") and not dirExists(r.st)
      # filesystems-ready: ST appears, SIGUSR1 flushes
      createDir(r.st)
      check kill(Pid(p.processID), SIGUSR1) == 0
      check waitUntil(proc(): bool = dirExists(r.st / "journal"))
      check waitUntil(proc(): bool = journalFiles(@[r.rt / "journal"]).len == 0)
      check journalIn(r).entries(JournalQuery()).len == 3
      # watchdog pings arrive
      check waitUntil(proc(): bool = recvDatagram(notifyFd, 200, dg) and dg.data == "WATCHDOG=1", 1000)
      # control socket from a client
      let c = controlCall(controlSocketPath(r.rt), %*{"verb": "disk-usage"})
      check c.ok and c.value["bytes"].getInt > 0
      check controlCall(controlSocketPath(r.rt), %*{"verb": "rotate"}).ok
      # clean stop
      check kill(Pid(p.processID), SIGTERM) == 0
      check waitUntil(proc(): bool = not p.running)
      check p.peekExitCode == 0
      check not present(r.sysrun / "journal" / "socket")
      check journalIn(r).entries(JournalQuery()).len == 3
      # restart: sequence continues
      p = spawn(r, bin)
      check waitUntil(proc(): bool = present(r.sysrun / "journal" / "socket") and
                                     present(r.rt / "journald.ctl"))
      sleep 100
      check journalSend(r.sysrun, [("MESSAGE", "after restart")])
      check waitUntil(proc(): bool = journalIn(r).entries(JournalQuery()).len == 4)
      let all = journalIn(r).entries(JournalQuery())
      check all.mapIt(it.seqnum) == @[1'u64, 2, 3, 4]
      discard kill(Pid(p.processID), SIGTERM)
      discard p.waitForExit(3000)

    test "kernel messages from the real /dev/kmsg are stored once, also across a restart":
      if not present("/dev/kmsg") or access("/dev/kmsg", R_OK or W_OK) != 0:
        skip()
      else:
        let r = testRoots(tmpDir("pk"), scSystem)
        let marker = "sdc-kmsg-marker-" & $getpid()
        var p = spawn(r, bin, [("SDC_DEVFS", "/dev")])
        defer: (if p.running: p.kill; p.close)
        check waitUntil(proc(): bool = present(r.rt / "journald.ctl"))
        let f = open("/dev/kmsg", fmWrite)
        f.write("<4>" & marker & " first\n")
        f.close()
        proc marked(): seq[JournalEntry] =
          journalIn(r).entries(JournalQuery(matches: @[JournalMatch(field: "_TRANSPORT", value: "kernel")])).
            filterIt(marker in it.message)
        check waitUntil(proc(): bool = marked().len == 1)
        let e = marked()[0]
        check e.priority == 4 and e.getField("SYSLOG_IDENTIFIER") == "kernel"
        # the kernel's timestamp became wall-clock time: within a minute of now
        check abs(e.realtime - int64(epochTime() * 1e6)) < 60_000_000
        check e.getField("_BOOT_ID").len == 32
        check kill(Pid(p.processID), SIGTERM) == 0
        check waitUntil(proc(): bool = not p.running)
        let before = journalIn(r).entries(JournalQuery()).len
        check before > 1                                  # the ring's history was read on first start
        p = spawn(r, bin, [("SDC_DEVFS", "/dev")])
        check waitUntil(proc(): bool = present(r.rt / "journald.ctl"))
        let g = open("/dev/kmsg", fmWrite)
        g.write("<4>" & marker & " second\n")
        g.close()
        check waitUntil(proc(): bool = marked().len == 2)
        sleep 300
        check journalIn(r).entries(JournalQuery()).len == before + 1   # nothing was stored twice
        check marked().mapIt(it.message).deduplicate.len == 2
        discard kill(Pid(p.processID), SIGTERM)
        discard p.waitForExit(3000)

    test "follow sees entries written by the daemon across rotation":
      let r = testRoots(tmpDir("pf"), scSystem)
      var p = spawn(r, bin)
      defer: (if p.running: p.kill; p.close)
      check waitUntil(proc(): bool = present(r.rt / "journald.ctl"))
      var got: seq[string]
      var n = 0
      let started = epochTime()
      let j = journalIn(r)
      j.follow(JournalQuery(), proc(): bool =
        inc n
        if n == 3: journalSend(r.sysrun, [("MESSAGE", "one")])
        if n == 6: discard controlCall(controlSocketPath(r.rt), %*{"verb": "rotate"})
        if n == 8: journalSend(r.sysrun, [("MESSAGE", "two")])
        epochTime() - started > 4 or got.len >= 2,
        proc(e: JournalEntry): bool =
          got.add e.message
          true, pollMs = 100)
      check got == @["one", "two"]
      discard kill(Pid(p.processID), SIGTERM)
      discard p.waitForExit(3000)
else:
  import std/unittest
  suite "journald process":
    test "Linux only":
      skip()
