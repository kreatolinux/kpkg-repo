import std/unittest
import journal/regexlite

proc ok(p, s: string; fold = false): bool = compileRegex(p, fold).isMatch(s)

suite "regexlite":
  test "literals, anchors, dot":
    check ok("abc", "xxabcxx") and not ok("abd", "xxabcxx")
    check ok("^abc", "abcd") and not ok("^bc", "abcd")
    check ok("cd$", "abcd") and not ok("bc$", "abcd")
    check ok("a.c", "abc") and not ok("a.c", "ac")
  test "repetition":
    check ok("ab*c", "ac") and ok("ab*c", "abbbc")
    check ok("ab+c", "abc") and not ok("ab+c", "ac")
    check ok("ab?c", "ac") and not ok("^ab?c$", "abbc")
    check ok("^a{2,3}$", "aaa") and not ok("^a{2,3}$", "aaaa") and not ok("^a{2}$", "a")
    check ok("(ab)+$", "xababab")
  test "alternation and groups":
    check ok("foo|bar", "a bar") and not ok("foo|bar", "baz")
    check ok("^(a|b)c$", "bc")
  test "sets and classes":
    check ok("[abc]x", "bx") and not ok("[abc]x", "dx")
    check ok("[a-c]+$", "abcabc") and ok("[^0-9]", "a1") and not ok("^[^0-9]$", "1")
    check ok("[[:digit:]]+", "ab12") and ok("\\d+", "x9") and ok("\\w+@", "me@")
    check ok("[]]", "]") and ok("a\\.b", "a.b") and not ok("a\\.b", "axb")
  test "case folding":
    check ok("ERROR", "an error", true) and not ok("ERROR", "an error")
    check ok("[A-Z]+", "abc", true)
  test "syntax errors":
    expect ValueError: discard compileRegex("(ab")
    expect ValueError: discard compileRegex("*a")
    expect ValueError: discard compileRegex("[ab")
  test "no catastrophic loop on empty matches":
    check ok("(a*)*b", "aaab")
