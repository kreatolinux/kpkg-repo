import std/[os, unittest, strutils, sequtils]
import journal/[format, reader, storage]
import common/clock
import ./jtest

proc newStore(dir: string; clk: FakeClock; limits = StorageLimits(); seed = 3): Storage =
  openStorage(dir, bootId(2), limits, clk, newRng(seed))

proc put(s: Storage; usec: int64; msg: string): JournalEntry =
  result = mk(usec, msg)
  doAssert s.store(result)

proc msgs(dir: string; q = JournalQuery()): seq[string] =
  for e in openJournal(@[dir]).entries(q): result.add e.message

suite "storage":
  setup:
    let dir = tmpDir("storage")
    let clk = testClock()
  test "sequence numbers continue across reopen and rotation":
    var s = newStore(dir, clk)
    check s.put(1, "a").seqnum == 1
    s.rotate
    check s.put(2, "b").seqnum == 2
    s.sync
    var s2 = newStore(dir, clk)
    check s2.seqnumId == s.seqnumId
    check s2.put(3, "c").seqnum == 3
    check listFiles(dir).len == 2
    check msgs(dir) == @["a", "b", "c"]
  test "rotation by size":
    var s = newStore(dir, clk, StorageLimits(maxFileSize: 1000))
    for i in 1 .. 40: discard s.put(int64(i), "message number " & $i & repeat('x', 50))
    check listFiles(dir).len > 3
    check msgs(dir).len == 40
    check listFiles(dir)[^1].archived == false
  test "rotation by age":
    var s = newStore(dir, clk, StorageLimits(maxFileSecUsec: 60_000_000))
    discard s.put(1, "a")
    clk.advance(61_000_000)
    discard s.put(2, "b")
    check listFiles(dir).len == 2
    discard s.put(3, "c")
    check listFiles(dir).len == 2
  test "empty active file is not rotated":
    var s = newStore(dir, clk)
    s.rotate
    check listFiles(dir).len == 0
  test "vacuum by explicit size and age":
    var s = newStore(dir, clk)
    for i in 1 .. 5:
      discard s.put(clk.real - int64(10 - i) * 86_400_000_000'i64, "old" & $i)
      s.rotate
    discard s.put(clk.real, "live")
    check listFiles(dir).len == 6
    let one = listFiles(dir)[0].size
    let freed = s.vacuum(maxArchivedBytes = one * 2 + 100)
    check freed > 0 and listFiles(dir).len == 3     # two archived plus the active
    check msgs(dir) == @["old4", "old5", "live"]
    discard s.vacuum(maxAgeUsec = 5 * 86_400_000_000'i64 + 1)   # old4 is 6 days old
    check msgs(dir) == @["old5", "live"]
    check s.vacuum(maxArchivedBytes = 0) > 0
    check msgs(dir) == @["live"]
  test "vacuum by file count and total size never deletes the active file":
    var s = newStore(dir, clk, StorageLimits(maxFiles: 3))
    for i in 1 .. 6:
      discard s.put(int64(i), "m" & $i)
      s.rotate
    check listFiles(dir).len == 3
    discard s.put(100, "live")
    check listFiles(dir).len == 4
    s.limits.maxFiles = 1
    discard s.enforceLimits()
    check listFiles(dir).len == 1 and msgs(dir) == @["live"]
    s.limits.maxUse = 1
    discard s.enforceLimits()
    check msgs(dir) == @["live"]
  test "retention":
    var s = newStore(dir, clk, StorageLimits(maxRetentionUsec: 1_000_000))
    discard s.put(clk.real - 5_000_000, "stale")
    s.rotate
    discard s.put(clk.real, "fresh")
    s.rotate
    check msgs(dir) == @["fresh"]
  test "keep free":
    var s = newStore(dir, clk)
    for i in 1 .. 3:
      discard s.put(int64(i), "m" & $i)
      s.rotate
    s.limits.keepFree = 100
    s.freeSpace = proc(d: string): int64 = 10 + 100 * int64(3 - listFiles(d).len)
    discard s.enforceLimits()
    check listFiles(dir).len == 2    # free space reached 110 after one deletion
  test "disk usage counts files and indexes":
    var s = newStore(dir, clk)
    discard s.put(1, "a")
    check s.diskUsage >= getFileSize(dir / "system.jrn") + 24
  test "flush merges volatile into persistent without duplicates":
    let vol = newStore(tmpDir("vol"), clk)
    for i in 1 .. 3: discard vol.put(int64(i), "v" & $i)
    let pers = newStore(dir, clk)
    check flushInto(vol, pers) == 3
    check msgs(dir) == @["v1", "v2", "v3"]
    check pers.seqnumId == vol.seqnumId and pers.nextSeq == 4
    check listFiles(vol.dir).len == 0
    discard pers.put(4, "p4")
    check openJournal(@[dir]).entries(JournalQuery()).mapIt(it.seqnum) == @[1'u64, 2, 3, 4]
  test "flush renumbers entries into an older persistent stream":
    let pers = newStore(dir, clk)
    discard pers.put(1, "old1")
    discard pers.put(2, "old2")
    let vol = newStore(tmpDir("vol2"), clk, seed = 99)
    discard vol.put(3, "v1")
    check flushInto(vol, pers) == 1
    let es = openJournal(@[dir]).entries(JournalQuery())
    check es.mapIt(it.message) == @["old1", "old2", "v1"]
    check es.mapIt(it.seqnum) == @[1'u64, 2, 3]
  test "reading both directories during a flush shows each entry once":
    let vol = newStore(tmpDir("vol3"), clk)
    for i in 1 .. 3: discard vol.put(int64(i), "v" & $i)
    vol.sync
    let pers = newStore(dir, clk)
    pers.seqnumId = vol.seqnumId     # copy but do not remove: a reader mid-flush
    for e in openJournal(@[vol.dir]).entries(JournalQuery()):
      var c = e
      pers.nextSeq = e.seqnum
      discard pers.store(c)
    pers.sync
    check openJournal(@[dir, vol.dir]).entries(JournalQuery()).len == 3
