import std/[os, unittest, options, strutils]
import journal/[format, index, writer]
import common/clock
import ./jtest

suite "format":
  test "crc32c known vector":
    check crc32c("123456789") == 0xE3069283'u32
  test "record round trip incl. binary values":
    var e = mk(1_700_000_000_000_000'i64, "hello")
    e.seqnum = 7
    e.fields.add ("BIN", "a\nb\0c\xff")
    e.fields.add ("EMPTY", "")
    let rec = encodeRecord(e)
    var d: JournalEntry
    check decodeBody(rec[4 .. ^1], d)
    check d.seqnum == 7 and d.fields == e.fields and d.crc == e.crc
    check d.priority == 6 and d.realtime == e.realtime and d.bootId == e.bootId
  test "crc corruption is rejected":
    var e = mk(5, "x")
    var rec = encodeRecord(e)
    rec[30] = char(ord(rec[30]) xor 1)
    var d: JournalEntry
    check not decodeBody(rec[4 .. ^1], d)
  test "no priority is 255":
    var e = mk(5, "x", prio = NoPriority)
    var d: JournalEntry
    check decodeBody(encodeRecord(e)[4 .. ^1], d)
    check d.priority == NoPriority
  test "header round trip":
    let h = FileHeader(flags: 1, fileId: bootId(1), machineId: bootId(2), seqnumId: bootId(3),
                       firstSeq: 9, firstTime: 77)
    check encodeHeader(h).len == HeaderSize
    check parseHeader(encodeHeader(h)).get == h
    check parseHeader("SDCJRN02" & repeat('\0', 100)).isNone
  test "cursor round trip":
    var e = mk(1234567, "x")
    e.seqnum = 255
    e.seqnumId = bootId(9)
    discard encodeRecord(e)
    let s = cursorOf(e)
    check s.startsWith("s=09090909090909090909090909090909;i=ff;")
    let c = parseCursor(s).get
    check c.seqnum == 255 and c.realtime == 1234567 and c.crc == e.crc
    check parseCursor("garbage").isNone
    check parseCursor("s=00;i=1").isNone    # t is required
  test "ids":
    check idFromHex(idHex(bootId(0xAB))) == bootId(0xAB)
    check idFromHex("xyz") == ""

suite "writer":
  setup:
    let dir = tmpDir("writer")
    let path = dir / "system.jrn"
    let rng = newRng(5)
  test "append, reopen continues, torn tail truncated":
    let jf = openJournalFile(path, bootId(2), bootId(3), rng)
    for i in 1 .. 300:
      var e = mk(int64(i) * 1000, "m" & $i)
      e.seqnum = uint64(i)
      jf.append(e)
    check jf.count == 300 and jf.header.firstSeq == 1 and jf.header.firstTime == 1000
    jf.close()
    check getFileSize(indexPath(path)) == 3 * 24
    let good = getFileSize(path)
    var f = open(path, fmAppend)
    f.write "\x40\x00\x00\x00partial record"
    f.close()
    let jf2 = openJournalFile(path, bootId(2), bootId(3), rng)
    check getFileSize(path) == good
    check jf2.count == 300 and jf2.lastSeq == 300
    var e = mk(999_000, "after")
    e.seqnum = 301
    jf2.append(e)
    jf2.close()
    var n = 0
    var fr = open(path)
    discard scanRecords(fr, getFileSize(path), HeaderSize, proc(e: var JournalEntry; o: int64): bool =
      inc n
      true)
    fr.close()
    check n == 301
  test "index seek by seqnum and time":
    let jf = openJournalFile(path, bootId(2), bootId(3), rng)
    for i in 1 .. 1000:
      var e = mk(int64(i) * 10, "m")
      e.seqnum = uint64(i)
      jf.append(e)
    jf.close()
    let ix = loadIndex(path)
    check ix.len == 8
    check ix[1].seqnum == 129
    # a scan from the seek position sees the wanted record first-or-after
    var fr = open(path)
    var first = 0'u64
    discard scanRecords(fr, getFileSize(path), seekSeqnum(ix, 500), proc(e: var JournalEntry; o: int64): bool =
      first = e.seqnum
      false)
    check first <= 500 and first > 500 - 128
    discard scanRecords(fr, getFileSize(path), seekRealtime(ix, 5000), proc(e: var JournalEntry; o: int64): bool =
      first = e.seqnum
      false)
    check first <= 500 and first > 500 - 128
    fr.close()
    check seekSeqnum(ix, 1) == HeaderSize
  test "missing or stale index is rebuilt":
    let jf = openJournalFile(path, bootId(2), bootId(3), rng)
    for i in 1 .. 200:
      var e = mk(int64(i), "m")
      e.seqnum = uint64(i)
      jf.append(e)
    jf.close()
    removeFile(indexPath(path))
    check loadIndex(path).len == 2
    writeFile(indexPath(path), repeat('\x07', 48))
    check loadIndex(path).len == 2
    check readFile(indexPath(path)).len == 48
  test "archive renames file and index":
    let jf = openJournalFile(path, bootId(2), bootId(3), rng)
    var e = mk(42, "x")
    e.seqnum = 5
    jf.append(e)
    let a = jf.archive()
    check not fileExists(path) and fileExists(a) and fileExists(indexPath(a))
    check a.extractFilename == "system@" & idHex(bootId(3)) & "-0000000000000005-000000000000002a.jrn"
    var f = open(a)
    check (readHeader(f).get.flags and FlagArchived) != 0
    f.close()
    check fileExists(path) == false
  test "empty file is dropped at archive":
    let jf = openJournalFile(path, bootId(2), bootId(3), rng)
    check jf.archive() == ""
    check not fileExists(path)
