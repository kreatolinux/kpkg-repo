import std/[os, unittest, options, sequtils]
import journal/[format, reader, storage]
import common/clock
import ./jtest

proc fill(dir: string): Storage =
  result = openStorage(dir, bootId(2), StorageLimits(), testClock(), newRng(3))
  var specs = @[
    (10, "boot1 a", "a.service", 6, 1), (20, "boot1 b", "b.service", 3, 1),
    (30, "boot1 c", "a.service", 7, 1), (40, "boot2 d", "b.service", 4, 2),
    (50, "boot2 e", "", 6, 2), (60, "boot2 f", "a.service", 2, 2)]
  for (t, m, u, p, b) in specs:
    var e = mk(int64(t), m, u, p, b)
    doAssert result.store(e)
  result.sync

proc msgs(es: seq[JournalEntry]): seq[string] = es.mapIt(it.message)

suite "reader":
  setup:
    let dir = tmpDir("reader")
    let st = fill(dir)
    let j = openJournal(@[dir])
  test "all entries oldest first, seqnum and ids set":
    let es = j.entries(JournalQuery())
    check es.len == 6 and es[0].seqnum == 1 and es[5].seqnum == 6
    check es[0].seqnumId == st.seqnumId
  test "reverse, limit, tail":
    check msgs(j.entries(JournalQuery(reverse: true, limit: 2))) == @["boot2 f", "boot2 e"]
    check msgs(j.entries(JournalQuery(limit: 2))) == @["boot1 a", "boot1 b"]
    check msgs(j.entries(JournalQuery(limit: 2, tail: true))) == @["boot2 e", "boot2 f"]
  test "time window":
    let q = JournalQuery(sinceUsec: some(20'i64), untilUsec: some(40'i64))
    check msgs(j.entries(q)) == @["boot1 b", "boot1 c", "boot2 d"]
  test "field matches: same field OR, different fields AND":
    var q = JournalQuery(matches: @[JournalMatch(field: "_SYSTEMD_UNIT", value: "a.service"),
                                    JournalMatch(field: "_SYSTEMD_UNIT", value: "b.service")])
    check j.entries(q).len == 5
    q.matches.add JournalMatch(field: "PRIORITY", value: "3")
    check msgs(j.entries(q)) == @["boot1 b"]
  test "disjunctions":
    let q = JournalQuery(disjunctions: @[
      @[JournalMatch(field: "PRIORITY", value: "2")],
      @[JournalMatch(field: "_SYSTEMD_UNIT", value: "b.service"), JournalMatch(field: "PRIORITY", value: "4")]])
    check msgs(j.entries(q)) == @["boot2 d", "boot2 f"]
  test "unit filter matches the four system fields and globs":
    var f = mk(70, "from manager", extra = @[("UNIT", "a.service")])
    discard st.store(f)
    var g = mk(80, "core", extra = @[("COREDUMP_UNIT", "a.service")])
    discard st.store(g)
    var h = mk(90, "user unit", extra = @[("_SYSTEMD_USER_UNIT", "a.service")])
    discard st.store(h)
    st.sync
    check msgs(j.entries(JournalQuery(units: @["a.service"]))) ==
      @["boot1 a", "boot1 c", "boot2 f", "from manager", "core"]
    check msgs(j.entries(JournalQuery(userUnits: @["a.service"]))) == @["user unit"]
    check j.entries(JournalQuery(units: @["*.service"])).len == 7
    check j.entries(JournalQuery(units: @["b*"])).len == 2
  test "priority range":
    check msgs(j.entries(JournalQuery(maxPriority: some(3)))) == @["boot1 b", "boot2 f"]
    check msgs(j.entries(JournalQuery(minPriority: some(6)))) ==
      @["boot1 a", "boot1 c", "boot2 e"]
  test "missing priority counts as info":
    var e = mk(70, "no prio", prio = NoPriority)
    discard st.store(e)
    st.sync
    check "no prio" in msgs(j.entries(JournalQuery(maxPriority: some(6))))
    check "no prio" notin msgs(j.entries(JournalQuery(maxPriority: some(5))))
  test "boots":
    let b = j.listBoots
    check b.len == 2 and b[0].bootId == idHex(bootId(1)) and b[1].bootId == idHex(bootId(2))
    check b[0].firstUsec == 10 and b[0].lastUsec == 30
    check msgs(j.entries(JournalQuery(bootIds: @[idHex(bootId(2))]))) ==
      @["boot2 d", "boot2 e", "boot2 f"]
  test "cursors":
    let es = j.entries(JournalQuery())
    let c = cursorOf(es[2])
    check msgs(j.entries(JournalQuery(cursor: some(c)))) == msgs(es[2 .. 5])
    check msgs(j.entries(JournalQuery(afterCursor: some(c)))) == msgs(es[3 .. 5])
    var q = JournalQuery()
    check q.seekCursor(c, after = true) and q.afterCursor.get == c
    check not q.seekCursor("nonsense")
  test "grep":
    check msgs(j.entries(JournalQuery(grep: some("BOOT2 [de]")))) == @["boot2 d", "boot2 e"]
    check j.entries(JournalQuery(grep: some("BOOT2 [de]"), caseSensitive: true)).len == 0
  test "field values and names":
    check j.fieldValues(JournalQuery(), "_SYSTEMD_UNIT") == @["a.service", "b.service"]
    check "MESSAGE" in j.fieldNames
  test "files in subdirectories and several dirs are merged by time":
    let other = tmpDir("reader2")
    let st2 = openStorage(other / "machine", bootId(2), StorageLimits(), testClock(), newRng(8))
    var e = mk(25, "between")
    discard st2.store(e)
    st2.sync
    let all = openJournal(@[dir, other]).entries(JournalQuery())
    check all.len == 7 and all[2].message == "between"
  test "torn tail: the reader stops at the first bad record":
    var f = open(dir / "system.jrn", fmAppend)
    f.write "\x20\x00\x00\x00garbage"
    f.close()
    check j.entries(JournalQuery()).len == 6
  test "corrupt record in the middle hides the rest of that file":
    var f = open(dir / "system.jrn", fmReadWriteExisting)
    f.setFilePos(HeaderSize + 4 + 30)
    f.write "\xff\xff"
    f.close()
    check j.entries(JournalQuery()).len == 0
  test "follow delivers the tail, then new entries, across rotation":
    var got: seq[string]
    var round = 0
    let q = JournalQuery(limit: 2)
    j.follow(q, proc(): bool =
      inc round
      if round == 1:
        var e = mk(100, "new1")
        discard st.store(e)
        st.rotate
        var e2 = mk(110, "new2")
        discard st.store(e2)
        st.sync
      round > 3, proc(e: JournalEntry): bool =
        got.add e.message
        true, pollMs = 20)
    check got == @["boot2 e", "boot2 f", "new1", "new2"]
  test "follow sink can end the loop":
    var n = 0
    j.follow(JournalQuery(), proc(): bool = false, proc(e: JournalEntry): bool =
      inc n
      n < 3)
    check n == 3
