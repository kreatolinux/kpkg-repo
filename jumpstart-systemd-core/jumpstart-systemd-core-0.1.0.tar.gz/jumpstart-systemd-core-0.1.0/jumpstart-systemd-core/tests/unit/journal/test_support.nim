## conf, control protocol, metadata and logops.
import std/[os, json, unittest, strutils, sequtils, tables]
import journal/[storage, conf, control, metadata]
import common/roots
import ./jtest

suite "conf":
  test "sizes and time spans":
    check parseSize("4G") == 4'i64 shl 30 and parseSize("512M") == 512'i64 shl 20
    check parseSize("100K") == 102400 and parseSize("77") == 77
    expect ValueError: discard parseSize("lots")
    check parseTimespan("30") == 30_000_000 and parseTimespan("5min") == 300_000_000
    check parseTimespan("1h 30min") == 5400_000_000'i64 and parseTimespan("2d") == 172_800_000_000'i64
    check parseTimespan("500ms") == 500_000 and parseTimespan("infinity") == 0
    check parseTimespan("1month") > 2_500_000_000_000'i64
    expect ValueError: discard parseTimespan("soon")
  test "keys of the [Journal] section only":
    var c = defaultConf()
    parseJournaldConf("""
# comment
[Other]
Storage=none
[Journal]
Storage=volatile
SystemMaxUse=2G
SystemMaxFiles=7
MaxFileSec=1week
LineMax=64K
MaxLevelStore=warning
ForwardToSyslog=yes
Compress=no
RuntimeMaxUse=50M
""", c)
    check c.storage == smVolatile and c.systemMaxUse == 2'i64 shl 30 and c.systemMaxFiles == 7
    check c.maxFileSecUsec == 7 * 86400 * 1_000_000'i64 and c.lineMax == 65536
    check c.maxLevelStore == 4 and c.runtimeMaxUse == 50'i64 shl 20
    check c.warnings.len == 0
    parseJournaldConf("[Journal]\nStorage=sometimes\nSystemMaxUse=lots\n", c)
    check c.warnings.len == 2
  test "files, drop-ins and shadowing":
    let r = testRoots(tmpDir("conf"), scSystem)
    createDir(r.etc / "systemd/journald.conf.d")
    createDir(r.sysrun / "journald.conf.d")
    createDir(r.usrLib / "systemd/journald.conf.d")
    writeFile(r.usrLib / "systemd/journald.conf", "[Journal]\nSystemMaxFiles=5\nStorage=auto\n")
    writeFile(r.etc / "systemd/journald.conf", "[Journal]\nSystemMaxFiles=6\n")
    writeFile(r.usrLib / "systemd/journald.conf.d/10-a.conf", "[Journal]\nStorage=none\n")
    writeFile(r.sysrun / "journald.conf.d/10-a.conf", "[Journal]\nStorage=volatile\n")   # shadows /usr/lib's
    writeFile(r.etc / "systemd/journald.conf.d/05-first.conf", "[Journal]\nSystemMaxFiles=9\n")
    let c = loadJournaldConf(r)
    check c.storage == smVolatile      # /run's drop-in shadows /usr/lib's
    check c.systemMaxFiles == 9        # drop-ins are applied after the main files
  test "limits":
    var c = defaultConf()
    c.systemMaxUse = 100 shl 20
    c.systemMaxFiles = 3
    c.maxFileSecUsec = 0
    let l = c.limitsFor(getTempDir(), false)
    check l.maxUse == 100 shl 20 and l.maxFiles == 3 and l.maxFileSecUsec == 0
    check l.maxFileSize == (100 shl 20) div 8
    check defaultConf().limitsFor(getTempDir(), true).maxFiles == 100

suite "control":
  proc ops(log: ref seq[string]): ControlOps =
    result.rotate = proc() = log[].add "rotate"
    result.vacuum = proc(a, b: int64; n: int): int64 =
      log[].add "vacuum " & $a & " " & $b & " " & $n
      42
    result.flush = proc(): bool = true
    result.sync = proc() = log[].add "sync"
    result.diskUsage = proc(): int64 = 1234
  test "verbs":
    var log = new(seq[string])
    let o = ops(log)
    check handleControl(%*{"verb": "rotate"}, o) == %*{"ok": true}
    check handleControl(%*{"verb": "vacuum", "max_size": 10}, o) == %*{"ok": true, "freed": 42}
    check handleControl(%*{"verb": "vacuum", "max_age_usec": 5}, o)["ok"].getBool
    check handleControl(%*{"verb": "vacuum"}, o)["ok"].getBool
    check handleControl(%*{"verb": "flush"}, o) == %*{"ok": true, "flushed": true}
    check handleControl(%*{"verb": "sync"}, o)["ok"].getBool
    check handleControl(%*{"verb": "disk-usage"}, o) == %*{"ok": true, "bytes": 1234}
    check handleControl(%*{"verb": "vacuum", "max_files": 3}, o)["ok"].getBool
    check log[] == @["rotate", "vacuum 10 -1 0", "vacuum -1 5 0", "vacuum -1 -1 0", "sync", "vacuum -1 -1 3"]
  test "errors":
    var log = new(seq[string])
    check not handleControl(%*{"verb": "nope"}, ops(log))["ok"].getBool
    check not handleControl(nil, ops(log))["ok"].getBool
    check not handleControl(%*[1], ops(log))["ok"].getBool
    var o = ops(log)
    o.rotate = proc() = raise newException(IOError, "disk on fire")
    check handleControl(%*{"verb": "rotate"}, o) == %*{"ok": false, "error": "disk on fire"}
  test "client reports a missing socket":
    let r = controlCall("/nonexistent/journald.ctl", %*{"verb": "sync"})
    check not r.ok and "cannot connect" in r.error

suite "metadata":
  test "unit of a cgroup path":
    let units = "/sys/fs/cgroup/jumpstart/cores/systemd/units"
    let mount = "/sys/fs/cgroup"
    check unitOfCgroup("/jumpstart/cores/systemd/units/system.slice.unit/sshd.service.unit",
                       units, mount) == ("sshd.service", "system.slice")
    check unitOfCgroup("/jumpstart/cores/systemd/units/system.slice.unit/foo.slice.unit/foo-bar.service.unit/sub/x",
                       units, mount) == ("foo-bar.service", "foo.slice")
    check unitOfCgroup("/jumpstart/cores/systemd/units/a.service.unit", units, mount) == ("a.service", "")
    check unitOfCgroup("/jumpstart/cores/systemd/units/x%25y.service.unit", units, mount).unit == "x%y.service"
    check unitOfCgroup("/jumpstart/cores/systemd/control", units, mount) == ("", "")
    check unitOfCgroup("/other/units/a.service.unit", units, mount) == ("", "")
    check unitOfCgroup("/u/units/a.service.unit", "/u/units", "/") == ("a.service", "")   # unitsCgroup without the mount
  test "cgroup file":
    check cgroupPathOf("1:name=x:/a\n0::/b/c\n") == "/b/c"
    check cgroupPathOf("") == ""
  test "process fields from a fake /proc":
    var r = testRoots(tmpDir("meta"), scSystem)
    r.unitsCgroup = "/jc/units"
    let p = r.procfs / "4242"
    createDir(p)
    writeFile(p / "comm", "sshd\n")
    writeFile(p / "cmdline", "sshd\0-D\0-e\0")
    writeFile(p / "status", "Name:\tsshd\nCapEff:\t000001ffffffffff\n")
    writeFile(p / "cgroup", "0::/jc/units/system.slice.unit/sshd.service.unit\n")
    createDir(r.sysrun / "units")
    createSymlink("0123456789abcdef0123456789abcdef", r.sysrun / "units" / "invocation:sshd.service")
    let f = processFields(r, 4242, 0, 5)
    let t = toTable(f)
    check t["_PID"] == "4242" and t["_UID"] == "0" and t["_GID"] == "5"
    check t["_COMM"] == "sshd" and t["_CMDLINE"] == "sshd -D -e"
    check t["_CAP_EFFECTIVE"] == "1ffffffffff"
    check t["_SYSTEMD_UNIT"] == "sshd.service" and t["_SYSTEMD_SLICE"] == "system.slice"
    check t["_SYSTEMD_CGROUP"] == "/jc/units/system.slice.unit/sshd.service.unit"
    check t["_SYSTEMD_INVOCATION_ID"] == "0123456789abcdef0123456789abcdef"
    r.scope = scUser
    check "_SYSTEMD_USER_UNIT" in toTable(processFields(r, 4242, 1000, 1000))
  test "an exited sender keeps _PID/_UID/_GID only":
    let r = testRoots(tmpDir("meta2"), scSystem)
    check processFields(r, 999999, 3, 4).mapIt(it.key) == @["_PID", "_UID", "_GID"]
