import std/[json, unittest]
import jumpstartcore/errors
import ipc/sdcproto

suite "sdc protocol":
  test "request round trip":
    let r = parseRequest(requestLine(%7, "job-submit", %*{"unit": "a.service"}))
    check r.verb == "job-submit" and r.id.getInt == 7
    check r.args["unit"].getStr == "a.service"
  test "bad requests":
    expect SdcFailure: discard parseRequest("""{"verb":"x"}""")
    expect SdcFailure: discard parseRequest("""{"id":"","verb":"x"}""")
    expect SdcFailure: discard parseRequest("""{"id":1,"verb":"x","args":[]}""")
    expect JsonParsingError: discard parseRequest("not json")
  test "error response carries code and result":
    let r = parseResponse(errorLine(%"a", ecBackend, "Job failed", "timeout", "x.service"))
    check not r.ok and r.code == ecBackend and r.jobResult == "timeout" and r.unit == "x.service"
  test "events and ok":
    let e = parseResponse(eventLine(%1, "item", %*{"name": "a"}, "units"))
    check e.isEvent and e.field == "units" and e.data["name"].getStr == "a"
    check parseResponse(okLine(%1, %*{"x": 1})).result["x"].getInt == 1
