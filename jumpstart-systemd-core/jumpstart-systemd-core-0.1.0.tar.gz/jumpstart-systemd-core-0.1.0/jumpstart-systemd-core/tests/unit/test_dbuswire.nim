## D-Bus wire format (src/dbus/wire.nim): byte layouts from the D-Bus
## specification's marshalling rules, round trips, framing and validation.
import std/[unittest, strutils]
import dbus/wire

proc hexOf(s: string): string = s.toHex.toLowerAscii

suite "marshalling layouts":
  test "string: length, bytes, NUL":
    check marshalBody([dstr("ab")]) == "\x02\x00\x00\x00ab\x00"
  test "struct aligns to 8":
    check marshalBody([dbyte(1), dstruct(duint32(2))]) ==
      "\x01" & repeat('\0', 7) & "\x02\x00\x00\x00"
  test "array of uint64: length excludes the padding before the first element":
    check marshalBody([darray("t", @[duint64(1'u64)])]) ==
      "\x08\x00\x00\x00" & repeat('\0', 4) & "\x01" & repeat('\0', 7)
  test "empty array still pads to the element alignment":
    check marshalBody([darray("(ss)")]) == "\x00\x00\x00\x00" & repeat('\0', 4)
  test "variant: signature then value":
    check marshalBody([dvariant(duint32(5))]) == "\x01u\x00\x00\x05\x00\x00\x00"
  test "boolean is a 32-bit 0 or 1":
    check marshalBody([dbool(true)]) == "\x01\x00\x00\x00"
  test "signature has a one-byte length":
    check marshalBody([dsig("a{sv}")]) == "\x05a{sv}\x00"
  test "int16 and int64 are little endian two's complement":
    check marshalBody([DValue(kind: dInt16, i: -2)]) == "\xfe\xff"
    check marshalBody([dint64(-1)]) == repeat('\xff', 8)

suite "round trips":
  test "nested values survive encode and decode":
    let dict = darray("{sv}", @[
      dentry(dstr("ActiveState"), dvariant(dstr("active"))),
      dentry(dstr("Job"), dvariant(dstruct(duint32(7), dpath("/org/freedesktop/systemd1/job/7")))),
      dentry(dstr("Names"), dvariant(dstrs(["a.service", "b.service"]))),
      dentry(dstr("T"), dvariant(duint64(high(uint64)))),
      dentry(dstr("D"), dvariant(ddouble(0.5)))])
    let body = @[dstr("org.freedesktop.systemd1.Unit"), dict, dstrs(newSeq[string]())]
    let sig = signatureOf(body)
    check sig == "sa{sv}as"
    let back = unmarshalBody(marshalBody(body), sig)
    check $back[1] == $dict
    check back[0].str == "org.freedesktop.systemd1.Unit"
  test "a whole message":
    let msg = Message(typ: mtSignal, serial: 9, path: "/org/freedesktop/systemd1",
      iface: "org.freedesktop.systemd1.Manager", member: "JobRemoved",
      body: @[duint32(3), dpath("/org/freedesktop/systemd1/job/3"), dstr("a.service"), dstr("done")])
    let data = encode(msg)
    check data.len mod 1 == 0
    check messageLength(data) == data.len
    check messageLength(data[0 ..< 10]) == -1
    let d = decode(data)
    check d.typ == mtSignal and d.serial == 9 and d.member == "JobRemoved"
    check d.signature == "uoss" and d.body[2].str == "a.service"
  test "the Hello call encodes to the reference bytes":
    # As sent by libdbus/GDBus: 'l', method call, flags 0, version 1, empty
    # body, serial 1, then PATH, DESTINATION, INTERFACE, MEMBER fields.
    let data = encode(Message(typ: mtMethodCall, serial: 1, path: "/org/freedesktop/DBus",
      iface: "org.freedesktop.DBus", member: "Hello", destination: "org.freedesktop.DBus"))
    check data[0 .. 3] == "l\x01\x00\x01"
    check data[4 .. 7] == "\x00\x00\x00\x00"
    check data[8 .. 11] == "\x01\x00\x00\x00"
    check data.len mod 8 == 0
    check "/org/freedesktop/DBus" in data and "Hello" in data
    let d = decode(data)
    check d.path == "/org/freedesktop/DBus" and d.destination == "org.freedesktop.DBus"

suite "validation":
  test "signatures":
    check splitSignature("a{sv}(ii)s") == @["a{sv}", "(ii)", "s"]
    check validSignature("a(ssssssouso)")
    check not validSignature("a{sv")
    check not validSignature("(")
    check not validSignature("z")
  test "object paths":
    check validObjectPath("/")
    check validObjectPath("/org/freedesktop/systemd1/unit/dbus_2eservice")
    check not validObjectPath("/a//b")
    check not validObjectPath("/a/")
    check not validObjectPath("/a-b")
    expect DBusWireError: discard marshalBody([dpath("bad")])
  test "corrupt input is rejected, not crashed on":
    let data = encode(Message(typ: mtMethodCall, serial: 1, path: "/", member: "X",
      body: @[dstr("hello")]))
    expect DBusWireError: discard decode(data[0 ..< data.len - 2])
    var bad = data
    bad[0] = 'B'
    expect DBusWireError: discard decode(bad)
    expect DBusWireError: discard unmarshalBody("\x05\x00\x00\x00ab", "s")
    expect DBusWireError: discard unmarshalBody("\x02\x00\x00\x00", "b")
  test "array element type must match":
    expect DBusWireError: discard marshalBody([darray("s", @[duint32(1)])])

suite "unit name labels":
  test "bus_label_escape":
    check labelEscape("dbus.service") == "dbus_2eservice"
    check labelEscape("gnome-session@gnome.target") == "gnome_2dsession_40gnome_2etarget"
    check labelEscape("1a") == "_31a"
    check labelEscape("") == "_"
  test "unescape inverts escape":
    for n in ["dbus.service", "org.gnome.Shell@user.service", "a_b.target", "x-y\\x2dz.slice", "9.service"]:
      check labelUnescape(labelEscape(n)) == n
