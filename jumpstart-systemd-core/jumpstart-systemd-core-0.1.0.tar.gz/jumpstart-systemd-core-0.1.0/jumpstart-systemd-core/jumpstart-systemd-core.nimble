# Package
version       = "0.0.0"
author        = "Kreato Linux"
description   = "systemd compatibility core for Jumpstart"
license       = "GPL-3.0-or-later"
srcDir        = "src"

requires "nim >= 2.2.0"
# Pin to a Jumpstart commit or tag before building outside a source checkout:
# requires "https://github.com/kreatolinux/src?subdir=libs/jumpstartcore#<commit>"
#
# In local development nim.cfg points at a sibling Jumpstart checkout instead.
