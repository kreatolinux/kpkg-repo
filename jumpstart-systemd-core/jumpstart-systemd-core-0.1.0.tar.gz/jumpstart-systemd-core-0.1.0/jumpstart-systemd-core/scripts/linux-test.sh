#!/bin/sh
# Run a command inside the privileged test image ($TEST_IMAGE, default jumpstart-dev:latest) against a copy of
# this repository (mounted read-only, copied with tar so nothing is written
# back). Needs the Jumpstart checkout next to this repository (nim.cfg).
# Usage: scripts/linux-test.sh 'nim c -r tests/unit/test_foo.nim'
set -eu
here=$(cd "$(dirname "$0")/.." && pwd)
src2=${JUMPSTART_SRC:-$here/../src-2}
exec docker run --rm --privileged --cgroupns=host \
  -v "$here":/ro/core:ro -v "$src2/libs":/ro/src-2/libs:ro \
  "${TEST_IMAGE:-jumpstart-dev:latest}" sh -c '
    set -e
    mkdir -p /w/src-2 /w/core
    cp -a /ro/src-2/libs /w/src-2/libs
    (cd /ro/core && tar --exclude=.git --exclude=out --exclude=nimcache --exclude=.isobuild -cf - .) | tar -xf - -C /w/core
    cd /w/core
    '"$*"
