#!/bin/sh
# QEMU user-mode networking: 10.0.2.15/24, gateway 10.0.2.2, DNS 10.0.2.3.
for d in /sys/class/net/*; do
  n=${d##*/}; [ "$n" = lo ] && continue
  ip link set "$n" up && ip addr add 10.0.2.15/24 dev "$n" && ip route add default via 10.0.2.2
  echo 'nameserver 10.0.2.3' > /etc/resolv.conf
  break
done
exit 0
