#!/bin/sh
# Creates the Kreato Linux rootfs for the QEMU image: out/qemu-kreato/cache/kreato-root.img (ext4, 14 GB sparse).
# The rootfs is the ghcr.io/kreatolinux/builder:aarch64 userland, extended with kpkg: `kpkg install`
# from the binary mirror (mirror.krea.to) and `kpkg build` for packages the mirror lacks. Needs
# docker with privileged containers (loop mount) and a clone of kpkg-repo.
#   KPKG_REPO=/path/to/kpkg-repo [KPKG_REV=d91fef12] [KREATO_PKGS="..."] [BUILD_BUDGET=5400] scripts/kreato-rootfs.sh
# KREATO_PKGS default: the headless set (linux booster dbus eudev elogind polkit accountsservice upower openssh);
# with GNOME=1: + gdm gnome-shell gnome-session.
set -eu
here=$(cd "$(dirname "$0")/.." && pwd)
repo=${KPKG_REPO:?set KPKG_REPO to a kpkg-repo clone (read only: it is copied)}
rev=${KPKG_REV:-d91fef12}   # the commit whose binaries the mirror has; recipes at master are newer than the mirror
q=$here/out/qemu-kreato; mkdir -p "$q/cache"
pin=${PIN_LATEST:-linux booster}   # installed at their newest recipe commit (the mirror has no binary for $rev)
pk=${KREATO_PKGS:-dbus eudev elogind polkit accountsservice upower openssh}
[ -z "${GNOME:-}" ] || pk="$pk gdm gnome-shell gnome-session"
img=${KREATO_BUILDER:-ghcr.io/kreatolinux/builder:aarch64}
name=kreato-rootfs-$$
[ -f "$q/cache/kreato-root.img" ] || {
  truncate -s 14G "$q/cache/kreato-root.img"
  docker run --rm -v "$q/cache":/w alpine:3.22 sh -c 'apk add -q e2fsprogs && mkfs.ext4 -q -F /w/kreato-root.img'
}
docker rm -f "$name" >/dev/null 2>&1 || true
# --init: kpkg refuses to run while a defunct kpkg process exists
docker run -d --init --name "$name" --privileged -v "$q/cache":/hostwork "$img" sleep infinity >/dev/null
trap 'docker exec "$name" sh -c "umount /rootfs/proc /rootfs/sys /rootfs/dev/pts /rootfs/dev; umount /rootfs" >/dev/null 2>&1; docker rm -f "$name" >/dev/null 2>&1' EXIT
docker exec "$name" sh -c '
  mkdir -p /rootfs && mount -o loop /hostwork/kreato-root.img /rootfs
  if [ ! -e /rootfs/etc/kreato-release ]; then   # seed from the builder image userland
    tar -C / --one-file-system -cf - --exclude=./rootfs --exclude=./hostwork --exclude=./proc --exclude=./sys --exclude=./dev . | tar -xpf - -C /rootfs
  fi
  mkdir -p /rootfs/proc /rootfs/sys /rootfs/dev /rootfs/etc/kpkg/repos'
if ! docker exec "$name" test -d /rootfs/etc/kpkg/repos/main/.git; then
  (cd "$(dirname "$repo")" && COPYFILE_DISABLE=1 tar -cf - --no-xattrs --no-mac-metadata --exclude="._*" "$(basename "$repo")" 2>/dev/null) | docker exec -i "$name" sh -c \
    'tar -xf - -C /rootfs/etc/kpkg/repos && mv /rootfs/etc/kpkg/repos/* /rootfs/etc/kpkg/repos/main 2>/dev/null || true'
fi
docker exec "$name" sh -c "
  mount -t proc proc /rootfs/proc; mount -t sysfs sys /rootfs/sys; mount --rbind /dev /rootfs/dev
  cp /etc/resolv.conf /rootfs/etc/resolv.conf; find /rootfs/tmp -maxdepth 1 -name 'kpkg.lock*' -delete"
docker cp "$here/scripts/kreato-rootfs-chroot.sh" "$name":/tmp/kr.sh
docker exec "$name" sh -c 'cp /tmp/kr.sh /rootfs/kr.sh'
# progress: docker exec <container> tail -f /rootfs/kreato-build.times (container name printed below)
echo ">> kreato rootfs: container $name, packages: $pk"
docker exec -e BUILD_BUDGET="${BUILD_BUDGET:-5400}" -e SKIP_BUILD="${SKIP_BUILD:-}" -e STOP_ON_FAIL="${STOP_ON_FAIL:-}" -e KPKG_REV="$rev" -e PIN_LATEST="$pin" "$name" \
  chroot /rootfs sh /kr.sh $pk || true
docker exec "$name" sh -c 'cat /rootfs/kreato-build.times' > "$q/kreato-build.times" || true
docker exec "$name" sh -c 'tar -C /rootfs -cf - kreato-logs 2>/dev/null' | tar -xf - -C "$q" 2>/dev/null || true
docker exec "$name" sh -c 'cat /rootfs/missing.txt' > "$q/kreato-missing.txt" || true
echo ">> done; timings in $q/kreato-build.times, packages missing from the mirror in $q/kreato-missing.txt"
