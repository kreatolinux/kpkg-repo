#!/bin/sh
# Boots out/qemu/disk.img interactively: UEFI (edk2) -> GRUB -> Booster -> Jumpstart.
# Serial console on this terminal (log in as root / root). Leave QEMU with Ctrl-a x.
# ssh: host port 2222 -> guest 22 (ssh -p 2222 root@localhost, password root).
# Env: DISK, FW (edk2 aarch64 code), MEM (MiB), SMP, SSH_PORT.
set -eu
here=$(cd "$(dirname "$0")/.." && pwd)
# GNOME=1 boots the desktop variant (out/qemu-gnome, built with GNOME=1 scripts/qemu-image.sh):
# virtio-gpu + keyboard/mouse, 4 GiB RAM. GFX=cocoa|vnc|none picks the display (default cocoa
# on macOS, none elsewhere); with MONITOR_SOCK=path the QEMU monitor is a unix socket
# (echo "screendump file.ppm" | nc -U path).
var=qemu; [ -z "${GNOME:-}" ] || var=qemu-gnome
[ -z "${KREATO:-}" ] || var=qemu-kreato   # KREATO=1: the Kreato Linux image (GNOME=1 adds the desktop devices)
disk=${DISK:-$here/out/$var/disk.img}
[ -f "$disk" ] || { echo "no $disk; run scripts/qemu-image.sh first" >&2; exit 1; }
qemu=$(command -v qemu-system-aarch64) || { echo "qemu-system-aarch64 not found" >&2; exit 1; }
FW=${FW:-$(dirname "$(readlink -f "$qemu")")/../share/qemu/edk2-aarch64-code.fd}
if [ "$(uname -s)" = Linux ]; then accel=${ACCEL:-kvm}; else accel=${ACCEL:-hvf}; fi
# the guest may write to the disk (it does not on the EROFS root), so run on a copy
run=$here/out/$var/run.img
[ -n "${KEEP_RUN_IMAGE:-}" ] && [ -f "$run" ] || cp -f "$disk" "$run"
if [ -n "${GNOME:-}" ]; then
  gfx=${GFX:-none}
  mon=none; [ -z "${MONITOR_SOCK:-}" ] || mon=unix:$MONITOR_SOCK,server,nowait
  ser="-serial mon:stdio"; [ -z "${SERIAL_SOCK:-}" ] || ser=
  set -- -m "${MEM:-4096}" -smp "${SMP:-4}" -display "$gfx" $ser -device virtio-gpu-pci \
    -device qemu-xhci -device usb-kbd -device usb-tablet -monitor "$mon"
else
  set -- -m "${MEM:-2048}" -smp "${SMP:-2}" -nographic -monitor none
fi
exec "$qemu" -M virt -accel "$accel" -cpu host "$@" \
  -bios "$FW" \
  -drive file="$run",format=raw,if=virtio,media=disk \
  -netdev user,id=n0,hostfwd=tcp:127.0.0.1:"${SSH_PORT:-2222}"-:22 -device virtio-net-pci,netdev=n0 \
  ${SERIAL_SOCK:+-chardev socket,id=s0,path=$SERIAL_SOCK,server=on,wait=off,logfile=${SERIAL_LOG:-$here/out/$var/serial.log} -serial chardev:s0}
