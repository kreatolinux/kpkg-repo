#!/bin/sh
# Runs INSIDE the Kreato rootfs (chroot, started by kreato-rootfs.sh). Installs the packages that
# the QEMU image needs with kpkg: whatever the binary mirror has is installed from it, the rest is
# built from source (time-boxed). Progress goes to /kreato-build.log; /kreato-build.times has the timings.
# Usage: kreato-rootfs-chroot.sh PKG...      env: BUILD_BUDGET (seconds, default 5400), SKIP_BUILD
export PYTHONDONTWRITEBYTECODE=1   # kpkg verifies installed files by checksum; python rewriting .pyc files breaks that
cd /
T=/kreato-build.times; : > $T
log() { echo "$(date +%T) $*" | tee -a $T; }
strip() { sed 's/\x1b\[[0-9;]*[A-Za-z]//g; s/\[[0-9;]*m//g'; }

# kpkg's downloader sometimes stores the HTTP response headers or a truncated body in the archive
# cache; verify every cached archive and refetch the broken ones with curl.
fixcache() {
  D=$(ls -d /var/cache/kpkg/archives/*/*/ 2>/dev/null | head -1) || return 0
  [ -n "$D" ] || return 0
  T2=$(basename $D)
  for f in $D*.kpkg; do
    [ -f "$f" ] || continue
    gzip -t "$f" 2>/dev/null || { log "refetch $(basename $f)"; curl -sf -o "$f" "https://mirror.krea.to/archives/system/$T2/$(basename $f)" || rm -f "$f"; }
  done
}
# retry a kpkg command: fix the archive cache, reinstall a package whose files kpkg complains about
kp() {
  for i in 1 2 3 4 5 6; do
    kpkg "$@" > /kpkg.out 2>&1 && return 0
    r=$(strip < /kpkg.out | sed -n "s/.*please reinstall '\(.*\)'.*/\1/p" | head -1)
    if [ "$r" = elogind ] && [ -L /usr/include/systemd/elogind ] && [ ! -e /usr/include/systemd/elogind ]; then
      # packaging bug: the elogind recipe's `ln -sn elogind $ROOT/usr/include/systemd` lands INSIDE the existing
      # directory as the self-referencing link usr/include/systemd/elogind -> elogind, which kpkg's integrity check
      # of every dependent build then reports as a missing file. Point it at its own directory instead.
      log "workaround: dangling usr/include/systemd/elogind"; ln -sfn . /usr/include/systemd/elogind
    elif [ -n "$r" ]; then log "reinstall $r"; kpkg install -y -f "$r" >/dev/null 2>&1; else fixcache; fi
  done
  return 1
}

[ -n "$(find /etc/kpkg/repos/main -maxdepth 1 -name .git 2>/dev/null)" ] && git config --global --add safe.directory '*'
# an earlier interrupted run (killed kpkg) leaves a lock and a pending history entry behind
kpkg clearLock >/dev/null 2>&1; kpkg history recover >/dev/null 2>&1 || true
# 1. a current kpkg first, from the newest recipes (the one in the seed image cannot verify packages that
# carry pkgsums.ini); then the recipes are pinned to KPKG_REV, the commit the mirror's binaries match
cd /etc/kpkg/repos/main && git checkout -q master 2>/dev/null; cd /
kp install -y kpkg
log "kpkg $(kpkg --version)"
head=$(cd /etc/kpkg/repos/main && git rev-parse --short HEAD)
# the kernel and Booster binaries on the mirror are newer than KPKG_REV: install them at the commit that
# last changed their recipe (kpkg's pkg#commit syntax), before the recipes are pinned
for p in $PIN_LATEST; do
  c=$(cd /etc/kpkg/repos/main && git log -1 --format=%h -- $p/run3)
  kpkg info $p 2>/dev/null | grep -q 'installed: yes' && continue
  log "install $p#$c"; kp install -y $p#$c || log "FAIL $p#$c: $(strip < /kpkg.out | tail -2 | tr '\n' ' ')"
done
[ -z "${KPKG_REV:-}" ] || (cd /etc/kpkg/repos/main && git checkout -q $KPKG_REV)
log "recipes at $(cd /etc/kpkg/repos/main && git rev-parse --short HEAD) (master was $head)"

# 2. which packages does the target set need, and which of them does the mirror lack?
kpkg install -n "$@" 2>&1 | strip | grep '^Packages' | head -1 | sed 's/^Packages ([0-9]*): //; s/ -> [^ ]*//g; s/ reinstall//g' | tr ' ' '\n' | grep -v '^$' | awk '!s[$0]++' > /closure.txt
log "closure: $(wc -l < /closure.txt) packages"
kpkg install -y -d "$@" 2>&1 | strip | sed -n "s/.*failed to download '\(.*\)'.*/\1/p" | sort -u > /missing.txt
log "missing from the binary mirror: $(wc -l < /missing.txt)"; cat /missing.txt | tr '\n' ' ' | tee -a $T; echo >> $T
# 3. one package at a time in dependency order (kpkg's closure list is topologically sorted): what the
# mirror has is installed from it, the rest is built from source and installed from the local archive,
# within the time budget (kpkg install fails as a whole as soon as one dependency has no binary).
kpkg init sandbox >/dev/null 2>&1 || kp init sandbox
start=$(date +%s)
for p in $(cat /closure.txt); do
  kpkg info $p 2>/dev/null | grep -q 'installed: yes' && continue
  if grep -qxF $p /missing.txt; then
    [ -z "${SKIP_BUILD:-}" ] || { log "skip (SKIP_BUILD) $p"; continue; }
    [ $(( $(date +%s) - start )) -lt ${BUILD_BUDGET:-5400} ] || { log "BUDGET EXHAUSTED before $p"; break; }
    log "build $p"; t0=$(date +%s)
    mkdir -p /kreato-logs
    if kp build -y -t=false $p; then
      cp /kpkg.out /kreato-logs/$p.log
      kp install -y $p >/dev/null 2>&1 && log "OK $p ($(( $(date +%s) - t0 )) s)" || log "BUILT-NOT-INSTALLED $p"
    else
      cp /kpkg.out /kreato-logs/$p.log
      log "FAIL $p: $(strip < /kpkg.out | grep -E 'ERROR:|fatal:|Error:|error: ' | head -2 | cut -c1-200 | tr '\n' ' ')"
      [ -z "${STOP_ON_FAIL:-}" ] || break
    fi
  else
    kp install -y $p >/dev/null 2>&1 || log "mirror install failed: $p"
  fi
done
log DONE
