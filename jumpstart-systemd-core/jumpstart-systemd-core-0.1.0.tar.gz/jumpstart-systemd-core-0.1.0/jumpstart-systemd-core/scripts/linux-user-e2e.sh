#!/bin/sh
# User-scope end-to-end test (tests/process/test_e2e_user.nim) in the privileged
# test image: builds the core tree as root, delegates a cgroup subtree to
# `nobody` and runs the test as that user, the way a per-user Jumpstart daemon does.
# Usage: scripts/linux-user-e2e.sh
set -eu
here=$(cd "$(dirname "$0")" && pwd)
exec "$here/linux-test.sh" '
  mkdir -p /tmp/out /tmp/sdc-core
  make build NIMFLAGS="-d:debug --threads:off --hints:off" BIN=/tmp/sdc-core/bin >/tmp/out/make.log 2>&1 || { tail -30 /tmp/out/make.log; exit 1; }
  cp -R share /tmp/sdc-core/share
  for f in /tmp/sdc-core/share/units/*.service /tmp/sdc-core/share/units-user/*.service; do
    sed -i "s|@COREDIR@|/tmp/sdc-core|g" "$f"; done
  chmod -R go-w /tmp/sdc-core; chmod -R a+rX /tmp/sdc-core
  nim c --threads:off --hints:off -o:/tmp/out/e2eu tests/process/test_e2e_user.nim >/tmp/out/nim.log 2>&1 || { tail -30 /tmp/out/nim.log; exit 1; }
  chmod 755 /tmp/out /tmp/out/e2eu
  rm -rf /tmp/sdc-eu; mkdir -p /tmp/sdc-eu/home /tmp/sdc-eu/xdg /tmp/sdc-eu/rt /tmp/sdc-eu/st
  chmod 700 /tmp/sdc-eu/xdg; chown -R 65534:65534 /tmp/sdc-eu
  CG=/sys/fs/cgroup/sdc-eu
  mkdir -p $CG/cores/systemd/control $CG/cores/systemd/units
  chown -R 65534:65534 $CG
  echo $$ > $CG/cgroup.procs
  SDC_E2E_USER_CORE=/tmp/sdc-core SDC_E2E_USER_CG=$CG/cores/systemd \
    setpriv --reuid=65534 --regid=65534 --clear-groups /tmp/out/e2eu
'
