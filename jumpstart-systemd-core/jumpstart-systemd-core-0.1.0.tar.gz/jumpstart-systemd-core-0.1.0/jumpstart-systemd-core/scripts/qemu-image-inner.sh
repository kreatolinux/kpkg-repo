#!/bin/sh
# Runs INSIDE a debian:trixie (arm64) container, started by qemu-image.sh.
# Mounts: /out (out/qemu, rw), /in/jumpstart-linux (ro), /in/core-root.tar,
# /in/erofsdrv (krep's static EROFS/GRUB image driver), /in/units (extra files).
# Builds the Debian rootfs, installs Jumpstart + the systemd core, then runs the
# krep pipeline (EROFS root + Booster initramfs + GRUB on an ESP) into /out/disk.img.
set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends ca-certificates curl git gcc libc6-dev make \
  linux-image-arm64 kmod erofs-utils gdisk tar dosfstools mtools \
  grub-efi-arm64-bin grub-common debootstrap >/dev/null

# Booster (cached in out/qemu/cache)
C=/out/cache; mkdir -p $C
if [ ! -x $C/booster-bin ] || [ ! -x $C/booster-init ]; then
  GOV=1.26.0
  curl -fsSL https://go.dev/dl/go$GOV.linux-arm64.tar.gz | tar -C /usr/local -xz
  export PATH=$PATH:/usr/local/go/bin
  git clone -q --branch 0.13 --depth 1 https://github.com/anatol/booster /booster
  (cd /booster && CGO_ENABLED=0 go build -o $C/booster-init ./init &&
    CGO_ENABLED=0 go build -o $C/booster-bin ./generator)
fi

# Debian rootfs
R=/rootfs; rm -rf $R; mkdir -p $R
# the plain Debian part is cached (delete out/qemu/cache/debian-base.tar to refresh it)
BASE=$C/debian-base.tar; [ -z "${GNOME:-}" ] || BASE=$C/debian-gnome.tar
if [ -f $BASE ]; then
  tar -xpf $BASE -C $R
else
  PKGS=systemd,util-linux,bash,coreutils,procps,iproute2,iputils-ping,nano,vim-tiny,login,passwd,libpam-modules,libpam-runtime,openssh-server,kmod,ca-certificates,less,grep,sed,findutils,mount,dbus-daemon
  debootstrap --variant=minbase --include=$PKGS trixie $R http://deb.debian.org/debian >/dev/null
  if [ -n "${GNOME:-}" ]; then
    # the desktop set goes in with apt inside the chroot (debootstrap --include cannot configure it)
    GP=${GNOME_PKGS:-dbus-user-session polkitd udev gdm3 gnome-shell gnome-session libgl1-mesa-dri libgles2 xwayland mesa-vulkan-drivers adwaita-icon-theme fonts-dejavu-core libpam-systemd pciutils usbutils xkb-data kbd}
    mount -t proc proc $R/proc; mount -t sysfs sys $R/sys; mount --bind /dev $R/dev; mount -t devpts devpts $R/dev/pts
    printf '#!/bin/sh\nexit 101\n' > $R/usr/sbin/policy-rc.d; chmod 755 $R/usr/sbin/policy-rc.d
    chroot $R apt-get update -qq
    chroot $R apt-get install -y --no-install-recommends $GP >/out/apt-gnome.log 2>&1 || { tail -40 /out/apt-gnome.log; exit 1; }
    rm -f $R/usr/sbin/policy-rc.d
    umount $R/dev/pts $R/dev $R/sys $R/proc
  fi
  chroot $R apt-get clean
  rm -rf $R/var/lib/apt/lists/* $R/usr/share/doc $R/usr/share/man $R/usr/share/info $R/usr/share/locale
  tar -cpf $BASE.part -C $R . && mv $BASE.part $BASE
fi
# systemd is installed for its unit files; it must never be the init
[ ! -e $R/sbin/init ] || rm -f $R/sbin/init
echo kreato-sdc > $R/etc/hostname
printf '127.0.0.1\tlocalhost\n127.0.1.1\tkreato-sdc\n' > $R/etc/hosts
echo 'root:root' | chroot $R chpasswd
printf 'PermitRootLogin yes\nPasswordAuthentication yes\n' > $R/etc/ssh/sshd_config.d/10-qemu-root.conf
rm -f $R/etc/machine-id; : > $R/etc/machine-id
mkdir -p $R/etc/tmpfiles.d

# Jumpstart
install -m 755 /in/jumpstart-linux/usr/bin/jumpstart $R/usr/bin/jumpstart
install -m 755 /in/jumpstart-linux/usr/bin/jumpctl $R/usr/bin/jumpctl
install -d -m 755 $R/usr/lib/jumpstart/cores $R/usr/lib/security
install -m 755 /in/jumpstart-linux/usr/lib/jumpstart/kongue-runner $R/usr/lib/jumpstart/kongue-runner
install -m 755 /in/jumpstart-linux/usr/lib/security/pam_jumpstart.so $R/usr/lib/security/pam_jumpstart.so

# systemd core (make install PREFIX=/usr, done by qemu-image.sh)
tar -xpf /in/core-root.tar -C $R
chown -R 0:0 $R/usr/lib/jumpstart
chmod -R go-w $R/usr/lib/jumpstart
chmod 755 $R/usr/lib/jumpstart/cores $R/usr/lib/jumpstart/cores/systemd

# Debian's real journald/logind cannot run under Jumpstart. The core ships its own
# journald units (lowest priority: a distribution's units of the same name win), so Debian's are dropped.
for u in systemd-journald.service systemd-journald.socket systemd-journald-dev-log.socket \
  systemd-journald-audit.socket 'systemd-journald@.service' 'systemd-journald@.socket' \
  'systemd-journald-varlink@.socket' systemd-journal-flush.service systemd-logind.service; do
  rm -f "$R/usr/lib/systemd/system/$u"
  find $R/usr/lib/systemd/system $R/etc/systemd/system -name "$u" -delete
done

# TPM / measured-boot units (no TPM in the VM, their conditions are false); keeping
# them makes a stop of sysinit.target fail the core's ordering-cycle check.
find $R/usr/lib/systemd/system $R/etc/systemd/system \( -name 'systemd-pcr*' -o -name 'systemd-tpm2-setup*' \) -delete

# enable cores; serviceHandler only runs the /etc overlay mounts
install -d -m 755 $R/etc/jumpstart/cores/enabled $R/etc/jumpstart/enabled
: > $R/etc/jumpstart/cores/enabled/serviceHandler
: > $R/etc/jumpstart/cores/enabled/systemd
printf '[System]\nmount_fstab = false\nhostname = kreato-sdc\n' > $R/etc/jumpstart/main.conf
# writable /etc on the read-only EROFS root: tmpfs-backed overlay, mounted by Jumpstart
cp /in/units/ovbase.kg /in/units/ovprep.kg /in/units/ov-etc.kg $R/etc/jumpstart/
ln -s ../ov-etc.kg $R/etc/jumpstart/enabled/ov-etc.kg

# gettys: only through systemd units (no native Jumpstart getty exists)
# serial-getty@ttyAMA0 comes from the core's serial getty generator (RFC 0002 8.6,
# from /sys/class/tty/console/active); tty1 is enabled by the usual link.
install -d $R/etc/systemd/system/getty.target.wants
ln -sf /usr/lib/systemd/system/getty@.service $R/etc/systemd/system/getty.target.wants/getty@tty1.service
install -d $R/etc/modules-load.d && echo virtio_net > $R/etc/modules-load.d/qemu.conf   # no udev: load the NIC driver by hand
# QEMU user-mode networking (static, no DHCP client in the image) and ssh
install -m 755 /in/units/qemu-net.sh $R/usr/local/sbin/qemu-net
install -m 644 /in/units/qemu-net.service $R/etc/systemd/system/qemu-net.service
install -d $R/etc/systemd/system/multi-user.target.wants
ln -sf /etc/systemd/system/qemu-net.service $R/etc/systemd/system/multi-user.target.wants/qemu-net.service
ln -sf /usr/lib/systemd/system/ssh.service $R/etc/systemd/system/multi-user.target.wants/ssh.service
rm -f $R/etc/systemd/system/sockets.target.wants/ssh.socket
if [ -n "${GNOME:-}" ]; then
  echo virtio_gpu >> $R/etc/modules-load.d/qemu.conf
  if [ "${LOGIND:-elogind}" = elogind ] && ls /out/debs/elogind_*.deb >/dev/null 2>&1; then
    # Gentoo-style logind: elogind provides org.freedesktop.login1 (sessions, seats, XDG_RUNTIME_DIR)
    # on top of the core, which has no systemd1 manager API. Debian's elogind Conflicts: systemd, so
    # its payload is unpacked with dpkg-deb -x, minus its busctl. libpam-systemd stays (login1 only).
    echo ">> unpacking elogind (not installed through dpkg: it Conflicts with systemd)"
    mkdir -p /tmp/el; dpkg-deb -x /out/debs/elogind_*.deb /tmp/el; rm -f /tmp/el/usr/bin/busctl
    cp -a /tmp/el/. $R/; rm -rf /tmp/el
    ln -sf /etc/systemd/system/elogind.service $R/etc/systemd/system/multi-user.target.wants/elogind.service
  fi
  install -d $R/etc/systemd/system/graphical.target.wants
  # PrivateUsers=yes needs user namespaces with an id mapping, which the core refuses (226/NAMESPACE):
  # a drop-in turns it off for the stock units that ask for it (accounts-daemon, upower, ...)
  for f in $(grep -lE '^PrivateUsers=(yes|true|1)' $R/usr/lib/systemd/system/*.service 2>/dev/null); do
    u=$(basename $f); install -d $R/etc/systemd/system/$u.d
    printf '[Service]\nPrivateUsers=no\n' > $R/etc/systemd/system/$u.d/10-core-privateusers.conf
  done
  # D-Bus activation hand-off to systemd needs org.freedesktop.systemd1 on the bus, which the core does
  # not provide: callers would wait the full 25 s service_start_timeout, so drop the activation files.
  for n in systemd1 hostname1 locale1 timedate1 network1 machine1 import1 resolve1 portable1 home1 oom1; do
    rm -f $R/usr/share/dbus-1/system-services/org.freedesktop.$n.service
  done
  # with --systemd-activation the bus waits service_start_timeout for org.freedesktop.systemd1 to show up
  # even when no service file names it; without the flag unknown names fail with ServiceUnknown at once
  install -d $R/etc/systemd/system/dbus.service.d
  printf '[Service]\nExecStart=\nExecStart=/usr/bin/dbus-daemon --system --address=systemd: --nofork --nopidfile --syslog-only\n' > $R/etc/systemd/system/dbus.service.d/10-no-systemd-activation.conf
  chroot $R useradd -m -s /bin/bash -G audio,video,plugdev,netdev user 2>/dev/null || chroot $R useradd -m -s /bin/bash user
  echo 'user:user' | chroot $R chpasswd
  mkdir -p $R/etc/tmpfiles.d; echo 'd /home/user 0700 user user -' > $R/etc/tmpfiles.d/jumpstart-user.conf   # /home is a tmpfs
  for u in polkit upower accounts-daemon udisks2 colord; do # dbus activation needs org.freedesktop.systemd1: start eagerly
    ln -sf /usr/lib/systemd/system/$u.service $R/etc/systemd/system/graphical.target.wants/$u.service
  done
  [ ! -d /in/gnome ] || cp -a /in/gnome/. $R/ 2>/dev/null || true
fi
mkdir -p $R/dev $R/proc $R/sys $R/run $R/tmp

if [ -n "${DEBUG_SHELL:-}" ]; then # a root shell on the serial port, started by native Jumpstart
  printf '#!/bin/sh\nexec setsid -c /bin/sh </dev/ttyAMA0 >/dev/ttyAMA0 2>&1\n' > $R/usr/local/sbin/dbgshell; chmod 755 $R/usr/local/sbin/dbgshell
  printf 'description: "debug shell"\ntype: "simple"\n\nservice {\n    exec "/usr/local/sbin/dbgshell"\n}\n' > $R/etc/jumpstart/dbgshell.kg
  ln -s ../dbgshell.kg $R/etc/jumpstart/enabled/dbgshell.kg
fi

# kernel + modules + Booster
KVER=$(ls /usr/lib/modules | head -1)
mkdir -p $R/usr/lib/modules $R/boot $R/usr/lib/booster
rm -rf "$R/usr/lib/modules/$KVER"; cp -a /usr/lib/modules/$KVER $R/usr/lib/modules/
cp /boot/vmlinuz-$KVER $R/boot/vmlinuz-$KVER
install -m 755 $C/booster-bin $R/usr/bin/booster
install -m 755 $C/booster-init $R/usr/lib/booster/init
printf 'modules_force_load: overlay\n' > $R/etc/booster.yaml

echo "--- rootfs: $(du -sx $R | cut -f1) KiB"
rm -rf /out/img; mkdir /out/img
# krep default writable mounts (tmpfs /var /tmp /root /home) are appended to /etc/fstab
KREP_BOOTLOADER=grub KREP_CONSOLE="${CONSOLE:-ttyAMA0,115200}" KREP_KERNEL_ARGS="${KERNEL_ARGS:-}" \
  /in/erofsdrv $R /out/img /usr/bin/jumpstart booster
mv /out/img/integration.img /out/disk.img
cp /out/img/integration.cmdline /out/disk.cmdline 2>/dev/null || true
rm -rf /out/img
sgdisk -p /out/disk.img
