#!/bin/sh
# Builds Jumpstart (daemon + jumpctl) from the sibling checkout inside the
# test image ($TEST_IMAGE, default jumpstart-dev:latest) and leaves the result in $OUT (default out/jumpstart-linux),
# for the integration test with the real `jumpctl cores run`.
set -eu
here=$(cd "$(dirname "$0")/.." && pwd)
src2=${JUMPSTART_SRC:-$here/../src-2}
out=${OUT:-$here/out/jumpstart-linux}
mkdir -p "$out"
docker run --rm --privileged -v "$src2":/ro/src-2:ro -v "$out":/out "${TEST_IMAGE:-jumpstart-dev:latest}" sh -c '
  set -e
  mkdir -p /w && (cd /ro/src-2 && tar --exclude=.git --exclude=out --exclude=.isobuild -cf - .) | tar -xf - -C /w
  cd /w
  make install_jumpstart PREFIX=/usr LIBDIR=/usr/lib DESTDIR=/out
'
