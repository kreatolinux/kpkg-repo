## Generates init.kg from the operation table of spec §5.3 and the registry
## (so the manifest cannot drift: every registry operation has an entry).
## Usage: nim c -r scripts/gen_manifest.nim > init.kg
import std/strutils
import jumpstartcore/registry

proc timeoutOf(op: string): string =
  case op
  of "core.verify": "10s"
  of "unit.list", "unit.validate": "30s"
  of "unit.resolve": "2s"
  of "unit.load": "2m"
  of "unit.activate", "target.start", "target.isolate": "15m"
  of "unit.deactivate": "5m"
  of "service.start": "10m"
  of "service.restart": "15m"
  of "service.stop", "service.reload": "5m"
  of "service.kill": "10s"
  of "service.enable", "mount.enable", "socket.enable", "swap.enable", "timer.enable", "path.enable",
     "target.enable": "10m"
  of "service.disable", "mount.disable", "socket.disable", "swap.disable", "timer.disable",
     "path.disable", "target.disable": "5m"
  of "target.stop": "10m"
  of "target.status": "30s"
  of "target.set-default": "10s"
  of "target.get-default": "5s"
  of "log.read": "30s"
  of "log.follow": "24h"
  of "log.write": "10s"
  of "log.rotate": "1m"
  of "log.vacuum": "5m"
  else:
    if op.endsWith(".status"): "10s"
    elif op.endsWith(".start") and op.startsWith("timer") or op.startsWith("path") and op.endsWith(".start"): "1m"
    elif op.endsWith(".stop") and (op.startsWith("timer") or op.startsWith("path")): "1m"
    elif op.endsWith(".start") or op.endsWith(".stop"):
      if op.endsWith(".start"): "10m" else: "5m"
    else: "10s"

echo """manifest_version: 1
name: "systemd"
description: "systemd unit compatibility"
core_version: "0.1.0"
version: "255"
jumpstart: ">=2.0.0, <3.0.0"
modes:
  - "system"
  - "user"

subsystems:
  - "core"
  - "unit"
  - "service"
  - "mount"
  - "timer"
  - "socket"
  - "target"
  - "swap"
  - "path"
  - "log"
# unit.activate reaches default.target in systemd's own order (cores 11.5,
# Appendix D); the manager owns every unit process (cores 15.2).
activation: "core"

supervisor:
  executable: "bin/systemd-compat-manager"
  ready_timeout: "30s"

supported_ops:
"""
var lastSub = ""
for spec in registry(CurrentManifestVersion):
  let sub = spec.name.split('.')[0]
  if sub != lastSub:
    echo ""
    lastSub = sub
  echo "  - name: \"" & spec.name & "\""
  if spec.name == "unit.translate":
    echo "    backend: \"unsupported\""
    continue
  echo "    backend: \"exec\""
  echo "    options:"
  if spec.name == "core.verify":
    echo "      executable: \"bin/systemd-compat\""
    echo "      mode: \"oneshot\""
    echo "      sandbox: true"
    echo "      # cores 13.1: the sandboxed working directory must be writable (the private /tmp is)"
    echo "      working_directory: \"/tmp\""
  else:
    echo "      executable: \"bin/systemd-compat\""
    echo "      mode: \"persistent\""
  echo "      timeout: \"" & timeoutOf(spec.name) & "\""
echo """
init {
  print "systemd core ${core.core_version} (systemd ${core.version} semantics)"
}"""
