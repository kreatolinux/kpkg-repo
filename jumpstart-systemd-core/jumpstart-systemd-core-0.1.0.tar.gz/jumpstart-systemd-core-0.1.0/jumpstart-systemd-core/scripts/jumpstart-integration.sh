#!/bin/sh
# Runs the real Jumpstart daemon as PID 1 of a throwaway privileged container
# with this core installed, and drives it through jumpctl. Needs
# scripts/build-jumpstart.sh to have produced out/jumpstart-linux first.
set -eu
here=$(cd "$(dirname "$0")/.." && pwd)
name=sdc-js-it
fail=0
docker rm -f $name >/dev/null 2>&1 || true
docker run -d --name $name --privileged --cgroupns=host --init=false \
  -v "$here":/ro/core:ro -v "${JUMPSTART_SRC:-$here/../src-2}/libs":/ro/src-2/libs:ro "${TEST_IMAGE:-jumpstart-dev:latest}" sh -c '
    set -e
    cp -a /ro/core/out/jumpstart-linux/usr/. /usr/
    chmod 755 /usr/bin/jumpctl /usr/bin/jumpstart /usr/lib/jumpstart/kongue-runner
    mkdir -p /w/src-2 && cp -a /ro/src-2/libs /w/src-2/libs
    mkdir -p /w/core && (cd /ro/core && tar --exclude=.git --exclude=out --exclude=nimcache -cf - .) | tar -xf - -C /w/core
    cd /w/core && make install PREFIX=/usr DESTDIR= NIMFLAGS="-d:debug --threads:off" >/dev/null 2>&1
    mkdir -p /etc/systemd/system
    printf "[Service]\nExecStart=/bin/sh -c \"echo up; exec sleep 1000\"\n" > /etc/systemd/system/hello.service
    exec /usr/bin/jumpstart' >/dev/null
i=0
until docker exec $name jumpctl cores status >/dev/null 2>&1; do
  i=$((i+1)); [ $i -gt 120 ] && { echo 'daemon did not come up'; docker logs $name | tail; exit 1; }
  sleep 2
done
run() { docker exec $name "$@"; }
check() { # check DESCRIPTION CONDITION-COMMAND...
  desc=$1; shift
  if "$@"; then echo "ok: $desc"; else echo "FAIL: $desc"; fail=1; fi
}
run jumpctl cores enable systemd --now || { echo 'FAIL: cores enable systemd --now'; fail=1; }
# the static check of the core's manifest and executables must be clean (no output, status 0)
chk=$(run jumpctl cores check systemd 2>&1); rc=$?
echo "cores check: rc=$rc ${chk:+output: $chk}"
[ $rc -eq 0 ] && [ -z "$chk" ] || { echo 'FAIL: jumpctl cores check systemd is not clean'; fail=1; }
run jumpctl cores status || true
# the boot transaction (unit.activate) must finish within a bound and reach the image's boot target
reached=
i=0
while [ $i -lt 60 ]; do
  if run jumpctl status systemd/multi-user.target 2>/dev/null | grep -q "reporting status as 'active'" &&
     run grep -q '\[core:systemd\] activation: done' /var/log/jumpstart.log; then reached=1; break; fi
  i=$((i+1)); sleep 2
done
[ -n "$reached" ] || { echo 'FAIL: multi-user.target not reached / boot report missing within 120 s'; fail=1; }
run jumpctl status systemd/multi-user.target || true
run grep -E 'systemd\] (request_id=[^ ]+ event=complete operation=unit.activate|activation:)' /var/log/jumpstart.log || true
# timers are real units now: none of the image's timers (or paths/swaps) may be among the boot failures
failed=$(run /usr/bin/systemctl --failed --no-legend --no-pager 2>/dev/null | grep -oE '[^ ]+\.(service|timer|path|swap|socket|mount|target|slice)( |$)' | tr -d ' ')
echo "failed units after boot: ${failed:-none}"
bad=$(printf '%s\n' "$failed" | grep -E '\.(timer|path|swap)$' || true)
[ -z "$bad" ] || { echo "FAIL: timer/path/swap units failed at boot: $bad"; fail=1; }
timers=$(run /usr/bin/systemctl list-units --type=timer --all --no-legend --no-pager 2>/dev/null | awk '{print $1, $3, $4}')
echo "timers: $timers"
case "$timers" in *"active waiting"*|*"active elapsed"*|*"active running"*) echo 'ok: timers are active' ;; *) echo 'FAIL: no active timer units'; fail=1 ;; esac
run jumpctl start systemd/hello.service || { echo 'FAIL: jumpctl start systemd/hello.service'; fail=1; }
st=$(run jumpctl status systemd/hello.service); echo "$st"
case "$st" in *"reporting status as 'active'"*) echo 'ok: jumpctl status hello.service active' ;; *) echo 'FAIL: jumpctl status hello.service'; fail=1 ;; esac
# the symlinked front-end must dispatch on its own name and report the unit as active
state=$(run /usr/bin/systemctl is-active hello.service) || true
echo "systemctl is-active: $state"
[ "$state" = active ] || { echo 'FAIL: systemctl is-active hello.service'; fail=1; }
run jumpctl stop systemd/hello.service || { echo 'FAIL: jumpctl stop systemd/hello.service'; fail=1; }
state=$(run /usr/bin/systemctl is-active hello.service) || true
echo "systemctl is-active after stop: $state"
[ "$state" = inactive ] || { echo 'FAIL: hello.service is not inactive after stop'; fail=1; }
docker logs $name 2>&1 | tail -15
[ -n "${KEEP:-}" ] || docker rm -f $name >/dev/null
[ $fail -eq 0 ] && echo 'integration: all checks passed' || echo 'integration: FAILED'
exit $fail
