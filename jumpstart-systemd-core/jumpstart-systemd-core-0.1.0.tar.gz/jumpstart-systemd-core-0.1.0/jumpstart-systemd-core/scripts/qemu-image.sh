#!/bin/sh
# Builds a UEFI-bootable arm64 disk image (GPT: ESP + EROFS root) in which
# Jumpstart is PID 1 with the systemd compatibility core enabled.
# Output: out/qemu/disk.img. Needs docker (arm64 host), the jumpstart-dev image
# (TEST_IMAGE) and the sibling Jumpstart checkout (JUMPSTART_SRC, default ../src-2).
# Pipeline follows src-2's krep/ISO.md and tests/krep/docker/container-build-uefi.sh.
set -eu
here=$(cd "$(dirname "$0")/.." && pwd)
src2=${JUMPSTART_SRC:-$here/../src-2}
img=${TEST_IMAGE:-jumpstart-dev:latest}
q=$here/out/qemu
if [ -n "${GNOME:-}" ]; then # separate variant: out/qemu-gnome (the default image is untouched)
  q=$here/out/qemu-gnome
  mkdir -p "$q/cache"
  for f in booster-bin booster-init erofsdrv; do # reuse the default variant's cached tools
    [ -e "$q/cache/$f" ] || { [ ! -e "$here/out/qemu/cache/$f" ] || cp "$here/out/qemu/cache/$f" "$q/cache/$f"; }
  done
fi
if [ -n "${KREATO:-}" ]; then # Kreato Linux userland (kpkg packages) instead of Debian: out/qemu-kreato
  q=$here/out/qemu-kreato
  mkdir -p "$q/cache"
  for f in erofsdrv; do
    [ -e "$q/cache/$f" ] || { [ ! -e "$here/out/qemu/cache/$f" ] || cp "$here/out/qemu/cache/$f" "$q/cache/$f"; }
  done
  # the kpkg userland rootfs (ext4) is made by scripts/kreato-rootfs.sh
  [ -f "$q/cache/kreato-root.img" ] || sh "$here/scripts/kreato-rootfs.sh"
fi
mkdir -p "$q"
start=$(date +%s)

# 1. Jumpstart binaries (jumpstart, jumpctl, kongue-runner, pam_jumpstart.so)
if [ ! -x "$here/out/jumpstart-linux/usr/bin/jumpstart" ] || [ -n "${REBUILD_JUMPSTART:-}" ]; then
  echo ">> building Jumpstart"; sh "$here/scripts/build-jumpstart.sh"
fi

# 2. the core: make install PREFIX=/usr into a staging tar, as jumpstart-integration.sh does
echo ">> installing the systemd core"
docker run --rm -e KREATO="${KREATO:-}" -v "$here":/ro/core:ro -v "$src2/libs":/ro/src-2/libs:ro "$img" sh -c '
  set -e
  mkdir -p /w/src-2 && cp -a /ro/src-2/libs /w/src-2/libs
  mkdir -p /w/core && (cd /ro/core && tar --exclude=.git --exclude=out --exclude=nimcache -cf - .) | tar -xf - -C /w/core
  cd /w/core && make install PREFIX=/usr DESTDIR=/stage ${KREATO:+SBINDIR=/usr/bin} ${NIMFLAGS:+NIMFLAGS="$NIMFLAGS"} >&2
  tar -C /stage -cf - .' > "$q/core-root.tar"

# 3. krep's static EROFS/GRUB driver (musl), from the Jumpstart checkout
if [ ! -x "$q/cache/erofsdrv" ] || [ -n "${REBUILD_DRIVER:-}" ]; then
  echo ">> building the krep image driver"
  mkdir -p "$q/cache"
  docker run --rm -v "$src2":/src:ro -v "$q/cache":/out nimlang/nim:2.2.4-alpine sh -c \
    'nim c -d:release --passL:-static --nimcache:/tmp/nc -o:/out/erofsdrv /src/tests/krep/linux_erofs_integration.nim >/dev/null'
fi

# 4. (KREATO=1) Kreato Linux rootfs from kpkg: only the image tooling comes from debian
if [ -n "${KREATO:-}" ]; then
  echo ">> building the Kreato Linux disk image"
  docker run --rm --privileged -v "$q":/out \
    -v "$here/out/jumpstart-linux":/in/jumpstart-linux:ro \
    -v "$q/core-root.tar":/in/core-root.tar:ro \
    -v "$q/cache/erofsdrv":/in/erofsdrv:ro \
    -v "$here/scripts/qemu-files":/in/units:ro -v "$here/scripts/qemu-files-kreato":/in/kreato:ro \
    -v "$here/scripts/qemu-image-kreato-inner.sh":/build.sh:ro ${KREATO_SSH_KEY:+-v "$KREATO_SSH_KEY":/in/ssh-key.pub:ro} \
    -e GNOME="${GNOME:-}" -e DEBUG_SHELL="${DEBUG_SHELL:-}" -e DIAG="${DIAG:-}" -e KDIAG_UNITS="${KDIAG_UNITS:-}" -e KDIAG_EXTRA="${KDIAG_EXTRA:-}" -e KREATO_SLIM="${KREATO_SLIM:-1}" -e CONSOLE="${CONSOLE:-}" -e KERNEL_ARGS="${KERNEL_ARGS:-}" \
    debian:trixie sh /build.sh | tee "$q/build.log" | tail -n 25
  [ -s "$q/disk.img" ] || { echo "no disk image produced, see $q/build.log" >&2; exit 1; }
  echo ">> done: $q/disk.img ($(du -h "$q/disk.img" | cut -f1) on disk) in $(( $(date +%s) - start )) s"
  echo "   boot it with: KREATO=1 [GNOME=1] scripts/qemu-boot.sh"
  exit 0
fi

# 4. rootfs + kernel + Booster + krep disk, in a debian:trixie arm64 container
echo ">> building the rootfs and the disk image (takes several minutes)"
docker run --rm --privileged -v "$q":/out \
  -v "$here/out/jumpstart-linux":/in/jumpstart-linux:ro \
  -v "$q/core-root.tar":/in/core-root.tar:ro \
  -v "$q/cache/erofsdrv":/in/erofsdrv:ro \
  -v "$here/scripts/qemu-files":/in/units:ro \
  -v "$here/scripts/qemu-image-inner.sh":/build.sh:ro \
  -e GNOME="${GNOME:-}" -e GNOME_PKGS="${GNOME_PKGS:-}" -v "$here/scripts/qemu-files-gnome":/in/gnome:ro -e DEBUG_SHELL="${DEBUG_SHELL:-}" -e CONSOLE="${CONSOLE:-}" -e KERNEL_ARGS="${KERNEL_ARGS:-}" \
  debian:trixie sh /build.sh | tee "$q/build.log" | tail -n 25
[ -s "$q/disk.img" ] || { echo "no disk image produced, see $q/build.log" >&2; exit 1; }
echo ">> done: $q/disk.img ($(du -h "$q/disk.img" | cut -f1) on disk) in $(( $(date +%s) - start )) s"
echo "   boot it with: scripts/qemu-boot.sh"
