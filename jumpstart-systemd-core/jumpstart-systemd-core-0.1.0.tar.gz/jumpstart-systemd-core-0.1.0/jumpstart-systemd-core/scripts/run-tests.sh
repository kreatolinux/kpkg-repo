#!/bin/sh
# Compile and run every tests/**/test_*.nim (or those matching $1, a substring).
# Prints a summary line; exits non-zero when any test file fails.
cd "$(dirname "$0")/.." || exit 1
pass=0; fail=0; failed=""
mkdir -p out; : > out/warnings.log
for t in $(find tests -name 'test_*.nim' | sort); do
  case "$t" in *"${1:-}"*) ;; *) continue ;; esac
  out=out/$(echo "$t" | tr '/' '_' | sed 's/\.nim$//')
  mkdir -p out
  nim c -d:release --threads:off -o:"$out" "$t" >out/build.log 2>&1; built=$?
  grep -h 'Warning' out/build.log >> out/warnings.log
  if [ $built -eq 0 ] && "$out" >"$out.log" 2>&1; then
    pass=$((pass+1))
  else
    fail=$((fail+1)); failed="$failed $t"
    tail -30 out/build.log "$out.log" 2>/dev/null
  fi
done
echo "test files: $pass passed, $fail failed$failed"
echo "compiler warnings: $(sort -u out/warnings.log | wc -l | tr -d ' ')"
[ "$fail" -eq 0 ]
