#!/bin/sh
# Runs INSIDE a privileged debian:trixie (arm64) container, started by qemu-image.sh KREATO=1.
# Mounts: /out (out/qemu-kreato, rw; cache/kreato-root.img is the Kreato Linux rootfs built by
# scripts/kreato-rootfs.sh), /in/jumpstart-linux (ro), /in/core-root.tar, /in/erofsdrv,
# /in/units (qemu-files), /in/kreato (qemu-files-kreato overlay).
# Debian only provides the image tooling (erofs/grub/gdisk); everything in the guest root is Kreato
# Linux, installed with kpkg. Jumpstart + the systemd core are added on top, as in qemu-image-inner.sh.
set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends ca-certificates curl git gcc libc6-dev make \
  kmod erofs-utils gdisk tar dosfstools mtools grub-efi-arm64-bin grub-common >/dev/null

C=/out/cache; mkdir -p $C
# the Kreato rootfs: a loop-mounted ext4 image, with a throwaway overlay on top
mkdir -p /lower /ovl /rootfs
mount -o loop $C/kreato-root.img /lower
mount -t tmpfs tmpfs /ovl; mkdir -p /ovl/u /ovl/w
mount -t overlay overlay -o lowerdir=/lower,upperdir=/ovl/u,workdir=/ovl/w /rootfs
R=/rootfs
# EROFS-size hygiene: package caches, the kpkg repository clone, man pages, logs of the build
rm -rf $R/var/cache/kpkg/archives $R/var/cache/kpkg/env $R/opt/kpkg $R/etc/kpkg/repos $R/root/.cache \
  $R/usr/share/man $R/usr/share/doc $R/usr/share/info $R/usr/share/locale $R/var/lib/kpkg/journal \
  $R/build*.log $R/build.times $R/inst.* $R/fixcache.* $R/bld.sh $R/miss.sh $R/rfix.sh $R/Dockerfile $R/hostwork 2>/dev/null || true
# The builder userland carries a toolchain and the kernel build tree; the QEMU test image does not need them
# (the krep driver needs room for a second copy). KREATO_SLIM=0 keeps everything.
if [ "${KREATO_SLIM:-1}" != 0 ]; then
  rm -rf $R/usr/lib/modules/*/build $R/usr/lib/modules/*/source $R/usr/include $R/usr/lib/gcc $R/usr/libexec/gcc \
    $R/usr/lib/llvm* $R/usr/lib/nim $R/usr/lib/vala* $R/usr/share/vala* $R/usr/share/cmake* $R/usr/share/gir-1.0 \
    $R/usr/aarch64-unknown-linux-gnu $R/var/lib/kpkg-aside $R/usr/lib/python3.14/test 2>/dev/null || true
  for f in nim nimble nim_dbg nimsuggest cmake ccmake cpack ctest lto-dump gcc g++ cpp c++ cc ld ld.bfd ld.gold gold as ar nm objdump ranlib strip readelf bison flex m4 vala valac; do
    rm -f $R/usr/bin/$f $R/usr/bin/aarch64-*-$f 2>/dev/null || true
  done
fi

[ -x $R/usr/bin/dbus-daemon ] || echo "!! no dbus in the rootfs (KREATO_PKGS)"
echo kreato-sdc > $R/etc/hostname
printf '127.0.0.1\tlocalhost\n127.0.1.1\tkreato-sdc\n' > $R/etc/hosts
mkdir -p $R/dev $R/proc $R/sys $R/run $R/tmp $R/etc/tmpfiles.d $R/etc/sysusers.d
rm -f $R/etc/machine-id; : > $R/etc/machine-id
# users: root/root and user/user (the greeter login). chroot needs /proc for some tools.
mount -t proc proc $R/proc
echo 'root:root' | chroot $R chpasswd
chroot $R sh -c 'grep -q "^user:" /etc/passwd || useradd -m -s /bin/bash user' || true
echo 'user:user' | chroot $R chpasswd
umount $R/proc
for g in audio video input render; do grep -q "^$g:" $R/etc/group && sed -i "/^$g:/ s/\$/,user/;s/:,user/:user/" $R/etc/group || true; done
grep -q '^messagebus:' $R/etc/passwd || {
  echo 'messagebus:x:18:' >> $R/etc/group
  echo 'messagebus:x:18:18:System Message Bus:/var/empty:/usr/bin/nologin' >> $R/etc/passwd
}

# groups the eudev rules and the desktop packages refer to; Kreato's shadow package ships only root and tty
for g in dialout kmem input video sgx audio lp disk cdrom tape floppy kvm render utmp wheel users; do
  chroot $R sh -c "grep -q '^$g:' /etc/group || groupadd $g" || true
done
chroot $R sh -c 'usermod -aG audio,video,input,render user' 2>/dev/null || true
# sshd: privilege separation user and an optional key for the test harness (KREATO_SSH_KEY=public key file)
grep -q '^sshd:' $R/etc/passwd || { echo 'sshd:x:74:74:sshd privsep:/var/empty:/usr/bin/nologin' >> $R/etc/passwd; echo 'sshd:x:74:' >> $R/etc/group; }
[ ! -f /in/ssh-key.pub ] || { cp /in/ssh-key.pub $R/etc/ssh/authorized_keys.root; chmod 644 $R/etc/ssh/authorized_keys.root; }

# Jumpstart (the development build replaces the one the kpkg 'jumpstart' package ships)
install -m 755 /in/jumpstart-linux/usr/bin/jumpstart $R/usr/bin/jumpstart
install -m 755 /in/jumpstart-linux/usr/bin/jumpctl $R/usr/bin/jumpctl
install -d -m 755 $R/usr/lib/jumpstart/cores $R/usr/lib/security
install -m 755 /in/jumpstart-linux/usr/lib/jumpstart/kongue-runner $R/usr/lib/jumpstart/kongue-runner
install -m 755 /in/jumpstart-linux/usr/lib/security/pam_jumpstart.so $R/usr/lib/security/pam_jumpstart.so
mkdir -p $R/usr/sbin; [ -e $R/sbin/init ] || ln -s ../bin/jumpstart $R/usr/bin/init 2>/dev/null || true

# systemd core
tar -xpf /in/core-root.tar -C $R
chown -R 0:0 $R/usr/lib/jumpstart
chmod -R go-w $R/usr/lib/jumpstart
chmod 755 $R/usr/lib/jumpstart/cores $R/usr/lib/jumpstart/cores/systemd

# serviceHandler runs only the /etc overlay mounts here. The stock Kreato getty units
# (busybox getty on tty1..6) would fight the systemd getty units for the ttys.
rm -f $R/etc/jumpstart/getty-tty*.service.kg $R/etc/jumpstart/enabled/getty-tty* 2>/dev/null || true
install -d -m 755 $R/etc/jumpstart/cores/enabled $R/etc/jumpstart/enabled
: > $R/etc/jumpstart/cores/enabled/serviceHandler
: > $R/etc/jumpstart/cores/enabled/systemd
printf '[System]\nmount_fstab = false\nhostname = kreato-sdc\n' > $R/etc/jumpstart/main.conf
cp /in/units/ovbase.kg /in/units/ovprep.kg /in/units/ov-etc.kg $R/etc/jumpstart/
ln -s ../ov-etc.kg $R/etc/jumpstart/enabled/ov-etc.kg

# unit files (Kreato packages ship none: gdm is built with systemdsystemunitdir=no, ...)
cp -a /in/kreato/. $R/
S=$R/etc/systemd/system
install -d $S/getty.target.wants $S/multi-user.target.wants $S/graphical.target.wants $S/sysinit.target.wants
# No systemd package here, so nothing enabled the core's own housekeeping units (the Debian image inherits those
# links from the systemd package): sysusers, tmpfiles (creates /var, /var/run -> /run, ...), user-sessions
CU=/usr/lib/jumpstart/cores/systemd/share/units
install -d $S/timers.target.wants
for u in systemd-sysusers.service systemd-tmpfiles-setup.service; do ln -sf $CU/$u $S/sysinit.target.wants/$u; done
ln -sf $CU/systemd-tmpfiles-clean.timer $S/timers.target.wants/systemd-tmpfiles-clean.timer
ln -sf $CU/systemd-user-sessions.service $S/multi-user.target.wants/systemd-user-sessions.service
ln -sf $CU/getty@.service $S/getty.target.wants/getty@tty1.service
install -d $R/etc/modules-load.d && printf 'virtio_net\nvirtio_gpu\n' > $R/etc/modules-load.d/qemu.conf
install -m 755 /in/units/qemu-net.sh $R/usr/local/sbin/qemu-net
install -m 644 /in/units/qemu-net.service $S/qemu-net.service
ln -sf /etc/systemd/system/qemu-net.service $S/multi-user.target.wants/qemu-net.service
ln -sf /etc/systemd/system/dbus.service $S/multi-user.target.wants/dbus.service
for u in systemd-udevd systemd-udev-trigger; do ln -sf /etc/systemd/system/$u.service $S/sysinit.target.wants/$u.service; done
[ ! -x $R/usr/libexec/elogind ] || ln -sf /etc/systemd/system/elogind.service $S/multi-user.target.wants/elogind.service
[ ! -x $R/usr/sbin/sshd -a ! -x $R/usr/bin/sshd ] || ln -sf /etc/systemd/system/sshd.service $S/multi-user.target.wants/sshd.service
for u in polkit accounts-daemon upower; do # dbus activation needs org.freedesktop.systemd1: start eagerly
  [ ! -f $S/$u.service ] || ln -sf /etc/systemd/system/$u.service $S/graphical.target.wants/$u.service
done
if [ -n "${GNOME:-}" ]; then
  ln -sf /etc/systemd/system/gdm.service $S/graphical.target.wants/gdm.service
  ln -sf /usr/lib/systemd/system/graphical.target $S/default.target
fi
# Kreato is merged-usr (/sbin -> usr/bin), but /usr/sbin is a separate directory: point the units at wherever the
# binary actually is (eudev's udevd, openssh's sshd, gdm, ... land in /usr/bin)
for f in $S/*.service; do
  for p in $(grep -o '/usr/sbin/[A-Za-z0-9_.-]*' $f | sort -u); do
    [ -x $R$p ] || { b=/usr/bin/${p##*/}; [ ! -x $R$b ] || sed -i "s|$p|$b|g" $f; }
  done
done
# dbus is configured with localstatedir=/usr/var, so libdbus/sd-bus clients look for the system bus socket in
# /usr/var/run/dbus/system_bus_socket: link that to /run
rm -rf $R/usr/var/run; mkdir -p $R/usr/var; ln -s /run $R/usr/var/run   # (the dbus package ships a real /usr/var/run/dbus)
# Linux-PAM is built with its helpers in /usr/sbin, but the kpkg package installs them into /usr/bin
# (/sbin is a link to /usr/bin here): without the links there is no login at all.
for h in unix_chkpwd unix_update pwhistory_helper mkhomedir_helper faillock; do
  [ ! -x $R/usr/bin/$h ] || [ -e $R/usr/sbin/$h ] || ln -s ../bin/$h $R/usr/sbin/$h
done
# pam_systemd.so is listed in system-session (the pam stack is shared with systemd distributions) but the elogind
# one is the module that exists here
[ ! -f $R/etc/pam.d/system-session ] || sed -i 's/pam_systemd.so/pam_elogind.so/' $R/etc/pam.d/system-session
# unit files for packages that are not in this rootfs would only fail: drop them
[ -x $R/usr/libexec/upowerd ] || rm -f $S/upower.service $S/graphical.target.wants/upower.service
[ -x $R/usr/libexec/accounts-daemon ] || rm -f $S/accounts-daemon.service $S/graphical.target.wants/accounts-daemon.service
[ -x $R/usr/lib/polkit-1/polkitd ] || rm -f $S/polkit.service $S/graphical.target.wants/polkit.service
[ -x $R/usr/sbin/gdm -o -x $R/usr/bin/gdm ] || rm -f $S/gdm.service $S/graphical.target.wants/gdm.service

if [ -n "${DEBUG_SHELL:-}" ]; then # a root shell on the serial port, started by native Jumpstart
  printf '#!/bin/sh\nexec setsid -c /bin/sh </dev/ttyAMA0 >/dev/ttyAMA0 2>&1\n' > $R/usr/local/sbin/dbgshell; chmod 755 $R/usr/local/sbin/dbgshell
  printf 'description: "debug shell"\ntype: "simple"\n\nservice {\n    exec "/usr/local/sbin/dbgshell"\n}\n' > $R/etc/jumpstart/dbgshell.kg
  ln -s ../dbgshell.kg $R/etc/jumpstart/enabled/dbgshell.kg
  ln -sf /dev/null $S/serial-getty@ttyAMA0.service   # the shell owns the serial port
fi
if [ -n "${DIAG:-}" ]; then # print the state of the system on the serial port a while after boot (no shell needed)
  cat > $R/usr/local/sbin/kdiag <<'DIAG'
#!/bin/sh
sleep ${DIAG_DELAY:-25}
exec > /dev/ttyAMA0 2>&1
KDIAG_UNITS=; KDIAG_JOURNAL=60; [ ! -f /etc/kdiag.env ] || . /etc/kdiag.env
echo "=== kdiag: failed units"; systemctl list-units --failed --no-pager
echo "=== kdiag: is-active"; systemctl is-active dbus.service elogind systemd-udevd sshd qemu-net polkit accounts-daemon upower gdm
echo "=== kdiag: ps"; ps
for u in $KDIAG_UNITS; do echo "=== kdiag: status $u"; systemctl status $u --no-pager -l; done
echo "=== kdiag: journal"; journalctl -b --no-pager | tail -${KDIAG_JOURNAL:-60}
[ ! -f /etc/kdiag.extra ] || sh /etc/kdiag.extra
echo "=== kdiag: end"
DIAG
  chmod 755 $R/usr/local/sbin/kdiag
  printf '[Unit]\nDescription=boot diagnostics\n\n[Service]\nType=simple\nExecStart=/usr/local/sbin/kdiag\n\n[Install]\nWantedBy=multi-user.target\n' > $S/kdiag.service
  ln -sf /etc/systemd/system/kdiag.service $S/multi-user.target.wants/kdiag.service
  printf 'KDIAG_UNITS="%s"\nKDIAG_JOURNAL=%s\n' "${KDIAG_UNITS:-}" "${KDIAG_JOURNAL:-60}" > $R/etc/kdiag.env
  printf '%s\n' "${KDIAG_EXTRA:-}" > $R/etc/kdiag.extra
fi

# kernel + modules + Booster: all from the kpkg 'linux' and 'booster' packages
KVER=$(ls $R/usr/lib/modules | head -1)
[ -f $R/usr/lib/modules/$KVER/modules.dep ] || depmod -b $R $KVER
[ -f $R/usr/lib/modules/$KVER/modules.dep ] || { echo '!! depmod produced no modules.dep'; ls $R/usr/lib/modules/$KVER | head; exit 1; }
[ -f $R/boot/vmlinuz-$KVER ] || { echo "!! no $R/boot/vmlinuz-$KVER (kpkg install linux)"; exit 1; }
[ -x $R/usr/bin/booster ] || { echo "!! no booster in the rootfs (kpkg install booster)"; exit 1; }
printf 'modules_force_load: overlay\n' > $R/etc/booster.yaml
# glibc keeps its runtime libraries (libresolv.so.2, ...) in /lib64, which ldconfig does not scan by default and
# the rootfs has no /etc/ld.so.conf; the booster generator resolves the init's libraries through the ld.so cache.
[ -f $R/etc/ld.so.conf ] || printf '/lib64\n/usr/lib64\n' > $R/etc/ld.so.conf
chroot $R /usr/bin/ldconfig
# ... and the booster generator itself only looks in /usr/lib, /lib and /usr/lib64 (generator/image.go elfLibDir)
# (Kreato's glibc package puts the runtime libraries in /lib64 and only the development links in /usr/lib64)
mkdir -p $R/usr/lib64
for f in $R/lib64/*; do b=${f##*/}; [ -e $R/usr/lib64/$b ] || [ -L $R/usr/lib64/$b ] || ln -s ../../lib64/$b $R/usr/lib64/$b; done

echo "--- rootfs: $(du -sx $R | cut -f1) KiB"
rm -rf /out/img; mkdir /out/img
KREP_BOOTLOADER=grub KREP_CONSOLE="${CONSOLE:-ttyAMA0,115200}" KREP_KERNEL_ARGS="${KERNEL_ARGS:-}" \
  /in/erofsdrv $R /out/img /usr/bin/jumpstart booster
mv /out/img/integration.img /out/disk.img
cp /out/img/integration.cmdline /out/disk.cmdline 2>/dev/null || true
rm -rf /out/img
sgdisk -p /out/disk.img
umount /rootfs /ovl /lower
