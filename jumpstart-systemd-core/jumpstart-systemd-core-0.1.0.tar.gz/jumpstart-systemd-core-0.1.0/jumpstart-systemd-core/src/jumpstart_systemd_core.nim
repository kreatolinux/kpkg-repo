## Constants shared by the binaries and the smoke test (spec §5.3).
import jumpstartcore/[protocol, registry]

const
  CoreName* = "systemd"
  CoreVersion* = "0.1.0"          ## `core_version` in init.kg
  SystemdVersion* = "255"         ## the systemd release whose semantics are the baseline
  ProtocolName* = CoreProtocol

proc registeredOperationCount*(): int =
  ## Operations in the registry for manifest_version 1: the manifest declares
  ## all of them; `unit.translate` is the only one marked unsupported.
  registry(CurrentManifestVersion).len
