## Injectable time and randomness, so timeouts and restart delays are testable.
import std/[monotimes, times, random]

type
  Clock* = ref object of RootObj
  FakeClock* = ref object of Clock
    mono*, real*: int64     ## microseconds, advanced by tests

method monoUsec*(c: Clock): int64 {.base.} =
  getMonoTime().ticks div 1000
method realUsec*(c: Clock): int64 {.base.} =
  let t = getTime()
  t.toUnix * 1_000_000 + (t.nanosecond div 1000)
method boottimeUsec*(c: Clock): int64 {.base.} = c.monoUsec()

method monoUsec*(c: FakeClock): int64 = c.mono
method realUsec*(c: FakeClock): int64 = c.real
proc advance*(c: FakeClock; usec: int64) =
  c.mono += usec
  c.real += usec

type
  Rng* = ref object of RootObj
    r: Rand

proc newRng*(seed = 0'i64): Rng =
  Rng(r: initRand(if seed == 0: getTime().toUnix * 1_000_003 + getMonoTime().ticks else: seed))
proc uniform*(g: Rng; lo, hi: int64): int64 =
  if hi <= lo: lo else: lo + g.r.rand(hi - lo)
proc bytes*(g: Rng; n: int): string =
  for _ in 0 ..< n: result.add char(g.r.rand(255))

proc newClock*(): Clock = Clock()
const UsecPerSec* = 1_000_000'i64
