## Unit names, escaping and cgroup components (systemd.unit(5), systemd.syntax;
## spec §6.6, §5.2). Pure.
import std/[options, strutils]
import ./sha1

type
  UnitKind* = enum
    ukService, ukSocket, ukTarget, ukDevice, ukMount, ukAutomount, ukSwap,
    ukTimer, ukPath, ukSlice, ukScope
  ParsedName* = object
    full*, prefix*, instance*, suffix*: string   ## suffix includes the dot
    kind*: UnitKind
    isTemplate*, isInstance*: bool

const
  KindSuffixes*: array[UnitKind, string] = [".service", ".socket", ".target",
    ".device", ".mount", ".automount", ".swap", ".timer", ".path", ".slice", ".scope"]
  MaxUnitNameLen* = 255
  ValidNameChars = {'a'..'z', 'A'..'Z', '0'..'9', ':', '_', '.', '\\', '-'}

proc kindOfSuffix*(suffix: string): Option[UnitKind] =
  for k in UnitKind:
    if KindSuffixes[k] == suffix: return some(k)

proc suffixOf*(name: string): string =
  let i = name.rfind('.')
  if i < 0: "" else: name[i .. ^1]

proc parseUnitName*(s: string): Option[ParsedName] =
  ## None when `s` is not a valid unit name. Templates (`a@.service`) and
  ## instances (`a@b.service`) are both valid.
  if s.len == 0 or s.len > MaxUnitNameLen: return
  let suffix = suffixOf(s)
  let kind = kindOfSuffix(suffix)
  if kind.isNone: return
  let stem = s[0 ..< s.len - suffix.len]
  if stem.len == 0: return
  var r = ParsedName(full: s, suffix: suffix, kind: kind.get)
  let at = stem.find('@')
  if at < 0:
    r.prefix = stem
  else:
    r.prefix = stem[0 ..< at]
    r.instance = stem[at + 1 .. ^1]
    if r.prefix.len == 0: return
    r.isTemplate = r.instance.len == 0
    r.isInstance = not r.isTemplate
  for c in r.prefix:
    if c notin ValidNameChars: return
  for c in r.instance:
    if c notin ValidNameChars and c != '@': return
  some(r)

proc isValidUnitName*(s: string): bool = parseUnitName(s).isSome

proc escape*(s: string): string =
  ## systemd-escape without --path: `/` becomes `-`, other unsafe bytes `\xNN`.
  for i, c in s:
    if c == '/': result.add '-'
    elif c in {'a'..'z', 'A'..'Z', '0'..'9', ':', '_'} or (c == '.' and i > 0):
      result.add c
    else:
      result.add "\\x" & toHex(ord(c), 2).toLowerAscii

proc unescape*(s: string): Option[string] =
  var i = 0
  var r = ""
  while i < s.len:
    let c = s[i]
    if c == '-': r.add '/'
    elif c == '\\':
      if i + 3 > s.high or s[i + 1] != 'x': return
      try: r.add char(parseHexInt(s[i + 2 .. i + 3]))
      except ValueError: return
      i += 3
    else: r.add c
    inc i
  some(r)

proc normalizePath*(p: string): string =
  ## Collapses duplicate and trailing slashes; "" stays "".
  if p.len == 0: return ""
  var prev = '\0'
  for c in p:
    if c == '/' and prev == '/': continue
    result.add c
    prev = c
  if result.len > 1 and result.endsWith("/"): result.setLen(result.len - 1)

proc escapePath*(p: string): string =
  let n = normalizePath(p)
  if n == "/": return "-"
  escape(n.strip(chars = {'/'}, trailing = true, leading = true))

proc unescapePath*(s: string): Option[string] =
  if s == "-": return some("/")
  let u = unescape(s)
  if u.isNone: return
  some("/" & u.get)

proc instantiate*(templ, instance: string): string =
  ## "a@.service" + "b" -> "a@b.service"
  let p = parseUnitName(templ)
  if p.isNone or not p.get.isTemplate: return templ
  p.get.prefix & "@" & instance & p.get.suffix

proc templateOf*(unit: string): string =
  let p = parseUnitName(unit)
  if p.isNone or not p.get.isInstance: return unit
  p.get.prefix & "@" & p.get.suffix

proc mangle*(s: string; fallbackKind = ukService): string =
  ## unit_name_mangle(): turn a user-typed name into a unit name. Paths become
  ## `.mount` units (or `.device` below /dev); names without a known suffix get
  ## the fallback suffix.
  if s.len == 0: return s
  if s.startsWith("/"):
    let n = normalizePath(s)
    let kind = if n == "/dev" or n.startsWith("/dev/"): ukDevice else: ukMount
    return escapePath(n) & KindSuffixes[kind]
  if kindOfSuffix(suffixOf(s)).isSome: return s
  s & KindSuffixes[fallbackKind]

proc cgroupComponent*(unit: string): string =
  ## §5.2 rule 1: injective, always ends in `.unit`.
  for c in unit:
    case c
    of '%': result.add "%25"
    of '\\': result.add "%5c"
    else: result.add c
  result.add ".unit"
  if result.len > 255: result = "~" & sha1hex(unit) & ".unit"

proc unitOfCgroupComponent*(c: string): Option[string] =
  ## Inverse of `cgroupComponent` (none for hashed names).
  if not c.endsWith(".unit") or c.startsWith("~"): return
  let stem = c[0 ..< c.len - 5]
  var i = 0
  var r = ""
  while i < stem.len:
    if stem[i] == '%':
      if stem[i .. min(i + 2, stem.high)] == "%25": r.add '%'
      elif stem[i .. min(i + 2, stem.high)] == "%5c": r.add '\\'
      else: return
      i += 3
    else:
      r.add stem[i]; inc i
  some(r)

proc sliceParents*(slice: string): seq[string] =
  ## "a-b-c.slice" -> ["a.slice", "a-b.slice"] (outermost first); "-.slice" -> [].
  if slice == "-.slice" or not slice.endsWith(".slice"): return
  let stem = slice[0 ..< slice.len - 6]
  var acc = ""
  for part in stem.split('-')[0 ..^ 2]:
    acc = if acc.len == 0: part else: acc & "-" & part
    result.add acc & ".slice"
