## Every path and system file the core touches, injectable for tests (§18.2.1).
import std/[os, strutils, posix]

type
  Scope* = enum scSystem, scUser
  Limits* = object
    deactivateBudgetMs*: int      ## 80_000 system, 15_000 user
    softDeadlineMarginMs*: int    ## 2_000
    notifyPerSecond*: int         ## 100
  Roots* = object
    scope*: Scope
    uid*: Uid
    coreRoot*, rt*, st*, sysrun*: string
    unitsCgroup*, controlCgroup*: string
    home*, runtime*: string
    etc*, run*, varLib*, varCache*, varLog*, usrLib*, usrShare*: string
    procfs*, sysfs*, devfs*, cgroupMount*: string
    cmdline*, mountinfo*, swaps*, osRelease*, machineId*, fstab*: string
    jumpstartSocket*: string
    limits*: Limits

proc defaultLimits*(scope: Scope): Limits =
  Limits(deactivateBudgetMs: if scope == scSystem: 80_000 else: 15_000,
         softDeadlineMarginMs: 2_000, notifyPerSecond: 100)

proc systemRoots*(): Roots =
  Roots(scope: scSystem, uid: 0, sysrun: "/run/systemd", etc: "/etc", run: "/run",
    varLib: "/var/lib", varCache: "/var/cache", varLog: "/var/log", usrLib: "/usr/lib",
    usrShare: "/usr/share", procfs: "/proc", sysfs: "/sys", devfs: "/dev",
    cgroupMount: "/sys/fs/cgroup", cmdline: "/proc/cmdline",
    mountinfo: "/proc/self/mountinfo", swaps: "/proc/swaps",
    osRelease: "/etc/os-release", machineId: "/etc/machine-id", fstab: "/etc/fstab",
    jumpstartSocket: "/run/jumpstart.sock", limits: defaultLimits(scSystem))

proc selfCgroupDir(procfs, mount: string): string =
  ## Absolute directory of this process's cgroup (cgroup v2 line `0::/path`).
  try:
    for line in readFile(procfs / "self/cgroup").splitLines:
      if line.startsWith("0::"): return mount & line[3 .. ^1]
  except IOError: discard

proc rootsFromEnvironment*(): Roots =
  ## Reads the JUMPSTART_* variables of cores §16.2. The manager runs in the
  ## core's `control/` cgroup; `units/` is its sibling (cores §15.1).
  result = systemRoots()
  result.coreRoot = getEnv("JUMPSTART_CORE_ROOT")
  result.rt = getEnv("JUMPSTART_CORE_RUNTIME_DIR")
  result.st = getEnv("JUMPSTART_CORE_STATE_DIR")
  result.uid = geteuid()
  if getEnv("JUMPSTART_MODE") == "user":
    result.scope = scUser
    result.home = getHomeDir().strip(chars = {'/'}, leading = false)
    result.runtime = getEnv("XDG_RUNTIME_DIR", "/run/user/" & $result.uid)
    result.sysrun = result.runtime / "systemd"
    result.etc = result.home / ".config"
    result.varLib = result.home / ".local/state"
    result.varCache = result.home / ".cache"
    result.varLog = result.home / ".local/state"
    result.limits = defaultLimits(scUser)
  let control = selfCgroupDir(result.procfs, result.cgroupMount)
  if control.endsWith("/control"):
    result.controlCgroup = control
    result.unitsCgroup = control.parentDir / "units"
  else:
    result.controlCgroup = control

proc testRoots*(base: string; scope: Scope): Roots =
  ## Every path below `base` (a temporary directory the test owns).
  result = systemRoots()
  result.scope = scope
  result.uid = geteuid()
  result.coreRoot = base / "core"
  result.rt = base / "rt"
  result.st = base / "st"
  result.sysrun = base / "run/systemd"
  result.etc = base / "etc"
  result.run = base / "run"
  result.varLib = base / "var/lib"
  result.varCache = base / "var/cache"
  result.varLog = base / "var/log"
  result.usrLib = base / "usr/lib"
  result.usrShare = base / "usr/share"
  result.procfs = base / "proc"
  result.sysfs = base / "sys"
  result.devfs = base / "dev"
  result.cgroupMount = base / "cgroup"
  result.cmdline = base / "proc/cmdline"
  result.mountinfo = base / "proc/self/mountinfo"
  result.swaps = base / "proc/swaps"
  result.osRelease = base / "etc/os-release"
  result.machineId = base / "etc/machine-id"
  result.fstab = base / "etc/fstab"
  result.jumpstartSocket = base / "run/jumpstart.sock"
  result.limits = defaultLimits(scope)
  for d in [result.coreRoot, result.rt, result.st, result.sysrun, result.etc,
            result.run, result.varLib, result.usrLib, base / "proc"]:
    createDir(d)
