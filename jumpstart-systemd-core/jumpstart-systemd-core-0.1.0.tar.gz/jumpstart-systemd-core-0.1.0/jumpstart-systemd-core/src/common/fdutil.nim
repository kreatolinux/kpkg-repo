## Small descriptor and Unix-socket helpers shared by the manager, the
## control protocol and the tools. `cint` descriptors throughout.
import std/[posix]

proc nodeExists*(path: string): bool =
  ## stat(2) succeeds: any file type counts. std/os.fileExists is true for
  ## regular files only, which is false for the device nodes under /dev.
  var st: Stat
  path.len > 0 and stat(path.cstring, st) == 0

proc setNonBlocking*(fd: cint) =
  let fl = fcntl(fd, F_GETFL)
  discard fcntl(fd, F_SETFL, fl or O_NONBLOCK)

proc setCloexec*(fd: cint) =
  discard fcntl(fd, F_SETFD, fcntl(fd, F_GETFD) or FD_CLOEXEC)

proc unixAddr(path: string; a: var Sockaddr_un): SockLen =
  a = Sockaddr_un()
  a.sun_family = TSa_Family(AF_UNIX)
  if path.len == 0 or path.len >= a.sun_path.len:
    raise newException(ValueError, "socket path too long or empty: " & path)
  copyMem(addr a.sun_path[0], path.cstring, path.len)
  SockLen(sizeof(a))

proc newUnixSocket*(stream: bool): cint =
  let fd = cint(socket(AF_UNIX, if stream: SOCK_STREAM else: SOCK_DGRAM, 0))
  if fd >= 0: setCloexec(fd)
  fd

proc connectUnix*(path: string; stream = true): cint =
  ## -1 on failure.
  let fd = newUnixSocket(stream)
  if fd < 0: return -1
  var a: Sockaddr_un
  try:
    let n = unixAddr(path, a)
    if connect(SocketHandle(fd), cast[ptr SockAddr](addr a), n) != 0:
      discard close(fd)
      return -1
  except ValueError:
    discard close(fd)
    return -1
  fd

proc bindUnix*(path: string; stream: bool; mode: Mode; backlog = 128): cint =
  ## Removes a stale socket file, binds, chmods, and (for streams) listens.
  ## Non-blocking and close-on-exec. -1 on failure (errno set).
  let fd = newUnixSocket(stream)
  if fd < 0: return -1
  var a: Sockaddr_un
  let n = unixAddr(path, a)
  discard unlink(path.cstring)
  if bindSocket(SocketHandle(fd), cast[ptr SockAddr](addr a), n) != 0:
    let e = errno
    discard close(fd)
    errno = e
    return -1
  discard chmod(path.cstring, mode)
  if stream and listen(SocketHandle(fd), cint(backlog)) != 0:
    let e = errno
    discard close(fd)
    errno = e
    return -1
  setNonBlocking(fd)
  fd

proc writeAll*(fd: cint; data: string): bool =
  var off = 0
  while off < data.len:
    let n = write(fd, unsafeAddr data[off], data.len - off)
    if n > 0: off += n
    elif n < 0 and errno == EINTR: discard
    else: return false
  true

proc readAvailable*(fd: cint; maxBytes = 65536): tuple[data: string, eof: bool] =
  ## One read of whatever is available (non-blocking descriptors).
  var buf = newString(maxBytes)
  let n = read(fd, addr buf[0], buf.len)
  if n > 0: result.data = buf[0 ..< n]
  elif n == 0: result.eof = true
  elif errno notin [EAGAIN, EWOULDBLOCK, EINTR]: result.eof = true
