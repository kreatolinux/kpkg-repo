## JSON helpers shared by the control protocol, the adapter and the executor.
import std/[json]

proc getStr*(n: JsonNode; key: string; default = ""): string =
  if n != nil and n.kind == JObject and n.hasKey(key) and n[key].kind == JString: n[key].str
  else: default
proc getBool*(n: JsonNode; key: string; default = false): bool =
  if n != nil and n.kind == JObject and n.hasKey(key) and n[key].kind == JBool: n[key].bval
  else: default
proc getInt*(n: JsonNode; key: string; default = 0): int =
  if n != nil and n.kind == JObject and n.hasKey(key) and n[key].kind == JInt: n[key].getInt
  else: default
proc getStrs*(n: JsonNode; key: string): seq[string] =
  if n != nil and n.kind == JObject and n.hasKey(key) and n[key].kind == JArray:
    for e in n[key]:
      if e.kind == JString: result.add e.str
proc has*(n: JsonNode; key: string): bool = n != nil and n.kind == JObject and n.hasKey(key)

proc strVal*(n: JsonNode): string = (if n != nil and n.kind == JString: n.str else: "")
proc intVal*(n: JsonNode): int = (if n != nil and n.kind == JInt: int(n.num) else: 0)
proc boolVal*(n: JsonNode): bool = (if n != nil and n.kind == JBool: n.bval else: false)
