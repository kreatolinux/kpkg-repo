## SHA-1 (RFC 3174), only for cgroup component names that are too long (§5.2).
import std/strutils

proc rol(x: uint32; n: int): uint32 = (x shl n) or (x shr (32 - n))

proc sha1hex*(data: string): string =
  var h = [0x67452301'u32, 0xEFCDAB89'u32, 0x98BADCFE'u32, 0x10325476'u32, 0xC3D2E1F0'u32]
  var msg = data
  let bitLen = uint64(data.len) * 8
  msg.add '\x80'
  while msg.len mod 64 != 56: msg.add '\0'
  for i in countdown(7, 0): msg.add char((bitLen shr (i * 8)) and 0xff)
  for chunk in countup(0, msg.len - 1, 64):
    var w: array[80, uint32]
    for i in 0 ..< 16:
      for j in 0 ..< 4: w[i] = (w[i] shl 8) or uint32(ord(msg[chunk + i * 4 + j]))
    for i in 16 ..< 80: w[i] = rol(w[i-3] xor w[i-8] xor w[i-14] xor w[i-16], 1)
    var (a, b, c, d, e) = (h[0], h[1], h[2], h[3], h[4])
    for i in 0 ..< 80:
      var f, k: uint32
      if i < 20: f = (b and c) or ((not b) and d); k = 0x5A827999'u32
      elif i < 40: f = b xor c xor d; k = 0x6ED9EBA1'u32
      elif i < 60: f = (b and c) or (b and d) or (c and d); k = 0x8F1BBCDC'u32
      else: f = b xor c xor d; k = 0xCA62C1D6'u32
      let t = rol(a, 5) + f + e + k + w[i]
      e = d; d = c; c = rol(b, 30); b = a; a = t
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e
  for v in h: result.add toHex(int64(v), 8).toLowerAscii
