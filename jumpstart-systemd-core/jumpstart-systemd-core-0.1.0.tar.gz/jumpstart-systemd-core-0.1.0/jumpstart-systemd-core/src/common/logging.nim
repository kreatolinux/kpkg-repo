## Minimal logging to standard error; the manager's stderr is collected by Jumpstart.
## A journal sink may be installed once the journal client exists.
type LogSink* = proc(level: int; unit, msg: string) {.closure.}
var sink*: LogSink

proc emit(level: int; tag, unit, msg: string) =
  if sink != nil:
    try: sink(level, unit, msg)
    except CatchableError: discard
  try:
    stderr.writeLine("systemd-compat: " & tag & (if unit.len > 0: " " & unit & ":" else: ":") & " " & msg)
  except IOError: discard

proc logInfo*(unit, msg: string) = emit(6, "info", unit, msg)
proc logWarn*(unit, msg: string) = emit(4, "warning", unit, msg)
proc logErr*(unit, msg: string) = emit(3, "error", unit, msg)
