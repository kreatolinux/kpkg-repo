## `Result[T]`: a value or a diagnostic, for code that reports problems as data.
type
  Result*[T] = object
    ok*: bool
    value*: T
    error*: string

proc ok*[T](value: T): Result[T] = Result[T](ok: true, value: value)
proc err*[T](message: string): Result[T] = Result[T](ok: false, error: message)
proc isOk*[T](r: Result[T]): bool = r.ok
proc get*[T](r: Result[T]): T =
  if not r.ok: raise newException(ValueError, r.error)
  r.value
proc getOr*[T](r: Result[T]; default: T): T = (if r.ok: r.value else: default)
