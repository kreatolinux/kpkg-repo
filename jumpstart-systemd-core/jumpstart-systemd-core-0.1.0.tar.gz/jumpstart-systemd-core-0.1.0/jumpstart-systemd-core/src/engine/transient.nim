## Transient units (`systemd-run`, spec §15.6): unit files written into the
## transient directory, loaded by the normal search path, started, optionally
## waited for, and garbage collected when they stop. No engine file is edited:
## everything works through `daemonReload`, `submitJob` and subscriptions.
import std/[os, tables, sets, sequtils, options]
import jumpstartcore/errors
import ../common/[names, roots]
import ../unitfile/model
import ./[types, graph, jobs, manager, api, eventloop]

type
  TransientUnit* = object
    name*, text*: string
  TransientResult* = object
    ok*: bool
    code*: CoreErrorCode
    message*: string
    name*, result*: string
    job*, execStatus*, execCode*: int
    runtimeUsec*: int64
  TransientDone* = proc(r: TransientResult) {.closure.}

var
  gcSet: HashSet[string]                      ## transient units collected when inactive
  collectFailed: HashSet[string]              ## ... and also when failed (CollectMode=inactive-or-failed)
  blockedBy: Table[string, string]            ## service of a timer pair -> its timer
  companions: Table[string, seq[string]]      ## timer -> its services
  gcInstalled: bool

proc transientDir(m: Manager): string = m.roots.sysrun / "transient"

proc removeTransient(m: Manager; names: seq[string]) =
  var any = false
  for n in names:
    let p = transientDir(m) / n
    let u = m.units.getOrDefault(n)
    if u != nil and u.active notin {asInactive, asFailed}: continue
    if u != nil and u.job != nil: continue
    if fileExists(p):
      try: removeFile(p) except OSError: continue
      any = true
    gcSet.excl n
    collectFailed.excl n
    for svc in companions.getOrDefault(n):
      blockedBy.del svc
    companions.del n
    if u != nil and u.active == asFailed and u.ops.resetFailed != nil: u.ops.resetFailed(m, u)
  if any: discard m.daemonReload()

proc installGc(m: Manager) =
  if gcInstalled: return
  gcInstalled = true
  m.subscribers.add Subscription(id: 0, patterns: @[], cb: proc(ev: StateEvent) =
    if ev.unit notin gcSet: return
    let dead = (ev.active == asInactive and ev.sub == "dead") or
               (ev.active == asFailed and ev.unit in collectFailed)
    if not dead: return
    if blockedBy.hasKey(ev.unit) and gcSet.contains(blockedBy[ev.unit]): return
    let name = ev.unit
    m.loop.afterEvent(proc() =
      removeTransient(m, @[name])
      # the services of a timer that has gone are now free to go
      for n in toSeq(blockedBy.keys):
        if not gcSet.contains(blockedBy[n]):
          blockedBy.del n
          let u = m.units.getOrDefault(n)
          if u != nil and u.active in {asInactive}: removeTransient(m, @[n])))

proc fail(code: CoreErrorCode; msg: string): TransientResult =
  TransientResult(ok: false, code: code, message: msg)

proc startTransient*(m: Manager; units: seq[TransientUnit]; start: string; collect, waitStart, waitExit: bool;
                     done: TransientDone) =
  ## Raises CoreError for immediate failures; `done` is called exactly once
  ## otherwise (possibly later). `start` names the unit to start ("" = only create).
  let dir = transientDir(m)
  if units.len == 0: raise newCoreError(ecUsage, "No transient unit given.")
  for t in units:
    if parseUnitName(t.name).isNone: raise newCoreError(ecName, "Invalid unit name " & t.name)
    let known = m.lookup(t.name)
    if fileExists(dir / t.name) or (known != nil and known.def.common.loadState != lsNotFound):
      raise newCoreError(ecState, "Unit " & t.name & " already exists.")
  createDir(dir)
  var created: seq[string]
  for t in units:
    writeFile(dir / t.name, t.text)
    created.add t.name
  discard m.daemonReload()
  for t in units:
    let u = m.lookup(t.name)
    if u == nil or u.def.common.loadState != lsLoaded:
      for n in created: removeFile(dir / n)
      discard m.daemonReload()
      raise newCoreError(ecUnitState, "Transient unit " & t.name & " failed to load.")
  installGc(m)
  for t in units:
    gcSet.incl t.name
    if collect: collectFailed.incl t.name
    let pn = parseUnitName(t.name)
    if pn.isSome and pn.get.kind == ukTimer:
      for o in units:
        if o.name != t.name and parseUnitName(o.name).get.kind == ukService:
          blockedBy[o.name] = t.name
          companions.mgetOrPut(t.name, @[]).add o.name
  if start.len == 0:
    done(TransientResult(ok: true, name: units[0].name))
    return
  let u = m.lookup(start)
  var answered = false
  var started = false
  var subscription: Subscription
  var jobId = 0
  proc finish(r: TransientResult) =
    if answered: return
    answered = true
    if subscription != nil: m.subscribers.keepItIf(it != subscription)
    done(r)
  proc exitResult(): TransientResult =
    result = TransientResult(ok: true, name: start, job: jobId, result: u.result)
    if u.ops.status != nil:
      let ex = u.ops.status(m, u)
      result.execStatus = ex.execMainStatus
      result.execCode = ex.execMainCode
    if u.activeEnter.monoUsec > 0 and u.inactiveEnter.monoUsec >= u.activeEnter.monoUsec:
      result.runtimeUsec = u.inactiveEnter.monoUsec - u.activeEnter.monoUsec
  if waitExit:
    subscription = Subscription(id: 0, patterns: @[start], cb: proc(ev: StateEvent) =
      if ev.active in {asActivating, asActive}: started = true
      elif started and ev.active in {asInactive, asFailed}: finish(exitResult()))
    m.subscribers.add subscription
  let job = try:
      submitJob(m, u, jtStart, jmReplace, joManual, proc(o: JobOutcome) =
        jobId = o.job
        case o.result
        of jrDone:
          started = true
          if waitExit:
            if u.active in {asInactive, asFailed}: finish(exitResult())
          elif waitStart: finish(TransientResult(ok: true, name: start, job: o.job, result: "done"))
        of jrSkipped:
          finish(TransientResult(ok: true, name: start, job: o.job, result: "skipped"))
        else:
          let (code, msg) = jobFailure(o)
          finish(fail(code, if msg.len > 0: msg else: "Job for " & start & " failed.")))
    except CoreError as e:
      if subscription != nil: m.subscribers.keepItIf(it != subscription)
      raise e
  if job != nil: jobId = job.id
  if not waitStart and not waitExit: finish(TransientResult(ok: true, name: start, job: jobId, result: "running"))
