## Unit state changes and their consequences (spec §7.6 to §7.8): job
## progress, `OnFailure=`/`OnSuccess=`, actions, `BindsTo=`, `StopWhenUnneeded=`,
## `Upholds=`, subscriptions and the Jumpstart dirty set. Type modules call
## `setState`; nothing else changes `Unit.active`.
import std/[tables, sets, posix, sequtils]
import jumpstartcore/errors
import ../common/[logging, clock]
import ../unitfile/model
import ./[types, graph, jobs, eventloop, gc]

proc requestPower*(m: Manager; action: PowerAction): bool =
  if m.powerHook == nil: return false
  m.powerHook(action)

proc runAction*(m: Manager; u: Unit; action: UnitAction; flavor: ActionFlavor; why: string) =
  ## `SuccessAction=` and friends (§8.7): the first action wins, once.
  if action == uaNone or m.actionTaken or m.stopping: return
  if flavor != afPlain:
    logWarn(u.id, "-force and -immediate variants use Jumpstart's orderly sequence")
  m.actionTaken = true
  logInfo(u.id, why & ": executing " & $action)
  let power = case action
    of uaReboot, uaKexec: paReboot
    of uaPoweroff: paPoweroff
    of uaHalt: paHalt
    else: paExit
  if not m.requestPower(power): logWarn(u.id, "power request was not accepted")

proc submitDependency(m: Manager; name: string; typ: JobType; mode: JobMode) =
  let target = m.lookup(name)
  if target == nil: return
  try: discard submitJob(m, target, typ, mode, joDependency)
  except CoreError as e: logWarn(name, "dependency job not queued: " & e.msg)

proc isNeeded(m: Manager; u: Unit): bool =
  if u.job != nil: return true
  for rid in m.reverseUnits(u, [dkRequires, dkRequisite, dkWants, dkBindsTo, dkUpholds]):
    let r = m.units.getOrDefault(rid)
    if r == nil: continue
    if r.active in {asActive, asActivating, asReloading}: return true
    if r.job != nil and r.job.typ.isStartLike: return true
  false

proc checkUnneeded(m: Manager; u: Unit) =
  if u.def.common.stopWhenUnneeded and u.active in {asActive, asReloading} and not m.isNeeded(u):
    logInfo(u.id, "Unneeded: stopping")
    try: discard submitJob(m, u, jtStop, jmReplace, joDependency)
    except CoreError as e: logWarn(u.id, e.msg)

proc checkUpholds(m: Manager; u: Unit) =
  ## For each active unit that upholds X: keep X started.
  var holders: seq[Unit]
  if u.active == asActive and u.def.common.deps[dkUpholds].len > 0: holders.add u
  for rid in m.reverseDeps(u.id, dkUpholds):
    let r = m.units.getOrDefault(rid)
    if r != nil and r.active == asActive: holders.add r
  for h in holders:
    for x in m.depUnits(h, [dkUpholds]):
      let t = m.units.getOrDefault(x)
      if t != nil and t.active in {asInactive, asFailed} and t.job == nil and t.loadOk:
        m.submitDependency(x, jtStart, jmReplace)

proc monitorFor(u: Unit; m: Manager; exitCode, exitStatus: string): seq[(string, string)] =
  @[("MONITOR_SERVICE_RESULT", u.result), ("MONITOR_EXIT_CODE", exitCode),
    ("MONITOR_EXIT_STATUS", exitStatus), ("MONITOR_UNIT", u.id)]

proc triggerHandlers(m: Manager; u: Unit; kinds: DepKind; mode: JobMode) =
  for name in m.depUnits(u, [kinds]):
    let target = m.lookup(name)
    if target == nil: continue
    if u.kind == ukService and target.kind == ukService:
      var st = StatusExtras(exitCode: -1)
      if u.ops.status != nil: st = u.ops.status(m, u)
      m.monitor[target.id] = monitorFor(u, m, if st.exitCode >= 0: "exited" else: "",
        if st.exitCode >= 0: $st.exitCode else: "")
    m.submitDependency(name, jtStart, mode)

proc progressJob(m: Manager; u: Unit) =
  let j = u.job
  if j == nil: return
  case j.typ
  of jtStart:
    if j.state != jsRunning: return
    case u.active
    of asActive: m.finishJob(j, jrDone)
    of asFailed:
      m.finishJob(j, jrFailed, "", (if u.result == "start-limit-hit": "E_UNIT_STATE" else: ""))
    of asInactive:
      if u.failedCondition.len > 0: m.finishJob(j, jrSkipped)
      elif u.result == "success": m.finishJob(j, jrDone)
      else: m.finishJob(j, jrFailed)
    else: discard
  of jtStop:
    if j.state == jsRunning and u.active in {asInactive, asFailed}: m.finishJob(j, jrDone)
  of jtRestart:
    if j.restartStopPhase:
      if u.active in {asInactive, asFailed}:
        j.typ = jtStart
        j.restartStopPhase = false
        j.state = jsWaiting
    elif j.state == jsRunning:
      case u.active
      of asActive: m.finishJob(j, jrDone)
      of asFailed: m.finishJob(j, jrFailed)
      else: discard
  of jtReload:
    if j.state != jsRunning: return
    case u.active
    of asActive:
      if u.reloadResult in ["", "success"]: m.finishJob(j, jrDone)
      else:
        m.finishJob(j, jrFailed, "Job for " & u.id & " failed: reload " & u.reloadResult)
    of asInactive, asFailed: m.finishJob(j, jrFailed)
    else: discard
  else: discard

proc globMatches(patterns: seq[string]; name: string): bool =
  if patterns.len == 0: return true
  for p in patterns:
    if fnmatch(p.cstring, name.cstring, 0) == 0: return true

proc setState*(m: Manager; u: Unit; active: ActiveState; sub: string; result = "") =
  ## The one place a unit's state changes. `result` (when non-empty) becomes
  ## the unit result; a start sets "success" before calling.
  let old = u.active
  let oldSub = u.sub
  if old == active and oldSub == sub and (result.len == 0 or result == u.result): return
  if result.len > 0: u.result = result
  u.active = active
  u.sub = sub
  let now = Stamp(realUsec: m.clock.realUsec, monoUsec: m.clock.monoUsec)
  u.since = now.realUsec
  if old != active:
    if active == asActive: u.activeEnter = now
    if old in {asActive, asReloading}: u.activeExit = now
    if active in {asInactive, asFailed}: u.inactiveEnter = now
    if old in {asInactive, asFailed}: u.inactiveExit = now
  m.dirty.incl u.id
  for s in toSeq(m.subscribers):
    if globMatches(s.patterns, u.id):
      s.cb(StateEvent(unit: u.id, active: active, sub: sub, result: u.result))
  if old != active or oldSub != sub: logInfo(u.id, $old & " -> " & $active & " (" & sub & ")")
  progressJob(m, u)
  let c = u.def.common
  if old != active:
    if active == asFailed:
      m.triggerHandlers(u, dkOnFailure, c.onFailureJobMode)
      m.runAction(u, c.failureAction, c.failureActionFlavor, u.id & " failed")
    elif active == asInactive and u.result == "success" and sub == "dead" and
        old in {asActive, asReloading, asDeactivating, asActivating}:
      m.triggerHandlers(u, dkOnSuccess, c.onSuccessJobMode)
      m.runAction(u, c.successAction, c.successActionFlavor, u.id & " succeeded")
    if active in {asInactive, asFailed}:
      for bid in m.boundBy(u):
        let b = m.units.getOrDefault(bid)
        if b != nil and b.active in {asActive, asActivating, asReloading}:
          m.submitDependency(bid, jtStop, jmReplace)
    m.loop.afterEvent(proc() =
      m.checkUnneeded(u)
      m.checkUpholds(u)
      for rid in m.reverseUnits(u, [dkRequires, dkRequisite, dkWants, dkBindsTo, dkUpholds]):
        let r = m.units.getOrDefault(rid)
        if r != nil: m.checkUnneeded(r)
      for x in m.depUnits(u, [dkRequires, dkRequisite, dkWants, dkBindsTo, dkUpholds]):
        let t = m.units.getOrDefault(x)
        if t != nil: m.checkUnneeded(t))
  m.loop.afterEvent(proc() = m.runScheduler())
  if active in {asInactive, asFailed}: m.scheduleGc()

proc failUnit*(m: Manager; u: Unit; result: string) =
  ## Used for `start-limit-hit`: lets the unit type keep its own state in sync.
  if u.ops.fail != nil: u.ops.fail(m, u, result)
  else: m.setState(u, asFailed, "failed", result)

proc initUnitState*(m: Manager) =
  m.failHook = proc(m: Manager; u: Unit; result: string) =
    m.failUnit(u, result)
    m.runAction(u, u.def.common.startLimitAction, u.def.common.startLimitActionFlavor,
                u.id & " start limit hit")
