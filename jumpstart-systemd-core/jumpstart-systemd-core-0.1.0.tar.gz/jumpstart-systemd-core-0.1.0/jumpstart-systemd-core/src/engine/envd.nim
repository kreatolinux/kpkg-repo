## environment.d(5) for the user manager: what systemd's
## 30-systemd-environment-d-generator adds to `systemd --user`'s
## environment. GDM relies on it: the greeter's environment (DCONF_PROFILE,
## XDG_DATA_DIRS, ...) is written to ~/.config/environment.d/gdm.conf and
## reaches the session only through the user manager's `Environment`.
##
## Directories, lowest priority first: /usr/lib/environment.d,
## /usr/local/lib/environment.d, /run/environment.d, /etc/environment.d,
## ~/.config/environment.d. A file name in a later directory hides the same
## name in earlier ones; the surviving `*.conf` files are read in file-name
## order. Lines are `KEY=VALUE`; `#` starts a comment; `$KEY`, `${KEY}`,
## `${KEY:-default}` and `${KEY:+alternate}` expand against the variables
## set so far; single and double quotes are removed.
import std/[algorithm, os, strutils, tables]
import ../common/roots

proc environmentDirs*(r: Roots): seq[string] =
  ## The system-wide directories derive from usrLib (/usr/lib) so tests can
  ## move them; the user's is CONFIG/environment.d (~/.config).
  let top = r.usrLib.parentDir.parentDir          # "/" for /usr/lib
  @[r.usrLib / "environment.d", top / "usr/local/lib/environment.d",
    r.run / "environment.d", top / "etc/environment.d", r.etc / "environment.d"]

proc validName(k: string): bool =
  k.len > 0 and k[0] notin {'0'..'9'} and k.allCharsInSet({'A'..'Z', 'a'..'z', '0'..'9', '_'})

proc expand*(value: string; env: Table[string, string]): string =
  var i = 0
  while i < value.len:
    let c = value[i]
    if c == '\\' and i + 1 < value.len:
      result.add value[i + 1]
      i += 2
    elif c == '$' and i + 1 < value.len and value[i + 1] == '{':
      let close = value.find('}', i + 2)
      if close < 0:
        result.add value[i .. ^1]
        break
      let inner = value[i + 2 ..< close]
      var name = inner
      var op = ""
      var word = ""
      for o in [":-", ":+"]:
        let p = inner.find(o)
        if p > 0:
          name = inner[0 ..< p]
          op = o
          word = inner[p + 2 .. ^1]
          break
      let cur = env.getOrDefault(name, "")
      case op
      of ":-": result.add(if cur.len > 0: cur else: expand(word, env))
      of ":+": result.add(if cur.len > 0: expand(word, env) else: "")
      else: result.add cur
      i = close + 1
    elif c == '$' and i + 1 < value.len and value[i + 1] in {'A'..'Z', 'a'..'z', '_'}:
      var j = i + 1
      while j < value.len and value[j] in {'A'..'Z', 'a'..'z', '0'..'9', '_'}: inc j
      result.add env.getOrDefault(value[i + 1 ..< j], "")
      i = j
    else:
      result.add c
      inc i

proc unquote(v: string): string =
  if v.len >= 2 and ((v[0] == '"' and v[^1] == '"') or (v[0] == '\'' and v[^1] == '\'')):
    v[1 ..< v.len - 1]
  else: v

proc applyEnvironmentFile*(text: string; env: var Table[string, string]) =
  for raw in text.splitLines:
    let line = raw.strip
    if line.len == 0 or line[0] in {'#', ';'}: continue
    let eq = line.find('=')
    if eq <= 0: continue
    let key = line[0 ..< eq].strip
    if not validName(key): continue
    let v = line[eq + 1 .. ^1].strip
    if v.len > 0 and v[0] == '\'':
      env[key] = unquote(v)                      # single quotes: no expansion
    else:
      env[key] = expand(unquote(v), env)

proc environmentDFiles*(dirs: seq[string]): seq[string] =
  var byName = initTable[string, string]()
  for d in dirs:
    if not dirExists(d): continue
    for kind, path in walkDir(d):
      if kind notin {pcFile, pcLinkToFile}: continue
      let name = path.extractFilename
      if not name.endsWith(".conf") or name.startsWith("."): continue
      byName[name] = path                        # later directories win
  var names: seq[string]
  for n in byName.keys: names.add n
  names.sort()
  for n in names: result.add byName[n]

proc loadEnvironmentD*(r: Roots; env: var Table[string, string]) =
  ## User scope only; system managers do not read environment.d.
  if r.scope != scUser: return
  for f in environmentDFiles(environmentDirs(r)):
    try: applyEnvironmentFile(readFile(f), env)
    except IOError: discard
