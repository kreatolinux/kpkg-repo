## Building a transaction (spec §7.4.3): collect, isolate, collapse, merge,
## break ordering cycles, drop redundant jobs. Pure with respect to the job
## table: nothing is installed here; `jobs.nim` checks against installed jobs
## and installs. Failures raise `CoreError`.
import std/[tables, sets, options, algorithm, strutils, sequtils, hashes]
import jumpstartcore/errors
import ../common/logging
import ../unitfile/model
import ./[types, graph]

type
  TJob* = ref object
    unit*: Unit
    typ*: JobType
    matters*, conflicts*: bool
    ancestors*: seq[TJob]
    removed*: bool
  Transaction* = ref object
    m*: Manager
    mode*: JobMode
    origin*: JobOrigin
    anchor*: TJob
    jobs*: seq[TJob]

proc hash*(j: TJob): Hash = hash(cast[pointer](j))

proc fail(code: CoreErrorCode; msg: string) {.noreturn.} =
  raise newCoreError(code, msg)

proc live*(tr: Transaction): seq[TJob] =
  for j in tr.jobs:
    if not j.removed: result.add j

proc find(tr: Transaction; u: Unit; typ: JobType): TJob =
  for j in tr.jobs:
    if not j.removed and j.unit == u and j.typ == typ: return j

proc canReload(u: Unit): bool =
  u.ops.canReload != nil and u.ops.canReload(u)

proc isActiveState(u: Unit): bool = u.active in {asActive, asReloading, asActivating}

proc addJob(tr: Transaction; u: Unit; typ: JobType; matters, conflicts: bool; ancestor: TJob) =
  let existing = tr.find(u, typ)
  if existing != nil:
    existing.matters = existing.matters or matters
    if ancestor != nil and ancestor notin existing.ancestors: existing.ancestors.add ancestor
    return
  let j = TJob(unit: u, typ: typ, matters: matters, conflicts: conflicts)
  if ancestor != nil: j.ancestors.add ancestor
  tr.jobs.add j
  if tr.anchor == nil: tr.anchor = j
  let m = tr.m
  if tr.mode == jmIgnoreDependencies: return

  proc dep(x: string; t: JobType; mt, cf: bool; required: bool) =
    let other = m.lookup(x)
    if other == nil:
      if required: fail(ecUnitState, "Unit " & x & " not found.")
      return
    if other.isMasked or not other.loadOk:
      if required:
        fail(ecUnitState, "Unit " & x & " is " & (if other.isMasked: "masked." else: "not loaded properly."))
      return
    tr.addJob(other, t, mt, cf, j)

  case typ
  of jtStart, jtReloadOrStart, jtRestart, jtTryRestart, jtTryReloadOrStart:
    if tr.mode != jmIgnoreRequirements:
      for x in m.depUnits(u, [dkRequires, dkBindsTo]): dep(x, jtStart, true, false, true)
      for x in m.depUnits(u, [dkWants, dkUpholds]): dep(x, jtStart, false, false, false)
      for x in m.depUnits(u, [dkRequisite]): dep(x, jtVerifyActive, true, false, true)
    for x in m.depUnits(u, [dkConflicts]): dep(x, jtStop, true, true, false)
    for x in m.conflictsWith(u): dep(x, jtStop, false, true, false)
  else: discard
  case typ
  of jtStop, jtRestart:
    for x in m.requiredBy(u) & m.boundBy(u) & m.consistsOf(u) & m.stopPropagatesTo(u):
      dep(x, (if typ == jtStop: jtStop else: jtTryRestart), true, false, false)
  else: discard
  case typ
  of jtReload, jtReloadOrStart:
    for x in m.reloadPropagatesTo(u): dep(x, jtTryReload, false, false, false)
  else: discard

proc removeJob(tr: Transaction; j: TJob) = j.removed = true

proc removeOrphans(tr: Transaction) =
  ## Jobs whose every ancestor was removed (and which are not the anchor).
  var changed = true
  while changed:
    changed = false
    for j in tr.live:
      if j == tr.anchor or j.ancestors.len == 0: continue
      var anyLive = false
      for a in j.ancestors:
        if not a.removed: anyLive = true
      if not anyLive:
        j.removed = true
        changed = true

proc collapse(tr: Transaction) =
  for j in tr.live:
    let u = j.unit
    case j.typ
    of jtTryRestart: j.typ = if isActiveState(u): jtRestart else: jtNop
    of jtTryReload: j.typ = if u.active == asActive: jtReload else: jtNop
    of jtTryReloadOrStart: j.typ = if isActiveState(u): jtReloadOrStart else: jtNop
    else: discard

const Mergeable = [jtStart, jtVerifyActive, jtReload, jtRestart, jtReloadOrStart, jtStop]

proc mergeTypes*(a, b: JobType): Option[JobType] =
  ## The merge table of §7.4.3 step 4. None: unmergeable.
  if a == jtNop: return some(b)
  if b == jtNop: return some(a)
  if a == b: return some(a)
  let ia = Mergeable.find(a)
  let ib = Mergeable.find(b)
  if ia < 0 or ib < 0: return none(JobType)
  if a == jtStop or b == jtStop: return none(JobType)
  const table: array[5, array[5, JobType]] = [
    #        start          verify-active  reload         restart   reload-or-start
    [jtStart,           jtStart,           jtReloadOrStart, jtRestart, jtReloadOrStart],
    [jtStart,           jtVerifyActive,    jtReload,        jtRestart, jtReloadOrStart],
    [jtReloadOrStart,   jtReload,          jtReload,        jtRestart, jtReloadOrStart],
    [jtRestart,         jtRestart,         jtRestart,       jtRestart, jtRestart],
    [jtReloadOrStart,   jtReloadOrStart,   jtReloadOrStart, jtRestart, jtReloadOrStart]]
  some(table[ia][ib])

proc mergePerUnit(tr: Transaction) =
  ## Step 4. Merge jobs of one unit; resolve unmergeable pairs or fail.
  var progress = true
  while progress:
    progress = false
    var byUnit = initOrderedTable[string, seq[TJob]]()
    for j in tr.live:
      if j.typ != jtNop: byUnit.mgetOrPut(j.unit.id, @[]).add j
    for id, js in byUnit:
      if js.len < 2: continue
      # try merging every pair
      for a in 0 ..< js.len:
        for b in a + 1 ..< js.len:
          if js[a].removed or js[b].removed: continue
          let merged = mergeTypes(js[a].typ, js[b].typ)
          if merged.isSome:
            js[a].typ = merged.get
            js[a].matters = js[a].matters or js[b].matters
            js[a].conflicts = js[a].conflicts and js[b].conflicts
            for x in js[b].ancestors:
              if x notin js[a].ancestors: js[a].ancestors.add x
            for other in tr.jobs:                       # re-point ancestors at the survivor
              for k in 0 ..< other.ancestors.len:
                if other.ancestors[k] == js[b]: other.ancestors[k] = js[a]
            if tr.anchor == js[b]: tr.anchor = js[a]
            js[b].removed = true
            progress = true
          else:
            let (x, y) = (js[a], js[b])
            let (stopJob, other) = if x.typ == jtStop: (x, y) else: (y, x)
            if not x.matters and not y.matters:
              # think positive: remove the stop, unless it exists only for a conflict
              if stopJob.conflicts: tr.removeJob(other) else: tr.removeJob(stopJob)
            elif not x.matters: tr.removeJob(x)
            elif not y.matters: tr.removeJob(y)
            else:
              fail(ecUnitState, "Transaction contains conflicting jobs '" & $x.typ & "' and '" &
                $y.typ & "' for " & id & ". Probably contradicting requirement dependencies configured.")
            tr.removeOrphans()
            progress = true
      if progress: break

proc breakCycles(tr: Transaction) =
  ## Step 5. Cycles in the `After` relation among units with jobs.
  while true:
    let jobs = tr.live
    var byUnit = initTable[string, TJob]()
    for j in jobs: byUnit[j.unit.id] = j
    var names = toSeq(byUnit.keys)
    names.sort()
    var state = initTable[string, int]()      # 0 new, 1 on stack, 2 done
    var stack: seq[string]
    var cycle: seq[string]
    proc dfs(n: string): bool =
      state[n] = 1
      stack.add n
      var succ = toSeq(tr.m.orderedBefore(byUnit[n].unit))
      succ.sort()
      for s in succ:
        if not byUnit.hasKey(s): continue
        if state.getOrDefault(s) == 1:
          cycle = stack[stack.find(s) .. ^1]
          return true
        if state.getOrDefault(s) == 0 and dfs(s): return true
      discard stack.pop()
      state[n] = 2
      false
    var found = false
    for n in names:
      if state.getOrDefault(n) == 0 and dfs(n):
        found = true
        break
    if not found: return
    var victim: TJob = nil
    for n in cycle:
      let j = byUnit[n]
      if not j.matters and j != tr.anchor:
        victim = j
        break
    if victim == nil:
      fail(ecUnitState, "Transaction for " & tr.anchor.unit.id & "/" & $tr.anchor.typ &
        " is destructive: ordering cycle between " & cycle.join(", "))
    logWarn(victim.unit.id, "Job " & victim.unit.id & "/" & $victim.typ &
      " deleted to break ordering cycle starting with " & cycle[0] & "/" & $byUnit[cycle[0]].typ)
    tr.removeJob(victim)
    tr.removeOrphans()

proc dropRedundant(tr: Transaction) =
  ## Step 6: jobs that would do nothing in the unit's current stable state.
  for j in tr.live:
    if j == tr.anchor: continue
    let u = j.unit
    let busy = u.ops.isBusy != nil and u.ops.isBusy(u)
    case j.typ
    of jtStart, jtVerifyActive:
      if u.active in {asActive, asReloading}: tr.removeJob(j)
    of jtStop:
      if u.active in {asInactive, asFailed} and not busy and u.job == nil: tr.removeJob(j)
    of jtNop: tr.removeJob(j)
    else: discard
  tr.removeOrphans()

proc isolateStops(tr: Transaction) =
  let m = tr.m
  for u in m.allUnits:
    if tr.find(u, jtStop) != nil: continue
    var collected = false
    for j in tr.live:
      if j.unit == u: collected = true
    if collected or not u.loadOk or u.def.common.ignoreOnIsolate: continue
    if u.active in {asActive, asActivating, asReloading} or u.job != nil:
      tr.addJob(u, jtStop, false, false, nil)

proc buildTransaction*(m: Manager; unit: Unit; typ: JobType; mode: JobMode;
                       origin: JobOrigin): Transaction =
  ## Raises `CoreError` (`ecUnitState`) when the transaction cannot be built.
  ## For `jtNop` the transaction holds just the anchor.
  result = Transaction(m: m, mode: mode, origin: origin)
  result.addJob(unit, typ, true, false, nil)
  if mode == jmIsolate: result.isolateStops()
  result.collapse()
  if result.anchor.typ == jtNop:
    for j in result.jobs:
      if j != result.anchor: j.removed = true
    return
  for j in result.live:
    if j.typ == jtNop and j != result.anchor: j.removed = true
  result.removeOrphans()
  result.mergePerUnit()
  result.breakCycles()
  result.dropRedundant()
