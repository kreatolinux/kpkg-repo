## Built-in behavior of targets, slices, power targets and devices, and the
## refusing fallback for a unit type whose behavior module is not installed
## (`.scope`, or a manager built without the type module).
## Everything else is a plain unit file with no behavior of its own beyond state.
import std/[strutils, options, os]
import ../common/[logging, roots, names, fdutil]
import ../unitfile/model
import ./[types, unitstate]
import ../service/cgroupmgr

proc powerActionOf(id: string): Option[PowerAction] =
  case id
  of "poweroff.target": some(paPoweroff)
  of "reboot.target": some(paReboot)
  of "halt.target": some(paHalt)
  of "kexec.target": some(paKexec)
  of "exit.target": some(paExit)
  else: none(PowerAction)

proc attachTarget*(m: Manager; u: Unit) =
  u.ops.start = proc(m: Manager; u: Unit): StartOutcome =
    let power = powerActionOf(u.id)
    if power.isSome:
      let valid = if m.roots.scope == scUser: power.get == paExit else: power.get != paExit
      if not valid:
        return StartOutcome(kind: skRefused, code: "E_UNSUPPORTED",
          text: "Job type start is not applicable for unit " & u.id & ".")
      if not m.requestPower(power.get):
        return StartOutcome(kind: skRefused, code: "E_IO", text: "Failed to request " & u.id & ".")
    logInfo(u.id, "Reached target " & u.def.common.description.strip & ".")
    m.setState(u, asActive, "active", "success")
    if u.id == "local-fs.target" and m.fsReady != nil: m.fsReady()
    StartOutcome(kind: skStarted)
  u.ops.stop = proc(m: Manager; u: Unit) =
    m.setState(u, asInactive, "dead", "success")
  u.ops.resetFailed = proc(m: Manager; u: Unit) =
    if u.active == asFailed: m.setState(u, asInactive, "dead", "success")

proc attachSlice*(m: Manager; u: Unit) =
  u.ops.start = proc(m: Manager; u: Unit): StartOutcome =
    discard m.ensureUnitCgroup(u)
    m.setState(u, asActive, "active", "success")
    StartOutcome(kind: skStarted)
  u.ops.stop = proc(m: Manager; u: Unit) =
    m.removeUnitCgroup(u)
    m.setState(u, asInactive, "dead", "success")

proc attachUnsupported*(m: Manager; u: Unit) =
  ## Loadable and listable, never started: the type module (units/*.nim) did not attach.
  let kind = $u.kind
  u.ops.start = proc(m: Manager; u: Unit): StartOutcome =
    StartOutcome(kind: skRefused, code: "E_UNSUPPORTED",
      text: "Unit " & u.id & " uses unsupported feature: " & kind & " units are not run by this manager.")
  u.ops.stop = proc(m: Manager; u: Unit) =
    m.setState(u, asInactive, "dead", "success")

proc devicePath*(m: Manager; u: Unit): string =
  ## `dev-ttyS0.device` -> `<devfs>/ttyS0`.
  let p = unescapePath(u.def.common.prefix)
  if p.isNone: return ""
  let path = p.get
  if path.startsWith("/dev/"): m.roots.devfs / path[5 .. ^1] else: path

proc deviceState(m: Manager; u: Unit) =
  let present = nodeExists(m.devicePath(u)) or symlinkExists(m.devicePath(u))
  if present and u.active != asActive: m.setState(u, asActive, "plugged", "success")
  elif not present and u.active == asActive: m.setState(u, asInactive, "dead", "success")

proc attachDevice*(m: Manager; u: Unit) =
  ## Devices are tracked by path, never stopped by jobs (§11.8); a start job
  ## succeeds when the node exists and fails at once otherwise.
  u.perpetual = true
  u.ops.start = proc(m: Manager; u: Unit): StartOutcome =
    m.deviceState(u)
    if u.active == asActive: StartOutcome(kind: skAlreadyActive)
    else: StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "Device " & m.devicePath(u) & " is not present.")
  u.ops.stop = proc(m: Manager; u: Unit) = m.deviceState(u)
  m.deviceState(u)
