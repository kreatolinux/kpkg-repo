## `set-property` and `clean`: persistent and runtime control drop-ins, and
## removal of a unit's per-unit directories. Used by the verb handlers; no socket
## types here.
import std/[os, strutils, sets, sequtils]
import jumpstartcore/errors
import ../common/[names, roots]
import ../unitfile/[model, paths]
import ./[types, graph, manager]

const
  UnitSectionKeys = ["Description", "Documentation", "Wants", "Requires", "Requisite", "BindsTo", "PartOf",
    "Upholds", "Conflicts", "Before", "After", "OnFailure", "OnSuccess", "PropagatesReloadTo",
    "ReloadPropagatedFrom", "JoinsNamespaceOf", "RequiresMountsFor", "StopWhenUnneeded",
    "RefuseManualStart", "RefuseManualStop", "AllowIsolate", "DefaultDependencies", "CollectMode",
    "FailureAction", "SuccessAction", "JobTimeoutSec", "JobTimeoutAction", "StartLimitIntervalSec",
    "StartLimitBurst", "StartLimitAction", "IgnoreOnIsolate", "SourcePath", "OnFailureJobMode",
    "OnSuccessJobMode", "JobRunningTimeoutSec", "RebootArgument", "SuccessActionExitStatus",
    "FailureActionExitStatus"]
  TimerKeys = ["OnCalendar", "OnActiveSec", "OnBootSec", "OnStartupSec", "OnUnitActiveSec",
    "OnUnitInactiveSec", "Persistent", "AccuracySec", "RandomizedDelaySec", "WakeSystem",
    "RemainAfterElapse", "OnClockChange", "OnTimezoneChange", "FixedRandomDelay", "Unit"]

proc sectionOfKind*(k: UnitKind): string =
  case k
  of ukService: "Service"
  of ukSocket: "Socket"
  of ukMount: "Mount"
  of ukSwap: "Swap"
  of ukSlice: "Slice"
  of ukTimer: "Timer"
  of ukPath: "Path"
  of ukScope: "Scope"
  of ukAutomount: "Automount"
  else: "Unit"

proc sectionFor*(key: string; kind: UnitKind): string =
  ## The section a property belongs to in a unit of `kind`.
  if key in UnitSectionKeys or key.startsWith("Condition") or key.startsWith("Assert"): return "Unit"
  if kind == ukTimer and key in TimerKeys: return "Timer"
  sectionOfKind(kind)

proc validKey*(k: string): bool =
  k.len > 0 and k[0] in UppercaseLetters and k.allCharsInSet(Letters + Digits)

proc splitAssignment*(a: string): tuple[key, value: string] =
  let eq = a.find('=')
  if eq < 0: return ("", "")
  (a[0 ..< eq].strip, a[eq + 1 .. ^1])

proc controlDirFor*(r: Roots; runtime: bool): string =
  let c = controlDirs(r)
  if runtime: c.runtime else: c.persistent

proc setProperties*(m: Manager; unitName: string; runtime: bool; props: seq[string]):
    tuple[applied: seq[string], dropins: seq[string]] =
  ## Writes `50-KEY.conf` in the control directory, reloads and rolls back
  ## the files when the loader does not know the property.
  let name = mangle(unitName)
  let u = m.lookup(name)
  if u == nil or u.def.common.loadState == lsNotFound:
    raise newCoreError(ecNotFound, "Unit " & name & " not found.")
  if props.len == 0: raise newCoreError(ecUsage, "No properties given.")
  let dir = controlDirFor(m.roots, runtime) / (u.id & ".d")
  var written: seq[(string, string)]            ## path, previous text ("\0" none)
  proc rollback() =
    for (p, old) in written:
      if old == "\0": removeFile(p)
      else: writeFile(p, old)
    try:
      if dirExists(dir) and toSeq(walkDir(dir)).len == 0: removeDir(dir)
    except OSError: discard
  for a in props:
    let (k, v) = splitAssignment(a)
    if not validKey(k):
      rollback()
      raise newCoreError(ecUsage, "Invalid property assignment '" & a & "'.")
    if '\n' in v or '\0' in v:
      rollback()
      raise newCoreError(ecUsage, "Invalid value for " & k & ".")
    createDir(dir)
    let p = dir / ("50-" & k & ".conf")
    written.add (p, (if fileExists(p): readFile(p) else: "\0"))
    writeFile(p, "[" & sectionFor(k, u.kind) & "]\n" & k & "=" & v & "\n")
    result.dropins.add p
    result.applied.add a
  discard m.daemonReload()
  let fresh = m.lookup(u.id)
  if fresh != nil:
    for d in fresh.def.common.diagnostics:
      if d.key.len > 0 and d.key in result.applied.mapIt(splitAssignment(it).key) and
          d.message.startsWith("Unknown key"):
        let bad = d.key
        rollback()
        discard m.daemonReload()
        raise newCoreError(ecUsage, "Unknown assignment: " & bad & ".")

proc cleanUnit*(m: Manager; unitName: string; what: seq[string]): int =
  ## Removes the unit's cache/state/logs/runtime/configuration directories (and
  ## a timer's stamp file); returns the number of entries removed.
  let u = m.lookup(mangle(unitName))
  if u == nil or u.def.common.loadState == lsNotFound:
    raise newCoreError(ecNotFound, "Unit " & mangle(unitName) & " not found.")
  if u.active notin {asInactive, asFailed}:
    raise newCoreError(ecUnitState, "Unit " & u.id & " is not inactive or failed; cannot clean.")
  var want = initHashSet[string]()
  # Without an explicit list, clean removes the cache, runtime and logs directories.
  for w in (if what.len == 0: @["cache", "runtime", "logs"] else: what):
    if w notin ["cache", "state", "logs", "runtime", "configuration", "fdstore", "all"]:
      raise newCoreError(ecUsage, "Invalid resource type: " & w)
    want.incl w
  proc wants(w: string): bool = "all" in want or w in want
  let r = m.roots
  let ec = execContextOf(u.def)
  template rm(base: string; names: seq[string]) =
    for n in names:
      let sub = n.split(':')[0].strip(chars = {'/'}, leading = false)
      if sub.len > 0 and ".." notin sub.split('/'):
        let p = base / sub
        if dirExists(p):
          removeDir(p)
          inc result
        elif fileExists(p) or symlinkExists(p):
          removeFile(p)
          inc result
  if ec != nil:
    let runBase = if r.scope == scUser: r.runtime else: r.run
    if wants("runtime"): rm(runBase, ec.runtimeDirectory)
    if wants("state"): rm(r.varLib, ec.stateDirectory)
    if wants("cache"): rm(r.varCache, ec.cacheDirectory)
    if wants("logs"): rm(r.logsRoot, ec.logsDirectory)
    if wants("configuration"): rm(r.etc, ec.configurationDirectory)
  if u.kind == ukTimer and wants("state") and r.st.len > 0:
    let stamp = r.st / "timers" / ("stamp-" & u.id)
    if fileExists(stamp):
      removeFile(stamp)
      inc result
