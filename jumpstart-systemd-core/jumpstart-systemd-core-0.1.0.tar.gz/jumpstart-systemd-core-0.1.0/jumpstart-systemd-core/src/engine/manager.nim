## Assembling the manager (spec §3.2, §8.1): environment, unit index, behavior
## attachment, daemon-reload and the reaper hookup.
import std/[os, strutils, tables, sets, sequtils]
import jumpstartcore/[reaper, environment]
import ../common/[roots, clock, names, fdutil]
import ../unitfile/[model, index, loader, specifiers, managerconf]
import ./[types, special, unitstate, eventloop, power, boot, gc, envd]
import ../service/[service, cgroupmgr]

var
  generatorHook*: proc(m: Manager): seq[GeneratedUnit] {.closure.}   ## fstab generator (units/mount.nim)
  socketAttach*, mountAttach*, timerAttach*, pathAttach*, swapAttach*, automountAttach*: proc(m: Manager; u: Unit) {.closure.}   ## set by the socket and mount unit modules

type ManagerExtra* = ref object of RootObj
  spec*: SpecifierEnv

proc specEnv*(m: Manager): SpecifierEnv =
  if m.extra of ManagerExtra: ManagerExtra(m.extra).spec else: newSpecifierEnv(m.roots)

proc readTrim(path: string): string =
  try: readFile(path).strip except IOError: ""

proc baseEnvironment(m: Manager) =
  ## §10.2 layer 1: the process environment without JUMPSTART_*, then locale.conf.
  for k, v in envPairs():
    if not isJumpstartVariable(k): m.env[k] = v
  if "PATH" notin m.env: m.env["PATH"] = SystemPath
  for line in readTrim(m.roots.etc / "locale.conf").splitLines:
    let eq = line.find('=')
    if eq > 0 and line[0] != '#':
      let k = line[0 ..< eq]
      if k in ["LANG", "LANGUAGE"] or k.startsWith("LC_"):
        m.env[k] = line[eq + 1 .. ^1].strip(chars = {'"', '\''})
  # User scope: environment.d(5), as systemd's environment-d generator (envd.nim).
  loadEnvironmentD(m.roots, m.env)
  for e in m.conf.defaultEnvironment:
    let eq = e.find('=')
    if eq > 0: m.env[e[0 ..< eq]] = e[eq + 1 .. ^1]

proc attachBehavior*(m: Manager; u: Unit) =
  case u.kind
  of ukService: service.attach(m, u)
  of ukTarget: attachTarget(m, u)
  of ukSlice: attachSlice(m, u)
  of ukDevice: attachDevice(m, u)
  of ukSocket, ukMount, ukTimer, ukPath, ukSwap, ukAutomount, ukScope:
    if socketAttach != nil and u.kind == ukSocket: socketAttach(m, u)
    elif mountAttach != nil and u.kind == ukMount: mountAttach(m, u)
    elif timerAttach != nil and u.kind == ukTimer: timerAttach(m, u)
    elif pathAttach != nil and u.kind == ukPath: pathAttach(m, u)
    elif swapAttach != nil and u.kind == ukSwap: swapAttach(m, u)
    elif automountAttach != nil and u.kind == ukAutomount: automountAttach(m, u)
    else: attachUnsupported(m, u)

proc serialGettyEdges(m: Manager): seq[(DepKind, string, string)] =
  ## §8.6: a `serial-getty@T.service` wanted by getty.target for every
  ## serial console (system scope).
  if m.roots.scope != scSystem: return
  var consoles = readTrim(m.roots.sysfs / "class/tty/console/active").splitWhitespace
  if consoles.len == 0:
    for w in readTrim(m.roots.cmdline).splitWhitespace:
      if w.startsWith("console="):
        let name = w["console=".len .. ^1].split(',')[0]
        consoles.add name
  for t in consoles:
    if t.startsWith("tty") and t.len > 3 and t[3 .. ^1].allCharsInSet(Digits): continue
    if not nodeExists(m.roots.devfs / t) and not symlinkExists(m.roots.devfs / t): continue
    result.add (dkWants, "getty.target", "serial-getty@" & t & ".service")

proc reloadIndex*(m: Manager): seq[Diag] =
  ## Scans the search path again (generators run before this, §6.12).
  var diags: seq[Diag]
  let generated = if generatorHook != nil: generatorHook(m) else: @[]
  m.index = buildIndex(m.roots, generated, diags, conf = m.conf)
  if m.extra of ManagerExtra: ManagerExtra(m.extra).spec = newSpecifierEnv(m.roots)
  m.indexReady = true
  diags

proc newManager*(roots: Roots; clock: Clock = nil): Manager =
  let c = if clock == nil: newClock() else: clock
  let m = Manager(roots: roots, loop: newEventLoop(c), clock: c, rng: newRng(),
    version: "255", units: initTable[string, Unit](), aliases: initTable[string, string](),
    jobs: initTable[int, Job](), env: initTable[string, string](), masked: initHashSet[string](),
    dirty: initHashSet[string](), pids: initTable[int, string](),
    monitor: initTable[string, seq[(string, string)]](), conf: ManagerConf())
  m.reaper = newReaper()
  m.startedUsec = c.monoUsec
  m.cg = newCgroupManager(roots)
  m.extra = ManagerExtra(spec: newSpecifierEnv(roots))
  m.bootId = readTrim(roots.procfs / "sys/kernel/random/boot_id").replace("-", "")
  m.machineId = readTrim(roots.machineId)
  m.firstBoot = m.machineId.len == 0 or m.machineId == "uninitialized"
  if m.firstBoot:
    var raw = m.rng.bytes(16)
    m.machineId = ""
    for ch in raw: m.machineId.add toHex(ord(ch), 2).toLowerAscii
  m.attachHook = proc(m: Manager; u: Unit) = attachBehavior(m, u)
  m.loadHook = proc(m: Manager; id: string): UnitDef = loader.loadUnit(m.index, id, m.specEnv)
  m.powerHook = proc(a: PowerAction): bool =
    result = requestPowerViaJumpstart(m.roots, a)
    if result and a != paExit: m.stopping = true
  var confDiags: seq[Diag]
  m.conf = parseManagerConf(roots, confDiags)
  initUnitState(m)
  installNotifyHandler(m)
  parseCmdline(m)
  m.baseEnvironment()
  m.extraDeps.add m.serialGettyEdges
  discard m.reloadIndex()
  m

proc hookReaper*(m: Manager) =
  ## Child exits arrive through the central reaper only (§3.2).
  m.reaper.onUnowned = proc(st: ChildStatus) = discard
  when defined(linux):
    try: m.reaper.installReaper(false)       # child subreaper + SIGCHLD handler
    except CatchableError: m.reaper.installSigChldHandler()
  else:
    m.reaper.installSigChldHandler()
  discard m.loop.addFd(m.reaper.wakeupFd, EvIn, proc(ev: uint32) = discard m.reaper.drainWakeup())

proc daemonReload*(m: Manager): tuple[loaded: int, errors: seq[Diag]] =
  ## §6.13: rescan, then re-read every loaded unit. Running units keep running.
  var confDiags: seq[Diag]
  m.conf = parseManagerConf(m.roots, confDiags)
  let diags = m.reloadIndex()
  for d in diags & confDiags:
    if d.severity == sevError: result.errors.add d
  m.extraDeps = m.extraDeps.filterIt(it[1] != "getty.target" or not it[2].startsWith("serial-getty@"))
  m.extraDeps.add m.serialGettyEdges
  for id in toSeq(m.units.keys):
    let u = m.units[id]
    let fresh = loader.loadUnit(m.index, id, m.specEnv)
    for dg in fresh.common.diagnostics:
      if dg.severity == sevError: result.errors.add dg
    if fresh.common.loadState == lsNotFound:
      if u.active == asInactive and u.job == nil and not u.perpetual:
        for n in u.def.common.names: m.aliases.del n
        m.units.del id
      else: u.needDaemonReload = true
      continue
    if fresh.kind != u.kind:
      u.needDaemonReload = true
      continue
    if fresh.common.id in m.masked: fresh.common.loadState = lsMasked
    let old = u.def
    u.def = fresh
    u.startLimit.intervalUsec = fresh.common.startLimitIntervalUsec
    u.startLimit.burst = fresh.common.startLimitBurst
    for n in fresh.common.names:
      if n != id: m.aliases[n] = id
    if u.ops.redefine != nil: u.ops.redefine(m, u, old, fresh)
    u.needDaemonReload = false
    inc result.loaded
  m.reverseDirty = true
  m.scheduleGc()
