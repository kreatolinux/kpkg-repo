## The job table (spec §7.4.4 to §7.4.9): installing a transaction against the
## installed jobs, ordering-aware scheduling, running jobs by type, finishing
## them and propagating failures, job timeouts.
import std/[tables, sets, options, algorithm, sequtils]
import jumpstartcore/errors
import ../common/[logging, clock]
import ../unitfile/model
import ./[types, graph, transaction, conditions, eventloop]

const MaxJobs* = 10_000

proc fail(code: CoreErrorCode; msg: string) {.noreturn.} =
  raise newCoreError(code, msg)

proc runScheduler*(m: Manager)

proc isDown(j: Job): bool =
  j.typ == jtStop or (j.typ == jtRestart and j.restartStopPhase)

proc unitBusy(u: Unit): bool = u.ops.isBusy != nil and u.ops.isBusy(u)

proc jobInfoText*(j: Job): string = $j.id & ":" & $j.typ

# ---- failure texts (§9.10, §4.7) ---------------------------------------------
proc failureText*(m: Manager; u: Unit; res: JobResult): string =
  case res
  of jrTimeout: "Job for " & u.id & " failed: a timeout was exceeded"
  of jrDependency: "A dependency job for " & u.id & " failed."
  of jrCanceled: "Job for " & u.id & " canceled."
  of jrAssert: "Assertion failed on job for " & u.id & "."
  of jrSkipped: "Job for " & u.id & " was skipped."
  of jrInvalid, jrUnsupported: "Job type is not applicable for unit " & u.id & "."
  of jrCollected: "Unit " & u.id & " was garbage collected."
  else:
    var reason = "of an unknown reason"
    var main = 0
    if u.ops.status != nil: main = u.ops.status(m, u).exitCode
    case u.result
    of "exit-code":
      reason = if main >= 0 and u.kind == ukService: "the service exited with status " & $main
               else: "the control process exited with error code"
    of "signal": reason = "a fatal signal was delivered to the service"
    of "core-dump": reason = "a fatal signal was delivered to the service, dumping core"
    of "timeout": reason = "a timeout was exceeded"
    of "protocol": reason = "the service did not take the steps required by its unit configuration"
    of "watchdog": reason = "the watchdog timeout was reached"
    of "resources": reason = "of resource exhaustion"
    of "oom-kill": reason = "of an out-of-memory kill"
    of "start-limit-hit": reason = "the start request was repeated too quickly"
    else: discard
    "Job for " & u.id & " failed because " & reason & "."

# ---- finishing -----------------------------------------------------------------
proc dropTimers(m: Manager; j: Job) =
  m.loop.cancelTimer(j.timeoutTimer)
  m.loop.cancelTimer(j.runningTimer)

proc finishJob*(m: Manager; j: Job; res: JobResult; message = ""; code = "") =
  ## Removes `j` from the table, wakes its waiters and propagates failure.
  if not m.jobs.hasKey(j.id): return
  m.jobs.del j.id
  let u = j.unit
  if u.job == j: u.job = nil
  m.dropTimers(j)
  var text = message
  if text.len == 0 and res notin {jrDone}: text = m.failureText(u, res)
  let outcome = JobOutcome(job: j.id, result: res, message: text, code: code,
                           unit: u.id, state: u.active)
  let waiters = j.waiters
  j.waiters = @[]
  if m.observer != nil: m.observer(outcome)
  if m.jobFinishedHook != nil:
    try: m.jobFinishedHook(outcome)
    except CatchableError as e: logErr(u.id, "job hook failed: " & e.msg)
  for w in waiters:
    try: w(outcome)
    except CatchableError as e: logErr(u.id, "job waiter failed: " & e.msg)
  if res in {jrFailed, jrTimeout, jrDependency} and j.typ in {jtStart, jtReloadOrStart, jtVerifyActive, jtRestart}:
    for rid in m.requiredBy(u) & m.boundBy(u):
      let r = m.units.getOrDefault(rid)
      if r != nil and r.job != nil and r.job.typ in {jtStart, jtVerifyActive, jtReloadOrStart}:
        m.finishJob(r.job, jrDependency)
  m.loop.afterEvent(proc() = m.runScheduler())

proc cancelJob*(m: Manager; id: int): bool =
  if not m.jobs.hasKey(id): return false
  let j = m.jobs[id]
  if j.irreversible and j.origin == joDependency: discard   # cancelled explicitly: allowed
  m.finishJob(j, jrCanceled)
  true

# ---- start limit ----------------------------------------------------------------
proc startLimitAllows*(m: Manager; u: Unit): bool =
  let r = addr u.startLimit
  if r.intervalUsec <= 0 or r.burst <= 0: return true
  let now = m.clock.monoUsec
  if r.begin == 0 or now - r.begin > r.intervalUsec:
    r.begin = now
    r.count = 0
  inc r.count
  r.count <= r.burst

# ---- running ---------------------------------------------------------------------
proc runStartFresh(m: Manager; j: Job)

proc abortRestart(m: Manager; u: Unit) =
  ## A queued automatic restart that cannot run (conditions failed) must not
  ## leave the unit waiting forever.
  if u.sub == "auto-restart-queued" and u.ops.stop != nil: u.ops.stop(m, u)

proc runStart(m: Manager; j: Job) =
  let u = j.unit
  case u.active
  of asActive, asReloading:
    m.finishJob(j, jrDone)
  of asActivating:
    if u.sub in ["auto-restart", "auto-restart-queued"]:
      # an automatic restart is queued: the job runs the start for real
      j.state = jsWaiting
      u.sub = "auto-restart-queued"
      runStartFresh(m, j)
    else:
      j.state = jsRunning
  of asDeactivating:
    discard                                # waits until the unit is inactive
  of asInactive, asFailed: runStartFresh(m, j)

proc runStartFresh(m: Manager; j: Job) =
  let u = j.unit
  block:
    let facts = gatherFacts(m)
    let check = checkConditions(facts, u.def.common.conditions)
    if not check.ok:
      u.failedCondition = check.failed
      u.conditionResult = false
      m.abortRestart(u)
      if check.isAssert: m.finishJob(j, jrAssert)
      else: m.finishJob(j, jrSkipped)
      return
    u.conditionResult = true
    u.failedCondition = ""
    if u.ops.start == nil:
      m.finishJob(j, jrUnsupported, "Job type start is not applicable for unit " & u.id & ".",
                  "E_UNSUPPORTED")
      return
    if not m.startLimitAllows(u):
      if m.failHook != nil: m.failHook(m, u, "start-limit-hit")
      m.finishJob(j, jrFailed, "Start request for " & u.id & " repeated too quickly.", "E_UNIT_STATE")
      return
    j.state = jsRunning
    let r = u.ops.start(m, u)
    case r.kind
    of skStarted: discard                   # setState completes the job
    of skAlreadyActive: m.finishJob(j, jrDone)
    of skConditionFailed:
      u.failedCondition = r.text
      m.finishJob(j, jrSkipped)
    of skAssertFailed:
      u.failedCondition = r.text
      m.finishJob(j, jrAssert)
    of skRefused: m.finishJob(j, jrFailed, r.text, r.code)

proc runJob(m: Manager; j: Job) =
  let u = j.unit
  if j.runningTimer.isSet: discard
  if u.def.common.jobRunningTimeoutUsec != Infinity:
    j.runningTimer = m.loop.addTimerIn(u.def.common.jobRunningTimeoutUsec, proc() =
      if m.jobs.hasKey(j.id): m.finishJob(j, jrTimeout))
  case j.typ
  of jtNop: m.finishJob(j, jrDone)
  of jtVerifyActive:
    if u.active in {asActive, asReloading}: m.finishJob(j, jrDone) else: m.finishJob(j, jrDependency)
  of jtStart: runStart(m, j)
  of jtStop:
    if u.active in {asInactive, asFailed} and not unitBusy(u):
      m.finishJob(j, jrDone)
    elif u.ops.stop == nil: m.finishJob(j, jrUnsupported)
    else:
      j.state = jsRunning
      u.ops.stop(m, u)
  of jtReload:
    if u.active notin {asActive, asReloading}:
      m.finishJob(j, jrFailed, "Unit " & u.id & " is not active.", "E_UNIT_STATE")
    elif u.ops.reload == nil or (u.ops.canReload != nil and not u.ops.canReload(u)):
      m.finishJob(j, jrUnsupported, "Job type reload is not applicable for unit " & u.id & ".",
                  "E_UNSUPPORTED")
    else:
      j.state = jsRunning
      u.reloadResult = "success"
      if not u.ops.reload(m, u):
        m.finishJob(j, jrUnsupported, "Job type reload is not applicable for unit " & u.id & ".",
                    "E_UNSUPPORTED")
  of jtReloadOrStart:
    if u.active in {asInactive, asFailed}: j.typ = jtStart
    elif u.ops.canReload != nil and u.ops.canReload(u) and u.active == asActive: j.typ = jtReload
    elif u.active == asActivating: j.typ = jtStart
    else: j.typ = jtRestart
    runJob(m, j)
  of jtRestart:
    if u.active in {asInactive, asFailed} and not unitBusy(u):
      j.typ = jtStart
      runStart(m, j)
    elif u.ops.stop == nil: m.finishJob(j, jrUnsupported)
    else:
      j.restartStopPhase = true
      j.state = jsRunning
      u.ops.stop(m, u)
  of jtTryRestart, jtTryReload, jtTryReloadOrStart:
    m.finishJob(j, jrDone)

proc blocked(m: Manager; j: Job): bool =
  ## §7.4.7: a job waits for the jobs of units ordered before it when it is an
  ## up job, and for every down job of a unit ordered after it.
  if j.ignoreOrder or j.typ == jtNop: return false
  let u = j.unit
  if j.typ.isUp or (j.typ == jtReloadOrStart):
    for id in m.orderedBefore(u):
      let other = m.units.getOrDefault(id)
      if other != nil and other.job != nil and other.job != j and other.job.typ != jtNop:
        return true
  for id in m.orderedAfter(u):
    let other = m.units.getOrDefault(id)
    if other != nil and other.job != nil and other.job != j and other.job.isDown:
      return true
  false

proc runScheduler*(m: Manager) =
  if m.scheduling:
    m.schedulingAgain = true
    return
  m.scheduling = true
  try:
    var progress = true
    while progress:
      progress = false
      m.schedulingAgain = false
      var ids = toSeq(m.jobs.keys)
      ids.sort()
      for id in ids:
        let j = m.jobs.getOrDefault(id)
        if j == nil or j.state != jsWaiting: continue
        if blocked(m, j): continue
        runJob(m, j)
        progress = true
      if m.schedulingAgain: progress = true
  finally:
    m.scheduling = false

# ---- installing ------------------------------------------------------------------
proc armTimeout(m: Manager; j: Job) =
  let t = j.unit.def.common.jobTimeoutUsec
  if t != Infinity:
    j.timeoutTimer = m.loop.addTimerIn(t, proc() =
      if m.jobs.hasKey(j.id): m.finishJob(j, jrTimeout))

proc installTransaction*(m: Manager; tr: Transaction;
                         waiter: proc(o: JobOutcome) {.closure.} = nil;
                         installedOut: ptr seq[Job] = nil): Job =
  ## Steps 7 and 8. All or nothing: every conflict is detected before the
  ## first change. Returns the anchor's installed job, or nil when the anchor
  ## completed immediately (`nop`); in that case `waiter` was called.
  let anchor = tr.anchor
  let live = tr.live
  if anchor.typ == jtNop:
    if waiter != nil: waiter(JobOutcome(result: jrDone, unit: anchor.unit.id, state: anchor.unit.active))
    return nil
  if m.jobs.len + live.len > MaxJobs: fail(ecLimit, "Too many jobs.")
  # check
  var cancels: seq[Job]
  var merges: seq[(Job, TJob, JobType)]
  var fresh: seq[TJob]
  if tr.mode == jmFlush:
    for j in toSeq(m.jobs.values):
      if j.state != jsRunning: cancels.add j
  for tj in live:
    let existing = tj.unit.job
    if existing == nil or existing in cancels:
      fresh.add tj
      continue
    let merged = mergeTypes(existing.typ, tj.typ)
    if merged.isSome:
      merges.add (existing, tj, merged.get)
    elif tr.mode == jmFail:
      fail(ecUnitState, "Transaction for " & anchor.unit.id & "/" & $anchor.typ &
        " is destructive (" & tj.unit.id & "/" & $tj.typ & " has '" & $existing.typ &
        "' job queued, but '" & $tj.typ & "' is included in transaction)")
    elif existing.irreversible:
      fail(ecUnitState, "Transaction for " & anchor.unit.id & "/" & $anchor.typ &
        " is destructive (" & tj.unit.id & " has an irreversible '" & $existing.typ & "' job)")
    else:
      cancels.add existing
      fresh.add tj
  # apply
  for c in cancels: m.finishJob(c, jrCanceled)
  var installed = initTable[TJob, Job]()
  for (existing, tj, merged) in merges:
    if existing.typ == jtStart and existing.state == jsRunning and merged == jtRestart:
      existing.typ = jtRestart
      existing.restartStopPhase = true
      if existing.unit.ops.stop != nil: existing.unit.ops.stop(m, existing.unit)
    else:
      existing.typ = merged
    existing.matters = existing.matters or tj.matters
    installed[tj] = existing
  for tj in fresh:
    inc m.jobSeq
    let j = Job(id: m.jobSeq, unit: tj.unit, typ: tj.typ, state: jsWaiting, matters: tj.matters,
      irreversible: tr.mode == jmReplaceIrreversibly, ignoreOrder: tr.mode == jmIgnoreDependencies,
      origin: tr.origin, installedUsec: m.clock.monoUsec)
    m.jobs[j.id] = j
    tj.unit.job = j
    installed[tj] = j
    m.armTimeout(j)
    if m.jobInstalledHook != nil:
      try: m.jobInstalledHook(j)
      except CatchableError as e: logErr(tj.unit.id, "job hook failed: " & e.msg)
    if m.notifier != nil: m.dirty.incl tj.unit.id
  if installedOut != nil:             # before the scheduler can install further jobs
    for j in installed.values:
      if j notin installedOut[]: installedOut[].add j
  result = installed.getOrDefault(anchor)
  if result != nil and waiter != nil: result.waiters.add waiter
  m.runScheduler()

# ---- submitting (admission, §7.4.3 step 0) ---------------------------------------
proc admit*(m: Manager; u: Unit; typ: JobType; mode: JobMode; origin: JobOrigin) =
  ## Raises `CoreError` when the request must be refused before any job is built.
  let c = u.def.common
  case c.loadState
  of lsMasked: fail(ecUnitState, "Unit " & u.id & " is masked.")
  of lsBadSetting, lsError:
    for d in c.diagnostics:
      if d.code == "E_UNSUPPORTED" and d.severity == sevError:
        fail(ecUnsupported, "Unit " & u.id & " uses unsupported feature " & d.key & ".")
    fail(ecUnitState, "Unit " & u.id & " has a bad setting: " & c.loadError)
  of lsNotFound: fail(ecNotFound, "Unit " & u.id & " not found.")
  else: discard
  let starting = typ in {jtStart, jtRestart, jtReloadOrStart, jtTryRestart, jtTryReloadOrStart}
  if m.stopping and starting and not m.allowStart: fail(ecShutdown, "Manager is shutting down.")
  if origin == joManual:
    if starting and c.refuseManualStart:
      fail(ecUnitState, "Operation refused, unit " & u.id & " may be requested by dependency only.")
    if typ == jtStop and c.refuseManualStop:
      fail(ecUnitState, "Operation refused, unit " & u.id & " may be requested by dependency only.")
  let notApplicable = "Job type " & $typ & " is not applicable for unit " & u.id & "."
  if u.kind == ukDevice and origin == joManual and typ in {jtStart, jtStop, jtRestart}:
    fail(ecUnsupported, notApplicable)
  if typ == jtReload and (u.ops.canReload == nil or not u.ops.canReload(u)):
    fail(ecUnsupported, notApplicable)
  if mode == jmIsolate:
    if typ != jtStart or u.kind != ukTarget or not c.allowIsolate:
      fail(ecUnsupported, notApplicable)

proc submitJob*(m: Manager; u: Unit; typ: JobType; mode: JobMode; origin: JobOrigin;
                waiter: proc(o: JobOutcome) {.closure.} = nil;
                installedOut: ptr seq[Job] = nil): Job =
  ## Admission, transaction build and install. Raises `CoreError`. Returns the
  ## installed (or merged-into) job; nil if the job completed immediately, in
  ## which case `waiter` has already been called.
  m.admit(u, typ, mode, origin)
  let tr = buildTransaction(m, u, typ, mode, origin)
  installTransaction(m, tr, waiter, installedOut)
