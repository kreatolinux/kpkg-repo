## Condition and assertion evaluation (spec §7.3). Reads the system through
## `Roots` (so tests point it at fixtures) and the manager environment.
## Virtualization, security, firmware, ACPower, CPUFeature and NeedsUpdate are
## deferred: they evaluate false and log one warning.
import std/[os, posix, strutils, tables, options]
import ../common/[roots, logging, fdutil]
import ../unitfile/model
import ./types

type Facts* = object
  ## Everything a condition may observe, gathered from the roots and manager.
  roots*: Roots
  env*: Table[string, string]
  firstBoot*: bool
  hostname*, machineId*: string
  uid*, gid*: int
  username*: string

const CapNames = ["CAP_CHOWN", "CAP_DAC_OVERRIDE", "CAP_DAC_READ_SEARCH", "CAP_FOWNER", "CAP_FSETID",
  "CAP_KILL", "CAP_SETGID", "CAP_SETUID", "CAP_SETPCAP", "CAP_LINUX_IMMUTABLE",
  "CAP_NET_BIND_SERVICE", "CAP_NET_BROADCAST", "CAP_NET_ADMIN", "CAP_NET_RAW", "CAP_IPC_LOCK",
  "CAP_IPC_OWNER", "CAP_SYS_MODULE", "CAP_SYS_RAWIO", "CAP_SYS_CHROOT", "CAP_SYS_PTRACE",
  "CAP_SYS_PACCT", "CAP_SYS_ADMIN", "CAP_SYS_BOOT", "CAP_SYS_NICE", "CAP_SYS_RESOURCE",
  "CAP_SYS_TIME", "CAP_SYS_TTY_CONFIG", "CAP_MKNOD", "CAP_LEASE", "CAP_AUDIT_WRITE",
  "CAP_AUDIT_CONTROL", "CAP_SETFCAP", "CAP_MAC_OVERRIDE", "CAP_MAC_ADMIN", "CAP_SYSLOG",
  "CAP_WAKE_ALARM", "CAP_BLOCK_SUSPEND", "CAP_AUDIT_READ", "CAP_PERFMON", "CAP_BPF",
  "CAP_CHECKPOINT_RESTORE"]

proc getgroupsC(n: cint; list: ptr Gid): cint {.importc: "getgroups", header: "<unistd.h>".}

proc gatherFacts*(m: Manager): Facts =
  var host = newString(256)
  discard gethostname(cstring(host), 255)
  host.setLen(cstring(host).len)
  let pw = getpwuid(geteuid())
  Facts(roots: m.roots, env: m.env, firstBoot: m.firstBoot, hostname: host,
    machineId: m.machineId, uid: int(geteuid()), gid: int(getegid()),
    username: if pw != nil: $pw.pw_name else: "")

proc native(): string =
  when defined(amd64): "x86-64"
  elif defined(arm64): "arm64"
  elif defined(i386): "x86"
  elif defined(riscv64): "riscv64"
  elif defined(powerpc64): "ppc64"
  else: hostCPU

proc globMatch(pattern, s: string): bool = fnmatch(pattern.cstring, s.cstring, 0) == 0

proc compare(op: string; a, b: int64): bool =
  case op
  of ">=": a >= b
  of "<=": a <= b
  of ">": a > b
  of "<": a < b
  of "!=": a != b
  else: a == b

proc splitOp(value: string): (string, string) =
  let v = value.strip
  for op in [">=", "<=", "!=", "=", ">", "<"]:
    if v.startsWith(op): return (op, v[op.len .. ^1].strip)
  ("=", v)

proc versionCompare(a, b: string): int =
  ## Dotted numeric comparison (`6.1.0-13` vs `5.10`).
  proc parts(s: string): seq[int] =
    for p in s.split({'.', '-', '+', '_'}):
      var n = 0
      var any = false
      for c in p:
        if c.isDigit: n = n * 10 + ord(c) - ord('0'); any = true
        else: break
      if any: result.add n
  let (pa, pb) = (parts(a), parts(b))
  for i in 0 ..< max(pa.len, pb.len):
    let x = if i < pa.len: pa[i] else: 0
    let y = if i < pb.len: pb[i] else: 0
    if x != y: return cmp(x, y)

proc readText(path: string): string =
  try: readFile(path) except IOError: ""

proc capBounding(f: Facts): uint64 =
  for line in readText(f.roots.procfs / "self/status").splitLines:
    if line.startsWith("CapBnd:"):
      try: return parseHexInt(line.split(':')[1].strip).uint64
      except ValueError: discard
  0

proc isMountPoint(f: Facts; path: string): bool =
  let want = path.strip(chars = {'/'}, leading = false)
  let target = if want.len == 0: "/" else: want
  for line in readText(f.roots.mountinfo).splitLines:
    let parts = line.split(' ')
    if parts.len > 4 and parts[4] == target: return true

var warned: seq[ConditionKind]

proc test(f: Facts; c: Condition): bool =
  let v = c.value
  case c.kind
  of ckPathExists: return v.len > 0 and (nodeExists(v) or symlinkExists(v))
  of ckPathExistsGlob:
    for _ in walkPattern(v): return true
    return false
  of ckPathIsDirectory: return dirExists(v)
  of ckPathIsSymbolicLink: return symlinkExists(v)
  of ckPathIsMountPoint: return isMountPoint(f, v)
  of ckPathIsReadWrite: return access(v.cstring, W_OK) == 0
  of ckDirectoryNotEmpty:
    if not dirExists(v): return false
    for _ in walkDir(v): return true
    return false
  of ckFileNotEmpty:
    try: return fileExists(v) and getFileSize(v) > 0 except OSError: return false
  of ckFileIsExecutable: return fileExists(v) and access(v.cstring, X_OK) == 0
  of ckPathIsEncrypted, ckCredential: return false
  of ckUser:
    if v == "@system": return f.uid in 1 .. 999
    if v.allCharsInSet({'0'..'9'}): return f.uid == parseInt(v)
    return f.username == v
  of ckGroup:
    var gids = newSeq[Gid](64)
    let n = getgroupsC(cint(gids.len), addr gids[0])
    for i in 0 ..< max(0, int(n)):
      if v.allCharsInSet({'0'..'9'}):
        if int(gids[i]) == parseInt(v): return true
      else:
        let gr = getgrgid(gids[i])
        if gr != nil and $gr.gr_name == v: return true
    return f.gid == (if v.allCharsInSet({'0'..'9'}): parseInt(v) else: -1)
  of ckEnvironment:
    let eq = v.find('=')
    if eq < 0: return f.env.hasKey(v)
    return f.env.getOrDefault(v[0 ..< eq], "\0") == v[eq + 1 .. ^1]
  of ckKernelCommandLine:
    for word in readText(f.roots.cmdline).splitWhitespace:
      if word == v: return true
      if v.find('=') < 0 and word.startsWith(v & "="): return true
    return false
  of ckArchitecture: return v == "native" or v == native()
  of ckHost:
    if v.len == 32 and v.allCharsInSet(HexDigits): return v.toLowerAscii == f.machineId
    return globMatch(v, f.hostname)
  of ckFirstBoot: return f.firstBoot == (v.toLowerAscii in ["1", "yes", "true", "on"])
  of ckCapability:
    let i = CapNames.find(v.toUpperAscii)
    return i >= 0 and ((capBounding(f) shr i) and 1) == 1
  of ckMemory:
    var total = 0'i64
    for line in readText(f.roots.procfs / "meminfo").splitLines:
      if line.startsWith("MemTotal:"):
        total = parseInt(line.splitWhitespace[1]).int64 * 1024
    let (op, rhs) = splitOp(v)
    var size = 0'i64
    var mult = 1'i64
    var num = rhs
    if rhs.len > 0 and rhs[^1] in {'K', 'M', 'G', 'T'}:
      mult = case rhs[^1]
        of 'K': 1024'i64
        of 'M': 1024'i64 * 1024
        of 'G': 1024'i64 * 1024 * 1024
        else: 1024'i64 * 1024 * 1024 * 1024
      num = rhs[0 ..< rhs.len - 1]
    try: size = parseBiggestInt(num) * mult except ValueError: return false
    return compare(op, total, size)
  of ckCPUs:
    let (op, rhs) = splitOp(v)
    try: return compare(op, sysconf(SC_NPROCESSORS_ONLN).int64, parseBiggestInt(rhs))
    except ValueError: return false
  of ckKernelVersion:
    var uts: Utsname
    discard uname(uts)
    let release = $cast[cstring](addr uts.release[0])
    let (op, rhs) = splitOp(v)
    if op == "=" and ('*' in rhs or '?' in rhs): return globMatch(rhs, release)
    let r = versionCompare(release, rhs)
    return compare(op, r, 0)
  of ckOSRelease:
    var text = readText(f.roots.osRelease)
    if text.len == 0: text = readText(f.roots.usrLib / "os-release")
    let parts = v.splitWhitespace
    let (key, op, rhs) = block:
      let eq = v.find('=')
      let first = v.find({'=', '!', '<', '>'})
      if first < 0: ("", "", "")
      else:
        var op = ""
        var j = first
        while j < v.len and v[j] in {'=', '!', '<', '>'}: op.add v[j]; inc j
        (v[0 ..< first].strip, op, v[j .. ^1].strip(chars = {' ', '"'}))
    discard parts
    for line in text.splitLines:
      let eq = line.find('=')
      if eq > 0 and line[0 ..< eq] == key:
        let have = line[eq + 1 .. ^1].strip(chars = {'"', '\''})
        case op
        of "=", "==": return have == rhs
        of "!=": return have != rhs
        of ">=", "<=", ">", "<": return compare(op, versionCompare(have, rhs), 0)
        else: return false
    return false
  of ckControlGroupController:
    if v == "v2": return fileExists(f.roots.cgroupMount / "cgroup.controllers")
    return v in readText(f.roots.cgroupMount / "cgroup.controllers").splitWhitespace
  of ckKernelModuleLoaded: return dirExists(f.roots.sysfs / "module" / v)
  of ckFirmware, ckVirtualization, ckSecurity, ckACPower, ckNeedsUpdate, ckCPUFeature:
    if c.kind notin warned:
      warned.add c.kind
      logWarn("", "Condition" & $c.kind & "= is not supported by this release; evaluates to false")
    return false

proc conditionText*(c: Condition): string =
  (if c.isAssert: "Assert" else: "Condition") & $c.kind & "=" &
    (if c.trigger: "|" else: "") & (if c.negate: "!" else: "") & c.value

proc holds*(f: Facts; c: Condition): bool = test(f, c) != c.negate

type CheckResult* = object
  ok*: bool
  failed*: string          ## text of the first failing condition
  isAssert*: bool

proc checkGroup(f: Facts; conds: seq[Condition]; asserts: bool): Option[string] =
  ## None when every non-trigger condition holds and (if any) one trigger does.
  var anyTrigger, triggerOk = false
  var firstFail = ""
  for c in conds:
    if c.isAssert != asserts: continue
    let ok = holds(f, c)
    if c.trigger:
      anyTrigger = true
      if ok: triggerOk = true
      elif firstFail.len == 0: firstFail = conditionText(c)
    elif not ok: return some(conditionText(c))
  if anyTrigger and not triggerOk: return some(firstFail)
  none(string)

proc checkConditions*(f: Facts; conds: seq[Condition]): CheckResult =
  ## Assertions first (a failed assertion fails the job, a failed condition
  ## only skips it).
  let a = checkGroup(f, conds, true)
  if a.isSome: return CheckResult(ok: false, failed: a.get, isAssert: true)
  let c = checkGroup(f, conds, false)
  if c.isSome: return CheckResult(ok: false, failed: c.get)
  CheckResult(ok: true)
