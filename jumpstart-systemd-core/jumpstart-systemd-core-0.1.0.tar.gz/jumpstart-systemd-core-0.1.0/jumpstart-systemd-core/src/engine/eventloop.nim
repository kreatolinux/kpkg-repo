## Single-threaded poll(2) event loop: descriptor watches, one-shot timers on
## the monotonic clock, and deferred callbacks (spec §3.2, §18.2.3).
## `poll` instead of `epoll` keeps the loop portable (macOS tests) and is
## ample for the number of descriptors a service manager watches.
import std/[heapqueue, tables]
import std/posix except Clock
import ../common/clock

type
  WatchId* = distinct int
  TimerId* = distinct int
  FdCallback* = proc(revents: uint32) {.closure.}
  Watch = object
    fd: cint
    events: uint32
    cb: FdCallback
  EventLoop* = ref object
    clock*: Clock
    watches: Table[int, Watch]
    timers: HeapQueue[(int64, int)]
    timerCbs: Table[int, proc() {.closure.}]
    deferred: seq[proc() {.closure.}]
    nextId: int
    stopRequested: bool

const
  EvIn* = 0x001'u32   ## POLLIN, POLLPRI, POLLOUT, POLLERR, POLLHUP are the
  EvPri* = 0x002'u32  ## same on Linux and macOS
  EvOut* = 0x004'u32
  EvErr* = 0x008'u32
  EvHup* = 0x010'u32

proc `==`*(a, b: WatchId): bool {.borrow.}
proc `==`*(a, b: TimerId): bool {.borrow.}
proc isSet*(t: TimerId): bool = int(t) != 0

proc newEventLoop*(clock: Clock = newClock()): EventLoop =
  EventLoop(clock: clock, nextId: 1)

proc addFd*(l: EventLoop; fd: cint; events: uint32; cb: FdCallback): WatchId =
  let id = l.nextId
  inc l.nextId
  l.watches[id] = Watch(fd: fd, events: events, cb: cb)
  WatchId(id)

proc modFd*(l: EventLoop; id: WatchId; events: uint32) =
  if l.watches.hasKey(int(id)): l.watches[int(id)].events = events

proc delFd*(l: EventLoop; id: WatchId) = l.watches.del(int(id))

proc addTimer*(l: EventLoop; atMonoUsec: int64; cb: proc() {.closure.}): TimerId =
  let id = l.nextId
  inc l.nextId
  l.timers.push((atMonoUsec, id))
  l.timerCbs[id] = cb
  TimerId(id)

proc addTimerIn*(l: EventLoop; afterUsec: int64; cb: proc() {.closure.}): TimerId =
  l.addTimer(l.clock.monoUsec + afterUsec, cb)

proc cancelTimer*(l: EventLoop; id: TimerId) =
  ## Safe on fired or already-cancelled timers.
  l.timerCbs.del(int(id))

proc afterEvent*(l: EventLoop; cb: proc() {.closure.}) = l.deferred.add cb

proc stop*(l: EventLoop) = l.stopRequested = true

proc runDeferred(l: EventLoop) =
  while l.deferred.len > 0:
    let batch = l.deferred
    l.deferred = @[]
    for cb in batch: cb()

proc fireDueTimers*(l: EventLoop): int =
  ## Runs every timer whose deadline has passed; returns how many fired.
  let now = l.clock.monoUsec
  while l.timers.len > 0 and l.timers[0][0] <= now:
    let (_, id) = l.timers.pop()
    var cb: proc() {.closure.}
    if l.timerCbs.take(id, cb):
      inc result
      cb()
      l.runDeferred()

proc nextTimeoutMs(l: EventLoop): int =
  while l.timers.len > 0 and not l.timerCbs.hasKey(l.timers[0][1]):
    discard l.timers.pop()          # drop cancelled heads
  if l.timers.len == 0: return -1
  let diff = l.timers[0][0] - l.clock.monoUsec
  if diff <= 0: 0 else: int(min((diff + 999) div 1000, 60_000))

proc runOnce*(l: EventLoop; maxWaitMs = -1) =
  ## One iteration: deferred callbacks, poll (bounded by the next timer and
  ## `maxWaitMs`), ready descriptors, due timers.
  l.runDeferred()
  var wait = l.nextTimeoutMs()
  if maxWaitMs >= 0 and (wait < 0 or maxWaitMs < wait): wait = maxWaitMs
  if l.deferred.len > 0: wait = 0
  var ids: seq[int]
  var fds: seq[TPollfd]
  for id, w in l.watches:
    ids.add id
    fds.add TPollfd(fd: w.fd, events: cshort(w.events), revents: 0)
  let base: ptr TPollfd = if fds.len == 0: nil else: addr fds[0]
  let n = poll(base, Tnfds(fds.len), cint(wait))
  if n > 0:
    for i in 0 ..< fds.len:
      if fds[i].revents != 0 and l.watches.hasKey(ids[i]):
        when defined(sdcTrace): stderr.writeLine "loop: fd " & $fds[i].fd & " revents " & $fds[i].revents
        let cb = l.watches[ids[i]].cb
        cb(uint32(fds[i].revents))
        l.runDeferred()
  discard l.fireDueTimers()
  l.runDeferred()

proc runLoop*(l: EventLoop) =
  l.stopRequested = false
  while not l.stopRequested:
    l.runOnce()

proc watchCount*(l: EventLoop): int = l.watches.len
proc timerCount*(l: EventLoop): int = l.timerCbs.len
