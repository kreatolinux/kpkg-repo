## Unit state notifications to Jumpstart (spec §4.8): a dirty set drained at
## most 100 times per second, failed units first, then oldest change.
import std/[tables, sets, algorithm]
import jumpstartcore/[protocol, jsonlines, names]
import ../common/logging
import ../unitfile/model
import ./[types, eventloop]

const
  TickUsec = 20_000
  PerTick = 2
  MaxDetail = 512

proc truncateUtf8*(s: string; limit: int): string =
  if s.len <= limit: return s
  var n = limit
  while n > 0 and (ord(s[n]) and 0xC0) == 0x80: dec n
  s[0 ..< n]

proc reportable*(u: Unit): bool =
  ## Only units addressable through Jumpstart operations (§13.3).
  u.kind notin {ukDevice, ukScope} and u.id != "-.slice" and
    not (u.kind in {ukMount, ukSwap} and u.def.common.source == usMountinfo) and
    validUnitName(u.id) and u.def.common.loadState != lsNotFound

proc startNotifier*(m: Manager; fd: cint; detailOf: proc(m: Manager; u: Unit): string) =
  ## Installs `m.notifier` writing protocol messages to `fd`, and the drain timer.
  m.notifier = proc(unit, state, detail: string) =
    try: writeAllFd(fd, encodeLine(notification(unit, state, detail)))
    except CatchableError as e: logWarn(unit, "notify failed: " & e.msg)
  proc tick() =
    var pending: seq[Unit]
    for id in m.dirty:
      let u = m.units.getOrDefault(id)
      if u != nil and u.reportable and u.jumpstartState != u.active.jumpstartState: pending.add u
    m.dirty.clear()
    # units whose state still differs stay dirty until reported
    pending.sort(proc(a, b: Unit): int =
      let fa = a.active == asFailed
      let fb = b.active == asFailed
      if fa != fb: return (if fa: -1 else: 1)
      cmp(a.since, b.since))
    var sent = 0
    for u in pending:
      if sent >= PerTick:
        m.dirty.incl u.id
        continue
      let state = u.active.jumpstartState
      m.notifier(u.id, state, truncateUtf8(detailOf(m, u), MaxDetail))
      u.jumpstartState = state
      inc sent
    discard m.loop.addTimerIn(TickUsec, tick)
  discard m.loop.addTimerIn(TickUsec, tick)
