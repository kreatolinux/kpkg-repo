## Power requests to Jumpstart (spec §8.7): the same request `jumpctl poweroff`
## sends on the Jumpstart system socket.
import std/[json, posix]
import ../common/[roots, logging, fdutil]
import ./types

proc readLineTimeout(fd: cint; ms: int): string =
  var buf: array[1, char]
  while true:
    var pfd = TPollfd(fd: fd, events: POLLIN)
    if poll(addr pfd, 1, cint(ms)) <= 0: return
    if read(fd, addr buf[0], 1) <= 0: return
    if buf[0] == '\n': return
    result.add buf[0]

proc requestPowerViaJumpstart*(roots: Roots; action: PowerAction): bool =
  ## True when Jumpstart answered `status: ok`.
  case action
  of paExit:
    if roots.scope != scUser:
      logWarn("", "exit is only meaningful in user scope; ignored")
      return false
    return kill(getppid(), SIGTERM) == 0
  of paKexec:
    logWarn("", "kexec is not supported by Jumpstart; rebooting instead")
    return requestPowerViaJumpstart(roots, paReboot)
  else: discard
  if roots.scope == scUser: return false
  let fd = connectUnix(roots.jumpstartSocket)
  if fd < 0:
    logErr("", "cannot reach Jumpstart at " & roots.jumpstartSocket)
    return false
  defer: discard close(fd)
  let req = $(%*{"client": {"name": "systemd-compat", "version": "0.1.0"},
                 "power": {"action": $action}}) & "\n"
  if write(fd, req.cstring, req.len) != req.len: return false
  let line = readLineTimeout(fd, 5000)
  try: parseJson(line){"status"}.getStr == "ok"
  except CatchableError: false
