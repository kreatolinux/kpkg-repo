## The facade the control protocol and tools use (spec §18.2.3): resolve,
## status, listings, show/cat, dependency trees, job submission, file
## operations. Returns JSON shaped as the `sdc/1` results of §4.3.
import std/[json, options, strutils, tables, sets, sequtils, algorithm, times, posix]
import jumpstartcore/errors
import ../common/[names]
import ../unitfile/[model, index, loader, properties]
import ./[types, graph, jobs]

proc subsystemOf*(kind: UnitKind): string =
  case kind
  of ukService: "service"
  of ukSocket: "socket"
  of ukTimer: "timer"
  of ukPath: "path"
  of ukMount, ukAutomount: "mount"
  of ukSwap: "swap"
  of ukTarget, ukSlice: "target"
  of ukDevice, ukScope: ""

proc rfc3339*(usec: int64): string =
  if usec <= 0: return ""
  let t = fromUnix(usec div 1_000_000).utc
  t.format("yyyy-MM-dd'T'HH:mm:ss") & "." & align($(usec mod 1_000_000), 6, '0') & "Z"

proc jumpstartEnablement*(s: EnablementState): string =
  ## §13.1.
  case s
  of esEnabled, esEnabledRuntime: "enabled"
  of esLinked, esLinkedRuntime, esDisabled, esBad, esNotFound: "disabled"
  of esMasked, esMaskedRuntime: "masked"
  of esStatic: "static"
  of esIndirect: "indirect"
  of esGenerated, esTransient: "generated"
  of esAlias: "disabled"

proc enablementOf*(m: Manager; u: Unit): EnablementState =
  if u.def.common.loadState == lsMasked: return esMasked
  if u.def.common.source in {usGenerated, usMountinfo, usFstab}: return esGenerated
  if u.def.common.source == usTransient: return esTransient
  if u.def.common.source == usBuiltin: return esStatic
  if m.index == nil: return esStatic
  index.enablementOf(m.index, u.id)

proc quoteStatus(s: string): string = "\"" & s.replace("\\", "\\\\").replace("\"", "\\\"") & "\""

proc unitDetail*(m: Manager; u: Unit): string =
  ## §13.1: `sub=..; result=..; load=..; since=..; ...`, at most 512 bytes.
  var pairs: seq[string]
  var status = ""
  pairs.add "sub=" & u.sub
  if u.kind == ukService or u.active == asFailed: pairs.add "result=" & u.result
  if u.def.common.loadState != lsLoaded: pairs.add "load=" & $u.def.common.loadState
  if u.since > 0: pairs.add "since=" & rfc3339(u.since)
  var ex = StatusExtras(exitCode: -1)
  if u.ops.status != nil: ex = u.ops.status(m, u)
  if ex.nRestarts > 0: pairs.add "restarts=" & $ex.nRestarts
  if u.job != nil: pairs.add "job=" & u.job.jobInfoText
  if u.failedCondition.len > 0 and u.active == asInactive: pairs.add "condition=" & u.failedCondition
  if m.index != nil and (u.needDaemonReload or fileChanged(m.index, u.def)): pairs.add "reload=needed"
  if ex.statusText.len > 0: status = "status=" & quoteStatus(ex.statusText)
  var text = (pairs & (if status.len > 0: @[status] else: @[])).join("; ")
  while text.len > 512 and pairs.len > 2:
    pairs.setLen(pairs.len - 1)
    status = ""
    text = pairs.join("; ")
  if text.len > 512:
    var n = 511
    while n > 0 and (ord(text[n]) and 0xC0) == 0x80: dec n
    text = text[0 ..< n] & "\xe2\x80\xa6"
  text

proc reportableName(u: Unit): bool = u.kind notin {ukDevice, ukScope} and u.id != "-.slice"

# ---- members, resolve, list -----------------------------------------------------
proc members*(m: Manager; u: Unit): seq[string] =
  var seen = initHashSet[string]()
  var todo = @[u.id]
  while todo.len > 0:
    let id = todo.pop()
    let x = m.lookup(id)
    if x == nil: continue
    for n in m.depUnits(x, [dkRequires, dkRequisite, dkWants, dkBindsTo, dkUpholds]):
      if not seen.containsOrIncl(n):
        let y = m.lookup(n)
        if y != nil and y.kind != ukDevice: todo.add n
  for n in seen:
    let y = m.units.getOrDefault(n)
    if y != nil and y.reportableName: result.add n
  result.sort()

proc resolve*(m: Manager; name: string): JsonNode =
  ## §13.3: owned names only; templates and devices/scopes are not owned.
  let mangled = if kindOfSuffix(suffixOf(name)).isSome: name
                elif name.endsWith("@"): name & ".service"
                else: name & ".service"
  let notOwned = %*{"owned": false, "name": name, "subsystem": ""}
  let p = parseUnitName(mangled)
  if p.isNone or p.get.isTemplate or p.get.kind in {ukDevice, ukScope}: return notOwned
  if p.get.isInstance and p.get.instance.len == 0: return notOwned
  var u = m.lookup(mangled)
  if u == nil or u.def.common.loadState == lsNotFound: return notOwned
  %*{"owned": true, "name": u.id, "subsystem": subsystemOf(u.kind), "kind": $u.kind,
     "load_state": $u.def.common.loadState, "aliases": u.def.common.names.filterIt(it != u.id),
     "fragment_path": u.def.common.fragmentPath}

proc statusJson*(m: Manager; u: Unit): JsonNode =
  var ex = StatusExtras(exitCode: -1)
  if u.ops.status != nil: ex = u.ops.status(m, u)
  let state = if u.def.common.loadState in {lsMasked, lsBadSetting, lsError}: "inactive"
              else: u.active.jumpstartState
  result = %*{"state": state, "detail": unitDetail(m, u),
              "enablement": jumpstartEnablement(enablementOf(m, u)),
              "substate": u.sub, "result": (if u.result.len > 0: u.result else: "success")}
  if u.since > 0: result["since"] = %rfc3339(u.since)
  case u.kind
  of ukService:
    if ex.mainPid > 0: result["main_pid"] = %ex.mainPid
    result["pids"] = %ex.pids.sorted
    if ex.exitCode >= 0: result["exit_code"] = %ex.exitCode
  of ukTarget, ukSlice: result["members"] = %members(m, u)
  of ukSocket: result["listen"] = %ex.listen
  of ukMount:
    result["source"] = %u.def.mount.what
    result["target"] = %u.def.mount.where
    result["fstype"] = %u.def.mount.typ
  of ukTimer:
    for (k, v) in ex.extra:
      if k in ["next_run", "last_run"]: result[k] = %rfc3339(parseBiggestInt(v))
  of ukSwap:
    result["device"] = %u.def.swap.what
    for (k, v) in ex.extra:
      if k == "priority": result[k] = %parseInt(v)
  of ukPath:
    result["watches"] = %newSeq[string]()
    result["triggers"] = %""
    for (k, v) in ex.extra:
      if k == "watches": result[k] = %v.splitLines
      elif k == "triggers": result[k] = %v
  else: discard

proc listRows*(m: Manager; states, types, patterns: seq[string]; all: bool): seq[JsonNode] =
  var names = initHashSet[string]()
  for u in m.allUnits: names.incl u.id
  if all and m.index != nil:
    for e in listNames(m.index):
      if not e.isAlias and e.kind != ukDevice: names.incl e.name
  for n in toSeq(names).sorted:
    let u = m.lookup(n)
    if u == nil: continue
    if types.len > 0 and $u.kind notin types and u.kind.subsystemOf notin types: continue
    if patterns.len > 0 and not patterns.anyIt(fnmatch(it.cstring, n.cstring, 0) == 0): continue
    let active = u.active.jumpstartState
    if states.len > 0 and active notin states and u.sub notin states and $u.active notin states: continue
    if not all and u.active == asInactive and u.job == nil and u.def.common.loadState == lsLoaded and
        patterns.len == 0 and states.len == 0: continue
    var row = %*{"name": u.id, "load": $u.def.common.loadState, "active": $u.active, "sub": u.sub,
                 "description": u.def.common.description}
    if u.job != nil:
      row["job_id"] = %u.job.id
      row["job_type"] = %($u.job.typ)
    result.add row

proc fileRows*(m: Manager; types, states, patterns: seq[string]): seq[JsonNode] =
  for e in listNames(m.index):
    if e.isAlias and e.state != esAlias: continue
    if types.len > 0 and suffixOf(e.name)[1 .. ^1] notin types: continue
    if states.len > 0 and $e.state notin states: continue
    if patterns.len > 0 and not patterns.anyIt(fnmatch(it.cstring, e.name.cstring, 0) == 0): continue
    result.add %*{"name": e.name, "path": e.fragment, "state": $e.state,
                  "subsystem": subsystemOf(e.kind), "enablement": jumpstartEnablement(e.state)}

proc unitListForJumpstart*(m: Manager): seq[JsonNode] =
  ## §13.4: files, link-farm instances and in-memory units; no mirrors/devices.
  var seen = initHashSet[string]()
  for e in listNames(m.index):
    if e.isAlias or e.kind in {ukDevice, ukScope}: continue
    let p = parseUnitName(e.name).get
    if p.isTemplate or e.name == "-.slice" or e.name == "-.mount": continue
    seen.incl e.name
    result.add %*{"name": e.name, "subsystem": subsystemOf(e.kind),
                  "enablement": jumpstartEnablement(e.state)}
  for u in m.allUnits:
    if u.id in seen or u.kind in {ukDevice, ukScope} or u.id == "-.slice" or u.id == "-.mount": continue
    if u.def.common.source in {usMountinfo, usBuiltin} and u.kind != ukTarget: continue
    if u.def.common.loadState == lsNotFound: continue
    result.add %*{"name": u.id, "subsystem": subsystemOf(u.kind),
                  "enablement": jumpstartEnablement(enablementOf(m, u))}
  result.sort(proc(a, b: JsonNode): int = cmp(a["name"].getStr, b["name"].getStr))

# ---- show / cat / deps ----------------------------------------------------------
proc depNames(u: Unit; k: DepKind): seq[string] = u.def.common.deps[k] & u.def.common.implicitDeps[k]

proc showProps*(m: Manager; u: Unit): seq[(string, string)] =
  let c = u.def.common
  result = @[("Id", u.id), ("Names", c.names.join(" ")), ("Description", c.description),
    ("LoadState", $c.loadState), ("ActiveState", $u.active), ("SubState", u.sub),
    ("FragmentPath", c.fragmentPath), ("SourcePath", c.sourcePath),
    ("DropInPaths", c.dropInPaths.join(" ")),
    ("UnitFileState", $enablementOf(m, u)),
    ("StateChangeTimestamp", rfc3339(u.since)),
    ("NeedDaemonReload", if m.index != nil and fileChanged(m.index, u.def): "yes" else: "no"),
    ("Job", if u.job != nil: $u.job.id else: "0"),
    ("ConditionResult", if u.conditionResult: "yes" else: "no"),
    ("CanStart", "yes"), ("CanStop", "yes"),
    ("CanReload", if u.ops.canReload != nil and u.ops.canReload(u): "yes" else: "no"),
    ("StopWhenUnneeded", if c.stopWhenUnneeded: "yes" else: "no"),
    ("RefuseManualStart", if c.refuseManualStart: "yes" else: "no"),
    ("RefuseManualStop", if c.refuseManualStop: "yes" else: "no"),
    ("AllowIsolate", if c.allowIsolate: "yes" else: "no"),
    ("DefaultDependencies", if c.defaultDependencies: "yes" else: "no"),
    ("InvocationID", "")]
  for k in DepKind:
    let v = depNames(u, k)
    if v.len > 0: result.add ($k, v.join(" "))
  for (k, rev) in [(dkRequires, "RequiredBy"), (dkWants, "WantedBy"), (dkBindsTo, "BoundBy"),
                   (dkPartOf, "ConsistsOf"), (dkConflicts, "ConflictedBy"), (dkTriggers, "TriggeredBy")]:
    let v = m.reverseDeps(u.id, k)
    if v.len > 0: result.add (rev, v.join(" "))
  var have = initHashSet[string]()
  for (k, v) in result: have.incl k
  if u.ops.properties != nil:
    for (k, v) in u.ops.properties(m, u):
      result.add (k, v)
      have.incl k
  for (k, v) in definitionProperties(u.def):
    if k notin have: result.add (k, v)

proc catUnit*(m: Manager; u: Unit): JsonNode =
  var files = newJArray()
  for p in @[u.def.common.fragmentPath] & u.def.common.dropInPaths:
    if p.len == 0: continue
    files.add %*{"path": p, "text": (try: readFile(p) except IOError: "")}
  %*{"name": u.id, "files": files}

proc depTree*(m: Manager; u: Unit; reverse, all: bool; depth = 0; seen: var HashSet[string]): JsonNode =
  result = %*{"name": u.id, "active": $u.active, "children": newJArray()}
  if depth > 32: return
  let kinds = [dkRequires, dkRequisite, dkWants, dkBindsTo, dkUpholds]
  let kids = if reverse: m.reverseUnits(u, kinds) else: m.depUnits(u, kinds)
  for n in kids:
    let c = m.lookup(n)
    if c == nil: continue
    if n in seen:
      result["children"].add %*{"name": n, "active": $c.active, "children": newJArray()}
      continue
    seen.incl n
    if c.kind == ukTarget and not all and depth > 0:
      result["children"].add %*{"name": n, "active": $c.active, "children": newJArray()}
    else:
      result["children"].add depTree(m, c, reverse, all, depth + 1, seen)

# ---- jobs -----------------------------------------------------------------------
proc parseJobType*(s: string): Option[JobType] =
  for t in JobType:
    if $t == s: return some(t)

proc parseJobMode*(s: string): Option[JobMode] =
  for t in JobMode:
    if $t == s: return some(t)

proc jobFailure*(o: JobOutcome): (CoreErrorCode, string) =
  ## Appendix D.2.
  case o.result
  of jrDone, jrSkipped: (ecBackend, "")
  of jrCanceled: (ecCancelled, o.message)
  of jrInvalid, jrUnsupported: (ecUnsupported, o.message)
  of jrCollected: (ecUnitState, o.message)
  else:
    if o.code == "E_UNIT_STATE": (ecUnitState, o.message)
    elif o.code == "E_UNSUPPORTED": (ecUnsupported, o.message)
    elif o.code == "E_IO": (ecIo, o.message)
    else: (ecBackend, o.message)

proc unitOrFail*(m: Manager; name: string): Unit =
  let n = mangle(name)
  let u = m.lookup(n)
  if u == nil: raise newCoreError(ecNotFound, "Unit " & n & " not found.")
  u

proc systemState*(m: Manager): tuple[state: string, failed: seq[string], jobs: int] =
  result.jobs = m.jobs.len
  for u in m.allUnits:
    if u.active == asFailed: result.failed.add u.id
  result.state =
    if m.stopping: $ssStopping
    elif m.booting: $ssStarting
    elif result.failed.len > 0: $ssDegraded
    else: $ssRunning

proc fileOpResultJson*(r: FileOpResult): JsonNode =
  var changes = newJArray()
  for c in r.changes:
    case c.kind
    of fcSymlink: changes.add %*{"type": "symlink", "path": c.link, "destination": c.target}
    of fcUnlink: changes.add %*{"type": "unlink", "path": c.link}
    of fcMkdir, fcRmdir: discard
  var warnings = newJArray()
  for d in r.diags: warnings.add %d.message
  var states = newJObject()
  for (n, s) in r.states: states[n] = %($s)
  %*{"changes": changes, "enablement": states, "warnings": warnings}
