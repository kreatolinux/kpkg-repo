## The unit table and the dependency graph (spec §7.1, §7.2): lazy loading,
## alias resolution, forward and reverse dependency sets, ordering sets.
import std/[tables, sets, options, algorithm, sequtils, strutils]
import ../common/[names, clock]
import ../unitfile/[model, index]
import ./types

proc newUnit*(m: Manager; def: UnitDef): Unit =
  let c = def.common
  result = Unit(id: c.id, kind: def.kind, def: def, active: asInactive, sub: "dead",
    result: "success", conditionResult: true)
  result.startLimit = RateLimit(intervalUsec: c.startLimitIntervalUsec, burst: c.startLimitBurst)
  result.since = m.clock.realUsec
  result.jumpstartState = ""

proc register*(m: Manager; u: Unit) =
  m.units[u.id] = u
  for n in u.def.common.names:
    if n != u.id: m.aliases[n] = u.id
  m.reverseDirty = true
  if m.attachHook != nil: m.attachHook(m, u)

proc lookup*(m: Manager; name: string): Unit =
  ## The loaded unit for `name` (an id or an alias), loading it from the index
  ## on first use. Nil when no such unit exists. A masked or broken unit is
  ## returned with its load state set so callers can report it.
  let id = m.canonical(name)
  if m.units.hasKey(id): return m.units[id]
  if m.loadHook == nil: return nil
  let r = if m.index == nil: none(Resolved) else: resolveName(m.index, name)
  if r.isNone or r.get.id.endsWith(".device") and r.get.fragment.len == 0:
    # §11.8: device units exist implicitly, tracked by the existence of the node
    let pn = parseUnitName(name)
    if pn.isSome and pn.get.kind == ukDevice and not pn.get.isTemplate:
      let def = newUnitDef(ukDevice, name)
      def.common.source = usBuiltin
      def.common.description = name
      result = newUnit(m, def)
      m.register(result)
      return
    return nil
  if m.units.hasKey(r.get.id): return m.units[r.get.id]
  let def = m.loadHook(m, r.get.id)
  if def == nil or def.common.loadState == lsNotFound: return nil
  if def.common.id in m.masked: def.common.loadState = lsMasked
  result = newUnit(m, def)
  m.register(result)

proc depsOf*(m: Manager; u: Unit; kind: DepKind): seq[string] =
  ## Explicit, link-farm, implicit and in-memory edges of `u`, deduplicated.
  let c = u.def.common
  var seen = initHashSet[string]()
  for n in c.deps[kind] & c.implicitDeps[kind]:
    if not seen.containsOrIncl(n): result.add n
  for (k, a, b) in m.extraDeps:
    if k == kind and a == u.id and not seen.containsOrIncl(b): result.add b

proc rebuildReverse(m: Manager) =
  m.reverseCache.clear()
  for id, u in m.units:
    for k in DepKind:
      for t in m.depsOf(u, k):
        let target = m.canonical(t)
        m.reverseCache.mgetOrPut((k, target), @[]).add id
  for key, v in m.reverseCache.mpairs: v.sort()
  m.reverseDirty = false

proc reverseDeps*(m: Manager; name: string; kind: DepKind): seq[string] =
  ## Loaded units that list `name` under `kind`.
  if m.reverseDirty: rebuildReverse(m)
  m.reverseCache.getOrDefault((kind, m.canonical(name)))

proc depUnits*(m: Manager; u: Unit; kinds: openArray[DepKind]): seq[string] =
  ## Canonical ids across several kinds (forward), deduplicated, order kept.
  var seen = initHashSet[string]()
  for k in kinds:
    for n in m.depsOf(u, k):
      let id = m.canonical(n)
      if not seen.containsOrIncl(id): result.add id

proc reverseUnits*(m: Manager; u: Unit; kinds: openArray[DepKind]): seq[string] =
  var seen = initHashSet[string]()
  for k in kinds:
    for n in m.reverseDeps(u.id, k):
      if not seen.containsOrIncl(n): result.add n

proc requiredBy*(m: Manager; u: Unit): seq[string] = m.reverseUnits(u, [dkRequires, dkRequisite])
proc boundBy*(m: Manager; u: Unit): seq[string] = m.reverseUnits(u, [dkBindsTo])
proc consistsOf*(m: Manager; u: Unit): seq[string] = m.reverseUnits(u, [dkPartOf])
proc conflictsWith*(m: Manager; u: Unit): seq[string] = m.reverseUnits(u, [dkConflicts])

proc stopPropagatesTo*(m: Manager; u: Unit): seq[string] =
  var seen = initHashSet[string]()
  for id in m.depUnits(u, [dkPropagatesStopTo]) & m.reverseUnits(u, [dkStopPropagatedFrom]):
    if not seen.containsOrIncl(id): result.add id

proc reloadPropagatesTo*(m: Manager; u: Unit): seq[string] =
  var seen = initHashSet[string]()
  for id in m.depUnits(u, [dkPropagatesReloadTo]) & m.reverseUnits(u, [dkReloadPropagatedFrom]):
    if not seen.containsOrIncl(id): result.add id

proc orderedBefore*(m: Manager; u: Unit): HashSet[string] =
  ## Units that must be ordered before `u`: `u.After` plus the units that list
  ## `u` in `Before=`.
  result = initHashSet[string]()
  for n in m.depsOf(u, dkAfter): result.incl m.canonical(n)
  for n in m.reverseDeps(u.id, dkBefore): result.incl n

proc orderedAfter*(m: Manager; u: Unit): HashSet[string] =
  ## Units ordered after `u`: `u.Before` plus the units that list `u` in `After=`.
  result = initHashSet[string]()
  for n in m.depsOf(u, dkBefore): result.incl m.canonical(n)
  for n in m.reverseDeps(u.id, dkAfter): result.incl n

proc isMasked*(u: Unit): bool = u.def.common.loadState == lsMasked
proc loadOk*(u: Unit): bool = u.def.common.loadState == lsLoaded

proc allUnits*(m: Manager): seq[Unit] =
  for id in m.units.keys.toSeq.sorted: result.add m.units[id]
