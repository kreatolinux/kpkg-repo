## Core types of the manager: units, jobs and the `Manager` object that
## everything hangs off (spec §18.2.3). Per-type behavior (service, socket,
## mount, ...) is plugged into `Unit.ops` by the type modules.
import std/[tables, sets]
import jumpstartcore/reaper
import ../common/[roots, clock, names]
import ../unitfile/[model, index]
import ./eventloop

type
  ActiveState* = enum
    asInactive = "inactive", asActivating = "activating", asActive = "active",
    asReloading = "reloading", asDeactivating = "deactivating", asFailed = "failed"
  JobType* = enum
    jtStart = "start", jtStop = "stop", jtReload = "reload", jtRestart = "restart",
    jtTryRestart = "try-restart", jtTryReload = "try-reload",
    jtReloadOrStart = "reload-or-start", jtTryReloadOrStart = "try-reload-or-start",
    jtVerifyActive = "verify-active", jtNop = "nop"
  JobResult* = enum
    jrDone = "done", jrCanceled = "canceled", jrTimeout = "timeout", jrFailed = "failed",
    jrDependency = "dependency", jrSkipped = "skipped", jrInvalid = "invalid",
    jrAssert = "assert", jrUnsupported = "unsupported", jrCollected = "collected"
  JobState* = enum jsWaiting = "waiting", jsRunning = "running"
  JobOrigin* = enum joManual = "manual", joDependency = "dependency"
  KillWhom* = enum kwMain = "main", kwControl = "control", kwAll = "all"
  PowerAction* = enum paPoweroff = "poweroff", paReboot = "reboot", paHalt = "halt",
    paKexec = "kexec", paExit = "exit"

  JobOutcome* = object
    job*: int
    result*: JobResult
    message*: string        ## failure text of §9.10 / Appendix D for failed jobs
    code*: string           ## error code name when not E_BACKEND (`E_UNIT_STATE` ...)
    unit*: string
    state*: ActiveState     ## the unit's state at completion

  Job* = ref object
    id*: int
    unit*: Unit
    typ*: JobType
    state*: JobState
    matters*, conflicts*, irreversible*, ignoreOrder*: bool
    origin*: JobOrigin
    waiters*: seq[proc(o: JobOutcome) {.closure.}]
    timeoutTimer*, runningTimer*: TimerId
    installedUsec*: int64
    restartStopPhase*: bool     ## a restart whose stop phase is in progress

  Stamp* = object
    realUsec*, monoUsec*: int64

  RateLimit* = object
    intervalUsec*: int64
    burst*: int
    begin*: int64
    count*: int

  StartKind* = enum skStarted, skAlreadyActive, skConditionFailed, skAssertFailed, skRefused
  StartOutcome* = object
    kind*: StartKind
    text*: string           ## condition text, or the refusal message
    code*: string           ## refusal: an error code name such as E_UNIT_STATE

  StatusExtras* = object
    mainPid*, controlPid*: int
    pids*: seq[int]
    exitCode*: int          ## last main exit status, -1 when none
    statusText*: string
    nRestarts*: int
    cgroup*: string
    execMainStatus*, execMainCode*: int
    listen*: seq[string]
    extra*: seq[(string, string)]

  UnitOps* = object
    ## Per-type behavior. Any proc may be nil: the engine then treats the
    ## operation as not applicable.
    start*: proc(m: Manager; u: Unit): StartOutcome {.closure.}
    stop*: proc(m: Manager; u: Unit) {.closure.}
    reload*: proc(m: Manager; u: Unit): bool {.closure.}
    canReload*: proc(u: Unit): bool {.closure.}
    kill*: proc(m: Manager; u: Unit; whom: KillWhom; sig: cint): int {.closure.}
    resetFailed*: proc(m: Manager; u: Unit) {.closure.}
    redefine*: proc(m: Manager; u: Unit; old, fresh: UnitDef) {.closure.}
    fail*: proc(m: Manager; u: Unit; result: string) {.closure.}  ## force `failed` keeping internal state in sync
    status*: proc(m: Manager; u: Unit): StatusExtras {.closure.}
    properties*: proc(m: Manager; u: Unit): seq[(string, string)] {.closure.}
    shutdown*: proc(m: Manager; u: Unit) {.closure.}
    isBusy*: proc(u: Unit): bool {.closure.}    ## has processes or pending work: not collectable

  Unit* = ref object
    id*: string
    kind*: UnitKind
    def*: UnitDef
    active*: ActiveState
    sub*: string
    result*: string                    ## unit result (`Result=`)
    since*: int64                      ## usec realtime of the last state change
    activeEnter*, activeExit*, inactiveEnter*, inactiveExit*: Stamp
    job*: Job
    ops*: UnitOps
    data*: RootRef                     ## per-type state owned by the type module
    startLimit*: RateLimit
    needDaemonReload*: bool
    reloadResult*: string              ## outcome of the last reload (`success`, `exit-code`, ...)
    conditionResult*: bool
    failedCondition*: string           ## text of the condition that skipped the last start
    perpetual*: bool                   ## never garbage collected, never stopped by deactivate
    jumpstartState*: string            ## last state reported to Jumpstart
    reportedAt*: int64

  Notifier* = proc(unit, state, detail: string) {.closure.}

  SystemState* = enum
    ssInitializing = "initializing", ssStarting = "starting", ssRunning = "running",
    ssDegraded = "degraded", ssMaintenance = "maintenance", ssStopping = "stopping"

  Manager* = ref object
    roots*: Roots
    loop*: EventLoop
    reaper*: Reaper
    clock*: Clock
    rng*: Rng
    units*: Table[string, Unit]
    aliases*: Table[string, string]    ## alias -> canonical id of loaded units
    index*: UnitIndex
    conf*: ManagerConf
    env*: Table[string, string]        ## manager environment (set-environment, DefaultEnvironment)
    jobs*: Table[int, Job]
    jobSeq*: int
    booting*, stopping*, firstBoot*, indexReady*: bool
    bootId*, machineId*, version*: string
    bootTarget*: string
    extraDeps*: seq[(DepKind, string, string)]   ## in-memory edges (generators, kernel cmdline)
    masked*: HashSet[string]           ## `systemd.mask=`
    notifier*: Notifier
    dirty*: HashSet[string]            ## units whose state must be reported to Jumpstart
    reverseCache*: Table[(DepKind, string), seq[string]]
    reverseDirty*: bool
    actionTaken*: bool
    subscribers*: seq[Subscription]
    startedUsec*, bootJobsDone*: int64
    attachHook*: proc(m: Manager; u: Unit) {.closure.}
    scheduling*, schedulingAgain*: bool
    allowStart*: bool                  ## deactivate installs its own start of shutdown.target
    fsReady*: proc() {.closure.}       ## sends `filesystems-ready` once
    fsReadySent*: bool
    observer*: proc(o: JobOutcome) {.closure.}   ## sees every finished job (boot tracking)
    firstBootHook*: proc(m: Manager) {.closure.}
    monitor*: Table[string, seq[(string, string)]]  ## MONITOR_* variables for OnFailure=/OnSuccess= targets
    failHook*: proc(m: Manager; u: Unit; result: string) {.closure.}  ## puts a unit into `failed` (unitstate.nim)
    pids*: Table[int, string]                 ## tracked unit processes: pid -> unit id
    notifyHandler*: proc(m: Manager; u: Unit; pid: int; datagram: string; fds: seq[cint]) {.closure.}
    powerHook*: proc(action: PowerAction): bool {.closure.}
    loadHook*: proc(m: Manager; id: string): UnitDef {.closure.}
    cg*: RootRef                       ## the CgroupManager (service/cgroupmgr.nim)
    extra*: RootRef                    ## further facilities of other layers

  StateEvent* = object
    unit*: string
    active*: ActiveState
    sub*, result*: string
  Subscription* = ref object
    id*: int
    patterns*: seq[string]
    cb*: proc(ev: StateEvent) {.closure.}

const NoJob* = 0

proc isUp*(t: JobType): bool = t in {jtStart, jtVerifyActive, jtReload, jtReloadOrStart}
proc isStartLike*(t: JobType): bool = t in {jtStart, jtReloadOrStart, jtRestart, jtTryRestart, jtTryReloadOrStart}
proc isActiveish*(s: ActiveState): bool = s in {asActive, asReloading, asActivating}
proc isStable*(s: ActiveState): bool = s in {asInactive, asActive, asFailed}
proc nowReal*(m: Manager): int64 = m.clock.realUsec
proc nowMono*(m: Manager): int64 = m.clock.monoUsec

proc jumpstartState*(a: ActiveState): string =
  ## cores §12.11: `reloading` is shown as `active`.
  case a
  of asInactive: "inactive"
  of asActivating: "activating"
  of asActive, asReloading: "active"
  of asDeactivating: "deactivating"
  of asFailed: "failed"

proc canonical*(m: Manager; name: string): string =
  m.aliases.getOrDefault(name, name)
