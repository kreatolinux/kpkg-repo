## Boot and shutdown (spec §8): kernel command line, default target,
## `unit.activate` as one transaction, `unit.deactivate` with its budget.
import std/[options, strutils, tables, sets, sequtils, posix]
import ../common/[logging, clock, roots]
import ../unitfile/[model, index]
import ./[types, graph, jobs, eventloop]

type
  FailedUnit* = object
    unit*, result*, message*: string

proc parseCmdline*(m: Manager) =
  ## §8.2: boot target, masks, wants, environment, first-boot override.
  let text = try: readFile(m.roots.cmdline) except IOError: ""
  var legacy = ""
  var explicitUnit = ""
  for w in text.splitWhitespace:
    if w.startsWith("systemd.unit="): explicitUnit = w["systemd.unit=".len .. ^1]
    elif w.startsWith("systemd.mask="): m.masked.incl w["systemd.mask=".len .. ^1]
    elif w.startsWith("systemd.wants="):
      m.extraDeps.add (dkWants, "default.target", w["systemd.wants=".len .. ^1])
    elif w.startsWith("systemd.setenv="):
      let kv = w["systemd.setenv=".len .. ^1]
      let eq = kv.find('=')
      if eq > 0: m.env[kv[0 ..< eq]] = kv[eq + 1 .. ^1]
    elif w.startsWith("systemd.condition-first-boot="):
      m.firstBoot = w["systemd.condition-first-boot=".len .. ^1].toLowerAscii in ["1", "yes", "true", "on"]
    elif w in ["emergency", "-b"]: legacy = "emergency.target"
    elif w in ["rescue", "single", "s", "S", "1"]: legacy = "rescue.target"
    elif w in ["2", "3", "4"]: legacy = "multi-user.target"
    elif w == "5": legacy = "graphical.target"
  m.bootTarget = if explicitUnit.len > 0: explicitUnit else: legacy

proc defaultTarget*(m: Manager): string =
  ## §8.3: the file or link `default.target`, else multi-user.target (system).
  if m.index != nil:
    let r = resolveName(m.index, "default.target")
    if r.isSome and r.get.id != "default.target": return r.get.id
    if r.isSome and r.get.fragment.len > 0: return "default.target"
  if m.roots.scope == scUser: "default.target" else: "multi-user.target"

proc pinned(u: Unit): bool =
  u.kind in {ukMount, ukSwap, ukDevice, ukAutomount} or u.perpetual

proc activeish(u: Unit): bool = u.active in {asActive, asActivating, asReloading, asDeactivating}

proc activate*(m: Manager; done: proc(started: int; failed: seq[FailedUnit]) {.closure.}) =
  ## One `start TARGET` transaction (mode replace, origin dependency); `done`
  ## runs when every job of it has finished.
  var name = if m.bootTarget.len > 0: m.bootTarget else: m.defaultTarget
  var target = m.lookup(name)
  if target == nil or not target.loadOk:
    logErr(name, "boot target cannot be loaded; using the default target")
    name = m.defaultTarget
    target = m.lookup(name)
  if target == nil:
    done(0, @[FailedUnit(unit: name, result: "failed", message: "Unit " & name & " not found.")])
    return
  if m.firstBoot and m.firstBootHook != nil: m.firstBootHook(m)
  m.booting = true
  var finished = initTable[int, JobOutcome]()
  var ids: seq[int]
  var idsKnown = false
  var completed = false
  proc finish() =
    if completed: return
    completed = true
    # not nil-ed here: this runs inside the observer, whose closure must outlive the call
    m.loop.afterEvent(proc() = m.observer = nil)
    m.booting = false
    var failed: seq[FailedUnit]
    var started = 0
    var seen = initHashSet[string]()
    for id in ids:
      let o = finished.getOrDefault(id)
      let u = m.units.getOrDefault(o.unit)
      if u == nil: continue
      if o.result notin {jrDone, jrSkipped}:
        failed.add FailedUnit(unit: o.unit, result: $o.result, message: o.message)
        seen.incl o.unit
      elif u.active == asActive and u.kind notin {ukMount, ukDevice, ukSwap}:
        inc started
    for u in m.allUnits:
      if u.active == asFailed and u.id notin seen:
        failed.add FailedUnit(unit: u.id, result: u.result, message: "Unit " & u.id & " failed.")
    if not m.fsReadySent and m.fsReady != nil: m.fsReady()
    done(started, failed)
  proc check() =
    if not idsKnown or completed: return
    for id in ids:
      if id notin finished: return
    finish()
  m.observer = proc(o: JobOutcome) =
    finished[o.job] = o
    check()
  try:
    var installed: seq[Job]
    discard submitJob(m, target, jtStart, jmReplace, joDependency, nil, addr installed)
    for j in installed: ids.add j.id
    idsKnown = true
    if ids.len == 0: finish() else: check()
  except CatchableError as e:
    m.observer = nil
    m.booting = false
    done(0, @[FailedUnit(unit: name, result: "failed", message: e.msg)])

proc deactivate*(m: Manager; done: proc(stopped: int; failed: seq[FailedUnit]) {.closure.}) =
  ## §8.8: stop everything within the budget; pinned units stay.
  m.stopping = true
  let budget = int64(m.roots.limits.deactivateBudgetMs) * 1000
  let began = m.clock.monoUsec
  var initial: seq[string]
  for u in m.allUnits:
    if u.active in {asActive, asActivating, asReloading} and not u.pinned: initial.add u.id
  for j in toSeq(m.jobs.values):
    if j.state != jsRunning: discard m.cancelJob(j.id)
  let shutdown = m.lookup("shutdown.target")
  m.allowStart = true
  try:
    if shutdown != nil and shutdown.loadOk:
      discard submitJob(m, shutdown, jtStart, jmFlush, joDependency)
  except CatchableError as e: logWarn("shutdown.target", e.msg)
  m.allowStart = false
  var phase = 1
  var finished = false
  var hurried = false
  proc stopLeft(excludeJournal: bool): int =
    for u in m.allUnits:
      if u.pinned or not u.activeish: continue
      if excludeJournal and u.id.startsWith("systemd-journald"): continue
      if u.job == nil or u.job.typ != jtStop:
        try: discard submitJob(m, u, jtStop, jmReplace, joDependency)
        except CatchableError: discard
      inc result
  proc finishAll() =
    if finished: return
    finished = true
    var failed: seq[FailedUnit]
    var stopped = 0
    for id in initial:
      let u = m.units.getOrDefault(id)
      if u == nil: continue
      if u.active in {asInactive, asFailed}: inc stopped
      if u.active == asFailed or u.activeish:
        failed.add FailedUnit(unit: id, result: (if u.result.len > 0: u.result else: "timeout"),
                              message: "Unit " & id & " did not stop cleanly.")
    done(stopped, failed)
  proc killAll() =
    for u in m.allUnits:
      if u.pinned or not u.activeish: continue
      if u.ops.kill != nil: discard u.ops.kill(m, u, kwAll, SIGKILL)
  proc tick() =
    if finished: return
    let elapsed = m.clock.monoUsec - began
    if elapsed >= budget:
      killAll()
      finishAll()
      return
    if elapsed >= budget div 2 and not hurried:
      hurried = true
      killAll()
    var others, journal = 0
    for u in m.allUnits:
      if u.pinned or not u.activeish: continue
      if u.id.startsWith("systemd-journald"): inc journal else: inc others
    case phase
    of 1:
      if m.jobs.len == 0:
        phase = 2
        discard stopLeft(true)
    of 2:
      if others == 0:
        phase = 3
        discard stopLeft(false)
      else: discard stopLeft(true)
    else:
      if journal == 0 and m.jobs.len == 0:
        finishAll()
        return
    discard m.loop.addTimerIn(50_000, tick)
  tick()
