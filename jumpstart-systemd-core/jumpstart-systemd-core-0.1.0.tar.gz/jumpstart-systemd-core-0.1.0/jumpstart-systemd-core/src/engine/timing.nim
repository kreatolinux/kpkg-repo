## Per-unit activation timing for `systemd-analyze blame` / `critical-chain`
## (`timing` verb): a subscription records when each unit first started
## activating and when it first became active, relative to manager start.
import std/[tables]
import ../common/clock
import ./types

type Times* = object
  activatingUsec*, activeUsec*: int64      ## monotonic, 0 = not seen

var recorded: Table[string, Times]

proc installTiming*(m: Manager) =
  m.subscribers.add Subscription(id: 0, patterns: @[], cb: proc(ev: StateEvent) =
    var t = recorded.getOrDefault(ev.unit)
    let now = m.clock.monoUsec - m.startedUsec
    case ev.active
    of asActivating:
      if t.activatingUsec == 0: t.activatingUsec = max(1'i64, now)
    of asActive:
      if t.activeUsec == 0:
        t.activeUsec = max(1'i64, now)
        if t.activatingUsec == 0: t.activatingUsec = t.activeUsec
    else: discard
    recorded[ev.unit] = t)

proc timingRows*(): Table[string, Times] = recorded
