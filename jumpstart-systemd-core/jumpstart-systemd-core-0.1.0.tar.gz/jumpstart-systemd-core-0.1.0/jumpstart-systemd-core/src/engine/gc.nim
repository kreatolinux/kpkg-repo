## Unit garbage collection (spec §7.6, `CollectMode=`): a loaded unit leaves memory
## when it is inactive (or failed, with `CollectMode=inactive-or-failed`), has no
## job and no running work, and no unit that stays loaded references it
## (`Requires=`/`Wants=`/... edges, triggers, `Slice=`). Mark and sweep: every unit
## that cannot be collected is a root, references are followed from the roots,
## the rest is dropped. Collected units are loaded again from disk on demand
## (`lookup`). Failed units stay under the default mode until `reset-failed`.
##
## `scheduleGc` is the only entry point of the engine: it runs one sweep after
## the current event, and a periodic sweep (every 5 s) catches units that were loaded
## by a query and never changed state.
import std/[tables, sets]
import ../unitfile/model
import ./[types, graph, eventloop, jsnotify]

const
  PerpetualNames = ["-.slice", "system.slice", "user.slice", "-.mount"]
  PeriodicUsec = 5_000_000'i64
  RetryUsec = 100_000'i64
  ReferenceKinds = [dkRequires, dkRequisite, dkWants, dkBindsTo, dkPartOf, dkUpholds,
                    dkOnFailure, dkOnSuccess, dkTriggers]

type
  GcState = ref object
    scheduled, periodic: bool
    retry: TimerId
    collected: int

var states: Table[int, tuple[m: Manager, st: GcState]]   ## the manager reference keeps its address from being reused

proc stateOf(m: Manager): GcState =
  let key = cast[int](m)
  if key notin states: states[key] = (m, GcState())
  result = states[key].st

proc collected*(m: Manager): int =
  ## Units collected over the manager's lifetime.
  let key = cast[int](m)
  if key in states: states[key].st.collected else: 0

proc notifyPending(m: Manager; u: Unit): bool =
  ## Jumpstart has not been told the unit's current state yet: dropping it now
  ## would leave Jumpstart with a stale state.
  m.notifier != nil and u.reportable and u.jumpstartState != u.active.jumpstartState

proc collectable(m: Manager; u: Unit; waitReport: var bool): bool =
  ## The unit itself would not stop it from being collected.
  if u.perpetual or u.job != nil or u.id in PerpetualNames: return false
  if u.ops.isBusy != nil and u.ops.isBusy(u): return false
  case u.active
  of asInactive: discard
  of asFailed:
    if not u.def.common.collectInactiveOrFailed: return false
  else: return false
  let sl = u.startLimit
  if sl.intervalUsec > 0 and sl.count > 0 and sl.begin != 0 and
     m.nowMono - sl.begin <= sl.intervalUsec:
    return false                    # the start rate limit window is open: its counter lives in the unit
  if m.notifyPending(u):
    waitReport = true
    return false
  true

proc collectGarbage*(m: Manager): int =
  ## One mark-and-sweep pass; returns the number of units removed.
  if m.stopping or m.booting: return 0
  var roots: seq[string]
  var waitReport = false
  for id, u in m.units:
    if not m.collectable(u, waitReport): roots.add id
  var marked = initHashSet[string]()
  for id in roots: marked.incl id
  var work = roots
  while work.len > 0:
    let u = m.units.getOrDefault(work.pop())
    if u == nil: continue
    var targets: seq[string]
    for k in ReferenceKinds: targets.add m.depsOf(u, k)
    if u.def.common.slice.len > 0: targets.add u.def.common.slice
    for t in targets:
      let id = m.canonical(t)
      if m.units.hasKey(id) and not marked.containsOrIncl(id): work.add id
  var dead: seq[string]
  for id in m.units.keys:
    if id notin marked: dead.add id
  for id in dead:
    let u = m.units[id]
    for n in u.def.common.names:
      if m.aliases.getOrDefault(n) == id: m.aliases.del n
    m.units.del id
    m.dirty.excl id
    m.monitor.del id
  if dead.len > 0: m.reverseDirty = true
  result = dead.len
  let st = m.stateOf
  st.collected += result
  if waitReport and not st.retry.isSet:
    st.retry = m.loop.addTimerIn(RetryUsec, proc() =
      st.retry = TimerId(0)
      discard m.collectGarbage())

proc scheduleGc*(m: Manager) =
  ## Collect after the current event (coalesced); starts the periodic sweep.
  let st = m.stateOf
  if not st.periodic:
    st.periodic = true
    proc tick() =
      discard m.collectGarbage()
      discard m.loop.addTimerIn(PeriodicUsec, tick)
    discard m.loop.addTimerIn(PeriodicUsec, tick)
  if st.scheduled: return
  st.scheduled = true
  m.loop.afterEvent(proc() =
    st.scheduled = false
    discard m.collectGarbage())
