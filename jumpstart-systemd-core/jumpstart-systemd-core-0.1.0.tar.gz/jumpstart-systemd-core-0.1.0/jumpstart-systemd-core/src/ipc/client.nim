## Blocking `sdc/1` client for the front-ends (spec §4, §15.1).
import std/[json, posix, strutils]
import jumpstartcore/errors
import ../common/fdutil
import ./sdcproto

type
  SdcClient* = ref object
    fd: cint
    buf: string
    nextId: int
  SdcReply* = object
    ok*: bool
    result*: JsonNode
    code*: CoreErrorCode
    message*, jobResult*: string

proc connect*(path: string): SdcClient =
  ## Nil when the socket cannot be reached (`errno` has the reason).
  let fd = connectUnix(path, true)
  if fd < 0: return nil
  SdcClient(fd: fd, nextId: 1)

proc close*(c: SdcClient) =
  if c.fd >= 0:
    discard posix.close(c.fd)
    c.fd = -1

proc readLine(c: SdcClient): string =
  while true:
    let nl = c.buf.find('\n')
    if nl >= 0:
      result = c.buf[0 ..< nl]
      c.buf = c.buf[nl + 1 .. ^1]
      return
    var chunk = newString(65536)
    let n = read(c.fd, addr chunk[0], chunk.len)
    if n > 0: c.buf.add chunk[0 ..< n]
    elif n == 0: raise newException(IOError, "connection closed by the manager")
    elif errno != EINTR: raise newException(IOError, "read failed: " & $strerror(errno))

proc request*(c: SdcClient; verb: string; args: JsonNode = nil;
              onEvent: proc(x: JsonNode) = nil): SdcReply =
  ## Sends one request and waits for its response; events go to `onEvent`
  ## (the `data` of each `item` event). Raises IOError when the link breaks.
  let id = c.nextId
  inc c.nextId
  if not writeAll(c.fd, requestLine(%id, verb, args)):
    raise newException(IOError, "cannot send to the manager")
  while true:
    let x = parseResponse(c.readLine())
    if x.id != %id and x.id.kind != JNull: continue
    if x.isEvent:
      if onEvent != nil: onEvent(x.data)
      continue
    if x.ok: return SdcReply(ok: true, result: x.result)
    return SdcReply(ok: false, code: x.code, message: x.message, jobResult: x.jobResult)
