## Handlers of the `sdc/1` verbs (spec §4.3). They call only the engine
## facade; blocking verbs answer from job callbacks.
import std/json except getStr, getInt, getBool
import std/[options, os, strutils, tables, sets, sequtils, algorithm, posix, times]
import jumpstartcore/errors
import ../common/[names, roots, jsonio, clock]
import ../unitfile/[model, install, validate]
from ../journal/logops import readEntries
import ../engine/[types, graph, jobs, unitstate, manager, boot, api, eventloop, setprop, transient, timing]
import ./[sdcproto, conn]

const
  ReadVerbs* = ["unit-index", "hello", "ping", "unit-resolve", "unit-list", "unit-list-files", "unit-show",
    "unit-status", "unit-cat", "unit-deps", "unit-validate", "job-list", "get-default", "subscribe",
    "system-state", "timing", "cancel"]
  Redacted = ["Environment", "EnvironmentFiles", "EnvironmentFile", "PassEnvironment", "LoadCredential",
    "SetCredential", "ImportCredential", "StandardInputText", "StandardInputData"]

const WriteVerbs = ["daemon-reload", "job-submit", "job-cancel", "kill", "reset-failed", "unit-file-op",
  "set-property", "environment", "clean", "freeze", "thaw", "transient-create", "transient-start", "power", "activate", "deactivate"]

type VerbCtx* = object
  m*: Manager
  startedUsec*: int64
  shutdown*: proc() {.closure.}          ## asks the manager to exit (EOF of the supervisor channel)

proc strVal(n: JsonNode): string = (if n != nil and n.kind == JString: n.str else: "")
proc intVal(n: JsonNode): int = (if n != nil and n.kind == JInt: int(n.num) else: 0)

proc bad(msg: string): ref CoreError = newCoreError(ecProtocol, msg)

proc requireStr(a: JsonNode; k: string): string =
  if not a.has(k) or a[k].kind != JString: raise bad("argument " & k & " must be a string")
  a[k].str

proc nameList(a: JsonNode; k: string): seq[string] =
  if not a.has(k): return
  if a[k].kind != JArray: raise bad("argument " & k & " must be a list")
  for e in a[k]:
    if e.kind != JString: raise bad("argument " & k & " must be a list of strings")
    result.add e.str

proc redactText(text: string): string =
  for line in text.splitLines:
    let eq = line.find('=')
    if eq > 0 and line[0 ..< eq].strip in Redacted: result.add line[0 ..< eq] & "=<redacted>\n"
    else: result.add line & "\n"

proc withTriggering(m: Manager; t: JobType; u: Unit; res: JsonNode) =
  ## A stop result names the active units that can re-activate the unit.
  if t != jtStop or u == nil: return
  let triggering = triggeringUnits(m, u)
  if triggering.len > 0: res["triggering"] = %triggering

proc wait_cb(w: proc(o: JobOutcome) {.closure.}; wait: bool): proc(o: JobOutcome) {.closure.} =
  ## With --no-block nobody waits: the job is only installed.
  if wait: w else: nil

proc jobSubmit(ctx: VerbCtx; c: Conn; id: JsonNode; a: JsonNode) =
  let m = ctx.m
  let name = requireStr(a, "unit")
  let typ = parseJobType(a.getStr("type", "start"))
  if typ.isNone: raise newCoreError(ecUnsupported, "unknown job type " & a.getStr("type"))
  let modeName = a.getStr("mode", "replace")
  let mode = parseJobMode(modeName)
  if mode.isNone: raise newCoreError(ecUnsupported, "job mode " & modeName & " is not supported")
  var t = typ.get
  var md = mode.get
  if a.getStr("type") == "isolate": (t = jtStart; md = jmIsolate)
  let origin = if a.getStr("origin", "manual") == "dependency": joDependency else: joManual
  let wait = a.getBool("wait", true)
  let u = unitOrFail(m, name)
  var deadlineTimer: TimerId
  var answered = false
  let waiter = proc(o: JobOutcome) =
    if answered or c.closed or not c.isPending(id): return
    answered = true
    m.loop.cancelTimer(deadlineTimer)
    let uu = m.units.getOrDefault(o.unit)
    let state = if uu != nil: $uu.active else: "inactive"
    case o.result
    of jrDone, jrSkipped:
      var res = %*{"job": o.job, "result": $o.result, "state": jumpstartState(
        (if uu != nil: uu.active else: asInactive))}
      if o.result == jrSkipped and uu != nil: res["detail"] = %uu.failedCondition
      withTriggering(m, t, uu, res)
      c.respondOk(id, res)
    else:
      let (code, msg) = jobFailure(o)
      c.respondError(id, code, if msg.len > 0: msg else: "Job for " & o.unit & " failed.", $o.result, o.unit)
    discard state
  # registered first: a job may complete inside submitJob (a simple service
  # is active as soon as it is forked)
  c.pending[$id] = Pending(id: id, cancel: proc() = answered = true)
  let job = try: submitJob(m, u, t, md, origin, wait_cb(waiter, wait))
            except CoreError:
              c.pending.del $id
              raise
  if answered: return
  if job == nil: return                      # completed immediately, waiter ran
  if not wait:
    answered = true
    var res = %*{"job": job.id, "result": "running", "state": jumpstartState(u.active)}
    withTriggering(m, t, u, res)
    c.respondOk(id, res)
    return
  if a.has("deadline"):
    try:
      let dl = parse(a["deadline"].str, "yyyy-MM-dd'T'HH:mm:ss'.'ffffff'Z'", utc())
      let remainingUsec = (dl.toTime.toUnix * 1_000_000 + dl.nanosecond div 1000) - m.clock.realUsec
      deadlineTimer = m.loop.addTimerIn(max(0'i64, remainingUsec), proc() =
        if answered or c.closed: return
        answered = true
        var res = %*{"job": job.id, "result": "running", "state": jumpstartState(u.active)}
        withTriggering(m, t, u, res)
        c.respondOk(id, res))
    except CatchableError: discard

proc fileOp(ctx: VerbCtx; c: Conn; id: JsonNode; a: JsonNode) =
  let m = ctx.m
  let opName = requireStr(a, "op")
  let names = nameList(a, "names")
  var op: FileOp
  case opName
  of "enable": op = foEnable
  of "disable": op = foDisable
  of "reenable": op = foReenable
  of "mask": op = foMask
  of "unmask": op = foUnmask
  of "link": op = foLink
  of "preset": op = foPreset
  of "preset-all": op = foPresetAll
  of "revert": op = foRevert
  of "add-wants": op = foAddWants
  of "add-requires": op = foAddRequires
  of "set-default": op = foSetDefault
  else: raise bad("unknown op " & opName)
  var opts = FileOpOptions(runtime: a.getBool("runtime"), global: a.getBool("global"),
    force: a.getBool("force"), target: a.getStr("target"))
  case a.getStr("preset_mode", "full")
  of "enable-only": opts.presetMode = pmEnableOnly
  of "disable-only": opts.presetMode = pmDisableOnly
  else: discard
  let r = fileOp(m.roots, op, names, opts)
  if not r.ok:
    let masked = "masked" in r.error
    raise newCoreError(if masked: ecUnitState else: ecBackend, r.error)
  if a.getBool("reload", true): discard m.daemonReload()
  var res = fileOpResultJson(r)
  if a.getBool("now") and opName in ["enable", "reenable", "disable", "mask"]:
    let typ = if opName in ["enable", "reenable"]: jtStart else: jtStop
    var outstanding = 0
    var failure: Option[(CoreErrorCode, string, string)]
    let finish = proc() =
      if c.closed or not c.isPending(id): return
      if failure.isSome: c.respondError(id, failure.get[0], failure.get[1], failure.get[2])
      else: c.respondOk(id, res)
    c.pending[$id] = Pending(id: id, cancel: proc() = discard)
    for n in names:
      let u = m.lookup(mangle(n))
      if u == nil: continue
      inc outstanding
      let w = proc(o: JobOutcome) =
        if o.result notin {jrDone, jrSkipped} and failure.isNone:
          let (code, msg) = jobFailure(o)
          failure = some((code, msg, $o.result))
        dec outstanding
        if outstanding == 0: finish()
      let job = try: submitJob(m, u, typ, jmReplace, joManual, w) except CoreError as e:
        dec outstanding
        failure = some((e.code, e.msg, ""))
        nil
      discard job
    if outstanding == 0: finish()
    return
  c.respondOk(id, res)

proc transientCreate(ctx: VerbCtx; c: Conn; id: JsonNode; a: JsonNode) =
  let m = ctx.m
  let name = requireStr(a, "name")
  if parseUnitName(name).isNone: raise newCoreError(ecName, "Invalid unit name " & name)
  let dir = m.roots.sysrun / "transient"
  createDir(dir)
  let path = dir / name
  if fileExists(path) or m.lookup(name) != nil and m.lookup(name).def.common.loadState != lsNotFound:
    raise newCoreError(ecState, "Unit " & name & " already exists.")
  writeFile(path, requireStr(a, "text"))
  discard m.daemonReload()
  let u = m.lookup(name)
  if u == nil or u.def.common.loadState != lsLoaded:
    removeFile(path)
    discard m.daemonReload()
    raise newCoreError(ecUnitState, "Transient unit " & name & " failed to load.")
  if not a.getBool("start"):
    c.respondOk(id, %*{"name": name})
    return
  c.pending[$id] = Pending(id: id, cancel: proc() = discard)
  let wait = a.getBool("wait")
  var jobId = 0
  let job = submitJob(m, u, jtStart, jmReplace, joManual, proc(o: JobOutcome) =
    if not wait or c.closed or not c.isPending(id): return
    if o.result in {jrDone, jrSkipped}: c.respondOk(id, %*{"name": name, "job": o.job})
    else:
      let (code, msg) = jobFailure(o)
      c.respondError(id, code, msg, $o.result, name))
  if job != nil: jobId = job.id
  if not wait and c.isPending(id): c.respondOk(id, %*{"name": name, "job": jobId})

proc transientStart(ctx: VerbCtx; c: Conn; id: JsonNode; a: JsonNode) =
  ## `transient-start` (StartTransientUnit): `units` [{name, text}], `start`
  ## (unit name, optional), `collect`, `wait` (start job, default true),
  ## `wait_exit` (until the unit stops).
  var units: seq[TransientUnit]
  if not a.has("units") or a["units"].kind != JArray: raise bad("argument units must be a list")
  for e in a["units"]:
    units.add TransientUnit(name: e.getStr("name"), text: e.getStr("text"))
  c.pending[$id] = Pending(id: id, cancel: proc() = discard)
  try:
    startTransient(ctx.m, units, a.getStr("start"), a.getBool("collect"), a.getBool("wait", true),
      a.getBool("wait_exit"), proc(r: TransientResult) =
        if c.closed or not c.isPending(id): return
        if not r.ok: c.respondError(id, r.code, r.message)
        else:
          c.respondOk(id, %*{"name": r.name, "job": r.job, "result": r.result, "exec_status": r.execStatus,
                             "exec_code": r.execCode, "runtime_usec": r.runtimeUsec}))
  except CoreError:
    c.pending.del $id
    raise

proc handleVerb*(ctx: VerbCtx; c: Conn; req: SdcRequest) =
  ## Answers `req` (possibly later). Raises CoreError for immediate failures.
  let m = ctx.m
  let a = req.args
  let id = req.id
  if req.verb notin ReadVerbs and req.verb notin WriteVerbs: raise bad("unknown verb " & req.verb)
  if req.verb notin ReadVerbs and not c.owner:
    raise newCoreError(ecPermission, "Access denied.")
  if req.verb notin ["hello", "ping", "cancel"] and not m.indexReady:
    raise newCoreError(ecBackend, "Manager is still starting.")
  case req.verb
  of "hello":
    c.respondOk(id, %*{"protocol": SdcProtocol,
      "scope": (if m.roots.scope == scUser: "user" else: "system"),
      "manager_pid": int(getpid()), "boot_id": m.bootId, "machine_id": m.machineId,
      "version": m.version, "core_version": "0.1.0",
      "started": rfc3339(ctx.startedUsec), "booting": m.booting})
  of "ping": c.respondOk(id)
  of "unit-resolve": c.respondOk(id, resolve(m, requireStr(a, "name")))
  of "unit-list":
    let rows = listRows(m, nameList(a, "states"), nameList(a, "types"), nameList(a, "patterns"),
                        a.getBool("all"))
    for r in rows: c.event(id, "item", r, "units")
    c.respondOk(id, %*{"count": rows.len})
  of "unit-index":
    # private: the §13.4 list for Jumpstart's router, as item events
    let rows = unitListForJumpstart(m)
    for r in rows: c.event(id, "item", r, "units")
    c.respondOk(id, %*{"count": rows.len})
  of "activate", "deactivate":
    let isActivate = req.verb == "activate"
    c.pending[$id] = Pending(id: id, cancel: proc() = discard)
    let report = proc(count: int; failed: seq[FailedUnit]) =
      if c.closed or not c.isPending(id): return
      var f = newJArray()
      for x in failed: f.add %*{"unit": x.unit, "result": x.result, "message": x.message}
      c.respondOk(id, %*{(if isActivate: "started" else: "stopped"): count, "failed": f})
    if isActivate: boot.activate(m, report) else: boot.deactivate(m, report)
  of "unit-list-files":
    let rows = fileRows(m, nameList(a, "types"), nameList(a, "states"),
                        nameList(a, "patterns"), a.getBool("preset"))
    for r in rows: c.event(id, "item", r, "unit_files")
    c.respondOk(id, %*{"count": rows.len})
  of "unit-show":
    var units = newJArray()
    let want = nameList(a, "properties")
    for n in nameList(a, "names"):
      let u = m.lookup(mangle(n))
      var props = newJObject()
      var list: seq[(string, string)]
      if u == nil:
        list = @[("Id", mangle(n)), ("LoadState", "not-found"), ("ActiveState", "inactive"), ("SubState", "dead")]
      else:
        list = showProps(m, u)
      for (k, v) in list:
        if want.len > 0 and k notin want: continue
        props[k] = %(if not c.owner and k in Redacted: "" else: v)
      units.add %*{"name": (if u == nil: mangle(n) else: u.id), "properties": props}
    c.respondOk(id, %*{"units": units})
  of "unit-status":
    let u = unitOrFail(m, requireStr(a, "name"))
    var res = statusJson(m, u)
    if u.ops.status != nil:
      let ex = u.ops.status(m, u)
      var tree = newJArray()
      if ex.cgroup.len > 0: tree.add %*{"path": ex.cgroup, "pids": ex.pids}
      res["cgroup_tree"] = tree
      res["exec"] = %*{"main_pid": ex.mainPid, "control_pid": ex.controlPid, "exit_status": ex.execMainStatus}
    res["name"] = %u.id
    res["sub"] = %u.sub
    res["load_state"] = %($u.def.common.loadState)
    res["description"] = %u.def.common.description
    res["fragment_path"] = %u.def.common.fragmentPath
    res["active_state"] = %($u.active)
    let lines = if a.has("journal_lines"): intVal(a["journal_lines"]) else: 10
    if lines < 0 or lines > 1000: raise bad("journal_lines must be 0 to 1000")
    if lines > 0:
      var js = newJArray()
      for e in readEntries(m.roots, u.id, none(int64), none(int64), lines):
        js.add %*{"time": e.time, "level": e.level, "unit": e.unit, "message": e.message}
      res["journal"] = js
    c.respondOk(id, res)
  of "unit-cat":
    var units = newJArray()
    for n in nameList(a, "names"):
      let u = unitOrFail(m, n)
      var j = catUnit(m, u)
      if not c.owner:
        for f in j["files"]: f["text"] = %redactText(f["text"].str)
      units.add j
    c.respondOk(id, %*{"units": units})
  of "unit-deps":
    let u = unitOrFail(m, requireStr(a, "name"))
    var seen = initHashSet[string]()
    c.respondOk(id, %*{"tree": depTree(m, u, a.getBool("reverse"), a.getBool("after"),
      a.getBool("before"), a.getBool("all"), 0, seen)})
  of "unit-validate":
    let name = requireStr(a, "name")
    let r = validateUnit(m.roots, name, m.specEnv)
    var ds = newJArray()
    for d in r.diagnostics:
      ds.add %*{"severity": $d.severity, "unit": d.unit, "file": d.file, "line": d.line,
                "key": d.key, "message": d.message, "code": d.code}
    c.respondOk(id, %*{"valid": r.valid, "diagnostics": ds})
  of "daemon-reload":
    let r = m.daemonReload()
    var errs = newJArray()
    for d in r.errors:
      errs.add %*{"unit": d.unit, "file": d.file, "line": d.line, "severity": $d.severity,
                  "code": d.code, "message": d.message}
    c.respondOk(id, %*{"loaded": r.loaded, "errors": errs})
  of "job-submit": jobSubmit(ctx, c, id, a)
  of "job-list":
    var n = 0
    for jid in toSeq(m.jobs.keys).sorted:
      let j = m.jobs[jid]
      if a.has("unit") and j.unit.id != mangle(a["unit"].strVal): continue
      c.event(id, "item", %*{"job": j.id, "unit": j.unit.id, "type": $j.typ, "state": $j.state}, "jobs")
      inc n
    c.respondOk(id, %*{"count": n})
  of "job-cancel":
    var n = 0
    if a.has("job"):
      if m.cancelJob(a["job"].intVal): inc n
    else:
      for jid in toSeq(m.jobs.keys):
        if m.cancelJob(jid): inc n
    c.respondOk(id, %*{"cancelled": n})
  of "kill":
    let u = unitOrFail(m, requireStr(a, "unit"))
    let whom = case a.getStr("whom", "all")
      of "main": kwMain
      of "control": kwControl
      else: kwAll
    var sig = 15
    if a.has("signal"):
      let s = a["signal"]
      if s.kind == JInt: sig = s.intVal
      else:
        let nm = s.strVal.toUpperAscii.replace("SIG", "")
        sig = case nm
          of "HUP": 1
          of "INT": 2
          of "QUIT": 3
          of "KILL": 9
          of "USR1": 10
          of "USR2": 12
          of "TERM": 15
          of "CONT": 18
          of "STOP": 19
          else: (try: parseInt(nm) except ValueError: 0)
    if sig < 1 or sig > 64: raise newCoreError(ecUsage, "Invalid signal")
    if u.ops.kill == nil: raise newCoreError(ecUnsupported, "Unit " & u.id & " cannot be signalled.")
    let n = u.ops.kill(m, u, whom, cint(sig))
    if n == 0 and u.active in {asInactive, asFailed}:
      raise newCoreError(ecUnitState, "Unit " & u.id & " is not active.")
    c.respondOk(id, %*{"signalled": n})
  of "reset-failed":
    var n = 0
    for u in m.allUnits:
      if a.has("unit") and u.id != mangle(a["unit"].strVal): continue
      if u.active == asFailed or u.startLimit.count > 0:
        u.startLimit.count = 0
        u.startLimit.begin = 0
        if u.ops.resetFailed != nil: u.ops.resetFailed(m, u)
        elif u.active == asFailed: m.setState(u, asInactive, "dead", "success")
        inc n
    c.respondOk(id, %*{"reset": n})
  of "unit-file-op": fileOp(ctx, c, id, a)
  of "get-default": c.respondOk(id, %*{"name": m.defaultTarget})
  of "environment":
    let act = a.getStr("action", "show")
    if act == "show" and c.uid != 0 and m.roots.scope == scSystem:
      raise newCoreError(ecPermission, "Access denied.")
    if a.has("vars"):
      if act == "set":
        for k, v in a["vars"]: m.env[k] = v.strVal
      elif act == "unset":
        for e in a["vars"]:
          m.env.del e.strVal
      elif act == "import":
        for e in a["vars"]:
          if existsEnv(e.strVal): m.env[e.strVal] = getEnv(e.strVal)
    var vars = newJObject()
    for k, v in m.env: vars[k] = %v
    c.respondOk(id, %*{"vars": vars})
  of "transient-create": transientCreate(ctx, c, id, a)
  of "power":
    let action = parsePowerAction(a.getStr("action"))
    if action.isNone: raise bad("unknown power action " & a.getStr("action"))
    c.respondOk(id, %*{"accepted": m.requestPower(action.get)})
  of "subscribe":
    let pats = nameList(a, "units")
    let sub = Subscription(id: m.subscribers.len + 1, patterns: pats, cb: proc(ev: StateEvent) =
      c.event(id, "item", %*{"event": "unit-state", "unit": ev.unit, "active": $ev.active,
                             "sub": ev.sub, "result": ev.result}, "events"))
    m.subscribers.add sub
    c.pending[$id] = Pending(id: id, cancel: proc() = m.subscribers.keepItIf(it != sub))
  of "system-state":
    let s = systemState(m)
    c.respondOk(id, %*{"state": s.state, "failed": s.failed, "jobs": s.jobs})
  of "timing":
    var rows = newJArray()
    for name, t in timingRows():
      rows.add %*{"name": name, "activating_usec": t.activatingUsec, "active_usec": t.activeUsec}
    c.respondOk(id, %*{"kernel_usec": 0, "userspace_usec": m.clock.monoUsec - m.startedUsec,
                       "units": rows})
  of "cancel":
    let target = if a.has("target"): a["target"] else: newJNull()
    let key = $target
    if c.pending.hasKey(key):
      let p = c.pending[key]
      if p.cancel != nil: p.cancel()
      c.respondError(p.id, ecCancelled, "Request cancelled.")
    c.respondOk(id)
  of "set-property":
    let r = setProperties(m, requireStr(a, "unit"), a.getBool("runtime"), nameList(a, "properties"))
    c.respondOk(id, %*{"applied": r.applied, "dropin": (if r.dropins.len > 0: r.dropins[0] else: ""),
                       "dropins": r.dropins})
  of "clean":
    c.respondOk(id, %*{"removed": cleanUnit(m, requireStr(a, "unit"), nameList(a, "what"))})
  of "transient-start": transientStart(ctx, c, id, a)
  of "freeze", "thaw":
    let frozen = req.verb == "freeze"
    var changed = 0
    var failed = newJArray()
    for n in nameList(a, "units"):
      let u = m.lookup(mangle(n))
      if u == nil or u.def.common.loadState == lsNotFound:
        failed.add %*{"unit": mangle(n), "message": "Unit " & mangle(n) & " not found."}
      elif u.active notin {asActive, asReloading}:
        failed.add %*{"unit": u.id, "message": "Unit " & u.id & " is not active."}
      else:
        try:
          if freezeUnit(m, u, frozen): inc changed
          else: failed.add %*{"unit": u.id, "message": "Unit " & u.id & " has no cgroup to freeze."}
        except CatchableError as e:
          failed.add %*{"unit": u.id, "message": "Cannot freeze " & u.id & ": " & e.msg}
    c.respondOk(id, %*{"changed": changed, "failed": failed})
  else:
    raise bad("unknown verb " & req.verb)
