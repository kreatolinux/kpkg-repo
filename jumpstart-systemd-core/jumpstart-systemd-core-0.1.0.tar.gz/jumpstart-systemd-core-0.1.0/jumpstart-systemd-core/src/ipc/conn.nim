## One accepted control connection (spec §4.1, §4.2): peer credentials,
## buffered input, serialized output, in-flight requests.
import std/[json, tables]
import jumpstartcore/errors
import ../common/fdutil
import ./sdcproto

type
  Conn* = ref object
    fd*: cint
    uid*: int
    owner*: bool                 ## full authorization (§4.1)
    closed*: bool
    private*: bool
    inbuf*: string
    firstByteUsec*: int64
    lastActivityUsec*: int64
    pending*: Table[string, Pending]
  Pending* = ref object
    id*: JsonNode
    cancel*: proc() {.closure.}  ## drops the wait; the response is E_CANCELLED

proc send*(c: Conn; line: string) =
  if c.closed: return
  if not writeAll(c.fd, line): c.closed = true

proc respondOk*(c: Conn; id: JsonNode; value: JsonNode = nil) =
  c.pending.del $id
  c.send okLine(id, value)

proc respondError*(c: Conn; id: JsonNode; code: CoreErrorCode; msg: string; jobResult = ""; unit = "") =
  c.pending.del $id
  c.send errorLine(id, code, msg, jobResult, unit)

proc event*(c: Conn; id: JsonNode; event: string; data: JsonNode; field = "") =
  c.send eventLine(id, event, data, field)

proc isPending*(c: Conn; id: JsonNode): bool = c.pending.hasKey $id
