## The `sdc/1` manager control protocol: newline-delimited JSON (spec §4.2).
## Messages, constructors and the line codec; sockets live in server.nim and
## client.nim.
import std/json
import jumpstartcore/errors

const
  SdcProtocol* = "sdc/1"
  MaxLineBytes* = 1024 * 1024

type
  SdcFailure* = object of CatchableError
    ## Raised by verb handlers; becomes an `ok: false` response.
    code*: CoreErrorCode
    jobResult*: string     ## optional `error.result`
    unit*: string          ## optional `error.unit`
  SdcRequest* = object
    id*: JsonNode          ## string or integer, echoed verbatim
    verb*: string
    args*: JsonNode        ## always an object

proc sdcFailure*(code: CoreErrorCode; message: string; jobResult = "";
                 unit = ""): ref SdcFailure =
  result = newException(SdcFailure, message)
  result.code = code
  result.jobResult = jobResult
  result.unit = unit

proc parseRequest*(line: string): SdcRequest =
  ## Raises `SdcFailure(ecProtocol)` for an unusable request. The caller
  ## decides whether the connection survives (unparseable JSON closes it).
  let node = parseJson(line)
  if node.kind != JObject: raise sdcFailure(ecProtocol, "request must be an object")
  if not node.hasKey("id") or node["id"].kind notin {JString, JInt} or
      (node["id"].kind == JString and node["id"].str.len == 0):
    raise sdcFailure(ecProtocol, "request id must be a non-empty string or an integer")
  result.id = node["id"]
  if not node.hasKey("verb") or node["verb"].kind != JString:
    raise sdcFailure(ecProtocol, "request has no verb")
  result.verb = node["verb"].str
  result.args = newJObject()
  if node.hasKey("args"):
    if node["args"].kind != JObject: raise sdcFailure(ecProtocol, "args must be an object")
    result.args = node["args"]

proc requestLine*(id: JsonNode; verb: string; args: JsonNode = nil): string =
  $(%*{"id": id, "verb": verb, "args": (if args.isNil: newJObject() else: args)}) & "\n"

proc okLine*(id: JsonNode; value: JsonNode = nil): string =
  $(%*{"id": id, "ok": true, "result": (if value.isNil: newJObject() else: value)}) & "\n"

proc errorLine*(id: JsonNode; code: CoreErrorCode; message: string;
                jobResult = ""; unit = ""): string =
  var err = %*{"code": errorName(code), "message": message}
  if jobResult.len > 0: err["result"] = %jobResult
  if unit.len > 0: err["unit"] = %unit
  $(%*{"id": id, "ok": false, "error": err}) & "\n"

proc eventLine*(id: JsonNode; event: string; data: JsonNode; field = ""): string =
  var node = %*{"id": id, "event": event, "data": data}
  if field.len > 0: node["field"] = %field
  $node & "\n"

type SdcResponse* = object
  id*: JsonNode
  ok*: bool
  result*: JsonNode
  code*: CoreErrorCode
  message*, jobResult*, unit*: string
  isEvent*: bool
  event*, field*: string
  data*: JsonNode

proc parseResponse*(line: string): SdcResponse =
  ## Client side: a response or an event line.
  let node = parseJson(line)
  if node.kind != JObject or not node.hasKey("id"):
    raise sdcFailure(ecProtocol, "malformed response")
  result.id = node["id"]
  if node.hasKey("event"):
    result.isEvent = true
    result.event = node["event"].getStr
    result.field = node{"field"}.getStr
    result.data = node{"data"}
    return
  result.ok = node{"ok"}.getBool
  if result.ok:
    result.result = node{"result"}
  else:
    let e = node{"error"}
    result.code = ecBackend
    discard tryParseErrorCode(e{"code"}.getStr, result.code)
    result.message = e{"message"}.getStr
    result.jobResult = e{"result"}.getStr
    result.unit = e{"unit"}.getStr
