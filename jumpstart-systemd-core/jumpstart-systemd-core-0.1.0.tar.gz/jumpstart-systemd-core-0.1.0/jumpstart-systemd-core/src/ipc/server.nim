## The two control sockets (spec §4.1): `RT/manager.sock` (private, adapter)
## and `SYSRUN/compat.sock` (public, front-ends). Line framing, limits,
## authorization by peer credentials, dispatch to `verbs`.
import std/[json, os, posix, strutils, tables, sequtils]
import jumpstartcore/[errors, peercred]
import ../common/[roots, fdutil, logging, clock]
import ../engine/[types, eventloop]
import ./[sdcproto, conn, verbs]

const
  MaxConns = 256
  MaxInflight = 64
  FirstByteTimeoutUsec = 10_000_000'i64
  IdleTimeoutUsec = 300_000_000'i64

type Server* = ref object
  ctx: VerbCtx
  conns: Table[cint, Conn]
  watches: Table[cint, WatchId]
  listeners: seq[cint]

proc closeConn(s: Server; c: Conn) =
  if c.fd < 0: return
  let m = s.ctx.m
  c.closed = true
  for key, p in c.pending:
    if p.cancel != nil: p.cancel()
  c.pending.clear()
  if s.watches.hasKey(c.fd):
    m.loop.delFd(s.watches[c.fd])
    s.watches.del c.fd
  s.conns.del c.fd
  discard close(c.fd)
  c.fd = -1

proc dispatchLine(s: Server; c: Conn; line: string) =
  var req: SdcRequest
  try:
    req = parseRequest(line)
  except JsonParsingError, ValueError:
    c.send errorLine(newJNull(), ecProtocol, "unparseable request")
    s.closeConn(c)
    return
  except SdcFailure as e:
    c.send errorLine(newJNull(), e.code, e.msg)
    return
  if c.pending.len >= MaxInflight:
    c.send errorLine(req.id, ecLimit, "Too many requests in flight.")
    return
  try:
    s.ctx.handleVerb(c, req)
  except CoreError as e:
    c.respondError(req.id, e.code, e.msg)
  except SdcFailure as e:
    c.respondError(req.id, e.code, e.msg, e.jobResult, e.unit)
  except CatchableError as e:
    logErr("", "verb " & req.verb & " failed: " & e.msg)
    c.respondError(req.id, ecBackend, e.msg)

proc onReadable(s: Server; c: Conn) =
  let m = s.ctx.m
  let (data, eof) = readAvailable(c.fd)
  if data.len > 0:
    if c.inbuf.len == 0: c.firstByteUsec = m.clock.monoUsec
    c.lastActivityUsec = m.clock.monoUsec
    c.inbuf.add data
    if c.inbuf.len > MaxLineBytes and '\n' notin c.inbuf:
      s.closeConn(c)
      return
    while true:
      let nl = c.inbuf.find('\n')
      if nl < 0: break
      let line = c.inbuf[0 ..< nl]
      c.inbuf = c.inbuf[nl + 1 .. ^1]
      if line.strip.len > 0: s.dispatchLine(c, line)
      if c.fd < 0: return
  if eof: s.closeConn(c)

proc accept(s: Server; listener: cint; private: bool) =
  let m = s.ctx.m
  while true:
    let fd = cint(accept(SocketHandle(listener), nil, nil))
    if fd < 0: break
    setCloexec(fd)
    setNonBlocking(fd)
    let c = Conn(fd: fd, private: private, pending: initTable[string, Pending](),
                 lastActivityUsec: m.clock.monoUsec)
    if s.conns.len >= MaxConns:
      c.send errorLine(newJNull(), ecLimit, "Too many connections.")
      discard close(fd)
      continue
    try:
      let pc = peerCredentials(fd)
      c.uid = int(pc.uid)
    except CatchableError:
      c.uid = -1
    let own = int(m.roots.uid)
    if m.roots.scope == scUser:
      if c.uid != own:
        c.send errorLine(newJNull(), ecPermission, "Access denied.")
        discard close(fd)
        continue
      c.owner = true
    else:
      c.owner = c.uid == 0
    s.conns[fd] = c
    s.watches[fd] = m.loop.addFd(fd, EvIn or EvHup, proc(ev: uint32) =
      if c.fd >= 0: s.onReadable(c))

proc sweep(s: Server) =
  let m = s.ctx.m
  let now = m.clock.monoUsec
  for c in toSeq(s.conns.values):
    if c.inbuf.len > 0 and now - c.firstByteUsec > FirstByteTimeoutUsec: s.closeConn(c)
    elif c.pending.len == 0 and now - c.lastActivityUsec > IdleTimeoutUsec: s.closeConn(c)
  discard m.loop.addTimerIn(1_000_000, proc() = s.sweep())

proc listenOn(s: Server; path: string; mode: Mode; private: bool) =
  ## One listening socket and its watch (a proc, so each closure owns its descriptor).
  let fd = bindUnix(path, true, mode)
  if fd < 0: raiseOSError(osLastError(), "cannot bind " & path)
  s.listeners.add fd
  discard s.ctx.m.loop.addFd(fd, EvIn, proc(ev: uint32) = s.accept(fd, private))

proc startControlServers*(ctx: VerbCtx): Server =
  ## Binds both sockets (raises OSError on failure) and registers them.
  let m = ctx.m
  let s = Server(ctx: ctx, conns: initTable[cint, Conn](), watches: initTable[cint, WatchId]())
  createDir(m.roots.rt)
  createDir(m.roots.sysrun)
  s.listenOn(m.roots.rt / "manager.sock", 0o600, true)
  s.listenOn(m.roots.sysrun / "compat.sock", Mode(if m.roots.scope == scSystem: 0o666 else: 0o600), false)
  discard m.loop.addTimerIn(1_000_000, proc() = s.sweep())
  s

proc shutdownServers*(s: Server) =
  for c in toSeq(s.conns.values): s.closeConn(c)
  for fd in s.listeners: discard close(fd)
  for p in [s.ctx.m.roots.rt / "manager.sock", s.ctx.m.roots.sysrun / "compat.sock"]:
    discard unlink(p.cstring)
