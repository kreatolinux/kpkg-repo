## Entry point of `systemd-compat-exec` (spec §10.1).
## `quit` clamps codes above 127, and Appendix D statuses go up to 245, so the
## process leaves through the C `exit`.
import std/os
import executor/run

proc cExit(code: cint) {.importc: "exit", header: "<stdlib.h>", noreturn.}
cExit(cint(executorMain(commandLineParams())))
