## Entry point of `systemd-compat-manager`, the core's supervisor (spec §3.2,
## §8.1, §14.2). Binds the control sockets, answers the supervisor handshake,
## then runs the event loop until Jumpstart closes descriptor 3.
import std/[os, posix]
import jumpstartcore/[protocol, jsonlines, reaper, adapterloop]
import common/[roots, logging, clock]
import engine/[types, manager, eventloop, api, jsnotify, boot]
import service/[notify]
import units/[socket, mount, timer, path, swap, automount]
import ipc/[server, verbs]
import generators/external
import engine/timing
import journal/client as jclient
import dbus/sd1api

proc main(): int =
  let roots = rootsFromEnvironment()
  if roots.rt.len == 0:
    stderr.writeLine "systemd-compat-manager: must be started by Jumpstart (JUMPSTART_CORE_RUNTIME_DIR unset)"
    return 2
  try: enableChildSubreaper() except CatchableError: discard
  for d in [roots.sysrun, roots.sysrun / "system", roots.sysrun / "units", roots.sysrun / "transient",
            roots.sysrun / "system.control"]:
    try: createDir(d)
    except OSError: discard
  installSocketSupport()
  installMountSupport()
  installTimerSupport()
  installPathSupport()
  installSwapSupport()
  installAutomountSupport()
  installExternalGenerators()
  let m = newManager(roots)
  installTiming(m)
  m.hookReaper()
  let queue = jclient.newJournalQueue(roots.sysrun)
  jclient.installLogSink(queue)
  discard m.loop.addTimerIn(1_000_000, proc() = discard)
  proc flushJournal() =
    queue.flush()
    discard m.loop.addTimerIn(1_000_000, flushJournal)
  flushJournal()
  m.watchMountinfo()
  m.watchSwaps()
  let ctx = VerbCtx(m: m, startedUsec: m.clock.realUsec)
  var srv: Server
  try:
    srv = startControlServers(ctx)
  except OSError as e:
    logErr("", "cannot start control sockets: " & e.msg)
    return 1
  if startNotifySocket(m) < 0 and defined(linux): logWarn("", "sd_notify socket unavailable")
  m.startNotifier(4, unitDetail)
  # User scope: org.freedesktop.systemd1 on the session bus (dbus/sd1api.nim).
  let busApi {.used.} = installBusApi(m)
  m.fsReady = proc() =
    if m.fsReadySent: return
    m.fsReadySent = true
    try: writeAllFd(4, encodeLine(filesystemsReady()))
    except CatchableError: discard
  # supervisor handshake (cores §17.2) now that every socket is bound
  try:
    let session = newAdapterSession(crSupervisor, 3, 4)
    discard session.handshake()
  except CatchableError as e:
    logErr("", "supervisor handshake failed: " & e.msg)
    return 1
  var stopping = false
  discard m.loop.addFd(3, EvIn or EvHup, proc(ev: uint32) =
    var buf: array[256, char]
    let n = read(3, addr buf[0], buf.len)
    if n == 0 and not stopping:           # EOF: Jumpstart wants the core unloaded (§14.2)
      stopping = true
      logInfo("", "supervisor channel closed; stopping")
      m.deactivate(proc(stopped: int; failed: seq[FailedUnit]) = m.loop.stop()))
  m.loop.runLoop()
  shutdownServers(srv)
  0

quit main()
