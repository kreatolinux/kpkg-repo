## Appending to one journal file (section 12.2): creation, torn-tail recovery,
## single-`write(2)` appends, index upkeep, fsync and archiving.
import std/[os, posix, options, strutils]
import ./[format, index]
import ../common/clock

when defined(linux):
  proc fdatasync(fd: cint): cint {.importc, header: "<unistd.h>".}
else:
  proc fdatasync(fd: cint): cint = fsync(fd)

type
  JournalFile* = ref object
    path*: string
    fd: cint
    header*: FileHeader
    size*: int64
    count*: int                 ## records in the file
    lastSeq*, lastRealtime*: uint64
    unsynced: bool

proc archivedName*(h: FileHeader): string =
  ## `system@SEQIDHEX-FIRSTSEQHEX-FIRSTREALTIMEHEX.jrn` (32, 16 and 16 digits).
  "system@" & idHex(h.seqnumId) & "-" & toHex(h.firstSeq, 16).toLowerAscii & "-" &
    toHex(h.firstTime, 16).toLowerAscii & ".jrn"

proc patchHeader(path: string; offset: int; data: string) =
  let fd = posix.open(path.cstring, O_WRONLY)
  if fd < 0: raiseOSError(osLastError(), path)
  defer: discard close(fd)
  if pwrite(fd, unsafeAddr data[0], data.len, Off(offset)) != data.len:
    raiseOSError(osLastError(), path)
  discard fdatasync(fd)

proc le64(v: uint64): string =
  for i in 0 ..< 8: result.add char((v shr (8 * i)) and 0xFF)

proc openAppendFd(path: string; mode: Mode): cint =
  result = posix.open(path.cstring, O_WRONLY or O_APPEND or O_CREAT or O_CLOEXEC, mode)
  if result < 0: raiseOSError(osLastError(), path)

proc openJournalFile*(path, machineId, seqnumId: string; rng: Rng; mode: Mode = 0o640): JournalFile =
  ## Opens `path` for appending. An existing file is truncated after its last
  ## valid record; a missing one is created with a fresh header. Raises `OSError`
  ## (and `IOError` for a file that is not a journal).
  result = JournalFile(path: path)
  if fileExists(path):
    var f: File
    if not open(f, path, fmRead): raise newException(IOError, "cannot open " & path)
    let h = readHeader(f)
    if h.isNone:
      close(f)
      raise newException(IOError, "not a journal file: " & path)
    result.header = h.get
    let ix = loadIndex(path)
    let size = getFileSize(path)
    var n = if ix.len > 0: (ix.len - 1) * IndexEvery else: 0
    var last: JournalEntry
    let startAt = if ix.len > 0: ix[^1].offset else: HeaderSize.int64
    let validEnd = scanRecords(f, size, startAt, proc(e: var JournalEntry; off: int64): bool =
      inc n
      last = e
      true)
    close(f)
    if validEnd < size: (if truncate(path.cstring, Off(validEnd)) != 0: raiseOSError(osLastError(), path))
    result.size = validEnd
    result.count = n
    if n > 0: result.lastSeq = last.seqnum; result.lastRealtime = uint64(last.realtime)
    result.fd = openAppendFd(path, mode)
  else:
    result.header = FileHeader(fileId: rng.bytes(16), machineId: machineId, seqnumId: seqnumId)
    let data = encodeHeader(result.header)
    result.fd = openAppendFd(path, mode)
    if posix.write(result.fd, unsafeAddr data[0], data.len) != data.len:
      raiseOSError(osLastError(), path)
    result.size = HeaderSize

proc sync*(jf: JournalFile) =
  if jf.unsynced:
    discard fdatasync(jf.fd)
    jf.unsynced = false

proc append*(jf: JournalFile; e: var JournalEntry) =
  ## Writes one record with a single `write(2)`; the caller assigns `seqnum`.
  ## Entries with PRIORITY at most `crit` are synced at once.
  e.seqnumId = jf.header.seqnumId
  let rec = encodeRecord(e)
  var wrote = posix.write(jf.fd, unsafeAddr rec[0], rec.len)
  if wrote != rec.len:
    let err = osLastError()
    if wrote > 0: discard truncate(jf.path.cstring, Off(jf.size))   # no partial record
    raiseOSError(err, jf.path)
  if jf.count == 0:
    jf.header.firstSeq = e.seqnum
    jf.header.firstTime = e.realtime
    patchHeader(jf.path, 64, le64(e.seqnum) & le64(uint64(e.realtime)))
  if jf.count mod IndexEvery == 0:
    appendIndexEntry(jf.path, IndexEntry(seqnum: e.seqnum, realtime: e.realtime, offset: jf.size))
  jf.size += rec.len
  inc jf.count
  jf.lastSeq = e.seqnum
  jf.lastRealtime = uint64(e.realtime)
  jf.unsynced = true
  if e.priority in 0 .. 2: jf.sync()

proc close*(jf: JournalFile) =
  if jf.fd >= 0:
    jf.sync()
    discard posix.close(jf.fd)
    jf.fd = -1

proc archive*(jf: JournalFile): string =
  ## Marks the file immutable and renames it (and its index); returns the new
  ## path. An empty file is deleted instead and "" is returned.
  jf.close()
  if jf.count == 0:
    removeFile(jf.path)
    removeFile(indexPath(jf.path))
    return ""
  jf.header.flags = jf.header.flags or FlagArchived
  var flags = ""
  for i in 0 ..< 4: flags.add char((jf.header.flags shr (8 * i)) and 0xFF)
  patchHeader(jf.path, 8, flags)
  result = jf.path.parentDir / archivedName(jf.header)
  moveFile(jf.path, result)
  try: moveFile(indexPath(jf.path), indexPath(result))
  except OSError: discard
