## Client side of the intake sockets (section 18.2.6): used by the manager and tools.
import std/[os, posix]
import ./[format, intake_native, intake_stream, sockutil]
import ../common/logging

const MaxInlineDatagram = 128 * 1024   ## larger entries travel in a sealed memfd

proc nativeSocketPath*(sysrun: string): string = sysrun / "journal" / "socket"
proc streamSocketPath*(sysrun: string): string = sysrun / "journal" / "stdout"
proc syslogSocketPath*(sysrun: string): string = sysrun / "journal" / "dev-log"

proc journalSend*(sysrun: string; fields: openArray[Field]): bool {.discardable.} =
  ## One native-protocol datagram; false when journald cannot be reached.
  let body = encodeNative(fields)
  let path = nativeSocketPath(sysrun)
  if body.len <= MaxInlineDatagram: return sendDatagram(path, body)
  let fd = memfdOf(body)
  if fd < 0: return false
  defer: discard close(fd)
  sendDatagram(path, "", [fd])

proc openStream*(sysrun: string; header: StreamHeader): cint =
  ## A stream socket (write side only) to the journal for a service's standard
  ## descriptor, or -1 when journald is not up.
  result = connectUnix(streamSocketPath(sysrun), stream = true)
  if result < 0: return -1
  let h = encodeStreamHeader(header)
  var off = 0
  while off < h.len:
    let n = write(result, unsafeAddr h[off], h.len - off)
    if n <= 0:
      discard close(result)
      return -1
    off += n
  discard shutdown(SocketHandle(result), SHUT_RD)

# --- the manager's own messages (section 12.1)

type JournalQueue* = ref object
  ## Messages kept (at most `MaxQueued`, oldest dropped) until journald accepts them.
  sysrun*: string
  pending: seq[seq[Field]]

const MaxQueued* = 4096

proc newJournalQueue*(sysrun: string): JournalQueue = JournalQueue(sysrun: sysrun)

proc flush*(q: JournalQueue) =
  ## Sends queued messages in order; stops at the first one journald refuses.
  while q.pending.len > 0:
    if not journalSend(q.sysrun, q.pending[0]): return
    q.pending.delete(0)

proc send*(q: JournalQueue; fields: seq[Field]) =
  ## Sends now (after any backlog) or queues when journald is unreachable.
  q.flush
  if q.pending.len == 0 and journalSend(q.sysrun, fields): return
  q.pending.add fields
  if q.pending.len > MaxQueued: q.pending.delete(0)

proc queued*(q: JournalQueue): int = q.pending.len

proc installLogSink*(q: JournalQueue) =
  ## Makes `logInfo/logWarn/logErr` also reach the journal as `SYSLOG_IDENTIFIER=systemd`
  ## entries, with `UNIT=` when a unit is given.
  logging.sink = proc(level: int; unit, msg: string) =
    var f = @[("MESSAGE", msg), ("PRIORITY", $level), ("SYSLOG_IDENTIFIER", "systemd")]
    if unit.len > 0: f.add ("UNIT", unit)
    q.send f
