## One journal directory (section 12.2, section 12.7): the active file, rotation, archived
## file naming, vacuum by size/age/count, disk usage and the volatile ->
## persistent flush. Time and randomness are injected.
import std/[os, posix, options, strutils, algorithm]
import ./[format, index, writer, reader]
import ../common/clock

type
  StorageLimits* = object
    maxUse*: int64              ## bytes of all files; 0 = unlimited
    keepFree*: int64            ## minimum free bytes on the filesystem; 0 = none
    maxFileSize*: int64
    maxFiles*: int              ## 0 = unlimited
    maxFileSecUsec*: int64      ## 0 = no age rotation
    maxRetentionUsec*: int64    ## 0 = keep forever
  Storage* = ref object
    dir*: string
    machineId*, seqnumId*: string    ## 16 raw bytes
    nextSeq*: uint64
    active*: JournalFile             ## nil until the first entry
    limits*: StorageLimits
    clock*: clock.Clock
    rng*: Rng
    mode*: Mode
    activeSince: int64
    dropped*: int                    ## entries lost to ENOSPC
    freeSpace*: proc(dir: string): int64   ## injectable for tests
  FileInfo* = object
    path*: string
    archived*: bool
    size*: int64
    firstTime*: int64
  FileSummary* = object
    header*: FileHeader
    lastSeq*: uint64
    lastRealtime*: int64
    size*: int64

const ActiveName* = "system.jrn"

proc fsStat(dir: string): tuple[total, free: int64] =
  var st: Statvfs
  if statvfs(dir.cstring, st) == 0:
    result = (int64(st.f_blocks) * int64(st.f_frsize), int64(st.f_bavail) * int64(st.f_frsize))

proc defaultLimits*(dir: string): StorageLimits =
  ## systemd-like defaults: 10% of the filesystem (at most 4 GiB) in use, 15% free.
  let (total, _) = fsStat(dir)
  let maxUse = if total > 0: min(total div 10, 4'i64 shl 30) else: 512'i64 shl 20
  StorageLimits(maxUse: maxUse, keepFree: total * 15 div 100,
    maxFileSize: clamp(maxUse div 8, 1'i64 shl 20, 128'i64 shl 20), maxFiles: 100,
    maxFileSecUsec: 30'i64 * 86400 * UsecPerSec)

proc listFiles*(dir: string): seq[FileInfo] =
  ## Archived files oldest first, then the active file.
  var active: Option[FileInfo]
  try:
    for k, p in walkDir(dir):
      if k != pcFile: continue
      let n = p.extractFilename
      if n == ActiveName:
        active = some(FileInfo(path: p, size: getFileSize(p)))
      elif n.startsWith("system@") and n.endsWith(".jrn"):
        var ft = 0'i64
        try: ft = int64(parseHexInt(n[n.len - 20 ..< n.len - 4]).uint64)
        except ValueError: discard
        result.add FileInfo(path: p, archived: true, size: getFileSize(p), firstTime: ft)
  except OSError: discard
  result.sort(proc(a, b: FileInfo): int = cmp((a.firstTime, a.path), (b.firstTime, b.path)))
  if active.isSome: result.add active.get

proc fileSummary*(path: string): Option[FileSummary] =
  ## Header, last sequence number and time of a file (without a full scan when
  ## an index exists).
  var f: File
  if not open(f, path, fmRead): return
  defer: close(f)
  let h = readHeader(f)
  if h.isNone: return
  var r = FileSummary(header: h.get, size: getFileSize(path))
  let ix = loadIndex(path)
  discard scanRecords(f, r.size, (if ix.len > 0: ix[^1].offset else: HeaderSize.int64),
    proc(e: var JournalEntry; off: int64): bool =
      r.lastSeq = e.seqnum
      r.lastRealtime = e.realtime
      true)
  some(r)

proc fileBytes(path: string): int64 =
  try: result = getFileSize(path)
  except OSError: discard
  try: result += getFileSize(indexPath(path))
  except OSError: discard

proc now(s: Storage): int64 = s.clock.realUsec()

proc openStorage*(dir, machineId: string; limits: StorageLimits; clock: clock.Clock; rng: Rng;
                  mode: Mode = 0o640; dirMode: Mode = 0o750): Storage =
  ## Creates `dir` if needed, picks up the newest file's sequence stream and
  ## reopens an active file left by an earlier run (recovering a torn tail).
  createDir(dir)
  discard chmod(dir.cstring, dirMode)
  result = Storage(dir: dir, machineId: machineId, limits: limits, clock: clock, rng: rng,
    mode: mode, nextSeq: 1, seqnumId: rng.bytes(16),
    freeSpace: proc(d: string): int64 = fsStat(d).free)
  let files = listFiles(dir)
  for fi in files:
    let sm = fileSummary(fi.path)
    if sm.isNone: continue
    result.seqnumId = sm.get.header.seqnumId
    result.nextSeq = max(result.nextSeq, sm.get.lastSeq + 1)
  if files.len > 0 and not files[^1].archived:
    let sm = fileSummary(files[^1].path)
    if sm.isSome and (sm.get.header.flags and FlagArchived) != 0:
      moveFile(files[^1].path, dir / archivedName(sm.get.header))   # crashed mid-rotation
      try: moveFile(indexPath(files[^1].path), indexPath(dir / archivedName(sm.get.header)))
      except OSError: discard
    elif sm.isSome:
      result.active = openJournalFile(files[^1].path, machineId, result.seqnumId, rng, mode)
      result.activeSince = if sm.get.header.firstTime > 0: sm.get.header.firstTime else: result.now

proc ensureActive(s: Storage) =
  if s.active == nil:
    s.active = openJournalFile(s.dir / ActiveName, s.machineId, s.seqnumId, s.rng, s.mode)
    s.activeSince = s.now

proc diskUsage*(s: Storage): int64 =
  for fi in listFiles(s.dir): result += fileBytes(fi.path)

proc vacuum*(s: Storage; maxArchivedBytes = -1'i64; maxAgeUsec = -1'i64; maxTotalBytes = -1'i64;
             keepFree = 0'i64; maxFiles = 0): int64 =
  ## Deletes archived files (never the active one) and returns the bytes freed.
  ## Files whose newest entry is older than `maxAgeUsec` go first; then the oldest
  ## files go until the archived size is within `maxArchivedBytes`, the total
  ## within `maxTotalBytes`, the free space at least `keepFree` and the file count
  ## at most `maxFiles` (a negative or zero limit is not applied).
  var archived: seq[FileInfo]
  var freed = 0'i64
  var activeBytes = 0'i64
  var count = 0
  for fi in listFiles(s.dir):
    inc count
    if fi.archived: archived.add fi else: activeBytes = fileBytes(fi.path)
  proc drop(i: int) =
    let b = fileBytes(archived[i].path)
    try:
      removeFile(archived[i].path)
      removeFile(indexPath(archived[i].path))
      freed += b
    except OSError: discard
    archived.delete(i)
    dec count
  if maxAgeUsec >= 0:
    let cutoff = s.now - maxAgeUsec
    var i = 0
    while i < archived.len:
      let sm = fileSummary(archived[i].path)
      if sm.isNone or sm.get.lastRealtime < cutoff: drop(i) else: inc i
  while archived.len > 0:
    var arch = 0'i64
    for fi in archived: arch += fileBytes(fi.path)
    let tooBig = (maxArchivedBytes >= 0 and arch > maxArchivedBytes) or
                 (maxTotalBytes > 0 and arch + activeBytes > maxTotalBytes)
    let tooFull = keepFree > 0 and s.freeSpace(s.dir) < keepFree
    let tooMany = maxFiles > 0 and count > maxFiles
    if not (tooBig or tooFull or tooMany): break
    drop(0)
  freed

proc enforceLimits*(s: Storage; usageFactor = 1.0): int64 =
  ## Vacuum with the configured limits (`usageFactor` 0.5: the emergency vacuum).
  let l = s.limits
  s.vacuum(maxAgeUsec = (if l.maxRetentionUsec > 0: l.maxRetentionUsec else: -1),
    maxTotalBytes = int64(float(l.maxUse) * usageFactor), keepFree = l.keepFree,
    maxFiles = l.maxFiles)

proc sync*(s: Storage) =
  if s.active != nil: s.active.sync

proc rotate*(s: Storage) =
  ## Archives the active file (a no-op while it is empty) and vacuums.
  if s.active == nil: return
  discard s.active.archive()
  s.active = nil
  discard s.enforceLimits()

proc needsRotation(s: Storage): bool =
  s.active != nil and s.active.count > 0 and
    ((s.limits.maxFileSize > 0 and s.active.size >= s.limits.maxFileSize) or
     (s.limits.maxFileSecUsec > 0 and s.now - s.activeSince >= s.limits.maxFileSecUsec))

proc rotateIfDue*(s: Storage) =
  if s.needsRotation: s.rotate

proc append(s: Storage; e: var JournalEntry): bool =
  for attempt in 0 .. 1:
    try:
      s.ensureActive
      s.active.append(e)
      s.nextSeq = max(s.nextSeq, e.seqnum + 1)
      return true
    except OSError as err:
      if attempt == 1 or err.errorCode != ENOSPC: break
      discard s.enforceLimits(0.5)
  inc s.dropped

proc store*(s: Storage; e: var JournalEntry): bool =
  ## Assigns the next sequence number and appends (rotating first when due).
  ## False when the entry had to be dropped.
  if s.needsRotation: s.rotate
  e.seqnum = s.nextSeq
  s.append(e)

proc flushInto*(vol, pers: Storage): int =
  ## Appends every entry of `vol` to `pers` (same timestamps, boot IDs and
  ## fields; sequence numbers kept when the streams agree) and deletes the
  ## volatile files. Returns the number of entries copied.
  vol.sync
  if pers.active == nil and listFiles(pers.dir).len == 0:
    pers.seqnumId = vol.seqnumId       # an empty journal continues the volatile stream
    pers.nextSeq = 1                   # appends advance it past the preserved numbers
  let j = openJournal(@[vol.dir])
  var ok = true
  var copied = 0
  j.forEachEntry(JournalQuery(), proc(e: JournalEntry): bool =
    var c = e
    if e.seqnumId == pers.seqnumId:
      if e.seqnum < pers.nextSeq: return true     # already flushed
      ok = pers.append(c) and ok
    else:
      ok = pers.store(c) and ok
    inc copied
    true)
  result = copied
  if ok:
    pers.sync
    if vol.active != nil: vol.active.close; vol.active = nil
    for fi in listFiles(vol.dir):
      removeFile(fi.path)
      try: removeFile(indexPath(fi.path))
      except OSError: discard
    try: removeDir(vol.dir)
    except OSError: discard
