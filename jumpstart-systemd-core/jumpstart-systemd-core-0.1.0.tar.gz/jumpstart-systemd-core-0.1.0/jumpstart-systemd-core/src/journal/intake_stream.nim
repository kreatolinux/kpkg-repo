## The stdout stream protocol (section 10.9, section 12.3): the seven-line header (with
## optional `X-SDC-*` extension lines before it), then one entry per line.
## `StreamParser` is a pure state machine fed with whatever bytes arrive.
import std/[strutils, base64]
import ./format

type
  StreamHeader* = object
    identifier*, unit*: string
    priority*: int                       ## 0..7
    levelPrefix*: bool
    forwardSyslog*, forwardKmsg*, forwardConsole*: bool
    extraFields*: seq[Field]             ## X-SDC-Fields (LogExtraFields=)
    levelMax*: int                       ## X-SDC-LevelMax; -1 = none
    rateIntervalUsec*, rateBurst*: int64 ## X-SDC-RateLimit; 0 = default
    facility*: int                       ## X-SDC-Facility, default 3 (daemon)
  StreamLine* = object
    priority*: int
    message*: string
  StreamParser* = ref object
    header*: StreamHeader
    ready*, failed*: bool
    lineMax: int
    pending: string                      ## header bytes, then the partial line
    headerLines: seq[string]
    atLineStart: bool
    curPriority: int

const
  MaxHeaderBytes = 128 * 1024
  DefaultLineMax* = 48 * 1024

proc defaultHeader*(): StreamHeader =
  StreamHeader(priority: 6, levelPrefix: true, levelMax: -1, facility: 3)

proc b01(b: bool): string =
  if b: "1\n" else: "0\n"

proc encodeStreamHeader*(h: StreamHeader): string =
  if h.extraFields.len > 0:
    var raw = ""
    for i, (k, v) in h.extraFields:
      if i > 0: raw.add '\0'
      raw.add k & "=" & v
    result.add "X-SDC-Fields: " & encode(raw) & "\n"
  if h.levelMax >= 0: result.add "X-SDC-LevelMax: " & $h.levelMax & "\n"
  if h.rateIntervalUsec > 0 or h.rateBurst > 0:
    result.add "X-SDC-RateLimit: " & $h.rateIntervalUsec & " " & $h.rateBurst & "\n"
  if h.facility != 3: result.add "X-SDC-Facility: " & $h.facility & "\n"
  result.add h.identifier & "\n" & h.unit & "\n" & $clamp(h.priority, 0, 7) & "\n"
  result.add b01(h.levelPrefix) & b01(h.forwardSyslog) & b01(h.forwardKmsg) & b01(h.forwardConsole)

proc newStreamParser*(lineMax = DefaultLineMax): StreamParser =
  StreamParser(header: defaultHeader(), lineMax: lineMax, atLineStart: true)

proc applyExtension(h: var StreamHeader; line: string) =
  let c = line.find(':')
  if c < 0: return
  let name = line[0 ..< c]
  let value = line[c + 1 .. ^1].strip
  try:
    case name
    of "X-SDC-Fields":
      for item in decode(value).split('\0'):
        let eq = item.find('=')
        if eq > 0 and item[0] != '_' and validKey(item[0 ..< eq]):
          h.extraFields.add (item[0 ..< eq], item[eq + 1 .. ^1])
    of "X-SDC-LevelMax": h.levelMax = clamp(parseInt(value), 0, 7)
    of "X-SDC-RateLimit":
      let parts = value.splitWhitespace
      if parts.len == 2:
        h.rateIntervalUsec = parseBiggestInt(parts[0])
        h.rateBurst = parseBiggestInt(parts[1])
    of "X-SDC-Facility": h.facility = clamp(parseInt(value), 0, 23)
    else: discard                       # unknown X-SDC-* lines are ignored
  except ValueError: discard

proc finishHeader(p: StreamParser): bool =
  let l = p.headerLines
  if l[2].len != 1 or l[2][0] notin {'0'..'7'}: return false
  for i in 3 .. 6:
    if l[i] notin ["0", "1"]: return false
  p.header.identifier = l[0]
  p.header.unit = l[1]
  p.header.priority = parseInt(l[2])
  p.header.levelPrefix = l[3] == "1"
  p.header.forwardSyslog = l[4] == "1"
  p.header.forwardKmsg = l[5] == "1"
  p.header.forwardConsole = l[6] == "1"
  p.curPriority = p.header.priority
  true

proc emitLine(p: StreamParser; line: string; res: var seq[StreamLine]) =
  ## `line` is one chunk (at most `lineMax` bytes); `<N>` is only looked for at
  ## the start of a logical line.
  var msg = line
  var prio = p.header.priority
  if p.atLineStart:
    if p.header.levelPrefix and msg.len >= 3 and msg[0] == '<' and msg[1] in {'0'..'7'} and msg[2] == '>':
      p.curPriority = ord(msg[1]) - ord('0')
      msg = msg[3 .. ^1]
    else: p.curPriority = p.header.priority
  prio = p.curPriority
  if msg.len > 0: res.add StreamLine(priority: prio, message: msg)

proc splitLines(p: StreamParser; res: var seq[StreamLine]; final: bool) =
  while true:
    let nl = p.pending.find('\n')
    if nl >= 0 and nl <= p.lineMax:
      p.emitLine(p.pending[0 ..< nl], res)
      p.pending = p.pending[nl + 1 .. ^1]
      p.atLineStart = true
    elif p.pending.len >= p.lineMax and p.lineMax > 0:
      p.emitLine(p.pending[0 ..< p.lineMax], res)
      p.pending = p.pending[p.lineMax .. ^1]
      p.atLineStart = false
    else: break
  if final and p.pending.len > 0:
    p.emitLine(p.pending, res)
    p.pending = ""
    p.atLineStart = true

proc feed*(p: StreamParser; data: string): seq[StreamLine] =
  ## Bytes from the connection; returns the completed entries. `failed` is set
  ## when the header is invalid (the connection should be closed).
  if p.failed: return
  p.pending.add data
  if not p.ready:
    while true:
      let nl = p.pending.find('\n')
      if nl < 0:
        if p.pending.len > MaxHeaderBytes: p.failed = true
        return
      let line = p.pending[0 ..< nl]
      p.pending = p.pending[nl + 1 .. ^1]
      if p.headerLines.len == 0 and line.startsWith("X-SDC-"):
        p.header.applyExtension(line)
        continue
      p.headerLines.add line
      if p.headerLines.len == 7:
        if not p.finishHeader: p.failed = true; return
        p.ready = true
        break
  p.splitLines(result, final = false)

proc finish*(p: StreamParser): seq[StreamLine] =
  ## At EOF: flushes a partial last line.
  if p.ready and not p.failed: p.splitLines(result, final = true)
