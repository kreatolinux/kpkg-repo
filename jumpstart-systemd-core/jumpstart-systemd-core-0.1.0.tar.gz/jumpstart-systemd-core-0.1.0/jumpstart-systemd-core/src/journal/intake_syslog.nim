## Syslog datagrams (section 12.3): RFC 3164-ish `<PRI>[TIMESTAMP HOST ]TAG[PID]: MESSAGE`.
import std/strutils
import ./format

const
  Months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  FacilityUser = 1
  PriorityNotice = 5

proc skipTimestamp(s: string; p: int): int =
  ## Index after `Mmm dd hh:mm:ss ` at `p`, or -1.
  if p + 16 > s.len or s[p ..< p + 3] notin Months or s[p + 3] != ' ' or
     s[p + 6] != ' ' or s[p + 9] != ':' or s[p + 12] != ':' or s[p + 15] != ' ': return -1
  p + 16

proc parseSyslog*(data: string): seq[Field] =
  var s = data.strip(leading = false, chars = {'\n', '\0'})
  var prio = PriorityNotice
  var facility = FacilityUser
  var p = 0
  if s.len > 2 and s[0] == '<':
    let close = s.find('>', 1)
    if close in 2 .. 4 and s[1 ..< close].allCharsInSet({'0'..'9'}):
      let pri = parseInt(s[1 ..< close])
      if pri <= 191:
        prio = pri and 7
        facility = pri shr 3
        p = close + 1
  let ts = skipTimestamp(s, p)
  var tag, pid: string
  var hadTs = ts >= 0
  if hadTs: p = ts
  # a host name follows a timestamp; a tag ends with ':' or '[' (no spaces)
  proc tagEnd(from0: int): int =
    var i = from0
    while i < s.len and i - from0 <= 48 and s[i] notin {':', '[', ' '}: inc i
    if i < s.len and s[i] in {':', '['} and i > from0: i else: -1
  var te = tagEnd(p)
  if hadTs and te < 0:
    let sp = s.find(' ', p)
    if sp > 0:
      te = tagEnd(sp + 1)
      if te >= 0: p = sp + 1
  var msg = s[p .. ^1]
  if te >= 0:
    var q = te
    tag = s[p ..< te]
    if s[q] == '[':
      let rb = s.find(']', q)
      if rb > 0 and s[q + 1 ..< rb].allCharsInSet({'0'..'9'}) and rb + 1 < s.len and s[rb + 1] == ':':
        pid = s[q + 1 ..< rb]
        q = rb + 1
      else: tag = ""
    if tag.len > 0 and s[q] == ':':
      msg = s[q + 1 .. ^1]
      if msg.startsWith(" "): msg = msg[1 .. ^1]
    else: tag = ""; msg = s[p .. ^1]
  result.add ("PRIORITY", $prio)
  result.add ("SYSLOG_FACILITY", $facility)
  if tag.len > 0: result.add ("SYSLOG_IDENTIFIER", tag)
  if pid.len > 0: result.add ("SYSLOG_PID", pid)
  result.add ("MESSAGE", msg)
  result.add ("_TRANSPORT", "syslog")
