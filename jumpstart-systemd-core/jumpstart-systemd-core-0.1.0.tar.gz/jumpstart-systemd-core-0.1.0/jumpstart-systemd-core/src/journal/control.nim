## The journald control socket (section 12.9): JSON lines, one request per connection.
## `handleControl` is pure over `ControlOps`; `controlCall` is the client side.
import std/[posix, os]
import std/json except getStr, getBool, getInt
import ../common/[results, jsonio]
import ./sockutil

type
  ControlOps* = object
    rotate*: proc()
    vacuum*: proc(maxSize, maxAgeUsec: int64; maxFiles: int): int64   ## -1/0 = not given; returns bytes freed
    flush*: proc(): bool                               ## true when entries were moved
    sync*: proc()
    diskUsage*: proc(): int64

proc controlSocketPath*(rt: string): string = rt / "journald.ctl"

proc handleControl*(req: JsonNode; ops: ControlOps): JsonNode =
  ## The answer for one request line (already parsed; nil when it was not JSON).
  proc fail(msg: string): JsonNode = %*{"ok": false, "error": msg}
  if req == nil or req.kind != JObject: return fail("request is not a JSON object")
  try:
    case req.getStr("verb")
    of "rotate": ops.rotate(); %*{"ok": true}
    of "vacuum":
      let size = if req.has("max_size"): int64(req["max_size"].getBiggestInt) else: -1'i64
      let age = if req.has("max_age_usec"): int64(req["max_age_usec"].getBiggestInt) else: -1'i64
      let files = if req.has("max_files"): int(req["max_files"].getBiggestInt) else: 0
      %*{"ok": true, "freed": ops.vacuum(size, age, files)}
    of "flush": %*{"ok": true, "flushed": ops.flush()}
    of "sync": ops.sync(); %*{"ok": true}
    of "disk-usage": %*{"ok": true, "bytes": ops.diskUsage()}
    else: fail("unknown verb: " & req.getStr("verb"))
  except CatchableError as e:
    fail(e.msg)

proc controlCall*(path: string; req: JsonNode; timeoutMs = 30_000): Result[JsonNode] =
  ## One request over the control socket. `error` explains a connect failure.
  let fd = connectUnix(path, stream = true)
  if fd < 0: return err[JsonNode]("cannot connect to " & path & ": " & osErrorMsg(osLastError()))
  defer: discard close(fd)
  let line = $req & "\n"
  var off = 0
  while off < line.len:
    let n = write(fd, unsafeAddr line[off], line.len - off)
    if n <= 0: return err[JsonNode]("write failed: " & osErrorMsg(osLastError()))
    off += n
  var reply = ""
  var buf: array[4096, char]
  while true:
    var pfd = TPollfd(fd: fd, events: POLLIN)
    let r = poll(addr pfd, 1, cint(timeoutMs))
    if r == 0: return err[JsonNode]("timeout waiting for journald")
    if r < 0:
      if osLastError() == OSErrorCode(EINTR): continue
      return err[JsonNode]("poll failed")
    let n = read(fd, addr buf[0], buf.len)
    if n <= 0: break
    for i in 0 ..< n: reply.add buf[i]
    if '\n' in reply: break
  try: ok(parseJson(reply))
  except JsonParsingError: err[JsonNode]("invalid reply from journald")
