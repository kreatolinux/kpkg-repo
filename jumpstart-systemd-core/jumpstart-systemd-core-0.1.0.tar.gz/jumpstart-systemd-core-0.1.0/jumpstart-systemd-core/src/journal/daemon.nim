## journald (section 12): one event loop over the native, stream and syslog sockets and
## the control socket. Sockets are inherited through LISTEN_FDS when present,
## otherwise bound at the SYSRUN paths. `Journald.step` runs one loop iteration so
## tests can drive the daemon without threads; `runJournald` is the entry point.
import std/[os, posix, selectors, json, strutils, tables, sequtils, times]
import jumpstartcore/peercred
import ../common/[roots, clock, logging]
import ./[format, storage, conf, control, metadata, sockutil, intake_native,
          intake_stream, intake_syslog, client, kmsg, ratelimit]

type
  JournaldSetup* = object
    roots*: Roots
    conf*: JournaldConf
    clock*: clock.Clock
    rng*: Rng
    bootId*, machineId*: string          ## 16 raw bytes
    hostname*: string
    inherited*: seq[tuple[fd: cint, name: string]]   ## socket activation
    notifySocket*: string
    watchdogUsec*: int64
    kmsgFd*: cint                        ## > 0: read kernel records from this descriptor (tests)
  Role = enum rNative, rSyslog, rStream, rControl, rConn, rCtlConn, rSignal, rKmsg
  Conn = ref object
    fd: cint
    parser: StreamParser
    peerUid: int64
    meta: seq[Field]
    metaDone: bool
    streamId: string
    buf: string                          ## control connections: the request line
  Journald* = ref object
    setup*: JournaldSetup
    store*: Storage                      ## nil when Storage=none
    volatile*: bool
    sel: Selector[int]
    roles: Table[cint, Role]
    conns: Table[cint, Conn]
    ownSockets: seq[string]
    listeners: seq[cint]
    stopping*: bool
    flushWanted: bool
    lastPeriodic, lastFlushCheck, lastSync, lastWatchdog: int64
    reportedDrops: int
    rate: RateLimiter
    lastRateSweep: int64
    kmsgFd: cint
    kmsgSeq: uint64                      ## last stored kernel sequence number
    kmsgSaved: uint64
    bootOffset: int64                    ## realtime minus boottime at start
    warnings*: seq[string]

const FlushCheckUsec = 5_000_000'i64

proc hex16(raw: string): string = idHex(raw)

proc machineIdRaw(roots: Roots): string =
  try:
    let r = idFromHex(readFile(roots.machineId).strip)
    if r.len == 16: return r
  except IOError: discard
  ZeroId

proc readBootId(roots: Roots; rng: Rng): string =
  try:
    let r = idFromHex(readFile(roots.procfs / "sys/kernel/random/boot_id").strip.replace("-", ""))
    if r.len == 16: return r
  except IOError: discard
  rng.bytes(16)

proc defaultSetup*(roots: Roots): JournaldSetup =
  ## Production values for `roots`: real clock, `/proc` boot ID, hostname, env.
  let rng = newRng()
  var host = newString(256)
  if gethostname(cstring(host), 255) == 0: host = $cstring(host) else: host = "localhost"
  JournaldSetup(roots: roots, conf: loadJournaldConf(roots), clock: newClock(), rng: rng,
    bootId: readBootId(roots, rng), machineId: machineIdRaw(roots), hostname: host,
    notifySocket: getEnv("NOTIFY_SOCKET"),
    watchdogUsec: (try: parseBiggestInt(getEnv("WATCHDOG_USEC", "0")) except ValueError: 0'i64))

proc inheritedSockets*(): seq[tuple[fd: cint, name: string]] =
  ## LISTEN_FDS / LISTEN_FDNAMES (sd_listen_fds); consumes the variables.
  if getEnv("LISTEN_PID") == $getpid():
    let n = try: parseInt(getEnv("LISTEN_FDS", "0")) except ValueError: 0
    let names = getEnv("LISTEN_FDNAMES").split(':')
    for i in 0 ..< n:
      result.add (cint(3 + i), if i < names.len: names[i] else: "")
  delEnv("LISTEN_PID"); delEnv("LISTEN_FDS"); delEnv("LISTEN_FDNAMES")

proc machineDir(s: JournaldSetup): string =
  if s.machineId == ZeroId: "unknown" else: hex16(s.machineId)

proc persistentDir*(s: JournaldSetup): string = s.roots.st / "journal" / s.machineDir
proc volatileDir*(s: JournaldSetup): string = s.roots.rt / "journal" / s.machineDir

proc stAvailable(s: JournaldSetup): bool =
  dirExists(s.roots.st) and access(s.roots.st.cstring, W_OK) == 0

proc modesFor(roots: Roots; persistent: bool): tuple[dir, file: Mode, gid: int] =
  ## section 12.2: 2750/0640 with group systemd-journal for system persistent storage,
  ## 0700/0600 otherwise.
  result = (Mode(0o700), Mode(0o600), -1)
  if persistent and roots.scope == scSystem:
    let g = getgrnam("systemd-journal")
    if g != nil: result = (Mode(0o2750), Mode(0o640), int(g.gr_gid))
    else: result = (Mode(0o2750), Mode(0o600), -1)

proc openStore(d: Journald; dir: string; persistent: bool): Storage =
  let (dirMode, fileMode, gid) = modesFor(d.setup.roots, persistent)
  createDir(dir.parentDir)
  discard chmod(dir.parentDir.cstring, if persistent: Mode(0o750) else: Mode(0o700))
  result = openStorage(dir, d.setup.machineId, d.setup.conf.limitsFor(dir, not persistent),
    d.setup.clock, d.setup.rng, fileMode, dirMode)
  if gid >= 0: discard chown(dir.cstring, Uid(-1), Gid(gid))
  discard chmod(dir.cstring, dirMode)   # chown clears setgid bits on some systems

proc openPersistent(d: Journald): Storage =
  try:
    result = d.openStore(persistentDir(d.setup), true)
  except OSError, IOError:
    d.warnings.add "cannot use persistent journal: " & getCurrentExceptionMsg()
    logWarn("systemd-journald", d.warnings[^1])

proc persistentWanted(d: Journald): bool =
  d.setup.conf.storage in {smAuto, smPersistent}

proc tryFlush*(d: Journald): bool =
  ## Moves volatile entries to the persistent journal once `ST` is usable (section 12.2).
  ## True when entries were flushed or storage switched; a no-op if persistent.
  if not d.volatile or not d.persistentWanted or not stAvailable(d.setup): return false
  let pers = d.openPersistent
  if pers == nil: return false
  if d.store != nil: discard flushInto(d.store, pers)
  d.store = pers
  d.volatile = false
  true

proc selectStorage(d: Journald) =
  let c = d.setup.conf
  d.volatile = true
  case c.storage
  of smNone: d.store = nil
  of smVolatile: d.store = d.openStore(volatileDir(d.setup), false)
  of smAuto, smPersistent:
    if stAvailable(d.setup):
      let pers = d.openPersistent
      if pers != nil:
        d.store = pers
        d.volatile = false
        let vd = volatileDir(d.setup)          # leftovers of an earlier run
        if listFiles(vd).len > 0:
          let vol = d.openStore(vd, false)
          discard flushInto(vol, pers)
        return
    elif c.storage == smPersistent:
      d.warnings.add "persistent journal unavailable: " & d.setup.roots.st & " is not usable, storing volatile"
      logWarn("systemd-journald", d.warnings[^1])
    d.store = d.openStore(volatileDir(d.setup), false)

# --- entries

proc nowUsec(d: Journald): int64 = d.setup.clock.realUsec()

const SyslogMonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

proc syslogLine*(e: JournalEntry): string =
  ## RFC 3164 rendering of an entry for `ForwardToSyslog=`.
  let prio = if e.priority in 0 .. 7: e.priority else: 6
  var facility = 1
  try: facility = parseInt(e.getField("SYSLOG_FACILITY"))
  except ValueError: discard
  if facility notin 0 .. 23: facility = 1
  var tag = e.getField("SYSLOG_IDENTIFIER")
  if tag.len == 0: tag = e.getField("_COMM")
  var pid = e.getField("SYSLOG_PID")
  if pid.len == 0: pid = e.getField("_PID")
  let t = fromUnix(e.realtime div 1_000_000).local
  result = "<" & $(facility * 8 + prio) & ">" & SyslogMonths[ord(t.month) - 1] & " " &
           align($t.monthday, 2) & " " & t.format("HH:mm:ss") & " " & e.getField("_HOSTNAME") & " "
  if tag.len > 0:
    result.add tag
    if pid.len > 0: result.add "[" & pid & "]"
    result.add ": "
  result.add e.getField("MESSAGE")

proc forwardSyslog(d: Journald; e: JournalEntry) =
  ## Section 12.8: sent if some process bound the socket; failures are ignored.
  let prio = if e.priority in 0 .. 7: e.priority else: 6
  if prio > d.setup.conf.maxLevelSyslog: return
  discard sendDatagram(d.setup.roots.sysrun / "journal" / "syslog", syslogLine(e))

proc driverEntry(d: Journald; msg: string; extra: openArray[Field] = []) =
  ## A journald-written entry (`_TRANSPORT=driver`); never rate limited.
  if d.store == nil: return
  var m = JournalEntry(realtime: d.nowUsec, monotonic: d.setup.clock.monoUsec,
    bootId: d.setup.bootId, priority: 4)
  m.fields = @[("MESSAGE", msg), ("PRIORITY", "4"), ("_TRANSPORT", "driver"),
    ("_BOOT_ID", hex16(d.setup.bootId)), ("_HOSTNAME", d.setup.hostname)]
  for f in extra: m.fields.add f
  discard d.store.store(m)

proc rateKey(fields: seq[Field]): string =
  ## The source of an entry: its unit, else `_COMM` and `_UID` ("" when unknown).
  var comm, uid: string
  for f in fields:
    case f.key
    of "_SYSTEMD_UNIT", "_SYSTEMD_USER_UNIT": return f.key & "=" & f.value
    of "_COMM": comm = f.value
    of "_UID": uid = f.value
    else: discard
  if comm.len > 0 or uid.len > 0: "_COMM=" & comm & ";_UID=" & uid else: ""

proc reportSuppressed(d: Journald; key: string; n: int64) =
  if n <= 0: return
  let eq = key.find('=')
  let name = key[eq + 1 .. ^1]
  if key.startsWith("_COMM="):
    d.driverEntry("Suppressed " & $n & " messages from " & name.split(';')[0])
  else:
    d.driverEntry("Suppressed " & $n & " messages from " & name, [(key[0 ..< eq], name)])

proc record*(d: Journald; fields: seq[Field]; transport: string; creds: seq[Field] = @[];
             sourceUsec = 0'i64; extra: seq[Field] = @[]; realtime = 0'i64; monotonic = 0'i64;
             rate: tuple[interval, burst: int64] = (0'i64, 0'i64); forward = false) =
  ## Builds a complete entry (section 12.4) and stores it. `fields` are sender
  ## supplied (or already trusted for syslog and streams). `realtime`/`monotonic`
  ## override the arrival times (kernel records); `rate` the limits of one stream.
  var e = JournalEntry(realtime: if realtime > 0: realtime else: d.nowUsec,
                       monotonic: if monotonic > 0: monotonic else: d.setup.clock.monoUsec,
                       bootId: d.setup.bootId, priority: NoPriority)
  e.fields = fields
  e.fields.add extra
  var havePrio = false
  for f in e.fields:
    if f.key == "PRIORITY" and f.value.len == 1 and f.value[0] in {'0'..'7'}:
      e.priority = ord(f.value[0]) - ord('0')
      havePrio = true
  if havePrio and e.priority > d.setup.conf.maxLevelStore: return
  if not e.hasField("_TRANSPORT"): e.fields.add ("_TRANSPORT", transport)
  e.fields.add creds
  if transport != "kernel" and transport != "driver":
    let c = d.setup.conf
    let verdict = d.rate.check(rateKey(e.fields), d.setup.clock.monoUsec,
      if rate.interval > 0: rate.interval else: c.rateIntervalUsec,
      if rate.burst > 0: rate.burst else: c.rateBurst)
    d.reportSuppressed(rateKey(e.fields), verdict.reportSuppressed)
    if not verdict.allow: return
  e.fields.add ("_BOOT_ID", hex16(d.setup.bootId))
  e.fields.add ("_MACHINE_ID", hex16(d.setup.machineId))
  e.fields.add ("_HOSTNAME", d.setup.hostname)
  e.fields.add ("_SOURCE_REALTIME_TIMESTAMP", $(if sourceUsec > 0: sourceUsec else: e.realtime))
  if d.setup.conf.forwardToSyslog or forward: d.forwardSyslog(e)
  if d.store == nil: return
  discard d.store.store(e)
  if d.store.dropped > d.reportedDrops:
    let n = d.store.dropped - d.reportedDrops
    d.reportedDrops = d.store.dropped
    d.driverEntry("Suppressed " & $n & " messages from journald (no space left)")

proc credFields(d: Journald; dg: Datagram): seq[Field] =
  if dg.hasCreds: result = processFields(d.setup.roots, dg.pid, int(dg.uid), int(dg.gid))

proc handleDatagram*(d: Journald; dg: Datagram; role: Role) =
  ## One datagram of the native or syslog socket.
  var data = dg.data
  for fd in dg.fds:
    if data.len == 0:
      try: data = readSealedFd(fd, MaxValueLen)
      except OSError as e: logWarn("systemd-journald", "rejected passed descriptor: " & e.msg)
    discard posix.close(fd)
  if dg.truncated: return
  case role
  of rSyslog:
    d.record(parseSyslog(data), "syslog", d.credFields(dg), dg.realtimeUsec)
  else:
    let fields = parseNative(data)
    if fields.len > 0: d.record(fields, "journal", d.credFields(dg), dg.realtimeUsec)

proc submitStreamLine(d: Journald; c: Conn; line: StreamLine) =
  let h = c.parser.header
  if h.levelMax >= 0 and line.priority > h.levelMax: return
  if not c.metaDone:
    c.metaDone = true
    var hasUnit = false
    for f in c.meta:
      if f.key in ["_SYSTEMD_UNIT", "_SYSTEMD_USER_UNIT"]: hasUnit = true
    # root vouches for the unit it names; in user scope the owner of the daemon does
    # (the socket lives below the user's own runtime directory)
    let trusted = c.peerUid == 0 or (d.setup.roots.scope == scUser and c.peerUid == int64(d.setup.roots.uid))
    if not hasUnit and trusted and h.unit.len > 0:
      c.meta.add ((if d.setup.roots.scope == scUser: "_SYSTEMD_USER_UNIT" else: "_SYSTEMD_UNIT"), h.unit)
  var fields = @[("MESSAGE", line.message), ("PRIORITY", $line.priority),
                 ("SYSLOG_FACILITY", $h.facility), ("_TRANSPORT", "stdout"),
                 ("_STREAM_ID", c.streamId)]
  if h.identifier.len > 0: fields.add ("SYSLOG_IDENTIFIER", h.identifier)
  fields.add h.extraFields
  d.record(fields, "stdout", c.meta, rate = (h.rateIntervalUsec, h.rateBurst), forward = h.forwardSyslog)

proc feedStream(d: Journald; c: Conn; data: string; eof: bool) =
  for l in c.parser.feed(data): d.submitStreamLine(c, l)
  if eof:
    for l in c.parser.finish(): d.submitStreamLine(c, l)

# --- sockets and loop

proc closeConn(d: Journald; fd: cint) =
  try: d.sel.unregister(fd.int) except CatchableError: discard
  d.roles.del fd
  d.conns.del fd
  discard posix.close(fd)

proc addListener(d: Journald; fd: cint; role: Role) =
  d.sel.registerHandle(fd.int, {Event.Read}, 0)
  d.roles[fd] = role
  d.listeners.add fd

proc classify(fd: cint; name: string): Role =
  let info = socketInfo(fd)
  if info.path.endsWith("/dev-log") or name == "dev-log": rSyslog
  elif info.stream: rStream
  else: rNative

proc ownSocket(d: Journald; path: string; stream: bool; mode: Mode; role: Role) =
  let fd = bindUnix(path, stream, mode)
  d.ownSockets.add path
  d.addListener(fd, role)

proc controlOps(d: Journald): ControlOps =
  ControlOps(
    rotate: proc() = (if d.store != nil: d.store.rotate),
    vacuum: proc(maxSize, maxAge: int64; maxFiles: int): int64 =
      if d.store == nil: 0'i64
      else: d.store.vacuum(maxArchivedBytes = maxSize, maxAgeUsec = maxAge, maxFiles = maxFiles),
    flush: proc(): bool = d.tryFlush(),
    sync: proc() = (if d.store != nil: d.store.sync),
    diskUsage: proc(): int64 =
      for dir in [persistentDir(d.setup), volatileDir(d.setup)]:
        if dirExists(dir):
          var tmp = Storage(dir: dir)
          result += tmp.diskUsage)

proc drainKmsg*(d: Journald) =
  ## Kernel records newer than the last stored sequence number, with the
  ## kernel's timestamps converted to wall-clock time (section 12.3).
  if d.kmsgFd < 0: return
  readKmsg(d.kmsgFd, proc(r: KmsgRecord) =
    if d.kmsgSeq > 0 and r.seq <= d.kmsgSeq: return          # stored before a restart
    d.kmsgSeq = max(d.kmsgSeq, r.seq)
    d.record(kmsgFields(r), "kernel", realtime = d.bootOffset + r.usec, monotonic = r.usec))
  if d.kmsgSeq != d.kmsgSaved:
    d.kmsgSaved = d.kmsgSeq
    saveLastSeq(d.setup.roots.rt, hex16(d.setup.bootId), d.kmsgSeq)

proc newJournald*(setup: JournaldSetup): Journald =
  ## Opens the storage and the sockets (inherited or bound).
  result = Journald(setup: setup, sel: newSelector[int](), roles: initTable[cint, Role](),
                    conns: initTable[cint, Conn]())
  let d = result
  d.selectStorage
  let sysrun = setup.roots.sysrun
  if setup.inherited.len > 0:
    for (fd, name) in setup.inherited:
      adoptListener(fd)
      d.addListener(fd, classify(fd, name))
  else:
    d.ownSocket(nativeSocketPath(sysrun), false, 0o666, rNative)
    d.ownSocket(streamSocketPath(sysrun), true, 0o666, rStream)
    d.ownSocket(syslogSocketPath(sysrun), false, 0o666, rSyslog)
  d.ownSocket(controlSocketPath(setup.roots.rt), true, 0o600, rControl)
  d.rate = newRateLimiter()
  d.kmsgFd = -1
  d.bootOffset = setup.clock.realUsec - setup.clock.boottimeUsec
  if setup.conf.readKmsg and setup.roots.scope == scSystem:
    d.kmsgFd = if setup.kmsgFd > 0: setup.kmsgFd else: openKmsg(setup.roots.devfs / "kmsg")
    if d.kmsgFd >= 0:
      d.kmsgSeq = loadLastSeq(setup.roots.rt, hex16(setup.bootId))
      d.kmsgSaved = d.kmsgSeq
      d.sel.registerHandle(d.kmsgFd.int, {Event.Read}, 0)
      d.roles[d.kmsgFd] = rKmsg
      d.drainKmsg                     # what the ring already holds
  let now = setup.clock.monoUsec
  d.lastPeriodic = now; d.lastFlushCheck = now; d.lastSync = now; d.lastWatchdog = now

proc acceptConn(d: Journald; listener: cint; role: Role) =
  for _ in 0 ..< 64:
    let fd = acceptConn(listener)
    if fd < 0: return
    var c = Conn(fd: fd, parser: newStreamParser(d.setup.conf.lineMax))
    try:
      let pc = peerCredentials(fd)
      c.peerUid = pc.uid
      if role == rStream:
        c.meta = processFields(d.setup.roots, pc.pid, int(pc.uid), int(pc.gid))
        c.streamId = hex16(d.setup.rng.bytes(16))
      else:
        c.peerUid = pc.uid
    except OSError:
      c.peerUid = -1
    d.conns[fd] = c
    d.roles[fd] = if role == rStream: rConn else: rCtlConn
    d.sel.registerHandle(fd.int, {Event.Read}, 0)

proc serveConn(d: Journald; fd: cint) =
  let c = d.conns.getOrDefault(fd)
  if c == nil: return
  var buf: array[65536, char]
  for _ in 0 ..< 16:
    let n = read(fd, addr buf[0], buf.len)
    if n > 0:
      var s = newString(n)
      copyMem(addr s[0], addr buf[0], n)
      d.feedStream(c, s, false)
      if c.parser.failed: d.closeConn(fd); return
    elif n == 0:
      d.feedStream(c, "", true)
      d.closeConn(fd)
      return
    else:
      let e = osLastError()
      if e == OSErrorCode(EAGAIN) or e == OSErrorCode(EWOULDBLOCK): return
      if e != OSErrorCode(EINTR):
        d.closeConn(fd)
        return

proc serveControl(d: Journald; fd: cint) =
  let c = d.conns.getOrDefault(fd)
  if c == nil: return
  var buf: array[4096, char]
  while true:
    let n = read(fd, addr buf[0], buf.len)
    if n <= 0:
      if n < 0 and osLastError() in [OSErrorCode(EAGAIN), OSErrorCode(EWOULDBLOCK)]: return
      break
    for i in 0 ..< n: c.buf.add buf[i]
    if '\n' in c.buf or c.buf.len > 65536: break
  var reply: JsonNode
  if c.peerUid != 0 and c.peerUid != int64(d.setup.roots.uid):
    reply = %*{"ok": false, "error": "permission denied"}
  else:
    let parsed = try: parseJson(c.buf) except JsonParsingError: nil
    reply = handleControl(parsed, controlOps(d))
  let line = $reply & "\n"
  discard fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) and not O_NONBLOCK)
  var off = 0
  while off < line.len:
    let n = write(fd, unsafeAddr line[off], line.len - off)
    if n <= 0: break
    off += n
  d.closeConn(fd)

proc notify*(d: Journald; msg: string) =
  if d.setup.notifySocket.len > 0: discard sendDatagram(d.setup.notifySocket, msg)

proc periodic(d: Journald) =
  let now = d.setup.clock.monoUsec
  if d.flushWanted:
    d.flushWanted = false
    discard d.tryFlush()
  if now - d.lastFlushCheck >= FlushCheckUsec:
    d.lastFlushCheck = now
    discard d.tryFlush()
  if d.store != nil:
    d.store.rotateIfDue
    if d.setup.conf.syncIntervalUsec > 0 and now - d.lastSync >= d.setup.conf.syncIntervalUsec:
      d.lastSync = now
      d.store.sync
  if now - d.lastRateSweep >= 1_000_000:
    d.lastRateSweep = now
    for (key, n) in d.rate.sweep(now): d.reportSuppressed(key, n)
  if d.setup.watchdogUsec > 0 and now - d.lastWatchdog >= d.setup.watchdogUsec div 2:
    d.lastWatchdog = now
    d.notify("WATCHDOG=1")

proc step*(d: Journald; timeoutMs: int) =
  ## One loop iteration: wait up to `timeoutMs`, serve what is ready, run timers.
  for key in d.sel.select(timeoutMs):
    let fd = cint(key.fd)
    case d.roles.getOrDefault(fd, rSignal)
    of rNative, rSyslog:
      let role = d.roles[fd]
      var dg: Datagram
      for _ in 0 ..< 256:
        if not recvDatagram(fd, 256 * 1024, dg): break
        d.handleDatagram(dg, role)
    of rStream: d.acceptConn(fd, rStream)
    of rControl: d.acceptConn(fd, rControl)
    of rConn: d.serveConn(fd)
    of rCtlConn: d.serveControl(fd)
    of rKmsg: d.drainKmsg
    of rSignal:
      if Event.Signal in key.events:
        discard                                  # handled by the signal registrations in run
  d.periodic

proc shutdown*(d: Journald) =
  if d.store != nil: d.store.sync
  for fd in d.listeners: discard posix.close(fd)
  if d.kmsgFd >= 0:
    try: d.sel.unregister(d.kmsgFd.int) except CatchableError: discard
    discard posix.close(d.kmsgFd)
    d.kmsgFd = -1
  for fd in toSeq(d.conns.keys): d.closeConn(fd)
  for p in d.ownSockets: discard unlink(p.cstring)

proc journaldRoots*(): Roots =
  ## `rootsFromEnvironment` with the manager's handoff variables (section 12.1).
  result = rootsFromEnvironment()
  if existsEnv("SDC_RUNTIME_DIR"): result.rt = getEnv("SDC_RUNTIME_DIR")
  if existsEnv("SDC_STATE_DIR"): result.st = getEnv("SDC_STATE_DIR")
  if existsEnv("SDC_SYSRUN"): result.sysrun = getEnv("SDC_SYSRUN")
  if existsEnv("SDC_DEVFS"): result.devfs = getEnv("SDC_DEVFS")     # where /dev/kmsg is (tests)
  if existsEnv("SDC_UNITS_CGROUP"): result.unitsCgroup = getEnv("SDC_UNITS_CGROUP")
  if getEnv("SDC_SCOPE") == "user": result.scope = scUser
  elif getEnv("SDC_SCOPE") == "system": result.scope = scSystem

var stopFlag, flushFlag {.global.}: bool

proc runJournald*(setup: JournaldSetup) =
  ## The daemon loop: READY=1, serve until SIGTERM/SIGINT, SIGUSR1 flushes.
  var s = setup
  let d = newJournald(s)
  proc onTerm(sig: cint) {.noconv.} = stopFlag = true
  proc onUsr1(sig: cint) {.noconv.} = flushFlag = true
  signal(SIGTERM, onTerm)
  signal(SIGINT, onTerm)
  signal(SIGUSR1, onUsr1)
  signal(SIGPIPE, SIG_IGN)
  d.notify("READY=1\nSTATUS=Processing requests...")
  while not stopFlag and not d.stopping:
    if flushFlag:
      flushFlag = false
      d.flushWanted = true
    try: d.step(1000)
    except CatchableError as e: logErr("systemd-journald", "loop error: " & e.msg)
  d.notify("STOPPING=1")
  d.shutdown

proc runJournald*() =
  var s = defaultSetup(journaldRoots())
  s.inherited = inheritedSockets()
  runJournald(s)
