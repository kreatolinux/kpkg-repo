## Reading journal files without any daemon (section 12.6): merged forward and reverse
## iteration over the files of several directories, filters, cursors, boots and
## follow mode (inotify with a 250 ms polling fallback).
import std/[os, posix, options, strutils, tables, algorithm, sequtils]
import ./[format, index, regexlite]

type
  JournalMatch* = object            ## same field => OR, different fields => AND
    field*, value*: string
  JournalQuery* = object
    matches*: seq[JournalMatch]
    disjunctions*: seq[seq[JournalMatch]]   ## "+" in journalctl: OR of AND-groups
    units*, userUnits*: seq[string]  ## `-u` / `--user-unit` (globs); OR over the unit fields
    sinceUsec*, untilUsec*: Option[int64]
    bootIds*: seq[string]            ## hex; empty = all boots
    maxPriority*, minPriority*: Option[int]   ## entries with priority <= max, >= min
    afterCursor*, cursor*: Option[string]     ## lower bounds on (realtime, seqnum)
    reverse*: bool                   ## newest first
    limit*: int                      ## 0 = unlimited
    tail*: bool                      ## with `limit`: keep the last `limit` matches
    grep*: Option[string]            ## regex on MESSAGE
    caseSensitive*: bool
  Journal* = ref object
    dirs*: seq[string]
    files*: seq[string]              ## explicit files (`--file`); used instead of `dirs` when set
  BootInfo* = object
    bootId*: string
    firstUsec*, lastUsec*: int64
  Source = ref object
    path: string
    f: File
    header: FileHeader
    size, pos, headNext: int64
    head: JournalEntry
    hasHead, done: bool

const
  SystemUnitFields = ["_SYSTEMD_UNIT", "UNIT", "COREDUMP_UNIT", "OBJECT_SYSTEMD_UNIT"]
  UserUnitFields = ["_SYSTEMD_USER_UNIT", "USER_UNIT", "OBJECT_SYSTEMD_USER_UNIT"]

proc openJournal*(dirs: seq[string]): Journal = Journal(dirs: dirs)
proc openJournalFiles*(files: seq[string]): Journal = Journal(files: files)

proc message*(e: JournalEntry): string = e.getField("MESSAGE")

proc journalFiles*(dirs: seq[string]): seq[string] =
  ## `*.jrn` files of each directory and of its immediate subdirectories.
  for d in dirs:
    try:
      for kind, p in walkDir(d):
        if kind == pcFile and p.endsWith(".jrn"): result.add p
        elif kind == pcDir:
          for k2, p2 in walkDir(p):
            if k2 == pcFile and p2.endsWith(".jrn"): result.add p2
    except OSError: discard

# --- matching

proc globMatch*(pat, s: string): bool =
  ## `*`, `?` and `[...]` , as journalctl -u accepts.
  proc go(p, i: int; s: string; pat: string): bool =
    if p == pat.len: return i == s.len
    case pat[p]
    of '*':
      for k in i .. s.len:
        if go(p + 1, k, s, pat): return true
      false
    of '?': i < s.len and go(p + 1, i + 1, s, pat)
    of '[':
      let close = pat.find(']', p + 2)
      if close < 0: return i < s.len and s[i] == '[' and go(p + 1, i + 1, s, pat)
      i < s.len and s[i] in pat[p + 1 ..< close] and go(close + 1, i + 1, s, pat)
    else: i < s.len and s[i] == pat[p] and go(p + 1, i + 1, s, pat)
  go(0, 0, s, pat)

type
  MatchGroup = seq[tuple[field: string, values: seq[string]]]
  Compiled = object
    q: JournalQuery
    base: MatchGroup
    alts: seq[MatchGroup]
    rx: Option[regexlite.Regex]
    lowKey: Option[(int64, uint64)]
    lowAfter: bool

proc group(ms: seq[JournalMatch]): MatchGroup =
  for m in ms:
    var found = false
    for g in result.mitems:
      if g.field == m.field: g.values.add m.value; found = true
    if not found: result.add (m.field, @[m.value])

proc holds(g: MatchGroup; e: JournalEntry): bool =
  for (field, values) in g:
    var ok = false
    for f in e.fields:
      if f.key == field and f.value in values: ok = true; break
    if not ok: return false
  true

proc compile(q: JournalQuery): Compiled =
  result.q = q
  result.base = group(q.matches)
  for d in q.disjunctions: result.alts.add group(d)
  if q.grep.isSome:
    result.rx = some(compileRegex(q.grep.get, not q.caseSensitive))
  let c = if q.afterCursor.isSome: q.afterCursor else: q.cursor
  if c.isSome:
    let pc = parseCursor(c.get)
    if pc.isSome:
      result.lowKey = some((pc.get.realtime, pc.get.seqnum))
      result.lowAfter = q.afterCursor.isSome

proc unitHolds(e: JournalEntry; names: seq[string]; fields: openArray[string]): bool =
  for f in e.fields:
    if f.key in fields:
      for n in names:
        if f.value == n or ('*' in n or '?' in n or '[' in n) and globMatch(n, f.value): return true

proc matches(c: Compiled; e: JournalEntry): bool =
  let q = c.q
  if q.sinceUsec.isSome and e.realtime < q.sinceUsec.get: return false
  if q.untilUsec.isSome and e.realtime > q.untilUsec.get: return false
  if c.lowKey.isSome:
    let k = (e.realtime, e.seqnum)
    if k < c.lowKey.get or (c.lowAfter and k == c.lowKey.get): return false
  if q.bootIds.len > 0 and idHex(e.bootId) notin q.bootIds: return false
  let pr = if e.priority == NoPriority: 6 else: e.priority
  if q.maxPriority.isSome and pr > q.maxPriority.get: return false
  if q.minPriority.isSome and pr < q.minPriority.get: return false
  if not c.base.holds(e): return false
  if c.alts.len > 0:
    var any = false
    for g in c.alts:
      if g.holds(e): any = true; break
    if not any: return false
  if q.units.len + q.userUnits.len > 0 and
     not (unitHolds(e, q.units, SystemUnitFields) or unitHolds(e, q.userUnits, UserUnitFields)):
    return false
  if c.rx.isSome and not c.rx.get.isMatch(e.message): return false
  true

# --- sources

proc openSource(path: string; fromPos = HeaderSize.int64): Source =
  var f: File
  if not open(f, path, fmRead): return nil
  let h = readHeader(f)
  if h.isNone: close(f); return nil
  Source(path: path, f: f, header: h.get, size: (try: getFileSize(f) except IOError: 0'i64),
         pos: fromPos)

proc fill(s: Source): bool =
  if s.hasHead: return true
  if s.done: return false
  var next: int64
  for attempt in 0 .. 1:
    if readRecordAt(s.f, s.pos, s.size, s.head, next):
      s.head.seqnumId = s.header.seqnumId
      s.headNext = next
      s.hasHead = true
      return true
    let sz = try: getFileSize(s.f) except IOError: s.size
    if sz == s.size: break
    s.size = sz
  s.done = true
  false

proc pop(s: Source) =
  s.pos = s.headNext
  s.hasHead = false

proc pick(srcs: seq[Source]): Source =
  for s in srcs:
    if s.fill and (result == nil or (s.head.realtime, s.head.seqnum) <
                   (result.head.realtime, result.head.seqnum)):
      result = s

proc openSources(j: Journal; lowUsec: int64): seq[Source] =
  for p in (if j.files.len > 0: j.files else: journalFiles(j.dirs)):
    let s = openSource(p)
    if s == nil: continue
    if lowUsec > 0:
      if s.header.firstSeq == 0: close(s.f); continue    # no entries yet
      s.pos = seekRealtime(loadIndex(p), lowUsec)
    result.add s

proc closeAll(srcs: seq[Source]) =
  for s in srcs: close(s.f)

proc lowBound(c: Compiled): int64 =
  result = if c.q.sinceUsec.isSome: c.q.sinceUsec.get else: 0
  if c.lowKey.isSome: result = max(result, c.lowKey.get[0])

proc trimFront(s: var seq[JournalEntry]; keep: int) =
  if s.len > keep: s = s[s.len - keep .. ^1]

# --- one-shot reading

proc scan(srcs: seq[Source]; c: Compiled; visit: proc(e: JournalEntry): bool;
          highWater: var Table[string, uint64]; dedupByHighWater = false) =
  ## Feeds `visit` the matching entries in (realtime, seqnum) order, skipping
  ## duplicates; stops when `visit` returns false or past `until`.
  var lastKey: (int64, uint64, string)
  var first = true
  while true:
    let s = pick(srcs)
    if s == nil: return
    let e = s.head
    s.pop
    let key = (e.realtime, e.seqnum, e.seqnumId)
    if not first and key == lastKey: continue
    first = false
    lastKey = key
    if c.q.untilUsec.isSome and e.realtime > c.q.untilUsec.get and not dedupByHighWater: return
    let hw = highWater.getOrDefault(e.seqnumId, 0)
    if dedupByHighWater and e.seqnum <= hw and hw != 0: continue
    if e.seqnum > hw: highWater[e.seqnumId] = e.seqnum
    if c.matches(e) and not visit(e): return

proc forEachEntry*(j: Journal; q: JournalQuery; visit: proc(e: JournalEntry): bool) =
  ## Streams matching entries oldest first until `visit` returns false.
  ## `reverse`, `limit` and `tail` are ignored (see `entries`).
  let c = compile(q)
  let srcs = j.openSources(lowBound(c))
  defer: closeAll(srcs)
  var hw: Table[string, uint64]
  scan(srcs, c, visit, hw)

proc entries*(j: Journal; q: JournalQuery): seq[JournalEntry] =
  ## Matching entries, oldest first (newest first with `reverse`), at most
  ## `limit`; with `tail` the last `limit` in iteration order of a forward query.
  let c = compile(q)
  let srcs = j.openSources(lowBound(c))
  defer: closeAll(srcs)
  var res: seq[JournalEntry]
  var hw: Table[string, uint64]
  let keepLast = q.limit > 0 and (q.reverse or q.tail)
  scan(srcs, c, proc(e: JournalEntry): bool =
    res.add e
    if keepLast and res.len > q.limit * 2: trimFront(res, q.limit)
    not (q.limit > 0 and not keepLast and res.len >= q.limit), hw)
  if keepLast and res.len > q.limit: trimFront(res, q.limit)
  if q.reverse: res.reverse
  res

iterator entryItems*(j: Journal; q: JournalQuery): JournalEntry =
  for e in entries(j, q): yield e

proc entryIter*(j: Journal; q: JournalQuery): iterator(): JournalEntry =
  ## The section 12.6 iterator form (materialized when called).
  let all = entries(j, q)
  result = iterator(): JournalEntry =
    for e in all: yield e

proc seekCursor*(q: var JournalQuery; cursor: string; after = false): bool =
  ## Restricts `q` to entries at or after (`after`: strictly after) `cursor`.
  if parseCursor(cursor).isNone: return false
  if after: q.afterCursor = some(cursor) else: q.cursor = some(cursor)
  true

proc listBoots*(j: Journal): seq[BootInfo] =
  let srcs = j.openSources(0)
  defer: closeAll(srcs)
  var seen = initTable[string, int]()
  var hw: Table[string, uint64]
  var boots: seq[BootInfo]
  scan(srcs, compile(JournalQuery()), proc(e: JournalEntry): bool =
    let id = idHex(e.bootId)
    if id notin seen:
      seen[id] = boots.len
      boots.add BootInfo(bootId: id, firstUsec: e.realtime)
    boots[seen[id]].lastUsec = e.realtime
    true, hw)
  result = boots
  result.sort(proc(a, b: BootInfo): int = cmp(a.firstUsec, b.firstUsec))

proc fieldValues*(j: Journal; q: JournalQuery; field: string): seq[string] =
  ## Distinct values of `field` among matching entries, in first-seen order.
  let srcs = j.openSources(0)
  defer: closeAll(srcs)
  var seen: Table[string, bool]
  var hw: Table[string, uint64]
  var res: seq[string]
  scan(srcs, compile(q), proc(e: JournalEntry): bool =
    for f in e.fields:
      if f.key == field and f.value notin seen:
        seen[f.value] = true
        res.add f.value
    true, hw)
  res

proc fieldNames*(j: Journal): seq[string] =
  let srcs = j.openSources(0)
  defer: closeAll(srcs)
  var seen: Table[string, bool]
  var hw: Table[string, uint64]
  var res: seq[string]
  scan(srcs, compile(JournalQuery()), proc(e: JournalEntry): bool =
    for f in e.fields:
      if f.key notin seen:
        seen[f.key] = true
        res.add f.key
    true, hw)
  res.sort
  res

# --- follow

when defined(linux):
  proc inotifyInit1(flags: cint): cint {.importc: "inotify_init1", header: "<sys/inotify.h>".}
  proc inotifyAddWatch(fd: cint; path: cstring; mask: uint32): cint
    {.importc: "inotify_add_watch", header: "<sys/inotify.h>".}

type Watcher* = ref object
  fd: cint

proc newWatcher*(): Watcher =
  result = Watcher(fd: -1)
  when defined(linux):
    result.fd = inotifyInit1(cint(0o4000 or 0o2000000))   # IN_NONBLOCK | IN_CLOEXEC

proc watch*(w: Watcher; dirs: seq[string]) =
  when defined(linux):
    if w.fd < 0: return
    for d in dirs:
      if dirExists(d):
        # IN_MODIFY | IN_MOVED_FROM | IN_MOVED_TO | IN_CREATE | IN_DELETE
        discard inotifyAddWatch(w.fd, d.cstring, 0x2 or 0x40 or 0x80 or 0x100 or 0x200)
        try:
          for k, p in walkDir(d):
            if k == pcDir: discard inotifyAddWatch(w.fd, p.cstring, 0x2 or 0x40 or 0x80 or 0x100 or 0x200)
        except OSError: discard
  else: discard

proc waitChange*(w: Watcher; timeoutMs: int) =
  ## Blocks until a watched directory changes or `timeoutMs` passes.
  if w.fd >= 0:
    var pfd = TPollfd(fd: w.fd, events: POLLIN)
    if poll(addr pfd, 1, cint(timeoutMs)) > 0:
      var buf: array[4096, char]
      while read(w.fd, addr buf[0], buf.len) > 0: discard
  else:
    sleep timeoutMs

proc close*(w: Watcher) =
  if w.fd >= 0: discard posix.close(w.fd)

proc follow*(j: Journal; q: JournalQuery; stop: proc(): bool;
             sink: proc(e: JournalEntry): bool; pollMs = 250) =
  ## Emits the last `limit` (all when 0) matching entries, then every new matching
  ## entry until `stop()` or `sink` returns false. Handles files that rotate,
  ## appear and vanish. `reverse` and `until` do not apply.
  var q = q
  q.reverse = false
  q.untilUsec = none(int64)
  q.tail = true
  let c = compile(q)
  var qn = q
  qn.limit = 0
  qn.sinceUsec = none(int64)
  let live = compile(qn)
  var srcs = j.openSources(lowBound(c))
  var hw: Table[string, uint64]
  var go = true
  var initial = newSeq[JournalEntry]()
  scan(srcs, c, proc(e: JournalEntry): bool =
    initial.add e
    if q.limit > 0 and initial.len > q.limit * 2: trimFront(initial, q.limit)
    true, hw)
  if q.limit > 0 and initial.len > q.limit: trimFront(initial, q.limit)
  for e in initial:
    if not sink(e): go = false; break
  let w = newWatcher()
  defer:
    closeAll(srcs)
    w.close
  while go and not stop():
    # pick up new files, follow renames, drop vanished ones
    var paths: seq[string]
    if j.files.len > 0:
      w.watch(j.files.mapIt(it.parentDir).deduplicate)
      paths = j.files.filterIt(fileExists(it))
    else:
      w.watch(j.dirs)
      paths = journalFiles(j.dirs)
    var kept: seq[Source]
    for s in srcs:
      s.done = false
    for p in paths:
      var known: Source
      for s in srcs:
        if s.path == p: known = s
      if known != nil: kept.add known; continue
      let n = openSource(p)
      if n == nil: continue
      var renamed: Source
      for s in srcs:
        if s.header.fileId == n.header.fileId: renamed = s
      if renamed != nil:
        renamed.path = p; kept.add renamed; close(n.f)
      else: kept.add n
    for s in srcs:
      if s notin kept: close(s.f)
    srcs = kept
    scan(srcs, live, proc(e: JournalEntry): bool =
      go = sink(e)
      go, hw, dedupByHighWater = true)
    if go: w.waitChange(pollMs)
