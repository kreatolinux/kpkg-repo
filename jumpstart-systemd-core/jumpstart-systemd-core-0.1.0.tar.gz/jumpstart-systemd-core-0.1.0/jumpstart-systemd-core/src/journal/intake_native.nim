## The native journal protocol (section 12.3): one entry per datagram, `KEY=VALUE\n`
## records or `KEY\n` + 64-bit LE length + data + `\n` for binary values. Pure
## parsing; trusted (`_`-prefixed) fields from senders are discarded.
import std/strutils
import ./format

proc le64(s: string; p: int): uint64 =
  for i in 0 ..< 8: result = result or (uint64(ord(s[p + i])) shl (8 * i))

proc parseNative*(data: string): seq[Field] =
  ## Sender-supplied fields in order. Invalid keys, `_`-prefixed keys, oversize
  ## values and a PRIORITY outside 0..7 are dropped; parsing stops at a
  ## malformed binary record.
  var p = 0
  template keep(k, v: string) =
    block:
      let key = k
      let value = v
      if key.len > 0 and key[0] != '_' and validKey(key) and value.len <= MaxValueLen and
         not (key == "PRIORITY" and not (value.len == 1 and value[0] in {'0'..'7'})):
        result.add (key, value)
  while p < data.len:
    var nl = data.find('\n', p)
    if nl < 0: nl = data.len
    let eq = data.find('=', p)
    if eq >= 0 and eq < nl:
      keep(data[p ..< eq], data[eq + 1 ..< nl])
      p = nl + 1
    else:                                  # binary form: KEY \n len data \n
      let key = data[p ..< nl]
      if nl + 9 > data.len: return
      let n = le64(data, nl + 1)
      let start = nl + 9
      if n > uint64(MaxValueLen) or uint64(start) + n > uint64(data.len): return
      keep(key, data[start ..< start + int(n)])
      p = start + int(n) + 1               # skip the trailing newline
      if p > data.len: p = data.len

proc encodeNative*(fields: openArray[Field]): string =
  ## The datagram body `sd_journal_send` would build.
  for (k, v) in fields:
    if not validKey(k) and not (k.len > 0 and k[0] == '_' and validKey(k)): continue
    if '\n' in v:
      result.add k & "\n"
      for i in 0 ..< 8: result.add char((uint64(v.len) shr (8 * i)) and 0xFF)
      result.add v & "\n"
    else:
      result.add k & "=" & v & "\n"
