## Unix socket plumbing for journald and its clients: binding, connecting,
## datagrams with credentials / timestamps / passed descriptors (Linux), sealed
## memfds. Everything compiles on macOS; the credential and descriptor parts
## only do real work on Linux.
import std/[os, posix]

type
  Datagram* = object
    data*: string
    uid*, gid*: int64
    pid*: int
    hasCreds*: bool
    realtimeUsec*: int64     ## SO_TIMESTAMP, 0 when unavailable
    fds*: seq[cint]          ## descriptors passed with SCM_RIGHTS (caller closes)
    truncated*: bool

when defined(linux):
  {.emit: """
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <stdint.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/un.h>
#include <unistd.h>
#ifndef F_ADD_SEALS
#define F_ADD_SEALS 1033
#define F_GET_SEALS 1034
#define F_SEAL_SEAL 1
#define F_SEAL_SHRINK 2
#define F_SEAL_GROW 4
#define F_SEAL_WRITE 8
#endif
typedef struct { long long uid, gid; int pid, hascred, nfds, trunc; long long ts; int fds[16]; } sdc_meta;
static long sdc_recv(int fd, char *buf, size_t len, sdc_meta *m) {
  union { char b[CMSG_SPACE(sizeof(struct ucred)) + CMSG_SPACE(sizeof(int) * 16) + CMSG_SPACE(sizeof(struct timeval))]; struct cmsghdr a; } ctl;
  struct iovec iov = { buf, len };
  struct msghdr mh; memset(&mh, 0, sizeof mh); memset(m, 0, sizeof *m);
  mh.msg_iov = &iov; mh.msg_iovlen = 1; mh.msg_control = ctl.b; mh.msg_controllen = sizeof ctl.b;
  long n = recvmsg(fd, &mh, MSG_DONTWAIT | MSG_CMSG_CLOEXEC);
  if (n < 0) return -1;
  m->trunc = (mh.msg_flags & MSG_TRUNC) != 0;
  for (struct cmsghdr *c = CMSG_FIRSTHDR(&mh); c; c = CMSG_NXTHDR(&mh, c)) {
    if (c->cmsg_level != SOL_SOCKET) continue;
    if (c->cmsg_type == SCM_CREDENTIALS) {
      struct ucred u; memcpy(&u, CMSG_DATA(c), sizeof u);
      m->uid = u.uid; m->gid = u.gid; m->pid = u.pid; m->hascred = 1;
    } else if (c->cmsg_type == SCM_RIGHTS) {
      int cnt = (c->cmsg_len - CMSG_LEN(0)) / sizeof(int);
      int *p = (int *)CMSG_DATA(c);
      for (int i = 0; i < cnt; i++) { if (m->nfds < 16) m->fds[m->nfds++] = p[i]; else close(p[i]); }
    } else if (c->cmsg_type == SCM_TIMESTAMP) {
      struct timeval tv; memcpy(&tv, CMSG_DATA(c), sizeof tv);
      m->ts = (long long)tv.tv_sec * 1000000LL + tv.tv_usec;
    }
  }
  return n;
}
static int sdc_send(const char *path, int abstract, const char *buf, size_t len, const int *fds, int nfds) {
  int s = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (s < 0) return -1;
  struct sockaddr_un sa; memset(&sa, 0, sizeof sa); sa.sun_family = AF_UNIX;
  size_t pl = strlen(path);
  if (pl + 1 > sizeof sa.sun_path) { close(s); errno = ENAMETOOLONG; return -1; }
  memcpy(sa.sun_path + (abstract ? 1 : 0), path + (abstract ? 1 : 0), pl);
  socklen_t sl = offsetof(struct sockaddr_un, sun_path) + pl + (abstract ? 0 : 1);
  union { char b[CMSG_SPACE(sizeof(int) * 16)]; struct cmsghdr a; } ctl;
  struct iovec iov = { (void *)buf, len };
  struct msghdr mh; memset(&mh, 0, sizeof mh);
  mh.msg_name = &sa; mh.msg_namelen = sl; mh.msg_iov = &iov; mh.msg_iovlen = 1;
  if (nfds > 0) {
    if (nfds > 16) nfds = 16;
    memset(ctl.b, 0, sizeof ctl.b);
    mh.msg_control = ctl.b; mh.msg_controllen = CMSG_SPACE(sizeof(int) * nfds);
    struct cmsghdr *c = CMSG_FIRSTHDR(&mh);
    c->cmsg_level = SOL_SOCKET; c->cmsg_type = SCM_RIGHTS; c->cmsg_len = CMSG_LEN(sizeof(int) * nfds);
    memcpy(CMSG_DATA(c), fds, sizeof(int) * nfds);
  }
  long r = sendmsg(s, &mh, MSG_NOSIGNAL | MSG_DONTWAIT);
  int e = errno; close(s); errno = e;
  return r < 0 ? -1 : 0;
}
static int sdc_memfd(const char *data, size_t len) {
  int fd = (int)syscall(SYS_memfd_create, "sdc-journal", 3u /* MFD_CLOEXEC|MFD_ALLOW_SEALING */);
  if (fd < 0) return -1;
  size_t off = 0;
  while (off < len) { ssize_t w = write(fd, data + off, len - off); if (w <= 0) { close(fd); return -1; } off += w; }
  if (fcntl(fd, F_ADD_SEALS, F_SEAL_SHRINK | F_SEAL_GROW | F_SEAL_WRITE | F_SEAL_SEAL) < 0) { close(fd); return -1; }
  return fd;
}
static int sdc_seals(int fd) { return fcntl(fd, F_GET_SEALS); }
""".}
  type SdcMeta {.importc: "sdc_meta", nodecl.} = object
    uid, gid: clonglong
    pid, hascred, nfds, trunc: cint
    ts: clonglong
    fds: array[16, cint]
  proc cRecv(fd: cint; buf: pointer; len: csize_t; m: ptr SdcMeta): clong {.importc: "sdc_recv", nodecl.}
  proc cSend(path: cstring; abstract: cint; buf: cstring; len: csize_t; fds: ptr cint; nfds: cint): cint
    {.importc: "sdc_send", nodecl.}
  proc cMemfd(data: cstring; len: csize_t): cint {.importc: "sdc_memfd", nodecl.}
  proc cSeals(fd: cint): cint {.importc: "sdc_seals", nodecl.}

const
  SealsNeeded = 2 or 4 or 8     # F_SEAL_SHRINK | F_SEAL_GROW | F_SEAL_WRITE

proc sockaddrFor(path: string; sa: var Sockaddr_un): SockLen =
  ## `@name` is an abstract socket (as for $NOTIFY_SOCKET).
  zeroMem(addr sa, sizeof sa)
  sa.sun_family = TSa_Family(AF_UNIX)
  if path.len + 1 > sizeof(sa.sun_path): raise newException(OSError, "socket path too long: " & path)
  let abstract = path.len > 0 and path[0] == '@'
  for i in (if abstract: 1 else: 0) ..< path.len: sa.sun_path[i] = path[i]
  SockLen(2 + path.len + (if abstract: 0 else: 1))   # offsetof(sun_path) is 2 on Linux

proc setCloexecNonblock(fd: cint) =
  discard fcntl(fd, F_SETFD, FD_CLOEXEC)
  discard fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) or O_NONBLOCK)

proc bindUnix*(path: string; stream: bool; mode: Mode; passCreds = true): cint =
  ## A bound (and, for streams, listening) non-blocking socket at `path`.
  createDir(path.parentDir)
  discard unlink(path.cstring)
  result = cint(socket(AF_UNIX, if stream: SOCK_STREAM else: SOCK_DGRAM, 0))
  if result < 0: raiseOSError(osLastError(), path)
  var sa: Sockaddr_un
  let sl = sockaddrFor(path, sa)
  if bindSocket(SocketHandle(result), cast[ptr SockAddr](addr sa), sl) != 0:
    let e = osLastError()
    discard close(result)
    raiseOSError(e, path)
  discard chmod(path.cstring, mode)
  if stream and listen(SocketHandle(result), 128) != 0: raiseOSError(osLastError(), path)
  setCloexecNonblock(result)
  when defined(linux):
    if passCreds and not stream:
      var one = cint(1)
      discard setsockopt(SocketHandle(result), SOL_SOCKET, 16, addr one, SockLen(sizeof one))   # SO_PASSCRED
      discard setsockopt(SocketHandle(result), SOL_SOCKET, 29, addr one, SockLen(sizeof one))   # SO_TIMESTAMP
      var big = cint(8 * 1024 * 1024)
      discard setsockopt(SocketHandle(result), SOL_SOCKET, 33, addr big, SockLen(sizeof big))   # SO_RCVBUFFORCE
      discard setsockopt(SocketHandle(result), SOL_SOCKET, SO_RCVBUF, addr big, SockLen(sizeof big))

proc adoptListener*(fd: cint) =
  ## Prepares an inherited descriptor (socket activation) for the event loop.
  setCloexecNonblock(fd)
  when defined(linux):
    var one = cint(1)
    var ty: cint
    var l = SockLen(sizeof ty)
    if getsockopt(SocketHandle(fd), SOL_SOCKET, SO_TYPE, addr ty, addr l) == 0 and ty == SOCK_DGRAM:
      discard setsockopt(SocketHandle(fd), SOL_SOCKET, 16, addr one, SockLen(sizeof one))
      discard setsockopt(SocketHandle(fd), SOL_SOCKET, 29, addr one, SockLen(sizeof one))

proc connectUnix*(path: string; stream: bool): cint =
  ## Connected socket, or -1.
  result = cint(socket(AF_UNIX, if stream: SOCK_STREAM else: SOCK_DGRAM, 0))
  if result < 0: return -1
  discard fcntl(result, F_SETFD, FD_CLOEXEC)
  var sa: Sockaddr_un
  try:
    let sl = sockaddrFor(path, sa)
    if connect(SocketHandle(result), cast[ptr SockAddr](addr sa), sl) != 0:
      discard close(result)
      return -1
  except OSError:
    discard close(result)
    return -1

proc acceptConn*(listener: cint): cint =
  result = cint(accept(SocketHandle(listener), nil, nil))
  if result >= 0: setCloexecNonblock(result)

proc sendDatagram*(path, data: string; fds: openArray[cint] = []): bool {.discardable.} =
  ## One datagram to `path`; false on any failure (no receiver, full buffer...).
  when defined(linux):
    let fdp = if fds.len > 0: unsafeAddr fds[0] else: nil
    cSend(path.cstring, cint(path.len > 0 and path[0] == '@'), data.cstring, csize_t(data.len),
          fdp, cint(fds.len)) == 0
  else:
    if fds.len > 0: return false
    let s = socket(AF_UNIX, SOCK_DGRAM, 0)
    if cint(s) < 0: return false
    defer: discard close(cint(s))
    var sa: Sockaddr_un
    try:
      let sl = sockaddrFor(path, sa)
      sendto(s, data.cstring, data.len, 0, cast[ptr SockAddr](addr sa), sl) == data.len
    except OSError: false

proc recvDatagram*(fd: cint; maxLen = 256 * 1024; got: var Datagram): bool =
  ## Reads one datagram without blocking; false when none is queued.
  var buf = newString(maxLen)
  got = Datagram()
  when defined(linux):
    var m: SdcMeta
    let n = cRecv(fd, addr buf[0], csize_t(maxLen), addr m)
    if n < 0: return false
    buf.setLen n
    got.data = buf
    got.truncated = m.trunc != 0
    got.hasCreds = m.hascred != 0
    got.uid = m.uid; got.gid = m.gid; got.pid = int(m.pid)
    got.realtimeUsec = m.ts
    for i in 0 ..< int(m.nfds): got.fds.add m.fds[i]
  else:
    let n = recv(SocketHandle(fd), addr buf[0], maxLen, 0)   # the descriptor is non-blocking
    if n < 0: return false
    buf.setLen n
    got.data = buf
  true

proc memfdOf*(data: string): cint =
  ## A sealed memfd holding `data` (Linux), else -1.
  when defined(linux): cMemfd(data.cstring, csize_t(data.len)) else: -1

proc readSealedFd*(fd: cint; maxBytes: int): string =
  ## Contents of a passed memfd. Raises `OSError` when it is not fully sealed or
  ## larger than `maxBytes`.
  when defined(linux):
    let seals = cSeals(fd)
    if seals < 0 or (seals and SealsNeeded) != SealsNeeded:
      raise newException(OSError, "memfd is not sealed")
  var st: Stat
  if fstat(fd, st) != 0: raiseOSError(osLastError())
  if st.st_size > maxBytes: raise newException(OSError, "memfd too large")
  result = newString(int(st.st_size))
  var off = 0
  while off < result.len:
    let r = pread(fd, addr result[off], result.len - off, Off(off))
    if r <= 0: raise newException(OSError, "short memfd read")
    off += int(r)

proc socketInfo*(fd: cint): tuple[stream: bool, path: string] =
  ## Socket type and bound path of an inherited descriptor ("" when unnamed).
  var ty: cint
  var l = SockLen(sizeof ty)
  if getsockopt(SocketHandle(fd), SOL_SOCKET, SO_TYPE, addr ty, addr l) == 0:
    result.stream = ty == SOCK_STREAM
  var sa: Sockaddr_un
  var sl = SockLen(sizeof sa)
  if getsockname(SocketHandle(fd), cast[ptr SockAddr](addr sa), addr sl) == 0:
    for i in 0 ..< max(0, int(sl) - 2):
      if i >= sizeof(sa.sun_path) or sa.sun_path[i] == '\0': break
      result.path.add sa.sun_path[i]
