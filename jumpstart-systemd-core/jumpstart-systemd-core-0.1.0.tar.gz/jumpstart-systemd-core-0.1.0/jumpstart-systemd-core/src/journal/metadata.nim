## Trusted entry metadata (section 12.4) derived from credentials and `/proc/PID`.
## The proc root and cgroup layout come from `Roots`, so tests use a fake tree.
import std/[os, strutils, options]
from ../common/names import unitOfCgroupComponent
import ../common/roots
import ./format

proc cgroupPathOf*(cgroupFile: string): string =
  ## The unified-hierarchy path (`0::/a/b`) of a `/proc/PID/cgroup` file.
  for line in cgroupFile.splitLines:
    if line.startsWith("0::"): return line[3 .. ^1].strip

proc relativeTo(path, prefix: string): Option[string] =
  let pre = prefix.strip(leading = false, chars = {'/'})
  if path == pre: some("")
  elif path.startsWith(pre & "/"): some(path[pre.len + 1 .. ^1])
  else: none(string)

proc unitOfCgroup*(cgroupPath, unitsCgroup, cgroupMount: string): tuple[unit, slice: string] =
  ## section 5.2 rule 7: below the core's `units/` cgroup the deepest component ending
  ## in `.unit` names the owner; the deepest `.slice.unit` above it is its slice.
  var prefix = unitsCgroup
  if prefix.startsWith(cgroupMount) and cgroupMount.len > 1: prefix = prefix[cgroupMount.len .. ^1]
  let rel = relativeTo(cgroupPath, prefix)
  if rel.isNone: return
  let parts = rel.get.split('/')
  var at = -1
  for i in countdown(parts.high, 0):
    if parts[i].endsWith(".unit") and unitOfCgroupComponent(parts[i]).isSome: at = i; break
  if at < 0: return
  result.unit = unitOfCgroupComponent(parts[at]).get
  for i in countdown(at - 1, 0):
    if parts[i].endsWith(".slice.unit") and unitOfCgroupComponent(parts[i]).isSome:
      return (result.unit, unitOfCgroupComponent(parts[i]).get)

proc readSmall(path: string): Option[string] =
  try: some(readFile(path)) except IOError: none(string)

proc processFields*(roots: Roots; pid, uid, gid: int): seq[Field] =
  ## `_PID/_UID/_GID` always; the rest only while `/proc/PID` can still be read.
  result.add ("_PID", $pid)
  result.add ("_UID", $uid)
  result.add ("_GID", $gid)
  if pid <= 0: return
  let proc0 = roots.procfs / $pid
  let comm = readSmall(proc0 / "comm")
  if comm.isSome: result.add ("_COMM", comm.get.strip(leading = false))
  try: result.add ("_EXE", expandSymlink(proc0 / "exe"))
  except OSError: discard
  let cmd = readSmall(proc0 / "cmdline")
  if cmd.isSome and cmd.get.len > 0:
    var line = cmd.get.strip(leading = false, chars = {'\0'}).replace('\0', ' ')
    if line.len > 4096: line.setLen 4096
    result.add ("_CMDLINE", line)
  let status = readSmall(proc0 / "status")
  if status.isSome:
    for l in status.get.splitLines:
      if l.startsWith("CapEff:"):
        let v = l[7 .. ^1].strip.strip(trailing = false, chars = {'0'})
        result.add ("_CAP_EFFECTIVE", if v.len == 0: "0" else: v.toLowerAscii)
  let cg = readSmall(proc0 / "cgroup")
  if cg.isSome:
    let path = cgroupPathOf(cg.get)
    if path.len > 0:
      result.add ("_SYSTEMD_CGROUP", path)
      let (unit, slice) = unitOfCgroup(path, roots.unitsCgroup, roots.cgroupMount)
      if unit.len > 0:
        result.add ((if roots.scope == scUser: "_SYSTEMD_USER_UNIT" else: "_SYSTEMD_UNIT"), unit)
        if slice.len > 0: result.add ("_SYSTEMD_SLICE", slice)
        try:
          let inv = expandSymlink(roots.sysrun / "units" / ("invocation:" & unit))
          result.add ("_SYSTEMD_INVOCATION_ID", inv.extractFilename)
        except OSError: discard
