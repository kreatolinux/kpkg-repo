## `journald.conf` (section 12.8): `[Journal]` of /usr/lib, /run and /etc `systemd/`
## with `journald.conf.d` drop-ins (same shadow-by-name rule as section 6.11).
import std/[os, strutils, algorithm, tables]
import ../common/roots
import ./storage

type
  StorageMode* = enum smAuto, smPersistent, smVolatile, smNone
  JournaldConf* = object
    storage*: StorageMode
    systemMaxUse*, systemKeepFree*, systemMaxFileSize*: int64   ## -1 = default
    runtimeMaxUse*, runtimeKeepFree*, runtimeMaxFileSize*: int64
    systemMaxFiles*, runtimeMaxFiles*: int                      ## -1 = default
    maxFileSecUsec*, maxRetentionUsec*, syncIntervalUsec*: int64  ## -1 = default
    lineMax*: int
    maxLevelStore*, maxLevelSyslog*: int
    rateIntervalUsec*, rateBurst*: int64   ## RateLimitIntervalSec=, RateLimitBurst=; 0 = off
    forwardToSyslog*, readKmsg*: bool
    warnings*: seq[string]

const UsecPerSec = 1_000_000'i64

proc defaultConf*(): JournaldConf =
  JournaldConf(systemMaxUse: -1, systemKeepFree: -1, systemMaxFileSize: -1,
    runtimeMaxUse: -1, runtimeKeepFree: -1, runtimeMaxFileSize: -1,
    systemMaxFiles: -1, runtimeMaxFiles: -1, maxFileSecUsec: -1, maxRetentionUsec: -1,
    syncIntervalUsec: 300 * UsecPerSec, lineMax: 48 * 1024, maxLevelStore: 7,
    maxLevelSyslog: 7, rateIntervalUsec: 30 * UsecPerSec, rateBurst: 10000, readKmsg: true)

proc parseSize*(s: string): int64 =
  ## `4G`, `512M`, `100K`, `1024` (bytes; multiples of 1024). Raises ValueError.
  let t = s.strip
  if t.len == 0: raise newException(ValueError, "empty size")
  var i = 0
  while i < t.len and t[i] in {'0'..'9'}: inc i
  if i == 0: raise newException(ValueError, "bad size: " & s)
  let n = parseBiggestInt(t[0 ..< i])
  let unit = t[i .. ^1].strip.toUpperAscii
  let mult = case unit
    of "", "B": 1'i64
    of "K", "KB", "KIB": 1'i64 shl 10
    of "M", "MB", "MIB": 1'i64 shl 20
    of "G", "GB", "GIB": 1'i64 shl 30
    of "T", "TB", "TIB": 1'i64 shl 40
    else: raise newException(ValueError, "bad size unit: " & s)
  n * mult

proc parseTimespan*(s: string): int64 =
  ## systemd.time(7) spans (`5min`, `1h 30min`, `30`: seconds) in microseconds.
  ## `infinity` is 0 (no limit here). Raises ValueError.
  let t = s.strip
  if t == "infinity": return 0
  var total = 0.0
  var any = false
  for word in t.splitWhitespace:
    var i = 0
    while i < word.len and word[i] in {'0'..'9', '.'}: inc i
    if i == 0: raise newException(ValueError, "bad time span: " & s)
    let n = parseFloat(word[0 ..< i])
    let mult = case word[i .. ^1]
      of "", "s", "sec", "second", "seconds": 1e6
      of "us", "usec": 1.0
      of "ms", "msec": 1e3
      of "m", "min", "minute", "minutes": 60e6
      of "h", "hr", "hour", "hours": 3600e6
      of "d", "day", "days": 86400e6
      of "w", "week", "weeks": 7 * 86400e6
      of "month", "months": 30.44 * 86400e6
      of "y", "year", "years": 365.25 * 86400e6
      else: raise newException(ValueError, "bad time unit: " & s)
    total += n * mult
    any = true
  if not any: raise newException(ValueError, "empty time span")
  int64(total)

proc level(value: string): int =
  let v = value.strip.toLowerAscii
  const names = ["emerg", "alert", "crit", "err", "warning", "notice", "info", "debug"]
  if v in names: names.find(v) else: clamp(parseInt(v), 0, 7)

proc applyJournalKey(c: var JournaldConf; key, value: string) =
  template num(field: untyped) = field = parseSize(value)
  template cnt(field: untyped) = field = int(parseBiggestInt(value.strip))
  template span(field: untyped) = field = parseTimespan(value)
  try:
    case key
    of "Storage":
      case value.strip.toLowerAscii
      of "auto": c.storage = smAuto
      of "persistent": c.storage = smPersistent
      of "volatile": c.storage = smVolatile
      of "none": c.storage = smNone
      else: c.warnings.add "invalid Storage=" & value
    of "SystemMaxUse": num(c.systemMaxUse)
    of "SystemKeepFree": num(c.systemKeepFree)
    of "SystemMaxFileSize": num(c.systemMaxFileSize)
    of "SystemMaxFiles": cnt(c.systemMaxFiles)
    of "RuntimeMaxUse": num(c.runtimeMaxUse)
    of "RuntimeKeepFree": num(c.runtimeKeepFree)
    of "RuntimeMaxFileSize": num(c.runtimeMaxFileSize)
    of "RuntimeMaxFiles": cnt(c.runtimeMaxFiles)
    of "MaxFileSec": span(c.maxFileSecUsec)
    of "MaxRetentionSec": span(c.maxRetentionUsec)
    of "SyncIntervalSec": span(c.syncIntervalUsec)
    of "RateLimitIntervalSec": span(c.rateIntervalUsec)
    of "RateLimitBurst": c.rateBurst = parseBiggestInt(value.strip)
    of "ForwardToSyslog": c.forwardToSyslog = parseBool(value.strip)
    of "ReadKMsg": c.readKmsg = parseBool(value.strip)
    of "MaxLevelSyslog": c.maxLevelSyslog = level(value)
    of "LineMax": c.lineMax = int(max(parseSize(value), 79))
    of "MaxLevelStore": c.maxLevelStore = level(value)
    else: discard    # accepted keys that have no effect, and unknown keys
  except ValueError:
    c.warnings.add "invalid value for " & key & "=: " & value

proc parseJournaldConf*(text: string; c: var JournaldConf) =
  ## Applies the `[Journal]` section of one file on top of `c`.
  var inJournal = false
  var pending = ""
  for raw in text.splitLines:
    var line = raw.strip
    if pending.len > 0: line = pending & line; pending = ""
    if line.endsWith("\\"):
      pending = line[0 ..< line.len - 1] & " "
      continue
    if line.len == 0 or line[0] in {'#', ';'}: continue
    if line[0] == '[':
      inJournal = line == "[Journal]"
      continue
    let eq = line.find('=')
    if inJournal and eq > 0: c.applyJournalKey(line[0 ..< eq].strip, line[eq + 1 .. ^1].strip)

proc confDirs(roots: Roots): seq[string] =
  ## Lowest priority first.
  if roots.scope == scSystem: @[roots.usrLib / "systemd", roots.sysrun, roots.etc / "systemd"]
  else: @[roots.usrLib / "systemd", roots.sysrun, roots.etc / "systemd"]

proc loadJournaldConf*(roots: Roots): JournaldConf =
  result = defaultConf()
  let dirs = confDirs(roots)
  for d in dirs:
    try: parseJournaldConf(readFile(d / "journald.conf"), result)
    except IOError: discard
  var drop = initTable[string, string]()     # name -> path, higher directories shadow lower
  for d in dirs:
    try:
      for k, p in walkDir(d / "journald.conf.d"):
        if k in {pcFile, pcLinkToFile} and p.endsWith(".conf"): drop[p.extractFilename] = p
    except OSError: discard
  var names: seq[string]
  for n in drop.keys: names.add n
  names.sort
  for n in names:
    try: parseJournaldConf(readFile(drop[n]), result)
    except IOError: discard

proc limitsFor*(c: JournaldConf; dir: string; runtime: bool): StorageLimits =
  ## Storage limits for `dir`: configured values over filesystem-based defaults.
  result = defaultLimits(dir)
  let (use, keep, size, files) =
    if runtime: (c.runtimeMaxUse, c.runtimeKeepFree, c.runtimeMaxFileSize, c.runtimeMaxFiles)
    else: (c.systemMaxUse, c.systemKeepFree, c.systemMaxFileSize, c.systemMaxFiles)
  if use >= 0:
    result.maxUse = use
    result.maxFileSize = clamp(use div 8, 1'i64 shl 20, 128'i64 shl 20)
  if keep >= 0: result.keepFree = keep
  if size >= 0: result.maxFileSize = size
  if files >= 0: result.maxFiles = files
  if c.maxFileSecUsec >= 0: result.maxFileSecUsec = c.maxFileSecUsec
  if c.maxRetentionUsec >= 0: result.maxRetentionUsec = c.maxRetentionUsec
