## Sparse index beside each journal file (section 12.2): one 24-byte entry
## (seqnum, realtime, offset) for every 128th record. An index is a valid prefix
## of the file's records even while the file grows; it is rebuilt when missing
## or when its last entry no longer matches the file.
import std/os
import ./format

const
  IndexEvery* = 128
  IndexEntrySize = 24

type IndexEntry* = object
  seqnum*: uint64
  realtime*, offset*: int64

proc indexPath*(file: string): string = file & ".idx"

proc encodeIndexEntry*(x: IndexEntry): string =
  for v in [x.seqnum, uint64(x.realtime), uint64(x.offset)]:
    for i in 0 ..< 8: result.add char((v shr (8 * i)) and 0xFF)

proc decodeIndex*(data: string): seq[IndexEntry] =
  for k in 0 ..< data.len div IndexEntrySize:
    var v: array[3, uint64]
    for j in 0 ..< 3:
      for i in 0 ..< 8: v[j] = v[j] or (uint64(ord(data[k * IndexEntrySize + j * 8 + i])) shl (8 * i))
    result.add IndexEntry(seqnum: v[0], realtime: int64(v[1]), offset: int64(v[2]))

proc buildIndex*(path: string): seq[IndexEntry] =
  ## Scans the whole file.
  var f: File
  if not open(f, path): return
  defer: close(f)
  var n = 0
  var res: seq[IndexEntry]
  discard scanRecords(f, getFileSize(path), HeaderSize, proc(e: var JournalEntry; off: int64): bool =
    if n mod IndexEvery == 0:
      res.add IndexEntry(seqnum: e.seqnum, realtime: e.realtime, offset: off)
    inc n
    true)
  res

proc appendIndexEntry*(file: string; x: IndexEntry) =
  ## Best effort: a lagging index is still a valid prefix.
  try:
    var f = open(indexPath(file), fmAppend)
    f.write encodeIndexEntry(x)
    close(f)
  except IOError, OSError: discard

proc lastEntryMatches(path: string; x: IndexEntry): bool =
  var f: File
  if not open(f, path): return false
  defer: close(f)
  var e: JournalEntry
  var next: int64
  readRecordAt(f, x.offset, getFileSize(path), e, next) and e.seqnum == x.seqnum

proc loadIndex*(path: string): seq[IndexEntry] =
  ## The index of `path`, rebuilt (and saved if possible) when stale or missing.
  try:
    result = decodeIndex(readFile(indexPath(path)))
  except IOError: discard
  if result.len > 0 and lastEntryMatches(path, result[^1]): return
  result = buildIndex(path)
  try:
    var data = ""
    for x in result: data.add encodeIndexEntry(x)
    writeFile(indexPath(path), data)
  except IOError: discard

proc seekBy(ix: seq[IndexEntry]; before: proc(x: IndexEntry): bool): int64 =
  ## Offset of the last indexed record for which `before` holds (`ix` is sorted).
  var lo = 0
  var hi = ix.len            # first index where `before` fails
  while lo < hi:
    let mid = (lo + hi) div 2
    if before(ix[mid]): lo = mid + 1 else: hi = mid
  if lo == 0: HeaderSize.int64 else: ix[lo - 1].offset

proc seekSeqnum*(ix: seq[IndexEntry]; seqnum: uint64): int64 =
  ## A scan from the result sees every record with a seqnum >= `seqnum`.
  seekBy(ix, proc(x: IndexEntry): bool = x.seqnum < seqnum)

proc seekRealtime*(ix: seq[IndexEntry]; usec: int64): int64 =
  ## A scan from the result sees every record with a realtime >= `usec`
  ## (assuming realtime is non-decreasing within a file).
  seekBy(ix, proc(x: IndexEntry): bool = x.realtime < usec)
