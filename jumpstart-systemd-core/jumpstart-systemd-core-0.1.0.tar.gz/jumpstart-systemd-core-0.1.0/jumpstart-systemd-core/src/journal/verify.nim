## Journal file inspection for `journalctl --verify` and `--header`: structure,
## per-record CRC-32C, sequence order and the sparse index, read from the file
## alone (no daemon).
import std/[options, os]
import ./[format, index]

type
  FileReport* = object
    path*: string
    readable*: bool              ## a journal file header was found
    problem*: string             ## "" when the file verifies
    header*: FileHeader
    size*: int64
    entries*: int
    lastSeq*: uint64
    firstRealtime*, lastRealtime*, lastMonotonic*: int64
    lastBootId*: string          ## 16 raw bytes of the last record
    archived*: bool

proc inspectFile*(path: string): FileReport =
  ## Reads every record; `problem` names the first defect found.
  var r = FileReport(path: path)
  defer: result = r
  var f: File
  if not open(f, path, fmRead):
    r.problem = "cannot open file"
    return
  defer: close(f)
  r.size = getFileSize(path)
  let h = readHeader(f)
  if h.isNone:
    r.problem = "bad file header (not a journal file)"
    return
  r.readable = true
  r.header = h.get
  r.archived = (h.get.flags and FlagArchived) != 0
  var prevSeq = 0'u64
  var offsets: seq[tuple[seqnum: uint64, offset: int64]]
  var firstSeq = 0'u64
  let validEnd = scanRecords(f, r.size, HeaderSize, proc(e: var JournalEntry; off: int64): bool =
    if r.entries == 0:
      firstSeq = e.seqnum
      r.firstRealtime = e.realtime
    elif e.seqnum <= prevSeq and r.problem.len == 0:
      r.problem = "sequence number " & $e.seqnum & " does not follow " & $prevSeq
    if r.entries mod IndexEvery == 0: offsets.add (e.seqnum, off)
    prevSeq = e.seqnum
    inc r.entries
    r.lastSeq = e.seqnum
    r.lastRealtime = e.realtime
    r.lastMonotonic = e.monotonic
    r.lastBootId = e.bootId
    true)
  if r.problem.len == 0 and validEnd < r.size:
    r.problem = "corrupt or truncated record at offset " & $validEnd
  if r.problem.len == 0 and r.entries > 0 and r.header.firstSeq != 0 and
     r.header.firstSeq != firstSeq:
    r.problem = "header first sequence number " & $r.header.firstSeq &
                     " does not match the first record (" & $firstSeq & ")"
  if r.problem.len == 0 and r.archived and r.entries == 0:
    r.problem = "archived file without entries"
  if r.problem.len == 0:
    # an index must be a prefix of the true record offsets
    var ix: seq[IndexEntry]
    try: ix = decodeIndex(readFile(indexPath(path)))
    except IOError: discard
    for i, x in ix:
      if i >= offsets.len or offsets[i].seqnum != x.seqnum or offsets[i].offset != x.offset:
        r.problem = "index entry " & $i & " does not match the file"
        break
