## Per-source rate limiting: at most `burst` entries per `interval` for each source,
## the rest dropped and counted. When the window ends the dropped count is handed
## back so journald can write the one `Suppressed N messages from SOURCE` entry.
import std/tables

type
  Window = object
    start: int64
    count: int64
    suppressed: int64
    interval, burst: int64
  RateLimiter* = ref object
    windows: Table[string, Window]
  Verdict* = object
    allow*: bool
    reportSuppressed*: int64    ## entries dropped in the previous window of this source

proc newRateLimiter*(): RateLimiter = RateLimiter(windows: initTable[string, Window]())

proc size*(r: RateLimiter): int = r.windows.len

proc check*(r: RateLimiter; key: string; now, interval, burst: int64): Verdict =
  ## One entry from `key`. `interval` or `burst` of 0 disables limiting.
  if key.len == 0 or interval <= 0 or burst <= 0: return Verdict(allow: true)
  var w = r.windows.getOrDefault(key, Window(start: now))
  if r.windows.hasKey(key) and now - w.start >= w.interval:
    result.reportSuppressed = w.suppressed
    w = Window(start: now)
  w.interval = interval
  w.burst = burst
  if w.count < burst:
    inc w.count
    result.allow = true
  else:
    inc w.suppressed
  r.windows[key] = w

proc sweep*(r: RateLimiter; now: int64): seq[tuple[key: string, suppressed: int64]] =
  ## Closes the windows that ended: returns those with dropped entries (so a
  ## source that fell silent is still reported) and forgets idle ones.
  var done: seq[string]
  for k, w in r.windows:
    if now - w.start >= w.interval:
      if w.suppressed > 0: result.add (k, w.suppressed)
      done.add k
  for k in done: r.windows.del k
