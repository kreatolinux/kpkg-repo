## The SDCJRN01 journal file format (section 12.2): record and header encoding, CRC-32C,
## torn-tail aware scanning and cursors. Pure apart from the `File` scanner.
import std/[strutils, options]

type
  Field* = tuple[key, value: string]
  JournalEntry* = object
    seqnum*: uint64
    realtime*, monotonic*: int64     ## microseconds
    bootId*: string                  ## 16 raw bytes
    priority*: int                   ## 0..7, `NoPriority` when absent
    fields*: seq[Field]
    seqnumId*: string                ## 16 raw bytes; set by readers and writers
    crc*: uint32                     ## CRC-32C of the record; set when encoded or decoded
  FileHeader* = object
    flags*: uint32
    fileId*, machineId*, seqnumId*: string   ## 16 raw bytes each
    firstSeq*: uint64
    firstTime*: int64
  Cursor* = object
    seqnumId*, bootId*: string       ## lowercase hex
    seqnum*: uint64
    monotonic*, realtime*: int64
    crc*: uint32

const
  Magic* = "SDCJRN01"
  HeaderSize* = 96
  FlagArchived* = 1'u32
  NoPriority* = 255
  MaxValueLen* = 16 * 1024 * 1024
  MaxRecordLen* = MaxValueLen + 4096
  FixedRecordLen = 8 + 8 + 8 + 16 + 1 + 1 + 2   ## bytes of a record before its fields
  ZeroId* = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"

proc makeCrcTable(): array[256, uint32] =
  for i in 0 ..< 256:
    var c = uint32(i)
    for _ in 0 ..< 8: c = if (c and 1) != 0: (c shr 1) xor 0x82F63B78'u32 else: c shr 1
    result[i] = c
const crcTable = makeCrcTable()

proc crc32c*(data: openArray[char]): uint32 =
  result = 0xFFFFFFFF'u32
  for c in data: result = crcTable[int((result xor uint32(ord(c))) and 0xFF)] xor (result shr 8)
  result = not result

proc idHex*(raw: string): string =
  for c in raw: result.add toHex(ord(c), 2).toLowerAscii

proc idFromHex*(h: string): string =
  ## 16 raw bytes from 32 hex digits; "" when `h` is not a valid ID.
  if h.len != 32: return ""
  for i in 0 ..< 16:
    try: result.add char(parseHexInt(h[2 * i .. 2 * i + 1]))
    except ValueError: return ""

proc validKey*(k: string): bool =
  if k.len < 1 or k.len > 64: return false
  for c in k:
    if c notin {'A'..'Z', '0'..'9', '_'}: return false
  true

proc getField*(e: JournalEntry; key: string): string =
  for f in e.fields:
    if f.key == key: return f.value
proc hasField*(e: JournalEntry; key: string): bool =
  for f in e.fields:
    if f.key == key: return true

proc putLe(s: var string; v: uint64; n: int) =
  for i in 0 ..< n: s.add char((v shr (8 * i)) and 0xFF)
proc getLe(s: openArray[char]; pos, n: int): uint64 =
  for i in 0 ..< n: result = result or (uint64(ord(s[pos + i])) shl (8 * i))

proc encodeHeader*(h: FileHeader): string =
  result = Magic
  result.putLe h.flags, 4
  result.putLe HeaderSize, 4
  result.add h.fileId; result.add h.machineId; result.add h.seqnumId
  result.putLe h.firstSeq, 8
  result.putLe uint64(h.firstTime), 8
  result.add repeat('\0', HeaderSize - result.len)

proc parseHeader*(data: string): Option[FileHeader] =
  if data.len < HeaderSize or data[0 ..< 8] != Magic: return
  if int(getLe(data, 12, 4)) != HeaderSize: return
  some(FileHeader(flags: uint32(getLe(data, 8, 4)), fileId: data[16 ..< 32],
    machineId: data[32 ..< 48], seqnumId: data[48 ..< 64],
    firstSeq: getLe(data, 64, 8), firstTime: int64(getLe(data, 72, 8))))

proc encodeRecord*(e: var JournalEntry): string =
  ## One complete record; sets `e.crc`.
  var body = ""
  body.putLe e.seqnum, 8
  body.putLe uint64(e.realtime), 8
  body.putLe uint64(e.monotonic), 8
  body.add (if e.bootId.len == 16: e.bootId else: ZeroId)
  body.add char(if e.priority in 0 .. 7: e.priority else: NoPriority)
  body.add '\0'
  body.putLe uint64(e.fields.len), 2
  for f in e.fields:
    body.putLe uint64(f.key.len), 2
    body.putLe uint64(f.value.len), 4
    body.add f.key; body.add f.value
  e.crc = crc32c(body)
  body.putLe e.crc, 4
  result.putLe uint64(body.len), 4
  result.add body

proc decodeBody*(body: string; e: var JournalEntry): bool =
  ## `body` is everything after `len`, including the CRC. False when corrupt.
  if body.len < FixedRecordLen + 4: return false
  let crc = uint32(getLe(body, body.len - 4, 4))
  if crc32c(toOpenArray(body, 0, body.len - 5)) != crc: return false
  e = JournalEntry(seqnum: getLe(body, 0, 8), realtime: int64(getLe(body, 8, 8)),
    monotonic: int64(getLe(body, 16, 8)), bootId: body[24 ..< 40],
    priority: ord(body[40]), crc: crc)
  if e.priority > 7: e.priority = NoPriority
  let n = int(getLe(body, 42, 2))
  var p = FixedRecordLen
  let stop = body.len - 4
  for _ in 0 ..< n:
    if p + 6 > stop: return false
    let kl = int(getLe(body, p, 2))
    let vl = int(getLe(body, p + 2, 4))
    p += 6
    if kl < 1 or kl > 64 or vl > MaxValueLen or p + kl + vl > stop: return false
    e.fields.add (body[p ..< p + kl], body[p + kl ..< p + kl + vl])
    p += kl + vl
  p == stop

proc readExact(f: File; n: int): Option[string] =
  var s = newString(n)
  if n > 0 and f.readBuffer(addr s[0], n) != n: return
  some(s)

proc readHeader*(f: File): Option[FileHeader] =
  f.setFilePos 0
  let d = readExact(f, HeaderSize)
  if d.isNone: none(FileHeader) else: parseHeader(d.get)

proc readRecordAt*(f: File; pos, size: int64; e: var JournalEntry; next: var int64): bool =
  ## Decodes the record at `pos`; false for a torn or corrupt one (or the end).
  if pos + 4 + FixedRecordLen + 4 > size: return false
  if getFilePos(f) != pos: f.setFilePos pos   # sequential reads keep the stdio buffer
  let lenb = readExact(f, 4)
  if lenb.isNone: return false
  let n = int64(getLe(lenb.get, 0, 4))
  if n > MaxRecordLen or pos + 4 + n > size: return false
  let body = readExact(f, int(n))
  if body.isNone or not decodeBody(body.get, e): return false
  next = pos + 4 + n
  true

proc scanRecords*(f: File; size, start: int64;
                  visit: proc(e: var JournalEntry; offset: int64): bool): int64 =
  ## Calls `visit` for each valid record from `start`; stops when it returns
  ## false or at the first torn record. Returns the offset after the last record
  ## visited (the valid end of the file when `visit` never stops it).
  var pos = max(start, HeaderSize.int64)
  var e: JournalEntry
  var next: int64
  while readRecordAt(f, pos, size, e, next):
    if not visit(e, pos): return next
    pos = next
  pos

# --- cursors

proc hexNoPad(v: uint64): string =
  result = toHex(v).toLowerAscii.strip(trailing = false, chars = {'0'})
  if result.len == 0: result = "0"

proc cursorOf*(e: JournalEntry): string =
  "s=" & idHex(e.seqnumId) & ";i=" & hexNoPad(e.seqnum) & ";b=" & idHex(e.bootId) &
    ";m=" & hexNoPad(uint64(e.monotonic)) & ";t=" & hexNoPad(uint64(e.realtime)) &
    ";x=" & hexNoPad(e.crc)

proc parseCursor*(s: string): Option[Cursor] =
  var c: Cursor
  var seen: set[char]
  try:
    for part in s.split(';'):
      if part.len < 3 or part[1] != '=': return
      let v = part[2 .. ^1]
      seen.incl part[0]
      case part[0]
      of 's': c.seqnumId = v.toLowerAscii
      of 'b': c.bootId = v.toLowerAscii
      of 'i': c.seqnum = parseHexInt(v).uint64
      of 'm': c.monotonic = parseHexInt(v)
      of 't': c.realtime = parseHexInt(v)
      of 'x': c.crc = uint32(parseHexInt(v))
      else: discard
  except ValueError: return
  if 's' notin seen or 'i' notin seen or 't' notin seen: return
  some(c)
