## Kernel log intake: `/dev/kmsg` records `PRI,SEQ,TIMESTAMP,FLAGS;MESSAGE` plus
## ` KEY=VALUE` continuation lines. `readKmsg` drains a nonblocking descriptor, one
## record per `read(2)` as the kernel delivers them.
import std/[posix, strutils, os]
import ./format

type
  KmsgRecord* = object
    priority*, facility*: int
    seq*: uint64
    usec*: int64                ## microseconds since boot (the kernel's clock)
    message*: string
    device*, subsystem*, sysname*: string

proc unescape(s: string): string =
  ## The kernel writes bytes outside 0x20..0x7e as `\xNN`.
  var i = 0
  while i < s.len:
    if s[i] == '\\' and i + 3 < s.len and s[i + 1] == 'x':
      try:
        result.add char(parseHexInt(s[i + 2 .. i + 3]))
        i += 4
        continue
      except ValueError: discard
    result.add s[i]
    inc i

proc parseKmsg*(raw: string; rec: var KmsgRecord): bool =
  ## False for a record that does not parse (it is skipped).
  let nl = raw.find('\n')
  let head = if nl < 0: raw else: raw[0 ..< nl]
  let semi = head.find(';')
  if semi < 0: return false
  let meta = head[0 ..< semi].split(',')
  if meta.len < 3: return false
  try:
    let pri = parseInt(meta[0])
    rec = KmsgRecord(priority: pri and 7, facility: pri shr 3,
                     seq: uint64(parseBiggestUInt(meta[1])), usec: parseBiggestInt(meta[2]))
  except ValueError: return false
  rec.message = unescape(head[semi + 1 .. ^1])
  if nl >= 0:
    for line in raw[nl + 1 .. ^1].splitLines:
      if line.len < 2 or line[0] != ' ': continue
      let kv = line[1 .. ^1]
      let eq = kv.find('=')
      if eq <= 0: continue
      let v = unescape(kv[eq + 1 .. ^1])
      case kv[0 ..< eq]
      of "DEVICE": rec.device = v
      of "SUBSYSTEM": rec.subsystem = v
      of "SYSNAME": rec.sysname = v
      else: discard
  true

proc kmsgFields*(r: KmsgRecord): seq[Field] =
  result = @[("PRIORITY", $r.priority), ("SYSLOG_FACILITY", $r.facility),
             ("SYSLOG_IDENTIFIER", "kernel"), ("MESSAGE", r.message), ("_TRANSPORT", "kernel")]
  if r.device.len > 0: result.add ("_KERNEL_DEVICE", r.device)
  if r.subsystem.len > 0: result.add ("_KERNEL_SUBSYSTEM", r.subsystem)
  if r.sysname.len > 0: result.add ("_UDEV_SYSNAME", r.sysname)

proc openKmsg*(path: string): cint =
  ## Nonblocking read-only descriptor, -1 when unavailable.
  posix.open(path.cstring, O_RDONLY or O_NONBLOCK or O_CLOEXEC)

proc readKmsg*(fd: cint; deliver: proc(r: KmsgRecord)) =
  ## Reads until the descriptor would block. `EPIPE` means the ring overwrote
  ## records we had not read: the next read continues at the oldest one left.
  var buf = newString(8193)
  for _ in 0 ..< 4096:
    let n = read(fd, addr buf[0], 8192)
    if n > 0:
      var rec: KmsgRecord
      if parseKmsg(buf[0 ..< n], rec): deliver(rec)
    elif n == 0: return
    else:
      let e = osLastError()
      if e == OSErrorCode(EAGAIN) or e == OSErrorCode(EWOULDBLOCK): return
      if e != OSErrorCode(EPIPE) and e != OSErrorCode(EINTR): return

proc seqFile*(rt: string): string = rt / "journald-kmsg-seq"

proc loadLastSeq*(rt, bootHex: string): uint64 =
  ## The last stored sequence number of this boot (`BOOTID SEQ`); 0 when none.
  try:
    let parts = readFile(seqFile(rt)).strip.splitWhitespace
    if parts.len == 2 and parts[0] == bootHex: uint64(parseBiggestUInt(parts[1])) else: 0'u64
  except CatchableError: 0'u64

proc saveLastSeq*(rt, bootHex: string; seq: uint64) =
  try:
    writeFile(seqFile(rt) & ".tmp", bootHex & " " & $seq & "\n")
    moveFile(seqFile(rt) & ".tmp", seqFile(rt))
  except CatchableError: discard
