## What the adapter needs for `log.*` (section 13.7, section 18.2.6): reading the last N
## entries, following, writing through the native socket and talking to journald's
## control socket.
import std/[json, options, times, strutils, os]
import ../common/[roots, results]
import ./[format, reader, client, control]

type LogEntry* = object
  time*, level*, unit*, message*: string

const
  DefaultLines* = 1000
  MaxLines* = 10000
  MaxMessageBytes = 8192

proc journalDirs*(roots: Roots): seq[string] =
  @[roots.rt / "journal", roots.st / "journal"]

proc levelOf*(priority: int): string =
  case priority
  of 0 .. 2: "fatal"
  of 3: "error"
  of 4: "warn"
  of 5: "notice"
  of 7: "debug"
  else: "info"          # 6 and missing

proc priorityOfLevel*(level: string): int =
  ## -1 for an unknown level.
  case level
  of "debug": 7
  of "info": 6
  of "notice": 5
  of "warn": 4
  of "error": 3
  of "fatal": 2
  else: -1

proc rfc3339*(usec: int64): string =
  ## `2026-10-17T12:00:30.123456Z`
  let t = fromUnix(usec div 1_000_000).utc
  t.format("yyyy-MM-dd'T'HH:mm:ss") & "." & align($(usec mod 1_000_000), 6, '0') & "Z"

proc cleanMessage*(raw: string): string =
  ## Invalid UTF-8 becomes U+FFFD, control characters (newlines too) become
  ## spaces, the result is at most 8 KiB.
  var i = 0
  while i < raw.len and result.len < MaxMessageBytes:
    let c = ord(raw[i])
    var n = 0
    if c < 0x80: n = 1
    elif c in 0xC2 .. 0xDF: n = 2
    elif c in 0xE0 .. 0xEF: n = 3
    elif c in 0xF0 .. 0xF4: n = 4
    var valid = n > 0 and i + n <= raw.len
    if valid:
      for k in 1 ..< n:
        if (ord(raw[i + k]) and 0xC0) != 0x80: valid = false
    if valid and n == 3 and ((c == 0xE0 and ord(raw[i + 1]) < 0xA0) or (c == 0xED and ord(raw[i + 1]) >= 0xA0)):
      valid = false
    if valid and n == 4 and ((c == 0xF0 and ord(raw[i + 1]) < 0x90) or (c == 0xF4 and ord(raw[i + 1]) >= 0x90)):
      valid = false
    if not valid:
      result.add "\xEF\xBF\xBD"
      inc i
    elif n == 1 and (c < 0x20 or c == 0x7F):
      result.add ' '
      inc i
    else:
      result.add raw[i ..< i + n]
      i += n
  if result.len > MaxMessageBytes:
    var cut = MaxMessageBytes
    while cut > 0 and (ord(result[cut]) and 0xC0) == 0x80: dec cut
    result.setLen cut

proc toLogEntry*(e: JournalEntry): LogEntry =
  var unit = e.getField("_SYSTEMD_UNIT")
  if unit.len == 0: unit = e.getField("_SYSTEMD_USER_UNIT")
  if unit.len == 0: unit = e.getField("UNIT")
  if unit.len == 0: unit = e.getField("SYSLOG_IDENTIFIER")
  LogEntry(time: rfc3339(e.realtime), level: levelOf(e.priority), unit: unit,
           message: cleanMessage(e.getField("MESSAGE")))

proc unitQuery(roots: Roots; unit: string): JournalQuery =
  if unit.len > 0:
    if roots.scope == scUser: result.userUnits = @[unit] else: result.units = @[unit]

proc readEntries*(roots: Roots; unit: string; sinceUsec, untilUsec: Option[int64];
                  lines: int): seq[LogEntry] =
  ## The last `lines` (default 1000, at most 10000) matching entries, oldest first.
  var q = unitQuery(roots, unit)
  q.sinceUsec = sinceUsec
  q.untilUsec = untilUsec
  q.limit = if lines <= 0: DefaultLines else: min(lines, MaxLines)
  q.tail = true
  for e in openJournal(journalDirs(roots)).entries(q): result.add toLogEntry(e)

proc followEntries*(roots: Roots; unit: string; sinceUsec: Option[int64];
                    sink: proc(e: LogEntry): bool; stop: proc(): bool = nil) =
  ## The last 10 matching entries (or those since `sinceUsec`), then new ones, until
  ## `sink` returns false or `stop()` is true.
  var q = unitQuery(roots, unit)
  q.sinceUsec = sinceUsec
  if sinceUsec.isNone: q.limit = 10
  openJournal(journalDirs(roots)).follow(q,
    proc(): bool = stop != nil and stop(),
    proc(e: JournalEntry): bool = sink(toLogEntry(e)))

proc okVoid(): Result[void] = Result[void](ok: true)

proc writeEntry*(roots: Roots; unit, level, message: string): Result[void] =
  ## `log.write`: a native datagram with SYSLOG_IDENTIFIER=jumpstart.
  let prio = priorityOfLevel(level)
  if prio < 0: return err[void]("E_INVALID: unknown level " & level)
  var fields = @[("MESSAGE", message), ("PRIORITY", $prio), ("SYSLOG_IDENTIFIER", "jumpstart")]
  if unit.len > 0: fields.add ("UNIT", unit)
  if not journalSend(roots.sysrun, fields): return err[void]("E_BACKEND: journald is not running")
  okVoid()

proc journaldControl*(roots: Roots; req: JsonNode): Result[JsonNode] =
  ## `log.rotate` / `log.vacuum`: one request to `RT/journald.ctl`; an
  ## `{"ok":false}` answer becomes an error.
  let r = controlCall(controlSocketPath(roots.rt), req)
  if not r.ok: return err[JsonNode]("E_BACKEND: " & r.error)
  if not r.value{"ok"}.getBool(false):
    return err[JsonNode]("E_BACKEND: " & r.value{"error"}.getStr("journald failed"))
  r
