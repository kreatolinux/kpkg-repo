## A small backtracking POSIX-ERE-style matcher for `journalctl --grep`: `.`,
## `[set]`, `[^set]`, `*`, `+`, `?`, `{m,n}`, `|`, `()`, `^`, `$`, `\` escapes,
## `\d \w \s` and optional case folding. No external regex library is needed.
import std/strutils

type
  Kind = enum nChar, nAny, nSet, nCat, nAlt, nRep, nBol, nEol
  Node = ref object
    kind: Kind
    c: char
    set: set[char]
    kids: seq[Node]
    lo, hi: int
  Regex* = object
    root: Node
    fold: bool

type Parser = object
  s: string
  i: int

proc fail(msg: string) {.noreturn.} = raise newException(ValueError, msg)

proc classOf(c: char): set[char] =
  case c
  of 'd': {'0'..'9'}
  of 'w': {'a'..'z', 'A'..'Z', '0'..'9', '_'}
  of 's': {' ', '\t', '\n', '\r', '\f', '\v'}
  else: {}

proc parseAlt(p: var Parser): Node

proc parseSet(p: var Parser): Node =
  result = Node(kind: nSet)
  var neg = false
  if p.i < p.s.len and p.s[p.i] == '^': neg = true; inc p.i
  var first = true
  while true:
    if p.i >= p.s.len: fail("unterminated [")
    var c = p.s[p.i]
    if c == ']' and not first: inc p.i; break
    first = false
    if c == '[' and p.i + 1 < p.s.len and p.s[p.i + 1] == ':':
      let e = p.s.find(":]", p.i)
      if e < 0: fail("bad character class")
      case p.s[p.i + 2 ..< e]
      of "alpha": result.set.incl {'a'..'z', 'A'..'Z'}
      of "digit": result.set.incl {'0'..'9'}
      of "alnum": result.set.incl {'a'..'z', 'A'..'Z', '0'..'9'}
      of "space": result.set.incl classOf('s')
      of "upper": result.set.incl {'A'..'Z'}
      of "lower": result.set.incl {'a'..'z'}
      of "punct": result.set.incl {'!'..'/', ':'..'@', '['..'`', '{'..'~'}
      else: fail("unknown character class")
      p.i = e + 2
      continue
    inc p.i
    if c == '\\' and p.i < p.s.len:
      c = p.s[p.i]; inc p.i
      if classOf(c).card > 0: result.set.incl classOf(c); continue
    if p.i + 1 < p.s.len and p.s[p.i] == '-' and p.s[p.i + 1] != ']':
      let hi = p.s[p.i + 1]
      if hi < c: fail("bad range")
      result.set.incl {c .. hi}
      p.i += 2
    else: result.set.incl c
  if neg: result.set = {'\0'..'\255'} - result.set

proc parseAtom(p: var Parser): Node =
  let c = p.s[p.i]
  inc p.i
  case c
  of '(':
    result = parseAlt(p)
    if p.i >= p.s.len or p.s[p.i] != ')': fail("unmatched (")
    inc p.i
  of '[': result = parseSet(p)
  of '.': result = Node(kind: nAny)
  of '^': result = Node(kind: nBol)
  of '$': result = Node(kind: nEol)
  of '\\':
    if p.i >= p.s.len: fail("trailing backslash")
    let e = p.s[p.i]
    inc p.i
    if classOf(e).card > 0: result = Node(kind: nSet, set: classOf(e))
    else: result = Node(kind: nChar, c: (if e == 'n': '\n' elif e == 't': '\t' else: e))
  of '*', '+', '?': fail("nothing to repeat")
  else: result = Node(kind: nChar, c: c)

proc parsePiece(p: var Parser): Node =
  result = parseAtom(p)
  while p.i < p.s.len:
    var lo, hi: int
    case p.s[p.i]
    of '*': lo = 0; hi = high(int); inc p.i
    of '+': lo = 1; hi = high(int); inc p.i
    of '?': lo = 0; hi = 1; inc p.i
    of '{':
      let e = p.s.find('}', p.i)
      if e < 0: fail("unterminated {")
      let parts = p.s[p.i + 1 ..< e].split(',')
      try:
        lo = parseInt(parts[0])
        hi = if parts.len == 1: lo elif parts[1].len == 0: high(int) else: parseInt(parts[1])
      except ValueError: fail("bad repeat count")
      p.i = e + 1
    else: break
    result = Node(kind: nRep, kids: @[result], lo: lo, hi: hi)

proc parseCat(p: var Parser): Node =
  result = Node(kind: nCat)
  while p.i < p.s.len and p.s[p.i] notin {'|', ')'}: result.kids.add parsePiece(p)

proc parseAlt(p: var Parser): Node =
  result = Node(kind: nAlt, kids: @[parseCat(p)])
  while p.i < p.s.len and p.s[p.i] == '|':
    inc p.i
    result.kids.add parseCat(p)

proc compileRegex*(pattern: string; ignoreCase = false): Regex =
  ## Raises `ValueError` on a syntax error.
  var p = Parser(s: pattern)
  let root = parseAlt(p)
  if p.i < p.s.len: fail("unmatched )")
  Regex(root: root, fold: ignoreCase)

proc same(a, b: char; fold: bool): bool =
  a == b or (fold and toLowerAscii(a) == toLowerAscii(b))

proc m(n: Node; s: string; i: int; fold: bool; k: proc(j: int): bool): bool =
  case n.kind
  of nChar: i < s.len and same(s[i], n.c, fold) and k(i + 1)
  of nAny: i < s.len and k(i + 1)
  of nSet:
    i < s.len and (s[i] in n.set or (fold and (toLowerAscii(s[i]) in n.set or toUpperAscii(s[i]) in n.set))) and k(i + 1)
  of nBol: i == 0 and k(i)
  of nEol: i == s.len and k(i)
  of nCat:
    proc step(idx, pos: int): bool =
      if idx == n.kids.len: return k(pos)
      m(n.kids[idx], s, pos, fold, proc(j: int): bool = step(idx + 1, j))
    step(0, i)
  of nAlt:
    for kid in n.kids:
      if m(kid, s, i, fold, k): return true
    false
  of nRep:
    proc rep(count, pos: int): bool =
      if count < n.hi and m(n.kids[0], s, pos, fold, proc(j: int): bool = j != pos and rep(count + 1, j)):
        return true
      count >= n.lo and k(pos)
    rep(0, i)

proc isMatch*(r: Regex; s: string): bool =
  ## True when the pattern matches anywhere in `s`.
  for start in 0 .. s.len:
    if m(r.root, s, start, r.fold, proc(j: int): bool = true): return true
