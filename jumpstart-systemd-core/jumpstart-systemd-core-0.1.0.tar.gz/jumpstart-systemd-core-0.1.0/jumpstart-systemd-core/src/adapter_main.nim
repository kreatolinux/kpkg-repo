## Entry point of `systemd-compat`, the persistent adapter (spec §3.3).
import common/roots
import adapter/adapter
quit runAdapter(rootsFromEnvironment())
