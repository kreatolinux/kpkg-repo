## Trust rules (spec §6.2): a definition source counts only when a non-privileged
## user could not have written it. The owner/mode lookup is injectable.
import std/[os, options, posix, strutils]
import ../common/roots

type
  StatInfo* = object
    uid*, mode*: int
    isDir*, isLink*, isReg*: bool
    size*, mtimeNs*: int64
  StatFn* = proc(path: string; follow: bool): Option[StatInfo] {.closure.}
  TrustPolicy* = object
    trustedUids*: seq[int]      ## owners accepted: 0, plus the manager's user in user scope
    stat*: StatFn

proc realStat*(path: string; follow: bool): Option[StatInfo] =
  var st: Stat
  let rc = if follow: posix.stat(path.cstring, st) else: lstat(path.cstring, st)
  if rc != 0: return
  let m = int(st.st_mode)
  some(StatInfo(uid: int(st.st_uid), mode: m and 0o7777,
    isDir: S_ISDIR(st.st_mode), isLink: S_ISLNK(st.st_mode), isReg: S_ISREG(st.st_mode),
    size: int64(st.st_size), mtimeNs: int64(st.st_mtime) * 1_000_000_000))

proc newTrustPolicy*(roots: Roots): TrustPolicy =
  ## Root, and the manager's own uid (equal to root for a real system manager;
  ## tests running unprivileged trust their own files).
  result.trustedUids = @[0]
  if int(roots.uid) != 0: result.trustedUids.add int(roots.uid)
  result.stat = realStat

proc permissive*(): TrustPolicy =
  ## Accepts every owner and mode (generated units in tests, offline operation as non-root).
  result.stat = proc(path: string; follow: bool): Option[StatInfo] =
    var r = realStat(path, follow)
    if r.isSome: r.get.uid = 0; r.get.mode = r.get.mode and not 0o022
    r
  result.trustedUids = @[0]


proc modeStr(m: int): string =
  result = ""
  for sh in [6, 3, 0]: result.add char(ord('0') + ((m shr sh) and 7))
  result = "0" & result

proc badOf(p: TrustPolicy; si: StatInfo): string =
  if si.uid notin p.trustedUids or (si.mode and 0o022) != 0:
    "ignored: owned by uid " & $si.uid & ", mode " & modeStr(si.mode)
  else: ""

proc untrustedReason*(p: TrustPolicy; searchDir, path: string): Option[string] =
  ## `none` when `path` (lexically below `searchDir`) is trusted, else the
  ## message of the E_PERMISSION diagnostic. Checks the search directory
  ## (resolved if a symlink), every directory down to the entry, the entry
  ## itself, and its final target after resolving symlinks (`/dev/null` is
  ## always trusted as a mask target).
  template fail(m: string) = return some(m)
  let sd = p.stat(searchDir, true)
  if sd.isNone: return                      # nothing to trust or distrust
  let b0 = badOf(p, sd.get)
  if b0.len > 0: fail b0
  var rel = path
  if path.len > searchDir.len and path.startsWith(searchDir): rel = path[searchDir.len .. ^1]
  var cur = searchDir
  let parts = rel.split('/')
  for i, part in parts:
    if part.len == 0: continue
    cur = cur / part
    if i == parts.high: break
    let si = p.stat(cur, true)
    if si.isNone: return
    let b = badOf(p, si.get)
    if b.len > 0: fail b
  let li = p.stat(path, false)
  if li.isNone: return
  if li.get.isLink:
    # the link itself must be ours; /dev/null is fine, anything else is checked at the target
    if li.get.uid notin p.trustedUids: fail "ignored: symlink owned by uid " & $li.get.uid
    var dest = ""
    try: dest = expandSymlink(path) except OSError: discard
    if dest == "/dev/null": return
    let ti = p.stat(path, true)
    if ti.isNone: return
    if ti.get.isReg or ti.get.isDir:
      let b = badOf(p, ti.get)
      if b.len > 0: fail b
    return
  let b = badOf(p, li.get)
  if b.len > 0: fail b

proc isTrusted*(p: TrustPolicy; searchDir, path: string): bool =
  untrustedReason(p, searchDir, path).isNone
