## Preset files (spec §6.10): `*.preset` search, parsing and the first-match
## decision. The enable/disable work itself is `install.fileOp(foPreset...)`.
import std/[os, algorithm, tables]
import std/strutils except escape, unescape
import ../common/[names, roots]
import ./[paths, values, trust]

type
  PresetAction* = enum paEnable, paDisable, paIgnore
  PresetRule* = object
    action*: PresetAction
    patterns*: seq[string]
    file*: string
    line*: int

proc presetDirs*(r: Roots): seq[string] =
  ## Highest priority first; the core's own directory is last.
  let local = r.usrLib.parentDir / "local/lib/systemd"
  if r.scope == scSystem:
    @[r.etc / "systemd/system-preset", r.sysrun / "system-preset", local / "system-preset",
      r.usrLib / "systemd/system-preset", r.coreRoot / "share/presets"]
  else:
    @[sysEtc(r) / "systemd/user-preset", r.run / "systemd/user-preset", local / "user-preset",
      r.usrLib / "systemd/user-preset", r.coreRoot / "share/presets-user"]

proc parsePresetText*(text, file: string): seq[PresetRule] =
  var n = 0
  for raw in text.splitLines:
    inc n
    let l = raw.strip
    if l.len == 0 or l[0] in {'#', ';'}: continue
    let w = l.splitWhitespace
    if w.len < 2: continue
    case w[0]
    of "enable": result.add PresetRule(action: paEnable, patterns: w[1 .. ^1], file: file, line: n)
    of "disable": result.add PresetRule(action: paDisable, patterns: w[1 .. ^1], file: file, line: n)
    of "ignore": result.add PresetRule(action: paIgnore, patterns: w[1 .. ^1], file: file, line: n)
    else: discard

proc loadPresets*(r: Roots; policy = TrustPolicy()): seq[PresetRule] =
  ## Files of the same name in a higher directory shadow lower ones; the
  ## survivors are applied in name order.
  var byName = initTable[string, string]()
  var pol = policy
  if pol.stat == nil: pol = newTrustPolicy(r)
  for d in presetDirs(r):
    if not dirExists(d): continue
    for k, p in walkDir(d):
      let fn = p.extractFilename
      if fn.endsWith(".preset") and k in {pcFile, pcLinkToFile} and fn notin byName and isTrusted(pol, d, p):
        byName[fn] = p
  var fns: seq[string]
  for k in byName.keys: fns.add k
  fns.sort()
  for fn in fns:
    try: result.add parsePresetText(readFile(byName[fn]), byName[fn])
    except CatchableError: discard

proc decide(rules: seq[PresetRule]; name: string; hit: var bool): PresetAction =
  for r in rules:
    for p in r.patterns:
      if globMatch(p, name):
        hit = true
        return r.action
  paEnable

proc presetAction*(rules: seq[PresetRule]; unit: string): PresetAction =
  ## First matching rule decides (an instance falls back to its template's
  ## rules); with no match the unit is enabled.
  var hit = false
  result = decide(rules, unit, hit)
  if not hit:
    let t = templateOf(unit)
    if t != unit: result = decide(rules, t, hit)
