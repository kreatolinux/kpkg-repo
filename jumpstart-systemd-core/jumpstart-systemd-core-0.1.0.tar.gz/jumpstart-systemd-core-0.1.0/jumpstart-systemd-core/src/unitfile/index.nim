## The unit index (spec §6.1, §6.6, §6.8, §6.9): one scan of the search path
## per reload giving, for every name, where it comes from, aliases, masks,
## link-farm dependencies, and the enablement state.
import std/[os, options, tables, algorithm, sets]
import std/strutils except escape, unescape
import ../common/[names, roots]
import ./[model, paths, trust, syntax, dropins, apply]

type
  EntryKind* = enum ekFile, ekAlias, ekMasked, ekLinked, ekBad
  Entry* = object
    name*, path*, fragment*, aliasOf*, badReason*: string
    dir*: int
    kind*: EntryKind
  EnableLink* = object
    dir*: int
    owner*, unit*, dest*, path*: string   ## `owner.wants/unit` -> dest
    dep*: DepKind
  GeneratedUnit* = object
    ## From the fstab/getty/mountinfo generators and transient units: the
    ## in-memory definition plus extra edges (kind, from, to) that
    ## `loadUnit` adds to unit `from`.
    name*: string
    def*: UnitDef
    extraDeps*: seq[(DepKind, string, string)]
  UnitIndex* = ref object
    roots*: Roots
    policy*: TrustPolicy
    conf*: ManagerConf            ## manager defaults used by loadUnit (set after parseManagerConf)
    dirs*: seq[SearchDir]
    entries*: Table[string, Entry]
    order*: seq[string]
    links*: Table[string, seq[EnableLink]]    ## by linked unit name
    farm*: Table[string, seq[EnableLink]]     ## by owner (`multi-user.target`)
    generated*: Table[string, GeneratedUnit]
    extra*: Table[string, seq[(DepKind, string)]]
    diags*: seq[Diag]
    udevRunning*: bool

const BuiltinAliases = {"runlevel0.target": "poweroff.target", "runlevel1.target": "rescue.target",
  "runlevel2.target": "multi-user.target", "runlevel3.target": "multi-user.target",
  "runlevel4.target": "multi-user.target", "runlevel5.target": "graphical.target",
  "runlevel6.target": "reboot.target", "ctrl-alt-del.target": "reboot.target"}.toTable

proc normPath(p: string): string = normalizedPath(p)

proc realDir(p: string): string =
  ## `p` with symlinked directories resolved (merged-/usr: /lib -> usr/lib); the
  ## lexical form when it cannot be resolved.
  try: normPath(expandFilename(p)) except OSError: normPath(p)

proc inSearchDir(idx: UnitIndex; absPath: string): bool =
  let d = normPath(absPath.parentDir)
  for sd in idx.dirs:
    if normPath(sd.path) == d: return true
  let rd = realDir(d)
  for sd in idx.dirs:
    if realDir(sd.path) == rd: return true

proc rootBase*(r: Roots): string = r.usrLib.parentDir.parentDir
  ## The directory that plays `/` (tests and `--root=`; "/" in production).

proc linkDest(idx: UnitIndex; path: string): string =
  ## The link text made absolute (below the fake root for absolute links when
  ## the index is rooted elsewhere) and lexically normalised.
  try:
    let d = expandSymlink(path)
    let b = rootBase(idx.roots)
    if d.isAbsolute:
      if b != "/" and d != "/dev/null" and not d.startsWith(b & "/"): normPath(b & d) else: normPath(d)
    else: normPath(parentDir(path) / d)
  except OSError: ""

proc classify(idx: UnitIndex; di: int; name, path: string; diags: var seq[Diag]): Option[Entry] =
  let st = idx.policy.stat(path, false)
  if st.isNone: return
  var e = Entry(name: name, path: path, dir: di)
  let bad = untrustedReason(idx.policy, idx.dirs[di].path, path)
  if st.get.isLink:
    var raw = ""
    try: raw = expandSymlink(path) except OSError: discard
    if raw == "/dev/null":
      e.kind = ekMasked
      return some(e)
    if bad.isSome:
      e.kind = ekBad; e.badReason = bad.get
      return some(e)
    let dest = linkDest(idx, path)
    if dest.len == 0: return
    let base = dest.extractFilename
    let pn = parseUnitName(name)
    let pb = parseUnitName(base)
    if pb.isSome and pn.isSome and pb.get.suffix == pn.get.suffix and inSearchDir(idx, dest):
      if base != name:
        e.kind = ekAlias; e.aliasOf = base
      else:
        e.kind = ekFile; e.fragment = dest
      return some(e)
    if pb.isSome and pn.isSome and pb.get.suffix != pn.get.suffix and inSearchDir(idx, dest):
      diags.add diag(sevWarning, name, path, 0, "", "alias to a unit of a different type ignored")
      return
    if not fileExists(dest): return
    e.kind = ekLinked; e.fragment = dest
    return some(e)
  if st.get.isDir: return
  if bad.isSome:
    e.kind = ekBad; e.badReason = bad.get
    return some(e)
  if st.get.size == 0: e.kind = ekMasked
  else: e.kind = ekFile; e.fragment = path
  some(e)

proc linkKindOf(suffix: string; dep: var DepKind): bool =
  case suffix
  of ".wants": dep = dkWants
  of ".requires": dep = dkRequires
  of ".upholds": dep = dkUpholds
  else: return false
  true

proc scanFarm(idx: UnitIndex; di: int; dirName: string) =
  let sd = idx.dirs[di]
  var dep: DepKind
  let dot = dirName.rfind('.')
  if dot <= 0 or not linkKindOf(dirName[dot .. ^1], dep): return
  let owner = dirName[0 ..< dot]
  let dd = sd.path / dirName
  var names: seq[string]
  try:
    for k, p in walkDir(dd): names.add p.extractFilename
  except OSError: return
  names.sort()
  for n in names:
    if parseUnitName(n).isNone: continue
    let p = dd / n
    let bad = untrustedReason(idx.policy, sd.path, p)
    if bad.isSome:
      idx.diags.add diag(sevError, n, p, 0, "", bad.get, "E_PERMISSION")
      continue
    var dest = ""
    let st = idx.policy.stat(p, false)
    if st.isSome and st.get.isLink: dest = linkDest(idx, p)
    elif st.isSome: dest = p
    else: continue
    let l = EnableLink(dir: di, owner: owner, unit: n, dest: dest, path: p, dep: dep)
    idx.farm.mgetOrPut(owner, @[]).add l
    idx.links.mgetOrPut(n, @[]).add l

proc buildIndex*(roots: Roots; generated: seq[GeneratedUnit]; diags: var seq[Diag];
                 policy = TrustPolicy(); conf = ManagerConf()): UnitIndex =
  ## Scans every search directory once (spec §6.1). Untrusted sources are
  ## skipped with an E_PERMISSION diagnostic; unreadable directories with a warning.
  result = UnitIndex(roots: roots, policy: policy, conf: conf, dirs: unitSearchPath(roots))
  if result.policy.stat == nil: result.policy = newTrustPolicy(roots)
  result.udevRunning = fileExists(roots.run / "udev/control")
  let idx = result
  for g in generated:
    idx.generated[g.name] = g
    for (k, f, t) in g.extraDeps: idx.extra.mgetOrPut(f, @[]).add (k, t)
  for di, d in idx.dirs:
    if not dirExists(d.path): continue
    var names: seq[(PathComponent, string)]
    try:
      for k, p in walkDir(d.path, relative = true): names.add (k, p)
    except OSError:
      diags.add diag(sevWarning, "", d.path, 0, "", "cannot read directory", "E_IO")
      continue
    names.sort(proc(a, b: (PathComponent, string)): int = cmp(a[1], b[1]))
    for (k, n) in names:
      let path = d.path / n
      if k in {pcDir, pcLinkToDir} and (n.endsWith(".wants") or n.endsWith(".requires") or n.endsWith(".upholds")):
        scanFarm(idx, di, n)
        continue
      if parseUnitName(n).isNone: continue
      let prev = idx.entries.getOrDefault(n)
      let ex = n in idx.entries
      let e = classify(idx, di, n, path, diags)
      if e.isNone: continue
      if e.get.kind == ekBad:
        diags.add diag(sevError, n, path, 0, "", e.get.badReason, "E_PERMISSION")
        if not ex: idx.entries[n] = e.get; idx.order.add n
        continue
      if ex and prev.kind != ekBad: continue
      if not ex: idx.order.add n
      idx.entries[n] = e.get
  for d in idx.diags: diags.add d
  idx.diags = diags

# ---- name resolution -------------------------------------------------------

proc builtinTarget(idx: UnitIndex; name: string): string =
  if idx.roots.scope == scSystem:
    if name == "default.target": return "multi-user.target"
  BuiltinAliases.getOrDefault(name)

proc followAlias*(idx: UnitIndex; name: string; loop: var bool): string =
  ## Canonical name of an index entry name (alias chains up to 16 steps).
  var cur = name
  for _ in 0 .. 16:
    let e = idx.entries.getOrDefault(cur)
    if cur in idx.entries and e.kind == ekAlias: cur = e.aliasOf
    else: return cur
  loop = true
  cur

proc hasName(idx: UnitIndex; n: string): bool =
  n in idx.entries or n in idx.generated or builtinTarget(idx, n).len > 0

proc aliasNamesOf*(idx: UnitIndex; id: string): seq[string] =
  ## Index entries (alias symlinks) that resolve to `id`.
  for n in idx.order:
    if n == id: continue
    let e = idx.entries[n]
    if e.kind == ekAlias:
      var loop = false
      if followAlias(idx, n, loop) == id and not loop: result.add n

proc fragmentOf*(idx: UnitIndex; name: string): string =
  idx.entries.getOrDefault(name).fragment

proc resolveName*(idx: UnitIndex; name: string): Option[Resolved] =
  ## Canonical id, names and provenance of `name` (§6.6, §6.8), or none when no
  ## unit file, alias, template, generated or built-in unit provides it.
  let pn = parseUnitName(name)
  if pn.isNone: return
  var r = Resolved(queried: name, kind: pn.get.kind)
  var lookup = name
  var inst = ""
  if lookup notin idx.entries and lookup notin idx.generated and builtinTarget(idx, lookup).len == 0:
    if pn.get.isInstance:
      let t = templateOf(name)
      if t notin idx.entries and t notin idx.generated: 
        if pn.get.kind == ukSlice: return some(Resolved(id: name, queried: name, kind: ukSlice, names: @[name]))
        return
      lookup = t
      inst = pn.get.instance
    elif pn.get.kind == ukSlice:
      return some(Resolved(id: name, queried: name, kind: ukSlice, names: @[name], generated: true))
    else: return
  if lookup notin idx.entries and lookup notin idx.generated:
    # a built-in alias (default.target ...)
    let b = builtinTarget(idx, lookup)
    r.id = b; r.names = @[b, name]; r.isAlias = true; r.generated = true
    return some(r)
  var loop = false
  var canon = followAlias(idx, lookup, loop)
  if loop: canon = lookup
  let e = idx.entries.getOrDefault(canon)
  let isEntry = canon in idx.entries
  r.id = if inst.len > 0: instantiate(canon, inst) else: canon
  r.isTemplateInstance = inst.len > 0
  r.isAlias = r.id != name
  r.masked = isEntry and e.kind == ekMasked
  r.generated = not isEntry
  if isEntry:
    r.fragment = e.fragment
    if e.kind in {ekFile, ekLinked, ekBad} and idx.dirs[e.dir].role in {drGeneratorEarly, drGenerator, drGeneratorLate}:
      r.generated = true
  r.names = @[r.id]
  for a in aliasNamesOf(idx, canon):
    r.names.add (if inst.len > 0: instantiate(a, inst) else: a)
  if name notin r.names and not r.isAlias: r.names.add name
  some(r)

# ---- reading a unit's source files -----------------------------------------

type UnitFiles* = object
  main*: string                 ## fragment path ("" for generated)
  dropIns*: seq[string]
  settings*: seq[Setting]
  texts*: seq[(string, string)] ## (path, text) of main file then drop-ins
  diags*: seq[Diag]
  fatal*: bool

proc readSource(path: string; unit: string; known: seq[string]; uf: var UnitFiles; isMain: bool) =
  var text = ""
  try:
    if getFileSize(path) > MaxFileBytes:
      uf.diags.add diag(sevError, unit, path, 0, "", "file is larger than 1 MiB", "E_LOAD")
      if isMain: uf.fatal = true
      return
    text = readFile(path)
  except CatchableError as e:
    uf.diags.add diag(sevError, unit, path, 0, "", "cannot read: " & e.msg, "E_IO")
    if isMain: uf.fatal = true
    return
  let sr = parseSyntax(text, path, unit, known)
  uf.diags.add sr.diags
  if sr.fatal:
    if isMain: uf.fatal = true
    return
  uf.texts.add (path, text)
  uf.settings.add sr.settings

proc readUnitFiles*(idx: UnitIndex; r: Resolved; fragment: string; kind: UnitKind): UnitFiles =
  ## Main file then name-sorted drop-ins, parsed. `fragment` is the template's
  ## file for instances.
  let known = sectionsOf(kind)
  if fragment.len > 0:
    result.main = fragment
    readSource(fragment, r.id, known, result, true)
  var diags: seq[Diag]
  let dis = collectDropIns(idx.dirs, r.names, idx.policy, diags, r.id)
  result.diags.add diags
  var n = 0
  for d in dis:
    inc n
    if n > MaxDropIns:
      result.diags.add diag(sevError, r.id, d.path, 0, "", "more than 1024 drop-in files", "E_LOAD")
      break
    result.dropIns.add d.path
    readSource(d.path, r.id, known, result, false)

proc fragmentFor*(idx: UnitIndex; r: Resolved): string =
  ## The file a resolved unit is loaded from (the template's for instances).
  if r.isTemplateInstance:
    var loop = false
    let t = followAlias(idx, templateOf(r.queried), loop)
    return idx.entries.getOrDefault(t).fragment
  r.fragment

# ---- enablement ------------------------------------------------------------

proc sameFileLoose(a, b: string): bool =
  if a == b: return true
  if normPath(a) == normPath(b): return true
  try: sameFile(a, b) except OSError: false

proc installKeys(idx: UnitIndex; r: Resolved; kind: UnitKind): tuple[present, other, also: bool, aliases: seq[string]] =
  let uf = readUnitFiles(idx, r, fragmentFor(idx, r), kind)
  for s in uf.settings:
    if s.section != "Install": continue
    result.present = true
    case s.key
    of "WantedBy", "RequiredBy", "UpheldBy", "Alias", "DefaultInstance":
      if s.value.len > 0: result.other = true
      if s.key == "Alias":
        for w in s.value.splitWhitespace: result.aliases.add w.replace("%i", r.queried.parseUnitName.get.instance)
    of "Also":
      if s.value.len > 0: result.also = true
    else: discard

proc enablementOf*(idx: UnitIndex; id: string): EnablementState =
  ## `systemctl is-enabled` vocabulary (§6.9). An alias reports the canonical
  ## unit's state.
  let rr = resolveName(idx, id)
  if rr.isNone: return esNotFound
  let r = rr.get
  if r.masked:
    var lp = false
    let e = idx.entries[followAlias(idx, (if r.isTemplateInstance: templateOf(r.queried) else: r.id), lp)]
    return if idx.dirs[e.dir].role == drRuntime: esMaskedRuntime else: esMasked
  let ename = if r.isTemplateInstance: templateOf(r.queried) else: r.id
  var loop = false
  let canon = followAlias(idx, ename, loop)
  if canon notin idx.entries:
    if r.id in idx.generated: return esGenerated
    return (if r.generated: esGenerated else: esStatic)
  let e = idx.entries[canon]
  if e.kind == ekBad: return esBad
  let role = idx.dirs[e.dir].role
  if role == drTransient: return esTransient
  if role in {drGeneratorEarly, drGenerator, drGeneratorLate}: return esGenerated
  let frag = fragmentFor(idx, r)
  var persistent, runtime = false
  for l in idx.links.getOrDefault(r.id):
    if sameFileLoose(l.dest, frag) or not fileExists(l.dest):
      if idx.dirs[l.dir].role == drRuntime: runtime = true else: persistent = true
  let k = installKeys(idx, r, r.kind)
  for a in aliasNamesOf(idx, canon):
    if a notin k.aliases and (if r.isTemplateInstance: instantiate(a, parseUnitName(r.id).get.instance) else: a) notin k.aliases: continue
    let ae = idx.entries[a]
    if idx.dirs[ae.dir].role == drRuntime: runtime = true
    else: persistent = true
  if persistent: return esEnabled
  if runtime: return esEnabledRuntime
  if e.kind == ekLinked: return (if role == drRuntime: esLinkedRuntime else: esLinked)
  if not k.present: return esStatic
  if k.also and not k.other: return esIndirect
  if not k.other and not k.also: return esStatic
  esDisabled

proc listNames*(idx: UnitIndex): seq[IndexEntry] =
  ## Every name known to the index (unit files, aliases, generated), sorted;
  ## the source of `unit.list` and `list-unit-files` (§13.4).
  var seen = initHashSet[string]()
  for n in idx.order:
    let e = idx.entries[n]
    if e.kind == ekBad: continue
    seen.incl n
    var ie = IndexEntry(name: n, kind: parseUnitName(n).get.kind, fragment: e.fragment, source: usFile)
    if idx.dirs[e.dir].role == drTransient: ie.source = usTransient
    elif idx.dirs[e.dir].role in {drGeneratorEarly, drGenerator, drGeneratorLate}: ie.source = usGenerated
    if e.kind == ekAlias:
      ie.isAlias = true; ie.aliasOf = e.aliasOf; ie.state = esAlias
    else: ie.state = enablementOf(idx, n)
    result.add ie
  for n, g in idx.generated:
    if n in seen: continue
    result.add IndexEntry(name: n, kind: g.def.kind, source: g.def.common.source, state: esGenerated)
  result.sort(proc(a, b: IndexEntry): int = cmp(a.name, b.name))

proc farmDeps*(idx: UnitIndex; names: seq[string]): seq[(DepKind, string)] =
  ## Dependencies given by `NAME.wants/`, `.requires/`, `.upholds/` directories
  ## for the unit's names (and the type/prefix/template-level directory names).
  var owners: seq[string]
  for n in names:
    for dn in dropInDirNames(n): owners.add dn[0 ..< dn.len - 2]
  var seen = initHashSet[string]()
  for o in owners:
    for l in idx.farm.getOrDefault(o):
      let key = $l.dep & "|" & l.unit
      if key in seen: continue
      seen.incl key
      result.add (l.dep, l.unit)
