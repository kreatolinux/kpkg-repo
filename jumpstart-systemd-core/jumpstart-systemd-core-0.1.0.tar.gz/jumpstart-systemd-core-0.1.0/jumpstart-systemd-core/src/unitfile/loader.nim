## Loading units (spec §6.1-§6.9, §7.2): index entry + drop-ins -> `UnitDef`,
## with manager defaults, link-farm dependencies, implicit dependencies,
## `[Install]` data and source stamps. `loadUnit` never raises: a bad unit comes
## back with `loadState` and `diagnostics` set.
import std/[os, options, tables, times]
import std/strutils except escape, unescape
import ../common/[names, roots, sha1]
import ./[trust, model, paths, syntax, dropins, apply, specifiers, implicit, index, values, presets]
export index

var noRunWarningKinds*: set[UnitKind] = {}
  ## Unit types whose files load with a `W_NOT_RUN` warning because the engine
  ## does not run them (none since path, swap and automount units exist).

proc initDef*(kind: UnitKind; name: string; conf: ManagerConf; roots: Roots): UnitDef =
  ## A definition with systemd's defaults and the manager defaults of `conf`.
  result = newUnitDef(kind, name)
  result.common.startLimitIntervalUsec = conf.defaultStartLimitIntervalUsec
  result.common.startLimitBurst = conf.defaultStartLimitBurst
  let ex = execContextOf(result)
  if ex != nil:
    ex.standardOutput = conf.defaultStandardOutput
    ex.standardError = conf.defaultStandardError
    ex.limits = conf.defaultLimits
  let rc = resourceControlOf(result)
  if rc != nil: rc.tasksMax = conf.defaultTasksMax
  case kind
  of ukService:
    let s = addr result.service
    s.restartUsec = conf.defaultRestartUsec
    s.timeoutStartUsec = conf.defaultTimeoutStartUsec
    s.timeoutStopUsec = conf.defaultTimeoutStopUsec
    s.timeoutAbortUsec = if conf.defaultTimeoutAbortUsec == UnsetInt: conf.defaultTimeoutStopUsec
                         else: conf.defaultTimeoutAbortUsec
    s.oomPolicy = conf.defaultOOMPolicy
  of ukSocket: result.socket.timeoutSec = conf.defaultTimeoutStartUsec
  of ukMount, ukAutomount: result.mount.timeoutSec = conf.defaultTimeoutStartUsec
  of ukSwap: result.swap.timeoutSec = conf.defaultTimeoutStartUsec
  else: discard

proc defaultSlice(roots: Roots): string =
  if roots.scope == scSystem: "system.slice" else: "app.slice"

proc finalize(def: UnitDef; ap: ApplyState; roots: Roots; conf: ManagerConf; diags: var seq[Diag]) =
  let cm = addr def.common
  template warn(k, m: string) = diags.add diag(sevWarning, cm.id, cm.fragmentPath, 0, k, m)
  case def.kind
  of ukService:
    let s = addr def.service
    if not ap.typeSet:
      s.typ = if s.commands[ekStart].len == 0: stOneshot
              elif s.busName.len > 0: stDbus
              else: stSimple
    if s.typ == stOneshot and not ap.timeoutStartSet: s.timeoutStartUsec = Infinity
    if not ap.timeoutAbortSet:
      s.timeoutAbortUsec = if conf.defaultTimeoutAbortUsec != UnsetInt: conf.defaultTimeoutAbortUsec else: s.timeoutStopUsec
    if s.typ in {stNotify, stNotifyReload}:
      if s.notifyAccess == naNone:
        if ap.notifyAccessSet:
          warn "NotifyAccess", "Type=" & $s.typ & " with NotifyAccess=none: access raised to main"
        s.notifyAccess = naMain
    elif s.notifyAccess == naNone and not ap.notifyAccessSet and
         ((s.watchdogUsec > 0 and s.watchdogUsec != Infinity) or s.fdStoreMax > 0):
      s.notifyAccess = naMain
    if s.typ == stDbus:
      warn "Type", "Type=dbus is run as Type=exec: the bus name is not tracked"
    if s.res.slice.len == 0: s.res.slice = defaultSlice(roots)
    cm.slice = s.res.slice
  of ukSocket:
    if def.socket.res.slice.len == 0: def.socket.res.slice = defaultSlice(roots)
    cm.slice = def.socket.res.slice
  of ukMount:
    if def.mount.res.slice.len == 0: def.mount.res.slice = "-.slice"
    cm.slice = def.mount.res.slice
  of ukSwap:
    if def.swap.res.slice.len == 0: def.swap.res.slice = "-.slice"
    cm.slice = def.swap.res.slice
  of ukSlice:
    let ps = sliceParents(cm.id)
    cm.slice = if cm.id == "-.slice": "" elif ps.len > 0: ps[^1] else: "-.slice"
  of ukScope:
    cm.loadState = lsError
    cm.loadError = ".scope units cannot be loaded from files"
    diags.add diag(sevError, cm.id, cm.fragmentPath, 0, "", ".scope units cannot be loaded from files", "E_UNSUPPORTED")
  else: discard
  let exc = execContextOf(def)
  if roots.scope == scUser and exc != nil and (exc.user.len > 0 or exc.group.len > 0):
    warn "User", "User= and Group= are ignored in user scope"
  if def.kind in noRunWarningKinds:
    warn "", "the engine does not run ." & $def.kind & " units in this release"
    diags[^1].code = "W_NOT_RUN"

proc addDep(c: var UnitCommon; k: DepKind; n: string) =
  if n notin c.deps[k]: c.deps[k].add n

proc statNs(path: string): int64 =
  try:
    let t = getLastModificationTime(path)
    t.toUnix * 1_000_000_000 + t.nanosecond
  except CatchableError: 0

proc stampOf(path, text: string): FileStamp =
  FileStamp(path: path, sha1: sha1hex(text), mtimeNs: statNs(path), size: int64(text.len))

type DefaultDepsFn = proc(name: string): bool {.closure.}

proc build(idx: UnitIndex; roots: Roots; r: Resolved; uf: UnitFiles; env: SpecifierEnv;
           conf: ManagerConf; source: UnitSource; hdd: DefaultDepsFn): UnitDef =
  let def = initDef(r.kind, r.id, conf, roots)
  let dflt = initDef(r.kind, r.id, conf, roots)
  var diags = uf.diags
  var ap: ApplyState
  let cm = addr def.common
  cm.names = r.names
  cm.source = source
  cm.fragmentPath = uf.main
  cm.dropInPaths = uf.dropIns
  cm.settings = uf.settings
  for (p, t) in uf.texts: cm.stamps.add stampOf(p, t)
  for s in uf.settings: applySetting(def, dflt, ap, s, env, diags)
  finalize(def, ap, roots, conf, diags)
  if idx != nil:
    for (k, n) in farmDeps(idx, r.names): addDep(cm[], k, n)
    for (k, n) in idx.extra.getOrDefault(r.id): addDep(cm[], k, n)
  fillImplicit(def, roots, hdd, idx != nil and idx.udevRunning)
  if hasErrors(diags) and cm.loadState == lsLoaded:
    var fatalErr = false
    for d in diags:
      if d.severity == sevError and d.code in ["E_LOAD", "E_IO"]: fatalErr = true
    if fatalErr: cm.loadState = lsError
  if cm.loadState == lsError and cm.loadError.len == 0:
    for d in diags:
      if d.severity == sevError: (cm.loadError = d.message; break)
  cm.diagnostics = diags
  def

proc peekDefaultDeps(idx: UnitIndex; name: string): bool =
  let rr = resolveName(idx, name)
  if rr.isNone: return false
  let r = rr.get
  result = true
  if r.kind == ukSlice and r.generated: return false
  let frag = fragmentFor(idx, r)
  if frag.len == 0: return false
  let uf = readUnitFiles(idx, r, frag, r.kind)
  for s in uf.settings:
    if s.section == "Unit" and s.key == "DefaultDependencies":
      let b = parseBoolVal(s.value)
      if b.isSome: result = b.get
      elif s.value.len == 0: result = true

proc problemDef(idx: UnitIndex; kind: UnitKind; id: string; state: LoadState; msg: string; names: seq[string] = @[]): UnitDef =
  result = initDef(kind, id, idx.conf, idx.roots)
  result.common.loadState = state
  result.common.loadError = msg
  if names.len > 0: result.common.names = names
  if state in {lsError, lsBadSetting}:
    result.common.diagnostics.add diag(sevError, id, "", 0, "", msg, "E_LOAD")

proc loadUnit*(idx: UnitIndex; id: string; env: SpecifierEnv): UnitDef =
  ## Loads `id` (any of its names; an alias yields the canonical unit, whose
  ## `common.id` and `names` say so). Never raises.
  let pn = parseUnitName(id)
  if pn.isNone:
    return problemDef(idx, ukService, id, lsError, "Invalid unit name '" & id & "'")
  let rr = resolveName(idx, id)
  if rr.isNone:
    return problemDef(idx, pn.get.kind, id, lsNotFound, "Unit " & id & " not found.")
  let r = rr.get
  let hdd: DefaultDepsFn = proc(n: string): bool = peekDefaultDeps(idx, n)
  if r.masked:
    return problemDef(idx, r.kind, r.id, lsMasked, "Unit " & r.id & " is masked.", r.names)
  # generated / transient / built-in
  if r.id in idx.generated and r.id notin idx.entries:
    let g = idx.generated[r.id]
    let d = clone(g.def)
    d.common.id = r.id
    d.common.names = r.names
    if d.common.source == usFile: d.common.source = usGenerated
    for (k, n) in farmDeps(idx, r.names): addDep(d.common, k, n)
    for (k, n) in idx.extra.getOrDefault(r.id): addDep(d.common, k, n)
    fillImplicit(d, idx.roots, hdd, idx.udevRunning)
    return d
  let lookupName = if r.isTemplateInstance: templateOf(r.queried) else: r.id
  var loop = false
  let canon = followAlias(idx, lookupName, loop)
  if canon notin idx.entries:
    # built-in alias such as default.target
    if r.kind == ukSlice:
      let d = initDef(ukSlice, r.id, idx.conf, idx.roots)
      d.common.source = usBuiltin
      var ap: ApplyState
      var diags: seq[Diag]
      finalize(d, ap, idx.roots, idx.conf, diags)
      fillImplicit(d, idx.roots, hdd, idx.udevRunning)
      return d
    if r.id != id and r.id in idx.entries:
      let d = loadUnit(idx, r.id, env)
      if id notin d.common.names: d.common.names.add id
      return d
    return problemDef(idx, r.kind, id, lsNotFound, "Unit " & id & " not found.")
  let e = idx.entries[canon]
  if e.kind == ekBad:
    return problemDef(idx, r.kind, r.id, lsError, e.badReason, r.names)
  if loop:
    return problemDef(idx, r.kind, r.id, lsError, "Alias loop at " & lookupName, r.names)
  let frag = fragmentFor(idx, r)
  let uf = readUnitFiles(idx, r, frag, r.kind)
  let source = case idx.dirs[e.dir].role
    of drTransient: usTransient
    of drGeneratorEarly, drGenerator, drGeneratorLate: usGenerated
    else: usFile
  var d: UnitDef
  if uf.fatal:
    d = problemDef(idx, r.kind, r.id, lsError, "", r.names)
    d.common.diagnostics = uf.diags
    for x in uf.diags:
      if x.severity == sevError: (d.common.loadError = x.message; break)
    d.common.fragmentPath = frag
  else:
    d = build(idx, idx.roots, r, uf, env, idx.conf, source, hdd)
  if r.isTemplateInstance: d.common.templatePath = frag
  if r.id != id and id notin d.common.names: d.common.names.add id
  d

proc parseUnitText*(name, text: string; roots: Roots; env: SpecifierEnv;
                    conf = ManagerConf(); source = usTransient; file = ""): UnitDef =
  ## A unit from text (transient units, generated units): no drop-ins, no link
  ## farm. Diagnostics are in `common.diagnostics`.
  let pn = parseUnitName(name)
  if pn.isNone:
    let d = initDef(ukService, name, conf, roots)
    d.common.loadState = lsError
    d.common.loadError = "Invalid unit name '" & name & "'"
    return d
  let r = Resolved(id: name, queried: name, names: @[name], kind: pn.get.kind)
  var uf = UnitFiles(main: file)
  let sr = parseSyntax(text, file, name, sectionsOf(r.kind))
  uf.diags = sr.diags
  uf.settings = sr.settings
  uf.texts.add (file, text)
  if sr.fatal:
    let d = initDef(r.kind, name, conf, roots)
    d.common.loadState = lsError
    d.common.diagnostics = uf.diags
    d.common.loadError = uf.diags[0].message
    return d
  build(nil, roots, r, uf, env, conf, source, nil)

proc fileChanged*(idx: UnitIndex; def: UnitDef): bool =
  ## `NeedDaemonReload`: the source list differs from what was loaded (file
  ## missing, mtime/size/SHA-1 different, or a drop-in added or removed).
  if def.common.stamps.len == 0 and def.common.fragmentPath.len == 0: return false
  for s in def.common.stamps:
    if not fileExists(s.path): return true
    let sz = getFileSize(s.path)
    if sz != s.size: return true
    if statNs(s.path) != s.mtimeNs:
      if sha1hex(readFile(s.path)) != s.sha1: return true
  var diags: seq[Diag]
  var now: seq[string]
  for d in collectDropIns(idx.dirs, def.common.names, idx.policy, diags, def.common.id): now.add d.path
  now != def.common.dropInPaths

proc loadAll*(idx: UnitIndex; env: SpecifierEnv): seq[UnitDef] =
  ## Eager load of every unit file name (aliases and masked names excluded),
  ## in index order: the parsing pass of `daemon-reload` (§6.13 step 2).
  for n in idx.order:
    let e = idx.entries[n]
    if e.kind in {ekAlias, ekMasked, ekBad}: continue
    result.add loadUnit(idx, n, env)

proc defaultTarget*(idx: UnitIndex): string =
  ## The configured default target (§8.3): where `default.target` resolves to.
  let r = resolveName(idx, "default.target")
  if r.isSome: r.get.id else: "multi-user.target"

proc catUnit*(def: UnitDef): string =
  ## `systemctl cat` text: `# FRAGMENT`, the file, then for every drop-in a
  ## blank line, `# PATH` and its text (§15.2.4). "" for units without files.
  var parts: seq[string]
  for p in (if def.common.fragmentPath.len > 0: @[def.common.fragmentPath] else: @[]) & def.common.dropInPaths:
    try:
      var t = readFile(p)
      if t.len > 0 and t[^1] != '\n': t.add '\n'
      parts.add "# " & p & "\n" & t
    except CatchableError: parts.add "# " & p & "\n# (unreadable)\n"
  parts.join("\n")

proc fileProperties*(idx: UnitIndex; def: UnitDef): seq[(string, string)] =
  ## The unit-file properties of `show` that need the index: `UnitFileState`,
  ## `UnitFilePreset` (`enabled`/`disabled`, "" when the unit has no [Install])
  ## and `NeedDaemonReload`.
  let st = enablementOf(idx, def.common.id)
  result.add ("UnitFileState", $st)
  var preset = ""
  if def.common.install.present or st in {esEnabled, esEnabledRuntime, esDisabled, esIndirect}:
    preset = if presetAction(loadPresets(idx.roots, permissive()), def.common.id) == paDisable: "disabled" else: "enabled"
  result.add ("UnitFilePreset", preset)
  result.add ("NeedDaemonReload", (if fileChanged(idx, def): "yes" else: "no"))
