## Command lines of `Exec*=` (spec §9.3.1): prefixes, `;` separated commands,
## quoting, executable lookup, and the exec-time `$VAR` substitution helper.
import std/[os, options, tables]
import std/strutils except escape, unescape
import ../common/roots
import ./[model, values]

const
  ExecSearchPath* = ["/usr/local/sbin", "/usr/local/bin", "/usr/sbin", "/usr/bin", "/sbin", "/bin"]
    ## The built-in lookup list for bare executable names (the unit's PATH is not used).

type Expander* = proc(s: string): Option[string] {.closure.}

const BackslashSemi = "\x5C" & ";"   ## the word `\;` is a literal `;` argument

proc parseCommand(words: seq[Word]; raw: string; expand: Expander; file: string; line: int;
                  errs: var seq[string]; res: var seq[ExecCommand]) =
  var c = ExecCommand(file: file, line: line)
  var idx = 0
  var rest = ""
  var bangs = 0
  while idx < words.len:
    let t = words[idx].text
    var j = 0
    block scan:
      while j < t.len:
        case t[j]
        of '@': c.flags.incl efAt
        of '-': c.flags.incl efMinus
        of ':': c.flags.incl efColon
        of '+': c.flags.incl efPlus; inc bangs
        of '!':
          inc bangs
          if j + 1 < t.len and t[j + 1] == '!':
            c.flags.incl {efBang, efBangBang}; inc j
          else: c.flags.incl efBang
        else: break scan
        inc j
    rest = t[j .. ^1]
    if rest.len > 0: break
    inc idx
  if idx >= words.len:
    errs.add "Missing executable in command line: " & raw
    return
  if bangs > 1:
    errs.add "Only one of '+', '!' and '!!' is allowed in: " & raw
    return
  var all = @[rest]
  for k in idx + 1 .. words.high: all.add words[k].text
  if expand != nil:
    for k in 0 .. all.high:
      let e = expand(all[k])
      if e.isNone:
        errs.add "Failed to expand specifiers in command line: " & raw
        return
      all[k] = e.get
  let exe = all[0]
  if exe.len == 0:
    errs.add "Empty executable name in: " & raw
    return
  if exe[0] != '/' and '/' in exe:
    errs.add "Executable path is not absolute: " & exe
    return
  c.path = exe
  var k = 1
  if efAt in c.flags:
    if all.len < 2:
      errs.add "Missing argv[0] for the '@' prefix in: " & raw
      return
    c.argv0 = all[1]
    k = 2
  for q in k .. all.high: c.args.add (if all[q] == BackslashSemi: ";" else: all[q])
  c.raw = quoteWord(c.path)
  for a in c.args: c.raw.add " " & quoteWord(a)
  res.add c

proc parseExecLine*(raw: string; errs: var seq[string]; expand: Expander = nil;
                    file = ""; line = 0): seq[ExecCommand] =
  ## One assignment value to zero or more commands. A command that is invalid
  ## (relative path, bad quoting, failed expansion, no executable) adds a message
  ## to `errs` and is dropped; the others are kept. `expand` is applied to every
  ## word including the executable (specifiers, section 6.5).
  var ws: seq[Word]
  if not splitWordsEx(raw, ws):
    errs.add "Unbalanced quoting in command line: " & raw
    return
  var cmd: seq[Word]
  for w in ws:
    if not w.quoted and w.text == ";":
      if cmd.len > 0: parseCommand(cmd, raw, expand, file, line, errs, result)
      cmd.setLen 0
    else: cmd.add w
  if cmd.len > 0: parseCommand(cmd, raw, expand, file, line, errs, result)

proc parseExecLine*(raw: string): seq[ExecCommand] =
  ## Without expansion or diagnostics (spec §18.2.2 signature).
  var e: seq[string]
  parseExecLine(raw, e)

proc execBase*(r: Roots): string = r.usrLib.parentDir.parentDir
  ## The directory that plays `/` (tests: the fake root).

proc execSearchDirs*(r: Roots): seq[string] =
  let b = execBase(r)
  for d in ExecSearchPath: result.add (if b == "/": d else: b & d)

proc isExecutableFile*(p: string): bool =
  fileExists(p) and fpUserExec in getFilePermissions(p)

proc lookupExecutable*(path: string; dirs: openArray[string]; base = ""): string =
  ## Absolute path found for an Exec word: itself (prefixed by `base`, the fake
  ## root) when absolute, else the first executable `dirs`/name. "" when absent.
  if path.startsWith("/"):
    let p = if base.len > 0 and base != "/": base & path else: path
    return (if isExecutableFile(p): path else: "")
  for d in dirs:
    if isExecutableFile(d / path):
      return d / path

proc expandExecArgs*(args: seq[string]; env: Table[string, string]; noSubst = false): seq[string] =
  ## Exec-time substitution (§9.3.1): `${VAR}` is one argument with the verbatim
  ## value, `$VAR` is the value split at white space, `$$` a literal `$`; an
  ## unset variable yields no argument. With `noSubst` (the `:` prefix) the
  ## arguments are returned unchanged.
  if noSubst: return args
  for a in args:
    if '$' notin a:
      result.add a; continue
    # a word that is exactly ${VAR} or $VAR substitutes whole; mixed text substitutes inline
    var i = 0
    var cur = ""
    var parts: seq[string]       # completed arguments produced by this word
    var produced = false         # whether this word produced anything (even empty text)
    var dropWord = false
    var splitUsed = false
    while i < a.len:
      if a[i] != '$':
        cur.add a[i]; inc i; produced = true; continue
      if i + 1 < a.len and a[i + 1] == '$':
        cur.add '$'; i += 2; produced = true; continue
      if i + 1 < a.len and a[i + 1] == '{':
        let e = a.find('}', i + 2)
        if e < 0: cur.add a[i]; inc i; produced = true; continue
        let name = a[i + 2 ..< e]
        if name in env: cur.add env[name]
        else: dropWord = dropWord or (a.len == e - i + 1)
        produced = true
        i = e + 1
        continue
      var j = i + 1
      while j < a.len and (a[j].isAlphaNumeric or a[j] == '_'): inc j
      if j == i + 1:
        cur.add '$'; inc i; produced = true; continue
      let name = a[i + 1 ..< j]
      if name in env:
        let pieces = env[name].splitWhitespace
        if j - i == a.len:        # whole word: split into several arguments
          for p in pieces: parts.add p
          splitUsed = true
          produced = false
        else: cur.add env[name]
      else:
        dropWord = dropWord or (j - i == a.len)
      i = j
    if splitUsed:
      result.add parts
    elif dropWord and cur.len == 0: discard
    else: result.add cur
