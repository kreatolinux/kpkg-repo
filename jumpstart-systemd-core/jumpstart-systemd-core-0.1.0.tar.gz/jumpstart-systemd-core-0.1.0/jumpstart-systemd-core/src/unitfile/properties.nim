## `systemctl show` properties of a definition (spec §15.2.6): systemd's property
## names and value formats for every directive. Static data only; runtime
## properties (`ActiveState`, `MainPID`, ...) are the engine's.
import std/[options, strutils, sequtils]
import ./[model, values]

const DirectiveNames = ["WorkingDirectory", "RootDirectory", "RootDirectoryStartOnly", "BindPaths",
  "BindReadOnlyPaths", "TemporaryFileSystem", "ReadWritePaths", "ReadOnlyPaths", "InaccessiblePaths",
  "ExecPaths", "NoExecPaths", "MountAPIVFS", "ProtectSystem", "ProtectHome", "PrivateTmp", "PrivateDevices",
  "PrivateMounts", "MountFlags", "ProtectProc", "ProcSubset", "ProtectKernelTunables", "ProtectKernelModules",
  "ProtectKernelLogs", "ProtectControlGroups", "ProtectClock", "ProtectHostname", "RuntimeDirectory",
  "StateDirectory", "CacheDirectory", "LogsDirectory", "ConfigurationDirectory", "RuntimeDirectoryMode",
  "StateDirectoryMode", "CacheDirectoryMode", "LogsDirectoryMode", "ConfigurationDirectoryMode",
  "RuntimeDirectoryPreserve", "User", "Group", "SupplementaryGroups", "DynamicUser", "CapabilityBoundingSet",
  "AmbientCapabilities", "SecureBits", "NoNewPrivileges", "SystemCallFilter", "SystemCallArchitectures",
  "RestrictAddressFamilies", "RestrictNamespaces", "SystemCallErrorNumber", "Personality", "LockPersonality",
  "MemoryDenyWriteExecute", "RestrictRealtime", "RestrictSUIDSGID", "PrivateNetwork", "PrivateIPC",
  "PrivateUsers", "RemoveIPC", "NetworkNamespacePath", "IPCNamespacePath", "Nice", "OOMScoreAdjust",
  "CPUSchedulingPriority", "IOSchedulingPriority", "CPUSchedulingPolicy", "CPUSchedulingResetOnFork",
  "CPUAffinity", "CoredumpFilter", "NUMAPolicy", "NUMAMask", "IOSchedulingClass", "TimerSlackNSec", "UMask",
  "KeyringMode", "IgnoreSIGPIPE", "Environment", "EnvironmentFile", "PassEnvironment", "UnsetEnvironment",
  "StandardInput", "StandardOutput", "StandardError", "StandardInputText", "StandardInputData", "TTYPath",
  "TTYReset", "TTYVHangup", "TTYVTDisallocate", "TTYRows", "TTYColumns", "SyslogIdentifier", "SyslogFacility",
  "SyslogLevel", "SyslogLevelPrefix", "LogLevelMax", "LogExtraFields", "LogRateLimitIntervalSec",
  "LogRateLimitBurst", "LoadCredential", "SetCredential", "ImportCredential",
  "Slice", "Delegate", "DelegateSubgroup", "DisableControllers", "CPUAccounting", "MemoryAccounting",
  "IOAccounting", "TasksAccounting", "CPUWeight", "StartupCPUWeight", "IOWeight", "StartupIOWeight",
  "CPUQuota", "CPUQuotaPeriodSec", "AllowedCPUs", "StartupAllowedCPUs", "AllowedMemoryNodes",
  "StartupAllowedMemoryNodes", "MemoryMin", "MemoryLow", "MemoryHigh", "MemoryMax", "MemorySwapMax",
  "MemoryZSwapMax", "StartupMemoryHigh", "StartupMemoryMax", "StartupMemorySwapMax", "StartupMemoryZSwapMax",
  "TasksMax", "MemoryZSwapWriteback", "IODeviceWeight", "IOReadBandwidthMax", "IOWriteBandwidthMax",
  "IOReadIOPSMax", "IOWriteIOPSMax", "IODeviceLatencyTargetSec", "DeviceAllow", "DevicePolicy",
  "KillMode", "KillSignal", "RestartKillSignal", "SendSIGHUP", "SendSIGKILL", "FinalKillSignal", "WatchdogSignal"]

type Props = seq[(string, string)]

proc directiveFor(field: string): string =
  for d in DirectiveNames:
    if cmpIgnoreCase(d, field) == 0: return d
  field.capitalizeAscii

proc propName(directive: string): string =
  ## Directive name -> systemd property name (`...Sec` becomes `...USec`).
  case directive
  of "CPUQuota": "CPUQuotaPerSecUSec"
  of "TimerSlackNSec": directive
  else:
    if directive.endsWith("Sec"): directive[0 ..< directive.len - 3] & "USec" else: directive

proc yn(b: bool): string = boolStr(b)
proc usec(v: int64): string = formatTimespan(v)

proc fmtLimit(r: ResLimit; unsetText = ""): string =
  if not r.set: unsetText
  elif r.infinity: "infinity"
  elif r.percent: (if r.value mod 10 == 0: $(r.value div 10) & "%" else: $(r.value div 10) & "." & $(r.value mod 10) & "%")
  else: $r.value

proc fmtStdio(s: StdioSpec): string =
  case s.kind
  of sioFile, sioAppend, sioTruncate, sioFd: $s.kind & ":" & s.path
  else: $s.kind

proc fmtOctal(v: int): string =
  let s = toOct(v, 4)
  s

proc quoteEnv(w: string): string =
  if ' ' in w or '"' in w or '\\' in w or '\t' in w: "\"" & w.replace("\\", "\\\\").replace("\"", "\\\"") & "\"" else: w

proc add(p: var Props; k, v: string) = p.add (k, v)

proc fmtExit(e: ExitSet): string =
  var parts: seq[string]
  for v in e.statuses: parts.add $v
  for v in e.signals: parts.add signalName(int(v))[3 .. ^1]
  parts.join(" ")

proc execStruct(c: ExecCommand): string =
  var argv = c.path
  if efAt in c.flags and c.argv0.len > 0: argv = c.argv0
  for a in c.args: argv.add " " & a
  "{ path=" & c.path & " ; argv[]=" & argv & " ; ignore_errors=" & yn(efMinus in c.flags) &
    " ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"

proc ioClassNumber(s: string): string =
  case s
  of "none": "0"
  of "realtime": "1"
  of "best-effort": "2"
  of "idle": "3"
  else: s

proc policyNumber(p: SchedPolicy): string =
  case p
  of spOther: "0"
  of spFifo: "1"
  of spRr: "2"
  of spBatch: "3"
  of spIdle: "5"

proc execProps(p: var Props; x: ExecContext) =
  for name, v in fieldPairs(x):
    let d = directiveFor(name)
    let k = propName(d)
    when v is bool: p.add k, yn(v)
    elif v is string:
      if name == "ioSchedulingClass": p.add k, ioClassNumber(v)
      else: p.add k, v
    elif v is seq[string]:
      case name
      of "environment":
        p.add k, v.map(quoteEnv).join(" ")
      of "capabilityBoundingSet", "ambientCapabilities":
        p.add k, v.map(proc(s: string): string = s.toLowerAscii).join(" ")
      else: p.add k, v.join(" ")
    elif v is int:
      if name.endsWith("DirectoryMode"): p.add k, fmtOctal(v)
      elif name == "umask": p.add k, (if v >= 0: fmtOctal(v) else: "0022")
      elif v >= 0: p.add k, $v
    elif v is int64:
      if name == "timerSlackNSec": p.add k, $(if v >= 0: v else: 50_000)
      elif name.endsWith("Sec"): (if v >= 0: p.add k, usec(v))
      else: p.add k, $v
    elif v is Option[int]:
      if v.isSome: p.add k, $v.get
    elif v is Option[SchedPolicy]:
      if v.isSome: p.add k, policyNumber(v.get)
    elif v is StdioSpec: p.add k, fmtStdio(v)
    elif v is enum: p.add k, $v
    else: discard
  for l in x.limits:
    let hard = if l.hard == Infinity: "infinity" else: $l.hard
    let soft = if l.soft == Infinity: "infinity" else: $l.soft
    p.add "Limit" & l.resource, hard
    p.add "Limit" & l.resource & "Soft", soft

proc devValues(v: seq[DeviceValue]): string =
  var parts: seq[string]
  for d in v: parts.add d.path & " " & $d.value
  parts.join(" ")

proc resProps(p: var Props; r: ResourceControl) =
  for name, v in fieldPairs(r):
    let d = directiveFor(name)
    let k = propName(d)
    when v is bool: p.add k, yn(v)
    elif v is string: p.add k, v
    elif v is seq[string]: p.add k, v.join(" ")
    elif v is int:
      if v == UnsetInt: p.add k, "[not set]"
      elif v == 0 and name.endsWith("CPUWeight"): p.add k, "idle"
      else: p.add k, $v
    elif v is int64:
      if name == "cpuQuota": p.add k, (if v == UnsetInt: "infinity" else: usec(v))
      elif v >= 0: p.add k, usec(v) elif name == "cpuQuotaPeriodSec": p.add k, "0"
    elif v is ResLimit:
      let def = if name.startsWith("memoryMin") or name.startsWith("memoryLow"): "0" else: "infinity"
      p.add k, fmtLimit(v, def)
    elif v is DelegateSpec:
      p.add k, (if v.enabled and v.controllers.len == 0: "yes" elif v.enabled: v.controllers.join(" ") else: "no")
    elif v is seq[DeviceValue]:
      for dv in v: p.add k, dv.path & " " & $dv.value
    elif v is seq[DeviceRule]:
      for dr in v: p.add k, dr.path & " " & (if dr.access.len > 0: dr.access else: "rwm")
    elif v is enum: p.add k, $v
    else: discard

proc killProps(p: var Props; k: KillContext) =
  p.add "KillMode", $k.killMode
  p.add "KillSignal", $k.killSignal
  p.add "RestartKillSignal", $(if k.restartKillSignal == 0: k.killSignal else: k.restartKillSignal)
  p.add "FinalKillSignal", $k.finalKillSignal
  p.add "SendSIGHUP", yn(k.sendSigHup)
  p.add "SendSIGKILL", yn(k.sendSigKill)
  p.add "WatchdogSignal", $k.watchdogSignal

proc condLine(c: Condition): string =
  (if c.trigger: "|" else: "") & (if c.negate: "!" else: "") & c.value

proc definitionProperties*(def: UnitDef): seq[(string, string)] =
  ## Every static property of `def` as (name, value), in a stable order; values
  ## follow `systemctl show` (booleans yes/no, `...USec` as `1min 30s`, lists
  ## space separated, `Exec*` as `{ path=... }` structs, repeated keys for
  ## arrays). Unset values are empty strings (callers drop them without `--all`).
  var p: Props
  let c = def.common
  p.add "Id", c.id
  p.add "Names", c.names.join(" ")
  p.add "Description", (if c.description.len > 0: c.description else: c.id)
  p.add "Documentation", c.documentation.join(" ")
  p.add "LoadState", $c.loadState
  p.add "FragmentPath", c.fragmentPath
  p.add "SourcePath", c.sourcePath
  p.add "DropInPaths", c.dropInPaths.join(" ")
  for k in DepKind:
    if k == dkTriggers:
      p.add "Triggers", (c.deps[k] & c.implicitDeps[k]).join(" ")
    else:
      p.add $k, (c.deps[k] & c.implicitDeps[k]).join(" ")
  p.add "RequiresMountsFor", c.requiresMountsFor.join(" ")
  p.add "WantsMountsFor", c.wantsMountsFor.join(" ")
  p.add "StopWhenUnneeded", yn(c.stopWhenUnneeded)
  p.add "RefuseManualStart", yn(c.refuseManualStart)
  p.add "RefuseManualStop", yn(c.refuseManualStop)
  p.add "AllowIsolate", yn(c.allowIsolate)
  p.add "IgnoreOnIsolate", yn(c.ignoreOnIsolate)
  p.add "DefaultDependencies", yn(c.defaultDependencies)
  p.add "CollectMode", $c.collectMode
  p.add "OnFailureJobMode", $c.onFailureJobMode
  p.add "OnSuccessJobMode", $c.onSuccessJobMode
  p.add "JobTimeoutUSec", usec(c.jobTimeoutUsec)
  p.add "JobRunningTimeoutUSec", usec(c.jobRunningTimeoutUsec)
  proc act(a: UnitAction; f: ActionFlavor): string =
    $a & (if f == afForce: "-force" elif f == afImmediate: "-immediate" else: "")
  p.add "JobTimeoutAction", act(c.jobTimeoutAction, c.jobTimeoutActionFlavor)
  p.add "SuccessAction", act(c.successAction, c.successActionFlavor)
  p.add "FailureAction", act(c.failureAction, c.failureActionFlavor)
  p.add "StartLimitAction", act(c.startLimitAction, c.startLimitActionFlavor)
  if c.successActionExitStatus >= 0: p.add "SuccessActionExitStatus", $c.successActionExitStatus
  if c.failureActionExitStatus >= 0: p.add "FailureActionExitStatus", $c.failureActionExitStatus
  p.add "StartLimitIntervalUSec", usec(c.startLimitIntervalUsec)
  p.add "StartLimitBurst", $c.startLimitBurst
  for cond in c.conditions:
    p.add (if cond.isAssert: "Assert" else: "Condition") & $cond.kind, condLine(cond)
  p.add "Slice", c.slice
  p.add "Alias", c.install.alias.join(" ")
  p.add "WantedBy", c.install.wantedBy.join(" ")
  p.add "RequiredBy", c.install.requiredBy.join(" ")
  p.add "UpheldBy", c.install.upheldBy.join(" ")
  case def.kind
  of ukService:
    let s = def.service
    p.add "Type", $s.typ
    p.add "ExitType", $s.exitType
    p.add "Restart", $s.restart
    p.add "RestartUSec", usec(s.restartUsec)
    p.add "RestartSteps", $s.restartSteps
    p.add "RestartMaxDelayUSec", (if s.restartMaxDelayUsec == 0: "infinity" else: usec(s.restartMaxDelayUsec))
    p.add "SuccessExitStatus", fmtExit(s.successExit)
    p.add "RestartPreventExitStatus", fmtExit(s.restartPreventExit)
    p.add "RestartForceExitStatus", fmtExit(s.restartForceExit)
    p.add "TimeoutStartUSec", usec(s.timeoutStartUsec)
    p.add "TimeoutStopUSec", usec(s.timeoutStopUsec)
    p.add "TimeoutAbortUSec", usec(s.timeoutAbortUsec)
    p.add "TimeoutStartFailureMode", $s.timeoutStartFailure
    p.add "TimeoutStopFailureMode", $s.timeoutStopFailure
    p.add "RuntimeMaxUSec", usec(s.runtimeMaxUsec)
    p.add "RuntimeRandomizedExtraUSec", usec(s.runtimeRandomExtraUsec)
    p.add "WatchdogUSec", usec(s.watchdogUsec)
    p.add "RemainAfterExit", yn(s.remainAfterExit)
    p.add "GuessMainPID", yn(s.guessMainPid)
    p.add "NonBlocking", yn(s.nonBlocking)
    p.add "PIDFile", s.pidFile
    p.add "NotifyAccess", $s.notifyAccess
    p.add "OOMPolicy", $s.oomPolicy
    p.add "Sockets", s.sockets.join(" ")
    p.add "FileDescriptorStoreMax", $s.fdStoreMax
    p.add "FileDescriptorStorePreserve", $s.fdStorePreserve
    p.add "ReloadSignal", $s.reloadSignal
    p.add "BusName", s.busName
    const execKeys = [(ekCondition, "ExecCondition"), (ekStartPre, "ExecStartPre"), (ekStart, "ExecStart"),
      (ekStartPost, "ExecStartPost"), (ekReload, "ExecReload"), (ekStop, "ExecStop"), (ekStopPost, "ExecStopPost")]
    for (k, name) in execKeys:
      for cmd in s.commands[k]: p.add name, execStruct(cmd)
    killProps(p, s.kill)
    execProps(p, s.exec)
    resProps(p, s.res)
  of ukSocket:
    let s = def.socket
    for l in s.listen:
      let t = case l.kind
        of lkStream: "Stream"
        of lkDatagram: "Datagram"
        of lkSequentialPacket: "SequentialPacket"
        of lkFifo: "FIFO"
        of lkSpecial: "Special"
        of lkNetlink: "Netlink"
        of lkMessageQueue: "MessageQueue"
      p.add "Listen", l.address & " (" & t & ")"
    p.add "Accept", yn(s.accept)
    p.add "Writable", yn(s.writable)
    p.add "KeepAlive", yn(s.keepAlive)
    p.add "NoDelay", yn(s.noDelay)
    p.add "ReusePort", yn(s.reusePort)
    p.add "FreeBind", yn(s.freeBind)
    p.add "Transparent", yn(s.transparent)
    p.add "Broadcast", yn(s.broadcast)
    p.add "PassCredentials", yn(s.passCredentials)
    p.add "PassSecurity", yn(s.passSecurity)
    p.add "PassPacketInfo", yn(s.passPacketInfo)
    p.add "RemoveOnStop", yn(s.removeOnStop)
    p.add "MaxConnections", $s.maxConnections
    p.add "MaxConnectionsPerSource", $s.maxConnectionsPerSource
    p.add "Service", s.service
    p.add "FileDescriptorName", s.fileDescriptorName
    p.add "SocketUser", s.socketUser
    p.add "SocketGroup", s.socketGroup
    p.add "BindToDevice", s.bindToDevice
    p.add "SocketMode", fmtOctal(s.socketMode)
    p.add "DirectoryMode", fmtOctal(s.directoryMode)
    p.add "Symlinks", s.symlinks.join(" ")
    p.add "TriggerLimitIntervalUSec", usec(s.triggerLimitIntervalSec)
    p.add "TriggerLimitBurst", (if s.triggerLimitBurst == UnsetInt: "[not set]" else: $s.triggerLimitBurst)
    p.add "PollLimitIntervalUSec", usec(s.pollLimitIntervalSec)
    p.add "PollLimitBurst", $s.pollLimitBurst
    p.add "BindIPv6Only", $s.bindIPv6Only
    p.add "Backlog", (if s.backlog == UnsetInt: "4096" else: $s.backlog)
    if s.receiveBuffer > 0: p.add "ReceiveBuffer", $s.receiveBuffer
    if s.sendBuffer > 0: p.add "SendBuffer", $s.sendBuffer
    if s.pipeSize > 0: p.add "PipeSize", $s.pipeSize
    if s.messageQueueMaxMessages > 0: p.add "MessageQueueMaxMessages", $s.messageQueueMaxMessages
    if s.messageQueueMessageSize > 0: p.add "MessageQueueMessageSize", $s.messageQueueMessageSize
    if s.ipTOS.len > 0: p.add "IPTOS", s.ipTOS
    if s.ipTTL != UnsetInt: p.add "IPTTL", $s.ipTTL
    if s.mark != UnsetInt: p.add "Mark", $s.mark
    if s.priority != UnsetInt: p.add "Priority", $s.priority
    if s.keepAliveTimeSec != UnsetInt: p.add "KeepAliveTimeUSec", usec(s.keepAliveTimeSec)
    if s.keepAliveIntervalSec != UnsetInt: p.add "KeepAliveIntervalUSec", usec(s.keepAliveIntervalSec)
    if s.keepAliveProbes != UnsetInt: p.add "KeepAliveProbes", $s.keepAliveProbes
    if s.deferAcceptSec != UnsetInt: p.add "DeferAcceptUSec", usec(s.deferAcceptSec)
    p.add "Timestamping", s.timestamping
    p.add "TCPCongestion", s.tcpCongestion
    p.add "SocketProtocol", s.socketProtocol
    p.add "TimeoutUSec", usec(s.timeoutSec)
    const sk = [(ekStartPre, "ExecStartPre"), (ekStartPost, "ExecStartPost"), (ekStop, "ExecStopPre"), (ekStopPost, "ExecStopPost")]
    for (k, name) in sk:
      for cmd in s.commands[k]: p.add name, execStruct(cmd)
    killProps(p, s.kill)
    execProps(p, s.exec)
    resProps(p, s.res)
  of ukTimer:
    let t = def.timer
    for v in t.values:
      case v.base
      of tbCalendar: p.add "TimersCalendar", "{ OnCalendar=" & v.calendar & " ; next_elapse=n/a }"
      of tbClockChange: p.add "OnClockChange", "yes"
      of tbTimezoneChange: p.add "OnTimezoneChange", "yes"
      else: p.add "TimersMonotonic", "{ " & $v.base & "=" & usec(v.usec) & " ; next_elapse=n/a }"
    p.add "AccuracyUSec", usec(t.accuracySec)
    p.add "RandomizedDelayUSec", usec(t.randomizedDelaySec)
    p.add "FixedRandomDelay", yn(t.fixedRandomDelay)
    p.add "Persistent", yn(t.persistent)
    p.add "WakeSystem", yn(t.wakeSystem)
    p.add "RemainAfterElapse", yn(t.remainAfterElapse)
    p.add "Unit", t.unit
  of ukPath:
    let t = def.path
    for x in t.paths: p.add "Paths", "{ " & $x.kind & "=" & x.path & " }"
    p.add "MakeDirectory", yn(t.makeDirectory)
    p.add "DirectoryMode", fmtOctal(t.directoryMode)
    p.add "TriggerLimitIntervalUSec", usec(t.triggerLimitIntervalSec)
    p.add "TriggerLimitBurst", $t.triggerLimitBurst
    p.add "Unit", t.unit
  of ukMount, ukAutomount:
    let m = def.mount
    p.add "What", m.what
    p.add "Where", m.where
    p.add "Type", m.typ
    p.add "Options", m.options
    p.add "SloppyOptions", yn(m.sloppyOptions)
    p.add "LazyUnmount", yn(m.lazyUnmount)
    p.add "ReadWriteOnly", yn(m.readWriteOnly)
    p.add "ForceUnmount", yn(m.forceUnmount)
    p.add "DirectoryMode", fmtOctal(m.directoryMode)
    p.add "TimeoutUSec", usec(m.timeoutSec)
    killProps(p, m.kill)
    execProps(p, m.exec)
    resProps(p, m.res)
  of ukSwap:
    let s = def.swap
    p.add "What", s.what
    p.add "Priority", (if s.priority.isSome: $s.priority.get else: "-1")
    p.add "Options", s.options
    p.add "TimeoutUSec", usec(s.timeoutSec)
    killProps(p, s.kill)
    execProps(p, s.exec)
    resProps(p, s.res)
  of ukSlice:
    resProps(p, def.slice.res)
  else: discard
  p

proc propertyValue*(props: seq[(string, string)]; name: string): string =
  ## First value of `name` ("" when absent).
  for (k, v) in props:
    if k == name: return v
