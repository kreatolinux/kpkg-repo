## Unit search path lists (spec §6.1, §6.12) derived from `Roots`; no environment
## variable is consulted. Priority is list order (index 0 wins).
import std/os
import ../common/roots

type
  DirRole* = enum
    drControl,          ## persistent set-property drop-ins (`system.control`)
    drRuntimeControl,   ## runtime set-property drop-ins
    drTransient,
    drGeneratorEarly,
    drPersistent,       ## `/etc/systemd/system`, `~/.config/systemd/user`: enable/mask/link write here
    drGlobal,           ## user scope: `/etc/xdg/systemd/user`, `/etc/systemd/user`
    drRuntime,          ## `/run/systemd/system`: the `--runtime` variants write here
    drGenerator,
    drVendor,           ## distribution units; links here are never removed
    drGeneratorLate,
    drCore              ## units shipped with the core (lowest)
  SearchDir* = object
    path*: string
    role*: DirRole

proc sysEtc*(r: Roots): string =
  ## The machine's `/etc` (user scope's `Roots.etc` is `~/.config`).
  if r.scope == scSystem: r.etc else: r.usrLib.parentDir.parentDir / "etc"

proc libDir(r: Roots): string = r.usrLib.parentDir.parentDir / "lib"

proc mergedUsr(r: Roots): bool =
  ## True when `/lib` does not exist or is a symlink to `/usr/lib`.
  let l = libDir(r)
  if not dirExists(l): return true
  if symlinkExists(l): return true
  try: sameFile(l, r.usrLib) except OSError: false

proc unitSearchPath*(r: Roots): seq[SearchDir] =
  ## §6.1, highest priority first.
  template dir(p: string; rl: DirRole) = result.add SearchDir(path: p, role: rl)
  if r.scope == scSystem:
    dir r.etc / "systemd/system.control", drControl
    dir r.sysrun / "system.control", drRuntimeControl
    dir r.sysrun / "transient", drTransient
    dir r.sysrun / "generator.early", drGeneratorEarly
    dir r.etc / "systemd/system", drPersistent
    dir r.sysrun / "system", drRuntime
    dir r.sysrun / "generator", drGenerator
    dir r.usrLib.parentDir / "local/lib/systemd/system", drVendor
    dir r.usrLib / "systemd/system", drVendor
    if not mergedUsr(r): dir libDir(r) / "systemd/system", drVendor
    dir r.sysrun / "generator.late", drGeneratorLate
    dir r.coreRoot / "share/units", drCore
  else:
    let se = sysEtc(r)
    dir r.etc / "systemd/user.control", drControl
    dir r.sysrun / "user.control", drRuntimeControl
    dir r.sysrun / "transient", drTransient
    dir r.sysrun / "generator.early", drGeneratorEarly
    dir r.etc / "systemd/user", drPersistent
    dir se / "xdg/systemd/user", drGlobal
    dir se / "systemd/user", drGlobal
    dir r.sysrun / "user", drRuntime
    dir r.run / "systemd/user", drRuntime
    dir r.sysrun / "generator", drGenerator
    dir r.home / ".local/share/systemd/user", drVendor
    dir r.usrShare.parentDir / "local/share/systemd/user", drVendor
    dir r.usrShare / "systemd/user", drVendor
    dir r.usrLib.parentDir / "local/lib/systemd/user", drVendor
    dir r.usrLib / "systemd/user", drVendor
    dir r.sysrun / "generator.late", drGeneratorLate
    dir r.coreRoot / "share/units-user", drCore

proc configDir*(r: Roots; runtime = false; global = false): string =
  ## Where `enable`/`mask`/`link` write: persistent (`/etc/systemd/system`,
  ## `~/.config/systemd/user`; `--global`: `/etc/systemd/user`) or runtime.
  if r.scope == scSystem:
    if runtime: r.sysrun / "system" else: r.etc / "systemd/system"
  elif global:
    if runtime: r.run / "systemd/user" else: sysEtc(r) / "systemd/user"
  else:
    if runtime: r.sysrun / "user" else: r.etc / "systemd/user"

proc enablementDirs*(r: Roots; global = false): seq[tuple[path: string, runtime: bool]] =
  ## Every configuration directory `disable` cleans, persistent first.
  if r.scope == scSystem:
    @[(r.etc / "systemd/system", false), (r.sysrun / "system", true)]
  elif global:
    @[(sysEtc(r) / "systemd/user", false), (r.run / "systemd/user", true)]
  else:
    @[(r.etc / "systemd/user", false), (sysEtc(r) / "xdg/systemd/user", false),
      (sysEtc(r) / "systemd/user", false), (r.sysrun / "user", true), (r.run / "systemd/user", true)]

proc controlDirs*(r: Roots): tuple[persistent, runtime: string] =
  if r.scope == scSystem: (r.etc / "systemd/system.control", r.sysrun / "system.control")
  else: (r.etc / "systemd/user.control", r.sysrun / "user.control")

proc generatorSearchPath*(r: Roots): seq[string] =
  ## §6.12: executables in these directories, high priority first.
  if r.scope == scSystem:
    result = @[r.sysrun / "system-generators", r.etc / "systemd/system-generators",
               r.usrLib.parentDir / "local/lib/systemd/system-generators",
               r.usrLib / "systemd/system-generators"]
    if not mergedUsr(r): result.add libDir(r) / "systemd/system-generators"
  else:
    let se = sysEtc(r)
    result = @[r.sysrun / "user-generators", r.etc / "systemd/user-generators",
               se / "systemd/user-generators", r.usrLib.parentDir / "local/lib/systemd/user-generators",
               r.usrLib / "systemd/user-generators"]

proc generatorOutputDirs*(r: Roots): tuple[normal, early, late: string] =
  (r.sysrun / "generator", r.sysrun / "generator.early", r.sysrun / "generator.late")

proc isVendorRole*(role: DirRole): bool = role in {drVendor, drCore}
