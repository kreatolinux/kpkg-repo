## Value types (spec §6.4): booleans, timespans, sizes, percents, words with
## quoting and C escapes, signals, exit status sets, and their formatting for
## `systemctl show`. Pure; every parser returns `none`/false on bad input.
import std/[options, strutils, sequtils]
import ./model

const UsecPerSec = 1_000_000'i64

proc parseBoolVal*(s: string): Option[bool] =
  case s.toLowerAscii
  of "1", "yes", "true", "on", "y", "t": some(true)
  of "0", "no", "false", "off", "n", "f": some(false)
  else: none(bool)

proc boolStr*(b: bool): string = (if b: "yes" else: "no")

# ---- timespans -------------------------------------------------------------

proc unitUsec(u: string): int64 =
  case u
  of "usec", "us", "\xCE\xBCs": 1
  of "msec", "ms": 1000
  of "seconds", "second", "sec", "s": UsecPerSec
  of "minutes", "minute", "min", "m": 60 * UsecPerSec
  of "hours", "hour", "hr", "h": 3600 * UsecPerSec
  of "days", "day", "d": 86400 * UsecPerSec
  of "weeks", "week", "w": 7 * 86400 * UsecPerSec
  of "months", "month", "M": 2629800 * UsecPerSec     # 30.4375 days
  of "years", "year", "y": 31557600 * UsecPerSec      # 365.25 days
  else: 0

proc parseTimespan*(s: string; bareUnit = UsecPerSec): Option[int64] =
  ## `systemd.time(7)`. A bare number counts `bareUnit` microseconds (default
  ## seconds). `infinity` is `high(int64)`. Overflow and negatives are errors.
  let t = s.strip
  if t.len == 0: return
  if t == "infinity": return some(Infinity)
  var i = 0
  var total = 0'i64
  var any = false
  while i < t.len:
    while i < t.len and t[i] in {' ', '\t'}: inc i
    if i >= t.len: break
    var ip = 0'i64
    var digits = 0
    while i < t.len and t[i] in {'0'..'9'}:
      let d = int64(ord(t[i]) - 48)
      if ip > (high(int64) - d) div 10: return
      ip = ip * 10 + d
      inc i; inc digits
    var frac = ""
    if i < t.len and t[i] == '.':
      inc i
      while i < t.len and t[i] in {'0'..'9'}:
        frac.add t[i]; inc i
    if digits == 0 and frac.len == 0: return
    var u = ""
    let save = i
    while i < t.len and t[i] in {' ', '\t'}: inc i
    while i < t.len and t[i] notin {' ', '\t'} and t[i] notin {'0'..'9', '.'}:
      u.add t[i]; inc i
    if u.len == 0: i = save
    let mult = if u.len == 0: bareUnit else: unitUsec(u)
    if mult == 0: return
    if ip > high(int64) div mult: return
    var part = ip * mult
    if frac.len > 0:
      var f = 0'i64
      var scale = 1'i64
      for c in frac:
        if scale >= mult * 10: break         # beyond one microsecond
        f = f * 10 + int64(ord(c) - 48)
        scale *= 10
      part += f * mult div scale
    if total > high(int64) - part: return
    total += part
    any = true
  if any: some(total) else: none(int64)

proc formatTimespan*(usec: int64): string =
  ## systemd's format_timespan: `1min 30s`, `100ms`, `1s 500ms`, `0`, `infinity`.
  if usec == Infinity: return "infinity"
  if usec == 0: return "0"
  const tbl = [("y", 31557600 * UsecPerSec), ("month", 2629800 * UsecPerSec), ("w", 604800 * UsecPerSec),
               ("d", 86400 * UsecPerSec), ("h", 3600 * UsecPerSec), ("min", 60 * UsecPerSec),
               ("s", UsecPerSec), ("ms", 1000'i64), ("us", 1'i64)]
  var v = usec
  for (n, m) in tbl:
    if v < m: continue
    let k = v div m
    v = v mod m
    if result.len > 0: result.add ' '
    result.add $k & n

proc formatUsecProperty*(usec: int64): string = formatTimespan(usec)

# ---- sizes, percents -------------------------------------------------------

proc parseSize*(s: string; base = 1024'i64): Option[int64] =
  ## `K M G T P E` suffixes (optional trailing `B`), fractions allowed, `infinity`.
  let t = s.strip
  if t == "infinity": return some(Infinity)
  if t.len == 0: return
  var i = 0
  var total = 0'i64
  var any = false
  while i < t.len:
    while i < t.len and t[i] in {' ', '\t'}: inc i
    if i >= t.len: break
    var ip = 0'i64
    var digits = 0
    while i < t.len and t[i] in {'0'..'9'}:
      let d = int64(ord(t[i]) - 48)
      if ip > (high(int64) - d) div 10: return
      ip = ip * 10 + d; inc i; inc digits
    var frac = ""
    if i < t.len and t[i] == '.':
      inc i
      while i < t.len and t[i] in {'0'..'9'}: frac.add t[i]; inc i
    if digits == 0 and frac.len == 0: return
    var mult = 1'i64
    if i < t.len and t[i] in {'K', 'M', 'G', 'T', 'P', 'E'}:
      for c in "KMGTPE":
        mult *= base
        if c == t[i]: break
      inc i
    if i < t.len and t[i] == 'B': inc i
    if ip > high(int64) div mult: return
    var part = ip * mult
    if frac.len > 0 and mult > 1:
      var f = 0'i64
      var scale = 1'i64
      for c in frac:
        if scale > 1_000_000_000: break
        f = f * 10 + int64(ord(c) - 48); scale *= 10
      part += f * (mult div scale) + (f * (mult mod scale)) div scale
    total += part
    any = true
    if i < t.len and t[i] notin {' ', '\t'} and t[i] notin {'0'..'9'}: return
  if any: some(total) else: none(int64)

proc parsePermille*(s: string): Option[int64] =
  ## `N%` or `N‰` (decimals allowed) to permille.
  var t = s.strip
  var perMille = false
  if t.endsWith("%"): t.setLen(t.len - 1)
  elif t.endsWith("\xE2\x80\xB0"): t.setLen(t.len - 3); perMille = true
  else: return
  t = t.strip
  if t.len == 0: return
  let dot = t.find('.')
  var ip, fp = 0'i64
  try:
    ip = parseBiggestInt(if dot < 0: t else: t[0 ..< dot])
    if dot >= 0 and dot < t.high:
      let f = t[dot + 1 .. ^1]
      if not f.allCharsInSet({'0'..'9'}): return
      fp = parseBiggestInt(f[0 ..< min(1, f.len)])
  except ValueError: return
  if ip < 0: return
  if perMille: some(ip)
  else: some(ip * 10 + fp)

proc parseNat*(s: string; maxv = high(int64)): Option[int64] =
  let t = s.strip
  if t.len == 0 or not t.allCharsInSet({'0'..'9'}): return
  try:
    let v = parseBiggestInt(t)
    if v <= maxv: some(v) else: none(int64)
  except ValueError: none(int64)

proc parseIntVal*(s: string): Option[int64] =
  let t = s.strip
  if t.len == 0: return
  try: some(parseBiggestInt(t))
  except ValueError: none(int64)

proc parseOctal*(s: string): Option[int] =
  let t = s.strip
  if t.len == 0 or not t.allCharsInSet({'0'..'7'}): return
  try: some(parseOctInt(t))
  except ValueError: none(int)

# ---- words -----------------------------------------------------------------

type Word* = object
  text*: string
  quoted*: bool               ## the word contained a quoted part

proc appendUtf8(s: var string; cp: int) =
  if cp < 0x80: s.add char(cp)
  elif cp < 0x800:
    s.add char(0xC0 or (cp shr 6)); s.add char(0x80 or (cp and 0x3F))
  elif cp < 0x10000:
    s.add char(0xE0 or (cp shr 12)); s.add char(0x80 or ((cp shr 6) and 0x3F)); s.add char(0x80 or (cp and 0x3F))
  else:
    s.add char(0xF0 or (cp shr 18)); s.add char(0x80 or ((cp shr 12) and 0x3F))
    s.add char(0x80 or ((cp shr 6) and 0x3F)); s.add char(0x80 or (cp and 0x3F))

proc cEscape(s: string; i: var int; outp: var string) =
  ## `s[i]` is the backslash; consumes the escape. Unknown escapes stay verbatim.
  let n = s.len
  if i + 1 >= n:
    outp.add '\\'; inc i; return
  let c = s[i + 1]
  template simple(ch: char) =
    outp.add ch; i += 2; return
  case c
  of 'a': simple '\a'
  of 'b': simple '\b'
  of 'f': simple '\f'
  of 'n': simple '\n'
  of 'r': simple '\r'
  of 't': simple '\t'
  of 'v': simple '\v'
  of '\\': simple '\\'
  of '"': simple '"'
  of '\'': simple '\''
  of 's': simple ' '
  of 'x':
    if i + 3 < n and s[i+2] in HexDigits and s[i+3] in HexDigits:
      outp.add char(parseHexInt(s[i+2 .. i+3])); i += 4; return
  of '0'..'7':
    if i + 3 < n and s[i+2] in {'0'..'7'} and s[i+3] in {'0'..'7'}:
      let v = parseOctInt(s[i+1 .. i+3])
      if v <= 255: outp.add char(v); i += 4; return
  of 'u', 'U':
    let k = if c == 'u': 4 else: 8
    if i + 2 + k <= n and s[i+2 ..< i+2+k].allCharsInSet(HexDigits):
      let cp = parseHexInt(s[i+2 ..< i+2+k])
      if cp > 0 and cp <= 0x10FFFF and not (cp in 0xD800..0xDFFF):
        appendUtf8(outp, cp); i += 2 + k; return
  else: discard
  outp.add '\\'; outp.add c; i += 2

proc splitWordsEx*(s: string; words: var seq[Word]; cunescape = true): bool =
  ## systemd's extract_first_word loop with UNQUOTE and CUNESCAPE: words are
  ## separated by white space, quotes group, escapes work in and out of quotes.
  ## False for an unterminated quote.
  var i = 0
  let n = s.len
  while true:
    while i < n and s[i] in {' ', '\t', '\n', '\r'}: inc i
    if i >= n: break
    var w = Word()
    var q = '\0'
    while i < n:
      let c = s[i]
      if q != '\0':
        if c == q: q = '\0'; inc i
        elif c == '\\' and cunescape: cEscape(s, i, w.text)
        else: w.text.add c; inc i
      elif c in {'\'', '"'}:
        q = c; w.quoted = true; inc i
      elif c in {' ', '\t', '\n', '\r'}: break
      elif c == '\\' and cunescape: cEscape(s, i, w.text)
      else: w.text.add c; inc i
    if q != '\0': return false
    words.add w
  true

proc splitWords*(s: string; ok: var bool): seq[string] =
  var ws: seq[Word]
  ok = splitWordsEx(s, ws)
  for w in ws: result.add w.text

proc splitWords*(s: string): seq[string] =
  var ok: bool
  splitWords(s, ok)

proc cUnescape*(s: string): string =
  var i = 0
  while i < s.len:
    if s[i] == '\\': cEscape(s, i, result)
    else: result.add s[i]; inc i

proc quoteWord*(w: string): string =
  ## For display: quote when the word has white space, quotes or backslashes.
  if w.len > 0 and not w.anyIt(it in {' ', '\t', '\n', '"', '\'', '\\', ';'}): return w
  result = "\""
  for c in w:
    case c
    of '"': result.add "\\\""
    of '\\': result.add "\\\\"
    of '\n': result.add "\\n"
    of '\t': result.add "\\t"
    else: result.add c
  result.add '"'

# ---- signals, exit sets ----------------------------------------------------

const SignalNames = [(1, "HUP"), (2, "INT"), (3, "QUIT"), (4, "ILL"), (5, "TRAP"), (6, "ABRT"),
  (7, "BUS"), (8, "FPE"), (9, "KILL"), (10, "USR1"), (11, "SEGV"), (12, "USR2"), (13, "PIPE"),
  (14, "ALRM"), (15, "TERM"), (16, "STKFLT"), (17, "CHLD"), (18, "CONT"), (19, "STOP"),
  (20, "TSTP"), (21, "TTIN"), (22, "TTOU"), (23, "URG"), (24, "XCPU"), (25, "XFSZ"),
  (26, "VTALRM"), (27, "PROF"), (28, "WINCH"), (29, "IO"), (30, "PWR"), (31, "SYS"),
  (34, "RTMIN"), (64, "RTMAX")]

proc parseSignal*(s: string): Option[int] =
  ## `SIGTERM`, `TERM` (case-sensitive), `RTMIN+3`, or a decimal 1..64.
  let t = s.strip
  if t.len == 0: return
  if t.allCharsInSet({'0'..'9'}):
    let v = parseNat(t, 64)
    if v.isSome and v.get >= 1: return some(int(v.get))
    return
  var name = t
  if name.startsWith("SIG"): name = name[3 .. ^1]
  if name == "IOT": return some(6)
  if name == "POLL": return some(29)
  if name == "CLD": return some(17)
  for (n, nm) in SignalNames:
    if nm == name: return some(n)
  for (base, nm, sign) in [(34, "RTMIN+", 1), (64, "RTMAX-", -1)]:
    if name.startsWith(nm):
      let k = parseNat(name[nm.len .. ^1], 30)
      if k.isSome:
        let v = base + sign * int(k.get)
        if v in 34..64: return some(v)
  none(int)

proc signalName*(n: int): string =
  ## `SIGTERM` style; "" for unknown numbers.
  for (k, nm) in SignalNames:
    if k == n: return "SIG" & nm
  if n in 35..63:
    return if n <= 49: "SIGRTMIN+" & $(n - 34) else: "SIGRTMAX-" & $(64 - n)

const ExitStatusNames = [("SUCCESS", 0), ("FAILURE", 1), ("USAGE", 64), ("DATAERR", 65), ("NOINPUT", 66),
  ("NOUSER", 67), ("NOHOST", 68), ("UNAVAILABLE", 69), ("SOFTWARE", 70), ("OSERR", 71), ("OSFILE", 72),
  ("CANTCREAT", 73), ("IOERR", 74), ("TEMPFAIL", 75), ("PROTOCOL", 76), ("NOPERM", 77), ("CONFIG", 78),
  ("CHDIR", 200), ("NICE", 201), ("FDS", 202), ("EXEC", 203), ("MEMORY", 204), ("LIMITS", 205),
  ("OOM_ADJUST", 206), ("SIGNAL_MASK", 207), ("STDIN", 208), ("STDOUT", 209), ("CHROOT", 210),
  ("IOPRIO", 211), ("TIMERSLACK", 212), ("SECUREBITS", 213), ("SETSCHEDULER", 214), ("CPUAFFINITY", 215),
  ("GROUP", 216), ("USER", 217), ("CAPABILITIES", 218), ("CGROUP", 219), ("SETSID", 220), ("CONFIRM", 221),
  ("STDERR", 222), ("PAM", 224), ("NETWORK", 225), ("NAMESPACE", 226), ("NO_NEW_PRIVILEGES", 227),
  ("SECCOMP", 228), ("SELINUX_CONTEXT", 229), ("PERSONALITY", 230), ("APPARMOR_PROFILE", 231),
  ("ADDRESS_FAMILIES", 232), ("RUNTIME_DIRECTORY", 233), ("CHOWN", 235), ("SMACK_PROCESS_LABEL", 236),
  ("KEYRING", 237), ("STATE_DIRECTORY", 238), ("CACHE_DIRECTORY", 239), ("LOGS_DIRECTORY", 240),
  ("CONFIGURATION_DIRECTORY", 241), ("NUMA_POLICY", 242), ("CREDENTIALS", 243), ("BPF", 245)]

proc exitStatusName*(code: int): string =
  ## `DATAERR` for 65, "" for numbers without a name.
  for (n, c) in ExitStatusNames:
    if c == code: return n

proc parseExitSet*(s: string; res: var ExitSet): bool =
  ## Words that are numbers 0..255 or signal names; false (set unchanged) when any is invalid.
  var r = ExitSet()
  var ok: bool
  for w in splitWords(s, ok):
    if w.len > 0 and w.allCharsInSet({'0'..'9'}):
      let v = parseNat(w, 255)
      if v.isNone: return false
      r.statuses.incl uint8(v.get)
    else:
      var named = -1
      for (n, c) in ExitStatusNames:
        if n == w: named = c
      if named >= 0: r.statuses.incl uint8(named)
      else:
        let sg = parseSignal(w)
        if sg.isNone: return false
        r.signals.incl uint8(sg.get)
  if not ok: return false
  res.statuses = res.statuses + r.statuses
  res.signals = res.signals + r.signals
  true

proc formatExitSet*(e: ExitSet): string =
  var parts: seq[string]
  for v in e.statuses: parts.add $v
  for v in e.signals: parts.add signalName(int(v))
  parts.join(" ")

# ---- glob ------------------------------------------------------------------

proc globMatch*(pattern, s: string): bool =
  ## fnmatch(3) without FNM_PATHNAME: `*`, `?`, `[a-z]`, `[!x]`, `\x`.
  proc m(p, i, j: int): bool =
    var pi = p
    var si = i
    while pi < pattern.len:
      let c = pattern[pi]
      case c
      of '*':
        while pi < pattern.len and pattern[pi] == '*': inc pi
        if pi == pattern.len: return true
        for k in si .. s.len:
          if m(pi, k, j): return true
        return false
      of '?':
        if si >= s.len: return false
        inc pi; inc si
      of '[':
        if si >= s.len: return false
        var q = pi + 1
        var neg = false
        if q < pattern.len and pattern[q] in {'!', '^'}: neg = true; inc q
        var matched = false
        var first = true
        while q < pattern.len and (pattern[q] != ']' or first):
          first = false
          var lo = pattern[q]
          if lo == '\\' and q + 1 < pattern.len: inc q; lo = pattern[q]
          if q + 2 < pattern.len and pattern[q + 1] == '-' and pattern[q + 2] != ']':
            let hi = pattern[q + 2]
            if s[si] >= lo and s[si] <= hi: matched = true
            q += 3
          else:
            if s[si] == lo: matched = true
            inc q
        if q >= pattern.len: return false     # unterminated class
        if matched == neg: return false
        pi = q + 1; inc si
      of '\\':
        if pi + 1 < pattern.len: inc pi
        if si >= s.len or s[si] != pattern[pi]: return false
        inc pi; inc si
      else:
        if si >= s.len or s[si] != c: return false
        inc pi; inc si
    si == s.len
  m(0, 0, 0)
