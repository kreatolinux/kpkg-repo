## The unit definition model (spec §18.2.2): the typed, fully defaulted result of
## loading a unit file with its drop-ins. Everything the engine, the executor and
## the unit-type modules read about a unit is here.
##
## Conventions
##  * Timespans are `int64` microseconds, `infinity` is `high(int64)` (`Infinity`).
##  * Sizes are `int64` bytes; `infinity` is `high(int64)`.
##  * Directive -> field name: lower camel of the directive (`PrivateTmp` ->
##    `privateTmp`; a leading acronym is lowered: `CPUAffinity` -> `cpuAffinity`,
##    `TTYPath` -> `ttyPath`, `SELinuxContext` -> `seLinuxContext`,
##    `IgnoreSIGPIPE` -> `ignoreSIGPIPE`).
##  * Enums carry the systemd spelling as their string value (`$restart`).
##  * Names ARE stable: new fields may be added, none are renamed or removed.
import std/options
import ../common/names
export names.UnitKind

const
  Infinity* = high(int64)         ## `infinity` for timespans and sizes
  UnsetInt* = -1                  ## "not configured" for ints where 0 is meaningful

type
  Severity* = enum sevWarning = "warning", sevError = "error"
  Diag* = object
    ## One diagnostic (§6.13). `line` is 0 when unknown, `key`/`code` may be empty.
    severity*: Severity
    unit*, file*, key*, message*, code*: string
    line*: int

  LoadState* = enum
    lsLoaded = "loaded", lsNotFound = "not-found", lsBadSetting = "bad-setting",
    lsError = "error", lsMasked = "masked", lsMerged = "merged"

  EnablementState* = enum
    ## `systemctl is-enabled` vocabulary (§6.9).
    esEnabled = "enabled", esEnabledRuntime = "enabled-runtime", esLinked = "linked",
    esLinkedRuntime = "linked-runtime", esMasked = "masked", esMaskedRuntime = "masked-runtime",
    esStatic = "static", esDisabled = "disabled", esIndirect = "indirect",
    esGenerated = "generated", esTransient = "transient", esAlias = "alias",
    esBad = "bad", esNotFound = "not-found"

  UnitSource* = enum
    ## Where a definition came from.
    usFile = "file", usGenerated = "generated", usTransient = "transient",
    usMountinfo = "mountinfo", usFstab = "fstab", usBuiltin = "builtin"

  DepKind* = enum
    dkRequires = "Requires", dkRequisite = "Requisite", dkWants = "Wants",
    dkBindsTo = "BindsTo", dkPartOf = "PartOf", dkUpholds = "Upholds",
    dkConflicts = "Conflicts", dkBefore = "Before", dkAfter = "After",
    dkOnFailure = "OnFailure", dkOnSuccess = "OnSuccess",
    dkPropagatesReloadTo = "PropagatesReloadTo", dkReloadPropagatedFrom = "ReloadPropagatedFrom",
    dkPropagatesStopTo = "PropagatesStopTo", dkStopPropagatedFrom = "StopPropagatedFrom",
    dkTriggers = "Triggers", dkJoinsNamespaceOf = "JoinsNamespaceOf"   ## last is R (rejected)

  ConditionKind* = enum
    ckArchitecture = "Architecture", ckFirmware = "Firmware", ckVirtualization = "Virtualization",
    ckHost = "Host", ckKernelCommandLine = "KernelCommandLine", ckKernelVersion = "KernelVersion",
    ckCredential = "Credential", ckEnvironment = "Environment", ckSecurity = "Security",
    ckCapability = "Capability", ckACPower = "ACPower", ckNeedsUpdate = "NeedsUpdate",
    ckFirstBoot = "FirstBoot", ckPathExists = "PathExists", ckPathExistsGlob = "PathExistsGlob",
    ckPathIsDirectory = "PathIsDirectory", ckPathIsSymbolicLink = "PathIsSymbolicLink",
    ckPathIsMountPoint = "PathIsMountPoint", ckPathIsReadWrite = "PathIsReadWrite",
    ckPathIsEncrypted = "PathIsEncrypted", ckDirectoryNotEmpty = "DirectoryNotEmpty",
    ckFileNotEmpty = "FileNotEmpty", ckFileIsExecutable = "FileIsExecutable",
    ckUser = "User", ckGroup = "Group", ckControlGroupController = "ControlGroupController",
    ckMemory = "Memory", ckCPUs = "CPUs", ckCPUFeature = "CPUFeature", ckOSRelease = "OSRelease",
    ckKernelModuleLoaded = "KernelModuleLoaded"
  Condition* = object
    ## `ConditionXxx=[|][!]value` / `AssertXxx=`. `value` is specifier-expanded.
    kind*: ConditionKind
    value*: string
    negate*, trigger*, isAssert*: bool
    file*: string
    line*: int

  UnitAction* = enum
    uaNone = "none", uaReboot = "reboot", uaPoweroff = "poweroff", uaHalt = "halt",
    uaKexec = "kexec", uaExit = "exit"
  ActionFlavor* = enum afPlain, afForce, afImmediate   ## the `-force`/`-immediate` suffix, folded out of UnitAction
  JobMode* = enum
    jmFail = "fail", jmReplace = "replace", jmReplaceIrreversibly = "replace-irreversibly",
    jmIsolate = "isolate", jmFlush = "flush", jmIgnoreDependencies = "ignore-dependencies",
    jmIgnoreRequirements = "ignore-requirements", jmTriggering = "triggering"
  CollectMode* = enum cmInactive = "inactive", cmInactiveOrFailed = "inactive-or-failed"

  ServiceType* = enum
    stSimple = "simple", stExec = "exec", stForking = "forking", stOneshot = "oneshot",
    stNotify = "notify", stNotifyReload = "notify-reload", stIdle = "idle", stDbus = "dbus"
  RestartPolicy* = enum
    rpNo = "no", rpOnSuccess = "on-success", rpOnFailure = "on-failure",
    rpOnAbnormal = "on-abnormal", rpOnAbort = "on-abort", rpOnWatchdog = "on-watchdog",
    rpAlways = "always"
  KillMode* = enum kmControlGroup = "control-group", kmProcess = "process", kmMixed = "mixed", kmNone = "none"
  NotifyAccess* = enum naNone = "none", naMain = "main", naExec = "exec", naAll = "all"
  ExitType* = enum etMain = "main", etCgroup = "cgroup"
  OomPolicy* = enum opContinue = "continue", opStop = "stop", opKill = "kill"
  FailureMode* = enum fmTerminate = "terminate", fmAbort = "abort", fmKill = "kill"
  FdStorePreserve* = enum fpNo = "no", fpYes = "yes", fpRestart = "restart"

  ExitSet* = object
    ## `SuccessExitStatus=` and friends: exit codes 0..255 and signal numbers 1..64.
    statuses*: set[uint8]
    signals*: set[uint8]

  Setting* = object
    ## One assignment as read (after continuation joining, before specifier expansion).
    section*, key*, value*, file*: string
    line*: int

  InstallSection* = object
    wantedBy*, requiredBy*, upheldBy*, alias*, also*: seq[string]
    defaultInstance*: string
    present*: bool                      ## an `[Install]` section exists

  FileStamp* = object
    ## For `NeedDaemonReload` (§6.13): path, mtime (ns), size, sha1 hex.
    path*, sha1*: string
    mtimeNs*, size*: int64

  ExecFlag* = enum efAt, efMinus, efColon, efPlus, efBang, efBangBang
    ## '!' is {efBang}; '!!' is {efBang, efBangBang} (treated as '!').
  ExecKind* = enum ekCondition, ekStartPre, ekStart, ekStartPost, ekReload, ekStop, ekStopPost
    ## Sockets: `ExecStopPre=` is stored under ekStop.
  ExecCommand* = object
    path*, argv0*: string               ## argv0 only with the `@` prefix
    args*: seq[string]                  ## raw words after the executable (and argv0); `$VAR` unexpanded
    flags*: set[ExecFlag]
    file*: string
    line*: int
    raw*: string                        ## the command text as written (for show/status)

  StdioKind* = enum
    sioInherit = "inherit", sioNull = "null", sioTty = "tty", sioTtyForce = "tty-force",
    sioTtyFail = "tty-fail", sioSocket = "socket", sioFd = "fd", sioFile = "file",
    sioAppend = "append", sioTruncate = "truncate", sioJournal = "journal", sioKmsg = "kmsg",
    sioSyslog = "syslog", sioJournalConsole = "journal+console", sioKmsgConsole = "kmsg+console",
    sioSyslogConsole = "syslog+console", sioData = "data"
  StdioSpec* = object
    kind*: StdioKind
    path*: string                       ## file:/append:/truncate: path, fd: name

  LimitSpec* = object
    ## `LimitNOFILE=1024:524288`. `resource` is the suffix (`NOFILE`, `CPU`, ...). `Infinity` is unlimited.
    resource*: string
    soft*, hard*: int64
  ProtectSystemMode* = enum psNo = "no", psYes = "yes", psFull = "full", psStrict = "strict"
  ProtectHomeMode* = enum phNo = "no", phYes = "yes", phReadOnly = "read-only", phTmpfs = "tmpfs"
  ProtectProcMode* = enum ppDefault = "default", ppNoAccess = "noaccess", ppInvisible = "invisible", ppPtraceable = "ptraceable"
  ProcSubsetMode* = enum pssAll = "all", pssPid = "pid"
  KeyringMode* = enum kmInherit = "inherit", kmPrivate = "private", kmShared = "shared"
  SchedPolicy* = enum spOther = "other", spBatch = "batch", spIdle = "idle", spFifo = "fifo", spRr = "rr"
  DirPreserve* = enum dpNo = "no", dpYes = "yes", dpRestart = "restart"
  DevicePolicy* = enum dvAuto = "auto", dvClosed = "closed", dvStrict = "strict"
  BindIPv6Only* = enum biDefault = "default", biBoth = "both", biIpv6Only = "ipv6-only"

  ExecContext* = object
    ## One field per directive of §2.5 with status S or P (plus `RootDirectoryStartOnly=`
    ## of §2.4). Applies to services, sockets, mounts and swaps. Defaults are systemd's.
    # paths
    workingDirectory*, rootDirectory*: string   ## WorkingDirectory keeps a leading `-` or is `~`
    rootDirectoryStartOnly*: bool
    bindPaths*, bindReadOnlyPaths*, temporaryFileSystem*, readWritePaths*, readOnlyPaths*,
      inaccessiblePaths*, execPaths*, noExecPaths*: seq[string]
    mountAPIVFS*: bool
    protectSystem*: ProtectSystemMode
    protectHome*: ProtectHomeMode
    privateTmp*, privateDevices*, privateMounts*: bool
    mountFlags*: string                         ## shared | slave | private | ""
    protectProc*: ProtectProcMode
    procSubset*: ProcSubsetMode
    protectKernelTunables*, protectKernelModules*, protectKernelLogs*, protectControlGroups*,
      protectClock*, protectHostname*: bool
    # state directories (entries `NAME` or `NAME:LINK`), modes and preserve
    runtimeDirectory*, stateDirectory*, cacheDirectory*, logsDirectory*, configurationDirectory*: seq[string]
    runtimeDirectoryMode*, stateDirectoryMode*, cacheDirectoryMode*, logsDirectoryMode*,
      configurationDirectoryMode*: int = 0o755
    runtimeDirectoryPreserve*: DirPreserve
    # identity
    user*, group*: string
    supplementaryGroups*: seq[string]
    dynamicUser*: bool
    # capabilities
    capabilityBoundingSet*, ambientCapabilities*, secureBits*: seq[string]  ## words; `~` kept on the first
    noNewPrivileges*: bool
    # syscalls and restrictions
    systemCallFilter*, systemCallArchitectures*, restrictAddressFamilies*, restrictNamespaces*: seq[string]
    systemCallErrorNumber*, personality*: string
    lockPersonality*, memoryDenyWriteExecute*, restrictRealtime*, restrictSUIDSGID*: bool
    # namespaces
    privateNetwork*, privateIPC*, privateUsers*, removeIPC*: bool
    networkNamespacePath*, ipcNamespacePath*: string
    # scheduling and process attributes
    nice*, oomScoreAdjust*, cpuSchedulingPriority*, ioSchedulingPriority*: Option[int]
    cpuSchedulingPolicy*: Option[SchedPolicy]
    cpuSchedulingResetOnFork*: bool
    cpuAffinity*, coredumpFilter*: seq[string]
    numaPolicy*, numaMask*, ioSchedulingClass*: string
    timerSlackNSec*: int64 = UnsetInt
    umask*: int = UnsetInt                      ## unset -1 (executor uses 0022)
    keyringMode*: KeyringMode
    ignoreSIGPIPE*: bool = true
    limits*: seq[LimitSpec]                     ## every `LimitXXX=` in file order (last per resource wins)
    # environment
    environment*, environmentFile*, passEnvironment*, unsetEnvironment*: seq[string]
    # stdio
    standardInput*: StdioSpec = StdioSpec(kind: sioNull)
    standardOutput*, standardError*: StdioSpec
    standardInputText*, standardInputData*: seq[string]
    ttyPath*: string = "/dev/console"
    ttyReset*, ttyVHangup*, ttyVTDisallocate*: bool
    ttyRows*, ttyColumns*: int = UnsetInt
    # logging
    syslogIdentifier*: string
    syslogFacility*: string = "daemon"
    syslogLevel*: string = "info"
    syslogLevelPrefix*: bool = true
    logLevelMax*: string
    logExtraFields*: seq[string]
    logRateLimitIntervalSec*: int64 = UnsetInt  ## unset: journald default
    logRateLimitBurst*: int = UnsetInt
    # credentials
    loadCredential*, setCredential*, importCredential*: seq[string]

  KillContext* = object
    killMode*: KillMode
    killSignal*: int = 15
    restartKillSignal*: int                     ## 0: same as killSignal
    finalKillSignal*: int = 9
    watchdogSignal*: int = 6
    sendSigHup*: bool
    sendSigKill*: bool = true

  ResLimit* = object
    ## `MemoryMax=` and friends: unset, a byte count, a percentage, or infinity.
    set*: bool
    infinity*: bool
    percent*: bool                              ## `value` is in permille (`50%` is 500) of the parent/total
    value*: int64
  DelegateSpec* = object
    enabled*: bool
    controllers*: seq[string]                   ## `Delegate=cpu memory`; empty with enabled = all
  DeviceValue* = object
    path*: string
    value*: int64                               ## bytes/s, iops, weight or usec per directive
  DeviceRule* = object
    path*, access*: string                      ## `DeviceAllow=/dev/null rwm`

  ResourceControl* = object
    ## One field per directive of §2.7 with status S or P.
    slice*: string
    delegate*: DelegateSpec
    delegateSubgroup*: string
    disableControllers*: seq[string]
    cpuAccounting*, memoryAccounting*, ioAccounting*, tasksAccounting*: bool
    cpuWeight*, startupCPUWeight*, ioWeight*, startupIOWeight*: int = UnsetInt  ## 0 means `idle` for CPU
    cpuQuota*: int64 = UnsetInt                 ## usec of CPU per second (CPUQuotaPerSecUSec); `20%` is 200000
    cpuQuotaPeriodSec*: int64 = UnsetInt        ## usec
    allowedCPUs*, startupAllowedCPUs*, allowedMemoryNodes*, startupAllowedMemoryNodes*: string
    memoryMin*, memoryLow*, memoryHigh*, memoryMax*, memorySwapMax*, memoryZSwapMax*,
      startupMemoryHigh*, startupMemoryMax*, startupMemorySwapMax*, startupMemoryZSwapMax*,
      tasksMax*: ResLimit
    memoryZSwapWriteback*: bool = true
    ioDeviceWeight*, ioReadBandwidthMax*, ioWriteBandwidthMax*, ioReadIOPSMax*,
      ioWriteIOPSMax*, ioDeviceLatencyTargetSec*: seq[DeviceValue]
    deviceAllow*: seq[DeviceRule]
    devicePolicy*: DevicePolicy

  ServiceConfig* = object
    typ*: ServiceType
    commands*: array[ExecKind, seq[ExecCommand]]
    exec*: ExecContext
    kill*: KillContext
    res*: ResourceControl
    restart*: RestartPolicy
    restartUsec*: int64
    restartSteps*: int
    restartMaxDelayUsec*: int64                 ## 0 unset
    successExit*, restartPreventExit*, restartForceExit*: ExitSet
    timeoutStartUsec*, timeoutStopUsec*, timeoutAbortUsec*, runtimeMaxUsec*,
      runtimeRandomExtraUsec*, watchdogUsec*: int64   ## resolved: abort = stop when unset; oneshot start = infinity
    timeoutStartFailure*, timeoutStopFailure*: FailureMode
    remainAfterExit*, guessMainPid*, nonBlocking*: bool
    pidFile*: string
    notifyAccess*: NotifyAccess                 ## resolved by the §9.2 default rules
    exitType*: ExitType
    oomPolicy*: OomPolicy
    sockets*: seq[string]
    fdStoreMax*: int
    fdStorePreserve*: FdStorePreserve
    reloadSignal*: int = 1                      ## SIGHUP
    busName*: string

  ListenKind* = enum
    lkStream = "ListenStream", lkDatagram = "ListenDatagram", lkSequentialPacket = "ListenSequentialPacket",
    lkFifo = "ListenFIFO", lkSpecial = "ListenSpecial", lkNetlink = "ListenNetlink",
    lkMessageQueue = "ListenMessageQueue"
  ListenSpec* = object
    kind*: ListenKind
    address*: string
  SocketConfig* = object
    ## `[Socket]`. `listen` is in file order (the order of passed descriptors).
    listen*: seq[ListenSpec]
    commands*: array[ExecKind, seq[ExecCommand]]
    exec*: ExecContext
    kill*: KillContext
    res*: ResourceControl
    accept*, removeOnStop*, writable*, keepAlive*, noDelay*, reusePort*, freeBind*, transparent*,
      broadcast*, passCredentials*, passSecurity*, passPacketInfo*: bool
    maxConnections*: int = 64
    maxConnectionsPerSource*: int
    service*, fileDescriptorName*, socketUser*, socketGroup*, bindToDevice*, ipTOS*,
      timestamping*, tcpCongestion*, socketProtocol*: string
    triggerLimitIntervalSec*, pollLimitIntervalSec*: int64 = 2_000_000
    triggerLimitBurst*: int = UnsetInt          ## unset: 200 (20 when Accept=yes)
    pollLimitBurst*: int = 150
    socketMode*: int = 0o666
    directoryMode*: int = 0o755
    symlinks*: seq[string]
    pipeSize*, receiveBuffer*, sendBuffer*: int64
    messageQueueMaxMessages*, messageQueueMessageSize*: int64
    bindIPv6Only*: BindIPv6Only
    backlog*: int = UnsetInt                    ## unset: SOMAXCONN
    keepAliveTimeSec*, keepAliveIntervalSec*, deferAcceptSec*: int64 = UnsetInt
    keepAliveProbes*, priority*, ipTTL*, mark*: int = UnsetInt
    timeoutSec*: int64                          ## resolved from the manager default

  TimerBase* = enum
    tbActive = "OnActiveSec", tbBoot = "OnBootSec", tbStartup = "OnStartupSec",
    tbUnitActive = "OnUnitActiveSec", tbUnitInactive = "OnUnitInactiveSec",
    tbCalendar = "OnCalendar", tbClockChange = "OnClockChange", tbTimezoneChange = "OnTimezoneChange"
  TimerValue* = object
    base*: TimerBase
    usec*: int64                                ## monotonic bases
    calendar*: string                           ## OnCalendar expression (specifiers expanded)
    raw*: string
  TimerConfig* = object
    values*: seq[TimerValue]                    ## in file order
    accuracySec*: int64 = 60_000_000
    randomizedDelaySec*: int64
    fixedRandomDelay*, persistent*, wakeSystem*: bool
    remainAfterElapse*: bool = true
    unit*: string                               ## empty: same-prefix service

  PathKind* = enum
    pkExists = "PathExists", pkExistsGlob = "PathExistsGlob", pkChanged = "PathChanged",
    pkModified = "PathModified", pkDirectoryNotEmpty = "DirectoryNotEmpty"
  PathSpec* = object
    kind*: PathKind
    path*: string
  PathConfig* = object
    paths*: seq[PathSpec]
    unit*: string
    makeDirectory*: bool
    directoryMode*: int = 0o755
    triggerLimitIntervalSec*: int64 = 2_000_000
    triggerLimitBurst*: int = 200

  MountConfig* = object
    ## `[Mount]` (also `[Automount]`, which is R). `what`/`where` are as written.
    what*, where*, typ*, options*: string
    sloppyOptions*, lazyUnmount*, readWriteOnly*, forceUnmount*: bool
    directoryMode*: int = 0o755
    timeoutSec*: int64
    extraOptions*: string                       ## automount
    timeoutIdleSec*: int64
    commands*: array[ExecKind, seq[ExecCommand]]
    exec*: ExecContext
    kill*: KillContext
    res*: ResourceControl
  SwapConfig* = object
    what*, options*: string
    priority*: Option[int]
    timeoutSec*: int64
    exec*: ExecContext
    kill*: KillContext
    res*: ResourceControl
  SliceConfig* = object
    res*: ResourceControl
  TargetConfig* = object
    ## Targets have no settings of their own.
    discard
  DeviceConfig* = object
    discard

  UnitCommon* = object
    id*: string
    names*: seq[string]                         ## id and every alias
    description*: string
    documentation*: seq[string]
    fragmentPath*, sourcePath*: string
    dropInPaths*: seq[string]
    loadState*: LoadState
    loadError*: string
    deps*: array[DepKind, seq[string]]          ## explicit + link-farm; excludes the implicit ones
    implicitDeps*: array[DepKind, seq[string]]  ## §7.2
    conditions*: seq[Condition]                 ## Condition* and Assert* (isAssert)
    defaultDependencies*: bool
    stopWhenUnneeded*, refuseManualStart*, refuseManualStop*, allowIsolate*, ignoreOnIsolate*: bool
    collectMode*: CollectMode
    collectInactiveOrFailed*: bool              ## collectMode == cmInactiveOrFailed
    successAction*, failureAction*, startLimitAction*, jobTimeoutAction*: UnitAction
    successActionFlavor*, failureActionFlavor*, startLimitActionFlavor*, jobTimeoutActionFlavor*: ActionFlavor
    successActionExitStatus*, failureActionExitStatus*: int = UnsetInt
    startLimitIntervalUsec*: int64
    startLimitBurst*: int
    jobTimeoutUsec*, jobRunningTimeoutUsec*: int64 = Infinity
    onFailureJobMode*, onSuccessJobMode*: JobMode
    requiresMountsFor*, wantsMountsFor*: seq[string]
    implicitMountsFor*: seq[string]             ## paths of §7.2 that imply RequiresMountsFor= (WorkingDirectory, Exec paths, PrivateTmp, ...)
    install*: InstallSection
    slice*: string                              ## for units with cgroups (== res.slice, resolved)
    source*: UnitSource
    diagnostics*: seq[Diag]
    # raw information for `systemctl cat/show` and re-evaluation
    settings*: seq[Setting]                     ## every setting of main file and drop-ins, in order
    stamps*: seq[FileStamp]                     ## source list stamps for NeedDaemonReload
    prefix*, instance*: string                  ## name parts ("getty", "tty1")
    templatePath*: string                       ## the template file when this is an instance
    isTemplate*: bool

  UnitDef* = ref object
    common*: UnitCommon
    case kind*: UnitKind
    of ukService: service*: ServiceConfig
    of ukSocket: socket*: SocketConfig
    of ukTimer: timer*: TimerConfig
    of ukPath: path*: PathConfig
    of ukMount, ukAutomount: mount*: MountConfig
    of ukSwap: swap*: SwapConfig
    of ukSlice: slice*: SliceConfig
    of ukTarget: target*: TargetConfig
    of ukDevice, ukScope: discard

  Resolved* = object
    ## Result of `resolveName`: the canonical id, all names, how it was found.
    id*: string                                 ## canonical unit name
    queried*: string
    names*: seq[string]
    kind*: UnitKind
    isAlias*, isTemplateInstance*, masked*, generated*: bool
    fragment*: string
  IndexEntry* = object
    name*: string
    kind*: UnitKind
    fragment*: string                           ## resolved file; "" for built-ins
    isAlias*: bool
    aliasOf*: string
    state*: EnablementState                     ## filled on demand by listNames
    source*: UnitSource

  ManagerConf* = object
    ## §6.11. Unset optional values are `UnsetInt`/empty.
    defaultTimeoutStartUsec*, defaultTimeoutStopUsec*, defaultDeviceTimeoutUsec*: int64 = 90_000_000
    defaultTimeoutAbortUsec*: int64 = UnsetInt
    defaultRestartUsec*: int64 = 100_000
    defaultStartLimitIntervalUsec*: int64 = 10_000_000
    defaultStartLimitBurst*: int = 5
    defaultEnvironment*: seq[string]
    defaultStandardOutput*: StdioSpec = StdioSpec(kind: sioJournal)
    defaultStandardError*: StdioSpec = StdioSpec(kind: sioInherit)
    defaultOOMPolicy*: OomPolicy = opStop
    defaultTasksMax*: ResLimit
    defaultLimits*: seq[LimitSpec] = @[LimitSpec(resource: "NOFILE", soft: 1024, hard: 524288)]
    ignoredKeys*: seq[string]                   ## W keys that were present

  ValidationResult* = object
    unit*: string
    valid*: bool                                ## no diagnostic of severity error
    diagnostics*: seq[Diag]
    def*: UnitDef                               ## the loaded definition (nil when unreadable)

  FileOp* = enum
    foEnable, foDisable, foReenable, foMask, foUnmask, foLink, foRevert, foAddWants,
    foAddRequires, foSetDefault, foPreset, foPresetAll, foIsEnabled
  PresetMode* = enum pmFull = "full", pmEnableOnly = "enable-only", pmDisableOnly = "disable-only"
  FileOpOptions* = object
    runtime*, global*, force*: bool
    presetMode*: PresetMode
    target*: string                             ## add-wants/add-requires TARGET, set-default TARGET
    defaultInstanceForTemplates*: bool = true
  FileChangeKind* = enum fcSymlink, fcUnlink, fcMkdir, fcRmdir
  FileChange* = object
    kind*: FileChangeKind
    link*, target*: string                      ## for fcSymlink: `Created symlink LINK -> TARGET.`
  FileOpResult* = object
    ok*: bool
    changes*: seq[FileChange]
    diags*: seq[Diag]                           ## errors and warnings (vendor link note, ...)
    states*: seq[(string, EnablementState)]     ## per name, for foIsEnabled and after enable
    error*: string                              ## first error text, "" when ok

const
  ServiceExecKeys* = ["ExecCondition", "ExecStartPre", "ExecStart", "ExecStartPost",
                      "ExecReload", "ExecStop", "ExecStopPost"]

proc systemdName*(e: EnablementState): string = $e

proc parseEnumStrict*[T: enum](s: string; res: var T): bool =
  ## Exact, case-sensitive match on the systemd spelling.
  for e in T:
    if $e == s:
      res = e
      return true

proc effectiveType*(c: ServiceConfig): ServiceType =
  ## `Type=dbus` degrades to `exec` (§2.4); everything else is as configured.
  if c.typ == stDbus: stExec else: c.typ

proc newUnitDef*(kind: UnitKind; id: string): UnitDef =
  ## An empty definition with systemd's defaults (service timeouts etc. are
  ## filled by the loader from the `ManagerConf`).
  result = case kind
    of ukService: UnitDef(kind: ukService)
    of ukSocket: UnitDef(kind: ukSocket)
    of ukTimer: UnitDef(kind: ukTimer)
    of ukPath: UnitDef(kind: ukPath)
    of ukMount: UnitDef(kind: ukMount)
    of ukAutomount: UnitDef(kind: ukAutomount)
    of ukSwap: UnitDef(kind: ukSwap)
    of ukSlice: UnitDef(kind: ukSlice)
    of ukTarget: UnitDef(kind: ukTarget)
    of ukDevice: UnitDef(kind: ukDevice)
    of ukScope: UnitDef(kind: ukScope)
  result.common = UnitCommon(id: id, names: @[id], loadState: lsLoaded, defaultDependencies: true,
    onFailureJobMode: jmReplace, onSuccessJobMode: jmFail,
    ignoreOnIsolate: kind in {ukSlice, ukDevice, ukMount, ukSwap, ukAutomount},
    startLimitIntervalUsec: 10_000_000, startLimitBurst: 5)
  case kind
  of ukService:
    result.service = ServiceConfig(restartUsec: 100_000, timeoutStartUsec: 90_000_000,
      timeoutStopUsec: 90_000_000, timeoutAbortUsec: 90_000_000, runtimeMaxUsec: Infinity,
      guessMainPid: true, oomPolicy: opStop, kill: KillContext(), reloadSignal: 1)
    result.service.runtimeMaxUsec = Infinity
  of ukSocket: result.socket = SocketConfig(timeoutSec: 90_000_000)
  of ukMount, ukAutomount: result.mount = MountConfig(timeoutSec: 90_000_000)
  of ukSwap: result.swap = SwapConfig(timeoutSec: 90_000_000)
  else: discard
  let p = parseUnitName(id)
  if p.isSome:
    result.common.prefix = p.get.prefix
    result.common.instance = p.get.instance
    result.common.isTemplate = p.get.isTemplate

proc execContextOf*(d: UnitDef): ptr ExecContext =
  ## The exec context of a service/socket/mount/swap (nil for other kinds; an automount has none).
  case d.kind
  of ukService: addr d.service.exec
  of ukSocket: addr d.socket.exec
  of ukMount: addr d.mount.exec
  of ukSwap: addr d.swap.exec
  else: nil

proc resourceControlOf*(d: UnitDef): ptr ResourceControl =
  case d.kind
  of ukService: addr d.service.res
  of ukSocket: addr d.socket.res
  of ukMount: addr d.mount.res
  of ukSwap: addr d.swap.res
  of ukSlice: addr d.slice.res
  else: nil

proc killContextOf*(d: UnitDef): ptr KillContext =
  case d.kind
  of ukService: addr d.service.kill
  of ukSocket: addr d.socket.kill
  of ukMount: addr d.mount.kill
  of ukSwap: addr d.swap.kill
  else: nil

proc diag*(sev: Severity; unit, file: string; line: int; key, msg: string; code = ""): Diag =
  Diag(severity: sev, unit: unit, file: file, line: line, key: key, message: msg, code: code)

proc isInfinity*(v: int64): bool = v == Infinity
proc hasErrors*(ds: openArray[Diag]): bool =
  for d in ds:
    if d.severity == sevError: return true

proc clone*(d: UnitDef): UnitDef =
  ## A deep copy (the definition is a ref; engines keep their own copies).
  result = newUnitDef(d.kind, d.common.id)
  result.common = d.common
  case d.kind
  of ukService: result.service = d.service
  of ukSocket: result.socket = d.socket
  of ukTimer: result.timer = d.timer
  of ukPath: result.path = d.path
  of ukMount, ukAutomount: result.mount = d.mount
  of ukSwap: result.swap = d.swap
  of ukSlice: result.slice = d.slice
  of ukTarget: result.target = d.target
  of ukDevice, ukScope: discard
