## Manager configuration (spec §6.11): `system.conf` / `user.conf` and their
## `.conf.d` directories, `[Manager]` only, a fixed list of keys.
import std/[os, options, tables, algorithm, strutils]
import ../common/roots
import ./[model, paths, syntax, values, apply, trust]

const
  IgnoredManagerKeys* = ["LogLevel", "LogTarget", "LogColor", "LogLocation", "LogTime", "ShowStatus",
    "DumpCore", "CrashChangeVT", "CrashShell", "CrashReboot", "CtrlAltDelBurstAction",
    "RuntimeWatchdogSec", "RebootWatchdogSec", "ShutdownWatchdogSec", "KExecWatchdogSec",
    "WatchdogDevice", "CPUAffinity", "NUMAPolicy", "NUMAMask", "CapabilityBoundingSet",
    "NoNewPrivileges", "SystemCallArchitectures", "TimerSlackNSec", "JoinControllers",
    "DefaultSmackProcessLabel", "DefaultIPAccounting", "DefaultMemoryPressureWatch",
    "DefaultMemoryPressureThresholdSec", "ManagerEnvironment", "DefaultDeviceTimeoutSec_"]
  AccountingKeys = ["DefaultCPUAccounting", "DefaultMemoryAccounting", "DefaultIOAccounting", "DefaultTasksAccounting"]

proc defaultManagerConf*(r: Roots): ManagerConf =
  ## Defaults of §6.11 (reads `kernel.pid_max` from `r.procfs` for `DefaultTasksMax`).
  result = ManagerConf()
  if r.scope == scSystem:
    try:
      let pm = parseNat(readFile(r.procfs / "sys/kernel/pid_max").strip)
      if pm.isSome: result.defaultTasksMax = ResLimit(set: true, value: max(1, pm.get * 15 div 100))
    except CatchableError: discard

proc confFiles(r: Roots): tuple[main: string, dropIns: seq[string]] =
  let name = if r.scope == scSystem: "system.conf" else: "user.conf"
  var dirs = @[sysEtc(r) / "systemd", r.run / "systemd", r.usrLib / "systemd"]
  for d in dirs:
    if fileExists(d / name):
      result.main = d / name
      break
  var dropDirs = @[r.usrLib / "systemd", r.run / "systemd", sysEtc(r) / "systemd"]
  if r.scope == scUser: dropDirs.add r.etc / "systemd"
  var byName = initTable[string, string]()
  for d in dropDirs:                     # later (higher priority) entries replace earlier
    let dd = d / (name & ".d")
    if not dirExists(dd): continue
    for k, p in walkDir(dd):
      if p.endsWith(".conf") and k in {pcFile, pcLinkToFile}: byName[p.extractFilename] = p
  var fns: seq[string]
  for k in byName.keys: fns.add k
  fns.sort()
  for f in fns: result.dropIns.add byName[f]
  if r.scope == scUser:
    let own = r.etc / "systemd" / name
    if fileExists(own): result.dropIns.add own      # applied last

proc parseManagerConf*(roots: Roots; diags: var seq[Diag]; policy = TrustPolicy()): ManagerConf =
  ## Reads the files, applies every honoured key, warns about ignored and
  ## unknown ones (once each). Never raises.
  var c = defaultManagerConf(roots)
  var pol = policy
  if pol.stat == nil: pol = newTrustPolicy(roots)
  let files = confFiles(roots)
  var paths: seq[string]
  if files.main.len > 0: paths.add files.main
  paths.add files.dropIns
  var warned: seq[string]
  let d0 = defaultManagerConf(roots)
  for p in paths:
    var text = ""
    let bad = untrustedReason(pol, p.parentDir.parentDir, p)
    if bad.isSome:
      diags.add diag(sevError, "", p, 0, "", bad.get, "E_PERMISSION")
      continue
    try: text = readFile(p)
    except CatchableError as e:
      diags.add diag(sevWarning, "", p, 0, "", "cannot read: " & e.msg, "E_IO")
      continue
    let sr = parseSyntax(text, p, "", @["Manager"])
    diags.add sr.diags
    for s in sr.settings:
      let key = s.key
      var err = ""
      template span(fld: untyped) =
        if s.value.len == 0: c.fld = d0.fld
        else:
          var t = parseTimespan(s.value)
          if t.isSome and t.get == 0 and key.startsWith("DefaultTimeout"): t = some(Infinity)
          if t.isSome: c.fld = t.get else: err = "Failed to parse timespan '" & s.value & "'"
      case key
      of "DefaultTimeoutStartSec": span(defaultTimeoutStartUsec)
      of "DefaultTimeoutStopSec": span(defaultTimeoutStopUsec)
      of "DefaultDeviceTimeoutSec": span(defaultDeviceTimeoutUsec)
      of "DefaultRestartSec": span(defaultRestartUsec)
      of "DefaultStartLimitIntervalSec": span(defaultStartLimitIntervalUsec)
      of "DefaultTimeoutAbortSec":
        if s.value.len == 0: c.defaultTimeoutAbortUsec = UnsetInt
        else:
          let t = parseTimespan(s.value)
          if t.isSome: c.defaultTimeoutAbortUsec = t.get else: err = "Failed to parse timespan '" & s.value & "'"
      of "DefaultStartLimitBurst":
        let v = if s.value.len == 0: some(5'i64) else: parseNat(s.value, 1_000_000)
        if v.isSome: c.defaultStartLimitBurst = int(v.get) else: err = "Failed to parse integer '" & s.value & "'"
      of "DefaultEnvironment":
        if s.value.len == 0: c.defaultEnvironment.setLen 0
        else:
          var ok: bool
          for w in splitWords(s.value, ok):
            if '=' in w and w[0] != '=': c.defaultEnvironment.add w
            else: err = "Invalid environment assignment '" & w & "', ignoring"
      of "DefaultStandardOutput", "DefaultStandardError":
        var spec: StdioSpec
        if s.value.len == 0:
          let d = ManagerConf()
          if key == "DefaultStandardOutput": c.defaultStandardOutput = d.defaultStandardOutput
          else: c.defaultStandardError = d.defaultStandardError
        elif parseStdio(s.value, false, spec):
          if key == "DefaultStandardOutput": c.defaultStandardOutput = spec else: c.defaultStandardError = spec
        else: err = "Failed to parse '" & s.value & "'"
      of "DefaultOOMPolicy":
        var e: OomPolicy
        if s.value.len == 0: c.defaultOOMPolicy = opStop
        elif parseEnumStrict(s.value, e): c.defaultOOMPolicy = e
        else: err = "Failed to parse '" & s.value & "'"
      of "DefaultTasksMax":
        if s.value.len == 0: c.defaultTasksMax = d0.defaultTasksMax
        else:
          let v = resLimitOf(s.value)
          if v.isSome: c.defaultTasksMax = v.get else: err = "Failed to parse '" & s.value & "'"
      else:
        if key.startsWith("DefaultLimit") and key[12 .. ^1] in LimitResources:
          let res = key[12 .. ^1]
          if s.value.len == 0:
            var keep: seq[LimitSpec]
            for l in c.defaultLimits:
              if l.resource != res: keep.add l
            c.defaultLimits = keep
          else:
            let lv = parseLimitValue(res, s.value)
            if lv.isNone: err = "Failed to parse limit '" & s.value & "'"
            else:
              var done = false
              for l in c.defaultLimits.mitems:
                if l.resource == res: l.soft = lv.get[0]; l.hard = lv.get[1]; done = true
              if not done: c.defaultLimits.add LimitSpec(resource: res, soft: lv.get[0], hard: lv.get[1])
        elif key in AccountingKeys: discard
        elif key in IgnoredManagerKeys:
          if key notin warned:
            warned.add key
            c.ignoredKeys.add key
            diags.add diag(sevWarning, "", s.file, s.line, key, key & "= is parsed and ignored by this implementation", "W_IGNORED")
        elif key notin warned:
          warned.add key
          diags.add diag(sevWarning, "", s.file, s.line, key, "Unknown key '" & key & "' in section [Manager], ignoring")
      if err.len > 0: diags.add diag(sevWarning, "", s.file, s.line, key, err)
  c
