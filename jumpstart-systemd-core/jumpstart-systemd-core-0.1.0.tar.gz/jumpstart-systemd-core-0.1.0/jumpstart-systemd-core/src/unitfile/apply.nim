## Turning settings into the typed model (spec §2, §6.3 rules 7-8, §6.4). One
## `applySetting` call per assignment, in file order; an empty value resets the
## setting. Directive -> field mapping is by name (`fieldPairs`, case-insensitive)
## with a small table of exceptions, so the model and the directive list cannot
## drift apart.
import std/[options, tables, sets]
import std/strutils except escape, unescape
import ../common/names
import ./[model, values, execcmd, specifiers]

type
  ApplyState* = object
    ## What the finalizer needs to know about explicit assignments.
    typeSet*, timeoutStartSet*, timeoutStopSet*, timeoutAbortSet*, notifyAccessSet*: bool
    warned: HashSet[string]
  Cur = object
    key, val: string
    reset: bool
    err: string
    ex: Expander
    st: Setting

const
  RejectedKeys* = ["JoinsNamespaceOf", "OpenFile", "USBFunctionDescriptors", "USBFunctionStrings",
    "RootImage", "RootImageOptions", "RootEphemeral", "RootHash", "RootHashSignature", "RootVerity",
    "MountImages", "ExtensionImages", "ExtensionDirectories", "PrivatePIDs", "LogNamespace",
    "LoadCredentialEncrypted", "SetCredentialEncrypted", "ListenUSBFunction"]
  IgnoredKeys* = ["IgnoreOnSnapshot", "JobTimeoutRebootArgument", "RebootArgument", "SurviveFinalKillSignal",
    "BusName", "MemoryPressureWatch", "MemoryPressureThresholdSec", "PAMName", "SetLoginEnvironment",
    "UtmpIdentifier", "UtmpMode", "SELinuxContext", "AppArmorProfile", "SmackProcessLabel", "SystemCallLog",
    "RestrictFileSystems", "LogFilterPatterns", "IPAccounting", "IPAddressAllow", "IPAddressDeny",
    "IPIngressFilterPath", "IPEgressFilterPath", "BPFProgram", "SocketBindAllow", "SocketBindDeny",
    "RestrictNetworkInterfaces", "NFTSet", "ManagedOOMSwap", "ManagedOOMMemoryPressure",
    "ManagedOOMMemoryPressureLimit", "ManagedOOMPreference", "SELinuxContextFromNet", "WakeSystem"]
  DeprecatedKeys* = ["MemoryLimit", "CPUShares", "StartupCPUShares", "BlockIOWeight", "StartupBlockIOWeight",
    "BlockIODeviceWeight", "BlockIOReadBandwidth", "BlockIOWriteBandwidth", "PermissionsStartOnly",
    "SysVStartPriority", "SysVMode", "RemoveIPC_"]
  LimitResources* = ["CPU", "FSIZE", "DATA", "STACK", "CORE", "RSS", "NOFILE", "AS", "NPROC", "MEMLOCK",
                     "LOCKS", "SIGPENDING", "MSGQUEUE", "NICE", "RTPRIO", "RTTIME"]
  NoExpandKeys = ["CPUQuota", "TasksMax", "MemoryMin", "MemoryLow", "MemoryHigh", "MemoryMax",
    "MemorySwapMax", "MemoryZSwapMax", "StartupMemoryHigh", "StartupMemoryMax", "StartupMemorySwapMax",
    "StartupMemoryZSwapMax"]   ## percent-valued: a trailing `%` is not a specifier
  ZeroIsInfinity = ["TimeoutStartSec", "TimeoutStopSec", "TimeoutAbortSec", "TimeoutSec", "TimeoutIdleSec"]
  SizeKeys = ["PipeSize", "ReceiveBuffer", "SendBuffer"]
  DepKeys = [dkRequires, dkRequisite, dkWants, dkBindsTo, dkPartOf, dkUpholds, dkConflicts, dkBefore,
             dkAfter, dkOnFailure, dkOnSuccess, dkPropagatesReloadTo, dkReloadPropagatedFrom,
             dkPropagatesStopTo, dkStopPropagatedFrom]
  ServiceAliases = {"RestartSec": "restartUsec", "RestartMaxDelaySec": "restartMaxDelayUsec",
    "TimeoutStartSec": "timeoutStartUsec", "TimeoutStopSec": "timeoutStopUsec",
    "TimeoutAbortSec": "timeoutAbortUsec", "RuntimeMaxSec": "runtimeMaxUsec",
    "RuntimeRandomizedExtraSec": "runtimeRandomExtraUsec", "WatchdogSec": "watchdogUsec",
    "TimeoutStartFailureMode": "timeoutStartFailure", "TimeoutStopFailureMode": "timeoutStopFailure",
    "FileDescriptorStoreMax": "fdStoreMax", "FileDescriptorStorePreserve": "fdStorePreserve",
    "Type": "typ"}.toTable

proc sectionsOf*(kind: UnitKind): seq[string] =
  ## Section names valid for a unit type (the syntax parser's `known`).
  result = @["Unit", "Install"]
  case kind
  of ukService: result.add "Service"
  of ukSocket: result.add "Socket"
  of ukTimer: result.add "Timer"
  of ukPath: result.add "Path"
  of ukMount: result.add "Mount"
  of ukAutomount: result.add "Automount"
  of ukSwap: result.add "Swap"
  of ukSlice: result.add "Slice"
  else: discard

# ---- generic value assignment by field type ---------------------------------

proc enumFromBool[T: enum](v: var T; b: bool): bool =
  let want = if b: "yes" else: "no"
  for e in T:
    if $e == want:
      v = e
      return true

proc intOf(c: var Cur): Option[int64] =
  let k = c.key
  if k.endsWith("Mode") or k == "UMask": return parseOctal(c.val).map(proc(x: int): int64 = int64(x))
  if k.endsWith("Signal"): return parseSignal(c.val).map(proc(x: int): int64 = int64(x))
  if k.endsWith("Weight"):
    if c.val == "idle": return some(0'i64)
    if c.val == "default": return some(-1'i64)
  parseIntVal(c.val)

proc int64Of(c: var Cur): Option[int64] =
  let k = c.key
  if k.endsWith("NSec"):
    if c.val.allCharsInSet({'0'..'9'}) and c.val.len > 0: return parseIntVal(c.val)
    let t = parseTimespan(c.val)
    if t.isSome and t.get < high(int64) div 1000: return some(t.get * 1000)
    return none(int64)
  if k.endsWith("Sec"):
    let t = parseTimespan(c.val)
    if t.isSome and t.get == 0 and k in ZeroIsInfinity: return some(Infinity)
    return t
  if k in SizeKeys: return parseSize(c.val)
  parseIntVal(c.val)

proc resLimitOf*(s: string): Option[ResLimit] =
  let t = s.strip
  if t == "infinity": return some(ResLimit(set: true, infinity: true))
  let p = parsePermille(t)
  if p.isSome: return some(ResLimit(set: true, percent: true, value: p.get))
  let z = parseSize(t)
  if z.isSome: return some(ResLimit(set: true, value: z.get))

proc setValue[T](v: var T; c: var Cur): bool =
  ## Assigns `c.val` to `v` according to the type of `v`. False when the type
  ## has no generic rule (the caller then does not count the field as handled).
  result = true
  when T is bool:
    let b = parseBoolVal(c.val)
    if b.isSome: v = b.get else: c.err = "Failed to parse boolean value '" & c.val & "'"
  elif T is string:
    v = c.val
  elif T is seq[string]:
    var ok: bool
    let w = splitWords(c.val, ok)
    if ok: v.add w else: c.err = "Invalid syntax (unbalanced quotes)"
  elif T is Option[int]:
    let n = intOf(c)
    if n.isSome: v = some(int(n.get)) else: c.err = "Failed to parse integer '" & c.val & "'"
  elif T is Option[SchedPolicy]:
    var e: SchedPolicy
    if parseEnumStrict(c.val, e): v = some(e) else: c.err = "Failed to parse '" & c.val & "'"
  elif T is enum:
    var e: T
    if parseEnumStrict(c.val, e): v = e
    else:
      let b = parseBoolVal(c.val)
      if b.isSome and enumFromBool(e, b.get): v = e
      else: c.err = "Failed to parse '" & c.val & "'"
  elif T is int:
    let n = intOf(c)
    if n.isSome: v = int(n.get) else: c.err = "Failed to parse integer '" & c.val & "'"
  elif T is int64:
    let n = int64Of(c)
    if n.isSome: v = n.get
    else: c.err = (if c.key.endsWith("Sec"): "Failed to parse timespan '" else: "Failed to parse value '") & c.val & "'"
  elif T is ResLimit:
    let r = resLimitOf(c.val)
    if r.isSome: v = r.get else: c.err = "Failed to parse value '" & c.val & "'"
  else:
    result = false

proc applyGeneric[T: object](obj: var T; dflt: T; c: var Cur; fname: string): bool =
  ## Finds the field whose name equals `fname` (ignoring case), assigns or, for
  ## an empty value, resets it to `dflt`'s. True when handled.
  var idx = -1
  var i = 0
  for name, v in fieldPairs(obj):
    if idx < 0 and cmpIgnoreCase(name, fname) == 0:
      if c.reset:
        when v is seq: (v.setLen 0; idx = i; result = true)
        else:
          idx = i
          result = true
      else:
        if setValue(v, c): (idx = i; result = true)
    inc i
  if c.reset and idx >= 0:
    var d = dflt
    var j = 0
    for a, b in fields(obj, d):
      if j == idx: a = b
      inc j

# ---- exec context and resource control specials ----------------------------

proc parseStdio*(val: string; isInput: bool; spec: var StdioSpec): bool =
  var arg = ""
  var k = val
  let colon = val.find(':')
  if colon > 0 and val[0 ..< colon] in ["fd", "file", "append", "truncate"]:
    k = val[0 ..< colon]; arg = val[colon + 1 .. ^1]
  var kind: StdioKind
  if not parseEnumStrict(k, kind): return false
  if kind == sioData and not isInput: return false
  if kind in {sioJournal, sioKmsg, sioSyslog, sioJournalConsole, sioKmsgConsole, sioSyslogConsole} and isInput: return false
  if kind in {sioFile, sioAppend, sioTruncate, sioFd} and arg.len == 0: return false
  spec = StdioSpec(kind: kind, path: arg)
  true

proc parseLimitValue*(res, val: string): Option[(int64, int64)] =
  ## `LimitXXX=` value for resource `res` (`NOFILE`): `soft[:hard]`, `infinity`,
  ## sizes, plain numbers; CPU in seconds, RTTIME in microseconds.
  let parts = val.split(':')
  if parts.len > 2: return
  proc one(s: string): Option[int64] =
    if s.strip == "infinity": return some(Infinity)
    case res
    of "CPU":
      let t = parseTimespan(s)
      if t.isSome: return some(t.get div 1_000_000)
    of "RTTIME": return parseTimespan(s, 1)
    of "NICE", "RTPRIO", "NOFILE", "NPROC", "LOCKS", "SIGPENDING", "MSGQUEUE": return parseIntVal(s)
    else: return parseSize(s)
    none(int64)
  let a = one(parts[0])
  let b = if parts.len == 2: one(parts[1]) else: a
  if a.isNone or b.isNone: return
  some((a.get, b.get))

proc validStateDir(p: string): bool =
  let t = p.split(':')[0]
  t.len > 0 and t[0] != '/' and ".." notin t.split('/')

proc applyExecSpecial(x: var ExecContext; dx: ExecContext; c: var Cur; handled: var bool) =
  handled = true
  let key = c.key
  template std(fld: untyped, isIn: bool) =
    if c.reset: x.fld = dx.fld
    elif not parseStdio(c.val, isIn, x.fld): c.err = "Invalid " & key & "= value '" & c.val & "'"
  case key
  of "StandardInput": std(standardInput, true)
  of "StandardOutput": std(standardOutput, false)
  of "StandardError": std(standardError, false)
  of "StandardInputText":
    if c.reset: x.standardInputText.setLen 0 else: x.standardInputText.add cUnescape(c.val)
  of "StandardInputData":
    if c.reset: x.standardInputData.setLen 0 else: x.standardInputData.add c.val.strip
  of "PrivateUsers":
    if c.reset: x.privateUsers = false
    else:
      let b = parseBoolVal(c.val)
      if b.isSome: x.privateUsers = b.get
      elif c.val in ["self", "identity"]: x.privateUsers = true
      else: c.err = "Failed to parse boolean value '" & c.val & "'"
  of "RuntimeDirectory", "StateDirectory", "CacheDirectory", "LogsDirectory", "ConfigurationDirectory":
    var ok: bool
    let ws = splitWords(c.val, ok)
    if c.reset: handled = false          # generic reset
    else:
      for w in ws:
        if validStateDir(w):
          case key
          of "RuntimeDirectory": x.runtimeDirectory.add w
          of "StateDirectory": x.stateDirectory.add w
          of "CacheDirectory": x.cacheDirectory.add w
          of "LogsDirectory": x.logsDirectory.add w
          else: x.configurationDirectory.add w
        else: c.err = "Invalid " & key & "= entry '" & w & "' (must be relative, no '..')"
  of "Environment":
    if c.reset: x.environment.setLen 0
    else:
      var ok: bool
      for w in splitWords(c.val, ok):
        let eq = w.find('=')
        if eq > 0 and w[0] notin {'0'..'9'} and w[0 ..< eq].allCharsInSet({'A'..'Z', 'a'..'z', '0'..'9', '_'}):
          x.environment.add w
        else: c.err = "Invalid environment assignment '" & w & "', ignoring"
      if not ok: c.err = "Invalid syntax (unbalanced quotes)"
  else:
    if key.startsWith("Limit") and key[5 .. ^1] in LimitResources:
      let res = key[5 .. ^1]
      if c.reset:
        var keep: seq[LimitSpec]
        for l in x.limits:
          if l.resource != res: keep.add l
        x.limits = keep
        return
      let lv = parseLimitValue(res, c.val)
      if lv.isNone: c.err = "Failed to parse limit '" & c.val & "'"; return
      let (a, b) = lv.get
      var done = false
      for l in x.limits.mitems:
        if l.resource == res:
          l.soft = a; l.hard = b; done = true
      if not done: x.limits.add LimitSpec(resource: res, soft: a, hard: b)
    else:
      handled = false

proc deviceValues(c: var Cur; target: var seq[DeviceValue]; parseV: proc(s: string): Option[int64]) =
  if c.reset:
    target.setLen 0
    return
  var ok: bool
  let w = splitWords(c.val, ok)
  if w.len != 2 or not ok: c.err = "Invalid syntax '" & c.val & "', expected 'PATH VALUE'"; return
  let v = parseV(w[1])
  if v.isNone or not w[0].startsWith("/"): c.err = "Failed to parse '" & c.val & "'"; return
  target.add DeviceValue(path: w[0], value: v.get)

proc applyResSpecial(r: var ResourceControl; c: var Cur; handled: var bool) =
  handled = true
  case c.key
  of "CPUQuota":
    if c.reset: r.cpuQuota = UnsetInt
    else:
      let p = parsePermille(c.val)
      if p.isSome and p.get > 0: r.cpuQuota = p.get * 1000
      else: c.err = "Failed to parse CPUQuota '" & c.val & "'"
  of "Delegate":
    if c.reset: r.delegate = DelegateSpec()
    else:
      let b = parseBoolVal(c.val)
      if b.isSome: r.delegate = DelegateSpec(enabled: b.get)
      else:
        var ok: bool
        r.delegate = DelegateSpec(enabled: true, controllers: splitWords(c.val, ok))
  of "DeviceAllow":
    if c.reset: r.deviceAllow.setLen 0
    else:
      var ok: bool
      let w = splitWords(c.val, ok)
      if w.len notin 1..2 or not ok: c.err = "Invalid DeviceAllow= '" & c.val & "'"
      else: r.deviceAllow.add DeviceRule(path: w[0], access: (if w.len == 2: w[1] else: ""))
  of "IODeviceWeight": deviceValues(c, r.ioDeviceWeight, proc(s: string): Option[int64] = parseNat(s, 10000))
  of "IOReadBandwidthMax": deviceValues(c, r.ioReadBandwidthMax, proc(s: string): Option[int64] = parseSize(s))
  of "IOWriteBandwidthMax": deviceValues(c, r.ioWriteBandwidthMax, proc(s: string): Option[int64] = parseSize(s))
  of "IOReadIOPSMax": deviceValues(c, r.ioReadIOPSMax, proc(s: string): Option[int64] = parseSize(s))
  of "IOWriteIOPSMax": deviceValues(c, r.ioWriteIOPSMax, proc(s: string): Option[int64] = parseSize(s))
  of "IODeviceLatencyTargetSec": deviceValues(c, r.ioDeviceLatencyTargetSec, proc(s: string): Option[int64] = parseTimespan(s))
  else: handled = false

# ---- unit-level helpers ----------------------------------------------------

proc parseAction*(s: string; a: var UnitAction; f: var ActionFlavor): bool =
  var base = s
  f = afPlain
  if s.endsWith("-force"): base = s[0 ..< s.len - 6]; f = afForce
  elif s.endsWith("-immediate"): base = s[0 ..< s.len - 10]; f = afImmediate
  if not parseEnumStrict(base, a): return false
  a != uaNone or f == afPlain

proc parseCondition*(key, val: string; file: string; line: int; cond: var Condition): bool =
  ## `ConditionXxx=` / `AssertXxx=` with the `|` and `!` prefixes.
  var isAssert = false
  var rest = ""
  if key.startsWith("Condition"): rest = key[9 .. ^1]
  elif key.startsWith("Assert"): rest = key[6 .. ^1]; isAssert = true
  else: return false
  var k: ConditionKind
  if not parseEnumStrict(rest, k): return false
  var v = val.strip
  var trig, neg = false
  while v.len > 0 and v[0] in {'|', '!'}:
    if v[0] == '|': trig = true else: neg = true
    v = v[1 .. ^1].strip(trailing = false)
  cond = Condition(kind: k, value: v, negate: neg, trigger: trig, isAssert: isAssert, file: file, line: line)
  true

proc mangleDep*(s: string): string =
  ## Dependency names: a name without a known suffix means `.service` (§6.6).
  mangle(s)

proc execKindOf(key: string; kind: UnitKind; k: var ExecKind): bool =
  case key
  of "ExecCondition": k = ekCondition
  of "ExecStartPre": k = ekStartPre
  of "ExecStart": k = ekStart
  of "ExecStartPost": k = ekStartPost
  of "ExecReload": k = ekReload
  of "ExecStop", "ExecStopPre": k = ekStop
  of "ExecStopPost": k = ekStopPost
  else: return false
  case kind
  of ukService: key != "ExecStopPre"
  of ukSocket: key notin ["ExecCondition", "ExecReload", "ExecStop"]
  else: false

# ---- the entry point -------------------------------------------------------

proc warnOnce(ap: var ApplyState; diags: var seq[Diag]; st: Setting; unit, msg: string) =
  let id = st.key & "|" & msg
  if id in ap.warned: return
  ap.warned.incl id
  diags.add diag(sevWarning, unit, st.file, st.line, st.key, msg)

proc commandsOf(def: UnitDef): ptr array[ExecKind, seq[ExecCommand]] =
  case def.kind
  of ukService: addr def.service.commands
  of ukSocket: addr def.socket.commands
  of ukMount, ukAutomount: addr def.mount.commands
  else: nil

proc applySetting*(def: UnitDef; dflt: UnitDef; ap: var ApplyState; st: Setting; env: SpecifierEnv;
                   diags: var seq[Diag]) =
  ## Applies one assignment. `dflt` is a pristine definition of the same unit
  ## (its manager defaults) used for resets. Problems become diagnostics; a
  ## directive of status R marks the unit `bad-setting`.
  let unit = def.common.id
  let key = st.key
  let sec = st.section
  template warn(msg: string) = diags.add diag(sevWarning, unit, st.file, st.line, key, msg)
  template err(msg: string) = diags.add diag(sevError, unit, st.file, st.line, key, msg)
  var kk: ExecKind
  let isExec = execKindOf(key, def.kind, kk) and sec in ["Service", "Socket"]
  if key in RejectedKeys:
    err("Directive " & key & "= is not supported by this implementation")
    diags[^1].code = "E_UNSUPPORTED"
    def.common.loadState = lsBadSetting
    if def.common.loadError.len == 0:
      def.common.loadError = key & "= is not supported"
    return
  if key in DeprecatedKeys:
    warn("Unknown key '" & key & "' in section [" & sec & "], ignoring (deprecated)")
    return
  if key in IgnoredKeys:
    warnOnce(ap, diags, st, unit, key & "= is parsed and ignored by this implementation")
  var c = Cur(key: key, val: st.value, reset: st.value.len == 0, st: st)
  c.ex = proc(s: string): Option[string] = expandSpecifiers(env, unit, s)
  if not isExec and '%' in c.val and key notin NoExpandKeys:
    var e: string
    let x = expandSpecifiers(env, unit, c.val, e)
    if x.isNone:
      warn(e & ", ignoring assignment")
      return
    c.val = x.get
  template finish() =
    if c.err.len > 0: warn(c.err)
  template bad(msg: string) = c.err = msg
  var handled = true

  if sec == "Unit" or (sec == "Service" and key in ["StartLimitIntervalSec", "StartLimitInterval", "StartLimitBurst", "StartLimitAction"]):
    let cm = addr def.common
    var depK: DepKind
    var isDep = false
    for d in DepKeys:
      if $d == key: depK = d; isDep = true
    if isDep:
      if c.reset: cm.deps[depK].setLen 0
      else:
        var ok: bool
        for w in splitWords(c.val, ok):
          let n = mangleDep(w)
          if parseUnitName(n).isSome: cm.deps[depK].add n
          else: warn("Invalid unit name '" & w & "' in " & key & "=")
    elif key.startsWith("Condition") or key.startsWith("Assert"):
      var cond: Condition
      if not parseCondition(key, c.val, st.file, st.line, cond):
        warn("Unknown key '" & key & "' in section [" & sec & "], ignoring")
      else:
        if c.reset:
          var keep: seq[Condition]
          for x in cm.conditions:
            if not (x.kind == cond.kind and x.isAssert == cond.isAssert): keep.add x
          cm.conditions = keep
        else: cm.conditions.add cond
    else:
      case key
      of "Description": cm.description = c.val
      of "Documentation":
        if c.reset: cm.documentation.setLen 0
        else:
          var ok: bool
          cm.documentation.add splitWords(c.val, ok)
      of "SourcePath": cm.sourcePath = c.val
      of "RequiresMountsFor", "WantsMountsFor":
        var ok: bool
        let ws = splitWords(c.val, ok)
        if c.reset:
          if key == "RequiresMountsFor": cm.requiresMountsFor.setLen 0 else: cm.wantsMountsFor.setLen 0
        for w in ws:
          if w.startsWith("/"):
            if key == "RequiresMountsFor": cm.requiresMountsFor.add w else: cm.wantsMountsFor.add w
          else: warn("Path '" & w & "' in " & key & "= is not absolute, ignoring")
      of "StopWhenUnneeded", "RefuseManualStart", "RefuseManualStop", "AllowIsolate", "IgnoreOnIsolate", "DefaultDependencies":
        let b = parseBoolVal(c.val)
        let d = if c.reset: none(bool) else: b
        if not c.reset and b.isNone: bad("Failed to parse boolean value '" & c.val & "'")
        else:
          case key
          of "StopWhenUnneeded": cm.stopWhenUnneeded = d.get(dflt.common.stopWhenUnneeded)
          of "RefuseManualStart": cm.refuseManualStart = d.get(false)
          of "RefuseManualStop": cm.refuseManualStop = d.get(false)
          of "AllowIsolate": cm.allowIsolate = d.get(false)
          of "IgnoreOnIsolate": cm.ignoreOnIsolate = d.get(dflt.common.ignoreOnIsolate)
          else: cm.defaultDependencies = d.get(true)
      of "CollectMode":
        var e: CollectMode
        if c.reset: cm.collectMode = cmInactive
        elif parseEnumStrict(c.val, e): cm.collectMode = e
        else: bad("Failed to parse CollectMode= '" & c.val & "'")
        cm.collectInactiveOrFailed = cm.collectMode == cmInactiveOrFailed
      of "OnFailureJobMode", "OnSuccessJobMode":
        var e: JobMode
        if c.reset: e = (if key == "OnFailureJobMode": jmReplace else: jmFail)
        elif not parseEnumStrict(c.val, e): bad("Failed to parse job mode '" & c.val & "'"); e = jmFail
        if c.err.len == 0:
          if key == "OnFailureJobMode": cm.onFailureJobMode = e else: cm.onSuccessJobMode = e
      of "SuccessAction", "FailureAction", "StartLimitAction", "JobTimeoutAction":
        var a = uaNone
        var f = afPlain
        if not c.reset and not parseAction(c.val, a, f): bad("Failed to parse action '" & c.val & "'")
        else:
          case key
          of "SuccessAction": cm.successAction = a; cm.successActionFlavor = f
          of "FailureAction": cm.failureAction = a; cm.failureActionFlavor = f
          of "StartLimitAction": cm.startLimitAction = a; cm.startLimitActionFlavor = f
          else: cm.jobTimeoutAction = a; cm.jobTimeoutActionFlavor = f
      of "SuccessActionExitStatus", "FailureActionExitStatus":
        let v = if c.reset: some(int64(UnsetInt)) else: parseNat(c.val, 255).map(proc(x: int64): int64 = x)
        if v.isNone: bad("Failed to parse exit status '" & c.val & "'")
        elif key == "SuccessActionExitStatus": cm.successActionExitStatus = int(v.get)
        else: cm.failureActionExitStatus = int(v.get)
      of "StartLimitIntervalSec", "StartLimitInterval":
        let v = if c.reset: some(dflt.common.startLimitIntervalUsec) else: parseTimespan(c.val)
        if v.isNone: bad("Failed to parse timespan '" & c.val & "'") else: cm.startLimitIntervalUsec = v.get
      of "StartLimitBurst":
        let v = if c.reset: some(int64(dflt.common.startLimitBurst)) else: parseNat(c.val, 1_000_000)
        if v.isNone: bad("Failed to parse integer '" & c.val & "'") else: cm.startLimitBurst = int(v.get)
      of "JobTimeoutSec", "JobRunningTimeoutSec":
        var v = if c.reset: some(Infinity) else: parseTimespan(c.val)
        if v.isSome and v.get == 0: v = some(Infinity)
        if v.isNone: bad("Failed to parse timespan '" & c.val & "'")
        elif key == "JobTimeoutSec": cm.jobTimeoutUsec = v.get
        else: cm.jobRunningTimeoutUsec = v.get
      of "IgnoreOnSnapshot", "JobTimeoutRebootArgument", "RebootArgument", "SurviveFinalKillSignal": discard
      else:
        warn("Unknown key '" & key & "' in section [Unit], ignoring")
    finish()
    return

  if sec == "Install":
    var ok: bool
    template lst(fld: untyped) =
      if c.reset: def.common.install.fld.setLen 0
      else: def.common.install.fld.add splitWords(c.val, ok)
    def.common.install.present = true
    case key
    of "WantedBy": lst(wantedBy)
    of "RequiredBy": lst(requiredBy)
    of "UpheldBy": lst(upheldBy)
    of "Alias": lst(alias)
    of "Also": lst(also)
    of "DefaultInstance": def.common.install.defaultInstance = c.val
    else: warn("Unknown key '" & key & "' in section [Install], ignoring")
    return

  # type-specific sections
  var dlt = dflt
  template tryAll(body: untyped) =
    handled = false
    body
  if isExec:
    var errs: seq[string]
    let cmds = parseExecLine(st.value, errs, c.ex, st.file, st.line)
    let arr = commandsOf(def)
    if st.value.len == 0: arr[][kk].setLen 0
    for m in errs: diags.add diag(sevError, unit, st.file, st.line, key, m)
    for cmd in cmds: arr[][kk].add cmd
    return
  case def.kind
  of ukService:
    if sec != "Service": return
    let f = ServiceAliases.getOrDefault(key, key)
    case key
    of "SuccessExitStatus", "RestartPreventExitStatus", "RestartForceExitStatus":
      template es(fld: untyped) =
        if c.reset: def.service.fld = ExitSet()
        elif not parseExitSet(c.val, def.service.fld): bad("Failed to parse exit status set '" & c.val & "'")
      case key
      of "SuccessExitStatus": es(successExit)
      of "RestartPreventExitStatus": es(restartPreventExit)
      else: es(restartForceExit)
    of "TimeoutSec":
      for k2 in ["TimeoutStartSec", "TimeoutStopSec"]:
        var c2 = c
        c2.key = k2
        discard applyGeneric(def.service, dflt.service, c2, ServiceAliases[k2])
        if c2.err.len > 0: c.err = c2.err
      ap.timeoutStartSet = not c.reset
      ap.timeoutStopSet = not c.reset
    else:
      handled = applyGeneric(def.service, dflt.service, c, f)
      if handled:
        case key
        of "Type": ap.typeSet = not c.reset
        of "TimeoutStartSec": ap.timeoutStartSet = not c.reset
        of "TimeoutStopSec": ap.timeoutStopSet = not c.reset
        of "TimeoutAbortSec": ap.timeoutAbortSet = not c.reset
        of "NotifyAccess": ap.notifyAccessSet = not c.reset
        else: discard
      else:
        handled = applyGeneric(def.service.kill, dflt.service.kill, c, key)
        if not handled: applyExecSpecial(def.service.exec, dflt.service.exec, c, handled)
        if not handled: handled = applyGeneric(def.service.exec, dlt.service.exec, c, key)
        if not handled: applyResSpecial(def.service.res, c, handled)
        if not handled: handled = applyGeneric(def.service.res, dlt.service.res, c, key)
        if not handled and key in IgnoredKeys: handled = true
        if not handled: warn("Unknown key '" & key & "' in section [Service], ignoring")
  of ukSocket:
    if sec != "Socket": return
    var lk: ListenKind
    if parseEnumStrict(key, lk):
      if c.reset: def.socket.listen.setLen 0
      else: def.socket.listen.add ListenSpec(kind: lk, address: c.val)
    elif key == "TimeoutSec":
      handled = applyGeneric(def.socket, dflt.socket, c, "timeoutSec")
    else:
      handled = applyGeneric(def.socket, dflt.socket, c, key)
      if not handled: handled = applyGeneric(def.socket.kill, dflt.socket.kill, c, key)
      if not handled: applyExecSpecial(def.socket.exec, dflt.socket.exec, c, handled)
      if not handled: handled = applyGeneric(def.socket.exec, dlt.socket.exec, c, key)
      if not handled: applyResSpecial(def.socket.res, c, handled)
      if not handled: handled = applyGeneric(def.socket.res, dlt.socket.res, c, key)
      if not handled and key in IgnoredKeys: handled = true
      if not handled: warn("Unknown key '" & key & "' in section [Socket], ignoring")
  of ukTimer:
    if sec != "Timer": return
    var tb: TimerBase
    if parseEnumStrict(key, tb):
      if c.reset: def.timer.values.setLen 0
      else:
        case tb
        of tbCalendar: def.timer.values.add TimerValue(base: tb, calendar: c.val, raw: c.val)
        of tbClockChange, tbTimezoneChange:
          let b = parseBoolVal(c.val)
          if b.isNone: bad("Failed to parse boolean value '" & c.val & "'")
          elif b.get: def.timer.values.add TimerValue(base: tb, raw: c.val)
        else:
          let t = parseTimespan(c.val)
          if t.isNone: bad("Failed to parse timespan '" & c.val & "'")
          else: def.timer.values.add TimerValue(base: tb, usec: t.get, raw: c.val)
    else:
      handled = applyGeneric(def.timer, dflt.timer, c, key)
      if not handled and key in IgnoredKeys: handled = true
      if not handled: warn("Unknown key '" & key & "' in section [Timer], ignoring")
  of ukPath:
    if sec != "Path": return
    var pk: PathKind
    if parseEnumStrict(key, pk):
      if c.reset: def.path.paths.setLen 0
      elif not c.val.startsWith("/"): bad("Path '" & c.val & "' is not absolute, ignoring")
      else: def.path.paths.add PathSpec(kind: pk, path: c.val)
    else:
      handled = applyGeneric(def.path, dflt.path, c, key)
      if not handled: warn("Unknown key '" & key & "' in section [Path], ignoring")
  of ukMount, ukAutomount:
    if sec notin ["Mount", "Automount"]: return
    let f = if key == "Type": "typ" else: key
    handled = applyGeneric(def.mount, dflt.mount, c, f)
    if not handled: handled = applyGeneric(def.mount.kill, dflt.mount.kill, c, key)
    if not handled: applyExecSpecial(def.mount.exec, dflt.mount.exec, c, handled)
    if not handled: handled = applyGeneric(def.mount.exec, dlt.mount.exec, c, key)
    if not handled: applyResSpecial(def.mount.res, c, handled)
    if not handled: handled = applyGeneric(def.mount.res, dlt.mount.res, c, key)
    if not handled and key in IgnoredKeys: handled = true
    if not handled: warn("Unknown key '" & key & "' in section [" & sec & "], ignoring")
  of ukSwap:
    if sec != "Swap": return
    handled = applyGeneric(def.swap, dflt.swap, c, key)
    if not handled: handled = applyGeneric(def.swap.kill, dflt.swap.kill, c, key)
    if not handled: applyExecSpecial(def.swap.exec, dflt.swap.exec, c, handled)
    if not handled: handled = applyGeneric(def.swap.exec, dlt.swap.exec, c, key)
    if not handled: applyResSpecial(def.swap.res, c, handled)
    if not handled: handled = applyGeneric(def.swap.res, dlt.swap.res, c, key)
    if not handled and key in IgnoredKeys: handled = true
    if not handled: warn("Unknown key '" & key & "' in section [Swap], ignoring")
  of ukSlice:
    if sec != "Slice": return
    applyResSpecial(def.slice.res, c, handled)
    if not handled: handled = applyGeneric(def.slice.res, dlt.slice.res, c, key)
    if not handled and key in IgnoredKeys: handled = true
    if not handled: warn("Unknown key '" & key & "' in section [Slice], ignoring")
  else: discard
  finish()
