## Implicit dependencies (spec §7.2), computed at load time into
## `UnitCommon.implicitDeps` and `implicitMountsFor`.
import std/sequtils
import std/[os, options]
import std/strutils except escape, unescape
import ../common/[names, roots]
import ./model

const NetworkFsTypes = ["nfs", "nfs4", "cifs", "smb3", "smbfs", "ncpfs", "9p", "ceph", "glusterfs", "fuse.sshfs", "afs"]

proc isNetworkMount*(typ, options: string): bool =
  typ in NetworkFsTypes or "_netdev" in options.split(',')

proc stripDash(p: string): string =
  ## Paths with a leading `-` ignore the prefix; `~` paths imply nothing.
  if p.startsWith("-"): p[1 .. ^1] else: p

proc addMount(c: var UnitCommon; p: string) =
  let q = stripDash(p)
  if q.startsWith("/") and q notin c.implicitMountsFor: c.implicitMountsFor.add q

proc addImp(c: var UnitCommon; k: DepKind; n: string) =
  if n notin c.implicitDeps[k]: c.implicitDeps[k].add n

proc stateDirPaths(roots: Roots; dirs: seq[string]; base: string): seq[string] =
  for d in dirs:
    let n = d.split(':')[0]
    result.add base & "/" & n

proc journalLike(k: StdioKind): bool =
  k in {sioJournal, sioSyslog, sioKmsg, sioJournalConsole, sioSyslogConsole, sioKmsgConsole}

proc fillImplicit*(def: UnitDef; roots: Roots; hasDefaultDeps: proc(name: string): bool;
                   udevRunning: bool) =
  ## Adds the dependencies of §7.2 to `def.common`. `hasDefaultDeps` answers
  ## whether a named unit has `DefaultDependencies=yes` (for targets).
  let sys = roots.scope == scSystem
  var cm = addr def.common
  let dd = cm.defaultDependencies
  template imp(k: DepKind; n: string) = addImp(cm[], k, n)
  template shutdownPair() =
    imp(dkBefore, "shutdown.target")
    imp(dkConflicts, "shutdown.target")
  template sysinit() =
    if sys:
      imp(dkRequires, "sysinit.target")
      imp(dkAfter, "sysinit.target")
  let id = cm.id
  let pn = parseUnitName(id)
  let prefix = if pn.isSome: pn.get.prefix else: id
  # settings that add dependencies
  var ex: ptr ExecContext = execContextOf(def)
  if ex != nil:
    addMount(cm[], ex.workingDirectory)
    addMount(cm[], ex.rootDirectory)
    for p in ex.readWritePaths & ex.readOnlyPaths & ex.inaccessiblePaths:
      addMount(cm[], p.strip(chars = {'-', '+'}, trailing = false))
    for p in ex.bindPaths & ex.bindReadOnlyPaths:
      let src = p.split(':')[0]
      addMount(cm[], src.strip(chars = {'-'}, trailing = false))
    let ur = if sys: roots.run else: roots.runtime
    let logRoot = roots.logsRoot
    for p in stateDirPaths(roots, ex.runtimeDirectory, ur): addMount(cm[], p)
    for p in stateDirPaths(roots, ex.stateDirectory, roots.varLib): addMount(cm[], p)
    for p in stateDirPaths(roots, ex.cacheDirectory, roots.varCache): addMount(cm[], p)
    for p in stateDirPaths(roots, ex.logsDirectory, logRoot): addMount(cm[], p)
    for p in stateDirPaths(roots, ex.configurationDirectory, roots.etc): addMount(cm[], p)
    if ex.privateTmp:
      addMount(cm[], "/tmp"); addMount(cm[], "/var/tmp")
    # a socket unit without commands never runs a process: no journal needed
    # (and the journal's own sockets must not wait for themselves)
    let runsProcesses = def.kind != ukSocket or
      def.socket.commands.anyIt(it.len > 0)
    if runsProcesses and (journalLike(ex.standardOutput.kind) or journalLike(ex.standardError.kind)):
      imp(dkRequires, "systemd-journald.socket")
      imp(dkAfter, "systemd-journald.socket")
  if def.kind == ukService:
    addMount(cm[], def.service.pidFile)
    for k in ExecKind:
      for c in def.service.commands[k]:
        if c.path.startsWith("/"): addMount(cm[], c.path)
    for s in def.service.sockets: imp(dkAfter, mangle(s, ukSocket))
  if cm.slice.len > 0 and cm.slice != "-.slice" and def.kind in {ukService, ukSocket, ukMount, ukSwap}:
    imp(dkRequires, cm.slice)
    imp(dkAfter, cm.slice)
  # per type
  case def.kind
  of ukService:
    if dd:
      sysinit()
      imp(dkAfter, "basic.target")
      shutdownPair()
  of ukSocket:
    if dd:
      imp(dkBefore, "sockets.target")
      sysinit()
      shutdownPair()
    if not def.socket.accept:
      let svc = if def.socket.service.len > 0: def.socket.service else: prefix & ".service"
      imp(dkBefore, svc)
      imp(dkTriggers, svc)
    for l in def.socket.listen:
      if l.kind in {lkStream, lkDatagram, lkSequentialPacket, lkFifo, lkSpecial} and l.address.startsWith("/"):
        addMount(cm[], l.address.parentDir)
    if def.socket.bindToDevice.len > 0:
      let dev = escapePath("/sys/subsystem/net/devices/" & def.socket.bindToDevice) & ".device"
      imp(dkBindsTo, dev); imp(dkAfter, dev)
  of ukTimer:
    if dd:
      imp(dkBefore, "timers.target")
      sysinit()
      shutdownPair()
      if sys:
        for v in def.timer.values:
          if v.base == tbCalendar:
            imp(dkAfter, "time-set.target"); imp(dkAfter, "time-sync.target"); break
    let u = if def.timer.unit.len > 0: def.timer.unit else: prefix & ".service"
    imp(dkBefore, u); imp(dkTriggers, u)
  of ukPath:
    if dd:
      imp(dkBefore, "paths.target")
      sysinit()
      shutdownPair()
    let u = if def.path.unit.len > 0: def.path.unit else: prefix & ".service"
    imp(dkBefore, u); imp(dkTriggers, u)
    for p in def.path.paths: addMount(cm[], p.path)
  of ukMount:
    let where = def.mount.where
    if where.len > 0 and where != "/":
      addMount(cm[], where.parentDir)
    if dd and cm.source != usMountinfo and where != "/":
      if isNetworkMount(def.mount.typ, def.mount.options):
        imp(dkBefore, "remote-fs.target")
        imp(dkAfter, "network.target"); imp(dkAfter, "network-online.target")
        imp(dkWants, "network-online.target")
      else:
        imp(dkBefore, "local-fs.target")
        imp(dkAfter, "local-fs-pre.target")
      imp(dkBefore, "umount.target")
      imp(dkConflicts, "umount.target")
    let w = def.mount.what
    if udevRunning and w.startsWith("/dev/"):
      let dev = escapePath(w) & ".device"
      imp(dkBindsTo, dev); imp(dkAfter, dev)
  of ukAutomount:
    let where = def.mount.where
    if where.len > 0 and where != "/": addMount(cm[], where.parentDir)
    imp(dkBefore, prefix & ".mount"); imp(dkTriggers, prefix & ".mount")
    if dd:
      imp(dkBefore, "umount.target")
      imp(dkConflicts, "umount.target")
  of ukSwap:
    if dd:
      imp(dkBefore, "swap.target")
      imp(dkBefore, "umount.target")
      imp(dkConflicts, "umount.target")
    let w = def.swap.what
    if udevRunning and w.startsWith("/dev/"):
      let dev = escapePath(w) & ".device"
      imp(dkBindsTo, dev); imp(dkAfter, dev)
  of ukTarget:
    if dd and sys: shutdownPair()
    if dd:
      for k in [dkWants, dkRequires, dkRequisite, dkBindsTo, dkUpholds]:
        for n in cm.deps[k]:
          if hasDefaultDeps != nil and hasDefaultDeps(n): imp(dkAfter, n)
  of ukSlice:
    if id != "-.slice":
      if dd: shutdownPair()
      let parents = sliceParents(id)
      let parent = if parents.len > 0: parents[^1] else: "-.slice"
      imp(dkRequires, parent); imp(dkAfter, parent)
  else: discard
