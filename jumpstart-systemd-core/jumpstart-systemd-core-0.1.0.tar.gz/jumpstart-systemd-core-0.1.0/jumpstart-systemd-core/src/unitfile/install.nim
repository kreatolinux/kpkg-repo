## Offline-capable enablement (spec §6.9, §6.10): `enable`, `disable`, `mask`,
## `link`, `revert`, `add-wants`, `set-default`, `preset`, ... as plain file
## operations whose on-disk result is exactly systemd's. A `Roots` whose paths
## point below a directory plays `--root=`: link locations are real paths, link
## targets are the paths as seen from inside that root (prefix stripped).
import std/[os, options, sets, tables, algorithm, posix]
import std/strutils except escape, unescape
import ../common/[names, roots]
import ./[model, paths, trust, specifiers, index, values, presets]

type Ctx = object
  roots: Roots
  idx: UnitIndex
  opts: FileOpOptions
  res: FileOpResult
  env: SpecifierEnv
  base: string
  seen: HashSet[string]

proc stripRoot(c: Ctx; p: string): string =
  ## The path as seen from inside the (fake) root.
  if c.base != "/" and p.startsWith(c.base & "/"): p[c.base.len .. ^1] else: p

proc underRoot(c: Ctx; p: string): string =
  if c.base != "/" and p.startsWith("/") and not p.startsWith(c.base & "/"): c.base & p else: p

proc fail(c: var Ctx; msg: string; unit = "") =
  c.res.ok = false
  if c.res.error.len == 0: c.res.error = msg
  c.res.diags.add diag(sevError, unit, "", 0, "", msg, "E_INSTALL")

proc warn(c: var Ctx; msg: string; unit = ""; code = "") =
  c.res.diags.add diag(sevWarning, unit, "", 0, "", msg, code)

proc mkdirs(c: var Ctx; dir: string) =
  ## `mkdir -p` with mode 0755, recording each directory created.
  if dir.len == 0 or dirExists(dir): return
  mkdirs(c, dir.parentDir)
  createDir dir
  setFilePermissions(dir, {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec, fpOthersRead, fpOthersExec})
  c.res.changes.add FileChange(kind: fcMkdir, link: dir)

proc isLink(p: string): bool = symlinkExists(p)

proc makeLink(c: var Ctx; link, target: string; force: bool; unit = ""): bool =
  ## Creates `link -> target`. An identical link is left alone; a different
  ## link (or file) is an error unless `force`.
  if isLink(link) or fileExists(link) or dirExists(link):
    if isLink(link):
      let cur = expandSymlink(link)
      if cur == target or normalizedPath(cur) == normalizedPath(target): return true
      if not force:
        c.fail("File '" & link & "' already exists and is a symlink to '" & cur & "'.", unit)
        return false
    elif dirExists(link):
      c.fail("File '" & link & "' already exists and is a directory.", unit)
      return false
    elif not force:
      c.fail("File '" & link & "' already exists.", unit)
      return false
    removeFile(link)
  else:
    mkdirs(c, link.parentDir)
  createSymlink(target, link)
  c.res.changes.add FileChange(kind: fcSymlink, link: link, target: target)
  true

proc configDirOf(c: Ctx): string = configDir(c.roots, c.opts.runtime, c.opts.global)

proc fragmentAsFound(c: Ctx; r: Resolved): string =
  ## The fragment path links point at ("as found in the search path"; the
  ## template's file for instances).
  let ename = if r.isTemplateInstance: templateOf(r.queried) else: r.id
  var lp = false
  let canon = followAlias(c.idx, ename, lp)
  if canon notin c.idx.entries: return ""
  let e = c.idx.entries[canon]
  if e.kind == ekLinked: e.path else: e.fragment

proc installOf(c: Ctx; r: Resolved): InstallSection =
  ## `[Install]` of main file and drop-ins, specifiers expanded for `r.id`.
  let uf = readUnitFiles(c.idx, r, fragmentFor(c.idx, r), r.kind)
  for s in uf.settings:
    if s.section != "Install": continue
    result.present = true
    var v = s.value
    if '%' in v:
      let x = expandSpecifiers(c.env, r.id, v)
      if x.isNone: continue
      v = x.get
    var ok: bool
    let ws = splitWords(v, ok)
    template lst(f: untyped) =
      if v.len == 0: result.f.setLen 0 else: result.f.add ws
    case s.key
    of "WantedBy": lst(wantedBy)
    of "RequiredBy": lst(requiredBy)
    of "UpheldBy": lst(upheldBy)
    of "Alias": lst(alias)
    of "Also": lst(also)
    of "DefaultInstance": result.defaultInstance = v

proc hasKeys(i: InstallSection): bool =
  i.wantedBy.len + i.requiredBy.len + i.upheldBy.len + i.alias.len + i.also.len > 0 or i.defaultInstance.len > 0

proc resolveForInstall(c: var Ctx; qname: string; r: var Resolved): bool =
  ## Resolves a (mangled) name for enabling, applying `DefaultInstance=` to
  ## templates. False (with an error recorded) when impossible.
  var name = qname
  let pn = parseUnitName(name)
  if pn.isNone:
    c.fail("Invalid unit name '" & qname & "'.", qname)
    return false
  var rr = resolveName(c.idx, name)
  if rr.isNone:
    c.fail("Unit file " & name & " does not exist.", name)
    return false
  if rr.get.masked:
    c.fail("Unit file " & name & " is masked.", name)
    return false
  if pn.get.isTemplate:
    let inst = installOf(c, rr.get).defaultInstance
    if inst.len == 0:
      c.fail("Template unit instance name missing for " & name & ".", name)
      return false
    name = instantiate(name, inst)
    rr = resolveName(c.idx, name)
    if rr.isNone: c.fail("Unit file " & name & " does not exist.", name); return false
  r = rr.get
  true

proc enableOne(c: var Ctx; qname: string; top: bool)

proc linkUnit(c: var Ctx; linkDir, linkName: string; r: Resolved; frag: string): bool =
  makeLink(c, linkDir / linkName, c.stripRoot(frag), c.opts.force, r.id)

proc enableResolved(c: var Ctx; r: Resolved; top: bool; fragOverride = "") =
  if r.id in c.seen: return
  c.seen.incl r.id
  let frag = if fragOverride.len > 0: underRoot(c, fragOverride) else: fragmentAsFound(c, r)
  if frag.len == 0:
    c.fail("Unit " & r.id & " is transient or generated.", r.id)
    return
  let info = installOf(c, r)
  if not info.hasKeys and top:
    c.warn("The unit files have no installation config (WantedBy=, RequiredBy=, UpheldBy=, Also=, or Alias= settings in the [Install] section, and DefaultInstance= for template units).", r.id, "W_NO_INSTALL")
  let cfg = configDirOf(c)
  let suffix = parseUnitName(r.id).get.suffix
  for a in info.alias:
    let pa = parseUnitName(a)
    if pa.isNone or pa.get.suffix != suffix:
      c.warn("Alias '" & a & "' is not a valid name of the same type, ignoring.", r.id)
      continue
    if a == r.id: continue
    discard linkUnit(c, cfg, a, r, frag)
  for (lst, ext) in [(info.wantedBy, ".wants"), (info.requiredBy, ".requires"), (info.upheldBy, ".upholds")]:
    for t in lst:
      if parseUnitName(t).isNone:
        c.warn("'" & t & "' in [Install] is not a valid unit name, ignoring.", r.id)
        continue
      discard linkUnit(c, cfg / (t & ext), r.id, r, frag)
  for a in info.also: enableOne(c, a, false)

proc enableOne(c: var Ctx; qname: string; top: bool) =
  if qname.startsWith("/"):
    # a unit file by path: link it into the configuration directory, then enable it
    let p = underRoot(c, qname)
    let bn = qname.extractFilename
    if parseUnitName(bn).isNone or not fileExists(p):
      c.fail("Unit file " & qname & " does not exist.", bn)
      return
    discard makeLink(c, configDirOf(c) / bn, c.stripRoot(qname), c.opts.force, bn)
    var d: seq[Diag]
    c.idx = buildIndex(c.roots, @[], d, permissive())
  var r: Resolved
  let name = if qname.startsWith("/"): qname.extractFilename else: mangle(qname)
  if not resolveForInstall(c, name, r): return
  enableResolved(c, r, top, if qname.startsWith("/"): qname else: "")

# ---- disable ---------------------------------------------------------------

proc sameFileUnder(c: Ctx; dest, frag: string): bool =
  for d in [dest, underRoot(c, dest)]:
    for f in [frag, underRoot(c, frag)]:
      if d == f: return true
      try:
        if fileExists(d) and fileExists(f) and sameFile(d, f): return true
      except OSError: discard

proc destOf(link: string): string =
  try: expandSymlink(link) except OSError: ""

proc markUnit(c: var Ctx; qname: string; marked: var Table[string, string]; visited: var HashSet[string]) =
  let name = mangle(qname)
  if name in visited: return
  visited.incl name
  marked[name] = ""
  let rr = resolveName(c.idx, name)
  if rr.isNone: return
  let r = rr.get
  for n in r.names: marked[n] = ""
  marked[r.id] = fragmentAsFound(c, r)
  if r.masked: return
  for a in installOf(c, r).also: markUnit(c, a, marked, visited)

proc doomed(c: Ctx; marked: Table[string, string]; link: string): bool =
  let name = link.extractFilename
  let dest = destOf(link)
  if dest.len == 0: return false
  let bn = dest.extractFilename
  if bn in marked and parseUnitName(bn).isSome and name != "default.target": return true
  if name in marked:
    if not fileExists(underRoot(c, dest)) and not fileExists(dest): return true
    if marked[name].len > 0 and sameFileUnder(c, dest, marked[name]): return true

proc removeMarked(c: var Ctx; dir: string; marked: Table[string, string]) =
  ## Walks one configuration directory (top-level links and `*.wants` etc.).
  if not dirExists(dir): return
  var entries: seq[(PathComponent, string)]
  for k, p in walkDir(dir): entries.add (k, p)
  entries.sort(proc(a, b: (PathComponent, string)): int = cmp(a[1], b[1]))
  for (k, p) in entries:
    let fn = p.extractFilename
    if k in {pcLinkToFile, pcLinkToDir}:
      if parseUnitName(fn).isSome and doomed(c, marked, p):
        removeFile p
        c.res.changes.add FileChange(kind: fcUnlink, link: p, target: destOf(p))
    elif k == pcDir and (fn.endsWith(".wants") or fn.endsWith(".requires") or fn.endsWith(".upholds")):
      var inner: seq[string]
      for k2, p2 in walkDir(p): inner.add p2
      inner.sort()
      for p2 in inner:
        if isLink(p2) and parseUnitName(p2.extractFilename).isSome and doomed(c, marked, p2):
          let t = destOf(p2)
          removeFile p2
          c.res.changes.add FileChange(kind: fcUnlink, link: p2, target: t)
      var left = false
      for k2, p2 in walkDir(p): left = true
      if not left:
        removeDir p
        c.res.changes.add FileChange(kind: fcRmdir, link: p)

proc disableNames(c: var Ctx; names: seq[string]) =
  var marked = initTable[string, string]()
  var visited = initHashSet[string]()
  var known = false
  for n in names:
    markUnit(c, n, marked, visited)
    let rr = resolveName(c.idx, mangle(n))
    if rr.isSome and not rr.get.masked: known = true
  let before = c.res.changes.len
  for (d, rt) in enablementDirs(c.roots, c.opts.global):
    removeMarked(c, d, marked)
  if c.res.changes.len == before and not known:
    for n in names: c.fail("Unit file " & mangle(n) & " does not exist.", mangle(n))
    return
  var d: seq[Diag]
  c.idx = buildIndex(c.roots, @[], d, permissive())
  for n in names:
    let st = enablementOf(c.idx, mangle(n))
    if st in {esEnabled, esEnabledRuntime}:
      c.warn("Unit " & mangle(n) & " is enabled by a vendor link; use mask to prevent it from starting.", mangle(n), "W_VENDOR_LINK")

# ---- mask, link, revert, ... ------------------------------------------------

proc maskNames(c: var Ctx; names: seq[string]) =
  for n in names:
    let name = mangle(n)
    if parseUnitName(name).isNone:
      c.fail("Invalid unit name '" & n & "'.", name)
      continue
    discard makeLink(c, configDirOf(c) / name, "/dev/null", c.opts.force, name)

proc unmaskNames(c: var Ctx; names: seq[string]) =
  for n in names:
    let name = mangle(n)
    for (d, rt) in enablementDirs(c.roots, c.opts.global)[0 .. 1]:
      let p = d / name
      if isLink(p) and destOf(p) == "/dev/null":
        removeFile p
        c.res.changes.add FileChange(kind: fcUnlink, link: p, target: "/dev/null")

proc linkPaths(c: var Ctx; names: seq[string]) =
  for n in names:
    if not n.startsWith("/"):
      c.fail("Link path must be absolute: " & n, n)
      continue
    let bn = n.extractFilename
    if parseUnitName(bn).isNone or not fileExists(underRoot(c, n)):
      c.fail("Unit file " & n & " does not exist or is not a unit file.", bn)
      continue
    discard makeLink(c, configDirOf(c) / bn, c.stripRoot(n), c.opts.force, bn)

proc revertNames(c: var Ctx; names: seq[string]) =
  for n in names:
    let name = mangle(n)
    let ctl = controlDirs(c.roots)
    var vendor = false
    for i, d in c.idx.dirs:
      if isVendorRole(d.role) and (fileExists(d.path / name) or symlinkExists(d.path / name)): vendor = true
    for dir in [configDir(c.roots, false, c.opts.global), configDir(c.roots, true, c.opts.global)]:
      let f = dir / name
      if isLink(f) and destOf(f) == "/dev/null":
        removeFile f
        c.res.changes.add FileChange(kind: fcUnlink, link: f, target: "/dev/null")
      elif fileExists(f) and vendor:
        removeFile f
        c.res.changes.add FileChange(kind: fcUnlink, link: f)
      elif fileExists(f):
        c.warn("Unit " & name & " has no vendor version; keeping " & f, name)
    for dir in [configDir(c.roots, false, c.opts.global), configDir(c.roots, true, c.opts.global), ctl.persistent, ctl.runtime]:
      for dn in [name & ".d"]:
        if dirExists(dir / dn):
          removeDir(dir / dn)
          c.res.changes.add FileChange(kind: fcRmdir, link: dir / dn)

proc addDeps(c: var Ctx; ext: string; names: seq[string]) =
  let t = mangle(c.opts.target, ukTarget)
  if parseUnitName(t).isNone:
    c.fail("Invalid unit name '" & c.opts.target & "'.", t)
    return
  for n in names:
    var r: Resolved
    let name = mangle(n)
    if not resolveForInstall(c, name, r): continue
    let frag = fragmentAsFound(c, r)
    if frag.len == 0: c.fail("Unit " & r.id & " is transient or generated.", r.id); continue
    discard linkUnit(c, configDirOf(c) / (t & ext), r.id, r, frag)

proc setDefault(c: var Ctx; names: seq[string]) =
  let t = mangle(if names.len > 0: names[0] else: c.opts.target, ukTarget)
  let rr = resolveName(c.idx, t)
  if rr.isNone or rr.get.generated and fragmentFor(c.idx, rr.get).len == 0:
    c.fail("Unit file " & t & " does not exist.", t)
    return
  if rr.get.masked:
    c.fail("Unit file " & t & " is masked.", t)
    return
  let frag = fragmentAsFound(c, rr.get)
  if frag.len == 0: c.fail("Unit " & t & " has no unit file.", t); return
  discard makeLink(c, configDirOf(c) / "default.target", c.stripRoot(frag), true, t)

# ---- presets ---------------------------------------------------------------

proc applyPreset(c: var Ctx; rules: seq[PresetRule]; name: string) =
  let act = presetAction(rules, name)
  case act
  of paIgnore: discard
  of paEnable:
    if c.opts.presetMode != pmDisableOnly: enableOne(c, name, true)
  of paDisable:
    if c.opts.presetMode != pmEnableOnly: disableNames(c, @[name])

proc presetAll(c: var Ctx) =
  let rules = loadPresets(c.roots, permissive())
  for e in listNames(c.idx):
    if e.isAlias or e.state in {esStatic, esAlias, esMasked, esMaskedRuntime, esGenerated, esTransient, esBad, esNotFound}: continue
    if parseUnitName(e.name).get.isTemplate: continue
    applyPreset(c, rules, e.name)

proc fileOp*(roots: Roots; op: FileOp; names: seq[string]; opts: FileOpOptions): FileOpResult =
  ## Runs one enablement operation. `names` are unit names as typed (mangled
  ## here) or, for `link`/`enable`, absolute unit file paths. The result lists
  ## every filesystem change in order; `ok` is false when something failed
  ## (the other names are still processed, as `systemctl` does).
  var d: seq[Diag]
  var c = Ctx(roots: roots, opts: opts, res: FileOpResult(ok: true), base: rootBase(roots),
              env: newSpecifierEnv(roots), seen: initHashSet[string]())
  c.idx = buildIndex(roots, @[], d, permissive())
  case op
  of foEnable:
    for n in names: enableOne(c, n, true)
  of foDisable: disableNames(c, names)
  of foReenable:
    disableNames(c, names)
    c.seen.clear()
    var d2: seq[Diag]
    c.idx = buildIndex(roots, @[], d2, permissive())
    for n in names: enableOne(c, n, true)
  of foMask: maskNames(c, names)
  of foUnmask: unmaskNames(c, names)
  of foLink: linkPaths(c, names)
  of foRevert: revertNames(c, names)
  of foAddWants: addDeps(c, ".wants", names)
  of foAddRequires: addDeps(c, ".requires", names)
  of foSetDefault: setDefault(c, names)
  of foPreset:
    let rules = loadPresets(roots, permissive())
    for n in names: applyPreset(c, rules, mangle(n))
  of foPresetAll: presetAll(c)
  of foIsEnabled:
    for n in names: c.res.states.add (mangle(n), enablementOf(c.idx, mangle(n)))
  c.res
