## Unit file syntax (spec §6.3, systemd.syntax(7)): bytes in, a flat list of
## settings plus diagnostics out. Pure; interpretation of values is `values.nim`.
import std/[strutils, unicode]
import ./model

const
  MaxFileBytes* = 1 shl 20
  MaxFileLines* = 8192
  MaxDropIns* = 1024

type SyntaxResult* = object
  settings*: seq[Setting]     ## in file order; X- keys and unknown-section keys removed
  sections*: seq[string]      ## section names seen, in order (with repeats)
  diags*: seq[Diag]
  fatal*: bool                ## not UTF-8 or too big: nothing was parsed

proc validKey(k: string): bool =
  if k.len == 0: return false
  for c in k:
    if c notin {'A'..'Z', 'a'..'z', '0'..'9', '_'}: return false
  true

proc parseSyntax*(text, file: string; unit = ""; known: seq[string] = @[]): SyntaxResult =
  ## `known` lists the section names valid for the unit type; when empty every
  ## section is accepted. Unknown sections and their keys are skipped with one
  ## warning per section occurrence; `X-` sections silently.
  var res = SyntaxResult()
  template warn(ln: int; k, m: string) = res.diags.add diag(sevWarning, unit, file, ln, k, m)
  template fatal(m: string) =
    res.fatal = true
    res.diags.add diag(sevError, unit, file, 0, "", m, "E_LOAD")
    return res
  if text.len > MaxFileBytes: fatal "file is larger than 1 MiB"
  if validateUtf8(text) >= 0: fatal "file is not valid UTF-8"
  let lines = text.split('\n')
  if lines.len > MaxFileLines + 1: fatal "file has more than 8192 lines"
  var section = ""
  var inSection, skipSection = false
  proc handle(line: string; ln: int) =
    if line.len == 0 or line[0] in {'#', ';'}: return
    if line[0] == '[':
      let e = line.find(']')
      if e < 0:
        warn ln, "", "Invalid section header '" & line & "'"
        return
      if e != line.high:
        warn ln, "", "Trailing garbage after section header, ignoring line"
        return
      section = line[1 ..< e]
      inSection = true
      res.sections.add section
      skipSection = section.startsWith("X-")
      if not skipSection and known.len > 0 and section notin known:
        skipSection = true
        warn ln, "", "Unknown section '" & section & "'. Ignoring."
      return
    let eq = line.find('=')
    if eq < 0:
      warn ln, "", "Missing '=', ignoring line."
      return
    let key = line[0 ..< eq].strip(chars = {' ', '\t'})
    let val = line[eq + 1 .. ^1].strip(chars = {' ', '\t'})
    if not inSection:
      warn ln, key, "Assignment outside of section. Ignoring."
      return
    if skipSection or key.startsWith("X-"): return
    if not validKey(key):
      warn ln, key, "Invalid key name, ignoring line."
      return
    res.settings.add Setting(section: section, key: key, value: val, file: file, line: ln)
  var cur = ""
  var curLine = 0
  var cont = false
  for i, raw in lines:
    let l = raw.strip(chars = {' ', '\t', '\r'})
    if l.len > 0 and l[0] in {'#', ';'}: continue    # comments never continue, and never end a continuation
    if cont:
      cur.add l
    else:
      cur = l
      curLine = i + 1
    if cur.len > 0 and cur[^1] == '\\':
      cur[^1] = ' '
      cont = true
      continue
    cont = false
    handle cur, curLine
    cur = ""
  if cont: handle cur.strip(chars = {' ', '\t'}), curLine
  res
