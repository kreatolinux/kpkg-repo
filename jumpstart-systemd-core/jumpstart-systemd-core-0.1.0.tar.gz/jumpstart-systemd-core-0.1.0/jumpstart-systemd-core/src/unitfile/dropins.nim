## Drop-in collection (spec §6.7): which `NAME.d/*.conf` files apply to a unit,
## in application order.
import std/[os, options, algorithm, tables]
import std/strutils except escape, unescape
import ../common/names
import ./[model, paths, trust]

type DropIn* = object
  fileName*, path*: string
  dir*: int                   ## index into the search path

proc dropInDirNames*(unitName: string): seq[string] =
  ## Directory names from least to most specific: `service.d`, dash-truncated
  ## prefixes (`foo-.service.d`), the template (`foo@.service.d`, for instances),
  ## the name itself. (systemd truncates the prefix before any `@`.)
  let p = parseUnitName(unitName)
  if p.isNone: return @[unitName & ".d"]
  let n = p.get
  result.add n.suffix[1 .. ^1] & ".d"
  for i, c in n.prefix:
    if c == '-': result.add n.prefix[0 .. i] & n.suffix & ".d"
  if n.isInstance: result.add n.prefix & "@" & n.suffix & ".d"
  result.add unitName & ".d"

proc collectDropIns*(dirs: seq[SearchDir]; names: seq[string]; policy: TrustPolicy;
                     diags: var seq[Diag]; unit = ""): seq[DropIn] =
  ## `names`: the unit's primary name followed by its aliases. Winners by file
  ## name: higher-priority directory, then more specific directory name; a
  ## `/dev/null` winner removes the file. Untrusted entries are skipped with an
  ## E_PERMISSION diagnostic. Result sorted by file name (bytes).
  type Cand = object
    path: string
    dir, spec: int
    masked: bool
  var best = initTable[string, Cand]()
  for di, d in dirs:
    if not dirExists(d.path): continue
    for name in names:
      let dnames = dropInDirNames(name)
      for si, dn in dnames:
        let dd = d.path / dn
        if not dirExists(dd): continue
        var entries: seq[string]
        try:
          for k, p in walkDir(dd): entries.add p.extractFilename
        except OSError:
          diags.add diag(sevWarning, unit, dd, 0, "", "cannot read drop-in directory")
          continue
        entries.sort()
        for fn in entries:
          if not fn.endsWith(".conf"): continue
          let path = dd / fn
          let bad = untrustedReason(policy, d.path, path)
          if bad.isSome:
            diags.add diag(sevError, unit, path, 0, "", bad.get, "E_PERMISSION")
            continue
          let li = policy.stat(path, false)
          if li.isNone: continue
          var masked = false
          if li.get.isLink:
            var dest = ""
            try: dest = expandSymlink(path) except OSError: discard
            masked = dest == "/dev/null"
          if not masked:
            let ti = policy.stat(path, true)
            if ti.isNone or not ti.get.isReg: continue
          let c = Cand(path: path, dir: di, spec: si, masked: masked)
          if fn notin best or c.dir < best[fn].dir or (c.dir == best[fn].dir and c.spec > best[fn].spec):
            best[fn] = c
  var fns: seq[string]
  for k in best.keys: fns.add k
  fns.sort()
  for fn in fns:
    let c = best[fn]
    if not c.masked: result.add DropIn(fileName: fn, path: c.path, dir: c.dir)
