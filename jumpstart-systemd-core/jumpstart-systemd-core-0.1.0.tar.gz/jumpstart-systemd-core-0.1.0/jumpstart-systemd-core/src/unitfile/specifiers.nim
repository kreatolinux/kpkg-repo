## Specifier expansion (spec §6.5). Everything the expansion can depend on is a
## plain field of `SpecifierEnv`, so tests build one by hand and production code
## builds it with `newSpecifierEnv(roots)`.
import std/[options, os, tables, posix, nativesockets]
import std/strutils except escape, unescape
import ../common/[names, roots]

type SpecifierEnv* = object
  scope*: Scope
  arch*, hostname*, prettyHostname*, machineId*, bootId*, kernelRelease*: string
  osRelease*: Table[string, string]
  user*, group*, home*, shell*: string        ## of the manager's user (not `User=`)
  uid*, gid*: int
  cacheRoot*, dataRoot*, configRoot*, logRoot*, stateRoot*, runtimeRoot*, tmp*, varTmp*: string

proc parseOsRelease*(text: string): Table[string, string] =
  ## `KEY=VALUE` lines, values optionally quoted; `#` comments.
  for raw in text.splitLines:
    let l = raw.strip
    if l.len == 0 or l[0] == '#': continue
    let eq = l.find('=')
    if eq <= 0: continue
    var v = l[eq + 1 .. ^1].strip
    if v.len >= 2 and v[0] in {'"', '\''} and v[^1] == v[0]:
      let inner = v[1 .. ^2]
      v = ""
      var i = 0
      while i < inner.len:
        if inner[i] == '\\' and i + 1 < inner.len and inner[i + 1] in {'"', '\\', '$', '`', '\''}:
          inc i
        v.add inner[i]; inc i
    result[l[0 ..< eq]] = v

proc nativeArchitecture*(): string =
  ## systemd's architecture name for the machine the manager was compiled for.
  when defined(amd64): "x86-64"
  elif defined(i386): "x86"
  elif defined(arm64): "arm64"
  elif defined(arm): "arm"
  elif defined(riscv64): "riscv64"
  elif defined(riscv32): "riscv32"
  elif defined(powerpc64el): "ppc64-le"
  elif defined(powerpc64): "ppc64"
  elif defined(loongarch64): "loongarch64"
  elif defined(mips64el): "mips64-le"
  elif defined(mipsel): "mips-le"
  elif defined(mips64): "mips64"
  elif defined(mips): "mips"
  else: "unknown"

proc readTrim(path: string): string =
  try: readFile(path).strip except CatchableError: ""

proc readOsRelease*(roots: Roots): Table[string, string] =
  for p in [roots.osRelease, roots.usrLib / "os-release"]:
    if fileExists(p): return parseOsRelease(readFile(p))

proc kernelRelease(): string =
  var u: Utsname
  if uname(u) == 0: $cast[cstring](addr u.release[0]) else: ""

proc newSpecifierEnv*(roots: Roots): SpecifierEnv =
  ## Reads hostname, user database, machine and boot id, os-release from the
  ## paths of `roots` (fakes in tests).
  var e = SpecifierEnv(scope: roots.scope, arch: nativeArchitecture(), kernelRelease: kernelRelease(),
    tmp: "/tmp", varTmp: "/var/tmp", uid: int(roots.uid))
  try: e.hostname = getHostname() except CatchableError: discard
  e.machineId = readTrim(roots.machineId)
  e.bootId = readTrim(roots.procfs / "sys/kernel/random/boot_id").replace("-", "")
  e.osRelease = readOsRelease(roots)
  let mi = readTrim(roots.etc / "machine-info")
  for l in mi.splitLines:
    if l.startsWith("PRETTY_HOSTNAME="):
      e.prettyHostname = parseOsRelease(l).getOrDefault("PRETTY_HOSTNAME")
  let pw = getpwuid(Uid(roots.uid))
  if pw != nil:
    e.user = $pw.pw_name
    e.shell = $pw.pw_shell
    e.gid = int(pw.pw_gid)
    e.home = $pw.pw_dir
    let gr = getgrgid(pw.pw_gid)
    if gr != nil: e.group = $gr.gr_name
  if e.shell.len == 0: e.shell = "/bin/sh"
  if roots.scope == scSystem:
    e.cacheRoot = roots.varCache; e.dataRoot = roots.usrShare; e.configRoot = roots.etc
    e.logRoot = roots.varLog; e.stateRoot = roots.varLib; e.runtimeRoot = roots.run
    if e.home.len == 0: e.home = "/root"
  else:
    if roots.home.len > 0: e.home = roots.home
    e.cacheRoot = roots.varCache; e.dataRoot = e.home / ".local/share"; e.configRoot = roots.etc
    e.logRoot = roots.logsRoot; e.stateRoot = roots.varLib; e.runtimeRoot = roots.runtime
  e

proc fixedSystemEnv*(): SpecifierEnv =
  ## The classic system-scope values of §17.2 (root, /run, /var/lib, ...), for tests.
  SpecifierEnv(scope: scSystem, arch: "x86-64", hostname: "host.example.org", machineId: "0123456789abcdef0123456789abcdef",
    bootId: "fedcba9876543210fedcba9876543210", kernelRelease: "6.1.0", user: "root", group: "root",
    home: "/root", shell: "/bin/sh", uid: 0, gid: 0, cacheRoot: "/var/cache", dataRoot: "/usr/share",
    configRoot: "/etc", logRoot: "/var/log", stateRoot: "/var/lib", runtimeRoot: "/run", tmp: "/tmp", varTmp: "/var/tmp")

proc osr(e: SpecifierEnv; k: string): string = e.osRelease.getOrDefault(k)

proc expandSpecifiers*(env: SpecifierEnv; unit, s: string; err: var string): Option[string] =
  ## `none` (with `err`) for an unknown or truncated specifier. `unit` is the
  ## full unit name the settings belong to; "" gives empty unit specifiers.
  if '%' notin s: return some(s)
  let pn = parseUnitName(unit)
  var prefix, instance, suffix, stem: string
  if pn.isSome:
    prefix = pn.get.prefix; instance = pn.get.instance; suffix = pn.get.suffix
    stem = unit[0 ..< unit.len - suffix.len]
  elif unit.len > 0:
    stem = unit
  let lastDash = prefix.rfind('-')
  let j = if lastDash < 0: prefix else: prefix[lastDash + 1 .. ^1]
  proc unesc(x: string): string =
    let u = unescape(x)
    if u.isSome: u.get else: x
  var r = ""
  var i = 0
  while i < s.len:
    let c = s[i]
    if c != '%':
      r.add c; inc i; continue
    if i + 1 >= s.len:
      err = "Trailing '%' in value"
      return
    let k = s[i + 1]
    i += 2
    case k
    of '%': r.add '%'
    of 'a': r.add env.arch
    of 'A': r.add env.osr("IMAGE_VERSION")
    of 'b': r.add env.bootId
    of 'B': r.add env.osr("BUILD_ID")
    of 'C': r.add env.cacheRoot
    of 'd': r.add env.runtimeRoot / "credentials" / unit
    of 'D': r.add env.dataRoot
    of 'E': r.add env.configRoot
    of 'f':
      let base = if instance.len > 0: instance else: prefix
      let u = unescapePath(base)
      r.add (if u.isSome: u.get else: "/" & base)
    of 'g': r.add env.group
    of 'G': r.add $env.gid
    of 'h': r.add env.home
    of 'H': r.add env.hostname
    of 'i': r.add instance
    of 'I': r.add unesc(instance)
    of 'j': r.add j
    of 'J': r.add unesc(j)
    of 'l': r.add env.hostname.split('.')[0]
    of 'L': r.add env.logRoot
    of 'm': r.add env.machineId
    of 'M': r.add env.osr("IMAGE_ID")
    of 'n': r.add unit
    of 'N': r.add stem
    of 'o': r.add env.osr("ID")
    of 'p': r.add prefix
    of 'P': r.add unesc(prefix)
    of 'q': r.add env.prettyHostname
    of 's': r.add env.shell
    of 'S': r.add env.stateRoot
    of 't': r.add env.runtimeRoot
    of 'T': r.add env.tmp
    of 'u': r.add env.user
    of 'U': r.add $env.uid
    of 'v': r.add env.kernelRelease
    of 'V': r.add env.varTmp
    of 'w': r.add env.osr("VERSION_ID")
    of 'W': r.add env.osr("VARIANT_ID")
    else:
      err = "Specifier '%" & $k & "' is not known"
      return
  some(r)

proc expandSpecifiers*(env: SpecifierEnv; unit, s: string): Option[string] =
  var e: string
  expandSpecifiers(env, unit, s, e)
