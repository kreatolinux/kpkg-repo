## Validation (spec §6.13, `unit.validate`, `systemd-analyze verify`): load a unit
## freshly from disk and report the errors and warnings of the spec's lists.
import std/[os, options, tables, sets, algorithm]
import std/strutils except escape, unescape
import ../common/[names, roots]
import ./[model, trust, execcmd, index, loader, specifiers]

var calendarValidator*: proc(expr: string): bool {.closure.} = nil
  ## Set by the timer implementation (`calendar.nim`); `nil` accepts any non-empty expression.

const DocSchemes = ["http://", "https://", "file:", "info:", "man:"]

proc orderingCycles*(defs: seq[UnitDef]): seq[seq[string]] =
  ## Ordering cycles (After=/Before=, explicit and implicit) among `defs`, one
  ## entry per strongly connected component of more than one unit (or a unit
  ## ordered after itself), unit names sorted.
  var succ = initTable[string, seq[string]]()          # edge a -> b: a runs before b
  var known = initHashSet[string]()
  for d in defs: known.incl d.common.id
  proc addEdge(a, b: string) =
    if a in known and b in known: succ.mgetOrPut(a, @[]).add b
  for d in defs:
    let c = d.common
    for lst in [c.deps[dkAfter], c.implicitDeps[dkAfter]]:
      for x in lst: addEdge(x, c.id)
    for lst in [c.deps[dkBefore], c.implicitDeps[dkBefore]]:
      for x in lst: addEdge(c.id, x)
  # Tarjan's strongly connected components
  var index = initTable[string, int]()
  var low = initTable[string, int]()
  var onStack = initHashSet[string]()
  var stack: seq[string]
  var counter = 0
  var found: seq[seq[string]]
  proc strong(v: string) =
    index[v] = counter; low[v] = counter; inc counter
    stack.add v; onStack.incl v
    for w in succ.getOrDefault(v):
      if w notin index:
        strong(w)
        low[v] = min(low[v], low[w])
      elif w in onStack:
        low[v] = min(low[v], index[w])
    if low[v] == index[v]:
      var comp: seq[string]
      while true:
        let w = stack.pop()
        onStack.excl w
        comp.add w
        if w == v: break
      if comp.len > 1 or v in succ.getOrDefault(v):
        comp.sort()
        found.add comp
  var ids: seq[string]
  for k in known: ids.add k
  ids.sort()
  for v in ids:
    if v notin index: strong(v)
  found.sort(proc(a, b: seq[string]): int = cmp(a[0], b[0]))
  result = found

proc isPathCondition(k: ConditionKind): bool =
  k in {ckPathExists, ckPathExistsGlob, ckPathIsDirectory, ckPathIsSymbolicLink, ckPathIsMountPoint,
        ckPathIsReadWrite, ckPathIsEncrypted, ckDirectoryNotEmpty, ckFileNotEmpty, ckFileIsExecutable}

proc checkDef(idx: UnitIndex; roots: Roots; env: SpecifierEnv; def: UnitDef; diags: var seq[Diag]; checkCycles: bool) =
  let cm = def.common
  let id = cm.id
  template err(key, msg: string; code = "") = diags.add diag(sevError, id, cm.fragmentPath, 0, key, msg, code)
  template warn(key, msg: string) = diags.add diag(sevWarning, id, cm.fragmentPath, 0, key, msg)
  # specifiers that cannot resolve
  if not cm.isTemplate and cm.instance.len == 0:
    for s in cm.settings:
      if ("%i" in s.value or "%I" in s.value):
        diags.add diag(sevWarning, id, s.file, s.line, s.key, "%i or %I used in a unit that is not a template: expands to the empty string")
  # per type
  case def.kind
  of ukService:
    let s = def.service
    if s.commands[ekStart].len == 0 and s.commands[ekStop].len == 0 and cm.successAction == uaNone:
      err "ExecStart", "Service has no ExecStart=, ExecStop=, or SuccessAction=. Refusing.", "E_SETTING"
    if s.typ == stOneshot and s.restart in {rpAlways, rpOnSuccess}:
      err "Restart", "Service has Restart= set to " & $s.restart & ", which isn't allowed for Type=oneshot services. Refusing.", "E_SETTING"
    if s.typ == stDbus and s.busName.len == 0:
      err "Type", "Service is of type dbus but no BusName= is set. Refusing.", "E_SETTING"
    if s.typ != stOneshot and s.commands[ekStart].len > 1:
      err "ExecStart", "Service has more than one ExecStart= setting, which is only allowed for Type=oneshot services. Refusing.", "E_SETTING"
    for k in ExecKind:
      for c in s.commands[k]:
        if c.path.startsWith("/"):
          if lookupExecutable(c.path, [], execBase(roots)).len == 0 and efMinus notin c.flags:
            diags.add diag(sevWarning, id, c.file, c.line, $k, "Command " & c.path & " is not executable: No such file or directory")
        elif lookupExecutable(c.path, execSearchDirs(roots)).len == 0 and efMinus notin c.flags:
          diags.add diag(sevError, id, c.file, c.line, $k, "Command " & c.path & " is not found in the executable search path", "E_SETTING")
  of ukSocket:
    let s = def.socket
    if s.listen.len == 0:
      err "Listen", "Unit has no Listen setting (ListenStream=, ListenDatagram=, ListenFIFO=, ...). Refusing.", "E_SETTING"
    if s.service.len > 0:
      let ps = parseUnitName(s.service)
      if ps.isNone or ps.get.kind != ukService:
        err "Service", "Service= must name a .service unit: " & s.service, "E_SETTING"
      elif s.accept and not ps.get.isTemplate:
        err "Service", "Accept=yes cannot be combined with a non-template Service=. Refusing.", "E_SETTING"
  of ukTimer:
    var any = false
    for v in def.timer.values: any = true
    if not any:
      err "OnCalendar", "Timer unit lacks value setting (OnCalendar=, OnActiveSec=, ...). Refusing.", "E_SETTING"
    for v in def.timer.values:
      if v.base == tbCalendar and (v.calendar.len == 0 or (calendarValidator != nil and not calendarValidator(v.calendar))):
        err "OnCalendar", "Failed to parse calendar specification '" & v.calendar & "'", "E_SETTING"
    if def.timer.unit.len > 0 and parseUnitName(def.timer.unit).isNone:
      err "Unit", "Unit= is not a valid unit name: " & def.timer.unit, "E_SETTING"
  of ukPath:
    if def.path.paths.len == 0:
      err "PathExists", "Path unit lacks path setting (PathExists=, PathChanged=, ...). Refusing.", "E_SETTING"
  of ukMount:
    let w = def.mount.where
    if w.len == 0 or not w.startsWith("/"):
      err "Where", "Where= setting is missing or not an absolute path. Refusing.", "E_SETTING"
    elif id.endsWith(".mount") and escapePath(w) & ".mount" != id and not cm.isTemplate:
      err "Where", "Where= setting doesn't match unit name. Refusing.", "E_SETTING"
    if def.mount.what.len == 0:
      err "What", "What= setting is missing. Refusing.", "E_SETTING"
  of ukAutomount:
    let w = def.mount.where
    if w.len == 0 or not w.startsWith("/"):
      err "Where", "Where= setting is missing or not an absolute path. Refusing.", "E_SETTING"
    elif id.endsWith(".automount") and escapePath(w) & ".automount" != id and not cm.isTemplate:
      err "Where", "Where= setting doesn't match unit name. Refusing.", "E_SETTING"
  of ukSwap:
    let w = def.swap.what
    if w.len == 0 or not w.startsWith("/"):
      err "What", "What= setting is missing or not an absolute path. Refusing.", "E_SETTING"
    elif escapePath(w) & ".swap" != id:
      err "What", "What= setting doesn't match unit name. Refusing.", "E_SETTING"
  else: discard
  # install section
  let suffix = parseUnitName(id).get.suffix
  for a in cm.install.alias:
    let pa = parseUnitName(a)
    if pa.isNone: err "Alias", "Alias= is not a valid unit name: " & a, "E_SETTING"
    elif pa.get.suffix != suffix: err "Alias", "Alias= '" & a & "' has a different unit type than " & id, "E_SETTING"
    elif cm.isTemplate and not (pa.get.isTemplate or pa.get.isInstance):
      err "Alias", "Alias= '" & a & "' of a template unit must be a template or an instance", "E_SETTING"
    elif not (cm.isTemplate or cm.instance.len > 0) and pa.get.isTemplate:
      err "Alias", "Alias= '" & a & "' is a template name but " & id & " is not a template", "E_SETTING"
  for t in cm.install.wantedBy & cm.install.requiredBy & cm.install.upheldBy:
    if resolveName(idx, t).isNone:
      warn "WantedBy", "[Install] target " & t & " does not exist"
  # dependencies
  for k in DepKind:
    for d in cm.deps[k]:
      if k == dkJoinsNamespaceOf: continue
      if d == id and k == dkAfter:
        warn "After", id & " lists itself in After=, ignoring"
      if resolveName(idx, d).isNone:
        warn $k, "Dependency " & d & " of " & id & " (" & $k & "=) does not exist"
  for d in cm.documentation:
    var ok = false
    for sc in DocSchemes:
      if d.startsWith(sc): ok = true
    if not ok: warn "Documentation", "Invalid URL scheme in Documentation=: " & d
  for c in cm.conditions:
    if isPathCondition(c.kind) and c.value.len > 0 and not c.value.startsWith("/"):
      diags.add diag(sevWarning, id, c.file, c.line, (if c.isAssert: "Assert" else: "Condition") & $c.kind,
        "Path in " & $c.kind & "= is not absolute: " & c.value)
  if cm.defaultDependencies and roots.scope == scSystem and def.kind in {ukService, ukSocket, ukTimer, ukPath}:
    for b in cm.deps[dkBefore]:
      if b in ["sysinit.target", "basic.target"]:
        warn "Before", id & " has DefaultDependencies=yes and Before=" & b & ": this is likely an ordering cycle"
  if checkCycles:
    # load the ordering neighbourhood and report a cycle through this unit
    var defs = @[def]
    var seen = initHashSet[string]()
    seen.incl id
    var queue = @[id]
    var qi = 0
    while qi < queue.len and defs.len < 400:
      var d = def
      if qi > 0:
        d = loadUnit(idx, queue[qi], env)
        defs.add d
      inc qi
      for lst in [d.common.deps[dkAfter], d.common.implicitDeps[dkAfter], d.common.deps[dkBefore], d.common.implicitDeps[dkBefore]]:
        for n in lst:
          if n notin seen and resolveName(idx, n).isSome:
            seen.incl n
            queue.add n
    for cyc in orderingCycles(defs):
      if id in cyc:
        warn "After", "Found ordering cycle: " & cyc.join(" -> ")

proc validateUnit*(roots: Roots; nameOrPath: string; env: SpecifierEnv): ValidationResult =
  ## Loads one unit afresh (by name, or from a file path) and returns every
  ## diagnostic; `valid` means no error. Cannot raise.
  var bd: seq[Diag]
  let idx = buildIndex(roots, @[], bd, newTrustPolicy(roots))
  var def: UnitDef
  var name = nameOrPath
  if '/' in nameOrPath and not nameOrPath.endsWith("/"):
    name = nameOrPath.extractFilename
    var text = ""
    try: text = readFile(nameOrPath)
    except CatchableError as e:
      result.unit = name
      result.diagnostics.add diag(sevError, name, nameOrPath, 0, "", "cannot read: " & e.msg, "E_IO")
      return
    def = parseUnitText(name, text, roots, env, idx.conf, usFile, nameOrPath)
    def.common.fragmentPath = nameOrPath
  else:
    name = mangle(nameOrPath)
    def = loadUnit(idx, name, env)
  result.unit = def.common.id
  result.def = def
  result.diagnostics = def.common.diagnostics
  if parseUnitName(name).isNone:
    result.diagnostics.add diag(sevError, name, "", 0, "", "Invalid unit name '" & name & "'", "E_LOAD")
  elif def.common.loadState == lsNotFound:
    result.diagnostics.add diag(sevError, name, "", 0, "", "Unit " & name & " not found.", "E_NOT_FOUND")
  elif def.common.loadState == lsMasked:
    result.diagnostics.add diag(sevError, name, "", 0, "", "Unit " & name & " is masked.", "E_UNIT_STATE")
  elif def.common.loadState in {lsLoaded, lsBadSetting}:
    var extra: seq[Diag]
    checkDef(idx, roots, env, def, extra, true)
    result.diagnostics.add extra
  result.valid = not hasErrors(result.diagnostics)
