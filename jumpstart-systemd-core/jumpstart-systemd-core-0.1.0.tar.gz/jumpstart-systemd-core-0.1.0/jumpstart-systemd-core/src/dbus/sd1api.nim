## `org.freedesktop.systemd1` on the D-Bus session bus (user scope): the
## part of systemd's manager API that desktop sessions use (gnome-session's
## leader and gnome-session-ctl, gnome-shell, gnome-settings-daemon,
## xdg-desktop-portal, dbus-daemon's `--systemd-activation`):
##
## * Manager (/org/freedesktop/systemd1): GetUnit, LoadUnit, GetUnitByPID,
##   GetJob, Start/Stop/Reload/Restart/TryRestart/ReloadOrRestart/
##   ReloadOrTryRestart/KillUnit, ResetFailedUnit, ResetFailed, ListUnits*,
##   ListJobs, CancelJob, ClearJobs, Subscribe, Unsubscribe, Reload,
##   Set/Unset/UnsetAndSetEnvironment, GetDefaultTarget, GetUnitFileState,
##   ListUnitFiles*, Enable/DisableUnitFiles, Exit; the manager properties;
##   the JobNew, JobRemoved, Reloading, UnitNew, UnitRemoved signals.
## * Units (/org/freedesktop/systemd1/unit/NAME): org.freedesktop.systemd1.Unit
##   (methods and properties) plus the type interface (Service, Socket, Timer,
##   Target, Slice, Path, Mount, Swap, Automount); PropertiesChanged on every
##   state change.
## * Jobs (/org/freedesktop/systemd1/job/ID): Id, Unit, JobType, State, Cancel.
## * Activator: `ActivationRequest` signals from dbus-daemon start the unit;
##   failures are answered with `ActivationFailure`.
## * The standard Peer, Introspectable and Properties interfaces.
##
## Not provided: transient units over the bus (StartTransientUnit answers
## NotSupported; scopes do not exist in this core), freezing, polkit (the
## session bus admits only its user).
import std/[algorithm, json, options, os, posix, sequtils, sets, strutils, tables]
import jumpstartcore/errors
import ../common/[names, roots, logging, clock]
import ../unitfile/[model, install, loader]
import ../engine/[types, graph, jobs, unitstate, manager, boot, api, eventloop, transient]
import ../service/cgroupmgr
import ./[wire, busconn]

const
  SdName* = "org.freedesktop.systemd1"
  SdPath* = "/org/freedesktop/systemd1"
  UnitPrefix* = SdPath & "/unit/"
  JobPrefix* = SdPath & "/job/"
  IfManager* = "org.freedesktop.systemd1.Manager"
  IfUnit* = "org.freedesktop.systemd1.Unit"
  IfJob* = "org.freedesktop.systemd1.Job"
  IfActivator* = "org.freedesktop.systemd1.Activator"
  IfProps = "org.freedesktop.DBus.Properties"
  IfIntro = "org.freedesktop.DBus.Introspectable"
  IfPeer = "org.freedesktop.DBus.Peer"
  ErrNoSuchUnit = "org.freedesktop.systemd1.NoSuchUnit"
  ErrNoSuchJob = "org.freedesktop.systemd1.NoSuchJob"
  ErrUnitMasked = "org.freedesktop.systemd1.UnitMasked"
  ErrOnlyByDependency = "org.freedesktop.systemd1.OnlyByDependency"
  ErrJobTypeNotApplicable = "org.freedesktop.systemd1.JobTypeNotApplicable"
  ErrShuttingDown = "org.freedesktop.systemd1.ShuttingDown"
  ErrTransactionDestructive = "org.freedesktop.systemd1.TransactionIsDestructive"
  ErrLoadFailed = "org.freedesktop.systemd1.LoadFailed"
  ErrInvalidArgs = "org.freedesktop.DBus.Error.InvalidArgs"
  ErrUnknownMethod = "org.freedesktop.DBus.Error.UnknownMethod"
  ErrUnknownObject = "org.freedesktop.DBus.Error.UnknownObject"
  ErrUnknownInterface = "org.freedesktop.DBus.Error.UnknownInterface"
  ErrUnknownProperty = "org.freedesktop.DBus.Error.UnknownProperty"
  ErrPropertyReadOnly = "org.freedesktop.DBus.Error.PropertyReadOnly"
  ErrNotSupported = "org.freedesktop.DBus.Error.NotSupported"
  ErrFailed = "org.freedesktop.DBus.Error.Failed"
  RetryUsec = 1_000_000'i64
  ActivationWatchUsec = 30_000_000'i64

type
  ApiError = object of CatchableError
    errName: string

  UnitGetter = proc(a: BusApi; u: Unit): DValue {.closure.}
  ManagerGetter = proc(a: BusApi): DValue {.closure.}
  UnitProp = tuple[name, sig: string; get: UnitGetter]
  ManagerProp = tuple[name, sig: string; get: ManagerGetter]

  BusApi* = ref object
    m*: Manager
    conn*: BusConn
    socketPath*: string
    uid: Uid
    retry: TimerId
    connectQueued: bool
    announced: HashSet[int]           ## job ids whose JobNew went out
    lastFailure: string               ## last connection error (logged once)
    enabled*: bool

proc apiErr(name, text: string): ref ApiError =
  result = newException(ApiError, text)
  result.errName = name

# ---- names and paths -------------------------------------------------------------
proc unitPath*(id: string): string = UnitPrefix & labelEscape(id)
proc jobPath*(id: int): string = JobPrefix & $id

proc unitOfPath(a: BusApi; path: string): Unit =
  if not path.startsWith(UnitPrefix): return nil
  let name = labelUnescape(path[UnitPrefix.len .. ^1])
  if name.len == 0: return nil
  a.m.lookup(name)

proc jobOfPath(a: BusApi; path: string): Job =
  if not path.startsWith(JobPrefix): return nil
  try: a.m.jobs.getOrDefault(parseInt(path[JobPrefix.len .. ^1]))
  except ValueError: nil

proc loaded(a: BusApi; name: string): Unit =
  ## GetUnit: units the manager has loaded (systemd answers NoSuchUnit for
  ## the others).
  let id = a.m.canonical(mangle(name))
  let u = a.m.units.getOrDefault(id)
  if u == nil or u.def.common.loadState == lsNotFound: return nil
  u

proc stampOf(s: Stamp): (DValue, DValue) = (duint64(s.realUsec), duint64(s.monoUsec))

proc jobTuple(u: Unit): DValue =
  if u.job == nil: dstruct(duint32(0), dpath("/"))
  else: dstruct(duint32(u.job.id), dpath(jobPath(u.job.id)))

proc dbusJobType(t: JobType): string =
  case t
  of jtReloadOrStart: "reload-or-start"
  of jtTryReloadOrStart: "try-reload-or-start"
  else: $t

# ---- properties ------------------------------------------------------------------
proc depList(a: BusApi; u: Unit; k: DepKind): DValue =
  dstrs(u.def.common.deps[k] & u.def.common.implicitDeps[k])

proc revList(a: BusApi; u: Unit; k: DepKind): DValue = dstrs(a.m.reverseDeps(u.id, k))

proc extras(a: BusApi; u: Unit): StatusExtras =
  result = StatusExtras(exitCode: -1)
  if u.ops.status != nil:
    try: result = u.ops.status(a.m, u) except CatchableError: discard

proc unitFileState(a: BusApi; u: Unit): string =
  let s = enablementOf(a.m, u)
  case s
  of esNotFound: ""
  of esBad: "bad"
  else: $s

proc unitProps(): seq[UnitProp] =
  proc s(f: proc(a: BusApi; u: Unit): string): UnitGetter =
    (proc(a: BusApi; u: Unit): DValue = dstr(f(a, u)))
  proc b(f: proc(a: BusApi; u: Unit): bool): UnitGetter =
    (proc(a: BusApi; u: Unit): DValue = dbool(f(a, u)))
  proc dep(k: DepKind): UnitGetter = (proc(a: BusApi; u: Unit): DValue = a.depList(u, k))
  proc rev(k: DepKind): UnitGetter = (proc(a: BusApi; u: Unit): DValue = a.revList(u, k))
  proc empty(): UnitGetter = (proc(a: BusApi; u: Unit): DValue = dstrs(newSeq[string]()))
  result = @[
    ("Id", "s", s(proc(a: BusApi; u: Unit): string = u.id)),
    ("Names", "as", (proc(a: BusApi; u: Unit): DValue =
      dstrs(if u.def.common.names.len > 0: u.def.common.names else: @[u.id]))),
    ("Following", "s", s(proc(a: BusApi; u: Unit): string = "")),
    ("Requires", "as", dep(dkRequires)), ("Requisite", "as", dep(dkRequisite)),
    ("Wants", "as", dep(dkWants)), ("BindsTo", "as", dep(dkBindsTo)),
    ("PartOf", "as", dep(dkPartOf)), ("Upholds", "as", dep(dkUpholds)),
    ("RequiredBy", "as", rev(dkRequires)), ("RequisiteOf", "as", rev(dkRequisite)),
    ("WantedBy", "as", rev(dkWants)), ("BoundBy", "as", rev(dkBindsTo)),
    ("UpheldBy", "as", rev(dkUpholds)), ("ConsistsOf", "as", rev(dkPartOf)),
    ("Conflicts", "as", dep(dkConflicts)), ("ConflictedBy", "as", rev(dkConflicts)),
    ("Before", "as", dep(dkBefore)), ("After", "as", dep(dkAfter)),
    ("OnSuccess", "as", dep(dkOnSuccess)), ("OnSuccessOf", "as", rev(dkOnSuccess)),
    ("OnFailure", "as", dep(dkOnFailure)), ("OnFailureOf", "as", rev(dkOnFailure)),
    ("Triggers", "as", dep(dkTriggers)), ("TriggeredBy", "as", rev(dkTriggers)),
    ("PropagatesReloadTo", "as", dep(dkPropagatesReloadTo)),
    ("ReloadPropagatedFrom", "as", dep(dkReloadPropagatedFrom)),
    ("PropagatesStopTo", "as", dep(dkPropagatesStopTo)),
    ("StopPropagatedFrom", "as", dep(dkStopPropagatedFrom)),
    ("JoinsNamespaceOf", "as", empty()),
    ("SliceOf", "as", empty()),
    ("RequiresMountsFor", "as", (proc(a: BusApi; u: Unit): DValue = dstrs(u.def.common.requiresMountsFor))),
    ("WantsMountsFor", "as", (proc(a: BusApi; u: Unit): DValue = dstrs(u.def.common.wantsMountsFor))),
    ("Documentation", "as", empty()),
    ("Description", "s", s(proc(a: BusApi; u: Unit): string =
      if u.def.common.description.len > 0: u.def.common.description else: u.id)),
    ("AccessSELinuxContext", "s", s(proc(a: BusApi; u: Unit): string = "")),
    ("LoadState", "s", s(proc(a: BusApi; u: Unit): string = $u.def.common.loadState)),
    ("ActiveState", "s", s(proc(a: BusApi; u: Unit): string = $u.active)),
    ("FreezerState", "s", s(proc(a: BusApi; u: Unit): string = "running")),
    ("SubState", "s", s(proc(a: BusApi; u: Unit): string = u.sub)),
    ("FragmentPath", "s", s(proc(a: BusApi; u: Unit): string = u.def.common.fragmentPath)),
    ("SourcePath", "s", s(proc(a: BusApi; u: Unit): string = u.def.common.sourcePath)),
    ("DropInPaths", "as", (proc(a: BusApi; u: Unit): DValue = dstrs(u.def.common.dropInPaths))),
    ("UnitFileState", "s", s(proc(a: BusApi; u: Unit): string = a.unitFileState(u))),
    ("UnitFilePreset", "s", s(proc(a: BusApi; u: Unit): string = "")),
    ("StateChangeTimestamp", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.since))),
    ("StateChangeTimestampMonotonic", "t", (proc(a: BusApi; u: Unit): DValue =
      duint64(max(max(u.activeEnter.monoUsec, u.activeExit.monoUsec),
                  max(u.inactiveEnter.monoUsec, u.inactiveExit.monoUsec))))),
    ("InactiveExitTimestamp", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveExit.realUsec))),
    ("InactiveExitTimestampMonotonic", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveExit.monoUsec))),
    ("ActiveEnterTimestamp", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.activeEnter.realUsec))),
    ("ActiveEnterTimestampMonotonic", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.activeEnter.monoUsec))),
    ("ActiveExitTimestamp", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.activeExit.realUsec))),
    ("ActiveExitTimestampMonotonic", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.activeExit.monoUsec))),
    ("InactiveEnterTimestamp", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveEnter.realUsec))),
    ("InactiveEnterTimestampMonotonic", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveEnter.monoUsec))),
    ("CanStart", "b", b(proc(a: BusApi; u: Unit): bool =
      u.kind notin {ukDevice, ukScope} and not u.def.common.refuseManualStart)),
    ("CanStop", "b", b(proc(a: BusApi; u: Unit): bool =
      u.kind notin {ukDevice, ukScope} and not u.def.common.refuseManualStop)),
    ("CanReload", "b", b(proc(a: BusApi; u: Unit): bool = u.ops.canReload != nil and u.ops.canReload(u))),
    ("CanIsolate", "b", b(proc(a: BusApi; u: Unit): bool = u.kind == ukTarget and u.def.common.allowIsolate)),
    ("CanClean", "as", empty()),
    ("CanFreeze", "b", b(proc(a: BusApi; u: Unit): bool = false)),
    ("CanLiveMount", "b", b(proc(a: BusApi; u: Unit): bool = false)),
    ("Job", "(uo)", (proc(a: BusApi; u: Unit): DValue = jobTuple(u))),
    ("StopWhenUnneeded", "b", b(proc(a: BusApi; u: Unit): bool = u.def.common.stopWhenUnneeded)),
    ("RefuseManualStart", "b", b(proc(a: BusApi; u: Unit): bool = u.def.common.refuseManualStart)),
    ("RefuseManualStop", "b", b(proc(a: BusApi; u: Unit): bool = u.def.common.refuseManualStop)),
    ("AllowIsolate", "b", b(proc(a: BusApi; u: Unit): bool = u.def.common.allowIsolate)),
    ("DefaultDependencies", "b", b(proc(a: BusApi; u: Unit): bool = u.def.common.defaultDependencies)),
    ("SurviveFinalKillSignal", "b", b(proc(a: BusApi; u: Unit): bool = false)),
    ("OnSuccessJobMode", "s", s(proc(a: BusApi; u: Unit): string = $u.def.common.onSuccessJobMode)),
    ("OnFailureJobMode", "s", s(proc(a: BusApi; u: Unit): string = $u.def.common.onFailureJobMode)),
    ("IgnoreOnIsolate", "b", b(proc(a: BusApi; u: Unit): bool = u.def.common.ignoreOnIsolate)),
    ("NeedDaemonReload", "b", b(proc(a: BusApi; u: Unit): bool =
      u.needDaemonReload or (a.m.index != nil and fileChanged(a.m.index, u.def)))),
    ("JobTimeoutUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(high(uint64)))),
    ("JobRunningTimeoutUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(high(uint64)))),
    ("JobTimeoutAction", "s", s(proc(a: BusApi; u: Unit): string = "none")),
    ("ConditionResult", "b", b(proc(a: BusApi; u: Unit): bool = u.conditionResult)),
    ("AssertResult", "b", b(proc(a: BusApi; u: Unit): bool = true)),
    ("ConditionTimestamp", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveExit.realUsec))),
    ("ConditionTimestampMonotonic", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveExit.monoUsec))),
    ("AssertTimestamp", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveExit.realUsec))),
    ("AssertTimestampMonotonic", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.inactiveExit.monoUsec))),
    ("LoadError", "(ss)", (proc(a: BusApi; u: Unit): DValue =
      let le = u.def.common.loadError
      if le.len == 0: dstruct(dstr(""), dstr(""))
      elif u.def.common.loadState == lsNotFound:
        dstruct(dstr("org.freedesktop.systemd1.NoSuchUnit"), dstr(le))
      else: dstruct(dstr("org.freedesktop.systemd1.BadUnitSetting"), dstr(le)))),
    ("Transient", "b", b(proc(a: BusApi; u: Unit): bool = u.def.common.source == usTransient)),
    ("Perpetual", "b", b(proc(a: BusApi; u: Unit): bool = u.perpetual)),
    ("StartLimitIntervalUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.startLimit.intervalUsec))),
    ("StartLimitBurst", "u", (proc(a: BusApi; u: Unit): DValue = duint32(u.startLimit.burst))),
    ("StartLimitAction", "s", s(proc(a: BusApi; u: Unit): string = "none")),
    ("InvocationID", "ay", (proc(a: BusApi; u: Unit): DValue = darray("y"))),
    ("CollectMode", "s", s(proc(a: BusApi; u: Unit): string = $u.def.common.collectMode)),
    ("Refs", "as", empty())]

proc unitKindInterface(k: UnitKind): string =
  case k
  of ukService: "org.freedesktop.systemd1.Service"
  of ukSocket: "org.freedesktop.systemd1.Socket"
  of ukTarget: "org.freedesktop.systemd1.Target"
  of ukTimer: "org.freedesktop.systemd1.Timer"
  of ukPath: "org.freedesktop.systemd1.Path"
  of ukMount: "org.freedesktop.systemd1.Mount"
  of ukAutomount: "org.freedesktop.systemd1.Automount"
  of ukSwap: "org.freedesktop.systemd1.Swap"
  of ukSlice: "org.freedesktop.systemd1.Slice"
  of ukDevice: "org.freedesktop.systemd1.Device"
  of ukScope: "org.freedesktop.systemd1.Scope"

proc extraValue(a: BusApi; u: Unit; key: string): string =
  for (k, v) in a.extras(u).extra:
    if k == key: return v

proc cgroupOf(a: BusApi; u: Unit): string =
  let full = a.extras(u).cgroup
  let mount = a.m.roots.cgroupMount
  if full.startsWith(mount): full[mount.len .. ^1] else: full

proc kindProps(k: UnitKind): seq[UnitProp] =
  proc s(f: proc(a: BusApi; u: Unit): string): UnitGetter =
    (proc(a: BusApi; u: Unit): DValue = dstr(f(a, u)))
  let resultProp: UnitProp = ("Result", "s", s(proc(a: BusApi; u: Unit): string =
    if u.result.len > 0: u.result else: "success"))
  let cg: UnitProp = ("ControlGroup", "s", s(proc(a: BusApi; u: Unit): string = a.cgroupOf(u)))
  let slice: UnitProp = ("Slice", "s", s(proc(a: BusApi; u: Unit): string = u.def.common.slice))
  case k
  of ukService:
    @[("Type", "s", s(proc(a: BusApi; u: Unit): string = $u.def.service.typ)),
      ("ExitType", "s", s(proc(a: BusApi; u: Unit): string = $u.def.service.exitType)),
      ("Restart", "s", s(proc(a: BusApi; u: Unit): string = $u.def.service.restart)),
      ("PIDFile", "s", s(proc(a: BusApi; u: Unit): string = u.def.service.pidFile)),
      ("NotifyAccess", "s", s(proc(a: BusApi; u: Unit): string = $u.def.service.notifyAccess)),
      ("RestartUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.def.service.restartUsec))),
      ("TimeoutStartUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.def.service.timeoutStartUsec))),
      ("TimeoutStopUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.def.service.timeoutStopUsec))),
      ("RuntimeMaxUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.def.service.runtimeMaxUsec))),
      ("WatchdogUSec", "t", (proc(a: BusApi; u: Unit): DValue = duint64(u.def.service.watchdogUsec))),
      ("RemainAfterExit", "b", (proc(a: BusApi; u: Unit): DValue = dbool(u.def.service.remainAfterExit))),
      ("GuessMainPID", "b", (proc(a: BusApi; u: Unit): DValue = dbool(u.def.service.guessMainPid))),
      ("MainPID", "u", (proc(a: BusApi; u: Unit): DValue = duint32(a.extras(u).mainPid))),
      ("ControlPID", "u", (proc(a: BusApi; u: Unit): DValue = duint32(a.extras(u).controlPid))),
      ("BusName", "s", s(proc(a: BusApi; u: Unit): string = u.def.service.busName)),
      ("StatusText", "s", s(proc(a: BusApi; u: Unit): string = a.extras(u).statusText)),
      ("StatusErrno", "i", (proc(a: BusApi; u: Unit): DValue = dint32(0))),
      resultProp,
      ("ReloadResult", "s", s(proc(a: BusApi; u: Unit): string =
        if u.reloadResult.len > 0: u.reloadResult else: "success")),
      ("NRestarts", "u", (proc(a: BusApi; u: Unit): DValue = duint32(a.extras(u).nRestarts))),
      ("ExecMainPID", "u", (proc(a: BusApi; u: Unit): DValue = duint32(a.extras(u).mainPid))),
      ("ExecMainCode", "i", (proc(a: BusApi; u: Unit): DValue = dint32(a.extras(u).execMainCode))),
      ("ExecMainStatus", "i", (proc(a: BusApi; u: Unit): DValue = dint32(a.extras(u).execMainStatus))),
      slice, cg]
  of ukSocket:
    @[("Listen", "a(ss)", (proc(a: BusApi; u: Unit): DValue =
        result = darray("(ss)")
        for l in u.def.socket.listen: result.items.add dstruct(dstr($l.kind), dstr(l.address)))),
      ("Accept", "b", (proc(a: BusApi; u: Unit): DValue = dbool(u.def.socket.accept))),
      ("NConnections", "u", (proc(a: BusApi; u: Unit): DValue = duint32(0))),
      resultProp, slice, cg]
  of ukTimer:
    @[("Unit", "s", s(proc(a: BusApi; u: Unit): string =
        let t = a.extraValue(u, "unit")
        if t.len > 0: t else: u.id.changeFileExt("service"))),
      ("NextElapseUSecRealtime", "t", (proc(a: BusApi; u: Unit): DValue =
        duint64(try: parseBiggestInt(a.extraValue(u, "next_run")) except ValueError: 0'i64))),
      ("LastTriggerUSec", "t", (proc(a: BusApi; u: Unit): DValue =
        duint64(try: parseBiggestInt(a.extraValue(u, "last_run")) except ValueError: 0'i64))),
      resultProp]
  of ukPath, ukMount, ukAutomount, ukSwap: @[resultProp]
  of ukSlice: @[cg]
  else: @[]

proc managerProps(): seq[ManagerProp] =
  proc s(f: proc(a: BusApi): string): ManagerGetter = (proc(a: BusApi): DValue = dstr(f(a)))
  proc t(f: proc(a: BusApi): int64): ManagerGetter = (proc(a: BusApi): DValue = duint64(f(a)))
  proc u32(f: proc(a: BusApi): int): ManagerGetter = (proc(a: BusApi): DValue = duint32(f(a)))
  result = @[
    ("Version", "s", s(proc(a: BusApi): string = a.m.version & " (jumpstart-systemd-core)")),
    ("Features", "s", s(proc(a: BusApi): string = "-PAM -AUDIT -SELINUX -APPARMOR +SECCOMP")),
    ("Virtualization", "s", s(proc(a: BusApi): string = "")),
    ("ConfidentialVirtualization", "s", s(proc(a: BusApi): string = "")),
    ("Architecture", "s", s(proc(a: BusApi): string =
      when defined(arm64): "arm64" elif defined(amd64): "x86-64" else: hostCPU)),
    ("Tainted", "s", s(proc(a: BusApi): string = "")),
    ("FirmwareTimestamp", "t", t(proc(a: BusApi): int64 = 0)),
    ("LoaderTimestamp", "t", t(proc(a: BusApi): int64 = 0)),
    ("KernelTimestamp", "t", t(proc(a: BusApi): int64 = 0)),
    ("UserspaceTimestamp", "t", t(proc(a: BusApi): int64 = a.m.clock.realUsec - (a.m.clock.monoUsec - a.m.startedUsec))),
    ("UserspaceTimestampMonotonic", "t", t(proc(a: BusApi): int64 = a.m.startedUsec)),
    ("FinishTimestamp", "t", t(proc(a: BusApi): int64 =
      if a.m.bootJobsDone > 0: a.m.clock.realUsec - (a.m.clock.monoUsec - a.m.bootJobsDone) else: 0)),
    ("FinishTimestampMonotonic", "t", t(proc(a: BusApi): int64 = a.m.bootJobsDone)),
    ("LogLevel", "s", s(proc(a: BusApi): string = "info")),
    ("LogTarget", "s", s(proc(a: BusApi): string = "journal")),
    ("NNames", "u", u32(proc(a: BusApi): int = a.m.units.len)),
    ("NFailedUnits", "u", u32(proc(a: BusApi): int = systemState(a.m).failed.len)),
    ("NJobs", "u", u32(proc(a: BusApi): int = a.m.jobs.len)),
    ("NInstalledJobs", "u", u32(proc(a: BusApi): int = a.m.jobSeq)),
    ("NFailedJobs", "u", u32(proc(a: BusApi): int = 0)),
    ("Progress", "d", (proc(a: BusApi): DValue = ddouble(if a.m.booting: 0.5 else: 1.0))),
    ("Environment", "as", (proc(a: BusApi): DValue =
      var env: seq[string]
      for k, v in a.m.env: env.add k & "=" & v
      env.sort()
      dstrs(env))),
    ("ConfirmSpawn", "b", (proc(a: BusApi): DValue = dbool(false))),
    ("ShowStatus", "b", (proc(a: BusApi): DValue = dbool(false))),
    ("UnitPath", "as", (proc(a: BusApi): DValue = dstrs(newSeq[string]()))),
    ("DefaultStandardOutput", "s", s(proc(a: BusApi): string = "journal")),
    ("DefaultStandardError", "s", s(proc(a: BusApi): string = "inherit")),
    ("RuntimeWatchdogUSec", "t", t(proc(a: BusApi): int64 = 0)),
    ("ServiceWatchdogs", "b", (proc(a: BusApi): DValue = dbool(true))),
    ("ControlGroup", "s", s(proc(a: BusApi): string = "")),
    ("SystemState", "s", s(proc(a: BusApi): string = systemState(a.m).state)),
    ("ExitCode", "y", (proc(a: BusApi): DValue = dbyte(0))),
    ("DefaultTimerAccuracyUSec", "t", t(proc(a: BusApi): int64 = 60_000_000)),
    ("DefaultTimeoutStartUSec", "t", t(proc(a: BusApi): int64 = 90_000_000)),
    ("DefaultTimeoutStopUSec", "t", t(proc(a: BusApi): int64 = 90_000_000)),
    ("DefaultRestartUSec", "t", t(proc(a: BusApi): int64 = 100_000)),
    ("TimerSlackNSec", "t", t(proc(a: BusApi): int64 = 50_000))]

let unitPropTable = unitProps()
let managerPropTable = managerProps()
var kindPropCache: Table[UnitKind, seq[UnitProp]]

proc propsOfKind(k: UnitKind): seq[UnitProp] =
  if not kindPropCache.hasKey(k): kindPropCache[k] = kindProps(k)
  kindPropCache[k]

proc propDict(a: BusApi; u: Unit; props: openArray[UnitProp]; only: seq[string] = @[]): DValue =
  result = darray("{sv}")
  for p in props:
    if only.len > 0 and p.name notin only: continue
    var v: DValue
    try: v = p.get(a, u)
    except CatchableError: continue
    result.items.add dentry(dstr(p.name), dvariant(v))

# ---- signals ---------------------------------------------------------------------
proc ready(a: BusApi): bool = a.conn != nil and not a.conn.closed

proc emitJobNew(a: BusApi; j: Job) =
  if not a.ready or j.id in a.announced: return
  a.announced.incl j.id
  a.conn.signal(SdPath, IfManager, "JobNew",
    @[duint32(j.id), dpath(jobPath(j.id)), dstr(j.unit.id)])

proc emitJobRemoved(a: BusApi; o: JobOutcome) =
  if not a.ready: return
  if o.job notin a.announced:
    a.conn.signal(SdPath, IfManager, "JobNew",
      @[duint32(o.job), dpath(jobPath(o.job)), dstr(o.unit)])
  a.announced.excl o.job
  a.conn.signal(SdPath, IfManager, "JobRemoved",
    @[duint32(o.job), dpath(jobPath(o.job)), dstr(o.unit), dstr($o.result)])

const ChangedUnitProps = ["ActiveState", "SubState", "StateChangeTimestamp",
  "StateChangeTimestampMonotonic", "InactiveExitTimestamp", "InactiveExitTimestampMonotonic",
  "ActiveEnterTimestamp", "ActiveEnterTimestampMonotonic", "ActiveExitTimestamp",
  "ActiveExitTimestampMonotonic", "InactiveEnterTimestamp", "InactiveEnterTimestampMonotonic",
  "Job", "ConditionResult", "AssertResult", "ConditionTimestamp", "ConditionTimestampMonotonic",
  "AssertTimestamp", "AssertTimestampMonotonic", "LoadState", "FreezerState"]
const ChangedServiceProps = ["MainPID", "ControlPID", "StatusText", "Result", "ReloadResult",
  "NRestarts", "ExecMainPID", "ExecMainCode", "ExecMainStatus"]

proc emitUnitChanged(a: BusApi; u: Unit) =
  if not a.ready: return
  let path = unitPath(u.id)
  a.conn.signal(path, IfProps, "PropertiesChanged", @[dstr(IfUnit),
    a.propDict(u, unitPropTable, @ChangedUnitProps), dstrs(newSeq[string]())])
  if u.kind == ukService:
    a.conn.signal(path, IfProps, "PropertiesChanged", @[dstr(unitKindInterface(u.kind)),
      a.propDict(u, propsOfKind(u.kind), @ChangedServiceProps), dstrs(newSeq[string]())])

# ---- argument helpers ----------------------------------------------------------------
proc expect(msg: Message; sig: string) =
  if msg.signature != sig:
    raise apiErr(ErrInvalidArgs, "Invalid arguments '" & msg.signature & "' to call " &
      msg.iface & "." & msg.member & "(), expecting '" & sig & "'.")

proc mapCoreError(e: ref CoreError): ref ApiError =
  let text = e.msg
  let name =
    case e.code
    of ecNotFound: ErrNoSuchUnit
    of ecUnsupported: ErrJobTypeNotApplicable
    of ecShutdown: ErrShuttingDown
    of ecUnitState:
      if "masked" in text: ErrUnitMasked
      elif "dependency only" in text: ErrOnlyByDependency
      elif "bad setting" in text: ErrLoadFailed
      else: ErrFailed
    else:
      if "destructive" in text.toLowerAscii: ErrTransactionDestructive
      else: ErrFailed
  apiErr(name, text)

proc requireUnit(a: BusApi; name: string): Unit =
  let u = a.m.lookup(mangle(name))
  if u == nil or u.def.common.loadState == lsNotFound:
    raise apiErr(ErrNoSuchUnit, "Unit " & mangle(name) & " not found.")
  u

proc enqueue(a: BusApi; u: Unit; typ: JobType; modeName: string): int =
  ## Submits a job (D-Bus semantics: returns at once with the job's id).
  var mode: JobMode
  var t = typ
  case modeName
  of "replace", "fail", "isolate", "flush", "ignore-dependencies", "ignore-requirements",
     "replace-irreversibly", "triggering":
    let pm = parseJobMode(modeName)
    if pm.isNone: raise apiErr(ErrInvalidArgs, "Job mode " & modeName & " is not supported.")
    mode = pm.get
  of "restart-dependencies":
    mode = jmReplace
  else: raise apiErr(ErrInvalidArgs, "Job mode " & modeName & " invalid.")
  if mode == jmIsolate and t != jtStart:
    raise apiErr(ErrInvalidArgs, "Isolate is only valid for start.")
  var finished = 0
  var job: Job
  try:
    job = submitJob(a.m, u, t, mode, joManual, proc(o: JobOutcome) = finished = o.job)
  except CoreError as e: raise mapCoreError(e)
  if job != nil: job.id else: finished

# ---- manager methods ------------------------------------------------------------------
proc unitRow(a: BusApi; u: Unit): DValue =
  let jid = if u.job != nil: u.job.id else: 0
  dstruct(dstr(u.id), dstr(if u.def.common.description.len > 0: u.def.common.description else: u.id),
    dstr($u.def.common.loadState), dstr($u.active), dstr(u.sub), dstr(""),
    dpath(unitPath(u.id)), duint32(jid), dstr(if u.job != nil: dbusJobType(u.job.typ) else: ""),
    dpath(if u.job != nil: jobPath(jid) else: "/"))

proc listUnits(a: BusApi; states, patterns: seq[string]): DValue =
  result = darray("(ssssssouso)")
  for u in a.m.allUnits:
    if u.kind == ukDevice: continue
    if states.len > 0 and $u.active notin states and u.sub notin states and
        $u.def.common.loadState notin states: continue
    if patterns.len > 0 and not patterns.anyIt(fnmatch(it.cstring, u.id.cstring, 0) == 0): continue
    result.items.add a.unitRow(u)

proc fileChangesValue(r: FileOpResult): DValue =
  result = darray("(sss)")
  for c in r.changes:
    case c.kind
    of fcSymlink: result.items.add dstruct(dstr("symlink"), dstr(c.link), dstr(c.target))
    of fcUnlink: result.items.add dstruct(dstr("unlink"), dstr(c.link), dstr(""))
    else: discard

proc unitFileOp(a: BusApi; op: FileOp; names: seq[string]; runtime, force: bool): FileOpResult =
  result = fileOp(a.m.roots, op, names, FileOpOptions(runtime: runtime, force: force))
  if not result.ok: raise apiErr(ErrFailed, result.error)
  discard a.m.daemonReload()

proc validEnvAssignment(s: string): bool =
  let eq = s.find('=')
  eq > 0 and s[0 ..< eq].allCharsInSet({'A'..'Z', 'a'..'z', '0'..'9', '_'}) and s[0] notin {'0'..'9'}

proc validEnvName(s: string): bool =
  s.len > 0 and s.allCharsInSet({'A'..'Z', 'a'..'z', '0'..'9', '_'}) and s[0] notin {'0'..'9'}

proc unitByPid(a: BusApi; pid: int): Unit =
  let owner = a.m.pids.getOrDefault(pid, "")
  if owner.len > 0: return a.m.units.getOrDefault(owner)
  let o = ownerOfPid(a.m, pid)
  if o.isSome: return a.m.units.getOrDefault(o.get)

proc jobTypeOfMethod(member: string): Option[JobType] =
  case member
  of "StartUnit", "StartUnitReplace", "Start": some(jtStart)
  of "StopUnit", "Stop": some(jtStop)
  of "ReloadUnit", "Reload": some(jtReload)
  of "RestartUnit", "Restart": some(jtRestart)
  of "TryRestartUnit", "TryRestart": some(jtTryRestart)
  of "ReloadOrRestartUnit", "ReloadOrRestart": some(jtReloadOrStart)
  of "ReloadOrTryRestartUnit", "ReloadOrTryRestart": some(jtTryReloadOrStart)
  else: none(JobType)

proc killWhom(s: string): KillWhom =
  case s
  of "main": kwMain
  of "control": kwControl
  of "all", "": kwAll
  else: raise apiErr(ErrInvalidArgs, "Invalid who argument " & s)

proc killUnit(a: BusApi; u: Unit; whom: string; sig: int) =
  if sig < 1 or sig > 64: raise apiErr(ErrInvalidArgs, "Signal number out of range.")
  if u.ops.kill == nil: raise apiErr(ErrJobTypeNotApplicable, "Unit " & u.id & " cannot be signalled.")
  discard u.ops.kill(a.m, u, killWhom(whom), cint(sig))

proc resetFailed(a: BusApi; u: Unit) =
  if u.active == asFailed or u.startLimit.count > 0:
    u.startLimit.count = 0
    u.startLimit.begin = 0
    if u.ops.resetFailed != nil: u.ops.resetFailed(a.m, u)
    elif u.active == asFailed: a.m.setState(u, asInactive, "dead", "success")

proc managerCall(a: BusApi; msg: Message): seq[DValue] =
  let m = a.m
  let b = msg.body
  let jt = jobTypeOfMethod(msg.member)
  if jt.isSome and msg.member.endsWith("Unit"):
    msg.expect("ss")
    let u = a.requireUnit(b[0].str)
    return @[dpath(jobPath(a.enqueue(u, jt.get, b[1].str)))]
  case msg.member
  of "GetUnit":
    msg.expect("s")
    let u = a.loaded(b[0].str)
    if u == nil: raise apiErr(ErrNoSuchUnit, "Unit " & mangle(b[0].str) & " not loaded.")
    @[dpath(unitPath(u.id))]
  of "LoadUnit":
    msg.expect("s")
    let u = m.lookup(mangle(b[0].str))
    if u == nil: raise apiErr(ErrNoSuchUnit, "Unit " & mangle(b[0].str) & " not found.")
    @[dpath(unitPath(u.id))]
  of "GetUnitByPID":
    msg.expect("u")
    let pid = int(b[0].u)
    let u = if pid > 0: a.unitByPid(pid) else: nil
    if u == nil: raise apiErr(ErrNoSuchUnit, "PID " & $pid & " does not belong to any loaded unit.")
    @[dpath(unitPath(u.id))]
  of "GetJob":
    msg.expect("u")
    let id = int(b[0].u)
    if not m.jobs.hasKey(id): raise apiErr(ErrNoSuchJob, "Job " & $id & " does not exist.")
    @[dpath(jobPath(id))]
  of "CancelJob":
    msg.expect("u")
    if not m.cancelJob(int(b[0].u)): raise apiErr(ErrNoSuchJob, "Job " & $b[0].u & " does not exist.")
    @[]
  of "ClearJobs":
    for id in toSeq(m.jobs.keys): discard m.cancelJob(id)
    @[]
  of "KillUnit":
    msg.expect("ssi")
    a.killUnit(a.requireUnit(b[0].str), b[1].str, int(b[2].i))
    @[]
  of "ResetFailedUnit":
    msg.expect("s")
    a.resetFailed(a.requireUnit(b[0].str))
    @[]
  of "ResetFailed":
    for u in m.allUnits: a.resetFailed(u)
    @[]
  of "ListUnits": @[a.listUnits(@[], @[])]
  of "ListUnitsFiltered":
    msg.expect("as")
    @[a.listUnits(b[0].strs, @[])]
  of "ListUnitsByPatterns":
    msg.expect("asas")
    @[a.listUnits(b[0].strs, b[1].strs)]
  of "ListUnitsByNames":
    msg.expect("as")
    var arr = darray("(ssssssouso)")
    for n in b[0].strs:
      let u = m.lookup(mangle(n))
      if u != nil: arr.items.add a.unitRow(u)
      else:
        arr.items.add dstruct(dstr(mangle(n)), dstr(""), dstr("not-found"), dstr("inactive"),
          dstr("dead"), dstr(""), dpath(unitPath(mangle(n))), duint32(0), dstr(""), dpath("/"))
    @[arr]
  of "ListJobs":
    var arr = darray("(usssoo)")
    for id in toSeq(m.jobs.keys).sorted:
      let j = m.jobs[id]
      arr.items.add dstruct(duint32(j.id), dstr(j.unit.id), dstr(dbusJobType(j.typ)), dstr($j.state),
        dpath(jobPath(j.id)), dpath(unitPath(j.unit.id)))
    @[arr]
  of "Subscribe", "Unsubscribe": @[]
  of "Reload":
    a.conn.signal(SdPath, IfManager, "Reloading", @[dbool(true)])
    discard m.daemonReload()
    a.conn.signal(SdPath, IfManager, "Reloading", @[dbool(false)])
    @[]
  of "SetEnvironment":
    msg.expect("as")
    let vs = b[0].strs
    for v in vs:
      if not validEnvAssignment(v): raise apiErr(ErrInvalidArgs, "Invalid environment assignment: " & v)
    for v in vs:
      let eq = v.find('=')
      m.env[v[0 ..< eq]] = v[eq + 1 .. ^1]
    @[]
  of "UnsetEnvironment":
    msg.expect("as")
    for v in b[0].strs:
      let k = if '=' in v: v[0 ..< v.find('=')] else: v
      if not validEnvName(k): raise apiErr(ErrInvalidArgs, "Invalid environment variable name: " & v)
    for v in b[0].strs:
      if '=' in v:
        let eq = v.find('=')
        if m.env.getOrDefault(v[0 ..< eq], "\0") == v[eq + 1 .. ^1]: m.env.del v[0 ..< eq]
      else: m.env.del v
    @[]
  of "UnsetAndSetEnvironment":
    msg.expect("asas")
    for v in b[0].strs:
      let k = if '=' in v: v[0 ..< v.find('=')] else: v
      if not validEnvName(k): raise apiErr(ErrInvalidArgs, "Invalid environment variable name: " & v)
    for v in b[1].strs:
      if not validEnvAssignment(v): raise apiErr(ErrInvalidArgs, "Invalid environment assignment: " & v)
    for v in b[0].strs:
      if '=' in v:
        let eq = v.find('=')
        if m.env.getOrDefault(v[0 ..< eq], "\0") == v[eq + 1 .. ^1]: m.env.del v[0 ..< eq]
      else: m.env.del v
    for v in b[1].strs:
      let eq = v.find('=')
      m.env[v[0 ..< eq]] = v[eq + 1 .. ^1]
    @[]
  of "GetDefaultTarget": @[dstr(m.defaultTarget)]
  of "GetUnitFileState":
    msg.expect("s")
    let r = fileOp(m.roots, foIsEnabled, @[b[0].str], FileOpOptions())
    if r.states.len == 0 or r.states[0][1] == esNotFound:
      raise apiErr(ErrNoSuchUnit, "Unit file " & b[0].str & " does not exist.")
    @[dstr($r.states[0][1])]
  of "ListUnitFiles", "ListUnitFilesByPatterns":
    var states, patterns: seq[string]
    if msg.member == "ListUnitFilesByPatterns":
      msg.expect("asas")
      states = b[0].strs
      patterns = b[1].strs
    var arr = darray("(ss)")
    for row in fileRows(m, @[], states, patterns):
      arr.items.add dstruct(dstr(row["path"].getStr), dstr(row["state"].getStr))
    @[arr]
  of "EnableUnitFiles", "ReenableUnitFiles":
    msg.expect("asbb")
    let op = if msg.member == "EnableUnitFiles": foEnable else: foReenable
    let r = a.unitFileOp(op, b[0].strs, b[1].b, b[2].b)
    @[dbool(true), fileChangesValue(r)]
  of "DisableUnitFiles", "MaskUnitFiles", "UnmaskUnitFiles":
    let op = case msg.member
      of "DisableUnitFiles": foDisable
      of "MaskUnitFiles": foMask
      else: foUnmask
    if msg.member == "MaskUnitFiles":
      msg.expect("asbb")
      @[fileChangesValue(a.unitFileOp(op, b[0].strs, b[1].b, b[2].b))]
    else:
      msg.expect("asb")
      @[fileChangesValue(a.unitFileOp(op, b[0].strs, b[1].b, false))]
  of "Exit":
    if m.roots.scope != scUser: raise apiErr(ErrNotSupported, "Exit is only supported for user service managers.")
    discard m.requestPower(paExit)
    @[]
  of "StartTransientUnit", "AttachProcessesToUnit", "AbandonScope", "FreezeUnit", "ThawUnit":
    raise apiErr(ErrNotSupported, msg.member & " is not supported by jumpstart-systemd-core.")
  else: raise apiErr(ErrUnknownMethod, "Unknown method " & msg.member & " or interface " & msg.iface & ".")

proc unitCall(a: BusApi; u: Unit; msg: Message): seq[DValue] =
  let b = msg.body
  let jt = jobTypeOfMethod(msg.member)
  if jt.isSome and not msg.member.endsWith("Unit"):
    msg.expect("s")
    if u.def.common.loadState == lsNotFound:
      raise apiErr(ErrNoSuchUnit, "Unit " & u.id & " not found.")
    return @[dpath(jobPath(a.enqueue(u, jt.get, b[0].str)))]
  case msg.member
  of "Kill":
    msg.expect("si")
    a.killUnit(u, b[0].str, int(b[1].i))
    @[]
  of "ResetFailed":
    a.resetFailed(u)
    @[]
  else: raise apiErr(ErrUnknownMethod, "Unknown method " & msg.member & " or interface " & msg.iface & ".")

# ---- properties and introspection ----------------------------------------------------
proc jobProps(a: BusApi; j: Job): seq[(string, DValue)] =
  @[("Id", duint32(j.id)), ("Unit", dstruct(dstr(j.unit.id), dpath(unitPath(j.unit.id)))),
    ("JobType", dstr(dbusJobType(j.typ))), ("State", dstr($j.state)),
    ("ActivationDetails", darray("(ss)"))]

proc managerPropDict(a: BusApi): DValue =
  result = darray("{sv}")
  for p in managerPropTable: result.items.add dentry(dstr(p.name), dvariant(p.get(a)))

proc getAll(a: BusApi; path, iface: string): DValue =
  if path == SdPath:
    if iface in [IfManager, ""]: return a.managerPropDict()
    raise apiErr(ErrUnknownInterface, "Unknown interface " & iface & ".")
  if path.startsWith(JobPrefix):
    let j = a.jobOfPath(path)
    if j == nil: raise apiErr(ErrUnknownObject, "Unknown object " & path & ".")
    result = darray("{sv}")
    if iface in [IfJob, ""]:
      for (k, v) in a.jobProps(j): result.items.add dentry(dstr(k), dvariant(v))
    return
  let u = a.unitOfPath(path)
  if u == nil: raise apiErr(ErrUnknownObject, "Unknown object " & path & ".")
  if iface == IfUnit: return a.propDict(u, unitPropTable)
  if iface == unitKindInterface(u.kind): return a.propDict(u, propsOfKind(u.kind))
  if iface == "":
    result = a.propDict(u, unitPropTable)
    result.items.add a.propDict(u, propsOfKind(u.kind)).items
    return
  raise apiErr(ErrUnknownInterface, "Unknown interface " & iface & ".")

proc getOne(a: BusApi; path, iface, name: string): DValue =
  let all = a.getAll(path, iface)
  for e in all.items:
    if e.fields[0].s == name: return e.fields[1].inner
  raise apiErr(ErrUnknownProperty, "Unknown property " & name & ".")

proc xmlEsc(s: string): string = s.multiReplace(("&", "&amp;"), ("<", "&lt;"), (">", "&gt;"), ("\"", "&quot;"))

const StdInterfaces = """
 <interface name="org.freedesktop.DBus.Peer">
  <method name="Ping"/>
  <method name="GetMachineId"><arg type="s" name="machine_uuid" direction="out"/></method>
 </interface>
 <interface name="org.freedesktop.DBus.Introspectable">
  <method name="Introspect"><arg name="xml_data" type="s" direction="out"/></method>
 </interface>
 <interface name="org.freedesktop.DBus.Properties">
  <method name="Get"><arg name="interface_name" direction="in" type="s"/><arg name="property_name" direction="in" type="s"/><arg name="value" direction="out" type="v"/></method>
  <method name="GetAll"><arg name="interface_name" direction="in" type="s"/><arg name="props" direction="out" type="a{sv}"/></method>
  <method name="Set"><arg name="interface_name" direction="in" type="s"/><arg name="property_name" direction="in" type="s"/><arg name="value" direction="in" type="v"/></method>
  <signal name="PropertiesChanged"><arg type="s" name="interface_name"/><arg type="a{sv}" name="changed_properties"/><arg type="as" name="invalidated_properties"/></signal>
 </interface>
"""

proc methodXml(name: string; ins: seq[(string, string)]; outs: seq[(string, string)]): string =
  result = "  <method name=\"" & name & "\">"
  for (n, t) in ins: result.add "<arg type=\"" & t & "\" name=\"" & n & "\" direction=\"in\"/>"
  for (n, t) in outs: result.add "<arg type=\"" & t & "\" name=\"" & n & "\" direction=\"out\"/>"
  result.add "</method>\n"

proc managerXml(): string =
  result = " <interface name=\"" & IfManager & "\">\n"
  for p in managerPropTable:
    result.add "  <property name=\"" & p.name & "\" type=\"" & p.sig & "\" access=\"read\"/>\n"
  for mname in ["GetUnit", "LoadUnit"]:
    result.add methodXml(mname, @[("name", "s")], @[("unit", "o")])
  result.add methodXml("GetUnitByPID", @[("pid", "u")], @[("unit", "o")])
  result.add methodXml("GetJob", @[("id", "u")], @[("job", "o")])
  for mname in ["StartUnit", "StopUnit", "ReloadUnit", "RestartUnit", "TryRestartUnit",
                "ReloadOrRestartUnit", "ReloadOrTryRestartUnit"]:
    result.add methodXml(mname, @[("name", "s"), ("mode", "s")], @[("job", "o")])
  result.add methodXml("KillUnit", @[("name", "s"), ("whom", "s"), ("signal", "i")], @[])
  result.add methodXml("ResetFailedUnit", @[("name", "s")], @[])
  result.add methodXml("ResetFailed", @[], @[])
  result.add methodXml("CancelJob", @[("id", "u")], @[])
  result.add methodXml("ClearJobs", @[], @[])
  result.add methodXml("ListUnits", @[], @[("units", "a(ssssssouso)")])
  result.add methodXml("ListUnitsFiltered", @[("states", "as")], @[("units", "a(ssssssouso)")])
  result.add methodXml("ListUnitsByPatterns", @[("states", "as"), ("patterns", "as")], @[("units", "a(ssssssouso)")])
  result.add methodXml("ListUnitsByNames", @[("names", "as")], @[("units", "a(ssssssouso)")])
  result.add methodXml("ListJobs", @[], @[("jobs", "a(usssoo)")])
  result.add methodXml("Subscribe", @[], @[])
  result.add methodXml("Unsubscribe", @[], @[])
  result.add methodXml("Reload", @[], @[])
  result.add methodXml("Exit", @[], @[])
  result.add methodXml("SetEnvironment", @[("assignments", "as")], @[])
  result.add methodXml("UnsetEnvironment", @[("names", "as")], @[])
  result.add methodXml("UnsetAndSetEnvironment", @[("names", "as"), ("assignments", "as")], @[])
  result.add methodXml("GetDefaultTarget", @[], @[("name", "s")])
  result.add methodXml("GetUnitFileState", @[("file", "s")], @[("state", "s")])
  result.add methodXml("ListUnitFiles", @[], @[("unit_files", "a(ss)")])
  result.add methodXml("ListUnitFilesByPatterns", @[("states", "as"), ("patterns", "as")], @[("unit_files", "a(ss)")])
  result.add methodXml("EnableUnitFiles", @[("files", "as"), ("runtime", "b"), ("force", "b")],
    @[("carries_install_info", "b"), ("changes", "a(sss)")])
  result.add methodXml("DisableUnitFiles", @[("files", "as"), ("runtime", "b")], @[("changes", "a(sss)")])
  result.add "  <signal name=\"UnitNew\"><arg type=\"s\" name=\"id\"/><arg type=\"o\" name=\"unit\"/></signal>\n"
  result.add "  <signal name=\"UnitRemoved\"><arg type=\"s\" name=\"id\"/><arg type=\"o\" name=\"unit\"/></signal>\n"
  result.add "  <signal name=\"JobNew\"><arg type=\"u\" name=\"id\"/><arg type=\"o\" name=\"job\"/><arg type=\"s\" name=\"unit\"/></signal>\n"
  result.add "  <signal name=\"JobRemoved\"><arg type=\"u\" name=\"id\"/><arg type=\"o\" name=\"job\"/><arg type=\"s\" name=\"unit\"/><arg type=\"s\" name=\"result\"/></signal>\n"
  result.add "  <signal name=\"Reloading\"><arg type=\"b\" name=\"active\"/></signal>\n"
  result.add " </interface>\n"

proc unitXml(k: UnitKind): string =
  result = " <interface name=\"" & IfUnit & "\">\n"
  for p in unitPropTable:
    result.add "  <property name=\"" & p.name & "\" type=\"" & p.sig & "\" access=\"read\"/>\n"
  for mname in ["Start", "Stop", "Reload", "Restart", "TryRestart", "ReloadOrRestart", "ReloadOrTryRestart"]:
    result.add methodXml(mname, @[("mode", "s")], @[("job", "o")])
  result.add methodXml("Kill", @[("whom", "s"), ("signal", "i")], @[])
  result.add methodXml("ResetFailed", @[], @[])
  result.add " </interface>\n <interface name=\"" & unitKindInterface(k) & "\">\n"
  for p in propsOfKind(k):
    result.add "  <property name=\"" & p.name & "\" type=\"" & p.sig & "\" access=\"read\"/>\n"
  result.add " </interface>\n"

const JobXml = """ <interface name="org.freedesktop.systemd1.Job">
  <method name="Cancel"/>
  <property name="Id" type="u" access="read"/>
  <property name="Unit" type="(so)" access="read"/>
  <property name="JobType" type="s" access="read"/>
  <property name="State" type="s" access="read"/>
  <property name="ActivationDetails" type="a(ss)" access="read"/>
 </interface>
"""

proc introspect(a: BusApi; path: string): string =
  result = "<!DOCTYPE node PUBLIC \"-//freedesktop//DTD D-BUS Object Introspection 1.0//EN\"\n" &
    "\"http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd\">\n<node>\n" & StdInterfaces
  if path == "/" : result.add " <node name=\"org\"/>\n"
  elif path == "/org": result.add " <node name=\"freedesktop\"/>\n"
  elif path == "/org/freedesktop": result.add " <node name=\"systemd1\"/>\n"
  elif path == SdPath:
    result.add managerXml()
    result.add " <node name=\"unit\"/>\n <node name=\"job\"/>\n"
  elif path == SdPath & "/unit":
    for u in a.m.allUnits:
      if u.kind != ukDevice: result.add " <node name=\"" & xmlEsc(labelEscape(u.id)) & "\"/>\n"
  elif path == SdPath & "/job":
    for id in toSeq(a.m.jobs.keys).sorted: result.add " <node name=\"" & $id & "\"/>\n"
  elif path.startsWith(JobPrefix):
    if a.jobOfPath(path) == nil: raise apiErr(ErrUnknownObject, "Unknown object " & path & ".")
    result.add JobXml
  else:
    let u = a.unitOfPath(path)
    if u == nil: raise apiErr(ErrUnknownObject, "Unknown object " & path & ".")
    result.add unitXml(u.kind)
  result.add "</node>\n"

# ---- dispatch -------------------------------------------------------------------------
proc handleCall(a: BusApi; msg: Message): seq[DValue] =
  let path = msg.path
  case msg.iface
  of IfPeer:
    case msg.member
    of "Ping": return @[]
    of "GetMachineId": return @[dstr(a.m.machineId)]
    else: raise apiErr(ErrUnknownMethod, "Unknown method " & msg.member & ".")
  of IfIntro:
    if msg.member != "Introspect": raise apiErr(ErrUnknownMethod, "Unknown method " & msg.member & ".")
    return @[dstr(a.introspect(path))]
  of IfProps:
    case msg.member
    of "Get":
      msg.expect("ss")
      return @[dvariant(a.getOne(path, msg.body[0].str, msg.body[1].str))]
    of "GetAll":
      msg.expect("s")
      return @[a.getAll(path, msg.body[0].str)]
    of "Set":
      raise apiErr(ErrPropertyReadOnly, "Property is read-only; use SetUnitProperties.")
    else: raise apiErr(ErrUnknownMethod, "Unknown method " & msg.member & ".")
  else: discard
  if path == SdPath:
    if msg.iface notin [IfManager, ""]:
      raise apiErr(ErrUnknownInterface, "Unknown interface " & msg.iface & ".")
    return a.managerCall(msg)
  if path.startsWith(JobPrefix):
    let j = a.jobOfPath(path)
    if j == nil: raise apiErr(ErrUnknownObject, "Unknown object " & path & ".")
    if msg.member == "Cancel" and msg.iface in [IfJob, ""]:
      discard a.m.cancelJob(j.id)
      return @[]
    raise apiErr(ErrUnknownMethod, "Unknown method " & msg.member & ".")
  if path.startsWith(UnitPrefix):
    let u = a.unitOfPath(path)
    if u == nil: raise apiErr(ErrUnknownObject, "Unknown object " & path & ".")
    if msg.iface notin [IfUnit, "", unitKindInterface(u.kind)]:
      raise apiErr(ErrUnknownInterface, "Unknown interface " & msg.iface & ".")
    return a.unitCall(u, msg)
  raise apiErr(ErrUnknownObject, "Unknown object " & path & ".")

proc activationFailure(a: BusApi; unit, name, text: string) =
  if not a.ready: return
  a.conn.signal(SdPath, IfActivator, "ActivationFailure",
    @[dstr(unit), dstr(name), dstr(text)], destination = BusName)

type BusServiceFile* = object
  path*, name*, exec*: string

proc busServiceDirs*(m: Manager): seq[string] =
  ## Session bus service directories (D-Bus specification, "Message Bus
  ## Starting Services"): $XDG_DATA_HOME, $XDG_DATA_DIRS, then the
  ## distribution's /usr/share (roots.usrShare), each with dbus-1/services.
  let dataHome = m.env.getOrDefault("XDG_DATA_HOME", m.roots.home / ".local/share")
  if dataHome.len > 0: result.add dataHome / "dbus-1/services"
  let dataDirs = m.env.getOrDefault("XDG_DATA_DIRS", "/usr/local/share:/usr/share")
  for d in dataDirs.split(':'):
    if d.len > 0 and d.isAbsolute and (d / "dbus-1/services") notin result:
      result.add d / "dbus-1/services"
  if (m.roots.usrShare / "dbus-1/services") notin result: result.add m.roots.usrShare / "dbus-1/services"

proc findBusServiceFor*(dirs: seq[string]; unit: string): Option[BusServiceFile] =
  ## The first `*.service` whose [D-BUS Service] names `unit` in
  ## SystemdService= (directories in priority order).
  for d in dirs:
    if not dirExists(d): continue
    var files: seq[string]
    for kind, f in walkDir(d):
      if kind in {pcFile, pcLinkToFile} and f.endsWith(".service"): files.add f
    files.sort()
    for f in files:
      var name, exec, sd: string
      var inSection = false
      try:
        for raw in readFile(f).splitLines:
          let line = raw.strip
          if line.startsWith("["):
            inSection = line == "[D-BUS Service]"
            continue
          if not inSection or line.len == 0 or line[0] == '#': continue
          let eq = line.find('=')
          if eq <= 0: continue
          case line[0 ..< eq].strip
          of "Name": name = line[eq + 1 .. ^1].strip
          of "Exec": exec = line[eq + 1 .. ^1].strip
          of "SystemdService": sd = line[eq + 1 .. ^1].strip
          else: discard
      except IOError: continue
      if sd == unit and name.len > 0 and exec.len > 0:
        return some(BusServiceFile(path: f, name: name, exec: exec))

proc transientFromBusService*(unit: string; svc: BusServiceFile): string =
  ## A service unit equivalent to what dbus-daemon itself would run (Exec=).
  let exec = svc.exec.replace("%", "%%").replace("$", "$$")
  "[Unit]\nDescription=" & svc.name & " (D-Bus activated, from " & svc.path & ")\n" &
    "CollectMode=inactive-or-failed\n\n[Service]\nType=dbus\nBusName=" & svc.name &
    "\nExecStart=" & exec & "\n"

proc watchActivation(a: BusApi; unit: string) =
  ## Type=dbus runs as Type=exec here (the bus name is not tracked), so a
  ## bus-activated service that dies before taking its name would leave the
  ## caller waiting for dbus-daemon's activation timeout. A unit that fails
  ## or stops within ActivationWatchUsec of the request is reported with
  ## ActivationFailure; dbus-daemon ignores it when the name was already
  ## acquired (no pending activation is left).
  let m = a.m
  let id = m.canonical(mangle(unit))
  var sub: Subscription
  var done = false
  var timer: TimerId
  var started = false
  proc finish() =
    if done: return
    done = true
    m.subscribers.keepItIf(it != sub)
    m.loop.cancelTimer(timer)
  sub = Subscription(id: -2, patterns: @[id, mangle(unit)], cb: proc(ev: StateEvent) =
    if done: return
    if ev.active in {asActivating, asActive}: started = true
    elif ev.active == asFailed or (started and ev.active == asInactive):
      let text = "Unit " & unit & " " & (if ev.active == asFailed: "failed" else: "stopped") &
        " before taking its bus name (" & ev.result & ")."
      m.loop.afterEvent(proc() =
        finish()
        a.activationFailure(unit, "org.freedesktop.systemd1.UnitFailed", text)))
  m.subscribers.add sub
  timer = m.loop.addTimerIn(ActivationWatchUsec, proc() = finish())

proc activationRequest(a: BusApi; unit: string) =
  ## dbus-daemon --systemd-activation asks for the unit named in a service
  ## file's SystemdService=. Not a manual start (RefuseManualStart= does not
  ## apply, as in systemd).
  ##
  ## Kreato packages are built without systemd, so several D-Bus services
  ## (dconf, xdg-desktop-portal-gnome, colord-session, ...) name a unit their
  ## package does not install. systemd would fail the activation; here the
  ## service runs as a transient unit made from the service file's Exec=,
  ## which is what dbus-daemon itself would have run.
  let u = a.m.lookup(mangle(unit))
  if u == nil or u.def.common.loadState == lsNotFound:
    let pn = parseUnitName(unit)
    let svc = if pn.isNone or pn.get.isTemplate or pn.get.kind != ukService: none(BusServiceFile)
              else: findBusServiceFor(busServiceDirs(a.m), unit)
    if svc.isNone:
      a.activationFailure(unit, ErrNoSuchUnit, "Unit " & unit & " not found.")
      return
    logInfo(unit, "bus activation request; no unit file, running " & svc.get.exec & " from " & svc.get.path)
    a.watchActivation(unit)
    try:
      startTransient(a.m, @[TransientUnit(name: unit, text: transientFromBusService(unit, svc.get))],
        unit, collect = true, waitStart = true, waitExit = false, proc(r: TransientResult) =
          if not r.ok: a.activationFailure(unit, "org.freedesktop.systemd1.UnitFailed",
            if r.message.len > 0: r.message else: "Unit " & unit & " failed."))
    except CoreError as e:
      let err = mapCoreError(e)
      a.activationFailure(unit, err.errName, err.msg)
    return
  logInfo(u.id, "bus activation request")
  a.watchActivation(unit)
  try:
    discard submitJob(a.m, u, jtStart, jmReplace, joDependency, proc(o: JobOutcome) =
      if o.result notin {jrDone, jrSkipped}:
        a.activationFailure(unit, "org.freedesktop.systemd1.UnitFailed",
          if o.message.len > 0: o.message else: "Unit " & unit & " failed."))
  except CoreError as e:
    let err = mapCoreError(e)
    a.activationFailure(unit, err.errName, err.msg)

proc onMessage(a: BusApi; msg: Message) =
  case msg.typ
  of mtSignal:
    if msg.iface == IfActivator and msg.member == "ActivationRequest" and msg.sender == BusName and
        msg.signature == "s":
      a.activationRequest(msg.body[0].str)
  of mtMethodCall:
    a.conn.hold()
    try:
      let body = a.handleCall(msg)
      a.conn.reply(msg, body)
    except ApiError as e:
      a.conn.replyError(msg, e.errName, e.msg)
    except CoreError as e:
      let err = mapCoreError(e)
      a.conn.replyError(msg, err.errName, err.msg)
    except CatchableError as e:
      logWarn("", "D-Bus " & msg.member & " failed: " & e.msg)
      a.conn.replyError(msg, ErrFailed, e.msg)
    finally:
      if a.conn != nil: a.conn.release()
  else: discard

# ---- connection management ------------------------------------------------------------
proc scheduleRetry(a: BusApi)

proc tryConnect*(a: BusApi): bool =
  ## Connects, authenticates, says Hello and takes org.freedesktop.systemd1.
  ## Blocking but short (a local bus answers in microseconds).
  if a.ready or not a.enabled: return a.ready
  var st: Stat
  if lstat(a.socketPath.cstring, st) != 0 or not S_ISSOCK(st.st_mode): return false
  let fd = connectUnixSocket(a.socketPath)
  if fd < 0: return false
  let c = newBusConn(fd, a.m.loop)
  try:
    authenticate(fd, a.uid)
    c.hello()
    let r = c.requestName(SdName, 4)      # DBUS_NAME_FLAG_DO_NOT_QUEUE
    if r notin [1'u32, 4'u32]:
      raise newException(IOError, "org.freedesktop.systemd1 is owned by another connection")
  except CatchableError as e:
    if e.msg != a.lastFailure:
      logWarn("", "cannot provide " & SdName & " on " & a.socketPath & ": " & e.msg)
      a.lastFailure = e.msg
    c.onClose = nil
    c.close()
    return false
  a.lastFailure = ""
  a.conn = c
  a.announced.clear()
  c.onMessage = proc(msg: Message) = a.onMessage(msg)
  c.onClose = proc() =
    if a.conn == c:
      a.conn = nil
      logInfo("", "session bus connection closed")
      a.scheduleRetry()
  c.start()
  logInfo("", "providing " & SdName & " on " & a.socketPath & " as " & c.uniqueName)
  true

proc scheduleRetry(a: BusApi) =
  if a.retry.isSet or not a.enabled: return
  a.retry = a.m.loop.addTimerIn(RetryUsec, proc() =
    a.retry = TimerId(0)
    if not a.ready and not a.tryConnect(): a.scheduleRetry())

proc queueConnect(a: BusApi) =
  if a.connectQueued or a.ready: return
  a.connectQueued = true
  a.m.loop.afterEvent(proc() =
    a.connectQueued = false
    discard a.tryConnect())

proc newBusApi*(m: Manager; socketPath: string; uid = geteuid()): BusApi =
  BusApi(m: m, socketPath: socketPath, uid: uid, enabled: true)

proc install*(a: BusApi) =
  ## Hooks the API into the manager: unit state changes and jobs become
  ## signals, and a unit that brings up the bus (dbus.socket, dbus.service,
  ## dbus-broker.service) triggers an immediate connection attempt, so the
  ## name is owned before the start job that started the bus completes.
  let m = a.m
  m.subscribers.add Subscription(id: -1, patterns: @[], cb: proc(ev: StateEvent) =
    let u = m.units.getOrDefault(ev.unit)
    if u != nil: a.emitUnitChanged(u)
    if ev.active == asActive and ev.unit in ["dbus.socket", "dbus.service", "dbus-broker.service"]:
      a.queueConnect())
  let prevInstalled = m.jobInstalledHook
  m.jobInstalledHook = proc(j: Job) =
    if prevInstalled != nil: prevInstalled(j)
    a.emitJobNew(j)
  let prevFinished = m.jobFinishedHook
  m.jobFinishedHook = proc(o: JobOutcome) =
    if prevFinished != nil: prevFinished(o)
    a.emitJobRemoved(o)
  if not a.tryConnect(): a.scheduleRetry()

proc installBusApi*(m: Manager): BusApi =
  ## User scope: the session bus at $XDG_RUNTIME_DIR/bus, the path a user
  ## dbus.service listens on and that GLib and libdbus use when
  ## DBUS_SESSION_BUS_ADDRESS is unset.
  if m.roots.scope != scUser or m.roots.runtime.len == 0: return nil
  let socketPath = m.roots.runtime / "bus"
  # systemd's user manager exports the session bus address to its units.
  if not m.env.hasKey("DBUS_SESSION_BUS_ADDRESS"):
    m.env["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=" & socketPath
  result = newBusApi(m, socketPath)
  result.install()
