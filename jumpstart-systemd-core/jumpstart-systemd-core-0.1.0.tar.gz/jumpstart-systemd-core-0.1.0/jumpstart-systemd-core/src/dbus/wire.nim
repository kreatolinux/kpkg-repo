## D-Bus wire format (D-Bus specification, "Message Protocol"): typed
## values, signatures, little-endian marshalling and message framing. Pure
## Nim, no libdbus: the manager's bus client (dbus/busconn.nim) and the
## `org.freedesktop.systemd1` API (dbus/sd1api.nim) are built on it.
##
## Only what a service manager needs: every basic type, arrays, structs,
## dict entries and variants. Unix file descriptors (`h`) are parsed as
## their index; the client never negotiates descriptor passing.
import std/[strutils]

type
  DKind* = enum
    dByte = "y", dBool = "b", dInt16 = "n", dUint16 = "q", dInt32 = "i",
    dUint32 = "u", dInt64 = "x", dUint64 = "t", dDouble = "d", dString = "s",
    dObjPath = "o", dSignature = "g", dUnixFd = "h", dArray = "a",
    dStruct = "(", dDictEntry = "{", dVariant = "v"

  DValue* = ref object
    case kind*: DKind
    of dByte, dUint16, dUint32, dUint64, dUnixFd: u*: uint64
    of dBool: b*: bool
    of dInt16, dInt32, dInt64: i*: int64
    of dDouble: d*: float64
    of dString, dObjPath, dSignature: s*: string
    of dArray:
      elemSig*: string      ## signature of one element
      items*: seq[DValue]
    of dStruct, dDictEntry: fields*: seq[DValue]
    of dVariant: inner*: DValue

  DBusWireError* = object of ValueError

  MsgType* = enum
    mtInvalid = 0, mtMethodCall = 1, mtMethodReturn = 2, mtError = 3, mtSignal = 4

  Message* = object
    typ*: MsgType
    flags*: uint8
    serial*: uint32
    path*, iface*, member*, errorName*, destination*, sender*: string
    replySerial*: uint32
    signature*: string
    body*: seq[DValue]

const
  FlagNoReplyExpected* = 0x1'u8
  FlagNoAutoStart* = 0x2'u8
  MaxMessageSize* = 64 * 1024 * 1024
  MaxDepth = 64

proc wireErr(msg: string) {.noreturn.} = raise newException(DBusWireError, msg)

# ---- constructors ---------------------------------------------------------------
proc dbyte*(v: uint8): DValue = DValue(kind: dByte, u: v)
proc dbool*(v: bool): DValue = DValue(kind: dBool, b: v)
proc dint32*(v: int): DValue = DValue(kind: dInt32, i: v)
proc duint32*(v: uint32): DValue = DValue(kind: dUint32, u: v)
proc duint32*(v: int): DValue = DValue(kind: dUint32, u: uint64(max(v, 0)))
proc dint64*(v: int64): DValue = DValue(kind: dInt64, i: v)
proc duint64*(v: uint64): DValue = DValue(kind: dUint64, u: v)
proc duint64*(v: int64): DValue = DValue(kind: dUint64, u: uint64(max(v, 0)))
proc ddouble*(v: float64): DValue = DValue(kind: dDouble, d: v)
proc dstr*(v: string): DValue = DValue(kind: dString, s: v)
proc dpath*(v: string): DValue = DValue(kind: dObjPath, s: v)
proc dsig*(v: string): DValue = DValue(kind: dSignature, s: v)
proc darray*(elemSig: string; items: seq[DValue] = @[]): DValue =
  DValue(kind: dArray, elemSig: elemSig, items: items)
proc dstruct*(fields: varargs[DValue]): DValue = DValue(kind: dStruct, fields: @fields)
proc dentry*(k, v: DValue): DValue = DValue(kind: dDictEntry, fields: @[k, v])
proc dvariant*(v: DValue): DValue = DValue(kind: dVariant, inner: v)
proc dstrs*(v: openArray[string]): DValue =
  result = darray("s")
  for x in v: result.items.add dstr(x)

# ---- signatures -------------------------------------------------------------------
proc signatureOf*(v: DValue): string =
  case v.kind
  of dArray: "a" & v.elemSig
  of dStruct:
    var s = "("
    for f in v.fields: s.add signatureOf(f)
    s & ")"
  of dDictEntry: "{" & signatureOf(v.fields[0]) & signatureOf(v.fields[1]) & "}"
  else: $v.kind

proc signatureOf*(vs: openArray[DValue]): string =
  for v in vs: result.add signatureOf(v)

proc completeTypeEnd(sig: string; pos: int; depth = 0): int =
  ## Index just past the single complete type starting at `pos`.
  if depth > MaxDepth: wireErr("signature nests too deeply")
  if pos >= sig.len: wireErr("signature ends early: " & sig)
  case sig[pos]
  of 'y', 'b', 'n', 'q', 'i', 'u', 'x', 't', 'd', 's', 'o', 'g', 'h', 'v': pos + 1
  of 'a':
    if pos + 1 < sig.len and sig[pos + 1] == '{':
      var p = completeTypeEnd(sig, pos + 2, depth + 1)          # key: basic
      p = completeTypeEnd(sig, p, depth + 1)
      if p >= sig.len or sig[p] != '}': wireErr("bad dict entry in signature " & sig)
      p + 1
    else: completeTypeEnd(sig, pos + 1, depth + 1)
  of '(':
    var p = pos + 1
    if p < sig.len and sig[p] == ')': wireErr("empty struct in signature " & sig)
    while p < sig.len and sig[p] != ')': p = completeTypeEnd(sig, p, depth + 1)
    if p >= sig.len: wireErr("unterminated struct in signature " & sig)
    p + 1
  else: wireErr("bad type code '" & sig[pos] & "' in signature " & sig)

proc splitSignature*(sig: string): seq[string] =
  ## The complete types of a signature, in order. Raises on a malformed one.
  var p = 0
  while p < sig.len:
    let e = completeTypeEnd(sig, p)
    result.add sig[p ..< e]
    p = e

proc validSignature*(sig: string): bool =
  if sig.len > 255: return false
  try:
    discard splitSignature(sig)
    true
  except DBusWireError: false

proc alignmentOf(code: char): int =
  case code
  of 'y', 'g', 'v': 1
  of 'n', 'q': 2
  of 'b', 'i', 'u', 's', 'o', 'a', 'h': 4
  of 'x', 't', 'd', '(', '{': 8
  else: 1

# ---- marshalling ----------------------------------------------------------------
proc pad(buf: var string; align: int) =
  while buf.len mod align != 0: buf.add '\0'

proc putU32(buf: var string; v: uint32) =
  for i in 0 .. 3: buf.add char((v shr (8 * i)) and 0xff)

proc putU16(buf: var string; v: uint16) =
  for i in 0 .. 1: buf.add char((v shr (8 * i)) and 0xff)

proc putU64(buf: var string; v: uint64) =
  for i in 0 .. 7: buf.add char((v shr (8 * i)) and 0xff)

proc validObjectPath*(p: string): bool =
  if p.len == 0 or p[0] != '/': return false
  if p == "/": return true
  if p[^1] == '/': return false
  var prevSlash = false
  for c in p:
    if c == '/':
      if prevSlash: return false
      prevSlash = true
    else:
      prevSlash = false
      if c notin {'A'..'Z', 'a'..'z', '0'..'9', '_'}: return false
  true

proc marshal*(buf: var string; v: DValue; depth = 0) =
  ## Appends `v` to `buf`; alignment is relative to the start of `buf`, which
  ## must itself start at an 8-aligned offset of the message.
  if depth > MaxDepth: wireErr("value nests too deeply")
  case v.kind
  of dByte: buf.add char(v.u and 0xff)
  of dBool:
    buf.pad 4
    buf.putU32(if v.b: 1 else: 0)
  of dInt16:
    buf.pad 2
    buf.putU16(cast[uint16](int16(v.i)))
  of dUint16:
    buf.pad 2
    buf.putU16(uint16(v.u))
  of dInt32:
    buf.pad 4
    buf.putU32(cast[uint32](int32(v.i)))
  of dUint32, dUnixFd:
    buf.pad 4
    buf.putU32(uint32(v.u))
  of dInt64:
    buf.pad 8
    buf.putU64(cast[uint64](v.i))
  of dUint64:
    buf.pad 8
    buf.putU64(v.u)
  of dDouble:
    buf.pad 8
    buf.putU64(cast[uint64](v.d))
  of dString, dObjPath:
    if '\0' in v.s: wireErr("string contains NUL")
    if v.kind == dObjPath and not validObjectPath(v.s): wireErr("invalid object path " & v.s)
    buf.pad 4
    buf.putU32(uint32(v.s.len))
    buf.add v.s
    buf.add '\0'
  of dSignature:
    if v.s.len > 255: wireErr("signature too long")
    buf.add char(v.s.len)
    buf.add v.s
    buf.add '\0'
  of dArray:
    buf.pad 4
    let lenAt = buf.len
    buf.putU32(0)
    buf.pad alignmentOf(if v.elemSig.len > 0: v.elemSig[0] else: 'y')
    let start = buf.len
    for it in v.items:
      if signatureOf(it) != v.elemSig:
        wireErr("array element of type " & signatureOf(it) & " in a" & v.elemSig)
      marshal(buf, it, depth + 1)
    let n = uint32(buf.len - start)
    for i in 0 .. 3: buf[lenAt + i] = char((n shr (8 * i)) and 0xff)
  of dStruct, dDictEntry:
    buf.pad 8
    for f in v.fields: marshal(buf, f, depth + 1)
  of dVariant:
    let s = signatureOf(v.inner)
    marshal(buf, dsig(s), depth + 1)
    marshal(buf, v.inner, depth + 1)

# ---- unmarshalling ----------------------------------------------------------------
type Reader = object
  data: string
  pos: int
  base: int      ## offset that alignment is relative to

proc align(r: var Reader; a: int) =
  while (r.pos - r.base) mod a != 0:
    if r.pos >= r.data.len: wireErr("truncated padding")
    if r.data[r.pos] != '\0': wireErr("non-zero padding")
    inc r.pos

proc need(r: Reader; n: int) =
  if n < 0 or r.pos + n > r.data.len: wireErr("message truncated")

proc getU32(r: var Reader): uint32 =
  r.need 4
  for i in 0 .. 3: result = result or (uint32(ord(r.data[r.pos + i])) shl (8 * i))
  r.pos += 4

proc getU16(r: var Reader): uint16 =
  r.need 2
  result = uint16(ord(r.data[r.pos])) or (uint16(ord(r.data[r.pos + 1])) shl 8)
  r.pos += 2

proc getU64(r: var Reader): uint64 =
  r.need 8
  for i in 0 .. 7: result = result or (uint64(ord(r.data[r.pos + i])) shl (8 * i))
  r.pos += 8

proc unmarshal(r: var Reader; sig: string; depth: int): DValue =
  if depth > MaxDepth: wireErr("value nests too deeply")
  case sig[0]
  of 'y':
    r.need 1
    result = dbyte(uint8(ord(r.data[r.pos])))
    inc r.pos
  of 'b':
    r.align 4
    let v = r.getU32
    if v > 1: wireErr("boolean out of range")
    result = dbool(v == 1)
  of 'n':
    r.align 2
    result = DValue(kind: dInt16, i: int64(cast[int16](r.getU16)))
  of 'q':
    r.align 2
    result = DValue(kind: dUint16, u: r.getU16)
  of 'i':
    r.align 4
    result = DValue(kind: dInt32, i: int64(cast[int32](r.getU32)))
  of 'u':
    r.align 4
    result = DValue(kind: dUint32, u: r.getU32)
  of 'h':
    r.align 4
    result = DValue(kind: dUnixFd, u: r.getU32)
  of 'x':
    r.align 8
    result = DValue(kind: dInt64, i: cast[int64](r.getU64))
  of 't':
    r.align 8
    result = DValue(kind: dUint64, u: r.getU64)
  of 'd':
    r.align 8
    result = DValue(kind: dDouble, d: cast[float64](r.getU64))
  of 's', 'o':
    r.align 4
    let n = int(r.getU32)
    r.need n + 1
    let s = r.data[r.pos ..< r.pos + n]
    if r.data[r.pos + n] != '\0': wireErr("string not NUL-terminated")
    r.pos += n + 1
    if sig[0] == 'o':
      if not validObjectPath(s): wireErr("invalid object path " & s)
      result = dpath(s)
    else: result = dstr(s)
  of 'g':
    r.need 1
    let n = ord(r.data[r.pos])
    inc r.pos
    r.need n + 1
    let s = r.data[r.pos ..< r.pos + n]
    r.pos += n + 1
    result = dsig(s)
  of 'v':
    let s = unmarshal(r, "g", depth + 1).s
    let parts = splitSignature(s)
    if parts.len != 1: wireErr("variant signature is not one complete type: " & s)
    result = dvariant(unmarshal(r, s, depth + 1))
  of 'a':
    r.align 4
    let n = int(r.getU32)
    if n > MaxMessageSize: wireErr("array too long")
    let elem = sig[1 .. ^1]
    r.align alignmentOf(elem[0])
    let stop = r.pos + n
    r.need n
    result = darray(elem)
    while r.pos < stop:
      result.items.add unmarshal(r, elem, depth + 1)
    if r.pos != stop: wireErr("array length mismatch")
  of '(':
    r.align 8
    result = DValue(kind: dStruct)
    for part in splitSignature(sig[1 ..< sig.len - 1]):
      result.fields.add unmarshal(r, part, depth + 1)
  of '{':
    r.align 8
    let parts = splitSignature(sig[1 ..< sig.len - 1])
    if parts.len != 2: wireErr("dict entry must have two fields")
    result = DValue(kind: dDictEntry)
    for part in parts: result.fields.add unmarshal(r, part, depth + 1)
  else: wireErr("bad type code " & sig[0])

proc unmarshalBody*(data: string; sig: string): seq[DValue] =
  ## Decodes a whole body (alignment relative to its first byte).
  var r = Reader(data: data, pos: 0, base: 0)
  for part in splitSignature(sig):
    result.add unmarshal(r, part, 0)
  if r.pos != data.len: wireErr("trailing bytes after body")

proc marshalBody*(vs: openArray[DValue]): string =
  for v in vs: marshal(result, v)

# ---- messages ---------------------------------------------------------------------
proc encode*(msg: Message): string =
  ## The complete little-endian message.
  let body = marshalBody(msg.body)
  var fields = darray("(yv)")
  proc field(code: uint8; v: DValue) = fields.items.add dstruct(dbyte(code), dvariant(v))
  if msg.path.len > 0: field(1, dpath(msg.path))
  if msg.iface.len > 0: field(2, dstr(msg.iface))
  if msg.member.len > 0: field(3, dstr(msg.member))
  if msg.errorName.len > 0: field(4, dstr(msg.errorName))
  if msg.replySerial != 0: field(5, duint32(msg.replySerial))
  if msg.destination.len > 0: field(6, dstr(msg.destination))
  if msg.sender.len > 0: field(7, dstr(msg.sender))
  let sig = signatureOf(msg.body)
  if sig.len > 0: field(8, dsig(sig))
  result.add 'l'
  result.add char(ord(msg.typ))
  result.add char(msg.flags)
  result.add char(1)
  result.putU32(uint32(body.len))
  result.putU32(msg.serial)
  marshal(result, fields)
  result.pad 8
  result.add body
  if result.len > MaxMessageSize: wireErr("message too large")

proc messageLength*(data: string; start = 0): int =
  ## Total length of the message starting at `start` once its 16-byte fixed
  ## header is available; -1 when fewer than 16 bytes are there.
  if data.len - start < 16: return -1
  if data[start] != 'l': wireErr("only little-endian messages are supported")
  var r = Reader(data: data, pos: start + 4, base: start)
  let bodyLen = int(r.getU32)
  r.pos = start + 12
  let fieldsLen = int(r.getU32)
  if bodyLen > MaxMessageSize or fieldsLen > MaxMessageSize: wireErr("message too large")
  var headerEnd = 16 + fieldsLen
  while headerEnd mod 8 != 0: inc headerEnd
  result = headerEnd + bodyLen
  if result > MaxMessageSize: wireErr("message too large")

proc decode*(data: string): Message =
  ## Decodes one complete message (exactly `messageLength` bytes).
  if data.len < 16: wireErr("message truncated")
  if data[0] != 'l': wireErr("only little-endian messages are supported")
  let t = ord(data[1])
  if t < 1 or t > 4: wireErr("unknown message type " & $t)
  result.typ = MsgType(t)
  result.flags = uint8(ord(data[2]))
  if ord(data[3]) != 1: wireErr("unsupported protocol version")
  var r = Reader(data: data, pos: 4, base: 0)
  let bodyLen = int(r.getU32)
  result.serial = r.getU32
  if result.serial == 0: wireErr("serial must not be zero")
  let fields = unmarshal(r, "a(yv)", 0)
  r.align 8
  for f in fields.items:
    let code = f.fields[0].u
    let v = f.fields[1].inner
    case code
    of 1: (if v.kind == dObjPath: result.path = v.s)
    of 2: (if v.kind == dString: result.iface = v.s)
    of 3: (if v.kind == dString: result.member = v.s)
    of 4: (if v.kind == dString: result.errorName = v.s)
    of 5: (if v.kind == dUint32: result.replySerial = uint32(v.u))
    of 6: (if v.kind == dString: result.destination = v.s)
    of 7: (if v.kind == dString: result.sender = v.s)
    of 8: (if v.kind == dSignature: result.signature = v.s)
    else: discard
  if r.pos + bodyLen != data.len: wireErr("body length mismatch")
  result.body = unmarshalBody(data[r.pos ..< data.len], result.signature)

# ---- helpers --------------------------------------------------------------------
proc str*(v: DValue): string =
  if v == nil or v.kind notin {dString, dObjPath, dSignature}: wireErr("expected a string")
  v.s

proc strs*(v: DValue): seq[string] =
  if v == nil or v.kind != dArray: wireErr("expected an array")
  for it in v.items: result.add it.str

proc `$`*(v: DValue): string =
  ## Debug rendering, GVariant-like.
  if v == nil: return "nil"
  case v.kind
  of dByte, dUint16, dUint32, dUint64, dUnixFd: $v.u
  of dBool: $v.b
  of dInt16, dInt32, dInt64: $v.i
  of dDouble: $v.d
  of dString, dSignature: "'" & v.s & "'"
  of dObjPath: "objectpath '" & v.s & "'"
  of dArray:
    var parts: seq[string]
    for it in v.items: parts.add $it
    "[" & parts.join(", ") & "]"
  of dStruct:
    var parts: seq[string]
    for it in v.fields: parts.add $it
    "(" & parts.join(", ") & ")"
  of dDictEntry: $v.fields[0] & ": " & $v.fields[1]
  of dVariant: "<" & $v.inner & ">"

proc labelEscape*(s: string): string =
  ## systemd's bus_label_escape: object path element for a unit name. Every
  ## byte outside [A-Za-z0-9] (and a leading digit) becomes `_xx`.
  if s.len == 0: return "_"
  for i, c in s:
    if c in {'A'..'Z', 'a'..'z'} or (i > 0 and c in {'0'..'9'}): result.add c
    else: result.add "_" & toHex(ord(c), 2).toLowerAscii

proc labelUnescape*(s: string): string =
  if s == "_": return ""
  var i = 0
  while i < s.len:
    if s[i] == '_' and i + 2 < s.len + 0 and i + 2 <= s.len - 1:
      try:
        result.add char(parseHexInt(s[i + 1 .. i + 2]))
        i += 3
        continue
      except ValueError: discard
    result.add s[i]
    inc i
