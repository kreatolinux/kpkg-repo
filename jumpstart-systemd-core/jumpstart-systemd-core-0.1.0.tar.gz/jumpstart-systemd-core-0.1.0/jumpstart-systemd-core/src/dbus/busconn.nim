## A D-Bus client connection driven by the manager's event loop: SASL
## EXTERNAL authentication, `Hello`, non-blocking reads and buffered writes,
## replies matched to calls by serial, and a short blocking `callSync` for
## the start-up handshake (D-Bus specification, "Authentication Protocol",
## "Message Bus Specification").
import std/[posix, strutils, tables]
import ../engine/eventloop
import ./wire

type
  ReplyHandler* = proc(reply: Message) {.closure.}
  BusConn* = ref object
    fd*: cint
    loop: EventLoop
    watch: WatchId
    watching: bool
    rbuf, wbuf: string
    serial: uint32
    uniqueName*: string
    pending: Table[uint32, ReplyHandler]
    backlog: seq[Message]            ## messages read during callSync, dispatched later
    onMessage*: proc(msg: Message) {.closure.}   ## method calls and signals
    onClose*: proc() {.closure.}
    closed*: bool
    holdDepth: int                    ## >0: outgoing signals wait (see `hold`)
    held: seq[string]

  BusError* = object of IOError
    errName*: string                  ## D-Bus error name for error replies

const
  BusName* = "org.freedesktop.DBus"
  BusPath* = "/org/freedesktop/DBus"

proc busErr(msg: string; name = ""): ref BusError =
  result = newException(BusError, msg)
  result.errName = name

proc setNonBlocking(fd: cint) =
  let fl = fcntl(fd, F_GETFL)
  discard fcntl(fd, F_SETFL, fl or O_NONBLOCK)

proc monoMs(): int64 =
  var ts: Timespec
  discard clock_gettime(CLOCK_MONOTONIC, ts)
  int64(ts.tv_sec) * 1000 + int64(ts.tv_nsec) div 1_000_000

when defined(linux):
  var MsgNoSignal {.importc: "MSG_NOSIGNAL", header: "<sys/socket.h>".}: cint
else:
  const MsgNoSignal = 0.cint

proc connectUnixSocket*(path: string): cint =
  ## A connected, close-on-exec stream socket; -1 when nobody listens.
  var address: Sockaddr_un
  if path.len == 0 or path.len >= address.sun_path.len: return -1
  address.sun_family = TSa_Family(AF_UNIX)
  for i, c in path: address.sun_path[i] = c
  let fd = posix.socket(AF_UNIX, SOCK_STREAM, 0)
  if fd == SocketHandle(-1): return -1
  discard fcntl(cint(fd), F_SETFD, FD_CLOEXEC)
  if posix.connect(fd, cast[ptr SockAddr](addr address), SockLen(sizeof(address))) != 0:
    discard posix.close(fd)
    return -1
  cint(fd)

proc waitFd(fd: cint; events: cshort; deadline: int64): bool =
  while true:
    let left = deadline - monoMs()
    if left <= 0: return false
    var p = TPollfd(fd: fd, events: events)
    let n = poll(addr p, 1, cint(left))
    if n > 0: return true
    if n < 0 and errno != EINTR: return false

proc writeAllBlocking(fd: cint; data: string; deadline: int64) =
  var off = 0
  while off < data.len:
    let n = send(SocketHandle(fd), unsafeAddr data[off], data.len - off, MsgNoSignal)
    if n > 0:
      off += n
    elif n < 0 and errno in [EAGAIN, EWOULDBLOCK, EINTR]:
      if not waitFd(fd, POLLOUT, deadline): raise busErr("bus write timed out")
    else: raise busErr("bus write failed: " & $strerror(errno))

proc readLineBlocking(fd: cint; deadline: int64): string =
  ## One CRLF-terminated authentication line (without CRLF).
  var buf: array[1, char]
  while true:
    if not waitFd(fd, POLLIN, deadline): raise busErr("bus authentication timed out")
    let n = posix.read(fd, addr buf[0], 1)
    if n == 1:
      result.add buf[0]
      if result.endsWith("\r\n"): return result[0 ..< result.len - 2]
      if result.len > 16384: raise busErr("authentication line too long")
    elif n == 0: raise busErr("bus closed the connection during authentication")
    elif errno notin [EAGAIN, EINTR]: raise busErr("bus read failed: " & $strerror(errno))

proc authenticate*(fd: cint; uid: Uid; timeoutMs = 2000) =
  ## SASL EXTERNAL with the effective UID, then BEGIN.
  let deadline = monoMs() + timeoutMs
  let hex = ($uid).toHex
  writeAllBlocking(fd, "\0AUTH EXTERNAL " & hex & "\r\n", deadline)
  let line = readLineBlocking(fd, deadline)
  if not line.startsWith("OK "): raise busErr("bus refused authentication: " & line)
  writeAllBlocking(fd, "BEGIN\r\n", deadline)

proc newBusConn*(fd: cint; loop: EventLoop): BusConn =
  result = BusConn(fd: fd, loop: loop, serial: 0)
  setNonBlocking(fd)

proc nextSerial(c: BusConn): uint32 =
  inc c.serial
  if c.serial == 0: inc c.serial
  c.serial

proc close*(c: BusConn) =
  if c.closed: return
  c.closed = true
  if c.watching:
    c.loop.delFd(c.watch)
    c.watching = false
  discard posix.close(c.fd)
  c.pending.clear()
  if c.onClose != nil:
    let cb = c.onClose
    c.onClose = nil
    cb()

proc updateWatch(c: BusConn) =
  if c.watching:
    c.loop.modFd(c.watch, EvIn or (if c.wbuf.len > 0: EvOut else: 0'u32))

proc flush(c: BusConn) =
  while c.wbuf.len > 0 and not c.closed:
    let n = send(SocketHandle(c.fd), addr c.wbuf[0], c.wbuf.len, MsgNoSignal)
    if n > 0:
      c.wbuf = c.wbuf[n .. ^1]
    elif n < 0 and errno == EINTR: continue
    elif n < 0 and errno in [EAGAIN, EWOULDBLOCK]: break
    else:
      c.close()
      return
  c.updateWatch()

proc sendRaw(c: BusConn; data: string) =
  if c.closed: return
  if c.wbuf.len > 32 * 1024 * 1024:
    c.close()                  # a peer that never reads: drop the connection
    return
  c.wbuf.add data
  c.flush()

proc send*(c: BusConn; msg: Message): uint32 =
  ## Queues `msg` with a fresh serial; returns the serial.
  var m = msg
  m.serial = c.nextSerial
  let data = encode(m)
  if c.holdDepth > 0 and m.typ == mtSignal: c.held.add data
  else: c.sendRaw(data)
  m.serial

proc hold*(c: BusConn) =
  ## Signals sent until `release` go out after it: a method reply must reach
  ## the caller before the JobRemoved/PropertiesChanged signals it caused.
  inc c.holdDepth

proc release*(c: BusConn) =
  if c.holdDepth > 0: dec c.holdDepth
  if c.holdDepth == 0 and c.held.len > 0:
    let held = c.held
    c.held = @[]
    for d in held: c.sendRaw(d)

proc call*(c: BusConn; msg: Message; handler: ReplyHandler = nil) =
  var m = msg
  m.typ = mtMethodCall
  if handler == nil: m.flags = m.flags or FlagNoReplyExpected
  let serial = c.send(m)
  if handler != nil: c.pending[serial] = handler

proc reply*(c: BusConn; call: Message; body: seq[DValue] = @[]) =
  if (call.flags and FlagNoReplyExpected) != 0 or c.closed: return
  discard c.send(Message(typ: mtMethodReturn, replySerial: call.serial,
    destination: call.sender, body: body))

proc replyError*(c: BusConn; call: Message; name, text: string) =
  if (call.flags and FlagNoReplyExpected) != 0 or c.closed: return
  discard c.send(Message(typ: mtError, replySerial: call.serial, destination: call.sender,
    errorName: name, body: @[dstr(text)]))

proc signal*(c: BusConn; path, iface, member: string; body: seq[DValue] = @[];
             destination = "") =
  if c.closed: return
  discard c.send(Message(typ: mtSignal, path: path, iface: iface, member: member,
    destination: destination, body: body))

proc extractMessages(c: BusConn): seq[Message] =
  while true:
    let n = messageLength(c.rbuf)
    if n < 0 or c.rbuf.len < n: break
    let one = c.rbuf[0 ..< n]
    c.rbuf = c.rbuf[n .. ^1]
    result.add decode(one)

proc readAvailable(c: BusConn): bool =
  ## Reads what is there; false on EOF or a hard error.
  var buf: array[65536, char]
  while true:
    let n = posix.read(c.fd, addr buf[0], buf.len)
    if n > 0:
      let start = c.rbuf.len
      c.rbuf.setLen(start + n)
      copyMem(addr c.rbuf[start], addr buf[0], n)
      if n < buf.len: return true
    elif n == 0: return false
    elif errno == EINTR: continue
    elif errno in [EAGAIN, EWOULDBLOCK]: return true
    else: return false

proc dispatch(c: BusConn; msg: Message) =
  case msg.typ
  of mtMethodReturn, mtError:
    var h: ReplyHandler
    if c.pending.take(msg.replySerial, h) and h != nil: h(msg)
  of mtMethodCall, mtSignal:
    if c.onMessage != nil: c.onMessage(msg)
  else: discard

proc onReadable(c: BusConn) =
  let alive = c.readAvailable()
  var msgs: seq[Message]
  try: msgs = c.extractMessages()
  except DBusWireError:
    c.close()
    return
  for msg in msgs:
    if c.closed: return
    c.dispatch(msg)
  if not alive: c.close()

proc callSync*(c: BusConn; msg: Message; timeoutMs = 2000): Message =
  ## Blocking call (handshake only). Other messages that arrive meanwhile are
  ## kept and dispatched by `start`. Raises BusError on an error reply.
  var m = msg
  m.typ = mtMethodCall
  let serial = c.send(m)
  let deadline = monoMs() + timeoutMs
  while true:
    if c.wbuf.len > 0:
      c.flush()
      if c.closed: raise busErr("bus connection closed")
    let events = if c.wbuf.len > 0: POLLIN or POLLOUT else: POLLIN
    if not waitFd(c.fd, cshort(events), deadline): raise busErr("bus call " & msg.member & " timed out")
    if not c.readAvailable():
      c.close()
      raise busErr("bus connection closed")
    for got in c.extractMessages():
      if got.typ in {mtMethodReturn, mtError} and got.replySerial == serial:
        if got.typ == mtError:
          let text = if got.body.len > 0 and got.body[0].kind == dString: got.body[0].s else: ""
          raise busErr(got.errorName & ": " & text, got.errorName)
        return got
      c.backlog.add got

proc hello*(c: BusConn; timeoutMs = 2000) =
  let r = c.callSync(Message(path: BusPath, iface: BusName, member: "Hello",
    destination: BusName), timeoutMs)
  if r.body.len < 1: raise busErr("Hello returned no name")
  c.uniqueName = r.body[0].str

proc requestName*(c: BusConn; name: string; flags = 4'u32; timeoutMs = 2000): uint32 =
  ## 1 = primary owner, 2 = queued, 3 = exists, 4 = already owner.
  let r = c.callSync(Message(path: BusPath, iface: BusName, member: "RequestName",
    destination: BusName, body: @[dstr(name), duint32(flags)]), timeoutMs)
  if r.body.len < 1: raise busErr("RequestName returned nothing")
  uint32(r.body[0].u)

proc start*(c: BusConn) =
  ## Hands the connection to the event loop and dispatches the backlog.
  if c.closed or c.watching: return
  c.watch = c.loop.addFd(c.fd, EvIn, proc(ev: uint32) =
    if c.closed: return
    if (ev and EvOut) != 0: c.flush()
    if (ev and (EvIn or EvHup or EvErr)) != 0: c.onReadable())
  c.watching = true
  c.updateWatch()
  let backlog = c.backlog
  c.backlog = @[]
  for msg in backlog:
    if c.closed: return
    c.dispatch(msg)
