## The serial getty generator (spec §8.6, §8.6.1): `getty.target` wants a
## `serial-getty@T.service` for every serial console the kernel is using. A
## terminal that a native Jumpstart unit already serves gets no second login
## prompt (cores §22; jumpstart_dec(5) names those decfiles `getty-<tty>`).
import std/[os, strutils, sets, algorithm]
import ../common/[roots, logging, fdutil]
import ../unitfile/model

const GettyNamePrefix = "getty-"

proc isTerminalName*(s: string): bool =
  ## A name a terminal device can have: `tty1`, `ttyS0`, `ttyAMA0`, `hvc0`,
  ## `xvc0`, `console`.
  s.len in 2 .. 16 and s.allCharsInSet(Letters + Digits)

proc isTtyName*(s: string): bool =
  ## `tty` followed by letters and digits, the shape of an argument that names
  ## a terminal without a `/dev/` prefix (`tty1`, `ttyS0`, `ttyAMA0`).
  s.len > 3 and s.startsWith("tty") and s[3 .. ^1].allCharsInSet(Letters + Digits)

proc isVirtualTerminal*(s: string): bool =
  ## `tty1` .. `tty63`: virtual terminals are never generated (§8.6).
  s.len > 3 and s.startsWith("tty") and s[3 .. ^1].allCharsInSet(Digits)

proc program(word: string): string =
  word.strip(chars = {'"', '\'', '='}).extractFilename

proc isGettyCommand*(command: string): bool =
  ## The command itself runs a getty: `getty`, `agetty`, `/sbin/agetty`, or
  ## `busybox getty` / `toybox getty`. A getty mentioned further along (inside
  ## `sh -c 'echo getty on ttyS5'`) does not count.
  let words = command.splitWhitespace
  if words.len == 0: return false
  let prog = program(words[0])
  if prog.endsWith("getty"): return true
  prog in ["busybox", "toybox"] and words.len > 1 and program(words[1]).endsWith("getty")

proc terminalNames*(command: string): seq[string] =
  ## The terminals a command line names: `/dev/ttyS0`, `/dev/hvc0` and `ttyS0`
  ## yield `ttyS0`, `hvc0` and `ttyS0`. agetty's `-` (the terminal it inherited)
  ## names none, and neither do its `115200,38400` or `vt100` arguments.
  for word in command.splitWhitespace:
    let w = word.strip(chars = {'"', '\'', ';'})
    let name = if w.startsWith("/dev/"): w["/dev/".len .. ^1] else: w
    let named = if w.startsWith("/dev/"): isTerminalName(name) else: isTtyName(name)
    if named and name notin result: result.add name

proc execCommands*(path: string): seq[string] =
  ## The `exec` statements of one decfile, one per element. Only the terminal
  ## argument matters here, so a line scan of the file is enough.
  var text: string
  try: text = readFile(path) except CatchableError: return
  for line in text.splitLines:
    let words = line.strip.splitWhitespace
    if words.len < 2 or words[0] != "exec": continue    # not `exec_post`
    var command = line.strip[words[0].len .. ^1].strip
    if command.len > 1 and command[0] == '"' and command[^1] == '"':
      command = command[1 .. ^2]                        # exec "cmd" as one word
    result.add command

proc bootTarget*(configRoot: string): string =
  ## The native target a boot starts (cores §22.3): `default-target`, or the
  ## built-in `default` target (an empty string) when there is no usable file.
  var text: string
  try: text = readFile(configRoot / "default-target") except CatchableError: return
  let name = text.strip
  if name.len > 0 and name != "default" and '/' notin name: return name

proc enabledUnits*(configRoot: string): seq[string] =
  ## The decfiles a boot starts: `enabled/<unit>.kg` (the built-in `default`
  ## target) plus `targets/<target>/<unit>.kg` of the boot target (cores §22.2).
  ## Name order, no duplicates.
  var dirs = @[configRoot / "enabled"]
  let target = bootTarget(configRoot)
  if target.len > 0: dirs.add configRoot / "targets" / target
  var paths: seq[string]
  for dir in dirs:
    # A dangling link is still an enablement, and walkDir does not raise here.
    for kind, path in walkDir(dir):
      if kind in {pcFile, pcLinkToFile} or symlinkExists(path): paths.add path
  for path in paths:
    if path.extractFilename.endsWith(".kg"): result.add path
  result.sort

proc servesTty*(path: string): seq[string] =
  ## The terminals one native decfile serves: `getty-<tty>` by name convention,
  ## and every terminal an `exec` statement runs a getty on.
  let base = path.extractFilename
  if base.len > ".kg".len and base.endsWith(".kg"):
    let unit = base[0 ..< ^".kg".len]
    if unit.startsWith(GettyNamePrefix):
      let tty = unit[GettyNamePrefix.len .. ^1]
      if isTerminalName(tty): result.add tty
  for command in execCommands(path):
    if not isGettyCommand(command): continue
    for tty in terminalNames(command):
      if tty notin result: result.add tty

proc nativeGettyTtys*(configRoot: string): HashSet[string] =
  ## Every terminal a native Jumpstart getty unit occupies at boot.
  for path in enabledUnits(configRoot):
    for tty in servesTty(path): result.incl tty

proc serialConsoles*(sysfs, cmdline: string): seq[string] =
  ## The consoles the kernel is using: `/sys/class/tty/console/active`, else the
  ## `console=` words of the kernel command line.
  var consoles: seq[string]
  try: consoles = readFile(sysfs / "class/tty/console/active").splitWhitespace
  except CatchableError: discard
  if consoles.len == 0:
    try:
      for word in readFile(cmdline).splitWhitespace:
        if word.startsWith("console="):
          consoles.add word["console=".len .. ^1].split(',')[0]
    except CatchableError: discard
  for console in consoles:
    if console.len > 0 and console notin result: result.add console

proc serialGettyEdges*(r: Roots): seq[(DepKind, string, string)] =
  ## System scope: one `Wants=` edge from `getty.target` per serial console that
  ## no native getty unit serves.
  if r.scope != scSystem: return
  let native = nativeGettyTtys(r.etc / "jumpstart")
  for tty in serialConsoles(r.sysfs, r.cmdline):
    if isVirtualTerminal(tty): continue
    if tty in native:
      logInfo("getty.target", "a native Jumpstart getty unit serves " & tty &
              "; not starting serial-getty@" & tty & ".service")
      continue
    if not nodeExists(r.devfs / tty) and not symlinkExists(r.devfs / tty): continue
    result.add (dkWants, "getty.target", "serial-getty@" & tty & ".service")
