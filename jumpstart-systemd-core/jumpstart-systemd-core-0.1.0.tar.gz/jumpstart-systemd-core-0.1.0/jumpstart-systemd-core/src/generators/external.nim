## External unit generators (spec §6.12, systemd.generator(7)): every executable
## in the generator directories runs at manager start and at each daemon-reload,
## before the unit index is built, writing units into the three output
## directories (`generator`, `generator.early`, `generator.late`).
import std/[os, posix, algorithm, tables]
import ../common/[roots, logging]
import ../unitfile/[paths, index]
import ../engine/[types, manager]

const
  GeneratorTimeoutMs* = 10_000
  GeneratorKillGraceMs = 2_000

proc generatorList*(r: Roots): seq[string] =
  ## Executable regular files, de-duplicated by name (earlier directory wins),
  ## sorted by name.
  var byName = initTable[string, string]()
  for d in generatorSearchPath(r):
    if not dirExists(d): continue
    for kind, p in walkDir(d):
      if kind notin {pcFile, pcLinkToFile}: continue
      let n = p.extractFilename
      if n in byName: continue
      if access(p.cstring, X_OK) != 0: continue
      byName[n] = p
  var names: seq[string]
  for n in byName.keys: names.add n
  names.sort()
  for n in names: result.add byName[n]

proc emptyDir(d: string) =
  try: removeDir(d)
  except OSError: discard
  try: createDir(d)
  except OSError as e: logWarn("", "cannot create generator directory " & d & ": " & e.msg)

proc generatorEnv(r: Roots; firstBoot, reload: bool): seq[string] =
  result = @["SYSTEMD_SCOPE=" & (if r.scope == scUser: "user" else: "system"),
    "SYSTEMD_IN_INITRD=0", "SYSTEMD_VERSION=255",
    "SYSTEMD_FIRST_BOOT=" & (if firstBoot: "1" else: "0"),
    "SYSTEMD_RELOAD=" & (if reload: "1" else: "0"),
    "PATH=" & getEnv("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin")]
  if existsEnv("LANG"): result.add "LANG=" & getEnv("LANG")

proc monoMs(): int64 =
  var ts: Timespec
  discard clock_gettime(CLOCK_MONOTONIC, ts)
  int64(ts.tv_sec) * 1000 + int64(ts.tv_nsec) div 1_000_000

proc runOne(path: string; args: seq[string]; env: seq[string]): tuple[ok: bool, why: string] =
  var argv = allocCStringArray(@[path] & args)
  var envp = allocCStringArray(env)
  defer:
    deallocCStringArray(argv)
    deallocCStringArray(envp)
  let pid = fork()
  if pid < 0: return (false, "cannot fork")
  if pid == 0:
    let nul = open("/dev/null", O_RDONLY)
    if nul >= 0: discard dup2(nul, 0)
    discard execve(path.cstring, argv, envp)
    exitnow(127)
  var status: cint
  let start = monoMs()
  var termAt = -1'i64
  while true:
    let r = waitpid(pid, status, WNOHANG)
    if r == pid: break
    if r < 0 and errno != EINTR: return (false, "waitpid failed")
    let now = monoMs()
    if termAt < 0 and now - start > GeneratorTimeoutMs:
      discard kill(pid, SIGTERM)
      termAt = now
    elif termAt >= 0 and now - termAt > GeneratorKillGraceMs:
      discard kill(pid, SIGKILL)
    discard usleep(5000)
  if WIFEXITED(status) and WEXITSTATUS(status) == 0: (true, "")
  elif WIFEXITED(status): (false, "exited with status " & $WEXITSTATUS(status))
  else: (false, "killed by signal " & $WTERMSIG(status))

proc runExternalGenerators*(r: Roots; firstBoot, reload: bool): int =
  ## Returns the number of generators run. Failures are warnings.
  let (normal, early, late) = generatorOutputDirs(r)
  for d in [normal, early, late]: emptyDir(d)
  let env = generatorEnv(r, firstBoot, reload)
  for g in generatorList(r):
    let res = runOne(g, @[normal, early, late], env)
    inc result
    if not res.ok: logWarn("", "Generator " & g & " failed: " & res.why)

proc installExternalGenerators*() =
  ## Chains the external generators in front of the built-in ones.
  let prev = generatorHook
  generatorHook = proc(m: Manager): seq[GeneratedUnit] =
    discard runExternalGenerators(m.roots, m.firstBoot, m.indexReady)
    if prev != nil: prev(m) else: @[]
