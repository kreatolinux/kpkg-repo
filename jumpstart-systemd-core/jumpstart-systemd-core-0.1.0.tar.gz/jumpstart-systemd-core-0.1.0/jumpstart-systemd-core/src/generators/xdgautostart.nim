## XDG autostart (systemd's `systemd-xdg-autostart-generator`, systemd.generator(7),
## systemd-xdg-autostart-generator(8)): every `*.desktop` file in the autostart
## directories becomes a user unit `app-<escaped-name>@autostart.service`, wanted
## by `xdg-desktop-autostart.target`, so a desktop session can delegate starting
## its autostart entries to the service manager.
##
## User scope only, like systemd: the generator runs from the manager's
## generator hook at manager start and on every daemon-reload.
##
## Read from systemd's src/xdg-autostart-generator/xdg-autostart-service.c:
##   * directories: `$XDG_CONFIG_HOME/autostart` first, then
##     `$XDG_CONFIG_DIRS/autostart` (default `/etc/xdg/autostart`); a file name
##     seen earlier wins, so a user override masks the system file of the same
##     name (a hidden/skipped winner still suppresses later ones);
##   * `Hidden=` and `X-systemd-skip=` true: no unit;
##   * `Type=` other than `Application` (or absent): no unit;
##   * no `Exec=`: no unit; `TryExec=` not executable, or the `Exec=` binary not
##     found: no unit;
##   * `OnlyShowIn=`/`NotShowIn=` become an `ExecCondition=` against
##     `$XDG_CURRENT_DESKTOP` at start time (systemd-xdg-autostart-condition);
##   * `AutostartCondition=`/`X-KDE-autostart-condition=` become an
##     `ExecCondition=` using the DE's helper binary when it exists;
##   * `Exec=` is split with shell-like quoting, the standardised `%f`, `%F`,
##     `%u`, `%U`, `%d`, `%D`, `%n`, `%N`, `%i`, `%c`, `%k`, `%v`, `%m` field
##     codes are dropped, `%%` becomes `%`, a remaining `%` is escaped as `%%`,
##     `~` is expanded, and the result is quoted for `ExecStart=:` (no `$VAR`
##     expansion);
##   * the unit is `Type=exec`, `ExitType=cgroup`, `Restart=no`,
##     `TimeoutStopSec=5s`, `Slice=app.slice`, `After=` and `PartOf=`
##     `graphical-session.target`, and is wanted by `xdg-desktop-autostart.target`.
##
## Differences from systemd, both deliberate:
##   * `X-GNOME-Autostart-Phase=`: systemd treats *any* phase as "the session
##     starts this itself" and marks the unit `NotShowIn=GNOME`, which leaves the
##     entry started by nobody once the session stops managing phases.
##     gnome-session >= 49 refuses every entry that sets the key ("App %s sets
##     X-GNOME-Autostart-Phase, but gnome-session no longer manages session
##     services", gsm-app.c), so here a phase other than `Application` is
##     *mapped*: the unit is generated normally (and a comment records the
##     phase). Entries without a phase, or with `Phase=Application`, are the ones
##     the session still starts itself, so they get no unit — that is what keeps
##     an entry from starting twice now that the core's graphical-session.target
##     pulls the target in.
##   * `X-GNOME-Autostart-enabled=false` (user disabled the entry) and
##     `X-GNOME-HiddenUnderSystemd=true` (entry replaced by a real unit) also
##     suppress the unit; gnome-session honours both, systemd's generator does
##     not read them.
import std/[os, options, strutils, sequtils, algorithm, tables]
import ../common/[roots, logging]
import ../unitfile/[model, loader, specifiers, execcmd, values]
import ../engine/[types, manager]

const
  AutostartTarget* = "xdg-desktop-autostart.target"
  ConditionBinary* = "systemd-xdg-autostart-condition"
    ## The core's own front-end (tools/misc.nim) for the OnlyShowIn/NotShowIn
    ## check; systemd ships the same check as a separate binary.
  GnomeConditionBinary* = "gnome-systemd-autostart-condition"
  KdeConditionBinary* = "kde-systemd-start-condition"
  NameValidChars = {'a'..'z', 'A'..'Z', '0'..'9', ':', '_', '.', '\\', '-'}
  FieldCodes = ["%f", "%F", "%u", "%U", "%d", "%D", "%n", "%N", "%i", "%c", "%k", "%v", "%m"]
  ShellNeedEscape = {'"', '\\', '`', '$'}
  ShellNeedQuotes = ShellNeedEscape + {'\'', '(', ')', '<', '>', '|', '&', ';', '!', '*', '?', '[', ']'}

type
  XdgAutostart* = object
    ## One `*.desktop` autostart entry, as far as the generator looks at it.
    name*: string                  ## `app-<escaped>@autostart.service`
    path*: string
    description*: string
    execString*: string
    workingDirectory*: string
    tryExec*: string
    typ*: string
    onlyShowIn*, notShowIn*: seq[string]
    hidden*: bool                  ## `Hidden=true`, or the file could not be parsed
    gnomeEnabled*: Option[bool]    ## `X-GNOME-Autostart-enabled=`
    hiddenUnderSystemd*: bool      ## `X-GNOME-HiddenUnderSystemd=`
    systemdSkip*: bool             ## `X-systemd-skip=`
    phase*: string                 ## `X-GNOME-Autostart-Phase=`
    autostartCondition*: string    ## `AutostartCondition=` (GNOME extension)
    kdeAutostartCondition*: string ## `X-KDE-autostart-condition=`
    parseError*: string            ## non-empty: the file was hidden because of it

# ---- names ----------------------------------------------------------------------

proc escapeName*(s: string): string =
  ## systemd's `unit_name_escape()`: `/` becomes `-`, a leading `.`, `-`, `\` and
  ## every byte outside `[A-Za-z0-9:_.\-]` become `\xNN`. (`names.escape` is the
  ## path flavour of `systemd-escape`; this one keeps `-` distinct from `/`.)
  for i, c in s:
    if i == 0 and c == '.': result.add "\\x2e"
    elif c == '/': result.add '-'
    elif c == '-' or c == '\\' or c notin NameValidChars:
      result.add "\\x" & toHex(ord(c), 2).toLowerAscii
    else: result.add c

proc autostartUnitName*(fileName: string): string =
  ## `xdg_autostart_service_translate_name()`: `a-b.blub.desktop` ->
  ## `app-a\x2db.blub@autostart.service`.
  var stem = fileName
  if stem.endsWith(".desktop"): stem.setLen(stem.len - 8)
  "app-" & escapeName(stem) & "@autostart.service"

# ---- desktop file parsing --------------------------------------------------------

proc xdgUnescapeChar(c: char; dst: var string): bool =
  ## One escape sequence's replacement (`\s`, `\n`, `\t`, `\r`, `\\`, `\;`);
  ## false for anything else, which makes the whole file unparsable as in systemd.
  case c
  of 's': dst.add ' '
  of 'n': dst.add '\n'
  of 't': dst.add '\t'
  of 'r': dst.add '\r'
  of '\\': dst.add '\\'
  of ';': dst.add ';'
  else: return false
  true

proc xdgUnescape(s: string; ok: var bool): string =
  ## A desktop entry string value.
  var i = 0
  while i < s.len:
    if s[i] != '\\':
      result.add s[i]; inc i; continue
    if i + 1 >= s.len or not xdgUnescapeChar(s[i + 1], result):
      ok = false; return
    i += 2

proc parseStrv(s: string; ok: var bool): seq[string] =
  ## A `;`-separated list where `\;` is a literal semicolon; empty items dropped.
  var cur = ""
  var i = 0
  while i < s.len:
    if s[i] == '\\':
      if i + 1 >= s.len or not xdgUnescapeChar(s[i + 1], cur):
        ok = false; return
      i += 2
    elif s[i] == ';':
      if cur.len > 0: result.add cur
      cur = ""
      inc i
    else:
      cur.add s[i]; inc i
  if cur.len > 0: result.add cur

proc parseDesktop*(text, path: string): XdgAutostart =
  ## The `[Desktop Entry]` group of one autostart file. A parse error hides the
  ## entry (it still masks later files of the same name), like systemd.
  result.path = path
  result.name = autostartUnitName(path.extractFilename)
  var ok = true
  var seen: seq[string]
  var section = ""
  for raw in text.splitLines:
    let line = raw.strip(chars = {' ', '\t', '\r'})
    if line.len == 0 or line[0] in {'#', ';'}: continue
    if line[0] == '[':
      let e = line.find(']')
      section = if e > 0: line[1 ..< e] else: ""
      continue
    if section != "Desktop Entry": continue
    let eq = line.find('=')
    if eq < 0: continue
    let key = line[0 ..< eq].strip(chars = {' ', '\t'})
    let val = line[eq + 1 .. ^1].strip(chars = {' ', '\t'})
    if key.len == 0 or '[' in key: continue       # `Name[de]=`: a translation
    template once(): bool =
      ## systemd's string/strv parsers ignore a second definition of the same key.
      if key in seen: false
      else:
        seen.add key
        true
    case key
    of "Name":
      if once(): result.description = xdgUnescape(val, ok)
    of "Exec":
      if once(): result.execString = xdgUnescape(val, ok)
    of "Path":
      if once(): result.workingDirectory = xdgUnescape(val, ok)
    of "TryExec":
      if once(): result.tryExec = xdgUnescape(val, ok)
    of "Type":
      if once(): result.typ = xdgUnescape(val, ok)
    of "OnlyShowIn":
      if once(): result.onlyShowIn = parseStrv(val, ok)
    of "NotShowIn":
      if once(): result.notShowIn = parseStrv(val, ok)
    of "Hidden":
      let b = parseBoolVal(val)
      if b.isNone: ok = false
      else: result.hidden = b.get
    of "X-GNOME-Autostart-enabled":
      let b = parseBoolVal(val)
      if b.isNone: ok = false
      else: result.gnomeEnabled = some(b.get)
    of "X-GNOME-HiddenUnderSystemd":
      let b = parseBoolVal(val)
      if b.isNone: ok = false
      else: result.hiddenUnderSystemd = b.get
    of "X-systemd-skip":
      let b = parseBoolVal(val)
      if b.isNone: ok = false
      else: result.systemdSkip = b.get
    of "X-GNOME-Autostart-Phase":
      if once(): result.phase = xdgUnescape(val, ok)
    of "AutostartCondition":
      if once(): result.autostartCondition = xdgUnescape(val, ok)
    of "X-KDE-autostart-condition":
      if once(): result.kdeAutostartCondition = xdgUnescape(val, ok)
    else: discard
  if not ok:
    result.hidden = true
    result.parseError = "cannot parse " & path & ", ignoring it"
  result

# ---- Exec= -----------------------------------------------------------------------

proc shellQuote(s: string): string =
  ## `shell_maybe_quote()` with `SHELL_ESCAPE_EMPTY`: an argument that needs it is
  ## enclosed in double quotes with `\`-escapes, an empty one becomes `""`.
  if s.len == 0: return "\"\""
  var needs = false
  for c in s:
    if ord(c) < 0x20 or ord(c) == 0x7f or c in ShellNeedQuotes: needs = true; break
  if not needs: return s
  result = "\""
  for c in s:
    case c
    of '"': result.add "\\\""
    of '\\': result.add "\\\\"
    of '\n': result.add "\\n"
    of '\t': result.add "\\t"
    of '\r': result.add "\\r"
    else:
      if ord(c) < 0x20: result.add "\\x" & toHex(ord(c), 2).toLowerAscii
      else: result.add c
  result.add '"'

proc formatExecStart*(execString, home: string; dirs: seq[string]; base = ""): Option[string] =
  ## `xdg_autostart_format_exec_start()`: the `ExecStart=` value for the unit, or
  ## none when the `Exec=` line is unusable (no executable, quoting, or the
  ## binary does not exist).
  var words: seq[Word]
  if not splitWordsEx(execString, words) or words.len == 0: return
  var argv: seq[string]
  var first = true
  for w in words:
    let c = w.text
    if first:
      first = false
      let exe = lookupExecutable(c, dirs, base)
      if exe.len == 0: return
      argv.add exe
      continue
    if c in FieldCodes: continue
    var a = c.replace("%%", "%").replace("%", "%%")
    if a.len > 0 and a[0] == '~' and (a.len == 1 or a[1] == '/'):
      a = home & a[1 .. ^1]
    argv.add a
  some(argv.mapIt(shellQuote(it)).join(" "))

# ---- unit generation --------------------------------------------------------------

proc specifierEscape(s: string): string = s.replace("%", "%%")

proc cescape(s: string): string =
  ## `cescape()`: control characters and `"`/`\` become escapes.
  for c in s:
    case c
    of '\a': result.add "\\a"
    of '\b': result.add "\\b"
    of '\f': result.add "\\f"
    of '\n': result.add "\\n"
    of '\r': result.add "\\r"
    of '\t': result.add "\\t"
    of '\v': result.add "\\v"
    of '\\': result.add "\\\\"
    of '"': result.add "\\\""
    else:
      if ord(c) < 0x20: result.add "\\x" & toHex(ord(c), 2).toLowerAscii
      else: result.add c

proc sessionStartsIt*(entry: XdgAutostart): bool =
  ## True when gnome-session starts the entry itself, so the generator must not:
  ## the session accepts only entries without `X-GNOME-Autostart-Phase` (or with
  ## `Phase=Application`) and refuses every other phase.
  entry.phase.len == 0 or cmpIgnoreCase(entry.phase, "Application") == 0

proc skipReason*(entry: XdgAutostart): string =
  ## Why no unit is generated for `entry`; "" when one is.
  if entry.hidden:
    return if entry.parseError.len > 0: entry.parseError else: "entry is hidden"
  if entry.systemdSkip: return "marked with X-systemd-skip"
  if entry.hiddenUnderSystemd: return "marked with X-GNOME-HiddenUnderSystemd"
  if entry.gnomeEnabled == some(false): return "disabled with X-GNOME-Autostart-enabled=false"
  if entry.typ != "Application":
    return "Type=" & (if entry.typ.len > 0: entry.typ else: "(unset)") & " is not supported"
  if entry.execString.len == 0: return "no Exec= line"
  if sessionStartsIt(entry): return "gnome-session starts it itself (no X-GNOME-Autostart-Phase)"

proc conditionLine(binary: string; condition: string; dirs: seq[string]; base: string): string =
  ## `ExecCondition=` for a DE helper, or a comment when the helper is missing
  ## (systemd's behaviour: the unit still starts).
  let found = lookupExecutable(binary, dirs, base)
  if found.len == 0:
    return "# ExecCondition using " & binary & " skipped due to missing binary.\n"
  "ExecCondition=" & found & " --condition \"" & cescape(condition) & "\"\n"

proc unitText*(entry: XdgAutostart; execStart: string; dirs: seq[string]; base = ""): string =
  ## The generated unit, as systemd's generator writes it.
  result = "[Unit]\n" &
    "Documentation=man:systemd-xdg-autostart-generator(8)\n" &
    "SourcePath=" & specifierEscape(entry.path) & "\n" &
    "PartOf=graphical-session.target\n"
  if entry.description.len > 0:
    result.add "Description=" & specifierEscape(entry.description) & "\n"
  if entry.phase.len > 0:
    result.add "# X-GNOME-Autostart-Phase=" & entry.phase &
      " (gnome-session no longer manages phases; started here)\n"
  result.add "After=graphical-session.target\n"
  result.add "\n[Service]\n" &
    "Type=exec\n" &
    "ExitType=cgroup\n" &
    "ExecStart=:" & execStart & "\n" &
    "Restart=no\n" &
    "TimeoutStopSec=5s\n" &
    "Slice=app.slice\n"
  if entry.workingDirectory.len > 0:
    result.add "WorkingDirectory=-" & cescape(entry.workingDirectory) & "\n"
  if entry.onlyShowIn.len > 0 or entry.notShowIn.len > 0:
    let found = lookupExecutable(ConditionBinary, dirs, base)
    if found.len == 0:
      result.add "# ExecCondition using " & ConditionBinary & " skipped due to missing binary.\n"
    else:
      result.add "ExecCondition=" & found & " -- \"" & cescape(entry.onlyShowIn.join(":")) &
        "\" \"" & cescape(entry.notShowIn.join(":")) & "\"\n"
  if entry.autostartCondition.len > 0:
    result.add conditionLine(GnomeConditionBinary, entry.autostartCondition, dirs, base)
  if entry.kdeAutostartCondition.len > 0:
    result.add conditionLine(KdeConditionBinary, entry.kdeAutostartCondition, dirs, base)

# ---- directories ------------------------------------------------------------------

proc autostartDirs*(r: Roots): seq[string] =
  ## Highest priority first: the user's own directory, then `$XDG_CONFIG_DIRS`
  ## (default `/etc/xdg`), each with `/autostart` appended. Below a fake root
  ## (tests) absolute entries are prefixed with it.
  let base = r.usrLib.parentDir.parentDir
  result.add r.etc / "autostart"
  var dirs: seq[string]
  let e = getEnv("XDG_CONFIG_DIRS")
  if e.len > 0: dirs = e.split(':').filterIt(it.len > 0)
  else: dirs = @["/etc/xdg"]
  for d in dirs:
    let p = if base != "/" and d.startsWith("/"): base & d else: d
    result.add p / "autostart"

proc readEntries*(r: Roots): seq[XdgAutostart] =
  ## Every entry, first file name wins (so `~/.config/autostart` overrides
  ## `/etc/xdg/autostart`), sorted by unit name.
  var byName: seq[string]
  for d in autostartDirs(r):
    if not dirExists(d): continue
    var names: seq[string]
    try:
      for kind, p in walkDir(d):
        if kind notin {pcFile, pcLinkToFile} or not p.endsWith(".desktop"): continue
        names.add p.extractFilename
    except OSError as e:
      logWarn("", "cannot read autostart directory " & d & ": " & e.msg)
      continue
    names.sort()
    for n in names:
      let unit = autostartUnitName(n)
      if unit in byName: continue
      byName.add unit
      var text = ""
      try: text = readFile(d / n)
      except IOError as e:
        logWarn(unit, "cannot read " & d / n & ": " & e.msg)
        continue
      result.add parseDesktop(text, d / n)
  result.sort(proc(a, b: XdgAutostart): int = cmp(a.name, b.name))

proc execDirs(r: Roots; pathEnv: string): tuple[dirs: seq[string], base: string] =
  ## Where `Exec=`/`TryExec=` binaries are looked up: the manager's `PATH` first,
  ## then the built-in list (a user manager started by PAM may have a short
  ## `PATH`; systemd's generator always has the standard one).
  let base = r.usrLib.parentDir.parentDir
  for d in pathEnv.split(':'):
    if d.len == 0: continue
    let p = if base != "/" and d.startsWith("/"): base & d else: d
    if p notin result.dirs: result.dirs.add p
  for d in execSearchDirs(r):
    if d notin result.dirs: result.dirs.add d
  result.base = base

proc generateXdgAutostart*(r: Roots; env: SpecifierEnv; conf: ManagerConf;
                           pathEnv = ""): seq[GeneratedUnit] =
  ## The generator's output for `r`: one generated service per entry that the
  ## session does not start itself, each wanted by `xdg-desktop-autostart.target`.
  if r.scope != scUser: return
  let (dirs, base) = execDirs(r, pathEnv)
  for entry in readEntries(r):
    let why = skipReason(entry)
    if why.len > 0:
      logInfo(entry.name, entry.path & ": not generating unit, " & why)
      continue
    if entry.tryExec.len > 0 and lookupExecutable(entry.tryExec, dirs, base).len == 0:
      logInfo(entry.name, entry.path & ": not generating unit, could not find TryExec= binary " & entry.tryExec)
      continue
    let execStart = formatExecStart(entry.execString, env.home, dirs, base)
    if execStart.isNone:
      logInfo(entry.name, entry.path & ": not generating unit, executable specified in Exec= does not exist or the line is unusable")
      continue
    let text = unitText(entry, execStart.get, dirs, base)
    # No source file: the unit text is not the desktop file, so it must not be
    # stamped for NeedDaemonReload= (the generator re-runs on every reload).
    let def = parseUnitText(entry.name, text, r, env, conf, usGenerated)
    if def.common.loadState != lsLoaded:
      logWarn(entry.name, entry.path & ": generated unit does not load: " & def.common.loadError)
      continue
    var g = GeneratedUnit(name: entry.name, def: def)
    g.extraDeps.add (dkWants, AutostartTarget, entry.name)
    result.add g

proc installXdgAutostart*() =
  ## Chains the generator in front of the other generator hooks. The manager's
  ## `PATH` decides where `Exec=`/`TryExec=` binaries are looked up, as in
  ## systemd's generator.
  let prev = generatorHook
  generatorHook = proc(m: Manager): seq[GeneratedUnit] =
    var res: seq[GeneratedUnit]
    if m.roots.scope == scUser:
      res.add generateXdgAutostart(m.roots, m.specEnv, m.conf, m.env.getOrDefault("PATH", ""))
    if prev != nil: res.add prev(m)
    res
