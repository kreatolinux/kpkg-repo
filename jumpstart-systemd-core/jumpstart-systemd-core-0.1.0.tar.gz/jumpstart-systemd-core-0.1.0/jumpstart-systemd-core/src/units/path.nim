## Path units: `PathExists=`, `PathExistsGlob=`, `PathChanged=`, `PathModified=`,
## `DirectoryNotEmpty=`, `MakeDirectory=`, `DirectoryMode=`, `TriggerLimit*=`, `Unit=`.
## Watches are inotify descriptors on the path or, while it does not exist, on its
## nearest existing ancestor; without inotify (not Linux) the loop polls every 500 ms.
## A glob is watched through the directory of its literal prefix only, so a change
## below a wildcard component is noticed at the next event of the prefix directory
## (or when the triggered unit stops).
import std/[os, posix, strutils, tables, sequtils]
import ../common/[logging, clock]
import ../unitfile/model
import ../engine/[types, graph, jobs, unitstate, eventloop, manager]
import ./[fswatch, subs]

type
  PathData* = ref object of RootObj
    state: string                  ## dead, waiting, running, failed
    ifd: cint
    watchId: WatchId
    pollTimer: TimerId
    wdOwner: Table[cint, seq[int]]
    selfWatch: seq[bool]           ## the watch is on the target itself, not an ancestor
    prevExists: seq[bool]
    pending: bool                  ## an edge event arrived while the unit ran
    sub: Subscription
    trigger: RateLimit
    lastCheck: seq[string]         ## polling fallback: a stat signature per path

proc pdata(u: Unit): PathData = PathData(u.data)

proc pathTriggered*(u: Unit): string =
  let t = u.def.path.unit
  if t.len > 0: t else: u.def.common.prefix & ".service"

proc isEdge(k: PathKind): bool = k in {pkChanged, pkModified}

proc globMatches(pattern: string): bool =
  try:
    for _ in walkPattern(pattern): return true
  except CatchableError: discard
  false

proc dirNotEmpty(p: string): bool =
  if not dirExists(p): return false
  try:
    for _ in walkDir(p): return true
  except CatchableError: discard
  false

proc pathPresent(p: string): bool =
  var st: Stat
  lstat(p.cstring, st) == 0

proc levelGood(s: PathSpec): bool =
  case s.kind
  of pkExists: pathPresent(s.path)
  of pkExistsGlob: globMatches(s.path)
  of pkDirectoryNotEmpty: dirNotEmpty(s.path)
  else: false

proc globPrefix(p: string): string =
  ## The directory made of the leading components without wildcards.
  var parts: seq[string]
  for c in p.split('/'):
    if c.len == 0: continue
    if c.anyIt(it in {'*', '?', '['}): break
    parts.add c
  "/" & parts.join("/")

proc watchTarget(s: PathSpec): string =
  if s.kind == pkExistsGlob: globPrefix(s.path) else: s.path

proc setPath(m: Manager; u: Unit; sub: string; result = "") =
  let d = pdata(u)
  d.state = sub
  let a = case sub
    of "dead": asInactive
    of "failed": asFailed
    else: asActive
  m.setState(u, a, sub, result)

proc rearm(m: Manager; u: Unit) =
  ## Registers (or refreshes) the watches for the current state of the file system.
  let d = pdata(u)
  let specs = u.def.path.paths
  d.wdOwner.clear()
  d.selfWatch = newSeq[bool](specs.len)
  for i, s in specs:
    var target = watchTarget(s)
    var mask: uint32 = WatchCreateDelete
    if pathPresent(target):
      d.selfWatch[i] = true
      mask = mask or WatchChanged
      if s.kind == pkModified: mask = mask or WatchModify
    else:
      while target.len > 1 and not pathPresent(target):
        target = target.parentDir
      if target.len == 0: target = "/"
    let wd = addWatch(d.ifd, target, mask)
    if wd >= 0:
      d.wdOwner.mgetOrPut(wd, @[]).add i
    d.prevExists[i] = pathPresent(s.path)

proc signature(s: PathSpec): string =
  ## Polling fallback: something that changes when the path changes.
  var st: Stat
  if stat(watchTarget(s).cstring, st) != 0: return "-"
  $int64(st.st_mtime) & ":" & $int64(st.st_ctime) & ":" & $int64(st.st_size)

proc enterWaiting(m: Manager; u: Unit; recheck: bool)

proc fire(m: Manager; u: Unit) =
  let d = pdata(u)
  if u.active != asActive: return
  let c = u.def.path
  let now = m.clock.monoUsec
  d.trigger.intervalUsec = c.triggerLimitIntervalSec
  d.trigger.burst = c.triggerLimitBurst
  if d.trigger.begin == 0 or now - d.trigger.begin > d.trigger.intervalUsec:
    d.trigger.begin = now
    d.trigger.count = 0
  inc d.trigger.count
  if d.trigger.count > c.triggerLimitBurst:
    logWarn(u.id, "Trigger limit hit, refusing further activations")
    u.ops.fail(m, u, "trigger-limit-hit")
    return
  let svc = m.lookup(pathTriggered(u))
  if svc == nil or not svc.loadOk:
    logErr(u.id, "Unit " & pathTriggered(u) & " not found, cannot trigger it.")
    u.ops.fail(m, u, "resources")
    return
  d.pending = false
  logInfo(u.id, "Path condition met, starting " & svc.id & ".")
  m.setPath(u, "running", "success")
  try: discard submitJob(m, svc, jtStart, jmReplace, joDependency)
  except CatchableError as e:
    logWarn(u.id, "cannot start " & svc.id & ": " & e.msg)
    m.loop.afterEvent(proc() =
      if u.active == asActive and pdata(u).state == "running": m.enterWaiting(u, false))

proc anyLevelGood(u: Unit): bool =
  u.def.path.paths.anyIt(not it.kind.isEdge and levelGood(it))

proc enterWaiting(m: Manager; u: Unit; recheck: bool) =
  let d = pdata(u)
  m.setPath(u, "waiting", "success")
  m.rearm(u)
  if recheck and (d.pending or anyLevelGood(u)): m.fire(u)

proc onEvents(m: Manager; u: Unit) =
  let d = pdata(u)
  if u.active != asActive: return
  let events = drainEvents(d.ifd)
  var edge = false
  let specs = u.def.path.paths
  let prev = d.prevExists
  let selfW = d.selfWatch
  var hit = newSeq[bool](specs.len)
  for ev in events:
    if ev.mask == 0x00008000'u32: continue          # IN_IGNORED
    for i in d.wdOwner.getOrDefault(ev.wd): hit[i] = true
  for i, s in specs:
    if not s.kind.isEdge or not hit[i]: continue
    if (i < selfW.len and selfW[i]) or pathPresent(s.path) != prev[i]: edge = true
  m.rearm(u)
  if d.state == "running":
    if edge: d.pending = true
    return
  if edge or anyLevelGood(u):
    d.pending = d.pending or edge
    m.fire(u)

proc pollTick(m: Manager; u: Unit) =
  let d = pdata(u)
  if u.active != asActive: return
  let specs = u.def.path.paths
  var edge = false
  for i, s in specs:
    let sig = signature(s)
    if s.kind.isEdge and d.lastCheck[i] != sig: edge = true
    d.lastCheck[i] = sig
  if d.state == "running":
    if edge: d.pending = true
  elif edge or anyLevelGood(u):
    d.pending = d.pending or edge
    m.fire(u)
  d.pollTimer = m.loop.addTimerIn(500_000, proc() = m.pollTick(u))

proc closeWatch(m: Manager; u: Unit) =
  let d = pdata(u)
  if d.watchId != WatchId(0):
    m.loop.delFd(d.watchId)
    d.watchId = WatchId(0)
  if d.ifd >= 0:
    discard close(d.ifd)
    d.ifd = -1
  m.loop.cancelTimer(d.pollTimer)
  d.pollTimer = TimerId(0)
  if d.sub != nil:
    m.subscribers.keepItIf(it != d.sub)
    d.sub = nil

proc pathStart(m: Manager; u: Unit): StartOutcome =
  let d = pdata(u)
  if d.state in ["waiting", "running"]: return StartOutcome(kind: skAlreadyActive)
  let c = u.def.path
  if c.paths.len == 0:
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "Path unit lacks path or other relevant setting.")
  let svc = m.lookup(pathTriggered(u))
  if svc == nil or not svc.loadOk:
    logErr(u.id, "Unit " & pathTriggered(u) & " not found.")
    u.result = "resources"
    m.setPath(u, "failed", "resources")
    return StartOutcome(kind: skStarted)
  if c.makeDirectory:
    for s in c.paths:
      if s.kind == pkExistsGlob: continue
      try:
        createDir(s.path)
        discard chmod(s.path.cstring, Mode(c.directoryMode))
      except CatchableError as e:
        logWarn(u.id, "cannot create directory " & s.path & ": " & e.msg)
  u.result = "success"
  d.pending = false
  d.trigger = RateLimit()
  d.prevExists = newSeq[bool](c.paths.len)
  d.lastCheck = c.paths.mapIt(signature(it))
  d.ifd = openWatcher()
  let uu = u
  if d.ifd >= 0:
    d.watchId = m.loop.addFd(d.ifd, EvIn, proc(ev: uint32) = m.onEvents(uu))
  else:
    d.pollTimer = m.loop.addTimerIn(500_000, proc() = m.pollTick(uu))
  d.sub = Subscription(patterns: @[globQuote(m.canonical(pathTriggered(u)))], cb: proc(ev: StateEvent) =
    if uu.active != asActive: return
    if ev.active in {asInactive, asFailed} and pdata(uu).state == "running":
      # the job that started the unit finishes right after this state change: re-check afterwards
      m.loop.afterEvent(proc() =
        let t = m.lookup(pathTriggered(uu))
        if uu.active == asActive and pdata(uu).state == "running" and t != nil and
            t.active in {asInactive, asFailed} and (t.job == nil or not t.job.typ.isStartLike):
          m.enterWaiting(uu, true)))
  m.subscribers.add d.sub
  m.setPath(u, "waiting", "success")
  m.rearm(u)
  # level conditions are checked once the start job is done
  m.loop.afterEvent(proc() =
    if uu.active == asActive and pdata(uu).state == "waiting" and anyLevelGood(uu): m.fire(uu))
  StartOutcome(kind: skStarted)

proc pathStop(m: Manager; u: Unit) =
  m.closeWatch(u)
  m.setPath(u, "dead", "success")

proc pathStatus(m: Manager; u: Unit): StatusExtras =
  result.exitCode = -1
  var w: seq[string]
  for s in u.def.path.paths: w.add $s.kind & "=" & s.path
  result.extra.add ("watches", w.join("\n"))
  result.extra.add ("triggers", pathTriggered(u))

proc attach*(m: Manager; u: Unit) =
  u.data = PathData(state: "dead", ifd: -1)
  u.sub = "dead"
  u.ops = UnitOps(start: pathStart, stop: pathStop, status: pathStatus,
    resetFailed: proc(m: Manager; u: Unit) =
      if u.active == asFailed: m.setPath(u, "dead", "success"),
    fail: proc(m: Manager; u: Unit; r: string) =
      m.closeWatch(u)
      m.setPath(u, "failed", r),
    shutdown: proc(m: Manager; u: Unit) = m.closeWatch(u))

proc installPathSupport*() =
  pathAttach = attach
