## Timer units (spec §11.2): `OnActiveSec=`, `OnBootSec=`, `OnStartupSec=`,
## `OnUnitActiveSec=`, `OnUnitInactiveSec=`, `OnCalendar=`, `RandomizedDelaySec=`,
## `FixedRandomDelay=`, `Persistent=`, `RemainAfterElapse=`, `Unit=`.
## `AccuracySec=` lets an elapse slip to a coalescing instant within its
## window (units/accuracy.nim). `OnClockChange=` elapses when `CLOCK_REALTIME`
## is set discontinuously (timerfd `TFD_TIMER_CANCEL_ON_SET` on Linux, and a
## drift check against the monotonic clock every second everywhere, which also
## serves injected test clocks); `OnTimezoneChange=` when `/etc/localtime` (or
## the zone file it points to) changes (inotify on Linux, a stat check every
## second elsewhere).
import std/[os, strutils, options, sequtils, times, posix]
import ../common/[logging, clock, sha1]
import ../unitfile/[model, validate]
import ../engine/[types, graph, jobs, unitstate, eventloop, manager]
import ./[calendar, accuracy, subs]

when defined(linux):
  import ./fswatch
  proc timerfdCreate(clockid, flags: cint): cint {.importc: "timerfd_create", header: "<sys/timerfd.h>".}
  proc timerfdSettime(fd, flags: cint; newValue: ptr Itimerspec; oldValue: ptr Itimerspec): cint
    {.importc: "timerfd_settime", header: "<sys/timerfd.h>".}

type
  TimerData* = ref object of RootObj
    state: string                  ## dead, waiting, running, elapsed, failed
    loopTimer: TimerId
    sub: Subscription
    armedMono, armedReal: int64    ## when the timer was started
    baseReal: int64                ## OnCalendar= computes the next elapse after this instant
    lastTrigger: int64             ## realtime of the last elapse, 0 when never
    fired: seq[bool]               ## per value: monotonic values elapse once per start
    delay: seq[int64]              ## per value: RandomizedDelaySec= part of the next elapse
    deadline: seq[int64]           ## per value: absolute monotonic deadline, -1 none
    nextMono: int64
    nextReal: int64
    fireAt: int64                  ## monotonic instant the loop timer is armed for (AccuracySec= applied)
    nextIsReal: bool               ## the earliest value is a realtime (calendar) one
    # OnClockChange= / OnTimezoneChange=
    watchIds: seq[WatchId]
    watchFds: seq[cint]
    eventTimer: TimerId
    lastRealCheck, lastMonoCheck: int64
    zoneSig: string
    stampPending: bool             ## the stamp file could not be written yet

const NoDeadline = low(int64)

proc tdata(u: Unit): TimerData = TimerData(u.data)

proc triggeredUnit*(u: Unit): string =
  let t = u.def.timer.unit
  if t.len > 0: t else: u.def.common.prefix & ".service"

proc stampPath(m: Manager; u: Unit): string =
  if m.roots.st.len == 0: "" else: m.roots.st / "timers" / ("stamp-" & u.id)

proc hasCalendar(u: Unit): bool =
  u.def.timer.values.anyIt(it.base == tbCalendar)

proc writeStamp(m: Manager; u: Unit; real: int64) =
  let d = tdata(u)
  let p = m.stampPath(u)
  if p.len == 0 or not u.def.timer.persistent or not u.hasCalendar: return
  try:
    createDir(p.parentDir)
    writeFile(p, "")
    setLastModificationTime(p, fromUnix(real div 1_000_000))
    d.stampPending = false
  except CatchableError:
    d.stampPending = true      # written at the next elapse or stop, once ST exists (§8.9)

proc readStamp(m: Manager; u: Unit): int64 =
  let p = m.stampPath(u)
  if p.len == 0 or not fileExists(p): return 0
  try: getLastModificationTime(p).toUnix * 1_000_000
  except CatchableError: 0

proc randomDelay(m: Manager; u: Unit): int64 =
  let t = u.def.timer
  if t.randomizedDelaySec <= 0: return 0
  if t.fixedRandomDelay:
    let h = sha1hex(u.id & m.machineId)
    var v = 0'i64
    for ch in h[0 ..< 12]: v = v * 16 + int64(parseHexInt($ch))
    return v mod (t.randomizedDelaySec + 1)
  m.rng.uniform(0, t.randomizedDelaySec)

proc setTimerState(m: Manager; u: Unit; sub: string; result = "") =
  let d = tdata(u)
  d.state = sub
  let a = case sub
    of "dead": asInactive
    of "failed": asFailed
    else: asActive
  m.setState(u, a, sub, result)

proc cancelLoop(m: Manager; u: Unit) =
  let d = tdata(u)
  if d.loopTimer.isSet:
    m.loop.cancelTimer(d.loopTimer)
    d.loopTimer = TimerId(0)

proc unsubscribe(m: Manager; u: Unit) =
  let d = tdata(u)
  if d.sub != nil:
    m.subscribers.keepItIf(it != d.sub)
    d.sub = nil

proc computeDeadlines(m: Manager; u: Unit) =
  ## Fills `deadline[]`, `nextMono`, `nextReal` from the values and the triggered unit's stamps.
  let d = tdata(u)
  let vals = u.def.timer.values
  let nowM = m.clock.monoUsec
  let nowR = m.clock.realUsec
  let svc = m.lookup(triggeredUnit(u))
  d.nextMono = NoDeadline
  d.nextReal = 0
  for i, v in vals:
    var at = NoDeadline
    if not d.fired[i]:
      case v.base
      of tbActive: at = d.armedMono + v.usec
      of tbBoot: at = nowM + (v.usec - m.clock.boottimeUsec)
      of tbStartup: at = (if m.startedUsec > 0: m.startedUsec else: d.armedMono) + v.usec
      of tbUnitActive:
        let s = if svc != nil and svc.inactiveExit.monoUsec > 0: svc.inactiveExit.monoUsec else: d.armedMono
        at = s + v.usec
      of tbUnitInactive:
        let s = if svc != nil and svc.inactiveEnter.monoUsec > 0: svc.inactiveEnter.monoUsec else: d.armedMono
        at = s + v.usec
      of tbCalendar:
        let p = parseCalendar(v.calendar)
        if p.isSome:
          let nx = nextElapse(p.get, d.baseReal)
          if nx.isSome: at = nowM + (nx.get - nowR)
      of tbClockChange, tbTimezoneChange: discard
    if at != NoDeadline: at += d.delay[i]
    d.deadline[i] = at
    if at != NoDeadline and (d.nextMono == NoDeadline or at < d.nextMono):
      d.nextMono = at
      d.nextIsReal = v.base == tbCalendar
  if d.nextMono != NoDeadline: d.nextReal = nowR + (d.nextMono - nowM)

proc elapse(m: Manager; u: Unit)

proc hasEvents(u: Unit): bool =
  u.def.timer.values.anyIt(it.base in {tbClockChange, tbTimezoneChange})

proc coalescedAt(m: Manager; u: Unit; at: int64): int64 =
  ## AccuracySec=: the instant within [at, at + accuracy] to wake up at.
  let acc = u.def.timer.accuracySec
  if acc <= 1: return at
  let p = perturbOf(m.machineId)
  if tdata(u).nextIsReal:
    let nowM = m.clock.monoUsec
    let nowR = m.clock.realUsec
    let r = nowR + (at - nowM)
    nowM + (coalesce(r, acc, p) - nowR)
  else: coalesce(at, acc, p)

proc arm(m: Manager; u: Unit) =
  ## Back in `waiting`: compute the next elapse and arm the loop timer, or
  ## settle in `elapsed` (or `dead`) when no value can fire any more.
  let d = tdata(u)
  m.cancelLoop(u)
  m.computeDeadlines(u)
  if d.nextMono == NoDeadline and u.hasEvents:
    m.setTimerState(u, "waiting", "success")      # only OnClockChange=/OnTimezoneChange=: nothing to arm
    return
  if d.nextMono == NoDeadline:
    if u.def.timer.remainAfterElapse: m.setTimerState(u, "elapsed", "success")
    else: m.setTimerState(u, "dead", "success")
    return
  m.setTimerState(u, "waiting", "success")
  let uu = u
  d.fireAt = m.coalescedAt(u, d.nextMono)
  d.loopTimer = m.loop.addTimer(d.fireAt, proc() =
    tdata(uu).loopTimer = TimerId(0)
    m.elapse(uu))

proc triggerService(m: Manager; u: Unit)

proc elapse(m: Manager; u: Unit) =
  let d = tdata(u)
  if u.active != asActive or d.state notin ["waiting", "elapsed"]: return
  let nowM = m.clock.monoUsec
  let nowR = m.clock.realUsec
  for i in 0 ..< d.deadline.len:
    if d.deadline[i] != NoDeadline and d.deadline[i] <= nowM:
      d.fired[i] = true
      d.delay[i] = m.randomDelay(u)
  d.lastTrigger = nowR
  d.baseReal = nowR
  # a calendar value elapses again; only the monotonic ones are once per start
  let vals = u.def.timer.values
  for i, v in vals:
    if v.base == tbCalendar: d.fired[i] = false
  m.writeStamp(u, nowR)
  m.triggerService(u)

proc triggerService(m: Manager; u: Unit) =
  let d = tdata(u)
  let svc = m.lookup(triggeredUnit(u))
  if svc == nil or not svc.loadOk:
    logErr(u.id, "Unit " & triggeredUnit(u) & " not found, cannot trigger it.")
    m.setTimerState(u, "failed", "resources")
    return
  if svc.active in {asActive, asActivating, asReloading} or svc.job != nil and svc.job.typ.isStartLike:
    logInfo(u.id, "Triggered unit " & svc.id & " is already active.")
    m.arm(u)
    return
  logInfo(u.id, "Timer elapsed, starting " & svc.id & ".")
  m.setTimerState(u, "running", "success")
  try: discard submitJob(m, svc, jtStart, jmReplace, joDependency)
  except CatchableError as e:
    logWarn(u.id, "cannot start " & svc.id & ": " & e.msg)
    m.arm(u)

# ---- OnClockChange= / OnTimezoneChange= ----------------------------------------------
proc eventElapse(m: Manager; u: Unit; what: string) =
  let d = tdata(u)
  if u.active != asActive or d.state notin ["waiting", "elapsed"]: return
  logInfo(u.id, what & " changed, elapsing.")
  let nowR = m.clock.realUsec
  d.lastTrigger = nowR
  m.triggerService(u)

proc closeEvents(m: Manager; u: Unit) =
  let d = tdata(u)
  for w in d.watchIds: m.loop.delFd(w)
  for f in d.watchFds: discard close(f)
  d.watchIds.setLen 0
  d.watchFds.setLen 0
  m.loop.cancelTimer(d.eventTimer)
  d.eventTimer = TimerId(0)

proc localtimeSig(m: Manager): string =
  let p = m.roots.etc / "localtime"
  var st: Stat
  if lstat(p.cstring, st) != 0: return "-"
  result = $int64(st.st_ino) & ":" & $int64(st.st_mtime)
  try:
    if symlinkExists(p): result.add ":" & expandSymlink(p)
    if stat(p.cstring, st) == 0: result.add ":" & $int64(st.st_ino) & ":" & $int64(st.st_mtime)
  except CatchableError: discard

proc armTimerfd(fd: cint) =
  when defined(linux):
    var spec: Itimerspec
    spec.it_value.tv_sec = posix.Time(4_000_000_000)
    # absolute, cancelled when CLOCK_REALTIME is set discontinuously
    discard timerfdSettime(fd, 1 or 2, addr spec, nil)

proc setupEvents(m: Manager; u: Unit) =
  let d = tdata(u)
  m.closeEvents(u)
  let wantClock = u.def.timer.values.anyIt(it.base == tbClockChange)
  let wantZone = u.def.timer.values.anyIt(it.base == tbTimezoneChange)
  let uu = u
  d.lastRealCheck = m.clock.realUsec
  d.lastMonoCheck = m.clock.monoUsec
  d.zoneSig = localtimeSig(m)
  when defined(linux):
    if wantClock:
      let fd = timerfdCreate(CLOCK_REALTIME.cint, O_NONBLOCK or O_CLOEXEC)
      if fd >= 0:
        armTimerfd(fd)
        d.watchFds.add fd
        d.watchIds.add m.loop.addFd(fd, EvIn, proc(ev: uint32) =
          var buf: array[8, byte]
          let n = read(fd, addr buf[0], 8)
          if n < 0 and errno == ECANCELED:
            armTimerfd(fd)
            tdata(uu).lastRealCheck = m.clock.realUsec
            tdata(uu).lastMonoCheck = m.clock.monoUsec
            m.eventElapse(uu, "System clock"))
    if wantZone:
      let ifd = openWatcher()
      if ifd >= 0:
        d.watchFds.add ifd
        discard addWatch(ifd, m.roots.etc, WatchCreateDelete or 0x4'u32)
        d.watchIds.add m.loop.addFd(ifd, EvIn, proc(ev: uint32) =
          var hit = false
          for e in drainEvents(ifd):
            if e.name == "localtime": hit = true
          if hit and localtimeSig(m) != tdata(uu).zoneSig:
            tdata(uu).zoneSig = localtimeSig(m)
            m.eventElapse(uu, "Timezone"))
  # the polling check covers injected clocks and systems without inotify/timerfd
  proc tick() =
    let dd = tdata(uu)
    dd.eventTimer = TimerId(0)
    if uu.active != asActive: return
    let nowR = m.clock.realUsec
    let nowM = m.clock.monoUsec
    let drift = (nowR - dd.lastRealCheck) - (nowM - dd.lastMonoCheck)
    dd.lastRealCheck = nowR
    dd.lastMonoCheck = nowM
    if wantClock and abs(drift) > 1_500_000: m.eventElapse(uu, "System clock")
    if wantZone:
      let sig = localtimeSig(m)
      if sig != dd.zoneSig:
        dd.zoneSig = sig
        m.eventElapse(uu, "Timezone")
    if uu.active == asActive: dd.eventTimer = m.loop.addTimerIn(1_000_000, tick)
  d.eventTimer = m.loop.addTimerIn(1_000_000, tick)

proc watchTriggered(m: Manager; u: Unit) =
  let d = tdata(u)
  let uu = u
  d.sub = Subscription(patterns: @[globQuote(m.canonical(triggeredUnit(u)))], cb: proc(ev: StateEvent) =
    let dd = tdata(uu)
    if uu.active != asActive: return
    let vals = uu.def.timer.values
    case ev.active
    of asActivating, asActive:
      for i, v in vals:
        if v.base == tbUnitActive: dd.fired[i] = false
      if dd.state in ["waiting", "elapsed"]: m.arm(uu)
    of asInactive, asFailed:
      for i, v in vals:
        if v.base == tbUnitInactive: dd.fired[i] = false
      if dd.state == "running":
        # the job that started the unit finishes right after this state change: re-check afterwards
        m.loop.afterEvent(proc() =
          let d2 = tdata(uu)
          let svc = m.lookup(triggeredUnit(uu))
          if uu.active == asActive and d2.state == "running" and svc != nil and
              svc.active in {asInactive, asFailed} and (svc.job == nil or not svc.job.typ.isStartLike):
            m.arm(uu))
      elif dd.state in ["waiting", "elapsed"]: m.arm(uu)
    else: discard)
  m.subscribers.add d.sub

proc timerStart(m: Manager; u: Unit): StartOutcome =
  let d = tdata(u)
  if d.state in ["waiting", "running", "elapsed"]: return StartOutcome(kind: skAlreadyActive)
  let vals = u.def.timer.values
  if vals.len == 0:
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "Timer unit lacks value setting.")
  let svc = m.lookup(triggeredUnit(u))
  if svc == nil or not svc.loadOk:
    logErr(u.id, "Unit " & triggeredUnit(u) & " not found.")
    u.result = "resources"
    m.setTimerState(u, "failed", "resources")
    return StartOutcome(kind: skStarted)
  d.armedMono = m.clock.monoUsec
  d.armedReal = m.clock.realUsec
  d.baseReal = d.armedReal
  d.lastTrigger = 0
  d.fired = newSeq[bool](vals.len)
  d.deadline = newSeq[int64](vals.len)
  d.delay = newSeq[int64](vals.len)
  for i in 0 ..< vals.len: d.delay[i] = m.randomDelay(u)
  if u.def.timer.persistent and u.hasCalendar:
    let stamp = m.readStamp(u)
    if stamp > 0:
      d.lastTrigger = stamp
      d.baseReal = stamp
  u.result = "success"
  m.unsubscribe(u)
  m.watchTriggered(u)
  if u.hasEvents: m.setupEvents(u)
  m.arm(u)
  StartOutcome(kind: skStarted)

proc timerStop(m: Manager; u: Unit) =
  let d = tdata(u)
  m.cancelLoop(u)
  m.closeEvents(u)
  m.unsubscribe(u)
  if d.stampPending and d.lastTrigger > 0: m.writeStamp(u, d.lastTrigger)
  m.setTimerState(u, "dead", "success")

proc timerStatus(m: Manager; u: Unit): StatusExtras =
  result.exitCode = -1
  let d = tdata(u)
  if d.state == "waiting" and d.nextReal > 0: result.extra.add ("next_run", $d.nextReal)
  if d.lastTrigger > 0: result.extra.add ("last_run", $d.lastTrigger)

proc timerProperties(m: Manager; u: Unit): seq[(string, string)] =
  let d = tdata(u)
  result.add ("Unit", triggeredUnit(u))
  result.add ("Result", if u.result.len > 0: u.result else: "success")
  result.add ("NextElapseUSecRealtime", if d.state == "waiting" and d.nextReal > 0: $d.nextReal else: "0")
  result.add ("LastTriggerUSec", if d.lastTrigger > 0: $d.lastTrigger else: "0")

proc attach*(m: Manager; u: Unit) =
  u.data = TimerData(state: "dead", nextMono: NoDeadline)
  u.sub = "dead"
  u.ops = UnitOps(start: timerStart, stop: timerStop, status: timerStatus, properties: timerProperties,
    resetFailed: proc(m: Manager; u: Unit) =
      if u.active == asFailed: m.setTimerState(u, "dead", "success"),
    fail: proc(m: Manager; u: Unit; r: string) =
      m.cancelLoop(u)
      m.closeEvents(u)
      m.unsubscribe(u)
      m.setTimerState(u, "failed", r),
    shutdown: proc(m: Manager; u: Unit) =
      m.cancelLoop(u)
      m.closeEvents(u)
      m.unsubscribe(u))

proc installTimerSupport*() =
  timerAttach = attach
  calendarValidator = calendarValid
