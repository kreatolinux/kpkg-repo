## Automount units: an autofs direct mount (protocol 5) at `Where=` whose lookups
## start the matching `.mount` unit. The manager holds the autofs pipe, answers
## `missing_direct` packets with `AUTOFS_IOC_READY` / `AUTOFS_IOC_FAIL` once the
## mount job ends, and with `TimeoutIdleSec=` asks the kernel to expire idle mounts
## (`expire_direct` packets stop the mount unit). Linux only: elsewhere a start
## fails with `resources`.
import std/[posix, strutils, sequtils, sets]
import ../common/[logging]
import ../unitfile/model
import ../engine/[types, graph, jobs, unitstate, eventloop, manager]
import ./mount

when defined(linux):
  import std/os
  import ./subs
  proc c_mount(src, target, fstype: cstring; flags: culong; data: cstring): cint
    {.importc: "mount", header: "<sys/mount.h>".}
  proc c_umount2(target: cstring; flags: cint): cint {.importc: "umount2", header: "<sys/mount.h>".}
  proc c_pipe2(fds: ptr array[2, cint]; flags: cint): cint {.importc: "pipe2", header: "<unistd.h>".}
  let ODirect {.importc: "O_DIRECT", header: "<fcntl.h>".}: cint
  let ODirectory {.importc: "O_DIRECTORY", header: "<fcntl.h>".}: cint
  proc c_exit(code: cint) {.importc: "_exit", header: "<unistd.h>".}
  proc c_ioctl(fd: cint; req: culong): cint {.importc: "ioctl", header: "<sys/ioctl.h>", varargs.}

const
  PtypeMissingDirect = 5'i32
  PtypeExpireDirect = 6'i32
  IocReady = 0x9360'u
  IocFail = 0x9361'u
  IocCatatonic = 0x9362'u
  IocSetTimeout = 0xC0089364'u
  IocExpireMulti = 0x40049366'u

type
  AutomountData* = ref object of RootObj
    state: string                  ## dead, waiting, running, failed
    pipeFd: cint
    ioctlFd: cint
    watchId: WatchId
    expireTimer: TimerId
    expirePid: int
    sub: Subscription
    tokens: seq[uint32]            ## missing_direct requests waiting for the mount job

proc adata(u: Unit): AutomountData = AutomountData(u.data)

proc mountUnitOf*(u: Unit): string = u.def.common.prefix & ".mount"

proc setAuto(m: Manager; u: Unit; sub: string; result = "") =
  let d = adata(u)
  d.state = sub
  let a = case sub
    of "dead": asInactive
    of "failed": asFailed
    else: asActive
  m.setState(u, a, sub, result)

proc reply(d: AutomountData; token: uint32; ok: bool) =
  when defined(linux):
    if d.ioctlFd >= 0: discard c_ioctl(d.ioctlFd, culong(if ok: IocReady else: IocFail), clong(token))

proc unmountAutofs(where: string) =
  when defined(linux):
    for _ in 0 ..< 8:
      var top = ""
      try:
        for e in parseMountinfo(readFile("/proc/self/mountinfo")):
          if e.mountPoint == where: top = e.fstype
      except IOError: discard
      if top != "autofs": break
      if c_umount2(where.cstring, 2) != 0: break    # MNT_DETACH

proc cancelExpire(m: Manager; u: Unit) =
  let d = adata(u)
  m.loop.cancelTimer(d.expireTimer)
  d.expireTimer = TimerId(0)

proc teardown(m: Manager; u: Unit; unmount: bool) =
  let d = adata(u)
  m.cancelExpire(u)
  if d.sub != nil:
    m.subscribers.keepItIf(it != d.sub)
    d.sub = nil
  if d.watchId != WatchId(0):
    m.loop.delFd(d.watchId)
    d.watchId = WatchId(0)
  for t in d.tokens: d.reply(t, false)
  d.tokens.setLen 0
  when defined(linux):
    if d.ioctlFd >= 0: discard c_ioctl(d.ioctlFd, culong(IocCatatonic))
  if d.ioctlFd >= 0: discard close(d.ioctlFd)
  if d.pipeFd >= 0: discard close(d.pipeFd)
  d.ioctlFd = -1
  d.pipeFd = -1
  ozMounts.excl u.def.mount.where
  if unmount: unmountAutofs(u.def.mount.where)

proc scheduleExpire(m: Manager; u: Unit)

proc expireNow(m: Manager; u: Unit) =
  ## The ioctl blocks until the daemon answers, so a short-lived child issues it.
  let d = adata(u)
  d.expireTimer = TimerId(0)
  if u.active != asActive or d.ioctlFd < 0: return
  if d.expirePid > 0 and kill(Pid(d.expirePid), 0) == 0:
    m.scheduleExpire(u)
    return
  when defined(linux):
    let fd = d.ioctlFd
    let pid = fork()
    if pid == 0:
      var flags: cint = 0
      let r = c_ioctl(fd, culong(IocExpireMulti), addr flags)
      c_exit(if r == 0: 0 else: 1)
    elif pid > 0:
      d.expirePid = int(pid)
  m.scheduleExpire(u)

proc scheduleExpire(m: Manager; u: Unit) =
  let d = adata(u)
  let idle = u.def.mount.timeoutIdleSec
  if idle <= 0 or idle == Infinity or d.state != "running" or d.expireTimer.isSet: return
  d.expireTimer = m.loop.addTimerIn(max(1_000_000'i64, idle div 3), proc() = m.expireNow(u))

proc mountEnded(m: Manager; u: Unit) =
  ## The mount unit is gone: back to waiting for the next lookup.
  let d = adata(u)
  m.cancelExpire(u)
  if d.state == "running": m.setAuto(u, "waiting", "success")

proc trigger(m: Manager; u: Unit; token: uint32) =
  let d = adata(u)
  let mnt = m.lookup(mountUnitOf(u))
  if mnt == nil or not mnt.loadOk:
    logErr(u.id, "Unit " & mountUnitOf(u) & " not found, cannot trigger it.")
    d.reply(token, false)
    return
  if mnt.active == asActive:
    d.reply(token, true)
    return
  d.tokens.add token
  if d.state == "waiting": m.setAuto(u, "running", "success")
  logInfo(u.id, "Got automount request for " & u.def.mount.where & ", triggering " & mnt.id & ".")
  try:
    discard submitJob(m, mnt, jtStart, jmReplace, joDependency, proc(o: JobOutcome) =
      let ok = o.result == jrDone and mnt.active == asActive
      let ts = d.tokens
      d.tokens.setLen 0
      for t in ts: d.reply(t, ok)
      if ok: m.scheduleExpire(u)
      elif u.active == asActive and d.state == "running": m.setAuto(u, "waiting", "success"))
  except CatchableError as e:
    logWarn(u.id, "cannot start " & mnt.id & ": " & e.msg)
    let ts = d.tokens
    d.tokens.setLen 0
    for t in ts: d.reply(t, false)
    if d.state == "running": m.setAuto(u, "waiting", "success")

proc expireRequest(m: Manager; u: Unit; token: uint32) =
  let d = adata(u)
  let mnt = m.lookup(mountUnitOf(u))
  if mnt == nil or mnt.active != asActive:
    d.reply(token, true)
    return
  logInfo(u.id, "Mount " & u.def.mount.where & " is idle, unmounting.")
  try:
    discard submitJob(m, mnt, jtStop, jmReplace, joDependency, proc(o: JobOutcome) =
      d.reply(token, o.result == jrDone))
  except CatchableError as e:
    logWarn(u.id, "cannot stop " & mnt.id & ": " & e.msg)
    d.reply(token, false)

proc readPackets(m: Manager; u: Unit) =
  let d = adata(u)
  var buf: array[1024, byte]
  while d.pipeFd >= 0:
    let n = read(d.pipeFd, addr buf[0], buf.len)
    if n <= 0: break
    if n < 12: continue
    var typ: int32
    var token: uint32
    copyMem(addr typ, addr buf[4], 4)
    copyMem(addr token, addr buf[8], 4)
    if typ == PtypeMissingDirect: m.trigger(u, token)
    elif typ == PtypeExpireDirect: m.expireRequest(u, token)
    else: logWarn(u.id, "ignoring autofs packet type " & $typ)

proc automountStart(m: Manager; u: Unit): StartOutcome =
  let d = adata(u)
  if d.state in ["waiting", "running"]: return StartOutcome(kind: skAlreadyActive)
  let c = u.def.mount
  if c.where.len == 0 or not c.where.startsWith("/"):
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "Unit " & u.id & " has no valid Where=.")
  if mountUnitName(c.where) != mountUnitOf(u):
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "Where= setting doesn't match unit name. Refusing.")
  let mnt = m.lookup(mountUnitOf(u))
  if mnt == nil or not mnt.loadOk:
    logErr(u.id, "Unit " & mountUnitOf(u) & " not found.")
    m.setAuto(u, "failed", "resources")
    return StartOutcome(kind: skStarted)
  u.result = "success"
  when not defined(linux):
    logErr(u.id, "automount units need Linux")
    m.setAuto(u, "failed", "resources")
    return StartOutcome(kind: skStarted)
  else:
    try:
      for e in parseMountinfo(readFile(m.roots.mountinfo)):
        if e.mountPoint == c.where and e.fstype != "autofs":
          logErr(u.id, "Path " & c.where & " is already a mount point, refusing start.")
          m.setAuto(u, "failed", "mount-failed")
          return StartOutcome(kind: skStarted)
    except IOError: discard
    try:
      createDir(c.where)
      discard chmod(c.where.cstring, Mode(c.directoryMode))
    except CatchableError as e:
      logErr(u.id, "Failed to create mount point " & c.where & ": " & e.msg)
      m.setAuto(u, "failed", "resources")
      return StartOutcome(kind: skStarted)
    var p: array[2, cint]
    if c_pipe2(addr p, O_CLOEXEC or ODirect or O_NONBLOCK) != 0:
      logErr(u.id, "Failed to create autofs pipe: " & osErrorMsg(osLastError()))
      m.setAuto(u, "failed", "resources")
      return StartOutcome(kind: skStarted)
    var opts = "fd=" & $p[1] & ",pgrp=" & $getpgrp() & ",minproto=5,maxproto=5,direct"
    if c.extraOptions.len > 0: opts.add "," & c.extraOptions
    let source = "systemd-" & $getpid()
    let r = c_mount(source.cstring, c.where.cstring, "autofs", 0, opts.cstring)
    let err = osErrorMsg(osLastError())
    discard close(p[1])
    if r != 0:
      discard close(p[0])
      logErr(u.id, "Failed to mount autofs at " & c.where & ": " & err)
      m.setAuto(u, "failed", "mount-failed")
      return StartOutcome(kind: skStarted)
    d.pipeFd = p[0]
    ozMounts.incl c.where
    d.ioctlFd = open(c.where.cstring, O_RDONLY or ODirectory or O_CLOEXEC)
    if d.ioctlFd < 0:
      logErr(u.id, "Failed to open " & c.where & ": " & osErrorMsg(osLastError()))
      m.teardown(u, true)
      m.setAuto(u, "failed", "mount-failed")
      return StartOutcome(kind: skStarted)
    var idle = culong(0)
    if c.timeoutIdleSec > 0 and c.timeoutIdleSec != Infinity: idle = culong((c.timeoutIdleSec + 999_999) div 1_000_000)
    discard c_ioctl(d.ioctlFd, culong(IocSetTimeout), addr idle)
    let uu = u
    d.watchId = m.loop.addFd(d.pipeFd, EvIn, proc(ev: uint32) = m.readPackets(uu))
    d.sub = Subscription(patterns: @[globQuote(m.canonical(mountUnitOf(u)))], cb: proc(ev: StateEvent) =
      if uu.active != asActive: return
      case ev.active
      of asInactive, asFailed: m.mountEnded(uu)
      of asActive:
        if adata(uu).state == "waiting": m.setAuto(uu, "running", "success")
        m.scheduleExpire(uu)
      else: discard)
    m.subscribers.add d.sub
    m.setAuto(u, if mnt.active == asActive: "running" else: "waiting", "success")
    m.scheduleExpire(u)
    StartOutcome(kind: skStarted)

proc automountStop(m: Manager; u: Unit) =
  m.teardown(u, true)
  m.setAuto(u, "dead", "success")

proc attach*(m: Manager; u: Unit) =
  u.data = AutomountData(state: "dead", pipeFd: -1, ioctlFd: -1)
  u.sub = "dead"
  u.ops = UnitOps(start: automountStart, stop: automountStop,
    resetFailed: proc(m: Manager; u: Unit) =
      if u.active == asFailed: m.setAuto(u, "dead", "success"),
    fail: proc(m: Manager; u: Unit; r: string) =
      m.teardown(u, true)
      m.setAuto(u, "failed", r),
    shutdown: proc(m: Manager; u: Unit) = m.teardown(u, true))

proc installAutomountSupport*() =
  automountAttach = attach
