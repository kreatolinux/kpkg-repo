## A thin inotify wrapper shared by the path and timer units. Elsewhere than
## Linux the watcher never opens (`fd < 0`) and callers poll.
when defined(linux):
  import std/[inotify, posix]

type FsEvent* = object
  wd*: cint
  mask*: uint32
  name*: string

const
  WatchChanged* = 0x00000008'u32 or 0x00000100'u32 or 0x00000200'u32 or 0x00000400'u32 or
    0x00000800'u32 or 0x00000040'u32 or 0x00000080'u32 or 0x00000004'u32
    ## CLOSE_WRITE | CREATE | DELETE | DELETE_SELF | MOVE_SELF | MOVED_FROM | MOVED_TO | ATTRIB
  WatchModify* = 0x00000002'u32
  WatchCreateDelete* = 0x00000100'u32 or 0x00000200'u32 or 0x00000040'u32 or 0x00000080'u32 or
    0x00000400'u32 or 0x00000800'u32      ## CREATE | DELETE | MOVED_* | DELETE_SELF | MOVE_SELF

proc openWatcher*(): cint =
  when defined(linux): inotify_init1(O_NONBLOCK or O_CLOEXEC)
  else: -1

proc addWatch*(fd: cint; path: string; mask: uint32): cint =
  ## The watch descriptor, or -1. Adding the same inode again updates its mask and returns the same one.
  when defined(linux):
    if fd < 0: return -1
    inotify_add_watch(fd, path.cstring, mask)
  else: -1

proc drainEvents*(fd: cint): seq[FsEvent] =
  when defined(linux):
    if fd < 0: return
    var buf: array[8192, byte]
    while true:
      let n = read(fd, addr buf[0], buf.len)
      if n <= 0: break
      var off = 0
      while off + sizeof(InotifyEvent) <= n:
        let ev = cast[ptr InotifyEvent](addr buf[off])
        var name = ""
        if ev.len > 0:
          name = $cast[cstring](addr buf[off + sizeof(InotifyEvent)])
        result.add FsEvent(wd: ev.wd, mask: ev.mask, name: name)
        off += sizeof(InotifyEvent) + int(ev.len)
  else: discard
