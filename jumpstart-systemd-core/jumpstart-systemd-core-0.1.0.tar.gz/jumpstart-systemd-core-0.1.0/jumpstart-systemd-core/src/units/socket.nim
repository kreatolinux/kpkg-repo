## Socket units and socket activation (spec §11.1): listening descriptors for
## stream, datagram, seqpacket, FIFO and special files, activation of the
## triggered service (`Accept=no`) or of a per-connection instance
## (`Accept=yes`), descriptor passing, trigger limits.
## Not in this release: message-queue listeners, the `ExecStart*`/
## `ExecStop*` commands of socket units.
import std/[os, posix, strutils, tables, sequtils]
import ../common/[logging, names, clock, fdutil]
import ../unitfile/model
import ../engine/[types, graph, jobs, unitstate, eventloop, manager]
import ../service/[service, execrun]

type
  SocketData* = ref object of RootObj
    state: string
    listeners: seq[Listener]
    watches: seq[WatchId]
    accepted: int
    trigger: RateLimit
    polling: bool
    sub: Subscription
    liveInstances: Table[string, string]      ## instance name -> peer key
  Listener = object
    fd: cint
    spec: ListenSpec
    path: string                              ## filesystem node to remove, if any

var pendingConnections: Table[string, cint]   ## instance name -> accepted descriptor

proc sdata(u: Unit): SocketData = SocketData(u.data)

proc fdName(u: Unit): string =
  let n = u.def.socket.fileDescriptorName
  if n.len > 0: n else: u.id[0 ..< u.id.len - ".socket".len]

proc triggeredService*(u: Unit): string =
  let s = u.def.socket.service
  if s.len > 0: s else: u.def.common.prefix & ".service"

proc setSock(m: Manager; u: Unit; sub: string; result = "") =
  let a = case sub
    of "dead": asInactive
    of "listening", "running": asActive
    of "failed": asFailed
    else: asActivating
  sdata(u).state = sub
  m.setState(u, a, sub, result)

# ---- address parsing and socket creation ------------------------------------------
type Addr = object
  family: cint
  sockType: cint
  bytes: string           ## raw sockaddr
  path: string

proc setOpt(fd: cint; level, opt: cint; value: int) =
  var v = cint(value)
  discard setsockopt(SocketHandle(fd), level, opt, addr v, SockLen(sizeof(v)))

proc bindC(fd: cint; a: pointer; len: cint): cint {.importc: "bind", header: "<sys/socket.h>".}

proc unixAddress(p: string): (string, bool) =
  var a: Sockaddr_un
  a.sun_family = TSa_Family(AF_UNIX)
  let abstract = p.startsWith("@")
  let name = if abstract: "\0" & p[1 .. ^1] else: p
  if name.len >= a.sun_path.len: raise newException(ValueError, "socket path too long: " & p)
  copyMem(addr a.sun_path[0], name.cstring, name.len)
  var raw = newString(sizeof(a))
  copyMem(addr raw[0], addr a, sizeof(a))
  let used = offsetOf(Sockaddr_un, sun_path) + name.len + (if abstract: 0 else: 1)
  (raw[0 ..< min(used, raw.len)], abstract)

proc createListener(m: Manager; u: Unit; spec: ListenSpec): Listener =
  ## Raises OSError/ValueError with a readable message.
  let c = u.def.socket
  result.spec = spec
  let isStream = spec.kind in {lkStream, lkSequentialPacket}
  case spec.kind
  of lkFifo:
    createDir(spec.address.parentDir)
    discard unlink(spec.address.cstring)
    if mkfifo(spec.address.cstring, Mode(c.socketMode)) != 0: raiseOSError(osLastError(), spec.address)
    discard chmod(spec.address.cstring, Mode(c.socketMode))
    result.fd = open(spec.address.cstring, O_RDWR or O_NONBLOCK or O_CLOEXEC)
    if result.fd < 0: raiseOSError(osLastError(), spec.address)
    result.path = spec.address
    return
  of lkSpecial:
    result.fd = open(spec.address.cstring, O_RDWR or O_NOCTTY or O_CLOEXEC)
    if result.fd < 0: raiseOSError(osLastError(), spec.address)
    return
  of lkNetlink:
    # `ListenNetlink=kobject-uevent 1` (systemd-udevd-kernel.socket): family name, then the group mask
    when defined(linux):
      let parts = spec.address.splitWhitespace
      if parts.len == 0: raise newException(ValueError, "ListenNetlink= needs a netlink family")
      let proto = case parts[0]
        of "route": 0
        of "firewall": 3
        of "audit": 9
        of "kobject-uevent": 15
        of "generic": 16
        else: raise newException(ValueError, "unknown netlink family " & parts[0])
      let groups = if parts.len > 1: parseUInt(parts[1]) else: 0'u
      result.fd = cint(socket(cint(16), cint(SOCK_RAW) or cint(SOCK_CLOEXEC), cint(proto)))
      if result.fd < 0: raiseOSError(osLastError(), "socket")
      setCloexec(result.fd); setNonBlocking(result.fd)
      # udevd drops uevents that carry no sender credentials ("No sender credentials received,
      # ignoring message"), so the unit's PassCredentials=yes has to reach the socket
      if c.passCredentials: setOpt(result.fd, SOL_SOCKET, 16, 1)      # SO_PASSCRED
      if c.receiveBuffer > 0:
        setOpt(result.fd, SOL_SOCKET, 33, int(c.receiveBuffer))       # SO_RCVBUFFORCE (128M for udev)
        setOpt(result.fd, SOL_SOCKET, SO_RCVBUF, int(c.receiveBuffer))
      if c.sendBuffer > 0: setOpt(result.fd, SOL_SOCKET, SO_SNDBUF, int(c.sendBuffer))
      var sa: array[12, byte]               # struct sockaddr_nl: family, pad, pid, groups
      sa[0] = 16
      copyMem(addr sa[8], unsafeAddr groups, 4)
      if bindC(result.fd, addr sa, 12) != 0:
        let e = osLastError(); discard close(result.fd); raiseOSError(e, "bind netlink " & spec.address)
      return
    else:
      raise newException(ValueError, "ListenNetlink= needs Linux")
  of lkMessageQueue:
    raise newException(ValueError, $spec.kind & "= is not supported by this release")
  else: discard
  let stype = case spec.kind
    of lkStream: SOCK_STREAM
    of lkSequentialPacket: SOCK_SEQPACKET
    else: SOCK_DGRAM
  var sa: string
  var family: cint
  var unixPath = ""
  let a = spec.address
  if a.startsWith("/") or a.startsWith("@"):
    family = AF_UNIX
    sa = unixAddress(a)[0]
    if a.startsWith("/"): unixPath = a
  else:
    var host = ""
    var port = ""
    if a.startsWith("["):
      let close = a.find(']')
      host = a[1 ..< close]
      port = a[close + 2 .. ^1]
    elif a.allCharsInSet(Digits): port = a
    else:
      let colon = a.rfind(':')
      host = a[0 ..< colon]
      port = a[colon + 1 .. ^1]
    var hints: AddrInfo
    hints.ai_family = if host.len == 0 or ':' in host: AF_INET6 else: AF_INET
    hints.ai_socktype = if isStream: SOCK_STREAM else: SOCK_DGRAM
    hints.ai_flags = AI_NUMERICHOST or AI_NUMERICSERV or AI_PASSIVE
    var info: ptr AddrInfo
    let rc = getaddrinfo((if host.len == 0: "::" else: host).cstring, port.cstring, addr hints, info)
    if rc != 0: raise newException(ValueError, "bad listen address " & a & ": " & $gai_strerror(rc))
    family = info.ai_family
    sa = newString(int(info.ai_addrlen))
    copyMem(addr sa[0], info.ai_addr, int(info.ai_addrlen))
    freeaddrinfo(info)
  result.fd = cint(socket(family, stype, 0))
  if result.fd < 0: raiseOSError(osLastError(), "socket")
  setCloexec(result.fd)
  setNonBlocking(result.fd)
  let fd = result.fd
  setOpt(fd, SOL_SOCKET, SO_REUSEADDR, 1)
  if c.keepAlive: setOpt(fd, SOL_SOCKET, SO_KEEPALIVE, 1)
  if c.broadcast: setOpt(fd, SOL_SOCKET, SO_BROADCAST, 1)
  if c.receiveBuffer > 0: setOpt(fd, SOL_SOCKET, SO_RCVBUF, int(c.receiveBuffer))
  if c.sendBuffer > 0: setOpt(fd, SOL_SOCKET, SO_SNDBUF, int(c.sendBuffer))
  when defined(linux):
    if c.passCredentials: setOpt(fd, SOL_SOCKET, 16, 1)            # SO_PASSCRED
    if c.reusePort: setOpt(fd, SOL_SOCKET, 15, 1)                  # SO_REUSEPORT
  if family == AF_INET6 and c.bindIPv6Only != biDefault:
    setOpt(fd, IPPROTO_IPV6, IPV6_V6ONLY, (if c.bindIPv6Only == biIpv6Only: 1 else: 0))
  if family in [AF_INET, AF_INET6] and isStream and c.noDelay: setOpt(fd, IPPROTO_TCP, TCP_NODELAY, 1)
  if unixPath.len > 0:
    createDir(unixPath.parentDir)
    if fileExists(unixPath) or symlinkExists(unixPath):
      let probe = connectUnix(unixPath, isStream)
      if probe >= 0:
        discard close(probe)
        discard close(fd)
        raise newException(OSError, "Address already in use: " & unixPath)
      discard unlink(unixPath.cstring)
    result.path = unixPath
  if bindSocket(SocketHandle(fd), cast[ptr SockAddr](unsafeAddr sa[0]), SockLen(sa.len)) != 0:
    let e = osLastError()
    discard close(fd)
    raiseOSError(e, a)
  if unixPath.len > 0:
    discard chmod(unixPath.cstring, Mode(c.socketMode))
    if c.socketUser.len > 0 or c.socketGroup.len > 0:
      var uid = Uid(high(uint32))
      var gid = Gid(high(uint32))
      if c.socketUser.len > 0:
        let pw = getpwnam(c.socketUser.cstring)
        if pw != nil: uid = pw.pw_uid
      if c.socketGroup.len > 0:
        let gr = getgrnam(c.socketGroup.cstring)
        if gr != nil: gid = gr.gr_gid
      discard chown(unixPath.cstring, uid, gid)
  if spec.kind in {lkStream, lkSequentialPacket}:
    let backlog = if c.backlog == UnsetInt: 4096 else: c.backlog
    if listen(SocketHandle(fd), cint(backlog)) != 0:
      let e = osLastError()
      discard close(fd)
      raiseOSError(e, "listen")
  for sl in c.symlinks:
    try:
      discard unlink(sl.cstring)
      createSymlink(a, sl)
    except OSError: logWarn(u.id, "cannot create symlink " & sl)

# ---- activation ---------------------------------------------------------------------
proc stopPolling(m: Manager; u: Unit) =
  let d = sdata(u)
  for w in d.watches: m.loop.delFd(w)
  d.watches = @[]
  d.polling = false

proc startPolling(m: Manager; u: Unit)

proc peerKey(fd: cint): string =
  var sa: Sockaddr_storage
  var len = SockLen(sizeof(sa))
  var local = "0"
  var peer = "0"
  if getpeername(SocketHandle(fd), cast[ptr SockAddr](addr sa), addr len) == 0:
    if sa.ss_family == TSa_Family(AF_UNIX):
      var cred: array[3, cint]       # pid, uid, gid on Linux
      var cl = SockLen(sizeof(cred))
      when defined(linux):
        if getsockopt(SocketHandle(fd), SOL_SOCKET, 17, addr cred, addr cl) == 0:
          peer = $cred[0] & "-" & $cred[1]
    else:
      var host = newString(64)
      var serv = newString(16)
      if getnameinfo(cast[ptr SockAddr](addr sa), len, cstring(host), 64, cstring(serv), 16,
          NI_NUMERICHOST or NI_NUMERICSERV) == 0:
        peer = $cstring(host) & ":" & $cstring(serv)
  var lsa: Sockaddr_storage
  var ll = SockLen(sizeof(lsa))
  if getsockname(SocketHandle(fd), cast[ptr SockAddr](addr lsa), addr ll) == 0 and
      lsa.ss_family != TSa_Family(AF_UNIX):
    var host = newString(64)
    var serv = newString(16)
    if getnameinfo(cast[ptr SockAddr](addr lsa), ll, cstring(host), 64, cstring(serv), 16,
        NI_NUMERICHOST or NI_NUMERICSERV) == 0:
      local = $cstring(host) & ":" & $cstring(serv)
  local & "-" & peer

proc triggerAllowed(m: Manager; u: Unit): bool =
  let c = u.def.socket
  let d = sdata(u)
  let burst = if c.triggerLimitBurst == UnsetInt: (if c.accept: 20 else: 200) else: c.triggerLimitBurst
  d.trigger.intervalUsec = c.triggerLimitIntervalSec
  d.trigger.burst = burst
  let now = m.clock.monoUsec
  if d.trigger.begin == 0 or now - d.trigger.begin > d.trigger.intervalUsec:
    d.trigger.begin = now
    d.trigger.count = 0
  inc d.trigger.count
  d.trigger.count <= burst

proc activate(m: Manager; u: Unit; l: Listener) =
  let c = u.def.socket
  let d = sdata(u)
  if not triggerAllowed(m, u):
    logWarn(u.id, "Trigger limit hit, refusing further activations")
    m.stopPolling(u)
    m.setSock(u, "failed", "trigger-limit-hit")
    return
  if c.accept:
    let cfd = cint(accept(SocketHandle(l.fd), nil, nil))
    if cfd < 0: return
    setCloexec(cfd)
    inc d.accepted
    let inst = instantiate(u.def.common.prefix & "@.service", $d.accepted & "-" & peerKey(cfd))
    if d.liveInstances.len >= c.maxConnections:
      logWarn(u.id, "Too many incoming connections (" & $d.liveInstances.len & ")")
      discard close(cfd)
      return
    pendingConnections[inst] = cfd
    d.liveInstances[inst] = ""
    let svc = m.lookup(inst)
    if svc == nil:
      logWarn(u.id, "no template service for " & inst)
      pendingConnections.del inst
      d.liveInstances.del inst
      discard close(cfd)
      return
    try: discard submitJob(m, svc, jtStart, jmReplace, joDependency)
    except CatchableError as e:
      logWarn(u.id, "cannot activate " & inst & ": " & e.msg)
      pendingConnections.del inst
      d.liveInstances.del inst
      discard close(cfd)
    return
  # Accept=no: stop polling, start the service, resume when it goes inactive
  m.stopPolling(u)
  m.setSock(u, "running")
  let svc = m.lookup(triggeredService(u))
  if svc == nil:
    logWarn(u.id, "triggered service " & triggeredService(u) & " not found")
    m.startPolling(u)
    m.setSock(u, "listening")
    return
  if svc.active in {asInactive, asFailed}:
    try: discard submitJob(m, svc, jtStart, jmReplace, joDependency)
    except CatchableError as e:
      logWarn(u.id, "cannot activate " & svc.id & ": " & e.msg)
  # resume polling once the service is down again
  if d.sub != nil: m.subscribers.keepItIf(it != d.sub)
  let svcName = svc.id
  d.sub = Subscription(id: 0, patterns: @[svcName], cb: proc(ev: StateEvent) =
    if ev.active in {asInactive, asFailed} and u.active == asActive and sdata(u).state == "running":
      let uu = m.lookup(svcName)
      if uu != nil and uu.job != nil and uu.job.typ == jtStart: return    # being started right now
      if sdata(u).sub != nil: m.subscribers.keepItIf(it != sdata(u).sub)
      sdata(u).sub = nil
      m.startPolling(u)
      m.setSock(u, "listening"))
  m.subscribers.add d.sub

proc startPolling(m: Manager; u: Unit) =
  let d = sdata(u)
  if d.polling: return
  d.polling = true
  for l in d.listeners:
    let lc = l
    if l.spec.kind == lkFifo or l.spec.kind == lkSpecial or true:
      d.watches.add m.loop.addFd(l.fd, EvIn, proc(ev: uint32) =
        if d.polling: m.activate(u, lc))

proc closeListeners(m: Manager; u: Unit; removeNodes: bool) =
  let d = sdata(u)
  m.stopPolling(u)
  for l in d.listeners:
    discard close(l.fd)
    if l.path.len > 0 and (removeNodes or l.spec.kind == lkFifo and u.def.socket.removeOnStop):
      discard unlink(l.path.cstring)
  d.listeners = @[]
  for sl in u.def.socket.symlinks: discard unlink(sl.cstring)
  if d.sub != nil:
    m.subscribers.keepItIf(it != d.sub)
    d.sub = nil

proc connectionEnded*(m: Manager; instance: string)

proc socketStart(m: Manager; u: Unit): StartOutcome =
  let d = sdata(u)
  if d.state in ["listening", "running"]: return StartOutcome(kind: skAlreadyActive)
  let c = u.def.socket
  if c.listen.len == 0:
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE",
      text: "Unit " & u.id & " has no Listen setting.")
  m.setSock(u, "start-pre")
  u.result = "success"
  for spec in c.listen:
    try: d.listeners.add m.createListener(u, spec)
    except CatchableError as e:
      logErr(u.id, "Failed to listen on " & spec.address & ": " & e.msg)
      m.closeListeners(u, true)
      m.setSock(u, "failed", "resources")
      return StartOutcome(kind: skStarted)
  d.trigger = RateLimit()
  if c.accept:
    d.sub = Subscription(patterns: @[u.def.common.prefix & "@*.service"], cb: proc(ev: StateEvent) =
      if ev.active in {asInactive, asFailed}: m.connectionEnded(ev.unit))
    m.subscribers.add d.sub
  m.setSock(u, "listening")
  m.startPolling(u)
  StartOutcome(kind: skStarted)

proc socketStop(m: Manager; u: Unit) =
  m.closeListeners(u, u.def.socket.removeOnStop or true)
  m.setSock(u, "dead", "success")

proc socketFdsFor*(m: Manager; svc: Unit): seq[PassedFdSpec] =
  ## §11.1.4: sockets named by `Sockets=` first, then those referencing the
  ## service; an `Accept=yes` instance gets its connection.
  if pendingConnections.hasKey(svc.id):
    # kept (and passed to every command of the instance) until the instance ends
    let fd = pendingConnections[svc.id]
    return @[PassedFdSpec(source: fd, name: "connection")]
  var order: seq[string]
  for s in svc.def.service.sockets: order.add m.canonical(s)
  for u in m.allUnits:
    if u.kind == ukSocket and not u.def.socket.accept and u.id notin order:
      if m.canonical(triggeredService(u)) == svc.id: order.add u.id
  for id in order:
    let u = m.units.getOrDefault(id)
    if u == nil or u.kind != ukSocket or not (u.data of SocketData): continue
    for l in sdata(u).listeners:
      result.add PassedFdSpec(source: l.fd, name: fdName(u))

proc socketStatus(m: Manager; u: Unit): StatusExtras =
  result.exitCode = -1
  for s in u.def.socket.listen:
    let kind = case s.kind
      of lkStream: "Stream"
      of lkDatagram: "Datagram"
      of lkSequentialPacket: "SequentialPacket"
      of lkFifo: "FIFO"
      of lkSpecial: "Special"
      of lkNetlink: "Netlink"
      of lkMessageQueue: "MessageQueue"
    result.listen.add s.address & " (" & kind & ")"

proc attach*(m: Manager; u: Unit) =
  u.data = SocketData(state: "dead", liveInstances: initTable[string, string]())
  u.sub = "dead"
  u.ops = UnitOps(start: socketStart, stop: socketStop, status: socketStatus,
    isBusy: proc(u: Unit): bool = sdata(u).listeners.len > 0 and u.active != asActive,
    resetFailed: proc(m: Manager; u: Unit) =
      if u.active == asFailed: m.setSock(u, "dead", "success"),
    fail: proc(m: Manager; u: Unit; r: string) =
      m.closeListeners(u, true)
      m.setSock(u, "failed", r),
    shutdown: proc(m: Manager; u: Unit) = m.closeListeners(u, true))

proc installSocketSupport*() =
  socketAttach = attach
  socketFdsHook = proc(m: Manager; svc: Unit): seq[PassedFdSpec] = socketFdsFor(m, svc)

proc connectionEnded*(m: Manager; instance: string) =
  ## An `Accept=yes` instance went inactive: free its slot and close its connection.
  if pendingConnections.hasKey(instance):
    discard close(pendingConnections[instance])
    pendingConnections.del instance
  for u in m.allUnits:
    if u.kind == ukSocket and u.data of SocketData: sdata(u).liveInstances.del instance
