## Calendar events of `systemd.time(7)` (spec §11.2.1): parsing and the next
## elapse after an instant. UTC is computed arithmetically; any other zone
## (and the local zone) goes through the C library's `localtime_r`/`mktime`,
## with `TZ` set for the duration of the computation (the manager is
## single-threaded). The search is bounded to 100 years.
import std/[strutils, options, os, posix]

type
  Item = object
    lo, hi, step: int          ## hi < 0: open ended (`a/s`); step >= 1
    loEnd, hiEnd: bool         ## day items only: counted from the end of the month (`~N`)
  Comp = object
    star: bool
    items: seq[Item]
  CalendarSpec* = object
    weekdays: set[0 .. 6]      ## Mon = 0; empty set: any
    year, month, day, hour, minute, second: Comp
    fracUsec: int64
    zone*: string              ## "" local, "UTC", or an IANA name

  Fields = object
    y, mo, d, h, mi, s: int

const
  WeekdayNames = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
  FullWeekdays = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
  MaxYear = 2262               ## inside int64 microseconds since 1970

proc isLeap(y: int): bool = (y mod 4 == 0 and y mod 100 != 0) or y mod 400 == 0
proc daysIn(y, mo: int): int =
  case mo
  of 2: (if isLeap(y): 29 else: 28)
  of 4, 6, 9, 11: 30
  else: 31

proc daysFromCivil(y, m, d: int): int64 =
  let yy = if m <= 2: y - 1 else: y
  let era = (if yy >= 0: yy else: yy - 399) div 400
  let yoe = yy - era * 400
  let doy = (153 * (m + (if m > 2: -3 else: 9)) + 2) div 5 + d - 1
  let doe = yoe * 365 + yoe div 4 - yoe div 100 + doy
  int64(era) * 146097 + doe - 719468

proc weekdayOf(y, m, d: int): int =
  ## Monday = 0.
  int(((daysFromCivil(y, m, d) mod 7) + 7 + 3) mod 7)    # 1970-01-01 was a Thursday (3)

proc timegmSec(f: Fields): int64 =
  daysFromCivil(f.y, f.mo, f.d) * 86400 + f.h * 3600 + f.mi * 60 + f.s

proc civilFromDays(z0: int64): (int, int, int) =
  let z = z0 + 719468
  let era = (if z >= 0: z else: z - 146096) div 146097
  let doe = z - era * 146097
  let yoe = (doe - doe div 1460 + doe div 36524 - doe div 146096) div 365
  let y = yoe + era * 400
  let doy = doe - (365 * yoe + yoe div 4 - yoe div 100)
  let mp = (5 * doy + 2) div 153
  let d = int(doy - (153 * mp + 2) div 5 + 1)
  let m = int(if mp < 10: mp + 3 else: mp - 9)
  (int(if m <= 2: y + 1 else: y), m, d)

proc gmFields(sec: int64): Fields =
  var days = sec div 86400
  var rem = sec mod 86400
  if rem < 0: (rem += 86400; dec days)
  let (y, m, d) = civilFromDays(days)
  Fields(y: y, mo: m, d: d, h: int(rem div 3600), mi: int((rem mod 3600) div 60), s: int(rem mod 60))

# ---- parsing --------------------------------------------------------------------
proc parseNum(s: string): Option[int] =
  if s.len == 0 or s.len > 9 or not s.allCharsInSet(Digits): return none(int)
  some(parseInt(s))

proc parseComp(text: string; minV, maxV: int; day = false; twoDigitYear = false): Option[Comp] =
  if text == "*": return some(Comp(star: true))
  var c = Comp()
  for part in text.split(','):
    var body = part
    var step = 1
    var hasStep = false
    let sl = body.find('/')
    if sl >= 0:
      let st = parseNum(body[sl + 1 .. ^1])
      if st.isNone or st.get < 1: return none(Comp)
      step = st.get
      hasStep = true
      body = body[0 ..< sl]
    var it = Item(step: step, hi: -1)
    proc val(s: string; isHi: bool): Option[int] =
      var t = s
      var fromEnd = false
      if day and t.startsWith("~"):
        fromEnd = true
        t = t[1 .. ^1]
      let n = parseNum(t)
      if n.isNone: return none(int)
      var v = n.get
      if fromEnd:
        if v < 1: return none(int)
        if isHi: it.hiEnd = true else: it.loEnd = true
        return some(v)
      if twoDigitYear and t.len <= 2:
        v = if v >= 70: 1900 + v else: 2000 + v
      some(v)
    let dd = body.find("..")
    if dd >= 0:
      let a = val(body[0 ..< dd], false)
      let b = val(body[dd + 2 .. ^1], true)
      if a.isNone or b.isNone: return none(Comp)
      it.lo = a.get; it.hi = b.get
    else:
      let a = val(body, false)
      if a.isNone: return none(Comp)
      it.lo = a.get
      it.hi = if hasStep: -1 else: a.get
      it.hiEnd = it.loEnd
    if not it.loEnd and (it.lo < minV or it.lo > maxV): return none(Comp)
    if not it.hiEnd and it.hi >= 0 and (it.hi < minV or it.hi > maxV): return none(Comp)
    c.items.add it
  some(c)

proc shorthand(s: string): string =
  case s.toLowerAscii
  of "minutely": "*-*-* *:*:00"
  of "hourly": "*-*-* *:00:00"
  of "daily": "*-*-* 00:00:00"
  of "monthly": "*-*-01 00:00:00"
  of "weekly": "Mon *-*-* 00:00:00"
  of "yearly", "annually": "*-01-01 00:00:00"
  of "quarterly": "*-01,04,07,10-01 00:00:00"
  of "semiannually": "*-01,07-01 00:00:00"
  else: ""

proc parseWeekdays(s: string): Option[set[0 .. 6]] =
  var r: set[0 .. 6]
  for part in s.split(','):
    let dd = part.find("..")
    proc one(n: string): int =
      let l = n.toLowerAscii
      for i in 0 .. 6:
        if l == WeekdayNames[i] or l == FullWeekdays[i]: return i
      -1
    if dd >= 0:
      let a = one(part[0 ..< dd])
      let b = one(part[dd + 2 .. ^1])
      if a < 0 or b < 0: return none(set[0 .. 6])
      var i = a
      while true:
        r.incl i
        if i == b: break
        i = (i + 1) mod 7
    else:
      let a = one(part)
      if a < 0: return none(set[0 .. 6])
      r.incl a
  some(r)

proc isWeekdayToken(s: string): bool =
  for ch in s:
    if ch notin Letters and ch notin {',', '.'}: return false
  parseWeekdays(s).isSome

proc zoneKnown(z: string): bool =
  z == "UTC" or fileExists("/usr/share/zoneinfo" / z) or fileExists("/usr/lib/zoneinfo" / z)

proc parseCalendar*(text: string): Option[CalendarSpec] =
  var expr = text.strip
  if expr.len == 0: return none(CalendarSpec)
  var toks = expr.splitWhitespace
  let sh = shorthand(toks[0])
  if sh.len > 0:
    toks = sh.splitWhitespace & toks[1 .. ^1]
  var spec = CalendarSpec()
  # the zone is a trailing word that is neither a weekday list nor a date/time
  if toks.len > 1:
    let last = toks[^1]
    if last.len > 0 and last[0] in Letters and not isWeekdayToken(last):
      if not zoneKnown(last): return none(CalendarSpec)
      spec.zone = last
      toks.setLen(toks.len - 1)
  var datePart, timePart = ""
  var wd = none(set[0 .. 6])
  var rest: seq[string]
  for i, t in toks:
    if i == 0 and t.len > 0 and t[0] in Letters:
      wd = parseWeekdays(t)
      if wd.isNone: return none(CalendarSpec)
    else: rest.add t
  # `2020-01-01T10:00` form
  if rest.len == 1 and 'T' in rest[0] and rest[0][0] in Digits:
    let p = rest[0].split('T', 1)
    rest = @[p[0], p[1]]
  case rest.len
  of 0: discard
  of 1:
    if ':' in rest[0]: timePart = rest[0] else: datePart = rest[0]
  of 2: datePart = rest[0]; timePart = rest[1]
  else: return none(CalendarSpec)
  if wd.isSome: spec.weekdays = wd.get
  let anyDate = datePart.len > 0
  let anyTime = timePart.len > 0
  # defaults: a weekday alone or nothing at all means 00:00:00
  if datePart.len == 0: datePart = "*-*-*"
  if timePart.len == 0: timePart = "00:00:00"
  # date: [Y-]M-D with `~` in the last separator
  var y, mo, d: string
  var dp = datePart
  let tilde = dp.rfind('~')
  var dayDash = dp.rfind('-')
  if tilde > dayDash:
    # `*-02~3`, `*~1`: the `~` plays the part of the dash before the day
    dayDash = tilde
  let dayText = (if dayDash >= 0: (if tilde > 0 and tilde == dayDash: "~" & dp[dayDash + 1 .. ^1] else: dp[dayDash + 1 .. ^1]) else: dp)
  let head = if dayDash >= 0: dp[0 ..< dayDash] else: ""
  if dayDash < 0: return none(CalendarSpec)
  let hp = head.split('-')
  case hp.len
  of 1: y = "*"; mo = hp[0]
  of 2: y = hp[0]; mo = hp[1]
  else: return none(CalendarSpec)
  d = dayText
  if mo.len == 0 or d.len == 0 or y.len == 0: return none(CalendarSpec)
  let yc = parseComp(y, 1970, MaxYear, twoDigitYear = true)
  let moc = parseComp(mo, 1, 12)
  let dc = parseComp(d, 1, 31, day = true)
  if yc.isNone or moc.isNone or dc.isNone: return none(CalendarSpec)
  spec.year = yc.get; spec.month = moc.get; spec.day = dc.get
  # time
  let tp = timePart.split(':')
  if tp.len < 2 or tp.len > 3: return none(CalendarSpec)
  let hc = parseComp(tp[0], 0, 23)
  let mc = parseComp(tp[1], 0, 59)
  var secText = if tp.len == 3: tp[2] else: "0"
  var sc: Option[Comp]
  let dot = secText.find('.')
  if dot >= 0:
    let frac = secText[dot + 1 .. ^1]
    if frac.len == 0 or frac.len > 6 or not frac.allCharsInSet(Digits): return none(CalendarSpec)
    spec.fracUsec = parseInt(frac & repeat('0', 6 - frac.len))
    secText = secText[0 ..< dot]
  sc = parseComp(secText, 0, 59)
  if hc.isNone or mc.isNone or sc.isNone: return none(CalendarSpec)
  spec.hour = hc.get; spec.minute = mc.get; spec.second = sc.get
  discard anyDate; discard anyTime
  some(spec)

# ---- matching -------------------------------------------------------------------
proc matches(c: Comp; v: int): bool =
  if c.star: return true
  for it in c.items:
    let hi = if it.hi < 0: high(int) else: it.hi
    if v >= it.lo and v <= hi and (v - it.lo) mod it.step == 0: return true

proc matchesDay(c: Comp; d, last: int): bool =
  if c.star: return true
  for it in c.items:
    let lo = if it.loEnd: last - (it.lo - 1) else: it.lo
    let hi = if it.hi < 0: high(int) elif it.hiEnd: last - (it.hi - 1) else: it.hi
    let (a, b) = if lo <= hi: (lo, hi) else: (hi, lo)
    if d >= a and d <= b and (d - lo) mod it.step == 0: return true

proc nextVal(c: Comp; v, maxV: int): int =
  ## Smallest matching value >= v, or -1.
  var x = v
  while x <= maxV:
    if matches(c, x): return x
    inc x
  -1

proc searchFields(spec: CalendarSpec; st: Fields): Option[Fields] =
  ## Smallest matching field set >= st (proleptic, zone-free arithmetic).
  var cur = st
  var steps = 0
  while cur.y <= min(MaxYear, st.y + 100) and steps < 400_000:
    inc steps
    if not spec.year.matches(cur.y):
      inc cur.y
      cur.mo = 1; cur.d = 1; cur.h = 0; cur.mi = 0; cur.s = 0
      continue
    if not spec.month.matches(cur.mo):
      inc cur.mo
      if cur.mo > 12: (cur.mo = 1; inc cur.y)
      cur.d = 1; cur.h = 0; cur.mi = 0; cur.s = 0
      continue
    let dim = daysIn(cur.y, cur.mo)
    if cur.d > dim or not spec.day.matchesDay(cur.d, dim) or
        (spec.weekdays != {} and weekdayOf(cur.y, cur.mo, cur.d) notin spec.weekdays):
      inc cur.d
      if cur.d > dim: (cur.d = 1; inc cur.mo; if cur.mo > 12: (cur.mo = 1; inc cur.y))
      cur.h = 0; cur.mi = 0; cur.s = 0
      continue
    let h = nextVal(spec.hour, cur.h, 23)
    if h < 0:
      cur.h = 0; cur.mi = 0; cur.s = 0; inc cur.d
      if cur.d > dim: (cur.d = 1; inc cur.mo; if cur.mo > 12: (cur.mo = 1; inc cur.y))
      continue
    if h != cur.h: (cur.h = h; cur.mi = 0; cur.s = 0)
    let mi = nextVal(spec.minute, cur.mi, 59)
    if mi < 0:
      cur.mi = 0; cur.s = 0; inc cur.h
      if cur.h > 23:
        cur.h = 0; inc cur.d
        if cur.d > dim: (cur.d = 1; inc cur.mo; if cur.mo > 12: (cur.mo = 1; inc cur.y))
      continue
    if mi != cur.mi: (cur.mi = mi; cur.s = 0)
    let s = nextVal(spec.second, cur.s, 59)
    if s < 0:
      cur.s = 0; inc cur.mi
      if cur.mi > 59:
        cur.mi = 0; inc cur.h
        if cur.h > 23:
          cur.h = 0; inc cur.d
          if cur.d > dim: (cur.d = 1; inc cur.mo; if cur.mo > 12: (cur.mo = 1; inc cur.y))
      continue
    cur.s = s
    return some(cur)
  none(Fields)

proc canElapse*(spec: CalendarSpec): bool =
  ## False for calendars that can never match (`2020-02-30`).
  searchFields(spec, Fields(y: 1970, mo: 1, d: 1)).isSome or
    searchFields(spec, Fields(y: 2024, mo: 1, d: 1)).isSome

# ---- conversion to instants -----------------------------------------------------
proc toTm(f: Fields): Tm =
  result.tm_year = cint(f.y - 1900)
  result.tm_mon = cint(f.mo - 1)
  result.tm_mday = cint(f.d)
  result.tm_hour = cint(f.h)
  result.tm_min = cint(f.mi)
  result.tm_sec = cint(f.s)
  result.tm_isdst = -1

proc localFields(sec: int64): Fields =
  var t = Time(sec)
  var tm: Tm
  discard localtime_r(t, tm)
  Fields(y: int(tm.tm_year) + 1900, mo: int(tm.tm_mon) + 1, d: int(tm.tm_mday),
         h: int(tm.tm_hour), mi: int(tm.tm_min), s: int(tm.tm_sec))

proc localToEpoch(f: Fields): Option[int64] =
  ## None for a local time that does not exist (DST gap). An ambiguous time (DST
  ## overlap) resolves to its first occurrence.
  var best = none(int64)
  for isdst in [1.cint, 0.cint]:
    var tm = toTm(f)
    tm.tm_isdst = isdst
    let t = int64(mktime(tm))
    if t == -1: continue
    let back = localFields(t)
    if back.y == f.y and back.mo == f.mo and back.d == f.d and back.h == f.h and back.mi == f.mi and back.s == f.s:
      if best.isNone or t < best.get: best = some(t)
  best

proc nextElapseWith(spec: CalendarSpec; afterUsec: int64): Option[int64] =
  ## Smallest instant > `afterUsec` (microseconds since the epoch) matching `spec`.
  let utc = spec.zone == "UTC"
  var sec = afterUsec div 1_000_000      # candidates <= afterUsec are skipped below
  var tries = 0
  while tries < 1000:
    inc tries
    let st = if utc: gmFields(sec) else: localFields(sec)
    let found = searchFields(spec, st)
    if found.isNone: return none(int64)
    let f = found.get
    let epoch = if utc: some(timegmSec(f)) else: localToEpoch(f)
    if epoch.isSome:
      let r = epoch.get * 1_000_000 + spec.fracUsec
      if r > afterUsec: return some(r)
      sec = epoch.get + 1
    else:
      # a local time that does not exist (DST gap): continue from what the C library normalizes it to
      var tm = toTm(f)
      sec = max(int64(mktime(tm)), sec + 1)
  none(int64)

proc withZone*[T](zone: string; body: proc(): T): T =
  if zone.len == 0 or zone == "UTC": return body()
  let had = existsEnv("TZ")
  let old = getEnv("TZ")
  putEnv("TZ", zone)
  tzset()
  try: result = body()
  finally:
    if had: putEnv("TZ", old) else: delEnv("TZ")
    tzset()

proc nextElapse*(spec: CalendarSpec; afterUsec: int64): Option[int64] =
  let s = spec
  withZone(spec.zone, proc(): Option[int64] = nextElapseWith(s, afterUsec))

proc calendarValid*(text: string): bool =
  let p = parseCalendar(text)
  p.isSome and canElapse(p.get)
