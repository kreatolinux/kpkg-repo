## Swap units: `swapon`/`swapoff` as control processes, state read from
## `/proc/swaps` (pollable), mirror units for every active swap area, and the
## fstab generator entries for `swap` lines.
import std/[os, posix, options, strutils, tables, sets]
import jumpstartcore/reaper
import ../common/[logging, names, roots]
import ../unitfile/[model, index]
import ../engine/[types, graph, unitstate, eventloop, manager]
import ../service/[execrun, execcontext]
import ./mount

type
  SwapEntry* = object
    path*, typ*: string
    size*, used*: int64
    priority*: int
  SwapData* = ref object of RootObj
    state: string
    pid: int
    timer: TimerId
    stopRequested: bool
    kernel: Option[SwapEntry]

proc swapUnitName*(what: string): string = escapePath(what) & ".swap"

proc parseProcSwaps*(text: string): seq[SwapEntry] =
  ## `Filename Type Size Used Priority`, the header line skipped.
  for line in text.splitLines:
    let f = line.splitWhitespace
    if f.len < 5 or f[0] == "Filename": continue
    try:
      result.add SwapEntry(path: decodeOctal(f[0]), typ: f[1], size: parseBiggestInt(f[2]),
                           used: parseBiggestInt(f[3]), priority: parseInt(f[4]))
    except ValueError: discard

proc sdata(u: Unit): SwapData = SwapData(u.data)

proc generateSwapFstab*(text: string; roots: Roots): seq[GeneratedUnit] =
  ## fstab `swap` lines: `What=` the spec, `Priority=` from `pri=N`, `Options=` the rest.
  for raw in text.splitLines:
    let line = raw.strip
    if line.len == 0 or line[0] == '#': continue
    let f = line.splitWhitespace
    if f.len < 4 or f[2] != "swap": continue
    let spec = decodeOctal(f[0])
    var what = spec
    for (prefix, dir) in [("UUID=", "by-uuid"), ("LABEL=", "by-label"), ("PARTUUID=", "by-partuuid"),
                          ("PARTLABEL=", "by-partlabel")]:
      if spec.startsWith(prefix): what = "/dev/disk/" & dir & "/" & spec[prefix.len .. ^1]
    if not what.startsWith("/"): continue
    let name = swapUnitName(what)
    let def = newUnitDef(ukSwap, name)
    def.common.source = usFstab
    def.common.fragmentPath = roots.fstab
    def.common.sourcePath = roots.fstab
    def.common.description = what
    def.swap.what = what
    var kept: seq[string]
    var noauto, nofail = false
    for o in f[3].split(','):
      if o == "noauto": noauto = true
      elif o == "nofail": nofail = true
      elif o.startsWith("pri="):
        try: def.swap.priority = some(parseInt(o[4 .. ^1]))
        except ValueError: discard
      elif o.startsWith("x-systemd.") or o in ["defaults", "auto", ""]: discard
      else: kept.add o
    def.swap.options = kept.join(",")
    var g = GeneratedUnit(name: name, def: def)
    if not noauto: g.extraDeps.add ((if nofail: dkWants else: dkRequires), "swap.target", name)
    result.add g

proc setSwp(m: Manager; u: Unit; sub: string; result = "") =
  let a = case sub
    of "dead": asInactive
    of "active": asActive
    of "failed": asFailed
    of "deactivating", "deactivating-sigterm", "deactivating-sigkill": asDeactivating
    else: asActivating
  sdata(u).state = sub
  m.setState(u, a, sub, result)

proc readSwaps(m: Manager): seq[SwapEntry] =
  try: parseProcSwaps(readFile(m.roots.swaps)) except IOError: @[]

proc attach*(m: Manager; u: Unit)

proc newMirror(m: Manager; e: SwapEntry): Unit =
  let def = newUnitDef(ukSwap, swapUnitName(e.path))
  def.common.source = usMountinfo
  def.common.fragmentPath = m.roots.swaps
  def.common.description = e.path
  def.common.defaultDependencies = false
  def.swap.what = e.path
  result = newUnit(m, def)
  result.perpetual = true
  m.register(result)

proc syncSwaps*(m: Manager) =
  ## Kernel truth wins over control-process state.
  let entries = m.readSwaps()
  var present = initHashSet[string]()
  for e in entries:
    let name = swapUnitName(e.path)
    present.incl name
    var u = m.units.getOrDefault(name)
    if u == nil:
      let l = m.lookup(name)
      u = if l != nil and l.kind == ukSwap: l else: newMirror(m, e)
    if not (u.data of SwapData): continue
    sdata(u).kernel = some(e)
    if sdata(u).state notin ["active", "activating", "activating-done", "deactivating"]:
      m.setSwp(u, "active", "success")
  for id, u in m.units:
    if u.kind != ukSwap or not (u.data of SwapData): continue
    if id in present: continue
    sdata(u).kernel = none(SwapEntry)
    if sdata(u).state == "active": m.setSwp(u, "dead", "success")

proc watchSwaps*(m: Manager) =
  ## Re-read on every kernel change (EPOLLPRI on `/proc/swaps`); a poll tick elsewhere.
  m.syncSwaps()
  when defined(linux):
    let fd = open(m.roots.swaps.cstring, O_RDONLY or O_CLOEXEC)
    if fd >= 0:
      discard m.loop.addFd(fd, EvPri or EvErr, proc(ev: uint32) =
        var buf = newString(1)
        discard lseek(fd, 0, SEEK_SET)
        discard read(fd, addr buf[0], 1)
        m.syncSwaps())
      return
  proc tick() =
    m.syncSwaps()
    discard m.loop.addTimerIn(2_000_000, tick)
  discard m.loop.addTimerIn(2_000_000, tick)

proc findProgram(name: string): string =
  for d in ["/usr/sbin", "/sbin", "/usr/bin", "/bin"]:
    if fileExists(d / name): return d / name
  name

proc runHelper(m: Manager; u: Unit; args: seq[string]; program: string; done: proc(ok: bool; res: string)) =
  let d = sdata(u)
  let cmd = ExecCommand(path: findProgram(program), args: args, raw: program & " " & args.join(" "))
  m.loop.cancelTimer(d.timer)
  let timeout = u.def.swap.timeoutSec
  var helperPid = 0
  try:
    let opts = RunOptions(kind: ekStart, facts: RunFacts(unit: u.id, kind: ekStart))
    let h = runCommand(m, u, cmd, u.def.swap.exec, opts, proc(ok: bool) = discard,
      proc(st: ChildStatus) =
        m.pids.del helperPid
        if d.pid == helperPid:
          m.loop.cancelTimer(d.timer)
          d.pid = 0
        let ok = st.kind == cekExited and st.code == 0
        done(ok, if ok: "success" elif st.kind == cekExited: "exit-code" else: "signal"))
    helperPid = int(h.pid)
    d.pid = helperPid
    m.pids[d.pid] = u.id
    if timeout != Infinity and timeout > 0:
      d.timer = m.loop.addTimerIn(timeout, proc() =
        if d.pid > 0: discard kill(Pid(d.pid), SIGKILL))
  except CatchableError as e:
    logErr(u.id, "cannot run " & program & ": " & e.msg)
    done(false, "resources")

proc swapOptionArgs*(options: string): seq[string] =
  ## `swapon` flags for the `Options=` words that mean something to it.
  for o in options.split(','):
    let w = o.strip
    if w == "discard": result.add "--discard"
    elif w.startsWith("discard="): result.add "--discard=" & w["discard=".len .. ^1]

proc swapStart(m: Manager; u: Unit): StartOutcome =
  let d = sdata(u)
  m.syncSwaps()
  if d.state == "active": return StartOutcome(kind: skAlreadyActive)
  if d.state in ["activating", "activating-done", "deactivating"]: return StartOutcome(kind: skStarted)
  let c = u.def.swap
  if c.what.len == 0 or not c.what.startsWith("/"):
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "Unit " & u.id & " has no valid What=.")
  if swapUnitName(c.what) != u.id:
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "What= setting doesn't match unit name. Refusing.")
  u.result = "success"
  d.stopRequested = false
  m.setSwp(u, "activating")
  var args: seq[string]
  if c.priority.isSome: args.add @["-p", $c.priority.get]
  args.add swapOptionArgs(c.options)
  args.add c.what
  m.runHelper(u, args, "swapon", proc(ok: bool; res: string) =
    m.syncSwaps()
    if sdata(u).state notin ["activating", "activating-done"]: return
    if ok and sdata(u).kernel.isSome: m.setSwp(u, "active", "success")
    elif ok: m.setSwp(u, "failed", "timeout")
    else: m.setSwp(u, "failed", res))
  StartOutcome(kind: skStarted)

proc swapStop(m: Manager; u: Unit) =
  let d = sdata(u)
  if d.state in ["dead", "failed"]:
    m.setSwp(u, "dead", "success")
    return
  if d.state == "deactivating": return
  d.stopRequested = true
  if d.pid > 0: discard kill(Pid(d.pid), SIGTERM)
  m.setSwp(u, "deactivating")
  m.runHelper(u, @[u.def.swap.what], "swapoff", proc(ok: bool; res: string) =
    m.syncSwaps()
    if sdata(u).state != "deactivating": return
    if sdata(u).kernel.isNone or ok: m.setSwp(u, "dead", "success")
    else: m.setSwp(u, "failed", res))

proc swapStatus(m: Manager; u: Unit): StatusExtras =
  result.exitCode = -1
  let d = sdata(u)
  result.controlPid = d.pid
  if d.kernel.isSome: result.extra.add ("priority", $d.kernel.get.priority)
  elif u.def.swap.priority.isSome: result.extra.add ("priority", $u.def.swap.priority.get)

proc attach*(m: Manager; u: Unit) =
  u.data = SwapData(state: "dead")
  u.sub = "dead"
  u.ops = UnitOps(start: swapStart, stop: swapStop, status: swapStatus,
    isBusy: proc(u: Unit): bool = sdata(u).pid > 0,
    resetFailed: proc(m: Manager; u: Unit) =
      if u.active == asFailed: m.setSwp(u, "dead", "success"),
    fail: proc(m: Manager; u: Unit; r: string) = m.setSwp(u, "failed", r))

proc installSwapSupport*() =
  swapAttach = attach
  let previous = generatorHook
  generatorHook = proc(m: Manager): seq[GeneratedUnit] =
    if previous != nil: result = previous(m)
    if m.roots.scope == scSystem and fileExists(m.roots.fstab): result.add generateSwapFstab(readFile(m.roots.fstab), m.roots)
