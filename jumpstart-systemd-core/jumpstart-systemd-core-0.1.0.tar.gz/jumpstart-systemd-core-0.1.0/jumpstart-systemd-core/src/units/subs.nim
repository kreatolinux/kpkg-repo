## State subscriptions match unit names as `fnmatch` patterns: a name with a
## backslash (`tmp-a\x2db.mount`) has to be quoted to match itself.
proc globQuote*(name: string): string =
  for c in name:
    if c in {'\\', '*', '?', '['}: result.add '\\'
    result.add c
