## Mount units (spec §11.4): `mount`/`umount` as control processes, state read
## from `/proc/self/mountinfo`, mirror units for every kernel mount, and the
## fstab generator. Swap lines of fstab belong to units/swap.nim; an entry with
## `x-systemd.automount` also yields the `.automount` unit (units/automount.nim).
import std/[os, posix, options, strutils, tables, sets]
import jumpstartcore/reaper
import ../common/[logging, names, roots]
import ../unitfile/[model, index, loader, values]
import ../engine/[types, graph, unitstate, eventloop, manager]
import ../service/[execrun, execcontext]

type
  MountEntry* = object
    mountPoint*, fstype*, source*, options*: string
  MountData* = ref object of RootObj
    state: string
    pid: int
    timer: TimerId
    stopRequested: bool
    kernel: Option[MountEntry]

proc decodeOctal*(s: string): string =
  ## `\040` and friends in mountinfo and fstab fields.
  var i = 0
  while i < s.len:
    if s[i] == '\\' and i + 3 < s.len and s[i + 1] in {'0'..'3'} and s[i + 2] in {'0'..'7'} and
        s[i + 3] in {'0'..'7'}:
      result.add char(((ord(s[i + 1]) - 48) shl 6) or ((ord(s[i + 2]) - 48) shl 3) or (ord(s[i + 3]) - 48))
      i += 4
    else:
      result.add s[i]
      inc i

proc parseMountinfo*(text: string): seq[MountEntry] =
  ## One entry per line; optional fields end at the `-` separator.
  for line in text.splitLines:
    let f = line.splitWhitespace
    var dash = -1
    for i in 6 ..< f.len:
      if f[i] == "-":
        dash = i
        break
    if f.len < 10 or dash < 0 or f.len < dash + 3: continue
    result.add MountEntry(mountPoint: decodeOctal(f[4]), options: f[5], fstype: f[dash + 1],
                          source: decodeOctal(f[dash + 2]))

proc mdata(u: Unit): MountData = MountData(u.data)

proc mountUnitName*(where: string): string = escapePath(where) & ".mount"

# ---- fstab ---------------------------------------------------------------------
proc fstabSpec(spec: string): string =
  for (prefix, dir) in [("UUID=", "by-uuid"), ("LABEL=", "by-label"), ("PARTUUID=", "by-partuuid"),
                        ("PARTLABEL=", "by-partlabel")]:
    if spec.startsWith(prefix): return "/dev/disk/" & dir & "/" & spec[prefix.len .. ^1]
  spec

proc networkFs(typ, opts: string): bool =
  typ in ["nfs", "nfs4", "cifs", "smb3", "smbfs", "ncpfs", "9p", "ceph", "glusterfs", "fuse.sshfs", "afs"] or
    "_netdev" in opts.split(',')

proc generateFstab*(text: string; roots: Roots): seq[GeneratedUnit] =
  ## §11.4.4 for mount entries.
  for raw in text.splitLines:
    let line = raw.strip
    if line.len == 0 or line[0] == '#': continue
    let f = line.splitWhitespace
    if f.len < 4:
      logWarn("", "ignoring short fstab line: " & line)
      continue
    let (spec, file, typ, opts) = (fstabSpec(decodeOctal(f[0])), decodeOctal(f[1]), f[2], f[3])
    if typ == "swap" or typ == "none" and file == "none": continue
    if file == "/" or not file.startsWith("/"): continue
    let name = mountUnitName(file)
    let def = newUnitDef(ukMount, name)
    def.common.source = usFstab
    def.common.fragmentPath = roots.fstab
    def.common.sourcePath = roots.fstab
    def.common.description = file
    def.mount.what = spec
    def.mount.where = file
    def.mount.typ = typ
    var kept: seq[string]
    var noauto, nofail, automount = false
    var idle = 0'i64
    for o in opts.split(','):
      if o == "noauto": noauto = true
      elif o == "nofail": nofail = true
      elif o == "x-systemd.automount": automount = true
      elif o.startsWith("x-systemd.idle-timeout="):
        let t = parseTimespan(o["x-systemd.idle-timeout=".len .. ^1])
        if t.isSome: idle = t.get
      elif o.startsWith("x-systemd.") or o in ["auto", "defaults", ""]: discard
      else: kept.add o
      if o == "defaults": kept.add o
    def.mount.options = kept.join(",")
    var g = GeneratedUnit(name: name, def: def)
    let target = if networkFs(typ, opts): "remote-fs.target" else: "local-fs.target"
    if automount:
      # the automount unit is wanted at boot; the mount itself only when something looks it up
      let aname = escapePath(file) & ".automount"
      let adef = newUnitDef(ukAutomount, aname)
      adef.common.source = usFstab
      adef.common.fragmentPath = roots.fstab
      adef.common.sourcePath = roots.fstab
      adef.common.description = file
      adef.mount.where = file
      adef.mount.timeoutIdleSec = idle
      var a = GeneratedUnit(name: aname, def: adef)
      a.extraDeps.add ((if nofail: dkWants else: dkRequires), target, aname)
      a.extraDeps.add (dkBefore, aname, target)
      result.add a
    elif not noauto:
      g.extraDeps.add ((if nofail: dkWants else: dkRequires), target, name)
    result.add g

# ---- state ---------------------------------------------------------------------
proc setMnt(m: Manager; u: Unit; sub: string; result = "") =
  let a = case sub
    of "dead": asInactive
    of "mounted", "remounting": asActive
    of "failed": asFailed
    of "unmounting": asDeactivating
    else: asActivating
  mdata(u).state = sub
  m.setState(u, a, sub, result)

proc readMountinfo(m: Manager): seq[MountEntry] =
  try: parseMountinfo(readFile(m.roots.mountinfo)) except IOError: @[]

proc newMirror(m: Manager; e: MountEntry): Unit =
  let def = newUnitDef(ukMount, mountUnitName(e.mountPoint))
  def.common.source = usMountinfo
  def.common.fragmentPath = m.roots.mountinfo
  def.common.description = e.mountPoint
  def.common.defaultDependencies = false
  def.mount.what = e.source
  def.mount.where = e.mountPoint
  def.mount.typ = e.fstype
  def.mount.options = e.options
  result = newUnit(m, def)
  result.perpetual = true
  m.register(result)

proc attach*(m: Manager; u: Unit)

proc syncMounts*(m: Manager) =
  ## §11.4.3: kernel truth wins over control-process state.
  let entries = m.readMountinfo()
  var present = initHashSet[string]()
  for e in entries:
    if e.fstype == "autofs": continue     # an automount's trigger is not the mount it triggers
    let name = mountUnitName(e.mountPoint)
    present.incl name
    var u = m.units.getOrDefault(name)
    if u == nil:
      let l = m.lookup(name)           # a unit file or fstab entry for it?
      u = if l != nil and l.kind == ukMount: l else: newMirror(m, e)
    if not (u.data of MountData): continue
    mdata(u).kernel = some(e)
    if u.def.mount.typ.len == 0 or u.def.mount.typ == "auto": u.def.mount.typ = e.fstype
    if u.def.common.source in {usMountinfo}: u.perpetual = true
    # A mount in progress completes when its control process exits (the helper
    # callback), not when the kernel entry first appears: otherwise a stop can
    # start while the finished helper is still waiting to be reaped.
    if mdata(u).state notin ["mounted", "remounting", "unmounting", "mounting"]:
      m.setMnt(u, "mounted", "success")
  for id, u in m.units:
    if u.kind != ukMount or not (u.data of MountData): continue
    if id in present: continue
    mdata(u).kernel = none(MountEntry)
    if mdata(u).state == "mounted": m.setMnt(u, "dead", "success")

proc watchMountinfo*(m: Manager) =
  ## Re-read on every kernel change (EPOLLPRI on Linux); a poll tick elsewhere.
  m.syncMounts()
  when defined(linux):
    let fd = open(m.roots.mountinfo.cstring, O_RDONLY or O_CLOEXEC)
    if fd >= 0:
      discard m.loop.addFd(fd, EvPri or EvErr, proc(ev: uint32) =
        var buf = newString(1)
        discard lseek(fd, 0, SEEK_SET)
        discard read(fd, addr buf[0], 1)
        m.syncMounts())
      return
  proc tick() =
    m.syncMounts()
    discard m.loop.addTimerIn(2_000_000, tick)
  discard m.loop.addTimerIn(2_000_000, tick)

# ---- start/stop -----------------------------------------------------------------
proc findProgram(name: string): string =
  for d in ["/usr/bin", "/bin", "/usr/sbin", "/sbin"]:
    if fileExists(d / name): return d / name
  name

proc cExit(code: cint) {.importc: "_exit", header: "<unistd.h>".}

var ozMounts*: HashSet[string]
  ## `Where=` of every active automount unit. The autofs mount lets only the
  ## manager's process group look through the trigger, so the helpers of a mount
  ## below an automount are spawned in that group (units/automount.nim).

proc spawnInManagerGroup(m: Manager; u: Unit; path: string; args: seq[string];
                         onExit: proc(st: ChildStatus) {.closure.}): int =
  ## fork + exec without the executor: the child keeps the manager's process group.
  let argv = allocCStringArray(@[path] & args)
  defer: deallocCStringArray(argv)
  let pid = fork()
  if pid < 0: return -1
  if pid == 0:
    let nul = open("/dev/null", O_RDWR)
    if nul >= 0:
      discard dup2(nul, 0); discard dup2(nul, 1); discard dup2(nul, 2)
    var empty, old: Sigset
    discard sigemptyset(empty)
    discard sigprocmask(SIG_SETMASK, empty, old)
    discard execv(path.cstring, argv)
    discard execvp(path.cstring, argv)
    cExit(127)
  m.reaper.register(pid, u.id, onExit)
  int(pid)

proc runHelper(m: Manager; u: Unit; args: seq[string]; program: string; done: proc(ok: bool; res: string)) =
  let d = mdata(u)
  let cmd = ExecCommand(path: findProgram(program), args: args, raw: program & " " & args.join(" "))
  m.loop.cancelTimer(d.timer)
  let timeout = u.def.mount.timeoutSec
  var helperPid = 0
  let onExit = proc(st: ChildStatus) =
    # A newer helper (a stop issued while this one was still being reaped)
    # owns the unit's pid and timer by now; leave them alone.
    m.pids.del helperPid
    if d.pid == helperPid:
      m.loop.cancelTimer(d.timer)
      d.pid = 0
    let ok = st.kind == cekExited and st.code == 0
    done(ok, if ok: "success" elif st.kind == cekExited: "exit-code" else: "signal")
  try:
    if u.def.mount.where in ozMounts:
      helperPid = m.spawnInManagerGroup(u, cmd.path, args, onExit)
      if helperPid < 0: raise newException(OSError, "fork failed")
    else:
      let opts = RunOptions(kind: ekStart, facts: RunFacts(unit: u.id, kind: ekStart))
      let h = runCommand(m, u, cmd, u.def.mount.exec, opts, proc(ok: bool) = discard, onExit)
      helperPid = int(h.pid)
    d.pid = helperPid
    m.pids[d.pid] = u.id
    if timeout != Infinity and timeout > 0:
      d.timer = m.loop.addTimerIn(timeout, proc() =
        if d.pid > 0: discard kill(Pid(d.pid), SIGKILL))
  except CatchableError as e:
    logErr(u.id, "cannot run " & program & ": " & e.msg)
    done(false, "resources")

proc mountStart(m: Manager; u: Unit): StartOutcome =
  let d = mdata(u)
  m.syncMounts()
  if d.state == "mounted": return StartOutcome(kind: skAlreadyActive)
  if d.state in ["mounting", "unmounting"]: return StartOutcome(kind: skStarted)
  let c = u.def.mount
  if c.where.len == 0 or not c.where.startsWith("/"):
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE", text: "Unit " & u.id & " has no valid Where=.")
  if mountUnitName(c.where) != u.id:
    return StartOutcome(kind: skRefused, code: "E_UNIT_STATE",
      text: "Where= setting doesn't match unit name. Refusing.")
  u.result = "success"
  d.stopRequested = false
  m.setMnt(u, "mounting")
  try: createDir(c.where)
  except OSError: discard
  var args = @[c.what, c.where]
  if c.typ.len > 0 and c.typ != "auto": args.add @["-t", c.typ]
  if c.options.len > 0: args.add @["-o", c.options]
  if c.sloppyOptions: args.add "-s"
  m.runHelper(u, args, "mount", proc(ok: bool; res: string) =
    m.syncMounts()
    if mdata(u).state != "mounting": return   # stopped meanwhile: the stop owns the state
    if ok and mdata(u).kernel.isSome: m.setMnt(u, "mounted", "success")
    elif ok:
      m.setMnt(u, "failed", "timeout")
    else: m.setMnt(u, "failed", res))
  StartOutcome(kind: skStarted)

proc mountStop(m: Manager; u: Unit) =
  let d = mdata(u)
  if d.state in ["dead", "failed"]:
    m.setMnt(u, "dead", "success")
    return
  if d.state == "unmounting": return
  d.stopRequested = true
  if d.pid > 0: discard kill(Pid(d.pid), SIGTERM)
  m.setMnt(u, "unmounting")
  var args: seq[string]
  if u.def.mount.lazyUnmount: args.add "-l"
  if u.def.mount.forceUnmount: args.add "-f"
  args.add u.def.mount.where
  m.runHelper(u, args, "umount", proc(ok: bool; res: string) =
    m.syncMounts()
    if mdata(u).state != "unmounting": return
    if mdata(u).kernel.isNone: m.setMnt(u, "dead", "success")
    elif ok: m.setMnt(u, "dead", "success")
    else: m.setMnt(u, "failed", res))

proc mountReload(m: Manager; u: Unit): bool =
  let d = mdata(u)
  if d.state != "mounted": return false
  m.setMnt(u, "remounting")
  let opts = "remount" & (if u.def.mount.options.len > 0: "," & u.def.mount.options else: "")
  m.runHelper(u, @["-o", opts, u.def.mount.where], "mount", proc(ok: bool; res: string) =
    m.syncMounts()
    u.reloadResult = if ok: "success" else: res
    m.setMnt(u, "mounted", "success"))
  true

proc mountStatus(m: Manager; u: Unit): StatusExtras =
  result.exitCode = -1
  let d = mdata(u)
  result.controlPid = d.pid

proc attach*(m: Manager; u: Unit) =
  u.data = MountData(state: "dead")
  u.sub = "dead"
  u.ops = UnitOps(start: mountStart, stop: mountStop, reload: mountReload,
    canReload: proc(u: Unit): bool = true, status: mountStatus,
    isBusy: proc(u: Unit): bool = mdata(u).pid > 0,
    resetFailed: proc(m: Manager; u: Unit) =
      if u.active == asFailed: m.setMnt(u, "dead", "success"),
    fail: proc(m: Manager; u: Unit; r: string) = m.setMnt(u, "failed", r))

proc installMountSupport*() =
  mountAttach = attach
  generatorHook = proc(m: Manager): seq[GeneratedUnit] =
    if m.roots.scope == scSystem and fileExists(m.roots.fstab): generateFstab(readFile(m.roots.fstab), m.roots)
    else: @[]
