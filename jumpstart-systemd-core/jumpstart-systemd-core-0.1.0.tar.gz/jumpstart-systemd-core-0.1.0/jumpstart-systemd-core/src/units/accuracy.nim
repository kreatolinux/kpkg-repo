## `AccuracySec=` wake-up coalescing, the algorithm of sd-event's
## `sleep_between`: the timer may fire anywhere in `[at, at + accuracy]`, and the
## latest instant in that window on a 1 min / 10 s / 1 s / 250 ms grid (offset by a
## per-machine perturbation) is picked, so the timers of one machine wake together.
import std/strutils
import ../common/clock

const
  Minute = 60 * UsecPerSec
  Grids = [Minute, 10 * UsecPerSec, UsecPerSec, 250_000'i64]

proc perturbOf*(machineId: string): int64 =
  ## sd-event: the two halves of the machine id xored, modulo one minute.
  let h = machineId.strip.toLowerAscii
  if h.len != 32: return 0
  try:
    let a = parseHexInt(h[0 ..< 8]).int64 shl 32 or parseHexInt(h[8 ..< 16]).int64
    let b = parseHexInt(h[16 ..< 24]).int64 shl 32 or parseHexInt(h[24 ..< 32]).int64
    result = int64((cast[uint64](a) xor cast[uint64](b)) mod uint64(Minute))
  except ValueError: discard

proc sleepBetween*(a, b, perturb: int64): int64 =
  ## The instant in `[a, b]` to wake up at; `a` when the window is empty.
  if b <= a + 1: return a
  for g in Grids:
    var c = (b div g) * g + (perturb mod g)
    if c >= b:
      if c < g: return b
      c -= g
    if c >= a: return c
  b

proc coalesce*(at, accuracy, perturb: int64): int64 =
  if accuracy <= 1: at else: sleepBetween(at, at + accuracy, perturb)
