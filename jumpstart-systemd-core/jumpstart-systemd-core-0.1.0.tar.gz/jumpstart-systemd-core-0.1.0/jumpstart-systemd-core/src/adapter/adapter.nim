## The persistent adapter (spec §3.3, §13): answers the exec protocol on
## descriptors 3 and 4 and talks to the manager over `RT/manager.sock`.
## Stateless and single-threaded: one `poll` loop over descriptor 3, one
## dedicated manager connection per in-flight request, and a forked reader per
## `log.follow`. Requests never block each other.
import std/json except getStr, getInt, getBool
import std/[options, os, strutils, times, sequtils]
import std/posix except Time, Clock
import jumpstartcore/[protocol, registry, errors, jsonlines]
import ../common/[roots, fdutil, jsonio, results]
import ../journal/logops
import ../ipc/sdcproto

const ExpectedBinaries = ["systemd-compat-manager", "systemd-compat", "systemd-compat-exec",
                          "systemd-compat-journald", "systemd-compat-tools"]

type
  Req = ref object
    id, op, unit: string
    args: JsonNode
    deadline, soft: Time
    fd: cint
    buf: string
    sentAt: Time
    retryAt: Time
    backoffMs: int
    pendingVerb: tuple[verb: string, args: JsonNode]
    onResult: proc(r: SdcResponse)
    onItem: proc(r: SdcResponse)
    followPid: Pid
    followFd: cint
    followBuf: string
    done: bool
  Adapter* = ref object
    roots: Roots
    reqs: seq[Req]
    reader: LineReader
    eof: bool
    sock: string

proc strVal(n: JsonNode): string = (if n != nil and n.kind == JString: n.str else: "")
proc intVal(n: JsonNode): int = (if n != nil and n.kind == JInt: int(n.num) else: 0)

proc nowTime(): Time = getTime()

proc routedOperations*(): seq[string] =
  ## Every registry operation except `unit.translate` (§5.3).
  for spec in registry(CurrentManifestVersion):
    if spec.name != "unit.translate": result.add spec.name

proc send(a: Adapter; msg: ProtocolMessage) =
  try: writeAllFd(4, encodeLine(msg))
  except CatchableError: a.eof = true

proc closeReq(a: Adapter; r: Req) =
  r.done = true
  if r.fd >= 0:
    discard close(r.fd)
    r.fd = -1
  if r.followFd >= 0:
    discard close(r.followFd)
    r.followFd = -1
  if r.followPid > 0:
    discard kill(r.followPid, SIGKILL)
    var st: cint
    discard waitpid(r.followPid, st, 0)
    r.followPid = 0
  a.reqs.keepItIf(it != r)

proc fail(a: Adapter; r: Req; code: CoreErrorCode; msg: string) =
  if r.done: return
  a.send errorResponse(r.id, errorName(code), if msg.len == 0: errorName(code) else: msg)
  a.closeReq(r)

proc succeed(a: Adapter; r: Req; value: JsonNode) =
  if r.done: return
  try:
    validateResult(r.op, value)
  except ProtocolError as e:
    stderr.writeLine "adapter: " & r.op & ": " & e.msg
    a.send errorResponse(r.id, "E_PROTOCOL", e.msg)
    a.closeReq(r)
    return
  a.send okResponse(r.id, value)
  a.closeReq(r)

proc call(a: Adapter; r: Req; verb: string; args: JsonNode; onResult: proc(x: SdcResponse);
          onItem: proc(x: SdcResponse) = nil) =
  ## Queues one `sdc` request on the request's own manager connection.
  r.pendingVerb = (verb, args)
  r.onResult = onResult
  r.onItem = onItem
  r.backoffMs = 100
  r.retryAt = fromUnix(0)
  if r.fd >= 0:
    discard close(r.fd)
    r.fd = -1

proc failFromSdc(a: Adapter; r: Req; x: SdcResponse) =
  a.fail(r, x.code, x.message)

proc pickFields(op: string; node: JsonNode): JsonNode =
  ## Only the registry fields of `op`'s result.
  result = newJObject()
  let spec = findOperation(CurrentManifestVersion, op)
  if spec.isNone: return
  for f in spec.get.results:
    if node.hasKey(f.name): result[f.name] = node[f.name]

proc rfc3339Soft(r: Req): string = formatDeadline(r.soft)

proc argStr(r: Req; k: string): string = r.args.getStr(k, "")

# ---- operation translation -----------------------------------------------------
proc coreVerify(a: Adapter; r: Req) =
  let root = a.roots.coreRoot
  var ok = dirExists(root / "share/units")
  for b in ExpectedBinaries:
    let p = root / "bin" / b
    var st: Stat
    if stat(p.cstring, st) != 0 or not S_ISREG(st.st_mode) or (int(st.st_mode) and 0o100) == 0 or
        st.st_uid != 0 and a.roots.scope == scSystem:
      ok = false
  a.succeed(r, %*{"installed": ok, "version": "255"})

proc stateOf(x: JsonNode): string = x{"state"}.strVal

proc jobOp(a: Adapter; r: Req; typ: string; mode = "replace") =
  a.call(r, "job-submit", %*{"unit": r.unit, "type": typ, "mode": mode, "wait": true,
                             "deadline": rfc3339Soft(r)}, proc(x: SdcResponse) =
    if x.ok: a.succeed(r, %*{"state": x.result.stateOf})
    else: a.failFromSdc(r, x))

proc fileOpOp(a: Adapter; r: Req; op: string) =
  var args = %*{"op": op, "names": [r.unit], "now": r.args.getBool("now", false)}
  if r.args.has("target"):
    args["target"] = r.args["target"]
    args["op"] = %(if op == "enable": "add-wants" else: "disable")
  a.call(r, "unit-file-op", args, proc(x: SdcResponse) =
    if x.ok: a.succeed(r, newJObject()) else: a.failFromSdc(r, x))

proc statusOp(a: Adapter; r: Req) =
  a.call(r, "unit-status", %*{"name": r.unit, "journal_lines": 0}, proc(x: SdcResponse) =
    if x.ok: a.succeed(r, pickFields(r.op, x.result)) else: a.failFromSdc(r, x))

proc startFollow(a: Adapter; r: Req) =
  ## A forked child tails the journal and writes JSON lines to a pipe.
  var fds: array[2, cint]
  if pipe(fds) != 0:
    a.fail(r, ecBackend, "cannot create pipe")
    return
  let since = if r.args.has("since"):
      (try: some(parseDeadline(r.args["since"].strVal).toUnix * 1_000_000) except CatchableError: none(int64))
    else: none(int64)
  let roots = a.roots
  let unit = r.unit
  let pid = fork()
  if pid == 0:
    discard close(fds[0])
    followEntries(roots, unit, since, proc(e: LogEntry): bool =
      let line = $(%*{"time": e.time, "level": e.level, "unit": e.unit, "message": e.message}) & "\n"
      writeAll(fds[1], line))
    quit(0)
  discard close(fds[1])
  r.followPid = pid
  r.followFd = fds[0]

proc logRead(a: Adapter; r: Req) =
  proc parseTime(k: string): Option[int64] =
    if r.args.has(k):
      try: return some(parseDeadline(r.args[k].strVal).toUnix * 1_000_000 +
                       (parseDeadline(r.args[k].strVal).nanosecond div 1000))
      except CatchableError: discard
    none(int64)
  let entries = readEntries(a.roots, r.unit, parseTime("since"), parseTime("until"),
                            r.args.getInt("lines", 1000))
  # Entries that went out as `item` events must not also be in the result:
  # the daemon appends items to the result's list. Keep only the entries
  # that could not be sent as items.
  var arr = newJArray()
  for e in entries:
    let item = %*{"time": e.time, "level": e.level, "unit": e.unit, "message": e.message}
    try:
      validateObjectItem("log.read", "entries", item)
      a.send itemEvent(r.id, "entries", item)
    except CatchableError:
      arr.add item
  a.succeed(r, %*{"entries": arr})

proc logOp(a: Adapter; r: Req) =
  case r.op
  of "log.read": a.logRead(r)
  of "log.follow": a.startFollow(r)
  of "log.write":
    let res = writeEntry(a.roots, r.unit, r.argStr("level"), r.argStr("message"))
    if res.ok: a.succeed(r, newJObject())
    else: a.fail(r, ecBackend, res.error)
  of "log.rotate":
    let res = journaldControl(a.roots, %*{"op": "rotate"})
    if res.ok: a.succeed(r, newJObject()) else: a.fail(r, ecBackend, res.error)
  else:
    var req = %*{"op": "vacuum"}
    if r.args.has("max_size"): req["max_size"] = r.args["max_size"]
    if r.args.has("max_age"): req["max_age"] = r.args["max_age"]
    let res = journaldControl(a.roots, req)
    if res.ok: a.succeed(r, %*{"freed": res.value{"freed"}.intVal})
    else: a.fail(r, ecBackend, res.error)

proc translate(a: Adapter; r: Req) =
  let op = r.op
  let sub = op.split('.')[0]
  case op
  of "core.verify": a.coreVerify(r)
  of "unit.list":
    # Units go out as `item` events; the daemon appends items to the result's
    # own list, so the result keeps only the units that could
    # not be sent as items (as log.read does) -- otherwise each unit is
    # reported twice.
    var unsent = newJArray()
    a.call(r, "unit-index", newJObject(), proc(x: SdcResponse) =
      if x.ok: a.succeed(r, %*{"units": unsent}) else: a.failFromSdc(r, x),
      proc(x: SdcResponse) =
        try:
          validateObjectItem("unit.list", "units", x.data)
          a.send itemEvent(r.id, "units", x.data)
        except CatchableError:
          unsent.add x.data)
  of "unit.resolve":
    let name = r.args.getStr("name", r.unit)
    a.call(r, "unit-resolve", %*{"name": name}, proc(x: SdcResponse) =
      if x.ok: a.succeed(r, pickFields(op, x.result)) else: a.failFromSdc(r, x))
  of "unit.load":
    a.call(r, "daemon-reload", newJObject(), proc(x: SdcResponse) =
      if x.ok: a.succeed(r, pickFields(op, x.result)) else: a.failFromSdc(r, x))
  of "unit.validate":
    a.call(r, "unit-validate", %*{"name": r.unit}, proc(x: SdcResponse) =
      if x.ok: a.succeed(r, pickFields(op, x.result)) else: a.failFromSdc(r, x))
  of "unit.activate":
    a.call(r, "activate", newJObject(), proc(x: SdcResponse) =
      if x.ok: a.succeed(r, pickFields(op, x.result)) else: a.failFromSdc(r, x))
  of "unit.deactivate":
    a.call(r, "deactivate", newJObject(), proc(x: SdcResponse) =
      if x.ok: a.succeed(r, pickFields(op, x.result)) else: a.failFromSdc(r, x))
  of "target.get-default":
    a.call(r, "get-default", newJObject(), proc(x: SdcResponse) =
      if x.ok: a.succeed(r, pickFields(op, x.result)) else: a.failFromSdc(r, x))
  of "target.set-default":
    a.call(r, "unit-file-op", %*{"op": "set-default", "names": [r.unit]}, proc(x: SdcResponse) =
      if x.ok: a.succeed(r, newJObject()) else: a.failFromSdc(r, x))
  of "target.isolate": a.jobOp(r, "start", "isolate")
  of "service.kill":
    a.call(r, "kill", %*{"unit": r.unit, "whom": "all", "signal": r.argStr("signal")}, proc(x: SdcResponse) =
      if x.ok: a.succeed(r, newJObject()) else: a.failFromSdc(r, x))
  of "log.read", "log.follow", "log.write", "log.rotate", "log.vacuum": a.logOp(r)
  else:
    let verb = op.split('.')[1]
    case verb
    of "start": a.jobOp(r, "start")
    of "stop": a.jobOp(r, "stop")
    of "restart": a.jobOp(r, "restart")
    of "reload": a.jobOp(r, "reload")
    of "enable": a.fileOpOp(r, "enable")
    of "disable": a.fileOpOp(r, "disable")
    of "status": a.statusOp(r)
    else: a.fail(r, ecUnsupported, "operation not implemented: " & op)
    discard sub

# ---- manager connection ----------------------------------------------------------
proc tryConnect(a: Adapter; r: Req) =
  let fd = connectUnix(a.sock, true)
  if fd < 0:
    r.retryAt = nowTime() + initDuration(milliseconds = r.backoffMs)
    r.backoffMs = min(r.backoffMs * 2, 2000)
    return
  setNonBlocking(fd)
  r.fd = fd
  r.buf = ""
  discard writeAll(fd, requestLine(%1, r.pendingVerb.verb, r.pendingVerb.args))

proc handleManagerLine(a: Adapter; r: Req; line: string) =
  let x = try: parseResponse(line) except CatchableError: (a.fail(r, ecProtocol, "bad manager response"); return)
  if x.isEvent:
    if r.onItem != nil and not r.done: r.onItem(x)
    return
  let cb = r.onResult
  r.onResult = nil
  if r.fd >= 0:
    discard close(r.fd)
    r.fd = -1
  r.pendingVerb = ("", nil)
  if cb != nil and not r.done: cb(x)

proc newRequest(a: Adapter; m: ProtocolMessage) =
  let dl = parseDeadline(m.deadline)
  let r = Req(id: m.id, op: m.op, unit: m.unit, args: m.args, deadline: dl,
              soft: dl - initDuration(milliseconds = a.roots.limits.softDeadlineMarginMs),
              fd: -1, followFd: -1)
  a.reqs.add r
  try: a.translate(r)
  except CoreError as e: a.fail(r, e.code, e.msg)
  except CatchableError as e: a.fail(r, ecBackend, e.msg)

proc step(a: Adapter) =
  ## One poll iteration.
  var pfds: seq[TPollfd]
  var owners: seq[Req]
  pfds.add TPollfd(fd: 3, events: POLLIN)
  owners.add nil
  var timeoutMs = 1000
  let now = nowTime()
  for r in a.reqs.toSeq:
    if r.done: continue
    if r.pendingVerb.verb.len > 0 and r.fd < 0:
      if r.retryAt <= now: a.tryConnect(r)
      let wait = int((r.retryAt - now).inMilliseconds)
      if r.fd < 0: timeoutMs = min(timeoutMs, max(wait, 1))
    if r.fd >= 0:
      pfds.add TPollfd(fd: r.fd, events: POLLIN)
      owners.add r
    if r.followFd >= 0:
      pfds.add TPollfd(fd: r.followFd, events: POLLIN)
      owners.add r
    timeoutMs = min(timeoutMs, max(1, int((r.deadline - now).inMilliseconds)))
  if poll(addr pfds[0], Tnfds(pfds.len), cint(timeoutMs)) > 0:
    for i, p in pfds:
      if p.revents == 0: continue
      let r = owners[i]
      if r == nil:
        var line: string
        discard a.reader.fill(0)
        while a.reader.nextLine(line):
          let msg = try: parseLine(line) except CatchableError: ProtocolMessage()
          case msg.kind
          of pmRequest: a.newRequest(msg)
          of pmCancel:
            # fail() removes the request from a.reqs: iterate over a copy
            for q in a.reqs.toSeq:
              if q.id == msg.id: a.fail(q, ecCancelled, "request cancelled")
          else: discard
        continue
      if r.done: continue
      let isFollow = r.followFd == p.fd
      var buf = newString(65536)
      let n = read(p.fd, addr buf[0], buf.len)
      if n <= 0:
        if isFollow: a.fail(r, ecBackend, "journal follower ended")
        elif r.fd == p.fd and r.pendingVerb.verb.len > 0:
          # the manager went away: retry within the deadline
          discard close(r.fd)
          r.fd = -1
          r.retryAt = nowTime() + initDuration(milliseconds = 100)
        continue
      if isFollow:
        r.followBuf.add buf[0 ..< n]
        while true:
          let nl = r.followBuf.find('\n')
          if nl < 0: break
          let line = r.followBuf[0 ..< nl]
          r.followBuf = r.followBuf[nl + 1 .. ^1]
          try: a.send entryEvent(r.id, parseJson(line))
          except CatchableError: discard
      else:
        r.buf.add buf[0 ..< n]
        while r.fd >= 0:
          let nl = r.buf.find('\n')
          if nl < 0: break
          let line = r.buf[0 ..< nl]
          r.buf = r.buf[nl + 1 .. ^1]
          a.handleManagerLine(r, line)
  let t = nowTime()
  for r in a.reqs.toSeq:
    if not r.done and r.deadline <= t: a.fail(r, ecTimeout, "request deadline reached")

proc runAdapter*(roots: Roots): int =
  ## The adapter's whole life: handshake, serve until EOF on descriptor 3.
  let a = Adapter(roots: roots, sock: roots.rt / "manager.sock", reader: newLineReader(3))
  try:
    let offer = parseLine(readLineFd(3))
    let ops = routedOperations()
    let reply = helloReply(crAdapter, ops)
    validateHandshake(offer, reply, ops)
    a.send reply
  except CatchableError as e:
    stderr.writeLine "adapter: handshake failed: " & e.msg
    return 1
  var eofSeen = false
  while not (eofSeen and a.reqs.len == 0):
    a.step()
    if a.eof: eofSeen = true
    if a.reader.eof: eofSeen = true
  0
