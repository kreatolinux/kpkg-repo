## `systemd-compat-tools`: the multi-call binary behind systemctl, journalctl,
## systemd-notify, systemd-escape, systemd-run, systemd-analyze,
## systemd-tmpfiles, systemd-sysusers, poweroff, reboot and halt (spec §15.1).
## Dispatches on the base name of argv[0], or on the first argument when
## invoked by its own name (for tests).
import std/[os, strutils]
import tools/[systemctl, misc, journalctl, sdrun, analyze, tmpfiles, sysusers]

proc cExit(code: cint) {.importc: "exit", header: "<stdlib.h>", noreturn.}

proc dispatch(name: string; args: seq[string]): int =
  case name
  of "systemctl": systemctlMain(args)
  of "journalctl": journalctlMain(args)
  of "systemd-notify": notifyMain(args)
  of "systemd-escape": escapeMain(args)
  of "systemd-run": runMain(args)
  of "systemd-analyze": analyzeMain(args)
  of "systemd-tmpfiles": tmpfilesMain(args)
  of "systemd-sysusers": sysusersMain(args)
  of "systemd-xdg-autostart-condition": xdgAutostartConditionMain(args)
  of "poweroff", "reboot", "halt": powerMain(name, args)
  else:
    stderr.writeLine "systemd-compat-tools: unknown program " & name
    127

var name = paramStr(0).extractFilename   # not getAppFilename: on Linux it resolves the symlinks the tools are installed as
var args = commandLineParams()
if name == "systemd-compat-tools" or name.startsWith("tools_main"):
  if args.len == 0:
    stderr.writeLine "usage: systemd-compat-tools PROGRAM [ARGS...]"
    cExit(2)
  name = args[0]
  args = args[1 .. ^1]
cExit(cint(dispatch(name, args)))
