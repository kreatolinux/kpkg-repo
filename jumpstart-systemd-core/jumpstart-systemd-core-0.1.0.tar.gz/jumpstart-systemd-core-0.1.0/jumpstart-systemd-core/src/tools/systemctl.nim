## `systemctl` (spec §15.2): the compatibility front-end over the manager's
## public socket, with offline file operations (`--root`).
import std/json except getStr, getInt, getBool
import std/[os, strutils, sequtils, times, options, terminal, algorithm]
import std/posix except Time, Clock
import jumpstartcore/errors
import ../common/[names, roots, jsonio]
import ../unitfile/[model, install, index, loader, trust]
import ../ipc/[client]
import ../journal/logops
import ./[frontcommon, sysedit]

type Opts = object
  user, system, noBlock, wait, now, force, runtime, global, noReload, reverse, after, before: bool
  all, failed, quiet, noLegend, plain, noPager, full, value, noWall, showAll: bool
  editFull, fromStdin: bool
  dropin: string
  root, jobMode, killWhom, signal, what, presetMode, host: string
  types, states, props: seq[string]
  lines: int
  output: string
  args: seq[string]

const NotSupported = "Verb not supported by the systemd core."

proc useColor(): bool =
  getEnv("NO_COLOR").len == 0 and isatty(stdout) and getEnv("TERM") notin ["", "dumb"] or
    getEnv("SYSTEMD_COLORS") in ["1", "true", "yes"]

proc utf8Locale(): bool =
  for v in ["LC_ALL", "LC_CTYPE", "LANG"]:
    let x = getEnv(v)
    if x.len > 0: return "UTF-8" in x.toUpperAscii or "UTF8" in x.toUpperAscii
  false

proc marker(active: string): string =
  let u = utf8Locale()
  case active
  of "active": (if u: "\xe2\x97\x8f" else: "*")
  of "failed": (if u: "\xc3\x97" else: "x")
  of "activating", "reloading", "deactivating": (if u: "\xe2\x86\xbb" else: "*")
  else: (if u: "\xe2\x97\x8b" else: "o")

proc sockPath(o: Opts): string = sockPathFor(o.user, o.system)

proc connectManager(o: Opts): SdcClient = connectOrDie(o.user, o.system)

proc fmtTime(usecs: int64): string =
  if usecs <= 0: return ""
  fromUnix(usecs div 1_000_000).local.format("ddd yyyy-MM-dd HH:mm:ss 'UTC'").replace("UTC", "UTC")

proc ago(since: string): string =
  ## "5min ago" style relative time from an RFC 3339 stamp.
  try:
    let t = parse(since[0 ..< 19], "yyyy-MM-dd'T'HH:mm:ss", utc()).toTime
    let d = (getTime() - t).inSeconds
    if d < 1: return "now"
    if d < 60: return $d & "s ago"
    if d < 3600: return $(d div 60) & "min ago"
    if d < 86400: return $(d div 3600) & "h ago"
    return $(d div 86400) & " days ago"
  except CatchableError: ""

proc fileOpFromArgs(verb: string): Option[FileOp] =
  case verb
  of "enable": some(foEnable)
  of "disable": some(foDisable)
  of "reenable": some(foReenable)
  of "mask": some(foMask)
  of "unmask": some(foUnmask)
  of "link": some(foLink)
  of "preset": some(foPreset)
  of "preset-all": some(foPresetAll)
  of "revert": some(foRevert)
  of "add-wants": some(foAddWants)
  of "add-requires": some(foAddRequires)
  of "set-default": some(foSetDefault)
  of "is-enabled": some(foIsEnabled)
  else: none(FileOp)

const InstalledCoreDir = "usr/lib/jumpstart/cores/systemd"

proc ownCoreRoot(): string =
  ## The core tree this binary belongs to (`<core>/bin/systemd-compat-tools`,
  ## reached through the /usr/bin links), so offline operations see the
  ## core's own units (getty@, graphical.target, systemd-tmpfiles-setup...).
  result = getEnv("JUMPSTART_CORE_ROOT")
  if result.len > 0: return
  let exe = getAppFilename()
  if exe.len == 0 or exe.parentDir.extractFilename != "bin": return ""
  let core = exe.parentDir.parentDir
  result = if dirExists(core / "share/units"): core else: ""

proc offlineRoots(o: Opts): Roots =
  var r = systemRoots()
  r.coreRoot = ownCoreRoot()
  if o.root.len > 0:
    var b = o.root.strip(chars = {'/'}, leading = false)
    if b.len == 0: b = "/"             # --root=/ is the running system, not "" (relative paths)
    r.etc = b / "etc"; r.run = b / "run"; r.varLib = b / "var/lib"; r.usrLib = b / "usr/lib"
    r.usrShare = b / "usr/share"; r.sysrun = b / "run/systemd"; r.varCache = b / "var/cache"
    r.varLog = b / "var/log"
    if b != "/": r.coreRoot = b / InstalledCoreDir
  if o.user:
    r.scope = scUser
  r

proc printChanges(r: FileOpResult; quiet: bool) =
  if quiet: return
  for c in r.changes:
    case c.kind
    of fcSymlink: echo "Created symlink " & c.link & " \xe2\x86\x92 " & c.target & "."
    of fcUnlink: echo "Removed " & c.link & "."
    else: discard

proc printDiags(r: FileOpResult) =
  for d in r.diags:
    stderr.writeLine(if d.severity == sevError: d.message else: d.message)

proc parseOpts(args: seq[string]; verb: var string): Opts =
  result.lines = 10
  var i = 0
  var positional: seq[string]
  proc nextVal(arg: string; inline: string): string =
    if inline.len > 0: return inline
    inc i
    if i < args.len: args[i] else: ""
  while i < args.len:
    let a = args[i]
    if a == "--":
      positional.add args[i + 1 .. ^1]
      break
    if a.startsWith("--"):
      var name = a[2 .. ^1]
      var val = ""
      let eq = name.find('=')
      if eq >= 0:
        val = name[eq + 1 .. ^1]
        name = name[0 ..< eq]
      case name
      of "user": result.user = true
      of "system": result.system = true
      of "no-block": result.noBlock = true
      of "wait": result.wait = true
      of "now": result.now = true
      of "force": result.force = true
      of "runtime": result.runtime = true
      of "global": result.global = true
      of "no-reload": result.noReload = true
      of "reverse": result.reverse = true
      of "after": result.after = true
      of "before": result.before = true
      of "all": result.all = true
      of "failed": result.failed = true
      of "quiet": result.quiet = true
      of "no-legend": result.noLegend = true
      of "plain": result.plain = true
      of "drop-in": result.dropin = nextVal(a, val)
      of "stdin": result.fromStdin = true
      of "no-pager", "no-ask-password", "no-wall", "check-inhibitors", "when", "message", "full":
        if name == "full": (result.editFull = true; result.full = true)
        if name in ["when", "message", "check-inhibitors"] and val.len == 0 and false: discard
      of "value": result.value = true
      of "root": result.root = nextVal(a, val)
      of "job-mode": result.jobMode = nextVal(a, val)
      of "kill-whom", "kill-who": result.killWhom = nextVal(a, val)
      of "signal": result.signal = nextVal(a, val)
      of "what": result.what = nextVal(a, val)
      of "preset-mode": result.presetMode = nextVal(a, val)
      of "type": result.types.add nextVal(a, val).split(',')
      of "state": result.states.add nextVal(a, val).split(',')
      of "property": result.props.add nextVal(a, val).split(',')
      of "lines": result.lines = (try: parseInt(nextVal(a, val)) except ValueError: 10)
      of "output": result.output = nextVal(a, val)
      of "host", "machine":
        stderr.writeLine "Remote and container operation is not supported."
        quit(1)
      of "version":
        echo "systemd 255 (255.0-jumpstart-core)"
        echo "-PAM -AUDIT -SELINUX -APPARMOR -IMA -SMACK +SECCOMP +CGROUP2"
        quit(0)
      of "help": verb = "help"
      else:
        stderr.writeLine "Unknown option: --" & name
        quit(1)
    elif a.len > 1 and a[0] == '-':
      for k, ch in a[1 .. ^1]:
        case ch
        of 'a': result.all = true
        of 'q': result.quiet = true
        of 'f': result.force = true
        of 'l': result.full = true
        of 'i': discard
        of 'h': verb = "help"
        of 't': result.types.add nextVal(a, "").split(',')
        of 'p': result.props.add nextVal(a, "").split(',')
        of 'n': result.lines = (try: parseInt(nextVal(a, "")) except ValueError: 10)
        of 'o': result.output = nextVal(a, "")
        of 's': result.signal = nextVal(a, "")
        of 'H', 'M':
          stderr.writeLine "Remote and container operation is not supported."
          quit(1)
        else:
          stderr.writeLine "Unknown option: -" & ch
          quit(1)
        if ch in {'t', 'p', 'n', 'o', 's'}: break
    else: positional.add a
    inc i
  if verb.len == 0:
    if positional.len > 0:
      verb = positional[0]
      result.args = positional[1 .. ^1]
    else: verb = "list-units"
  else: result.args = positional

proc expect(r: SdcReply): JsonNode =
  if not r.ok:
    stderr.writeLine r.message
    quit(1)
  r.result

proc jobFailureLine(unitName: string; r: SdcReply): string =
  ## "Job for X failed because REASON." as systemd prints it.
  var msg = r.message
  if msg.startsWith("Job for " & unitName & " failed because"): return msg & "\nSee \"systemctl status " & unitName &
    "\" and \"journalctl -xeu " & unitName & "\" for details."
  msg

proc submitJobs(c: SdcClient; o: Opts; typ: string; mode = "replace"): int =
  var rc = 0
  for raw in o.args:
    let name = mangle(raw)
    let jm = if o.jobMode.len > 0: o.jobMode else: mode
    let r = c.request("job-submit", %*{"unit": name, "type": typ, "mode": jm, "wait": not o.noBlock})
    if not r.ok:
      if r.code == ecNotFound or r.code == ecUnitState or r.code == ecUnsupported:
        stderr.writeLine (if r.code == ecNotFound: "Failed to " & typ & " " & name & ": " & r.message
                         else: jobFailureLine(name, r))
      else:
        stderr.writeLine jobFailureLine(name, r)
      rc = 1
  rc

proc statusText(c: SdcClient; name: string; o: Opts): int =
  let r = c.request("unit-status", %*{"name": name})
  if not r.ok:
    if r.code == ecNotFound:
      stderr.writeLine "Unit " & name & " could not be found."
      return 4
    stderr.writeLine r.message
    return 1
  let j = r.result
  let active = j["active_state"].strVal
  let sub = j["sub"].strVal
  let desc = j["description"].strVal
  let col = useColor()
  let mk = marker(active)
  echo mk & " " & name & (if desc.len > 0: " - " & desc else: "")
  let frag = j["fragment_path"].strVal
  let load = j["load_state"].strVal
  echo "     Loaded: " & load & (if frag.len > 0: " (" & frag & "; " & j["enablement"].strVal & ")" else: "")
  var line = "     Active: " & active & " (" & sub & ")"
  if j.hasKey("since"): line &= " since " & fmtTime(try: parse(j["since"].strVal[0 ..< 19], "yyyy-MM-dd'T'HH:mm:ss", utc()).toTime.toUnix * 1_000_000 except CatchableError: 0) & "; " & ago(j["since"].strVal)
  if active == "failed" and j["result"].strVal.len > 0: line &= "\n     Result: " & j["result"].strVal
  echo line
  if j.hasKey("main_pid") and j["main_pid"].intVal > 0:
    echo "   Main PID: " & $j["main_pid"].intVal
  let st = j["detail"].strVal
  let sidx = st.find("status=\"")
  if sidx >= 0: echo "     Status: " & st[sidx + 7 .. ^1].strip(chars = {'"'})
  if j.hasKey("cgroup_tree") and j["cgroup_tree"].len > 0:
    let cg = j["cgroup_tree"][0]
    var path = cg["path"].strVal
    let ui = path.find("/units/")
    if ui >= 0: path = path[ui + 6 .. ^1].replace(".unit", "")
    echo "     CGroup: " & path
    let pids = cg["pids"]
    for k, p in pids.elems:
      let cmd = try: readFile("/proc/" & $p.intVal & "/cmdline").replace("\0", " ").strip except IOError: ""
      echo "             " & (if k == pids.len - 1: "\xe2\x94\x94\xe2\x94\x80" else: "\xe2\x94\x9c\xe2\x94\x80") & $p.intVal & " " & cmd
  if o.lines > 0 and load == "loaded":
    try:
      let roots = block:
        var r0 = systemRoots()
        r0.rt = getEnv("JUMPSTART_CORE_RUNTIME_DIR", "/run/jumpstart/cores/systemd")
        r0.st = getEnv("JUMPSTART_CORE_STATE_DIR", "/var/lib/jumpstart/cores/systemd")
        r0
      let es = readEntries(roots, name, none(int64), none(int64), o.lines)
      if es.len > 0: echo ""
      for e in es:
        echo e.time[0 ..< 19].replace("T", " ") & " " & name & ": " & e.message
    except CatchableError: discard
  if col: discard
  if active in ["active", "reloading"]: 0 else: 3

proc showUnits(c: SdcClient; o: Opts) =
  if o.args.len == 0:
    echo "Version=255\nArchitecture=" & hostCPU
    return
  let r = c.request("unit-show", %*{"names": o.args.mapIt(mangle(it)), "properties": o.props,
                                   "all": o.all or o.showAll}).expect
  var first = true
  for u in r["units"]:
    if not first: echo ""
    first = false
    for k, v in u["properties"]:
      let val = v.strVal
      if val.len == 0 and not o.all and o.props.len == 0: continue
      if o.value: echo val else: echo k & "=" & val

proc listUnits(c: SdcClient; o: Opts) =
  var states = o.states
  if o.failed: states = @["failed"]
  var rows: seq[JsonNode]
  discard c.request("unit-list", %*{"states": states, "types": o.types, "patterns": o.args,
    "all": o.all}, proc(x: JsonNode) = rows.add x).expect
  var w = [4, 4, 6, 3]
  for r in rows:
    w[0] = max(w[0], r["name"].strVal.len)
    w[1] = max(w[1], r["load"].strVal.len)
    w[2] = max(w[2], r["active"].strVal.len)
    w[3] = max(w[3], r["sub"].strVal.len)
  if not o.noLegend:
    echo "  " & "UNIT".alignLeft(w[0]) & " " & "LOAD".alignLeft(w[1]) & " " & "ACTIVE".alignLeft(w[2]) &
      " " & "SUB".alignLeft(w[3]) & " DESCRIPTION"
  for r in rows:
    let mk = if r["active"].strVal == "failed": marker("failed") else: " "
    echo mk & " " & r["name"].strVal.alignLeft(w[0]) & " " & r["load"].strVal.alignLeft(w[1]) & " " &
      r["active"].strVal.alignLeft(w[2]) & " " & r["sub"].strVal.alignLeft(w[3]) & " " & r["description"].strVal
  if not o.noLegend:
    echo "\nLOAD   = Reflects whether the unit definition was properly loaded."
    echo "ACTIVE = The high-level unit activation state, i.e. generalization of SUB."
    echo "SUB    = The low-level unit activation state, values depend on unit type."
    echo "\n" & $rows.len & " loaded units listed."

proc listUnitFiles(c: SdcClient; o: Opts) =
  var rows: seq[JsonNode]
  discard c.request("unit-list-files", %*{"types": o.types, "states": o.states, "patterns": o.args},
    proc(x: JsonNode) = rows.add x).expect
  var w = 9
  for r in rows: w = max(w, r["name"].strVal.len)
  if not o.noLegend: echo "UNIT FILE".alignLeft(w) & " STATE   PRESET"
  for r in rows: echo r["name"].strVal.alignLeft(w) & " " & r["state"].strVal.alignLeft(7) & " -"
  if not o.noLegend: echo "\n" & $rows.len & " unit files listed."

proc printTree(n: JsonNode; prefix = "") =
  let kids = n["children"]
  for i, k in kids.elems:
    let last = i == kids.len - 1
    echo prefix & (if last: "\xe2\x94\x94\xe2\x94\x80" else: "\xe2\x94\x9c\xe2\x94\x80") &
      marker(k["active"].strVal) & " " & k["name"].strVal
    printTree(k, prefix & (if last: "  " else: "\xe2\x94\x82 "))

proc catUnits(c: SdcClient; o: Opts): int =
  var first = true
  for n in o.args:
    let r = c.request("unit-cat", %*{"names": [mangle(n)]})
    if not r.ok:
      stderr.writeLine "No files found for " & mangle(n) & "."
      result = 1
      continue
    for u in r.result["units"]:
      for f in u["files"]:
        if not first: echo ""
        first = false
        echo "# " & f["path"].strVal
        stdout.write f["text"].strVal
        if not f["text"].strVal.endsWith("\n"): echo ""

proc runFileOp(o: Opts; verb: string): int =
  let op = fileOpFromArgs(verb).get
  var names = o.args
  var opts = FileOpOptions(runtime: o.runtime, global: o.global, force: o.force)
  if o.presetMode == "enable-only": opts.presetMode = pmEnableOnly
  elif o.presetMode == "disable-only": opts.presetMode = pmDisableOnly
  if op in {foAddWants, foAddRequires}:
    if names.len < 2:
      stderr.writeLine "Too few arguments."
      return 1
    opts.target = names[0]
    names = names[1 .. ^1]
  let offline = o.root.len > 0
  var conn: SdcClient
  if not offline: conn = connect(sockPath(o))
  if conn == nil or offline:
    let r = fileOp(offlineRoots(o), op, names, opts)
    printDiags(r)
    if op == foIsEnabled:
      var any = false
      for (n, s) in r.states:
        if not o.quiet: echo $s
        if s in {esEnabled, esEnabledRuntime, esStatic, esAlias, esIndirect, esGenerated, esTransient}: any = true
      return (if any: 0 else: 1)
    printChanges(r, o.quiet)
    if not r.ok:
      stderr.writeLine r.error
      return 1
    return 0
  if op == foIsEnabled:
    var any = false
    for n in names:
      let r = conn.request("unit-show", %*{"names": [mangle(n)], "properties": ["UnitFileState"]})
      let st = if r.ok: r.result["units"][0]["properties"]["UnitFileState"].strVal else: "not-found"
      if not o.quiet: echo st
      if st in ["enabled", "enabled-runtime", "static", "alias", "indirect", "generated", "transient"]: any = true
    return (if any: 0 else: 1)
  let opName = case op
    of foEnable: "enable"
    of foDisable: "disable"
    of foReenable: "reenable"
    of foMask: "mask"
    of foUnmask: "unmask"
    of foLink: "link"
    of foPreset: "preset"
    of foPresetAll: "preset-all"
    of foRevert: "revert"
    of foAddWants: "add-wants"
    of foAddRequires: "add-requires"
    else: "set-default"
  var args = %*{"op": opName, "names": names, "runtime": o.runtime, "global": o.global,
    "force": o.force, "now": o.now, "reload": not o.noReload, "target": opts.target,
    "preset_mode": o.presetMode}
  let r = conn.request("unit-file-op", args)
  if not r.ok:
    stderr.writeLine r.message
    return 1
  if not o.quiet:
    for ch in r.result["changes"]:
      if ch["type"].strVal == "symlink":
        echo "Created symlink " & ch["path"].strVal & " \xe2\x86\x92 " & ch["destination"].strVal & "."
      else: echo "Removed " & ch["path"].strVal & "."
  0

proc editRoots(o: Opts): Roots =
  result = offlineRoots(o)
  if o.user and o.root.len == 0:
    result.home = getHomeDir().strip(chars = {'/'}, leading = false)
    result.etc = result.home / ".config"
    result.sysrun = getEnv("XDG_RUNTIME_DIR", "/run/user/" & $geteuid()) / "systemd"

proc fragmentsOf(conn: SdcClient; roots: Roots; names: seq[string]): seq[string] =
  ## Fragment path of each unit ("" when it has none), from the manager, or
  ## from the unit index when there is no manager.
  if conn != nil:
    let r = conn.request("unit-show", %*{"names": names, "properties": ["FragmentPath"]})
    if r.ok:
      for u in r.result["units"]: result.add u["properties"]{"FragmentPath"}.strVal
      return
  var d: seq[Diag]
  let idx = buildIndex(roots, @[], d, permissive())
  for n in names:
    let rs = resolveName(idx, n)
    result.add (if rs.isSome: fragmentFor(idx, rs.get) else: "")

proc editVerb(o: Opts): int =
  if o.args.len == 0:
    stderr.writeLine "Too few arguments."
    return 1
  let roots = editRoots(o)
  var conn: SdcClient
  if o.root.len == 0: conn = connect(sockPath(o))
  let names = o.args.mapIt(mangle(it))
  let frags = fragmentsOf(conn, roots, names)
  let stdinText = if o.fromStdin: stdin.readAll() else: ""
  var changed = false
  for i, n in names:
    if frags[i].len == 0 and not o.force:
      stderr.writeLine "Failed to edit " & n & ": Unit does not exist. Use --force to create it."
      result = 1
      continue
    var err = ""
    case editOne(n, frags[i], roots, EditOpts(full: o.editFull, runtime: o.runtime, force: o.force,
        fromStdin: o.fromStdin, dropin: o.dropin), stdinText, err)
    of erChanged: changed = true
    of erUnchanged: stderr.writeLine "No changes made to " & n & "."
    of erEmpty: stderr.writeLine "Skipping empty file for " & n & "."
    of erFailed:
      stderr.writeLine err
      result = 1
  if changed and not o.noReload and conn != nil:
    let r = try: conn.request("daemon-reload") except IOError: SdcReply(ok: false, message: "connection lost")
    if not r.ok:
      stderr.writeLine "Failed to reload the manager: " & r.message
      return 1
    for n in names:
      let v = conn.request("unit-validate", %*{"name": n})
      if v.ok:
        for d in v.result["diagnostics"]:
          if d["severity"].strVal in ["warning", "error"] and d["file"].strVal.len > 0:
            stderr.writeLine d["file"].strVal & ":" & $d["line"].intVal & ": " & d["message"].strVal

proc setPropertyVerb(c: SdcClient; o: Opts): int =
  if o.args.len < 2:
    stderr.writeLine "Too few arguments."
    return 1
  let r = c.request("set-property", %*{"unit": mangle(o.args[0]), "runtime": o.runtime,
    "properties": o.args[1 .. ^1]})
  if not r.ok:
    stderr.writeLine "Failed to set properties on " & mangle(o.args[0]) & ": " & r.message
    return 1

proc cleanVerb(c: SdcClient; o: Opts): int =
  if o.args.len == 0:
    stderr.writeLine "Too few arguments."
    return 1
  for raw in o.args:
    let r = c.request("clean", %*{"unit": mangle(raw),
      "what": (if o.what.len > 0: o.what.split(',') else: @[])})
    if not r.ok:
      stderr.writeLine "Failed to clean " & mangle(raw) & ": " & r.message
      result = 1

proc listTimers(c: SdcClient; o: Opts): int =
  var rows: seq[JsonNode]
  var states = o.states
  if not o.all and states.len == 0: states = @["active"]
  discard c.request("unit-list", %*{"states": states, "types": ["timer"], "patterns": o.args,
    "all": o.all}, proc(x: JsonNode) = rows.add x).expect
  let now = getTime().toUnix * 1_000_000
  type Row = tuple[next, last: int64, unit, activates: string]
  var table: seq[Row]
  for r in rows:
    let name = r["name"].strVal
    let sh = c.request("unit-show", %*{"names": [name],
      "properties": ["NextElapseUSecRealtime", "LastTriggerUSec", "Unit"]})
    if not sh.ok: continue
    let p = sh.result["units"][0]["properties"]
    proc num(k: string): int64 = (try: parseBiggestInt(p{k}.strVal) except ValueError: 0)
    table.add (num("NextElapseUSecRealtime"), num("LastTriggerUSec"), name, p{"Unit"}.strVal)
  table.sort(proc(a, b: Row): int =
    let ka = if a.next > 0: a.next else: high(int64)
    let kb = if b.next > 0: b.next else: high(int64)
    result = cmp(ka, kb)
    if result == 0: result = cmp(a.unit, b.unit))
  var cells: seq[array[6, string]]
  for t in table:
    cells.add [(if t.next > 0: formatLocal(t.next) else: "-"),
               (if t.next > 0: roughTimespan(abs(t.next - now)) & (if t.next >= now: " left" else: " ago") else: "-"),
               (if t.last > 0: formatLocal(t.last) else: "-"),
               (if t.last > 0: roughTimespan(abs(now - t.last)) & " ago" else: "-"),
               t.unit, t.activates]
  var w: array[6, int]
  let heads = ["NEXT", "LEFT", "LAST", "PASSED", "UNIT", "ACTIVATES"]
  for i in 0 .. 5:
    w[i] = heads[i].len
    for c in cells: w[i] = max(w[i], c[i].len)
  proc line(c: array[6, string]): string =
    for i in 0 .. 5: result.add (if i < 5: c[i].alignLeft(w[i]) & " " else: c[i])
  if not o.noLegend: echo line(heads)
  for c in cells: echo line(c)
  if not o.noLegend: echo "\n" & $cells.len & " timers listed."

proc systemctlMain*(args: seq[string]): int =
  var verb = ""
  let o = parseOpts(args, verb)
  if verb == "help":
    echo "systemctl [OPTIONS...] COMMAND [UNIT...]\n\nQuery or send control commands to the system manager."
    return 0
  if fileOpFromArgs(verb).isSome and verb != "get-default":
    return runFileOp(o, verb)
  case verb
  of "suspend", "hibernate", "hybrid-sleep", "suspend-then-hibernate", "soft-reboot", "switch-root":
    stderr.writeLine "Operation not supported by the systemd core."
    return 1
  of "edit": return editVerb(o)
  of "get-default":
    if o.root.len > 0:
      let r = fileOp(offlineRoots(o), foIsEnabled, @["default.target"], FileOpOptions())
      var d: seq[Diag]
      let idx = buildIndex(offlineRoots(o), @[], d)
      let rr = resolveName(idx, "default.target")
      echo (if rr.isSome: rr.get.id else: "multi-user.target")
      discard r
      return 0
    let c = connectManager(o)
    echo c.request("get-default").expect["name"].strVal
    return 0
  else: discard
  let c = connectManager(o)
  var rc = 0
  try:
    case verb
    of "start": rc = submitJobs(c, o, "start")
    of "stop": rc = submitJobs(c, o, "stop")
    of "restart": rc = submitJobs(c, o, "restart")
    of "reload": rc = submitJobs(c, o, "reload")
    of "try-restart", "condrestart": rc = submitJobs(c, o, "try-restart")
    of "reload-or-restart": rc = submitJobs(c, o, "reload-or-start")
    of "try-reload-or-restart", "force-reload": rc = submitJobs(c, o, "try-reload-or-start")
    of "isolate": rc = submitJobs(c, o, "start", "isolate")
    of "default":
      var oo = o
      oo.args = @["default.target"]
      rc = submitJobs(c, oo, "start", "isolate")
    of "rescue", "emergency":
      var oo = o
      oo.args = @[verb & ".target"]
      rc = submitJobs(c, oo, "start", "isolate")
    of "kill":
      for raw in o.args:
        let r = c.request("kill", %*{"unit": mangle(raw), "whom": (if o.killWhom.len > 0: o.killWhom else: "all"),
                                     "signal": (if o.signal.len > 0: o.signal else: "TERM")})
        if not r.ok:
          stderr.writeLine "Failed to kill " & mangle(raw) & ": " & r.message
          rc = 1
    of "status":
      if o.args.len == 0:
        let s = c.request("system-state").expect
        echo marker("active") & " State: " & s["state"].strVal
        echo "     Jobs: " & $s["jobs"].intVal & " queued"
        echo "   Failed: " & $s["failed"].len & " units"
      else:
        for raw in o.args:
          let r0 = statusText(c, mangle(raw), o)
          rc = max(rc, r0)
          if o.args.len > 1: echo ""
    of "show": showUnits(c, o)
    of "cat": rc = catUnits(c, o)
    of "is-active", "is-failed":
      var any = false
      for raw in o.args:
        let r = c.request("unit-show", %*{"names": [mangle(raw)], "properties": ["ActiveState"]})
        let st = if r.ok: r.result["units"][0]["properties"]["ActiveState"].strVal else: "inactive"
        if not o.quiet: echo st
        if verb == "is-active" and st in ["active", "reloading"]: any = true
        if verb == "is-failed" and st == "failed": any = true
      rc = if any: 0 else: (if verb == "is-active": 3 else: 1)
    of "list-units": listUnits(c, o)
    of "list-unit-files": listUnitFiles(c, o)
    of "list-jobs":
      var rows: seq[JsonNode]
      discard c.request("job-list", newJObject(), proc(x: JsonNode) = rows.add x).expect
      if not o.noLegend: echo "JOB UNIT TYPE STATE"
      for r in rows: echo $r["job"].intVal & " " & r["unit"].strVal & " " & r["type"].strVal & " " & r["state"].strVal
      if not o.noLegend: echo "\n" & $rows.len & " jobs listed."
    of "list-dependencies":
      let name = if o.args.len > 0: mangle(o.args[0]) else: "default.target"
      let t = c.request("unit-deps", %*{"name": name, "reverse": o.reverse, "all": o.all}).expect["tree"]
      echo marker(t["active"].strVal) & " " & t["name"].strVal
      printTree(t)
    of "daemon-reload", "daemon-reexec":
      let r = c.request("daemon-reload")
      if not r.ok:
        stderr.writeLine r.message
        rc = 1
    of "reset-failed":
      if o.args.len == 0: discard c.request("reset-failed").expect
      for raw in o.args: discard c.request("reset-failed", %*{"unit": mangle(raw)}).expect
    of "show-environment":
      for k, v in c.request("environment", %*{"action": "show"}).expect["vars"]: echo k & "=" & v.strVal
    of "set-environment", "unset-environment", "import-environment":
      var vars = newJObject()
      if verb == "set-environment":
        for a in o.args:
          let eq = a.find('=')
          if eq > 0: vars[a[0 ..< eq]] = %a[eq + 1 .. ^1]
      else: vars = %o.args
      discard c.request("environment", %*{"action": verb.split('-')[0], "vars": vars}).expect
    of "is-system-running":
      var st = c.request("system-state").expect["state"].strVal
      if o.wait:
        while st in ["initializing", "starting"]:
          sleep 200
          st = c.request("system-state").expect["state"].strVal
      echo st
      rc = if st == "running": 0 else: 1
    of "poweroff", "reboot", "halt", "kexec":
      let a = if verb == "kexec": "reboot" else: verb
      if o.force: stderr.writeLine "Warning: --force is ignored; Jumpstart's orderly shutdown is used."
      let r = c.request("power", %*{"action": a})
      if not r.ok or not r.result["accepted"].boolVal:
        stderr.writeLine "Failed to " & verb & ": " & (if r.ok: "request was refused" else: r.message)
        rc = 1
    of "exit":
      let r = c.request("power", %*{"action": "exit"})
      if not r.ok: (stderr.writeLine r.message; rc = 1)
    of "cancel":
      if o.args.len == 0: discard c.request("job-cancel").expect
      for a in o.args: discard c.request("job-cancel", %*{"job": (try: parseInt(a) except ValueError: 0)})
    of "set-property": rc = setPropertyVerb(c, o)
    of "clean": rc = cleanVerb(c, o)
    of "list-timers": rc = listTimers(c, o)
    of "whoami":
      for p in (if o.args.len > 0: o.args else: @[$getpid()]):
        let text = try: readFile("/proc/" & p & "/cgroup") except IOError: ""
        for line in text.splitLines:
          if line.startsWith("0::"):
            let comps = line[3 .. ^1].split('/').filterIt(it.endsWith(".unit"))
            if comps.len > 0:
              echo comps[^1][0 ..< comps[^1].len - 5]
    else:
      stderr.writeLine (if verb in ["bind", "mount-image", "service-log-level", "service-log-target",
        "list-machines", "list-automounts", "list-sockets", "list-paths",
        "freeze", "thaw"]: NotSupported
        else: "Unknown command verb " & verb & ".")
      rc = 1
  except IOError as e:
    stderr.writeLine "Failed to talk to the manager: " & e.msg
    rc = 1
  rc
