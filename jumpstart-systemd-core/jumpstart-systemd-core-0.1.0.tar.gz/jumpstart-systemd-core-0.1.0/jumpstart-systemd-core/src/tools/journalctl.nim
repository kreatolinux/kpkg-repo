## journalctl (section 15.3): reads the journal files directly (journal/reader.nim) and
## talks to journald's control socket for --rotate, --vacuum-*, --flush, --sync and
## --disk-usage. `journalctlRun` takes its roots and output sinks so tests can
## capture everything; `journalctlMain` is what the multi-call binary calls.
import std/[os, posix, json, options, strutils, unicode, sequtils, algorithm]
import ../common/[roots, results]
from ../common/clock import newClock, realUsec
from ../common/names import mangle
import ../journal/[format, reader, control, conf, logops, regexlite, verify]

type
  Output = proc(s: string)
  Opts = object
    units, userUnits, idents: seq[string]
    follow, reverse, noTail, quiet, utc, noHostname, noPager, all, dmesg: bool
    showCursor, listBoots, listFields: bool
    lines: Option[int]               ## 0 = all
    boot: Option[string]
    output, grep, field, directory, cursorFile: string
    outputFields: seq[string]
    priority, since, until, cursor, afterCursor: string
    caseSensitive: Option[bool]
    user: bool
    rotate, flush, sync, diskUsage: bool
    header, verify, newId128: bool
    files: seq[string]
    vacuumSize, vacuumTime: string
    vacuumFiles: int
    positional: seq[string]
  ArgKind = enum akNone, akReq, akOpt

const
  Specs: seq[tuple[long: string, short: char, kind: ArgKind]] = @[
    ("unit", 'u', akReq), ("user-unit", '\0', akReq), ("identifier", 't', akReq),
    ("follow", 'f', akNone), ("lines", 'n', akOpt), ("reverse", 'r', akNone),
    ("no-tail", '\0', akNone), ("boot", 'b', akOpt), ("list-boots", '\0', akNone),
    ("priority", 'p', akReq), ("since", 'S', akReq), ("until", 'U', akReq),
    ("output", 'o', akReq), ("output-fields", '\0', akReq), ("all", 'a', akNone),
    ("no-full", '\0', akNone), ("full", 'l', akNone), ("catalog", 'x', akNone),
    ("quiet", 'q', akNone), ("utc", '\0', akNone), ("no-hostname", '\0', akNone),
    ("no-pager", '\0', akNone), ("pager-end", 'e', akNone), ("dmesg", 'k', akNone),
    ("grep", 'g', akReq), ("case-sensitive", '\0', akOpt), ("field", 'F', akReq),
    ("fields", 'N', akNone), ("cursor", '\0', akReq), ("after-cursor", '\0', akReq),
    ("cursor-file", '\0', akReq), ("show-cursor", '\0', akNone), ("merge", 'm', akNone),
    ("directory", 'D', akReq), ("system", '\0', akNone), ("user", '\0', akNone),
    ("disk-usage", '\0', akNone), ("vacuum-size", '\0', akReq), ("vacuum-time", '\0', akReq),
    ("vacuum-files", '\0', akReq), ("rotate", '\0', akNone), ("flush", '\0', akNone),
    ("sync", '\0', akNone), ("help", 'h', akNone), ("version", '\0', akNone),
    ("file", '\0', akReq), ("header", '\0', akNone), ("verify", '\0', akNone),
    ("new-id128", '\0', akNone)]
  Unsupported = ["setup-keys", "update-catalog",
                 "list-catalog", "machine", "namespace", "interval", "force", "verify-key",
                 "root", "image", "sync-and-exit", "relinquish-var"]
  UnsupportedMsg = "Option not supported by the systemd core."
  PriorityNames = ["emerg", "alert", "crit", "err", "warning", "notice", "info", "debug"]

# --- time

proc tzset() {.importc, header: "<time.h>".}
proc timegm(tm: var Tm): Time {.importc, header: "<time.h>".}

proc fmtTime*(usec: int64; fmt: string; utc: bool): string =
  ## strftime of a microsecond timestamp in the local zone (or UTC).
  var t = Time(usec div 1_000_000)
  var tm: Tm
  tzset()
  if utc: discard gmtime_r(t, tm) else: discard localtime_r(t, tm)
  var buf = newString(256)
  let n = strftime(cstring(buf), 255, fmt.cstring, tm)
  buf.setLen n
  buf

proc mkTime(y, mo, d, h, mi, s: int; utc: bool): int64 =
  var tm: Tm
  tm.tm_year = cint(y - 1900); tm.tm_mon = cint(mo - 1); tm.tm_mday = cint(d)
  tm.tm_hour = cint(h); tm.tm_min = cint(mi); tm.tm_sec = cint(s)
  tm.tm_isdst = -1
  tzset()
  int64(if utc: timegm(tm) else: mktime(tm))

proc parseTimeSpec*(s: string; nowUsec: int64): Option[int64] =
  ## journalctl --since/--until syntax; local time zone unless the text ends in UTC.
  var t = s.strip
  var utc = false
  if t.len == 0: return
  if t.endsWith("UTC"):
    utc = true
    t = t[0 ..< t.len - 3].strip
  const day = 86_400_000_000'i64
  proc midnight(usec: int64): int64 =
    var tm: Tm
    var tt = Time(usec div 1_000_000)
    tzset()
    if utc: discard gmtime_r(tt, tm) else: discard localtime_r(tt, tm)
    mkTime(int(tm.tm_year) + 1900, int(tm.tm_mon) + 1, int(tm.tm_mday), 0, 0, 0, utc) * 1_000_000
  try:
    case t
    of "now": return some(nowUsec)
    of "today": return some(midnight(nowUsec))
    of "yesterday": return some(midnight(nowUsec) - day)
    of "tomorrow": return some(midnight(nowUsec) + day)
    else: discard
    if t.startsWith("@"):
      return some(int64(parseFloat(t[1 .. ^1]) * 1e6))
    if t.endsWith(" ago"): return some(nowUsec - parseTimespan(t[0 ..< t.len - 4]))
    if t.endsWith(" left"): return some(nowUsec + parseTimespan(t[0 ..< t.len - 5]))
    if t.len > 1 and t[0] in {'-', '+'} and t[1] in {'0'..'9'}:
      let span = parseTimespan(t[1 .. ^1])
      return some(if t[0] == '-': nowUsec - span else: nowUsec + span)
    # [DATE][ T]TIME
    var datePart, timePart: string
    let sep = t.find({' ', 'T'})
    if sep > 0 and '-' in t[0 ..< sep]:
      datePart = t[0 ..< sep]; timePart = t[sep + 1 .. ^1].strip
    elif ':' in t: timePart = t
    else: datePart = t
    var y, mo, d: int
    if datePart.len > 0:
      let p = datePart.split('-')
      if p.len != 3: return
      y = parseInt(p[0]); mo = parseInt(p[1]); d = parseInt(p[2])
      if mo notin 1 .. 12 or d notin 1 .. 31: return
    else:
      var tm: Tm
      var tt = Time(nowUsec div 1_000_000)
      tzset()
      if utc: discard gmtime_r(tt, tm) else: discard localtime_r(tt, tm)
      y = int(tm.tm_year) + 1900; mo = int(tm.tm_mon) + 1; d = int(tm.tm_mday)
    var h, mi, sec, frac = 0
    if timePart.len > 0:
      let p = timePart.split(':')
      if p.len notin 2 .. 3: return
      h = parseInt(p[0]); mi = parseInt(p[1])
      if p.len == 3:
        let sp = p[2].split('.')
        sec = parseInt(sp[0])
        if sp.len == 2: frac = parseInt((sp[1] & "000000")[0 ..< 6])
      if h > 23 or mi > 59 or sec > 60: return
    return some(mkTime(y, mo, d, h, mi, sec, utc) * 1_000_000 + frac)
  except ValueError:
    discard

# --- option parsing

proc specOf(name: string): int =
  for i, s in Specs:
    if s.long == name: return i
  -1

proc looksLikeBootSpec(s: string): bool =
  (s.len > 0 and (s.allCharsInSet({'0'..'9'}) or (s[0] in {'-', '+'} and s.len > 1 and s[1 .. ^1].allCharsInSet({'0'..'9'})))) or
    (s.len == 32 and s.allCharsInSet(HexDigits))

proc parseArgs(args: seq[string]; o: var Opts; errp: Output): bool =
  var i = 0
  var onlyPositional = false
  proc setOpt(o: var Opts; name, value: string; hasValue: bool): bool =
    case name
    of "unit": o.units.add value
    of "user-unit": o.userUnits.add value
    of "identifier": o.idents.add value
    of "follow": o.follow = true
    of "lines":
      if not hasValue: o.lines = some(10)
      elif value == "all": o.lines = some(0)
      else:
        try: o.lines = some(parseInt(value))
        except ValueError:
          errp "Failed to parse lines '" & value & "'\n"
          return false
    of "reverse": o.reverse = true
    of "no-tail": o.noTail = true
    of "boot": o.boot = some(if hasValue: value else: "0")
    of "list-boots": o.listBoots = true
    of "priority": o.priority = value
    of "since": o.since = value
    of "until": o.until = value
    of "output": o.output = value
    of "output-fields": o.outputFields = value.split(',')
    of "all": o.all = true
    of "quiet": o.quiet = true
    of "utc": o.utc = true
    of "no-hostname": o.noHostname = true
    of "no-pager": o.noPager = true
    of "dmesg": o.dmesg = true
    of "grep": o.grep = value
    of "case-sensitive":
      o.caseSensitive = some(not hasValue or value.toLowerAscii in ["1", "yes", "true", "on", "y", "t"])
    of "field": o.field = value
    of "fields": o.listFields = true
    of "cursor": o.cursor = value
    of "after-cursor": o.afterCursor = value
    of "cursor-file": o.cursorFile = value
    of "show-cursor": o.showCursor = true
    of "directory": o.directory = value
    of "user": o.user = true
    of "disk-usage": o.diskUsage = true
    of "vacuum-size": o.vacuumSize = value
    of "vacuum-time": o.vacuumTime = value
    of "vacuum-files":
      try: o.vacuumFiles = parseInt(value)
      except ValueError:
        errp "Failed to parse vacuum-files '" & value & "'\n"
        return false
    of "rotate": o.rotate = true
    of "flush": o.flush = true
    of "sync": o.sync = true
    of "file":
      let hits = if value.anyIt(it in {'*', '?', '['}): toSeq(walkPattern(value)) else: @[value]
      if hits.len == 0:
        errp "Failed to open files '" & value & "': No such file or directory\n"
        return false
      for h in hits: o.files.add h
    of "header": o.header = true
    of "verify": o.verify = true
    of "new-id128": o.newId128 = true
    of "help":
      errp "journalctl [OPTIONS...] [MATCHES...]\n"
      return false
    of "version": discard
    else: discard                 # accepted and ignored (-x, -a, -l, -m, --system, ...)
    true
  while i < args.len:
    let a = args[i]
    inc i
    if onlyPositional or a == "-" or not a.startsWith("-"):
      o.positional.add a
    elif a == "--": onlyPositional = true
    elif a.startsWith("--"):
      var name = a[2 .. ^1]
      var value = ""
      var hasValue = false
      let eq = name.find('=')
      if eq >= 0:
        value = name[eq + 1 .. ^1]; name = name[0 ..< eq]; hasValue = true
      if name in Unsupported:
        errp UnsupportedMsg & "\n"
        return false
      let si = specOf(name)
      if si < 0:
        errp "journalctl: unrecognized option '--" & name & "'\n"
        return false
      if Specs[si].kind == akReq and not hasValue:
        if i >= args.len:
          errp "journalctl: option '--" & name & "' requires an argument\n"
          return false
        value = args[i]; inc i; hasValue = true
      elif Specs[si].kind == akOpt and not hasValue and name in ["lines", "boot"] and i < args.len and
           (looksLikeBootSpec(args[i]) or (name == "lines" and args[i] == "all")):
        value = args[i]; inc i; hasValue = true
      if not setOpt(o, name, value, hasValue): return false
    else:
      var j = 1
      while j < a.len:
        let c = a[j]
        inc j
        var si = -1
        for k, s in Specs:
          if s.short == c: si = k
        if c in {'M'}:
          errp UnsupportedMsg & "\n"
          return false
        if si < 0:
          errp "journalctl: invalid option -- '" & $c & "'\n"
          return false
        let name = Specs[si].long
        var value = ""
        var hasValue = false
        case Specs[si].kind
        of akReq:
          if j < a.len: value = a[j .. ^1]; j = a.len
          elif i < args.len: value = args[i]; inc i
          else:
            errp "journalctl: option requires an argument -- '" & $c & "'\n"
            return false
          hasValue = true
        of akOpt:
          if j < a.len: value = a[j .. ^1]; j = a.len; hasValue = true
          elif i < args.len and name in ["lines", "boot"] and
               (looksLikeBootSpec(args[i]) or (name == "lines" and args[i] == "all")):
            value = args[i]; inc i; hasValue = true
        of akNone: discard
        if not setOpt(o, name, value, hasValue): return false
  true

# --- formatting helpers

proc formatBytes*(n: int64): string =
  ## systemd's format_bytes: `512B`, `1.5K`, `8.0M`.
  if n < 1024: return $n & "B"
  var v = float(n)
  for u in ["K", "M", "G", "T", "P"]:
    v /= 1024
    if v < 1024 or u == "P": return formatFloat(v, ffDecimal, 1) & u

proc isText(s: string): bool =
  validateUtf8(s) < 0 and not s.anyIt(it < ' ' and it notin {'\n', '\t'})

proc displayValue(v: string; all: bool): string =
  if all or isText(v): v else: "[" & $v.len & "B blob data]"

proc messageOf(e: JournalEntry; o: Opts): string =
  displayValue(e.getField("MESSAGE"), o.all)

proc ident(e: JournalEntry): string =
  result = e.getField("SYSLOG_IDENTIFIER")
  if result.len == 0: result = e.getField("_COMM")

proc pidOf(e: JournalEntry): string =
  result = e.getField("_PID")
  if result.len == 0: result = e.getField("SYSLOG_PID")

proc shortLine(e: JournalEntry; o: Opts; stamp: string): string =
  result = stamp & " "
  if not o.noHostname and e.getField("_HOSTNAME").len > 0: result.add e.getField("_HOSTNAME") & " "
  result.add ident(e)
  let pid = pidOf(e)
  if pid.len > 0: result.add "[" & pid & "]"
  result.add ": " & messageOf(e, o) & "\n"

proc jsonValue(v: string): JsonNode =
  if validateUtf8(v) < 0: return %v
  result = newJArray()              # binary values are arrays of byte numbers
  for c in v: result.add %ord(c)

proc entryJson(e: JournalEntry; o: Opts): JsonNode =
  result = newJObject()
  result["__CURSOR"] = %cursorOf(e)
  result["__REALTIME_TIMESTAMP"] = %($e.realtime)
  result["__MONOTONIC_TIMESTAMP"] = %($e.monotonic)
  var haveBoot = false
  for f in e.fields:
    if f.key == "_BOOT_ID": haveBoot = true
  if not haveBoot: result["_BOOT_ID"] = %idHex(e.bootId)
  for f in e.fields:
    if o.outputFields.len > 0 and f.key notin o.outputFields: continue
    let v = jsonValue(f.value)
    if result.hasKey(f.key):
      if result[f.key].kind == JArray and not (v.kind == JArray and f.value.len > 0 and not isText(f.value)):
        result[f.key].add v
      else: result[f.key] = %[result[f.key], v]
    else: result[f.key] = v

proc formatEntry(e: JournalEntry; o: Opts): string =
  let utc = o.utc
  case o.output
  of "", "short": shortLine(e, o, fmtTime(e.realtime, "%b %d %H:%M:%S", utc))
  of "short-precise":
    shortLine(e, o, fmtTime(e.realtime, "%b %d %H:%M:%S", utc) & "." & align($(e.realtime mod 1_000_000), 6, '0'))
  of "short-full", "with-unit":
    shortLine(e, o, fmtTime(e.realtime, "%a %Y-%m-%d %H:%M:%S %Z", utc))
  of "short-iso": shortLine(e, o, fmtTime(e.realtime, "%Y-%m-%dT%H:%M:%S%z", utc))
  of "short-iso-precise":
    var z = fmtTime(e.realtime, "%z", utc)
    shortLine(e, o, fmtTime(e.realtime, "%Y-%m-%dT%H:%M:%S", utc) & "." &
              align($(e.realtime mod 1_000_000), 6, '0') & z)
  of "short-unix": shortLine(e, o, $(e.realtime div 1_000_000) & "." & align($(e.realtime mod 1_000_000), 6, '0'))
  of "short-monotonic":
    shortLine(e, o, "[" & align($(e.monotonic div 1_000_000), 5) & "." &
              align($(e.monotonic mod 1_000_000), 6, '0') & "]")
  of "cat":
    messageOf(e, o) & "\n"
  of "verbose":
    var s = fmtTime(e.realtime, "%a %Y-%m-%d %H:%M:%S", utc) & "." &
            align($(e.realtime mod 1_000_000), 6, '0') & fmtTime(e.realtime, " %Z", utc) &
            " [" & cursorOf(e) & "]\n"
    for f in e.fields:
      if o.outputFields.len > 0 and f.key notin o.outputFields: continue
      s.add "    " & f.key & "=" & displayValue(f.value, o.all) & "\n"
    s
  of "export":
    var s = "__CURSOR=" & cursorOf(e) & "\n__REALTIME_TIMESTAMP=" & $e.realtime &
            "\n__MONOTONIC_TIMESTAMP=" & $e.monotonic & "\n"
    var haveBoot = false
    for f in e.fields:
      if f.key == "_BOOT_ID": haveBoot = true
    if not haveBoot: s.add "_BOOT_ID=" & idHex(e.bootId) & "\n"
    for f in e.fields:
      if o.outputFields.len > 0 and f.key notin o.outputFields: continue
      if isText(f.value) and '\n' notin f.value: s.add f.key & "=" & f.value & "\n"
      else:
        s.add f.key & "\n"
        for i in 0 ..< 8: s.add char((uint64(f.value.len) shr (8 * i)) and 0xFF)
        s.add f.value & "\n"
    s & "\n"
  of "json": $entryJson(e, o) & "\n"
  of "json-pretty": entryJson(e, o).pretty(4) & "\n"
  of "json-sse": "data: " & $entryJson(e, o) & "\n\n"
  of "json-seq": "\x1e" & $entryJson(e, o) & "\n"
  else: ""

const OutputFormats = ["", "short", "short-full", "short-iso", "short-iso-precise", "short-precise",
  "short-monotonic", "short-unix", "verbose", "export", "json", "json-pretty", "json-sse",
  "json-seq", "cat", "with-unit"]

# --- query building

proc parsePriority(s: string): Option[tuple[lo, hi: int]] =
  proc one(x: string): int =
    let i = PriorityNames.find(x.toLowerAscii)
    if i >= 0: return i
    if x.len == 1 and x[0] in {'0'..'7'}: return ord(x[0]) - ord('0')
    -1
  let parts = s.split("..")
  if parts.len notin 1 .. 2: return
  let a = one(parts[0])
  let b = if parts.len == 2: one(parts[1]) else: a
  if a < 0 or b < 0: return
  if parts.len == 1: some((0, a)) else: some((min(a, b), max(a, b)))

proc positionalMatches(args: seq[string]; q: var JournalQuery; errp: Output): bool =
  var groups: seq[seq[JournalMatch]] = @[@[]]
  for a in args:
    if a == "+":
      groups.add @[]
    elif a.startsWith("/"):
      var m = JournalMatch(field: "_EXE", value: a)
      if fileExists(a):
        try:
          var f = open(a)
          var hdr = newString(2)
          if f.readBuffer(addr hdr[0], 2) == 2 and hdr == "#!":
            m = JournalMatch(field: "_COMM", value: a.extractFilename)
          f.close()
        except IOError: discard
      groups[^1].add m
    else:
      let eq = a.find('=')
      if eq <= 0 or not validKey(a[0 ..< eq]):
        errp "Failed to add match '" & a & "'\n"
        return false
      groups[^1].add JournalMatch(field: a[0 ..< eq], value: a[eq + 1 .. ^1])
  if groups.len == 1: q.matches.add groups[0]
  else:
    for g in groups:
      if g.len > 0: q.disjunctions.add g
  true

proc canRead(dirs: seq[string]): tuple[any, denied: bool] =
  proc check(d: string; r: var tuple[any, denied: bool]) =
    if not dirExists(d): return
    if access(d.cstring, R_OK or X_OK) != 0: r.denied = true; return
    for k, p in walkDir(d):
      if k == pcFile and p.endsWith(".jrn"):
        if access(p.cstring, R_OK) == 0: r.any = true else: r.denied = true
      elif k == pcDir: check(p, r)
  for d in dirs:
    try: check(d, result)
    except OSError: result.denied = true

# --- --verify, --header, --new-id128

proc verifyFiles(files: seq[string]; emit: Output): int =
  if files.len == 0:
    emit "No journal files were found.\n"
    return 0
  for p in files.sorted:
    let r = inspectFile(p)
    if r.problem.len == 0: emit "PASS: " & p & "\n"
    else:
      emit "FAIL: " & p & " (" & r.problem & ")\n"
      result = 1

proc showHeaders(files: seq[string]; utc: bool; emit: Output): int =
  if files.len == 0:
    emit "No journal files were found.\n"
    return 0
  proc ts(usec: int64): string =
    if usec <= 0: "n/a"
    else: fmtTime(usec, "%a %Y-%m-%d %H:%M:%S", utc) & "." & align($(usec mod 1_000_000), 6, '0') &
          fmtTime(usec, " %Z", utc)
  for p in files.sorted:
    let r = inspectFile(p)
    if not r.readable:
      emit "File path: " & p & "\nFailed to read the journal file header: " & r.problem & "\n\n"
      result = 1
      continue
    let h = r.header
    emit "File path: " & p & "\n" &
      "File ID: " & idHex(h.fileId) & "\n" &
      "Machine ID: " & idHex(h.machineId) & "\n" &
      "Boot ID: " & (if r.lastBootId.len == 16: idHex(r.lastBootId) else: "n/a") & "\n" &
      "Sequential number ID: " & idHex(h.seqnumId) & "\n" &
      "State: " & (if r.archived: "ARCHIVED" else: "ONLINE") & "\n" &
      "Header size: " & $HeaderSize & "\n" &
      "Head sequential number: " & $r.header.firstSeq & "\n" &
      "Tail sequential number: " & $r.lastSeq & "\n" &
      "Head realtime timestamp: " & ts(r.firstRealtime) & "\n" &
      "Tail realtime timestamp: " & ts(r.lastRealtime) & "\n" &
      "Tail monotonic timestamp: " & (if r.entries > 0: $(r.lastMonotonic div 1_000_000) & "." &
        align($(r.lastMonotonic mod 1_000_000), 6, '0') & "s" else: "n/a") & "\n" &
      "Entry objects: " & $r.entries & "\n" &
      "Disk usage: " & formatBytes(r.size) & "\n" &
      (if r.problem.len > 0: "Problem: " & r.problem & "\n" else: "") & "\n"

proc newId128(emit: Output): int =
  var raw = newString(16)
  var ok = false
  try:
    var f = open("/dev/urandom")
    ok = f.readBuffer(addr raw[0], 16) == 16
    f.close()
  except IOError: discard
  if not ok:
    emit "Failed to generate ID.\n"
    return 1
  raw[6] = char((ord(raw[6]) and 0x0F) or 0x40)       # UUID version 4
  raw[8] = char((ord(raw[8]) and 0x3F) or 0x80)
  let h = idHex(raw)
  let uuid = h[0 ..< 8] & "-" & h[8 ..< 12] & "-" & h[12 ..< 16] & "-" & h[16 ..< 20] & "-" & h[20 .. ^1]
  var mk = ""
  for i in 0 ..< 16:
    mk.add "0x" & h[2 * i .. 2 * i + 1]
    if i < 15: mk.add ", "
  emit "As string:\n" & h & "\n\nAs UUID:\n" & uuid & "\n\nAs macro:\n#define MESSAGE_XYZ SD_ID128_MAKE(" &
    mk & ")\n\nAs Python constant:\n>>> import uuid\n>>> MESSAGE_XYZ = uuid.UUID('" & uuid & "')\n"
  0

# --- running

proc runControl(o: Opts; roots: Roots; emit, errp: Output): int =
  let sock = controlSocketPath(roots.rt)
  proc call(req: JsonNode; what: string): Option[JsonNode] =
    let r = controlCall(sock, req)
    if not r.ok:
      errp "Failed to " & what & ": " & r.error & "\n"
      return
    if not r.value{"ok"}.getBool(false):
      errp "Failed to " & what & ": " & r.value{"error"}.getStr("unknown error") & "\n"
      return
    some(r.value)
  if o.flush and call(%*{"verb": "flush"}, "flush journal").isNone: return 1
  if o.rotate and call(%*{"verb": "rotate"}, "rotate journal").isNone: return 1
  if o.vacuumSize.len > 0 or o.vacuumTime.len > 0 or o.vacuumFiles > 0:
    var req = %*{"verb": "vacuum"}
    try:
      if o.vacuumSize.len > 0: req["max_size"] = %parseSize(o.vacuumSize)
      if o.vacuumTime.len > 0: req["max_age_usec"] = %parseTimespan(o.vacuumTime)
    except ValueError:
      errp "Failed to parse vacuum limit.\n"
      return 1
    if o.vacuumFiles > 0: req["max_files"] = %o.vacuumFiles
    let r = call(req, "vacuum journal")
    if r.isNone: return 1
    emit "Vacuuming done, freed " & formatBytes(r.get{"freed"}.getBiggestInt) &
         " of archived journals from " & (roots.st / "journal") & ".\n"
  if o.sync and call(%*{"verb": "sync"}, "sync journal").isNone: return 1
  if o.diskUsage:
    var bytes = -1'i64
    let r = controlCall(sock, %*{"verb": "disk-usage"})
    if r.ok and r.value{"ok"}.getBool(false): bytes = r.value{"bytes"}.getBiggestInt
    else:                                   # no daemon: add the files up locally
      bytes = 0
      for f in journalFiles(journalDirs(roots)): (try: bytes += getFileSize(f) except OSError: discard)
    emit "Archived and active journals take up " & formatBytes(bytes) & " in the file system.\n"
  0

proc realNowUsec(): int64 = newClock().realUsec()

proc journalctlRun*(args: seq[string]; roots: Roots; emit, errp: Output; nowUsec = 0'i64;
                    stop: proc(): bool = nil): int =
  ## Runs journalctl against `roots`. `emit` receives standard output, `errp`
  ## standard error; `stop` (polled while following) ends `--follow`.
  var o: Opts
  if not parseArgs(args, o, errp): return 1
  if o.output notin OutputFormats:
    errp "Unknown output format '" & o.output & "'.\n"
    return 1
  if o.follow and o.reverse:
    errp "Cannot use --follow with --reverse.\n"
    return 1
  let now = if nowUsec != 0: nowUsec else: realNowUsec()
  if o.rotate or o.flush or o.sync or o.diskUsage or o.vacuumSize.len > 0 or o.vacuumTime.len > 0 or
     o.vacuumFiles > 0:
    return runControl(o, roots, emit, errp)
  if o.newId128: return newId128(emit)
  let dirs = if o.directory.len > 0: @[o.directory] else: journalDirs(roots)
  if o.files.len > 0:
    for f in o.files:
      if not fileExists(f):
        errp "Failed to open file '" & f & "': No such file or directory\n"
        return 1
  elif not (o.verify or o.header):
    let access = canRead(dirs)
    if access.denied and not access.any:
      errp "No journal files were opened due to insufficient permissions.\n"
      return 1
  if o.header or o.verify:
    let files = if o.files.len > 0: o.files else: journalFiles(dirs)
    return if o.verify: verifyFiles(files, emit) else: showHeaders(files, o.utc, emit)
  let j = if o.files.len > 0: openJournalFiles(o.files) else: openJournal(dirs)

  var q: JournalQuery
  let userScope = o.user or roots.scope == scUser
  for u in o.units:
    let name = if u.anyIt(it in {'*', '?', '['}) and not u.contains('.'): u else: mangle(u)
    if userScope: q.userUnits.add name else: q.units.add name
  for u in o.userUnits: q.userUnits.add (if u.anyIt(it in {'*', '?', '['}) and not u.contains('.'): u else: mangle(u))
  for t in o.idents: q.matches.add JournalMatch(field: "SYSLOG_IDENTIFIER", value: t)
  if not positionalMatches(o.positional, q, errp): return 1
  if o.dmesg:
    q.matches.add JournalMatch(field: "_TRANSPORT", value: "kernel")
    if o.boot.isNone: o.boot = some("0")
  if o.priority.len > 0:
    let p = parsePriority(o.priority)
    if p.isNone:
      errp "Unknown log level " & o.priority & "\n"
      return 1
    q.maxPriority = some(p.get.hi)
    if p.get.lo > 0: q.minPriority = some(p.get.lo)
  if o.since.len > 0:
    let t = parseTimeSpec(o.since, now)
    if t.isNone:
      errp "Failed to parse timestamp: " & o.since & "\n"
      return 1
    q.sinceUsec = t
  if o.until.len > 0:
    let t = parseTimeSpec(o.until, now)
    if t.isNone:
      errp "Failed to parse timestamp: " & o.until & "\n"
      return 1
    q.untilUsec = t
  if q.sinceUsec.isSome and q.untilUsec.isSome and q.sinceUsec.get > q.untilUsec.get:
    errp "--since= must be before --until=.\n"
    return 1
  if o.grep.len > 0:
    q.grep = some(o.grep)
    q.caseSensitive = if o.caseSensitive.isSome: o.caseSensitive.get else: o.grep.anyIt(it in {'A'..'Z'})
  if o.cursorFile.len > 0 and o.afterCursor.len == 0 and o.cursor.len == 0 and fileExists(o.cursorFile):
    o.afterCursor = readFile(o.cursorFile).strip
  if o.cursor.len > 0 and not q.seekCursor(o.cursor):
    errp "Failed to seek to cursor: Invalid argument\n"
    return 1
  if o.afterCursor.len > 0 and not q.seekCursor(o.afterCursor, after = true):
    errp "Failed to seek to cursor: Invalid argument\n"
    return 1
  if o.grep.len > 0:
    try: discard compileRegex(o.grep)
    except ValueError:
      errp "Failed to compile regular expression: " & o.grep & "\n"
      return 1

  # boots
  if o.listBoots:
    let boots = j.listBoots
    if boots.len == 0:
      if not o.quiet: emit "-- No entries --\n"
      return 0
    emit "IDX BOOT ID                          FIRST ENTRY                 LAST ENTRY\n"
    for i, b in boots:
      let idx = i - (boots.len - 1)
      emit align($idx, 3) & " " & b.bootId & " " &
        fmtTime(b.firstUsec, "%a %Y-%m-%d %H:%M:%S %Z", o.utc) & " " &
        fmtTime(b.lastUsec, "%a %Y-%m-%d %H:%M:%S %Z", o.utc) & "\n"
    return 0
  if o.boot.isSome:
    let spec = o.boot.get
    if spec.len == 32 and spec.allCharsInSet(HexDigits): q.bootIds = @[spec.toLowerAscii]
    else:
      let boots = j.listBoots
      var idx = 0
      try: idx = parseInt(spec)
      except ValueError:
        errp "Failed to parse boot descriptor '" & spec & "'\n"
        return 1
      let at = if idx > 0: idx - 1 else: boots.len - 1 + idx
      if at < 0 or at >= boots.len:
        errp "No journal boot entry found from the specified boot offset.\n"
        return 1
      q.bootIds = @[boots[at].bootId]

  if o.listFields:
    for n in j.fieldNames: emit n & "\n"
    return 0
  if o.field.len > 0:
    for v in j.fieldValues(q, o.field): emit v & "\n"
    return 0

  var linesN = if o.lines.isSome: o.lines.get elif o.follow and not o.noTail: 10 else: 0
  q.limit = linesN
  q.reverse = o.reverse
  q.tail = true
  var last = ""
  var shown = 0
  proc show(e: JournalEntry) =
    emit formatEntry(e, o)
    last = cursorOf(e)
    inc shown
  if o.follow:
    j.follow(q, (proc(): bool = stop != nil and stop()), proc(e: JournalEntry): bool =
      show(e)
      true)
  else:
    for e in j.entries(q): show(e)
  if shown == 0 and not o.quiet and not o.follow: emit "-- No entries --\n"
  if o.showCursor and last.len > 0: emit "-- cursor: " & last & "\n"
  if o.cursorFile.len > 0 and last.len > 0:
    try: writeFile(o.cursorFile, last & "\n")
    except IOError: discard
  0

proc defaultRoots(user: bool): Roots =
  ## Roots for a shell: the environment's JUMPSTART_* values, else the
  ## documented locations of the core's runtime and state directories (section 5.1).
  var env = rootsFromEnvironment()
  if user: env.scope = scUser
  if env.rt.len == 0:
    env.rt = if user: getEnv("XDG_RUNTIME_DIR", "/run/user/" & $getuid()) / "jumpstart/cores/systemd"
             else: "/run/jumpstart/cores/systemd"
  if env.st.len == 0:
    env.st = if user: getHomeDir() / ".local/state/jumpstart/cores/systemd"
             else: "/var/lib/jumpstart/cores/systemd"
  env

var interrupted {.global.}: bool

proc journalctlMain*(args: seq[string]): int =
  ## Entry used by the multi-call binary.
  let user = "--user" in args
  let roots = defaultRoots(user)
  proc onInt(sig: cint) {.noconv.} = interrupted = true
  signal(SIGINT, onInt)
  signal(SIGPIPE, SIG_IGN)
  var pager: File
  let pagerCmd = getEnv("SYSTEMD_PAGER", getEnv("PAGER"))
  var usePager = isatty(1) != 0 and pagerCmd.len > 0 and "--no-pager" notin args and
                 "-f" notin args and "--follow" notin args
  if usePager:
    pager = popen(pagerCmd.cstring, "w")
    usePager = pager != nil
  let outp: Output = proc(s: string) =
    if usePager: pager.write s
    else:
      stdout.write s
      stdout.flushFile
  let errp: Output = proc(s: string) = stderr.write s
  result = journalctlRun(args, roots, outp, errp, 0, proc(): bool = interrupted)
  if usePager: discard pclose(pager)
