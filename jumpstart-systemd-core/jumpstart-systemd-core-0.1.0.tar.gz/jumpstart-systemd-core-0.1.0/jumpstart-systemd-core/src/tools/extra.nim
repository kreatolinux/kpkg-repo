## `systemd-cat`, `systemd-detect-virt`, `systemd-id128` and `systemd-inhibit`:
## the journal copy tool, the virtualization probe, 128-bit ID printing and the
## lock-less pass-through for COMMAND.
##
## The option parsers and the decision tables are pure; the filesystem probes,
## the socket and the process work sit behind small procs below them.
import std/[os, options, strutils, posix]
import ../common/[roots, clock]
import ../journal/[format, client, logops, sockutil]
import ../unitfile/values

# ---- systemd-cat -----------------------------------------------------------

const
  CatUsage = "systemd-cat [OPTIONS...] [COMMAND...]\n\n" &
    "Connect the output of COMMAND (or standard input) to the journal.\n\n" &
    "  -t --identifier=ID   syslog identifier (default: cat)\n" &
    "  -p --priority=PRIO   syslog priority name or number (default: info)\n" &
    "     --level-prefix=BOOL  read a <N> priority prefix on every line\n" &
    "     --stderr-priority    connect the command's standard error too\n"
  SyslogNames = ["emerg", "alert", "crit", "err", "warning", "notice", "info", "debug"]

type
  CatOpts* = object
    identifier*: string
    priority*: int
    levelPrefix*, stderrPriority*: bool
    command*: seq[string]
    help*: bool

  LevelPrefix* = object
    ## A line split at its `<N>` priority prefix.
    found*: bool
    priority*: int
    message*: string

proc parsePriority*(s: string): int =
  ## Syslog priority name (`emerg`..`debug`, also `error`, `warn`, `fatal`) or
  ## a number 0..7; -1 when unknown.
  if s.len == 1 and s[0] in {'0' .. '7'}: return ord(s[0]) - ord('0')
  let name = s.toLowerAscii
  let i = SyslogNames.find(name)
  if i >= 0: return i
  logops.priorityOfLevel(name)

proc splitLevelPrefix*(line: string): LevelPrefix =
  ## `<N>message` with N in 0..7: the prefix becomes the priority and is removed.
  if line.len >= 3 and line[0] == '<' and line[2] == '>' and line[1] in {'0' .. '7'}:
    LevelPrefix(found: true, priority: ord(line[1]) - ord('0'), message: line[3 .. ^1])
  else:
    LevelPrefix(message: line)

proc entryFields*(identifier: string; priority: int; message: string): seq[Field] =
  ## One native-protocol entry for a journal line.
  @[("MESSAGE", message), ("PRIORITY", $priority), ("SYSLOG_IDENTIFIER", identifier)]

proc optValue(args: seq[string]; i: var int; inline: string): string =
  ## The value of an option: from `--opt=VALUE`, else the next argument.
  if inline.len > 0: return inline
  inc i
  if i < args.len: args[i] else: ""

proc splitOption(word: string): tuple[name, inline: string] =
  ## `--name=VALUE`, `--name`, `-nVALUE` or `-n`.
  var body = word[1 .. ^1]
  if body.startsWith("-"):
    body = body[1 .. ^1]
    let eq = body.find('=')
    if eq >= 0: return (body[0 ..< eq], body[eq + 1 .. ^1])
    return (body, "")
  if body.len > 1: (body[0 .. 0], body[1 .. ^1]) else: (body, "")

proc parseCatArgs*(args: seq[string]; o: var CatOpts; err: var string): bool =
  ## Options up to the first non-option word, which starts COMMAND.
  var i = 0
  while i < args.len:
    let a = args[i]
    if a == "--":
      o.command = args[i + 1 .. ^1]
      return true
    if a.len > 1 and a[0] == '-' and a != "-":
      let (name, inline) = splitOption(a)
      case name
      of "identifier", "t":
        o.identifier = optValue(args, i, inline)
        if o.identifier.len == 0:
          err = "Identifier may not be empty."
          return false
      of "priority", "p":
        let v = optValue(args, i, inline)
        o.priority = parsePriority(v)
        if o.priority < 0:
          err = "Invalid priority: " & v
          return false
      of "level-prefix":
        let v = optValue(args, i, inline)
        let b = parseBoolVal(v)
        if b.isNone:
          err = "Invalid boolean value: " & v
          return false
        o.levelPrefix = b.get
      of "stderr-priority":
        o.stderrPriority = true
      of "help", "h":
        o.help = true
      else:
        err = "Unknown option: " & a
        return false
    else:
      o.command = args[i .. ^1]
      return true
    inc i
  true

proc unreachableReason(sysrun: string): string =
  ## The error line for a journal that does not accept entries; "" when it does.
  let path = nativeSocketPath(sysrun)
  let fd = connectUnix(path, stream = false)
  if fd < 0: return "Failed to connect to the journal: " & path & ": " & $strerror(errno)
  discard close(fd)
  ""

proc emit(sysrun: string; o: CatOpts; line: string): bool =
  ## Sends one line, applying the `<N>` prefix when asked; false on failure.
  var priority = o.priority
  var message = line
  if o.levelPrefix:
    let p = splitLevelPrefix(line)
    if p.found:
      priority = p.priority
      message = p.message
  result = journalSend(sysrun, entryFields(o.identifier, priority, message))
  if not result:
    stderr.writeLine "Failed to write to the journal: " & nativeSocketPath(sysrun)

proc feed(fd: cint; sysrun: string; o: CatOpts): bool =
  ## One journal entry per line of `fd`, including a last line without `\n`.
  var buf = newString(8192)
  var pending = ""
  while true:
    let n = read(fd, addr buf[0], buf.len)
    if n < 0:
      if errno == EINTR: continue
      break
    if n == 0: break
    pending.add buf[0 ..< n]
    while true:
      let nl = pending.find('\n')
      if nl < 0: break
      let line = pending[0 ..< nl]
      pending.delete(0 .. nl)
      if not emit(sysrun, o, line): return false
  result = pending.len == 0 or emit(sysrun, o, pending)

proc execute(o: CatOpts; sysrun: string): int =
  ## Runs COMMAND with its output piped to the journal; its exit status.
  var fds: array[0 .. 1, cint]
  if pipe(fds) != 0:
    stderr.writeLine "Failed to create a pipe: " & $strerror(errno)
    return 1
  stdout.flushFile()
  stderr.flushFile()
  let pid = fork()
  if pid < 0:
    stderr.writeLine "Failed to fork: " & $strerror(errno)
    return 1
  if pid == 0:
    discard close(fds[0])
    if fds[1] != 1: discard dup2(fds[1], 1)
    if o.stderrPriority and fds[1] != 2: discard dup2(fds[1], 2)
    if fds[1] != 1 and fds[1] != 2: discard close(fds[1])
    let argv = allocCStringArray(o.command)
    discard execvp(o.command[0].cstring, argv)
    stderr.writeLine "Failed to execute " & o.command[0] & ": " & $strerror(errno)
    exitnow(127)
  discard close(fds[1])
  let ok = feed(fds[0], sysrun, o)
  discard close(fds[0])
  var status: cint
  while waitpid(pid, status, 0) < 0:
    if errno != EINTR: return 1
  if not ok: return 1
  if WIFEXITED(status): return int(WEXITSTATUS(status))
  if WIFSIGNALED(status): return 128 + int(WTERMSIG(status))
  1

proc catMain*(args: seq[string]): int =
  var o = CatOpts(identifier: "cat", priority: 6)
  var err = ""
  if not parseCatArgs(args, o, err):
    stderr.writeLine err
    return 1
  if o.help:
    echo CatUsage
    return 0
  let sysrun = systemRoots().sysrun
  let unreachable = unreachableReason(sysrun)
  if unreachable.len > 0:
    stderr.writeLine unreachable
    return 1
  if o.command.len == 0:
    return (if feed(0, sysrun, o): 0 else: 1)
  execute(o, sysrun)

# ---- systemd-detect-virt ---------------------------------------------------

const
  ContainerIds = ["docker", "podman", "lxc", "lxc-libvirt", "systemd-nspawn", "openvz",
    "rkt", "wsl", "proot", "pouch"]
  DmiVendors = [("KubeVirt", "kvm"), ("oVirt", "kvm"), ("QEMU", "kvm"), ("Amazon EC2", "amazon"),
    ("VMware, Inc.", "vmware"), ("innotek GmbH", "oracle"), ("Xen", "xen"), ("Bochs", "bochs"),
    ("Parallels", "parallels"), ("Microsoft Corporation", "microsoft"), ("Google", "google"),
    ("Apple Inc.", "apple")]
  DmiProducts = [("VirtualBox", "oracle"), ("Virtual Machine", "microsoft"), ("KVM", "kvm"),
    ("Bochs", "bochs"), ("Parallels Virtual Platform", "parallels"),
    ("VMware Virtual Platform", "vmware"), ("Google Compute Engine", "google"),
    ("OpenStack", "kvm"), ("BHYVE", "bhyve"), ("Hyper-V", "microsoft"),
    ("QEMU Virtual Machine", "kvm")]
  DmiBios = [("innotek GmbH", "oracle"), ("Xen", "xen"), ("Amazon EC2", "amazon")]

type
  Probe* = object
    ## What the filesystem showed; the detection rules below are pure.
    containerEnv*: string        ## `container=` in /proc/1/environ
    systemdContainer*: string    ## /run/systemd/container
    dockerenv*: bool             ## /.dockerenv exists
    procVz*, procBc*: bool       ## /proc/vz, /proc/bc (openvz host has both)
    uidMapPrivate*: bool         ## /proc/self/uid_map is not the identity
    hypervisorType*: string      ## /sys/hypervisor/type
    sysVendor*, productName*, biosVendor*: string
    hypervisorFlag*: bool        ## /proc/cpuinfo has the `hypervisor` flag
    chroot*: bool                ## /proc/1/root is not /

proc fromTable(value: string; table: openArray[(string, string)]): string =
  ## The identifier of the first table row whose key prefixes `value`.
  for (key, id) in table:
    if value.startsWith(key): return id
  ""

proc containerId*(p: Probe): string =
  ## The container manager, "" when this is not a container.
  if p.dockerenv: return "docker"
  for name in [p.systemdContainer, p.containerEnv]:
    if name.len == 0: continue
    let id = name.toLowerAscii
    return (if id in ContainerIds: id else: "container-other")
  if p.procVz and not p.procBc: return "openvz"
  if p.uidMapPrivate: return "container-other"
  ""

proc vmId*(p: Probe): string =
  ## The hypervisor, "" when this is not a virtual machine.
  if p.hypervisorType == "xen": return "xen"
  result = fromTable(p.sysVendor, DmiVendors)
  if result.len > 0: return
  result = fromTable(p.productName, DmiProducts)
  if result.len > 0: return
  result = fromTable(p.biosVendor, DmiBios)
  if result.len > 0: return
  if p.hypervisorFlag: result = "kvm"

proc detectVirt*(p: Probe): string =
  ## The identifier `systemd-detect-virt` prints: a container beats a virtual
  ## machine, `chroot` only when neither matched.
  result = p.containerId
  if result.len == 0: result = p.vmId
  if result.len == 0 and p.chroot: result = "chroot"
  if result.len == 0: result = "none"

proc uidMapIsPrivate*(text: string): bool =
  ## True when `/proc/self/uid_map` shows more than the identity mapping.
  for line in text.splitLines:
    let f = line.splitWhitespace
    if f.len < 3: continue
    if f[0] != f[1] or f[2] != "4294967295": return true
  false

proc cpuInfoHasHypervisor*(text: string): bool =
  for line in text.splitLines:
    if not (line.startsWith("flags") or line.startsWith("Features")): continue
    for word in line.splitWhitespace:
      if word == "hypervisor": return true
  false

proc readText(path: string): string =
  try: readFile(path) except IOError: ""

proc readOneLine(path: string): string =
  let text = readText(path)
  let nl = text.find('\n')
  (if nl >= 0: text[0 ..< nl] else: text).strip

proc containerEnvVar(procfs: string): string =
  for entry in readText(procfs / "1/environ").split('\0'):
    if entry.startsWith("container="): return entry[10 .. ^1]
  ""

proc inChroot(procfs: string): bool =
  ## `/proc/1/root` and `/` are different directories.
  var a, b: Stat
  if stat((procfs / "1/root").cstring, a) != 0: return false
  if stat("/".cstring, b) != 0: return false
  a.st_dev != b.st_dev or a.st_ino != b.st_ino

proc gatherProbe*(roots: Roots): Probe =
  ## Reads the container, hypervisor and DMI markers of this machine.
  Probe(containerEnv: containerEnvVar(roots.procfs),
    systemdContainer: readOneLine(roots.run / "systemd/container"),
    dockerenv: fileExists("/.dockerenv"),
    procVz: fileExists(roots.procfs / "vz"), procBc: fileExists(roots.procfs / "bc"),
    uidMapPrivate: uidMapIsPrivate(readText(roots.procfs / "self/uid_map")),
    hypervisorType: readOneLine(roots.sysfs / "hypervisor/type"),
    sysVendor: readOneLine(roots.sysfs / "class/dmi/id/sys_vendor"),
    productName: readOneLine(roots.sysfs / "class/dmi/id/product_name"),
    biosVendor: readOneLine(roots.sysfs / "class/dmi/id/bios_vendor"),
    hypervisorFlag: cpuInfoHasHypervisor(readText(roots.procfs / "cpuinfo")),
    chroot: inChroot(roots.procfs))

proc detectVirtMain*(args: seq[string]): int =
  var kind = ""
  var quiet, privateUsers = false
  for a in args:
    case a
    of "--vm": kind = "vm"
    of "--container": kind = "container"
    of "--chroot": kind = "chroot"
    of "-q", "--quiet": quiet = true
    of "-r", "--private-users": privateUsers = true
    of "-h", "--help":
      echo "systemd-detect-virt [--vm|--container|--chroot] [-q] [-r]"
      return 0
    else:
      stderr.writeLine (if a.startsWith("-") and a.len > 1: "Unknown option " & a
                        else: "Too many arguments.")
      return 1
  let p = gatherProbe(systemRoots())
  var id: string
  if privateUsers:
    id = if p.uidMapPrivate: (if p.containerId.len > 0: p.containerId else: "container-other")
         else: "none"
  elif kind == "vm": id = p.vmId
  elif kind == "container": id = p.containerId
  elif kind == "chroot": id = (if p.chroot: "chroot" else: "")
  else: id = detectVirt(p)
  if id.len == 0: id = "none"
  if not quiet: echo id
  if id == "none": 1 else: 0

# ---- systemd-id128 ---------------------------------------------------------

const Id128Usage = "systemd-id128 [OPTIONS...] COMMAND\n\n" &
  "  new            generate a new 128-bit ID\n" &
  "  machine-id     show the machine ID\n" &
  "  boot-id        show the boot ID\n" &
  "  invocation-id  show $INVOCATION_ID\n\n" &
  "  -p --pretty    print the ID as 8-4-4-4-12\n" &
  "  -u --uuid      print the ID in the UUID notation\n"

proc normalizeId*(s: string): string =
  ## 32 lowercase hex digits, or "" when `s` is not a 128-bit ID.
  for c in s:
    if c == '-' or c in Whitespace: continue
    if c in {'0' .. '9'}: result.add c
    elif c in {'a' .. 'f'}: result.add c
    elif c in {'A' .. 'F'}: result.add c.toLowerAscii
    else: return ""
  if result.len != 32: result = ""

proc pretty*(id: string): string =
  ## 8-4-4-4-12, lowercase; `id` comes from `normalizeId`.
  if id.len != 32: return ""
  id[0 .. 7] & "-" & id[8 .. 11] & "-" & id[12 .. 15] & "-" & id[16 .. 19] & "-" & id[20 .. 31]

proc uuid*(s: string): string =
  ## The same 16 bytes in the canonical UUID notation; "" when `s` is not an ID.
  let id = normalizeId(s)
  if id.len == 0: "" else: pretty(id)

proc newId*(): string =
  ## A fresh random 128-bit ID, 32 lowercase hex digits.
  let rng = newRng()
  for c in rng.bytes(16): result.add toHex(ord(c), 2).toLowerAscii

proc id128Main*(args: seq[string]): int =
  var sub = ""
  var asPretty, asUuid = false
  for a in args:
    case a
    of "-p", "--pretty": asPretty = true
    of "-u", "--uuid": asUuid = true
    of "-h", "--help":
      echo Id128Usage
      return 0
    else:
      if a.startsWith("-") and a.len > 1:
        stderr.writeLine "Unknown option " & a
        return 1
      if sub.len > 0:
        stderr.writeLine "Too many arguments."
        return 1
      sub = a
  var id = ""
  case sub
  of "new": id = newId()
  of "machine-id":
    id = normalizeId(readOneLine(systemRoots().machineId))
    if id.len == 0:
      stderr.writeLine "Failed to read /etc/machine-id."
      return 1
  of "boot-id":
    id = normalizeId(readOneLine(systemRoots().procfs / "sys/kernel/random/boot_id"))
    if id.len == 0:
      stderr.writeLine "Failed to read /proc/sys/kernel/random/boot_id."
      return 1
  of "invocation-id":
    let env = getEnv("INVOCATION_ID")
    if env.len == 0:
      stderr.writeLine "$INVOCATION_ID is not set."
      return 1
    id = normalizeId(env)
    if id.len == 0:
      stderr.writeLine "INVOCATION_ID is not a valid 128-bit ID."
      return 1
  of "":
    stderr.writeLine "Command required."
    return 1
  else:
    stderr.writeLine "Unknown command " & sub
    return 1
  if asUuid: echo uuid(id) elif asPretty: echo pretty(id) else: echo id
  0

# ---- systemd-inhibit -------------------------------------------------------

const
  InhibitUsage = "systemd-inhibit [OPTIONS...] COMMAND...\n\n" &
    "  --what=WHAT  --who=WHO  --why=WHY  --mode=MODE (ignored)\n" &
    "  --list       print nothing\n"
  InhibitWarning* = "Warning: inhibitors are not supported by the systemd core; " &
    "running the command without a lock."

type
  InhibitOpts* = object
    what*, who*, why*, mode*: string
    list*, help*: bool
    command*: seq[string]

proc parseInhibitArgs*(args: seq[string]; o: var InhibitOpts; err: var string): bool =
  ## `--what=`, `--who=`, `--why=` and `--mode=` are accepted and recorded but
  ## have no effect; the first non-option word starts COMMAND.
  var i = 0
  while i < args.len:
    let a = args[i]
    if a == "--":
      o.command = args[i + 1 .. ^1]
      return true
    if a.len > 1 and a[0] == '-' and a != "-":
      let (name, inline) = splitOption(a)
      case name
      of "list": o.list = true
      of "help", "h": o.help = true
      of "what": o.what = optValue(args, i, inline)
      of "who": o.who = optValue(args, i, inline)
      of "why": o.why = optValue(args, i, inline)
      of "mode":
        o.mode = optValue(args, i, inline)
        if o.mode notin ["block", "delay", "block-weak"]:
          err = "Invalid inhibition mode: " & o.mode
          return false
      of "no-pager", "no-ask-password", "quiet", "no-wall":
        discard
      else:
        err = "Unknown option: " & a
        return false
    else:
      o.command = args[i .. ^1]
      return true
    inc i
  true

proc inhibitMain*(args: seq[string]): int =
  var o = InhibitOpts(mode: "block")
  var err = ""
  if not parseInhibitArgs(args, o, err):
    stderr.writeLine err
    return 1
  if o.help:
    echo InhibitUsage
    return 0
  if o.list: return 0
  if o.command.len == 0:
    stderr.writeLine "No command specified."
    return 1
  stderr.writeLine InhibitWarning
  let argv = allocCStringArray(o.command)
  discard execvp(o.command[0].cstring, argv)
  stderr.writeLine "Failed to execute " & o.command[0] & ": " & $strerror(errno)
  127
