## Small front-ends: `systemd-notify`, `systemd-escape` (spec §15.6), and the
## `poweroff`/`reboot`/`halt` wrappers.
import std/[json, os, strutils, options, posix]
import ../common/[names, fdutil, jsonio]
import ../ipc/client
import ./[systemctl, frontcommon]
import std/monotimes

proc monoMicros(): int64 = getMonoTime().ticks div 1000

proc notifyMain*(args: seq[string]): int =
  var msg: seq[string]
  var booted = false
  for a in args:
    if a == "--ready": msg.add "READY=1"
    elif a == "--reloading": msg.add "RELOADING=1\nMONOTONIC_USEC=" & $(int64(monoMicros()))
    elif a == "--stopping": msg.add "STOPPING=1"
    elif a == "--booted": booted = true
    elif a.startsWith("--status="): msg.add "STATUS=" & a[9 .. ^1]
    elif a.startsWith("--pid"):
      let v = if '=' in a: a.split('=')[1] else: $getppid()
      msg.add "MAINPID=" & (if v.len > 0: v else: $getppid())
    elif a in ["--no-block", "--quiet"] or a.startsWith("--uid=") or a.startsWith("--exec"): discard
    elif a.startsWith("--"):
      stderr.writeLine "Unknown option " & a
      return 1
    else: msg.add a
  if booted: return (if dirExists("/run/systemd/system"): 0 else: 1)
  if msg.len == 0:
    stderr.writeLine "No command specified."
    return 1
  let sock = getEnv("NOTIFY_SOCKET")
  if sock.len == 0:
    stderr.writeLine "$NOTIFY_SOCKET is not set."
    return 1
  let fd = newUnixSocket(false)
  var a: Sockaddr_un
  a.sun_family = TSa_Family(AF_UNIX)
  let path = if sock[0] == '@': "\0" & sock[1 .. ^1] else: sock
  if path.len >= a.sun_path.len: return 1
  copyMem(addr a.sun_path[0], path.cstring, path.len)
  let body = msg.join("\n")
  let n = sendto(SocketHandle(fd), body.cstring, body.len, 0,
    cast[ptr SockAddr](addr a), SockLen(offsetOf(Sockaddr_un, sun_path) + path.len))
  discard close(fd)
  if n < 0:
    stderr.writeLine "Failed to notify init system: " & $strerror(errno)
    return 1
  0

proc escapeMain*(args: seq[string]): int =
  var path, unesc, mangleIt = false
  var templ, instance, suffix = ""
  var items: seq[string]
  for a in args:
    case a
    of "-p", "--path": path = true
    of "-u", "--unescape": unesc = true
    of "-m", "--mangle": mangleIt = true
    else:
      if a.startsWith("--template="): templ = a[11 .. ^1]
      elif a.startsWith("--suffix="): suffix = a[9 .. ^1]
      elif a == "--instance": instance = "1"
      elif a.startsWith("-"):
        stderr.writeLine "Unknown option " & a
        return 1
      else: items.add a
  if items.len == 0:
    stderr.writeLine "Not enough arguments."
    return 1
  var outs: seq[string]
  for i in items:
    if mangleIt: outs.add mangle(i)
    elif unesc:
      let r = if path: unescapePath(i) else: names.unescape(i)
      if r.isNone:
        stderr.writeLine "Failed to unescape string: " & i
        return 1
      outs.add r.get
    else:
      var e = if path: escapePath(i) else: names.escape(i)
      if templ.len > 0:
        let p = parseUnitName(templ)
        e = if p.isSome and p.get.isTemplate: instantiate(templ, e) else: templ
      if suffix.len > 0: e &= "." & suffix
      outs.add e
  echo outs.join(" ")
  0

proc xdgAutostartConditionMain*(args: seq[string]): int =
  ## `systemd-xdg-autostart-condition ONLY-SHOW-IN NOT-SHOW-IN`: the
  ## `ExecCondition=` of the units generators/xdgautostart.nim writes. Exit 0
  ## when the entry applies to this desktop, 1 when it does not; the two
  ## arguments are the entry's `OnlyShowIn=` and `NotShowIn=` lists joined with
  ## `:` and may start with a dash, so `--` ends the options.
  var positional: seq[string]
  var optionsDone = false
  for a in args:
    if not optionsDone and a == "--":
      optionsDone = true
    elif not optionsDone and a.startsWith("-") and a.len > 1:
      stderr.writeLine "Unknown option " & a
      return 1
    else:
      positional.add a
  if positional.len != 2:
    stderr.writeLine "Expected two arguments: ONLY-SHOW-IN NOT-SHOW-IN"
    return 1
  proc split(s: string): seq[string] =
    for x in s.split(':'):
      if x.len > 0: result.add x
  let onlyShowIn = split(positional[0])
  let notShowIn = split(positional[1])
  let desktops = split(getEnv("XDG_CURRENT_DESKTOP"))
  for d in desktops:
    if d in onlyShowIn: return 0
    if d in notShowIn: return 1
  if onlyShowIn.len > 0: return 1
  0

proc shutdownMain*(args: seq[string]): int =
  ## `shutdown` (spec §15.6): only `now` and `+0` act; other times are refused.
  var action = "poweroff"
  var cancel = false
  var at = ""
  for a in args:
    case a
    of "-r", "--reboot": action = "reboot"
    of "-H", "--halt": action = "halt"
    of "-h", "-P", "--poweroff": action = "poweroff"
    of "-c", "--cancel": cancel = true
    of "--help":
      echo "shutdown [OPTIONS...] [TIME] [MESSAGE]"
      return 0
    else:
      if a.startsWith("-"):
        stderr.writeLine "Unknown option " & a
        return 1
      if at.len == 0: at = a
  if cancel: return 0
  if at.len > 0 and at notin ["now", "+0"]:
    stderr.writeLine "Scheduled shutdown is not supported by the systemd core."
    return 1
  systemctlMain(@[action])

proc initMain*(verb: string; args: seq[string]): int =
  ## `telinit N` and `init N` (spec §15.6): runlevels map to isolated targets.
  if args.len == 0:
    stderr.writeLine "Too few arguments."
    return 1
  case args[0]
  of "0": systemctlMain(@["poweroff"])
  of "6": systemctlMain(@["reboot"])
  of "1", "s", "S": systemctlMain(@["isolate", "rescue.target"])
  of "2", "3", "4": systemctlMain(@["isolate", "multi-user.target"])
  of "5": systemctlMain(@["isolate", "graphical.target"])
  else:
    stderr.writeLine "Unknown runlevel " & args[0] & "."
    1

proc runlevelMain*(args: seq[string]): int =
  ## `runlevel` (spec §15.6): the active target as `N <level>`.
  let c = connectOrDie(false, false)
  let r = c.request("unit-show", %*{"names": ["graphical.target", "multi-user.target",
    "rescue.target", "emergency.target"], "properties": ["ActiveState"]})
  if not r.ok:
    stderr.writeLine r.message
    return 1
  var active: seq[string]
  for u in r.result["units"]:
    if u["properties"]["ActiveState"].strVal in ["active", "reloading"]: active.add u["name"].strVal
  let level = if "graphical.target" in active: "5"
    elif "multi-user.target" in active: "3"
    elif "rescue.target" in active or "emergency.target" in active: "S"
    else: "unknown"
  echo "N " & level
  0

proc powerMain*(verb: string; args: seq[string]): int =
  ## `poweroff`, `reboot`, `halt` accept and ignore -f, --no-wall, -w, -p and friends.
  var rest: seq[string]
  for a in args:
    if a.startsWith("-"): continue
    rest.add a
  systemctlMain(@[verb])
