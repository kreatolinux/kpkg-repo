## Small front-ends: `systemd-notify`, `systemd-escape` (spec §15.6), and the
## `poweroff`/`reboot`/`halt` wrappers.
import std/[os, strutils, options, posix]
import ../common/[names, fdutil]
import ./systemctl
import std/monotimes

proc monoMicros(): int64 = getMonoTime().ticks div 1000

proc notifyMain*(args: seq[string]): int =
  var msg: seq[string]
  var booted = false
  for a in args:
    if a == "--ready": msg.add "READY=1"
    elif a == "--reloading": msg.add "RELOADING=1\nMONOTONIC_USEC=" & $(int64(monoMicros()))
    elif a == "--stopping": msg.add "STOPPING=1"
    elif a == "--booted": booted = true
    elif a.startsWith("--status="): msg.add "STATUS=" & a[9 .. ^1]
    elif a.startsWith("--pid"):
      let v = if '=' in a: a.split('=')[1] else: $getppid()
      msg.add "MAINPID=" & (if v.len > 0: v else: $getppid())
    elif a in ["--no-block", "--quiet"] or a.startsWith("--uid=") or a.startsWith("--exec"): discard
    elif a.startsWith("--"):
      stderr.writeLine "Unknown option " & a
      return 1
    else: msg.add a
  if booted: return (if dirExists("/run/systemd/system"): 0 else: 1)
  if msg.len == 0:
    stderr.writeLine "No command specified."
    return 1
  let sock = getEnv("NOTIFY_SOCKET")
  if sock.len == 0:
    stderr.writeLine "$NOTIFY_SOCKET is not set."
    return 1
  let fd = newUnixSocket(false)
  var a: Sockaddr_un
  a.sun_family = TSa_Family(AF_UNIX)
  let path = if sock[0] == '@': "\0" & sock[1 .. ^1] else: sock
  if path.len >= a.sun_path.len: return 1
  copyMem(addr a.sun_path[0], path.cstring, path.len)
  let body = msg.join("\n")
  let n = sendto(SocketHandle(fd), body.cstring, body.len, 0,
    cast[ptr SockAddr](addr a), SockLen(offsetOf(Sockaddr_un, sun_path) + path.len))
  discard close(fd)
  if n < 0:
    stderr.writeLine "Failed to notify init system: " & $strerror(errno)
    return 1
  0

proc escapeMain*(args: seq[string]): int =
  var path, unesc, mangleIt = false
  var templ, instance, suffix = ""
  var items: seq[string]
  for a in args:
    case a
    of "-p", "--path": path = true
    of "-u", "--unescape": unesc = true
    of "-m", "--mangle": mangleIt = true
    else:
      if a.startsWith("--template="): templ = a[11 .. ^1]
      elif a.startsWith("--suffix="): suffix = a[9 .. ^1]
      elif a == "--instance": instance = "1"
      elif a.startsWith("-"):
        stderr.writeLine "Unknown option " & a
        return 1
      else: items.add a
  if items.len == 0:
    stderr.writeLine "Not enough arguments."
    return 1
  var outs: seq[string]
  for i in items:
    if mangleIt: outs.add mangle(i)
    elif unesc:
      let r = if path: unescapePath(i) else: names.unescape(i)
      if r.isNone:
        stderr.writeLine "Failed to unescape string: " & i
        return 1
      outs.add r.get
    else:
      var e = if path: escapePath(i) else: names.escape(i)
      if templ.len > 0:
        let p = parseUnitName(templ)
        e = if p.isSome and p.get.isTemplate: instantiate(templ, e) else: templ
      if suffix.len > 0: e &= "." & suffix
      outs.add e
  echo outs.join(" ")
  0

proc xdgAutostartConditionMain*(args: seq[string]): int =
  ## `systemd-xdg-autostart-condition ONLY-SHOW-IN NOT-SHOW-IN`: the
  ## `ExecCondition=` of the units generators/xdgautostart.nim writes. Exit 0
  ## when the entry applies to this desktop, 1 when it does not; the two
  ## arguments are the entry's `OnlyShowIn=` and `NotShowIn=` lists joined with
  ## `:` and may start with a dash, so `--` ends the options.
  var positional: seq[string]
  var optionsDone = false
  for a in args:
    if not optionsDone and a == "--":
      optionsDone = true
    elif not optionsDone and a.startsWith("-") and a.len > 1:
      stderr.writeLine "Unknown option " & a
      return 1
    else:
      positional.add a
  if positional.len != 2:
    stderr.writeLine "Expected two arguments: ONLY-SHOW-IN NOT-SHOW-IN"
    return 1
  proc split(s: string): seq[string] =
    for x in s.split(':'):
      if x.len > 0: result.add x
  let onlyShowIn = split(positional[0])
  let notShowIn = split(positional[1])
  let desktops = split(getEnv("XDG_CURRENT_DESKTOP"))
  for d in desktops:
    if d in onlyShowIn: return 0
    if d in notShowIn: return 1
  if onlyShowIn.len > 0: return 1
  0

proc powerMain*(verb: string; args: seq[string]): int =
  ## `poweroff`, `reboot`, `halt` accept and ignore -f, --no-wall, -w, -p and friends.
  var rest: seq[string]
  for a in args:
    if a.startsWith("-"): continue
    rest.add a
  systemctlMain(@[verb])
