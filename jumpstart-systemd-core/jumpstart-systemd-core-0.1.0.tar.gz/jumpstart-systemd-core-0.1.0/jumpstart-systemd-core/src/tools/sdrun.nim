## `systemd-run` (spec §15.6): transient service and timer units through the
## `transient-start` verb. `--scope` has no scope units behind it: the command
## is executed in place with a warning.
import std/json except getStr, getInt, getBool
import std/[os, strutils, posix, random, options]
import ../common/[names, jsonio]
import ../ipc/client
import ../engine/setprop
import ../unitfile/model
import ./frontcommon

type RunOpts* = object
  user*, system*, scope*, wait*, pty*, pipe*, collect*, noBlock*, quiet*, sameDir*, remain*, sighup*: bool
  unit*, description*, serviceType*, uid*, gid*, workdir*, slice*, nice*: string
  props*, timerProps*, env*: seq[string]
  onTimers*: seq[(string, string)]       ## key, value of the [Timer] section
  command*: seq[string]

proc quoteWord*(w: string): string =
  ## One argument of ExecStart= (systemd.syntax quoting).
  if w.len > 0 and w.allCharsInSet(Letters + Digits + {'_', '.', '/', '=', ',', ':', '@', '+', '-'}): return w
  result = "\""
  for ch in w:
    case ch
    of '"': result.add "\\\""
    of '\\': result.add "\\\\"
    of '%': result.add "%%"
    of '$': result.add "$$"
    of '\n': result.add "\\n"
    of '\t': result.add "\\t"
    else: result.add ch
  result.add "\""

proc execLine*(argv: seq[string]): string =
  for i, a in argv:
    if i > 0: result.add ' '
    result.add (if a == ";": "\\;" else: quoteWord(a))

proc buildUnits*(o: RunOpts; base: string; ttyPath = ""; pipeIo = false; clientPid = 0): seq[(string, string)] =
  ## (name, text) of the service and, with timer options, of the timer.
  let desc = if o.description.len > 0: o.description else: o.command.join(" ")
  var unitSec = "[Unit]\nDescription=" & desc.replace("\n", " ") & "\n"
  var svcSec = "[Service]\n"
  var timerSec = "[Timer]\n"
  var extraUnit, extraSvc: string
  for p in o.props:
    let (k, v) = splitAssignment(p)
    if not validKey(k): raise newException(ValueError, "Invalid property assignment: " & p)
    case sectionFor(k, ukService)
    of "Unit": extraUnit.add k & "=" & v & "\n"
    else: extraSvc.add k & "=" & v & "\n"
  if o.collect: unitSec.add "CollectMode=inactive-or-failed\n"
  unitSec.add extraUnit
  if o.serviceType.len > 0: svcSec.add "Type=" & o.serviceType & "\n"
  if o.remain: svcSec.add "RemainAfterExit=yes\n"
  if o.sighup: svcSec.add "SendSIGHUP=yes\n"
  if o.uid.len > 0: svcSec.add "User=" & o.uid & "\n"
  if o.gid.len > 0: svcSec.add "Group=" & o.gid & "\n"
  if o.workdir.len > 0: svcSec.add "WorkingDirectory=" & o.workdir & "\n"
  if o.slice.len > 0: svcSec.add "Slice=" & o.slice & "\n"
  if o.nice.len > 0: svcSec.add "Nice=" & o.nice & "\n"
  for e in o.env: svcSec.add "Environment=" & quoteWord(e) & "\n"
  if ttyPath.len > 0:
    svcSec.add "StandardInput=tty\nStandardOutput=tty\nStandardError=tty\nTTYPath=" & ttyPath & "\n"
  elif pipeIo:
    let pre = "/proc/" & $clientPid & "/fd/"
    svcSec.add "StandardInput=file:" & pre & "0\nStandardOutput=append:" & pre & "1\n" &
      "StandardError=append:" & pre & "2\n"
  svcSec.add "ExecStart=" & execLine(o.command) & "\n"
  svcSec.add extraSvc
  result.add (base & ".service", unitSec & "\n" & svcSec)
  if o.onTimers.len > 0:
    var timerUnitSec = "[Unit]\nDescription=" & desc.replace("\n", " ") & "\n"
    for (k, v) in o.onTimers: timerSec.add k & "=" & v & "\n"
    timerSec.add "RemainAfterElapse=no\n"
    for p in o.timerProps:
      let (k, v) = splitAssignment(p)
      if not validKey(k): raise newException(ValueError, "Invalid property assignment: " & p)
      if sectionFor(k, ukTimer) == "Unit": timerUnitSec.add k & "=" & v & "\n"
      else: timerSec.add k & "=" & v & "\n"
    result.add (base & ".timer", timerUnitSec & "\n" & timerSec)

proc parseArgs(args: seq[string]; o: var RunOpts): int =
  ## Returns -1 to continue, or an exit code.
  var i = 0
  proc val(name, inl: string): string =
    if inl.len > 0: return inl
    inc i
    if i < args.len: args[i] else: ""
  while i < args.len:
    let a = args[i]
    if a == "--":
      o.command = args[i + 1 .. ^1]
      return -1
    if a.startsWith("--"):
      var name = a[2 .. ^1]
      var v = ""
      let eq = name.find('=')
      if eq >= 0:
        v = name[eq + 1 .. ^1]
        name = name[0 ..< eq]
      case name
      of "user": o.user = true
      of "system": o.system = true
      of "scope": o.scope = true
      of "wait": o.wait = true
      of "pty": o.pty = true
      of "pipe": o.pipe = true
      of "collect": o.collect = true
      of "no-block": o.noBlock = true
      of "quiet": o.quiet = true
      of "same-dir": o.sameDir = true
      of "remain-after-exit": o.remain = true
      of "send-sighup": o.sighup = true
      of "no-ask-password", "no-pager", "ignore-failure": discard
      of "unit": o.unit = val(name, v)
      of "description": o.description = val(name, v)
      of "service-type": o.serviceType = val(name, v)
      of "uid": o.uid = val(name, v)
      of "gid": o.gid = val(name, v)
      of "working-directory": o.workdir = val(name, v)
      of "slice": o.slice = val(name, v)
      of "nice": o.nice = val(name, v)
      of "property": o.props.add val(name, v)
      of "timer-property": o.timerProps.add val(name, v)
      of "setenv": o.env.add val(name, v)
      of "on-active": o.onTimers.add ("OnActiveSec", val(name, v))
      of "on-boot": o.onTimers.add ("OnBootSec", val(name, v))
      of "on-startup": o.onTimers.add ("OnStartupSec", val(name, v))
      of "on-unit-active": o.onTimers.add ("OnUnitActiveSec", val(name, v))
      of "on-unit-inactive": o.onTimers.add ("OnUnitInactiveSec", val(name, v))
      of "on-calendar": o.onTimers.add ("OnCalendar", val(name, v))
      of "machine", "host", "shell", "path-property", "socket-property":
        stderr.writeLine "Option --" & name & " is not supported by the systemd core."
        return 1
      of "help":
        echo "systemd-run [OPTIONS...] COMMAND [ARGS...]\n\nRun the specified command in a transient service or scope unit."
        return 0
      of "version":
        echo "systemd 255 (255.0-jumpstart-core)"
        return 0
      else:
        stderr.writeLine "Unknown option: --" & name
        return 1
    elif a.len > 1 and a[0] == '-':
      let ch = a[1]
      let inl = a[2 .. ^1]
      case ch
      of 'q': o.quiet = true
      of 't': o.pty = true
      of 'P': o.pipe = true
      of 'd': o.sameDir = true
      of 'G': o.collect = true
      of 'H', 'M', 'S':
        stderr.writeLine "Option -" & ch & " is not supported by the systemd core."
        return 1
      of 'p': o.props.add val("property", inl)
      of 'u': o.unit = val("unit", inl)
      of 'E': o.env.add val("setenv", inl)
      of 'h':
        echo "systemd-run [OPTIONS...] COMMAND [ARGS...]"
        return 0
      else:
        stderr.writeLine "Unknown option: -" & ch
        return 1
    else:
      o.command = args[i .. ^1]
      return -1
    inc i
  -1

proc runMain*(args: seq[string]): int =
  var o: RunOpts
  let rc = parseArgs(args, o)
  if rc >= 0: return rc
  if o.command.len == 0:
    stderr.writeLine "Command line to execute required."
    return 1
  if o.scope:
    stderr.writeLine "Warning: scope units are not supported by the systemd core; running the command directly."
    var argv = allocCStringArray(o.command)
    discard execvp(o.command[0].cstring, argv)
    stderr.writeLine "Failed to execute " & o.command[0] & ": " & $strerror(errno)
    return 127
  if o.sameDir and o.workdir.len == 0: o.workdir = getCurrentDir()
  # resolve the executable to an absolute path
  var exe = o.command[0]
  if '/' notin exe:
    let found = findExe(exe)
    if found.len == 0:
      stderr.writeLine "Failed to find executable " & exe & "."
      return 1
    exe = found
  elif not exe.isAbsolute: exe = absolutePath(exe)
  o.command[0] = exe
  if o.wait and o.onTimers.len > 0:
    stderr.writeLine "--wait may not be combined with timer options."
    return 1
  var ttyPath = ""
  var pipeIo = false
  if o.pty:
    if isatty(0) != 0 and ttyname(0) != nil:
      ttyPath = $ttyname(0)
      o.wait = true
    else:
      stderr.writeLine "Warning: standard input is not a terminal; --pty acts as --pipe."
      o.pipe = true
  if o.pipe:
    pipeIo = true
    o.wait = true
  var base: string
  if o.unit.len > 0:
    base = o.unit
    for suf in [".service", ".timer"]:
      if base.endsWith(suf): base = base[0 ..< base.len - suf.len]
    if parseUnitName(base & ".service").isNone:
      stderr.writeLine "Invalid unit name '" & o.unit & "'."
      return 1
  else:
    randomize()
    base = "run-r" & toHex(rand(0xFFFFFFFF), 8).toLowerAscii
  var units: seq[(string, string)]
  try: units = buildUnits(o, base, ttyPath, pipeIo, int(getpid()))
  except ValueError as e:
    stderr.writeLine e.msg
    return 1
  let c = connectOrDie(o.user, o.system)
  var ja = newJArray()
  for (n, t) in units: ja.add %*{"name": n, "text": t}
  let main = units[^1][0]
  let isTimer = main.endsWith(".timer")
  let r = try: c.request("transient-start", %*{"units": ja, "start": main, "collect": o.collect,
      "wait": not o.noBlock, "wait_exit": o.wait})
    except IOError as e:
      stderr.writeLine "Failed to talk to the manager: " & e.msg
      return 1
  if not r.ok:
    stderr.writeLine "Failed to start transient " & (if isTimer: "timer" else: "service") & " unit: " & r.message
    return 1
  if not o.quiet:
    if isTimer:
      stderr.writeLine "Running timer as unit: " & main & "\nWill run service as unit: " & units[0][0]
    else: stderr.writeLine "Running as unit: " & main
  if o.wait:
    let j = r.result
    let res = j.getStr("result")
    if not o.quiet:
      stderr.writeLine "Finished with result: " & res
      if j.getInt("exec_code") == 1: stderr.writeLine "Main processes terminated with: code=exited/status=" & $j.getInt("exec_status")
      elif j.getInt("exec_code") > 1: stderr.writeLine "Main processes terminated with: code=killed/status=" & $j.getInt("exec_status")
      if j.getInt("runtime_usec") > 0: stderr.writeLine "Service runtime: " & roughTimespan(j["runtime_usec"].getBiggestInt)
    if res == "success": return 0
    return max(1, j.getInt("exec_status"))
  0
