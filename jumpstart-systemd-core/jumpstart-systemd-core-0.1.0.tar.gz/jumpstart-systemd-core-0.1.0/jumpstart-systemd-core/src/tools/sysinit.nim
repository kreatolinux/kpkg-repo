## `systemd-sysctl`, `systemd-modules-load`, `systemd-fsck` and
## `systemd-remount-fs`: the system-initialisation front-ends. Each one is a
## thin apply loop around the parsers below; the parsers are pure so they run
## without /proc, /etc or root.
import std/[os, strutils, algorithm, sequtils, options, posix]

proc cExit(code: cint) {.importc: "_exit", header: "<unistd.h>", noreturn.}

proc runArgv*(argv: seq[string]): int =
  ## Runs `argv` through PATH and returns its exit status; -1 when it could not
  ## be started or was killed by a signal.
  if argv.len == 0: return -1
  let cargv = allocCStringArray(argv)
  let pid = fork()
  if pid < 0:
    deallocCStringArray(cargv)
    return -1
  if pid == 0:
    discard execvp(argv[0].cstring, cargv)
    cExit(127)
  deallocCStringArray(cargv)
  var status: cint
  while waitpid(pid, status, 0) < 0:
    if errno != EINTR: return -1
  if WIFEXITED(status): int(WEXITSTATUS(status)) else: -1

# ---- configuration discovery ---------------------------------------------------

const
  SysctlDirNames = ["/etc/sysctl.d", "/run/sysctl.d", "/usr/local/lib/sysctl.d", "/usr/lib/sysctl.d",
                    "/lib/sysctl.d"]
  ModuleDirNames = ["/etc/modules-load.d", "/run/modules-load.d", "/usr/local/lib/modules-load.d",
                    "/usr/lib/modules-load.d", "/lib/modules-load.d"]

proc mergedUsr*(): bool =
  ## `/lib` is a symlink to `/usr/lib`, so `/lib/*.d` is the same directory.
  symlinkExists("/lib") and (try: expandSymlink("/lib") == "/usr/lib" except OSError: false)

proc sysctlDirs*(mergedUsr: bool): seq[string] =
  ## Highest priority first; the `/lib` directory only exists unmerged.
  result = @(SysctlDirNames[0 .. 3])
  if not mergedUsr: result.add SysctlDirNames[4]

proc moduleDirs*(mergedUsr: bool): seq[string] =
  result = @(ModuleDirNames[0 .. 3])
  if not mergedUsr: result.add ModuleDirNames[4]

proc sysctlConfigPaths*(mergedUsr: bool): seq[string] =
  ## The `*.conf` directories and `/etc/sysctl.conf`, which is applied last.
  result = sysctlDirs(mergedUsr)
  result.add "/etc/sysctl.conf"

proc confDirNames(d: string): seq[string] =
  ## The `*.conf` names of one directory, masked files left out.
  if not dirExists(d): return
  try:
    for kind, p in walkDir(d):
      let n = p.extractFilename
      if not n.endsWith(".conf") or kind notin {pcFile, pcLinkToFile}: continue
      if symlinkExists(p) and (try: expandSymlink(p) == "/dev/null" except OSError: false): continue
      result.add n
  except OSError: discard

proc mergeConfFiles*(dirs: seq[string]; names: seq[seq[string]]): seq[string] =
  ## Full paths sorted by file name; a name present in several directories is
  ## taken from the first (highest priority) one.
  var picked: seq[tuple[name, path: string]]
  for i, d in dirs:
    if i >= names.len: break
    for n in names[i]:
      if picked.anyIt(it.name == n): continue
      picked.add (n, d / n)
  picked.sort(proc(a, b: tuple[name, path: string]): int = cmp(a.name, b.name))
  result = picked.mapIt(it.path)

proc discoverConfFiles(dirs: seq[string]): seq[string] =
  var names: seq[seq[string]]
  for d in dirs: names.add confDirNames(d)
  mergeConfFiles(dirs, names)

proc sysctlConfFiles*(): seq[string] = discoverConfFiles(sysctlDirs(mergedUsr()))

proc modulesConfFiles*(): seq[string] =
  ## The `modules-load.d` snippets, masked files left out.
  discoverConfFiles(moduleDirs(mergedUsr()))

# ---- systemd-sysctl ------------------------------------------------------------

type SysctlSetting* = tuple[key, value: string, ignoreErrors: bool]

proc parseSysctlConf*(text: string): seq[SysctlSetting] =
  ## `key = value` assignments in file order; a leading `-` makes a failed
  ## write non-fatal. A later assignment overrides an earlier one simply by
  ## being applied after it.
  for raw in text.splitLines:
    var line = raw.strip
    if line.len == 0 or line[0] in {'#', ';'}: continue
    var ignoreErrors = false
    if line[0] == '-':
      ignoreErrors = true
      line = line[1 .. ^1]
    let eq = line.find('=')
    if eq < 0: continue                      # not an assignment
    let key = line[0 ..< eq].strip
    if key.len == 0: continue
    result.add (key, line[eq + 1 .. ^1].strip, ignoreErrors)

proc hasGlob*(s: string): bool = '*' in s or '?' in s

proc matchGlob*(pattern, name: string): bool =
  ## Shell-style `*` and `?` matching, as allowed in sysctl keys.
  if pattern.len == 0: return name.len == 0
  case pattern[0]
  of '*':
    for i in 0 .. name.len:
      if matchGlob(pattern[1 .. ^1], name[i .. ^1]): return true
    false
  of '?': name.len > 0 and matchGlob(pattern[1 .. ^1], name[1 .. ^1])
  else: name.len > 0 and name[0] == pattern[0] and matchGlob(pattern[1 .. ^1], name[1 .. ^1])

proc sysctlPath*(key: string; prefix = ""): string =
  ## Where a key lives: `/proc/sys`, or `prefix`, plus the key with its dots
  ## turned into path separators.
  let base = if prefix.len == 0: "/proc/sys"
             else: prefix.strip(chars = {'/'}, leading = false, trailing = true)
  base / key.replace('.', '/')

proc expandGlob(path: string): seq[string] =
  ## Paths matching a pattern whose wildcards are whole path components.
  var cur = @[""]
  for comp in path.split('/'):
    if comp.len == 0: continue
    var next: seq[string]
    for base in cur:
      let dir = if base.len == 0: "/" else: base
      if hasGlob(comp):
        try:
          for kind, p in walkDir(dir, relative = true):
            if matchGlob(comp, p): next.add (if dir == "/": "/" & p else: dir / p)
        except OSError: discard
      else:
        next.add (if dir == "/": "/" & comp else: dir / comp)
    cur = next
  cur

proc writeSysctl(path, value: string): cint =
  ## 0 on success, else the errno of the failed write.
  let fd = open(path.cstring, O_WRONLY or O_CLOEXEC)
  if fd < 0: return errno
  defer: discard close(fd)
  if value.len > 0 and write(fd, unsafeAddr value[0], value.len) < 0: return errno
  0

proc applySysctlSetting(setting: SysctlSetting; prefix: string): int =
  ## 0, or 1 when a write failed and the line did not ask to ignore errors.
  let p = sysctlPath(setting.key, prefix)
  let targets = if hasGlob(setting.key): expandGlob(p) else: @[p]
  for t in targets:
    let e = writeSysctl(t, setting.value)
    if e == 0 or e == ENOENT: continue       # the kernel does not have this key
    let msg = "Couldn't write '" & setting.value & "' to '" & t & "'"
    if setting.ignoreErrors:
      stderr.writeLine msg & ", ignoring: " & $strerror(e)
    else:
      stderr.writeLine msg & ": " & $strerror(e)
      result = 1

proc applySysctl*(settings: seq[SysctlSetting]; prefix = ""): int =
  for s in settings:
    if applySysctlSetting(s, prefix) != 0: result = 1

proc sysctlMain*(args: seq[string]): int =
  var prefix = ""
  for a in args:
    if a.startsWith("--prefix="): prefix = a[9 .. ^1]
    elif a == "--system": discard
    elif a in ["-h", "--help"]:
      echo "systemd-sysctl [OPTIONS...]\n\nApply kernel variables."
      return 0
    elif a == "--version":
      echo "systemd 255 (255.0-jumpstart-core)"
      return 0
    else:
      stderr.writeLine "Unknown option " & a
      return 1
  var settings: seq[SysctlSetting]
  for f in sysctlConfFiles():
    try: settings.add parseSysctlConf(readFile(f))
    except IOError, OSError:
      stderr.writeLine "Failed to read " & f
      result = 1
  if applySysctl(settings, prefix) != 0: result = 1

# ---- systemd-modules-load ------------------------------------------------------

proc parseModulesConf*(text: string): seq[string] =
  ## One module name per line; `#`/`;` comments and blank lines are skipped.
  for raw in text.splitLines:
    let line = raw.strip
    if line.len == 0 or line[0] in {'#', ';'}: continue
    result.add line

proc modulesFromCmdline*(cmdline: string): seq[string] =
  ## Every `modules_load=` item, comma separated.
  for raw in cmdline.splitWhitespace:
    let w = if raw.startsWith("rd."): raw[3 .. ^1] else: raw
    if not w.startsWith("modules_load="): continue
    for m in w[13 .. ^1].split({',', ' ', '\t'}):
      let t = m.strip
      if t.len > 0: result.add t

proc dedupeModules*(names: seq[string]): seq[string] =
  ## First-seen order; `dm-crypt` and `dm_crypt` are the same module.
  var seen: seq[string]
  for n in names:
    let k = n.replace('-', '_')
    if k in seen: continue
    seen.add k
    result.add n

proc modulesLoadMain*(args: seq[string]): int =
  for a in args:
    if a in ["-h", "--help"]:
      echo "systemd-modules-load [CONFIGURATION FILE...]\n\nLoad statically configured kernel modules."
      return 0
    elif a == "--version":
      echo "systemd 255 (255.0-jumpstart-core)"
      return 0
    else:
      stderr.writeLine "Unknown option " & a
      return 1
  var names = modulesFromCmdline((try: readFile("/proc/cmdline") except IOError: ""))
  for f in modulesConfFiles():
    try: names.add parseModulesConf(readFile(f))
    except IOError, OSError:
      stderr.writeLine "Failed to read " & f
      result = 1
  for m in dedupeModules(names):
    let code = runArgv(@["modprobe", "-abq", m])
    if code < 0:
      stderr.writeLine "Failed to load module " & m & ": modprobe could not be run."
      result = 1
    elif code != 0:
      stderr.writeLine "Failed to load module " & m & ": modprobe exited with status " & $code & "."
      result = 1

# ---- systemd-fsck --------------------------------------------------------------

type
  FsckMode* = enum fmAuto, fmForce, fmSkip
  FsckRepair* = enum frNo, frYes, frPreen

proc fsckModeFromString(s: string): Option[FsckMode] =
  case s
  of "auto": some(fmAuto)
  of "force": some(fmForce)
  of "skip": some(fmSkip)
  else: none(FsckMode)

proc fsckRepairFromString(s: string): Option[FsckRepair] =
  case s
  of "preen": some(frPreen)
  of "yes", "true", "1": some(frYes)
  of "no", "false", "0": some(frNo)
  else: none(FsckRepair)

proc parseFsckCmdline*(cmdline: string): tuple[mode: FsckMode, repair: FsckRepair] =
  ## `fsck.mode=` and `fsck.repair=`, the last occurrence winning; unknown
  ## values are ignored. `fastboot`/`forcefsck` are the legacy spellings.
  result = (fmAuto, frPreen)
  for raw in cmdline.splitWhitespace:
    let w = if raw.startsWith("rd."): raw[3 .. ^1] else: raw
    if w == "fastboot": result.mode = fmSkip
    elif w == "forcefsck": result.mode = fmForce
    elif w.startsWith("fsck.mode="):
      let m = fsckModeFromString(w[10 .. ^1])
      if m.isSome: result.mode = m.get
    elif w.startsWith("fsck.repair="):
      let r = fsckRepairFromString(w[12 .. ^1])
      if r.isSome: result.repair = r.get

proc fsckArgv*(mode: FsckMode; repair: FsckRepair; device: string): seq[string] =
  ## fsck(8) with the repair flag of the mode, `-T` and util-linux's `-l` lock,
  ## empty when the check is skipped. `-M` (skip a mounted device) is left out:
  ## the plain DEVICE form cannot tell whether the device is the root file
  ## system, which fsck checks while it is still mounted read-only.
  if mode == fmSkip: return
  let repairFlag = case repair
    of frNo: "-n"
    of frYes: "-y"
    of frPreen: "-a"
  result = @["fsck", repairFlag, "-T", "-l"]
  if mode == fmForce: result.add "-f"
  result.add device

const
  FsckErrorCorrected = 1
  FsckSystemShouldReboot = 2
  FsckErrorsLeftUncorrected = 4
  FsckOperationalError = 8
  FsckUsage = 16
  FsckCanceled = 32

proc needsReboot*(code: int): bool = (code and FsckSystemShouldReboot) != 0

proc mapFsckStatus*(code: int): int =
  ## 0 and 1 (errors corrected) are success, 2 asks for a reboot and is still
  ## success, every other bit fails the unit.
  if (code and (FsckErrorsLeftUncorrected or FsckOperationalError or FsckUsage or FsckCanceled)) != 0:
    return 1
  if (code and not (FsckErrorCorrected or FsckSystemShouldReboot)) != 0: return 1
  0

proc fsckMain*(args: seq[string]): int =
  var device = ""
  for a in args:
    if a in ["-h", "--help"]:
      echo "systemd-fsck [DEVICE]\n\nCheck a file system before it is mounted."
      return 0
    elif a == "--version":
      echo "systemd 255 (255.0-jumpstart-core)"
      return 0
    elif a.startsWith("-") and a.len > 1:
      stderr.writeLine "Unknown option " & a
      return 1
    elif device.len == 0: device = a
    else:
      stderr.writeLine "Too many arguments."
      return 1
  if device.len == 0:
    stderr.writeLine "Not enough arguments."
    return 1
  let (mode, repair) = parseFsckCmdline((try: readFile("/proc/cmdline") except IOError: ""))
  if mode == fmSkip: return 0
  var st: Stat
  if stat(device.cstring, st) != 0:
    stderr.writeLine "Failed to stat " & device & ": " & $strerror(errno)
    return 1
  let code = runArgv(fsckArgv(mode, repair, device))
  if code < 0:
    stderr.writeLine "Failed to run fsck for " & device & "."
    return 1
  result = mapFsckStatus(code)
  if result != 0: stderr.writeLine "fsck failed with exit status " & $code & "."
  elif needsReboot(code): stderr.writeLine "fsck of " & device & " asked for a reboot."

# ---- systemd-remount-fs --------------------------------------------------------

type RemountEntry* = tuple[target, options: string]

proc cmdlineRw*(cmdline: string): string =
  ## `ro` or `rw` from the kernel command line, the last one winning; read-write
  ## when neither is there.
  result = "rw"
  for w in cmdline.splitWhitespace:
    if w == "ro": result = "ro"
    elif w == "rw": result = "rw"

proc remountOptions*(target, fstabOptions, cmdline: string): string =
  ## Only the fstab options that change a remount survive: ro/rw, plus bind and
  ## rbind for `/usr`, which fstab lines use for the bind mount. Without any,
  ## the kernel command line decides and the default is read-write.
  var keep: seq[string]
  for o in fstabOptions.split(','):
    let t = o.strip
    if t in ["ro", "rw"]: keep.add t
    elif target == "/usr" and t in ["bind", "rbind"]: keep.add t
  if keep.len == 0: keep.add cmdlineRw(cmdline)
  keep.join(",")

proc remountPlan*(fstabText, cmdline: string): seq[RemountEntry] =
  ## `/` always and `/usr` when /etc/fstab mounts it; the first line for a
  ## target wins.
  var targets = @["/"]
  var lines: seq[tuple[target, options: string]]
  for raw in fstabText.splitLines:
    let line = raw.strip
    if line.len == 0 or line[0] == '#': continue
    let f = line.splitWhitespace
    if f.len < 4 or f[1] notin ["/", "/usr"]: continue
    if f[1] notin targets: targets.add f[1]
    if not lines.anyIt(it.target == f[1]): lines.add (f[1], f[3])
  for t in targets:
    var options = ""
    for (target, o) in lines:
      if target == t: options = o
    result.add (t, remountOptions(t, options, cmdline))

proc remountArgv*(target, options: string): seq[string] =
  ## `mount -o remount,OPTIONS TARGET`.
  @["mount", "-o", (if options.len == 0: "remount" else: "remount," & options), target]

proc remountFsMain*(args: seq[string]): int =
  for a in args:
    if a in ["-h", "--help"]:
      echo "systemd-remount-fs\n\nRemount the root and kernel file systems according to /etc/fstab."
      return 0
    elif a == "--version":
      echo "systemd 255 (255.0-jumpstart-core)"
      return 0
    else:
      stderr.writeLine "Unknown option " & a
      return 1
  var fstab = ""
  if fileExists("/etc/fstab"):
    try: fstab = readFile("/etc/fstab")
    except IOError, OSError:
      stderr.writeLine "Failed to read /etc/fstab."
      return 1
  let cmdline = try: readFile("/proc/cmdline") except IOError: ""
  for (target, options) in remountPlan(fstab, cmdline):
    let code = runArgv(remountArgv(target, options))
    if code != 0:
      stderr.writeLine "Failed to remount " & target & ": mount exited with status " & $code & "."
      result = 1
