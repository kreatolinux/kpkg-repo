## `systemctl edit` (spec §15.2.4): drop-in or full-file editing through
## $SYSTEMD_EDITOR / $EDITOR / $VISUAL.
import std/[os, strutils, osproc, sequtils]
import ../unitfile/paths
import ../common/roots

type EditOpts* = object
  full*, runtime*, force*, fromStdin*: bool
  dropin*: string                 ## drop-in file name ("" = override.conf)

const
  Discard = "### Lines below this comment will be discarded"
  EditingHeader = "### Anything between here and the comment below will become the new contents of the file"

proc findEditor*(): string =
  for v in ["SYSTEMD_EDITOR", "EDITOR", "VISUAL"]:
    let e = getEnv(v)
    if e.len > 0: return e
  for e in ["editor", "nano", "vim", "vi"]:
    if findExe(e).len > 0: return e

proc commentOut(text: string): string =
  for l in text.splitLines:
    result.add (if l.len > 0: "# " & l else: "#") & "\n"

proc targetPath*(r: Roots; unit, existingFragment: string; o: EditOpts): string =
  let dir = configDir(r, o.runtime)
  if o.full:
    if existingFragment.len > 0 and existingFragment.parentDir == dir: existingFragment
    else: dir / unit
  else:
    var fn = if o.dropin.len > 0: o.dropin else: "override.conf"
    if not fn.endsWith(".conf"): fn.add ".conf"
    dir / (unit & ".d") / fn

proc extractEdited*(text: string): string =
  ## Content of the editable region, without the scaffold lines.
  var body = text
  let cut = body.find(Discard)
  if cut >= 0: body = body[0 ..< cut]
  var lines = body.splitLines
  lines = lines.filterIt(not (it.startsWith("### Editing ") or it == EditingHeader))
  result = lines.join("\n").strip(chars = {'\n', '\r'}, trailing = false)
  result = result.strip(leading = false) & "\n"
  if result.strip.len == 0: result = ""

type EditResult* = enum erChanged, erUnchanged, erEmpty, erFailed

proc editOne*(unit, fragment: string; r: Roots; o: EditOpts; stdinText: string; err: var string): EditResult =
  let target = targetPath(r, unit, fragment, o)
  var initial = ""
  var scaffold = true
  let had = fileExists(target)
  if had:
    initial = readFile(target)
    scaffold = false
  elif o.full:
    scaffold = false
    if fragment.len > 0 and fileExists(fragment): initial = readFile(fragment)
  if o.fromStdin:
    let edited = if stdinText.strip.len == 0: "" else: stdinText.strip(leading = false) & "\n"
    if edited.len == 0: return erEmpty
    if had and edited == initial: return erUnchanged
    createDir(target.parentDir)
    writeFile(target, edited)
    return erChanged
  var text = initial
  if scaffold:
    text = "### Editing " & target & "\n" & EditingHeader & "\n\n\n\n" & Discard & "\n\n"
    if fragment.len > 0 and fileExists(fragment): text.add "### " & fragment & "\n" & commentOut(readFile(fragment))
  let editor = findEditor()
  if editor.len == 0:
    err = "Cannot find an editor; set $EDITOR."
    return erFailed
  try: createDir(target.parentDir)
  except OSError as e:
    err = "Failed to create " & target.parentDir & ": " & e.msg
    return erFailed
  let tmp = target.parentDir / (".#" & target.extractFilename & $getCurrentProcessId())
  writeFile(tmp, text)
  defer: removeFile(tmp)
  if execShellCmd(editor & " " & quoteShell(tmp)) != 0:
    err = "Editor \"" & editor & "\" failed."
    return erFailed
  let edited = extractEdited(readFile(tmp))
  if edited.len == 0:
    if not had:
      try:
        if toSeq(walkDir(target.parentDir)).len == 0 and not o.full: removeDir(target.parentDir)
      except OSError: discard
    return erEmpty
  if had and edited == initial: return erUnchanged
  if not had and o.full and edited == initial: return erUnchanged
  moveFile(tmp, target)
  setFilePermissions(target, {fpUserRead, fpUserWrite, fpGroupRead, fpOthersRead})
  erChanged
