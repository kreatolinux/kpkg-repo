## `systemd-sysusers` (spec §15.5, sysusers.d(5)): create system users and
## groups from `sysusers.d` snippets by editing /etc/passwd, group, shadow
## and gshadow atomically under /etc/.pwd.lock.
import std/[os, strutils, sequtils, algorithm, tables, options, posix, times]

type
  SuLine* = object
    typ*: char
    locked*: bool
    name*, id*, gecos*, home*, shell*, file*: string
    line*: int
  Db* = object
    passwd*, group*, shadow*, gshadow*: seq[string]
  Opts* = object
    root*: string
    dryRun*, inline*: bool
    replace*: string

const
  DefaultSysMin = 100
  DefaultSysMax = 999

proc rp(root, p: string): string =
  if root.len == 0: p else: root / p.strip(chars = {'/'}, trailing = false)

proc readDb(root, name: string): seq[string] =
  let p = rp(root, "/etc" / name)
  if not fileExists(p): return
  for l in readFile(p).splitLines:
    if l.len > 0: result.add l

proc field(line: string; i: int): string =
  let f = line.split(':')
  if i < f.len: f[i] else: ""

proc idInUse(lines: seq[string]; id: int): bool =
  lines.anyIt(it.field(2) == $id)

proc findByName(lines: seq[string]; name: string): int =
  for i, l in lines:
    if l.field(0) == name: return i
  -1

proc loginDefs(root: string): tuple[lo, hi: int] =
  result = (DefaultSysMin, DefaultSysMax)
  try:
    for l in readFile(rp(root, "/etc/login.defs")).splitLines:
      let w = l.splitWhitespace
      if w.len >= 2 and not l.startsWith("#"):
        if w[0] == "SYS_UID_MIN": result.lo = parseInt(w[1])
        elif w[0] == "SYS_UID_MAX": result.hi = parseInt(w[1])
  except CatchableError: discard

# ---- parsing --------------------------------------------------------------------
proc words(s: string): seq[string] =
  var i = 0
  while i < s.len:
    while i < s.len and s[i] in {' ', '\t'}: inc i
    if i >= s.len: break
    var w = ""
    var q = '\0'
    while i < s.len:
      let c = s[i]
      if q != '\0':
        if c == q: q = '\0'
        elif c == '\\' and i + 1 < s.len:
          inc i
          w.add s[i]
        else: w.add c
      elif c in {'"', '\''}: q = c
      elif c in {' ', '\t'}: break
      else: w.add c
      inc i
    result.add w

proc parseSuLine*(raw, file: string; lineNo: int; err: var string): Option[SuLine] =
  let line = raw.strip
  if line.len == 0 or line[0] in {'#', ';'}: return none(SuLine)
  let w = words(line)
  if w.len < 2 or w[0].len == 0 or w[0][0] notin {'u', 'g', 'm', 'r'}:
    err = "Unknown line type or too few fields."
    return none(SuLine)
  var l = SuLine(typ: w[0][0], file: file, line: lineNo, name: w[1])
  l.locked = '!' in w[0]
  if w.len > 2: l.id = w[2]
  if w.len > 3: l.gecos = w[3]
  if w.len > 4: l.home = w[4]
  if w.len > 5: l.shell = w[5]
  case l.typ
  of 'u', 'g':
    if l.name != "-" and not (l.name.len > 0 and l.name.allCharsInSet(Letters + Digits + {'_', '-', '.'}) and
        l.name[0] notin Digits + {'-'}):
      err = "Invalid user or group name '" & l.name & "'."
      return none(SuLine)
  of 'm':
    if w.len < 3:
      err = "Too few fields for 'm'."
      return none(SuLine)
  else: discard
  some(l)

# ---- allocation -----------------------------------------------------------------
proc idFromPath(root, p: string): int =
  var st: Stat
  if stat(rp(root, p).cstring, st) != 0: return -1
  int(st.st_uid)

proc parseRange(s: string): Option[(int, int)] =
  let p = s.split('-')
  try:
    if p.len == 1: return some((parseInt(p[0]), parseInt(p[0])))
    if p.len == 2: return some((parseInt(p[0]), parseInt(p[1])))
  except ValueError: discard
  none((int, int))

type Ctx = object
  db: Db
  root: string
  lo, hi: int
  reserved: seq[(int, int)]
  changed: bool
  warnings: int
  dry: bool

proc reservedId(c: Ctx; id: int): bool = c.reserved.anyIt(id >= it[0] and id <= it[1])

proc allocate(c: Ctx; needBoth: bool): int =
  ## First free id from SYS_UID_MAX downward, free in passwd (and group when `needBoth`).
  for id in countdown(c.hi, c.lo):
    if idInUse(c.db.passwd, id) or idInUse(c.db.group, id) and needBoth: continue
    if not needBoth and idInUse(c.db.group, id): continue
    if c.reservedId(id): continue
    return id
  -1

proc resolveId(c: Ctx; spec: string): tuple[uid, gid: int, gname: string] =
  ## "-", "N", "/path", "N:G", "N:groupname". -1 means allocate.
  result = (-1, -1, "")
  if spec.len == 0 or spec == "-": return
  let parts = spec.split(':')
  let first = parts[0]
  if first.startsWith("/"): result.uid = idFromPath(c.root, first)
  elif first != "-" and first.allCharsInSet(Digits): result.uid = parseInt(first)
  if parts.len > 1:
    let g = parts[1]
    if g.allCharsInSet(Digits) and g.len > 0: result.gid = parseInt(g)
    else: result.gname = g

proc addGroup(c: var Ctx; name: string; gid: int; members = "") =
  c.db.group.add name & ":x:" & $gid & ":" & members
  c.db.gshadow.add name & ":!::" & members
  c.changed = true

proc doGroup(c: var Ctx; l: SuLine; err: var string) =
  if findByName(c.db.group, l.name) >= 0: return
  var gid = -1
  if l.id.len > 0 and l.id != "-":
    if l.id.startsWith("/"): gid = idFromPath(c.root, l.id)
    elif l.id.allCharsInSet(Digits): gid = parseInt(l.id)
    if gid >= 0 and idInUse(c.db.group, gid):
      err = "Group ID " & $gid & " of " & l.name & " is already in use."
      return
  if gid < 0:
    for id in countdown(c.hi, c.lo):
      if not idInUse(c.db.group, id) and not c.reservedId(id):
        gid = id
        break
  if gid < 0:
    err = "No free group ID for " & l.name & "."
    return
  c.addGroup(l.name, gid)
  if c.dry: echo "Would create group " & l.name & " (" & $gid & ")"

proc doUser(c: var Ctx; l: SuLine; err: var string) =
  if findByName(c.db.passwd, l.name) >= 0: return
  var (uid, gid, gname) = c.resolveId(l.id)
  if uid >= 0 and idInUse(c.db.passwd, uid):
    err = "User ID " & $uid & " of " & l.name & " is already in use."
    return
  # primary group
  var gi = findByName(c.db.group, if gname.len > 0: gname else: l.name)
  if gid < 0 and gi >= 0: gid = parseInt(c.db.group[gi].field(2))
  if gid >= 0 and gi < 0 and gname.len == 0 and idInUse(c.db.group, gid):
    gi = c.db.group.findIt(it.field(2) == $gid)
  if uid < 0:
    if gid >= 0 and gi >= 0: uid = c.allocate(false)
    else: uid = c.allocate(true)
    if uid < 0:
      err = "No free user ID for " & l.name & "."
      return
  if gi < 0:
    let gn = if gname.len > 0: gname else: l.name
    var newGid = gid
    if newGid < 0:
      newGid = if not idInUse(c.db.group, uid): uid else: -1
      if newGid < 0:
        for id in countdown(c.hi, c.lo):
          if not idInUse(c.db.group, id) and not c.reservedId(id):
            newGid = id
            break
    if newGid < 0 or idInUse(c.db.group, newGid):
      err = "No usable group ID for " & l.name & "."
      return
    c.addGroup(gn, newGid)
    gid = newGid
  elif gid < 0:
    gid = parseInt(c.db.group[gi].field(2))
  let home = if l.home.len > 0 and l.home != "-": l.home else: "/"
  let shell = if l.shell.len > 0 and l.shell != "-": l.shell else: "/usr/sbin/nologin"
  let gecos = if l.gecos == "-": "" else: l.gecos
  c.db.passwd.add l.name & ":x:" & $uid & ":" & $gid & ":" & gecos & ":" & home & ":" & shell
  c.db.shadow.add l.name & ":!*:" & $(getTime().toUnix div 86400) & "::::::"
  c.changed = true
  if c.dry: echo "Would create user " & l.name & " (" & $uid & ")"

proc doMember(c: var Ctx; l: SuLine; err: var string) =
  let gname = l.id
  let gi = findByName(c.db.group, gname)
  if gi < 0 or findByName(c.db.passwd, l.name) < 0:
    err = "Cannot add " & l.name & " to " & gname & ": no such user or group."
    return
  let f = c.db.group[gi].split(':')
  let members = (if f.len > 3 and f[3].len > 0: f[3].split(',') else: @[])
  if l.name in members: return
  let nm = (members & @[l.name]).join(",")
  c.db.group[gi] = f[0] & ":" & f[1] & ":" & f[2] & ":" & nm
  let si = findByName(c.db.gshadow, gname)
  if si >= 0:
    let sf = c.db.gshadow[si].split(':')
    let sm = (if sf.len > 3 and sf[3].len > 0: sf[3].split(',') else: @[])
    c.db.gshadow[si] = sf[0] & ":" & sf[1] & ":" & (if sf.len > 2: sf[2] else: "") & ":" &
      (sm & @[l.name]).join(",")
  c.changed = true

# ---- files ----------------------------------------------------------------------
proc writeAtomic(root, name: string; lines: seq[string]; defMode: int) =
  let p = rp(root, "/etc" / name)
  var mode = defMode
  var uid = Uid(high(uint32))
  var gid = Gid(high(uint32))
  var st: Stat
  if stat(p.cstring, st) == 0:
    mode = int(st.st_mode) and 0o7777
    uid = st.st_uid
    gid = st.st_gid
  let tmp = p & ".sysusers-new"
  writeFile(tmp, lines.join("\n") & "\n")
  discard chmod(tmp.cstring, Mode(mode))
  if uid != Uid(high(uint32)): discard chown(tmp.cstring, uid, gid)
  moveFile(tmp, p)

proc lockDb(root: string): cint =
  let dir = rp(root, "/etc")
  createDir(dir)
  let fd = open((dir / ".pwd.lock").cstring, O_WRONLY or O_CREAT or O_CLOEXEC, Mode(0o600))
  if fd < 0: return -1
  var fl: Tflock
  fl.l_type = cshort(F_WRLCK)
  fl.l_whence = cshort(SEEK_SET)
  discard fcntl(fd, F_SETLKW, addr fl)
  fd

proc discoverConfigs*(root: string; coreShare: string): seq[string] =
  var byName = initTable[string, string]()
  var dirs = @[rp(root, "/etc/sysusers.d"), rp(root, "/run/sysusers.d"), rp(root, "/usr/local/lib/sysusers.d"),
               rp(root, "/usr/lib/sysusers.d")]
  if coreShare.len > 0: dirs.add coreShare
  for d in dirs:
    if not dirExists(d): continue
    for k, p in walkDir(d):
      let n = p.extractFilename
      if n.endsWith(".conf") and n notin byName: byName[n] = p
  var names = toSeq(byName.keys)
  names.sort()
  for n in names:
    let p = byName[n]
    if symlinkExists(p) and (try: expandSymlink(p) == "/dev/null" except OSError: false): continue
    result.add p

proc applyLines*(root: string; lines: seq[SuLine]; dry = false): int =
  ## 0, or 1 when a line failed. Idempotent.
  let (lo, hi) = loginDefs(root)
  var c = Ctx(root: root, lo: lo, hi: hi, dry: dry)
  c.db = Db(passwd: readDb(root, "passwd"), group: readDb(root, "group"), shadow: readDb(root, "shadow"),
            gshadow: readDb(root, "gshadow"))
  for l in lines:
    if l.typ == 'r':
      let r = parseRange(l.id)
      if r.isSome: c.reserved.add r.get
  proc run(c: var Ctx; l: SuLine): int =
    var err = ""
    case l.typ
    of 'g': doGroup(c, l, err)
    of 'u': doUser(c, l, err)
    of 'm': doMember(c, l, err)
    else: discard
    if err.len > 0:
      stderr.writeLine l.file & ":" & $l.line & ": " & err
      return 1
  for typ in ['g', 'u', 'm']:
    for l in lines:
      if l.typ == typ and c.run(l) != 0: result = 1
  if c.changed and not dry:
    let fd = lockDb(root)
    try:
      writeAtomic(root, "passwd", c.db.passwd, 0o644)
      writeAtomic(root, "group", c.db.group, 0o644)
      writeAtomic(root, "shadow", c.db.shadow, 0o600)
      writeAtomic(root, "gshadow", c.db.gshadow, 0o600)
    finally:
      if fd >= 0: discard close(fd)

proc sysusersMain*(args: seq[string]): int =
  var o: Opts
  var pos: seq[string]
  for a in args:
    if a.startsWith("--root="): o.root = a[7 .. ^1].strip(chars = {'/'}, leading = false)
    elif a.startsWith("--replace="): o.replace = a[10 .. ^1]
    elif a == "--dry-run": o.dryRun = true
    elif a == "--inline": o.inline = true
    elif a in ["--help", "-h"]:
      echo "systemd-sysusers [OPTIONS...] [CONFIGURATION FILE...]\n\nCreates system user and group accounts."
      return 0
    elif a == "--version":
      echo "systemd 255 (255.0-jumpstart-core)"
      return 0
    elif a.startsWith("--") and a != "--":
      stderr.writeLine "Unknown option: " & a
      return 1
    else: pos.add a
  if o.replace.len > 0 and pos.len == 0:
    stderr.writeLine "When --replace= is used, at least one positional argument must be specified."
    return 1
  var sources: seq[(string, string)]            ## file label, text
  var files: seq[string]
  if o.inline:
    for i, t in pos: sources.add ("<inline:" & $i & ">", t)
  elif o.replace.len > 0:
    let share = (let c = getAppFilename().parentDir.parentDir / "share/sysusers.d"; if dirExists(c): c else: "")
    let skip = o.replace.extractFilename
    files = discoverConfigs(o.root, share).filterIt(it.extractFilename != skip) & pos
  elif pos.len > 0: files = pos
  else:
    let share = (let c = getAppFilename().parentDir.parentDir / "share/sysusers.d"; if dirExists(c): c else: "")
    files = discoverConfigs(o.root, share)
  for f in files:
    try: sources.add (f, if f == "-": stdin.readAll() else: readFile(f))
    except IOError:
      stderr.writeLine "Failed to read " & f
      result = 1
  var lines: seq[SuLine]
  for (label, text) in sources:
    var n = 0
    for raw in text.splitLines:
      inc n
      var err = ""
      let l = parseSuLine(raw, label, n, err)
      if err.len > 0:
        stderr.writeLine label & ":" & $n & ": " & err
        result = 1
      elif l.isSome: lines.add l.get
  result = max(result, applyLines(o.root, lines, o.dryRun))
