## `systemd-tmpfiles` (spec §15.4, tmpfiles.d(5)): create, remove and clean
## files and directories from `tmpfiles.d` snippets. ACL (`a`, `A`), xattr
## (`t`, `T`) and chattr (`h`, `H`) lines are skipped with a warning.
import std/[os, strutils, sequtils, algorithm, tables, options, times, posix, base64, nativesockets]
import ../unitfile/values

var oNoFollow {.importc: "O_NOFOLLOW", header: "<fcntl.h>".}: cint

type
  TmpLine* = object
    typ*: char
    replace*, bootOnly*, ignoreErr*, verify*, base64*, cred*: bool
    path*, user*, group*, age*, arg*: string
    mode*: string
    file*: string
    line*: int
  Settings* = object
    root*: string
    user*: bool
    create*, remove*, clean*, boot*, dryRun*: bool
    prefixes*, excludes*: seq[string]
    home*, hostname*, machineId*, bootId*, release*, userName*, groupName*: string
    uid*, gid*: int
    errors*, parseErrors*: int

const KnownTypes = "fFwdDepLcbaAxXrRzZCvqQtThH"

proc rp(s: Settings; p: string): string =
  ## A path below the root.
  if s.root.len == 0: p else: s.root / p.strip(chars = {'/'}, trailing = false)

# ---- parsing --------------------------------------------------------------------
proc unescapeC*(s: string): string =
  var i = 0
  while i < s.len:
    let c = s[i]
    if c != '\\' or i + 1 >= s.len:
      result.add c
      inc i
      continue
    inc i
    case s[i]
    of 'n': result.add '\n'; inc i
    of 't': result.add '\t'; inc i
    of 'r': result.add '\r'; inc i
    of '\\': result.add '\\'; inc i
    of '"': result.add '"'; inc i
    of '\'': result.add '\''; inc i
    of 'x':
      inc i
      var h = ""
      while h.len < 2 and i < s.len and s[i] in HexDigits:
        h.add s[i]
        inc i
      if h.len > 0: result.add chr(parseHexInt(h))
    of '0' .. '7':
      var o = ""
      while o.len < 3 and i < s.len and s[i] in {'0' .. '7'}:
        o.add s[i]
        inc i
      result.add chr(parseOctInt(o) and 0xff)
    else:
      result.add '\\'
      result.add s[i]
      inc i

proc nextWord(s: string; i: var int): Option[string] =
  ## One whitespace separated field; quotes group, `\` escapes inside quotes.
  while i < s.len and s[i] in {' ', '\t'}: inc i
  if i >= s.len: return none(string)
  var w = ""
  var q = '\0'
  while i < s.len:
    let c = s[i]
    if q != '\0':
      if c == q: q = '\0'
      elif c == '\\' and i + 1 < s.len and q == '"':
        inc i
        w.add '\\'
        w.add s[i]
      else: w.add c
    elif c in {'"', '\''}: q = c
    elif c in {' ', '\t'}: break
    else: w.add c
    inc i
  some(w)

proc expandSpecifiers*(s: Settings; text: string): string =
  var i = 0
  while i < text.len:
    if text[i] != '%' or i + 1 >= text.len:
      result.add text[i]
      inc i
      continue
    inc i
    let rt = getEnv("XDG_RUNTIME_DIR", "/run/user/" & $s.uid)
    case text[i]
    of '%': result.add '%'
    of 't': result.add (if s.user: rt else: "/run")
    of 'S': result.add (if s.user: s.home / ".local/state" else: "/var/lib")
    of 'C': result.add (if s.user: s.home / ".cache" else: "/var/cache")
    of 'L': result.add (if s.user: s.home / ".local/state" else: "/var/log")
    of 'T': result.add "/tmp"
    of 'V': result.add "/var/tmp"
    of 'h': result.add s.home
    of 'H': result.add s.hostname
    of 'm': result.add s.machineId
    of 'b': result.add s.bootId
    of 'v': result.add s.release
    of 'u': result.add s.userName
    of 'U': result.add $s.uid
    of 'g': result.add s.groupName
    of 'G': result.add $s.gid
    else:
      result.add '%'
      result.add text[i]
    inc i

proc parseLine*(s: Settings; raw: string; file: string; lineNo: int; err: var string): Option[TmpLine] =
  let line = raw.strip
  if line.len == 0 or line[0] in {'#', ';'}: return none(TmpLine)
  var i = 0
  let tf = nextWord(line, i)
  if tf.isNone: return none(TmpLine)
  let t = tf.get
  if t.len == 0 or t[0] notin KnownTypes:
    err = "Unknown file type '" & t & "'."
    return none(TmpLine)
  var l = TmpLine(typ: t[0], file: file, line: lineNo)
  for ch in t[1 .. ^1]:
    case ch
    of '+': l.replace = true
    of '!': l.bootOnly = true
    of '-': l.ignoreErr = true
    of '=': l.verify = true
    of '~': l.base64 = true
    of '^': l.cred = true
    of '$': discard     # purgeable marker (systemd 256+); only --purge, which is not implemented, uses it
    else:
      err = "Unknown modifier '" & $ch & "'."
      return none(TmpLine)
  let pw = nextWord(line, i)
  if pw.isNone:
    err = "Missing path."
    return none(TmpLine)
  l.path = expandSpecifiers(s, pw.get)
  if l.path.len == 0 or l.path[0] != '/':
    err = "Path '" & l.path & "' is not absolute."
    return none(TmpLine)
  l.mode = nextWord(line, i).get("-")
  l.user = nextWord(line, i).get("-")
  l.group = nextWord(line, i).get("-")
  l.age = nextWord(line, i).get("-")
  while i < line.len and line[i] in {' ', '\t'}: inc i
  var arg = line[i .. ^1]
  if arg.len >= 2 and arg[0] in {'"', '\''} and arg[^1] == arg[0]: arg = arg[1 ..< arg.len - 1]
  l.arg = if arg == "-": "" else: expandSpecifiers(s, arg)
  if l.mode != "-" and l.mode.len > 0:
    let m = l.mode.strip(chars = {':', '~'}, trailing = false)
    if parseOctal(m).isNone:
      err = "Invalid mode '" & l.mode & "'."
      return none(TmpLine)
  if l.age != "-":
    var a = l.age.strip(chars = {'~'}, trailing = false)
    if a.len > 2 and a[1] == ':' and a[0] in {'a', 'm', 'c', 'b', 'A', 'M', 'C', 'B'}: a = a[2 .. ^1]
    if parseTimespan(a).isNone:
      err = "Invalid age '" & l.age & "'."
      return none(TmpLine)
  some(l)

# ---- identities -----------------------------------------------------------------
proc lookupId(s: Settings; db, name: string): int =
  ## uid/gid of `name` (or a number) in the root's passwd/group; -1 when unknown.
  if name == "-" or name.len == 0: return -1
  let n = name.strip(chars = {':'}, trailing = false)
  if n.len == 0 or n == "-": return -1
  if n.allCharsInSet(Digits): return parseInt(n)
  try:
    for l in readFile(rp(s, "/etc" / db)).splitLines:
      let f = l.split(':')
      if f.len >= 3 and f[0] == n: return parseInt(f[2])
  except CatchableError: discard
  if s.root.len == 0:
    if db == "passwd":
      let p = getpwnam(n.cstring)
      if p != nil: return int(p.pw_uid)
    else:
      let g = getgrnam(n.cstring)
      if g != nil: return int(g.gr_gid)
  -1

proc modeOf(l: TmpLine): int =
  if l.mode == "-" or l.mode.len == 0: return -1
  let m = l.mode.strip(chars = {':', '~'}, trailing = false)
  let v = parseOctal(m)
  if v.isSome: v.get else: -1

# ---- actions --------------------------------------------------------------------
type Fail = object of CatchableError

proc fail(msg: string) = raise newException(Fail, msg)

proc fileExists(p: string): bool =
  ## Shadows std/os.fileExists (regular files only): anything that is not a
  ## directory counts, so existing device nodes, fifos and sockets are found.
  var st: Stat
  stat(p.cstring, st) == 0 and not S_ISDIR(st.st_mode)

proc applyPerms(s: Settings; l: TmpLine; p: string; created: bool; defMode: int) =
  var mode = modeOf(l)
  let modeCreationOnly = l.mode.startsWith(":")
  if mode >= 0 and modeCreationOnly and not created: mode = -1
  if mode < 0 and created: mode = defMode
  if mode >= 0 and not symlinkExists(p):
    var m = mode
    if l.mode.startsWith("~") and dirExists(p):
      m = mode      # masking keeps only the bits that make sense for the file type
    var cur: Stat
    # like systemd, do nothing when the mode already matches (a read-only root cannot chmod)
    if stat(p.cstring, cur) == 0 and (int(cur.st_mode) and 0o7777) == m: discard
    elif chmod(p.cstring, Mode(m)) != 0 and errno != EPERM:
      fail("Failed to set mode of " & p & ": " & $strerror(errno))
  var uid = lookupId(s, "passwd", l.user)
  var gid = lookupId(s, "group", l.group)
  if l.user.startsWith(":") and not created: uid = -1
  if l.group.startsWith(":") and not created: gid = -1
  if (uid >= 0 or gid >= 0):
    let u = if uid >= 0: Uid(uid) else: Uid(high(uint32))
    let g = if gid >= 0: Gid(gid) else: Gid(high(uint32))
    var cur: Stat
    let same = lstat(p.cstring, cur) == 0 and (uid < 0 or int(cur.st_uid) == uid) and (gid < 0 or int(cur.st_gid) == gid)
    if not same and lchown(p.cstring, u, g) != 0 and errno != EPERM:
      fail("Failed to chown " & p & ": " & $strerror(errno))

proc ensureParents(p: string) =
  let d = p.parentDir
  if d.len > 0 and not dirExists(d): createDir(d)

proc argData(l: TmpLine): string =
  if l.base64: base64.decode(l.arg) else: unescapeC(l.arg)

proc globPaths(s: Settings; l: TmpLine): seq[string] =
  let p = rp(s, l.path)
  if not p.anyIt(it in {'*', '?', '['}):
    return @[p]
  for f in walkPattern(p): result.add f
  result.sort()

proc doDir(s: Settings; l: TmpLine; typ: char) =
  let p = rp(s, l.path)
  var created = false
  if symlinkExists(p) and not dirExists(p):
    fail("'" & p & "' already exists and is not a directory.")
  if not dirExists(p):
    if fileExists(p): fail("'" & p & "' already exists and is not a directory.")
    ensureParents(p)
    createDir(p)
    created = true
  applyPerms(s, l, p, created, 0o755)

proc doFile(s: Settings; l: TmpLine; truncate: bool) =
  let p = rp(s, l.path)
  var created = false
  if not fileExists(p) and not symlinkExists(p):
    ensureParents(p)
    let fd = open(p.cstring, O_WRONLY or O_CREAT or O_EXCL or oNoFollow or O_CLOEXEC, Mode(0o644))
    if fd < 0: fail("Failed to create file " & p & ": " & $strerror(errno))
    discard close(fd)
    created = true
    let data = argData(l)
    if data.len > 0: writeFile(p, data)
  elif truncate:
    writeFile(p, argData(l))
  elif dirExists(p): fail("'" & p & "' already exists and is a directory.")
  applyPerms(s, l, p, created, 0o644)

proc doWrite(s: Settings; l: TmpLine) =
  for p in globPaths(s, l):
    if not (fileExists(p) or symlinkExists(p) or p.startsWith("/dev") or p.startsWith("/proc") or p.startsWith("/sys")):
      continue
    if not fileExists(p) and not dirExists(p): continue
    let data = argData(l)
    var flags = O_WRONLY or O_NOCTTY or O_CLOEXEC
    if l.replace: flags = flags or O_APPEND
    var st: Stat
    if stat(p.cstring, st) == 0 and S_ISREG(st.st_mode) and not l.replace: flags = flags or O_TRUNC
    let fd = open(p.cstring, flags)
    if fd < 0: fail("Failed to open file " & p & ": " & $strerror(errno))
    let n = write(fd, data.cstring, data.len)
    discard close(fd)
    if n < 0: fail("Failed to write file " & p & ": " & $strerror(errno))

proc doFifo(s: Settings; l: TmpLine) =
  let p = rp(s, l.path)
  var created = false
  if symlinkExists(p) or fileExists(p) or dirExists(p):
    var st: Stat
    if lstat(p.cstring, st) == 0 and S_ISFIFO(st.st_mode): discard
    elif l.replace:
      removeFile(p)
    else: fail("'" & p & "' already exists and is not a fifo.")
  if not (symlinkExists(p) or fileExists(p)):
    ensureParents(p)
    if mkfifo(p.cstring, Mode(0o644)) != 0: fail("Failed to create fifo " & p & ": " & $strerror(errno))
    created = true
  applyPerms(s, l, p, created, 0o644)

proc doSymlink(s: Settings; l: TmpLine) =
  let p = rp(s, l.path)
  let target = if l.arg.len > 0: l.arg else: "/usr/share/factory" / l.path.strip(chars = {'/'}, trailing = false)
  if symlinkExists(p):
    if expandSymlink(p) == target: return
    if not l.replace: return
    removeFile(p)
  elif fileExists(p) or dirExists(p):
    if not l.replace: return
    if dirExists(p): removeDir(p) else: removeFile(p)
  ensureParents(p)
  createSymlink(target, p)

proc makedev(major, minor: int): Dev =
  Dev((uint64(major and 0xfff) shl 8) or uint64(minor and 0xff) or
      (uint64(minor and not 0xff) shl 12) or (uint64(major and not 0xfff) shl 32))

proc doDevice(s: Settings; l: TmpLine) =
  let p = rp(s, l.path)
  let parts = l.arg.split(':')
  if parts.len != 2: fail("Can't parse device file major/minor '" & l.arg & "'.")
  let major = (try: parseInt(parts[0]) except ValueError: -1)
  let minor = (try: parseInt(parts[1]) except ValueError: -1)
  if major < 0 or minor < 0: fail("Can't parse device file major/minor '" & l.arg & "'.")
  var created = false
  if symlinkExists(p) or fileExists(p):
    if l.replace: removeFile(p)
    else:
      applyPerms(s, l, p, false, 0o644)
      return
  ensureParents(p)
  let kind = if l.typ == 'c': S_IFCHR else: S_IFBLK
  if mknod(p.cstring, Mode(int(kind) or (if modeOf(l) >= 0: modeOf(l) else: 0o644)), makedev(major, minor)) != 0:
    fail("Failed to create device node " & p & ": " & $strerror(errno))
  created = true
  applyPerms(s, l, p, created, 0o644)

proc adjust(s: Settings; l: TmpLine; recursive: bool) =
  for p in globPaths(s, l):
    if not (fileExists(p) or dirExists(p) or symlinkExists(p)): continue
    applyPerms(s, l, p, false, -1)
    if recursive and dirExists(p) and not symlinkExists(p):
      for q in walkDirRec(p, yieldFilter = {pcFile, pcDir, pcLinkToFile, pcLinkToDir}, followFilter = {pcDir}):
        applyPerms(s, l, q, false, -1)

proc doCopy(s: Settings; l: TmpLine) =
  let p = rp(s, l.path)
  let src = if l.arg.len > 0: l.arg else: "/usr/share/factory" / l.path.strip(chars = {'/'}, trailing = false)
  let sp = rp(s, src)
  if fileExists(p) or symlinkExists(p): return
  if dirExists(p) and toSeq(walkDir(p)).len > 0: return
  ensureParents(p)
  if dirExists(sp): copyDirWithPermissions(sp, p)
  elif fileExists(sp): copyFileWithPermissions(sp, p)
  else: return    # like systemd, a missing source is not an error (the units of Debian's UKI stub rely on it)
  applyPerms(s, l, p, true, -1)

proc remove(s: Settings; l: TmpLine; recursive: bool) =
  for p in globPaths(s, l):
    if symlinkExists(p) or fileExists(p): removeFile(p)
    elif dirExists(p):
      if recursive: removeDir(p)
      else:
        if rmdir(p.cstring) != 0 and errno notin [ENOTEMPTY, EEXIST]:
          fail("Failed to remove " & p & ": " & $strerror(errno))

proc emptyDirContents(p: string) =
  if not dirExists(p): return
  for k, q in walkDir(p):
    if k in {pcDir}: removeDir(q) else: removeFile(q)

# ---- cleaning -------------------------------------------------------------------
proc ageOf(l: TmpLine): tuple[usec: int64, by: string, skipTop: bool] =
  var a = l.age
  if a.startsWith("~"):
    result.skipTop = true
    a = a[1 .. ^1]
  if a.len > 2 and a[1] == ':':
    result.by = a[0 .. 0].toLowerAscii
    a = a[2 .. ^1]
  result.usec = parseTimespan(a).get(0)

proc cleanDir(s: Settings; top: string; cutoff: int64; by: string; skipTop: bool; excl: seq[string];
              exclTop: seq[string]; depth: int; dev: Dev): bool =
  ## True when the directory is empty after cleaning.
  result = true
  var entries: seq[string]
  for k, q in walkDir(top): entries.add q
  for q in entries:
    if q in excl or q in exclTop:
      result = false
      continue
    var st: Stat
    if lstat(q.cstring, st) != 0: continue
    if st.st_dev != dev:
      result = false
      continue
    let isDir = S_ISDIR(st.st_mode)
    var keep = false
    if isDir:
      let childEmpty = cleanDir(s, q, cutoff, by, skipTop, excl, exclTop, depth + 1, dev)
      keep = not childEmpty
    let at = int64(st.st_atim.tv_sec)
    let mt = int64(st.st_mtim.tv_sec)
    let ct = int64(st.st_ctim.tv_sec)
    var newest: int64
    if by.len > 0:
      newest = case by[0]
        of 'a': at
        of 'c': ct
        else: mt
    elif isDir: newest = max(at, mt)
    else: newest = max(at, max(mt, ct))
    if newest >= cutoff: keep = true
    if skipTop and depth == 0: keep = true
    if keep:
      result = false
      continue
    try:
      if isDir:
        if rmdir(q.cstring) != 0: result = false
      else: removeFile(q)
    except OSError: result = false

proc cleanItem(s: Settings; l: TmpLine; excl, exclTop: seq[string]) =
  if l.age == "-": return
  let (usec, by, skipTop) = ageOf(l)
  if usec == 0 and not l.age.endsWith("0") and l.age notin ["0"]: return
  for p in globPaths(s, l):
    if not dirExists(p) or symlinkExists(p): continue
    var st: Stat
    if stat(p.cstring, st) != 0: continue
    let cutoff = getTime().toUnix - usec div 1_000_000
    discard cleanDir(s, p, cutoff, by, skipTop, excl, exclTop, 0, st.st_dev)

# ---- driver ---------------------------------------------------------------------
proc pathMatches(path, prefix: string): bool =
  let pp = prefix.strip(chars = {'/'}, leading = false)
  path == pp or path.startsWith(pp & "/") or pp.len == 0

proc selected(s: Settings; p: string): bool =
  if s.prefixes.len > 0 and not s.prefixes.anyIt(pathMatches(p, it)): return false
  not s.excludes.anyIt(pathMatches(p, it))

proc readLines*(s: var Settings; files: seq[string]; items: var seq[TmpLine]) =
  var seen = initTable[string, string]()
  for f in files:
    var text: string
    try:
      text = if f == "-": stdin.readAll() else: readFile(f)
    except IOError:
      stderr.writeLine "Failed to open " & f
      inc s.parseErrors
      continue
    var n = 0
    for raw in text.splitLines:
      inc n
      var err = ""
      let l = parseLine(s, raw, f, n, err)
      if err.len > 0:
        stderr.writeLine f & ":" & $n & ": " & err
        inc s.parseErrors
        continue
      if l.isNone: continue
      let key = $l.get.typ & ":" & l.get.path
      if key in seen and l.get.typ notin {'w', 'a', 'A'}:
        stderr.writeLine f & ":" & $n & ": Duplicate line for path \"" & l.get.path & "\", ignoring."
        continue
      seen[key] = f
      items.add l.get

proc configDirs*(s: Settings; coreShare: string): seq[string] =
  if s.user:
    result = @[s.home / ".config/user-tmpfiles.d", "/etc/user-tmpfiles.d", "/usr/share/user-tmpfiles.d"]
  else:
    result = @[rp(s, "/etc/tmpfiles.d"), rp(s, "/run/tmpfiles.d"), rp(s, "/usr/local/lib/tmpfiles.d"),
               rp(s, "/usr/lib/tmpfiles.d")]
    if dirExists(rp(s, "/lib")) and not symlinkExists(rp(s, "/lib")) and
        not (dirExists(rp(s, "/usr/lib")) and (try: sameFile(rp(s, "/lib"), rp(s, "/usr/lib")) except OSError: false)):
      result.add rp(s, "/lib/tmpfiles.d")
    if coreShare.len > 0: result.add coreShare

proc discoverFiles*(dirs: seq[string]): seq[string] =
  var byName = initTable[string, string]()
  for d in dirs:
    if not dirExists(d): continue
    for k, p in walkDir(d):
      let n = p.extractFilename
      if not n.endsWith(".conf") or n in byName: continue
      byName[n] = p
  var names = toSeq(byName.keys)
  names.sort()
  for n in names:
    let p = byName[n]
    if symlinkExists(p) and (try: expandSymlink(p) == "/dev/null" except OSError: false): continue
    result.add p

proc runItems*(sv: var Settings; items: seq[TmpLine]) =
  let s = sv
  var errors = 0
  var sorted = items
  sorted.sort(proc(a, b: TmpLine): int = cmp(a.path, b.path))
  var excl, exclTop: seq[string]
  for l in sorted:
    if l.typ == 'x':
      excl.add rp(s, l.path)
    elif l.typ == 'X': exclTop.add rp(s, l.path)
  proc each(rev: bool; body: proc(l: TmpLine)) =
    for l in (if rev: sorted.reversed else: sorted):
      if l.bootOnly and not s.boot: continue
      if l.cred: continue
      if not selected(s, l.path): continue
      if s.dryRun:
        echo "Would process: " & $l.typ & " " & l.path
        continue
      try: body(l)
      except Fail, OSError, IOError, ValueError:
        if not l.ignoreErr:
          stderr.writeLine getCurrentExceptionMsg()
          inc errors
  if s.create:
    each(false, proc(l: TmpLine) =
      case l.typ
      of 'd', 'v', 'q', 'Q': doDir(s, l, l.typ)
      of 'D': doDir(s, l, 'D')
      of 'e':
        for p in globPaths(s, l):
          if dirExists(p): applyPerms(s, l, p, false, -1)
      of 'f': doFile(s, l, l.replace)
      of 'F': doFile(s, l, true)
      of 'w': doWrite(s, l)
      of 'p': doFifo(s, l)
      of 'L': doSymlink(s, l)
      of 'c', 'b': doDevice(s, l)
      of 'z': adjust(s, l, false)
      of 'Z': adjust(s, l, true)
      of 'C': doCopy(s, l)
      of 'a', 'A', 't', 'T', 'h', 'H':
        stderr.writeLine l.file & ":" & $l.line & ": Type '" & $l.typ & "' is not supported, skipping."
      else: discard)
  if s.remove:
    each(true, proc(l: TmpLine) =
      case l.typ
      of 'r': remove(s, l, false)
      of 'R': remove(s, l, true)
      of 'D': emptyDirContents(rp(s, l.path))
      else: discard)
  if s.clean:
    each(false, proc(l: TmpLine) =
      if l.typ in {'d', 'D', 'e', 'v', 'q', 'Q', 'C'}: cleanItem(s, l, excl, exclTop))
  sv.errors += errors

proc tmpfilesMain*(args: seq[string]): int =
  var s = Settings(uid: int(getuid()), gid: int(getgid()))
  var files: seq[string]
  for a in args:
    if a == "--create": s.create = true
    elif a == "--remove": s.remove = true
    elif a == "--clean": s.clean = true
    elif a == "--boot": s.boot = true
    elif a == "--dry-run": s.dryRun = true
    elif a == "--user": s.user = true
    elif a.startsWith("--root="): s.root = a[7 .. ^1].strip(chars = {'/'}, leading = false)
    elif a.startsWith("--prefix="): s.prefixes.add a[9 .. ^1]
    elif a.startsWith("--exclude-prefix="): s.excludes.add a[17 .. ^1]
    elif a in ["--graceful", "--no-pager", "--quiet"]: discard
    elif a in ["--help", "-h"]:
      echo "systemd-tmpfiles [OPTIONS...] [CONFIGURATION FILE...]\n\nCreate, clean up or remove files and directories."
      return 0
    elif a == "--version":
      echo "systemd 255 (255.0-jumpstart-core)"
      return 0
    elif a.startsWith("--"):
      stderr.writeLine "Unknown option: " & a
      return 1
    else: files.add a
  if not (s.create or s.remove or s.clean):
    stderr.writeLine "You need to specify at least one of --clean, --create or --remove."
    return 1
  try: s.hostname = getHostname() except CatchableError: discard
  s.home = getHomeDir().strip(chars = {'/'}, leading = false)
  if s.home.len == 0: s.home = "/"
  let pw = getpwuid(Uid(s.uid))
  if pw != nil: s.userName = $pw.pw_name
  let gr = getgrgid(Gid(s.gid))
  if gr != nil: s.groupName = $gr.gr_name
  s.machineId = (try: readFile(rp(s, "/etc/machine-id")).strip except IOError: "")
  s.bootId = (try: readFile("/proc/sys/kernel/random/boot_id").strip.replace("-", "") except IOError: "")
  var u: Utsname
  if uname(u) == 0: s.release = $cast[cstring](addr u.release[0])
  if files.len == 0:
    let share = block:
      let exe = getAppFilename()
      let c = exe.parentDir.parentDir / "share/tmpfiles.d"
      if dirExists(c): c else: ""
    files = discoverFiles(configDirs(s, share))
  var items: seq[TmpLine]
  readLines(s, files, items)
  runItems(s, items)
  if s.errors > 0: 1
  elif s.parseErrors > 0: 65
  else: 0
