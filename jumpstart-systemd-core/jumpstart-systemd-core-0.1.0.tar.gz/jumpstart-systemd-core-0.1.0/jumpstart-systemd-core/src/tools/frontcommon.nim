## Helpers shared by the front-end tools: manager discovery and
## time formatting.
import std/[os, strutils, posix]
import ../ipc/client
import ../unitfile/values

proc sockPathFor*(user, system: bool): string =
  let uid = int(geteuid())
  if user or (uid != 0 and not system):
    getEnv("XDG_RUNTIME_DIR", "/run/user/" & $uid) / "systemd/compat.sock"
  else: "/run/systemd/compat.sock"

proc connectOrDie*(user, system: bool): SdcClient =
  let path = sockPathFor(user, system)
  result = connect(path)
  if result == nil:
    let reason = $strerror(errno)
    if not dirExists("/run/systemd/system") and not fileExists(path):
      stderr.writeLine "System has not been booted with systemd as init system (PID 1). Can't operate."
    else:
      stderr.writeLine "Failed to connect to the manager: " & path & ": " & reason
    quit(1)

proc formatLocal*(usec: int64; fmt = "%a %Y-%m-%d %H:%M:%S %Z"; utc = false): string =
  if usec <= 0: return "n/a"
  var t = Time(usec div 1_000_000)
  var tmv: Tm
  if utc: discard gmtime_r(t, tmv) else: discard localtime_r(t, tmv)
  var buf = newString(96)
  let n = strftime(cstring(buf), 96, fmt.cstring, tmv)
  buf.setLen(int(n))
  buf

proc roughTimespan*(usec: int64): string =
  ## The two most significant units of `formatTimespan`.
  let parts = formatTimespan(max(usec, 0)).split(' ')
  parts[0 ..< min(2, parts.len)].join(" ")
