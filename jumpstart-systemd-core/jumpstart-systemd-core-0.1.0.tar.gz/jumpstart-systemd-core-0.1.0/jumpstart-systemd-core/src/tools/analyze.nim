## `systemd-analyze` (spec §15.7): verify, calendar, timespan, timestamp, time,
## blame, critical-chain, cat-config, unit-paths and a minimal security table.
import std/json except getStr, getInt, getBool
import std/[os, strutils, sequtils, algorithm, options, times, tables, sets]
import std/posix except Time
import ../common/[roots, names, jsonio]
import ../unitfile/[model, paths, validate, specifiers, values]
import ../units/calendar
import ../ipc/client
import ./frontcommon

const CalendarShorthands = {"minutely": "*-*-* *:*:00", "hourly": "*-*-* *:00:00", "daily": "*-*-* 00:00:00",
  "monthly": "*-*-01 00:00:00", "weekly": "Mon *-*-* 00:00:00", "yearly": "*-01-01 00:00:00",
  "annually": "*-01-01 00:00:00", "quarterly": "*-01,04,07,10-01 00:00:00",
  "semiannually": "*-01,07-01 00:00:00", "biannually": "*-01,07-01 00:00:00"}.toTable

proc pad2(s: string): string =
  if s.len == 1 and s[0] in Digits: "0" & s else: s

proc padParts(s: string; sep: char): string =
  s.split(sep).mapIt(it.split(',').mapIt(it.split("..").mapIt(pad2(it)).join("..")).join(",")).join($sep)

proc normalizeCalendar*(text: string): string =
  ## systemd's normalized form, computed textually.
  let t = text.strip
  if t.toLowerAscii in CalendarShorthands: return CalendarShorthands[t.toLowerAscii]
  var weekday, date, time, zone: string
  proc day3(d: string): string = (if d.len >= 3: d[0 ..< 3].capitalizeAscii else: d)
  for tok in t.splitWhitespace:
    if tok.toUpperAscii == "UTC" or ('/' in tok and ':' notin tok): zone = tok
    elif tok.allCharsInSet(Letters + {',', '.'}):
      weekday = tok.split(',').mapIt(it.split("..").map(day3).join("..")).join(",")
    elif ':' in tok: time = tok
    elif '-' in tok or tok == "*": date = tok
  if date.len > 0:
    let parts = date.split('-')
    case parts.len
    of 2: date = "*-" & padParts(date, '-')
    else: date = padParts(date, '-')
    if time.len == 0: time = "00:00:00"
  elif time.len > 0 or weekday.len > 0:
    date = "*-*-*"
    if time.len == 0: time = "00:00:00"
  if time.len > 0:
    let parts = time.split(':')
    if parts.len == 2: time = padParts(time, ':') & ":00" else: time = padParts(time, ':')
  result = (if weekday.len > 0: weekday & " " else: "") & date & " " & time
  if zone.len > 0: result.add " " & zone

proc leftOrAgo(usec, now: int64): string =
  let d = usec - now
  roughTimespan(abs(d)) & (if d >= 0: " left" else: " ago")

proc localIsUtc(): bool = formatLocal(0 + 86400_000_000, "%Z") in ["UTC", "GMT"]

proc calendarCmd(args: seq[string]; iterations: int): int =
  if args.len == 0:
    stderr.writeLine "Expected at least one calendar specification."
    return 1
  var first = true
  for a in args:
    if not first: echo ""
    first = false
    let p = parseCalendar(a)
    if p.isNone or not canElapse(p.get):
      stderr.writeLine "Failed to parse calendar specification '" & a & "'."
      stderr.writeLine "Invalid calendar specification, or it can never elapse."
      result = 1
      continue
    echo "  Original form: " & a
    echo "Normalized form: " & normalizeCalendar(a)
    var after = getTime().toUnix * 1_000_000
    let now = after
    for i in 1 .. max(1, iterations):
      let n = nextElapse(p.get, after)
      if n.isNone:
        echo (if i == 1: "    Next elapse: never" else: "        Iter. #" & $i & ": never")
        break
      let label = if i == 1: "    Next elapse: " else: "        Iter. #" & $i & ": "
      echo label & formatLocal(n.get)
      if not localIsUtc(): echo "       (in UTC): " & formatLocal(n.get, utc = true)
      if i == 1 or true: echo "       From now: " & leftOrAgo(n.get, now)
      after = n.get

proc timespanCmd(args: seq[string]): int =
  if args.len == 0:
    stderr.writeLine "Expected at least one time span."
    return 1
  for i, a in args:
    if i > 0: echo ""
    let v = parseTimespan(a)
    if v.isNone:
      stderr.writeLine "Failed to parse time span '" & a & "'."
      result = 1
      continue
    echo "Original: " & a
    echo "      \xCE\xBCs: " & $v.get
    echo "   Human: " & formatTimespan(v.get)

proc parseTimestamp*(text: string; now: int64): Option[int64] =
  ## Seconds since the epoch of the common `systemd.time` timestamp forms.
  let t = text.strip
  let day = now - now mod 86400
  case t
  of "now": return some(now)
  of "today": return some(day)
  of "yesterday": return some(day - 86400)
  of "tomorrow": return some(day + 86400)
  else: discard
  if t.startsWith("@"):
    try: return some(parseBiggestInt(t[1 .. ^1]))
    except ValueError: return none(int64)
  if t.endsWith(" ago"):
    let v = parseTimespan(t[0 ..< t.len - 4])
    if v.isSome: return some(now - v.get div 1_000_000)
  if t.startsWith("+") or t.startsWith("-"):
    let v = parseTimespan(t[1 .. ^1])
    if v.isSome: return some(now + (if t[0] == '+': 1 else: -1) * (v.get div 1_000_000))
  for f in ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd", "HH:mm:ss", "HH:mm"]:
    try:
      var dt = parse(t, f, utc())
      if f.startsWith("HH"):
        let n = fromUnix(now).utc
        dt = dateTime(n.year, n.month, n.monthday, dt.hour, dt.minute, dt.second, zone = utc())
      return some(dt.toTime.toUnix)
    except CatchableError: discard
  none(int64)

proc timestampCmd(args: seq[string]): int =
  if args.len == 0:
    stderr.writeLine "Expected at least one timestamp."
    return 1
  let now = getTime().toUnix
  for i, a in args:
    if i > 0: echo ""
    let v = parseTimestamp(a, now)
    if v.isNone:
      stderr.writeLine "Failed to parse timestamp '" & a & "'."
      result = 1
      continue
    echo "  Original form: " & a
    echo "Normalized form: " & formatLocal(v.get * 1_000_000)
    if not localIsUtc(): echo "       (in UTC): " & formatLocal(v.get * 1_000_000, utc = true)
    echo "   UNIX seconds: @" & $v.get
    echo "       From now: " & leftOrAgo(v.get * 1_000_000, now * 1_000_000)

proc verifyCmd(files: seq[string]; user: bool): int =
  if files.len == 0:
    stderr.writeLine "Too few arguments."
    return 1
  var roots = systemRoots()
  if user: roots.scope = scUser
  let env = newSpecifierEnv(roots)
  for f in files:
    let r = validateUnit(roots, f, env)
    for d in r.diagnostics:
      let file = if d.file.len > 0: d.file else: f
      echo file & (if d.line > 0: ":" & $d.line else: "") & ": " & d.message
    if not r.valid: result = 1

proc unitPathsCmd(user: bool): int =
  var roots = systemRoots()
  if user:
    roots.scope = scUser
    roots.home = getHomeDir().strip(chars = {'/'}, leading = false)
    roots.etc = roots.home / ".config"
    roots.sysrun = getEnv("XDG_RUNTIME_DIR", "/run/user/" & $getuid()) / "systemd"
  for d in unitSearchPath(roots):
    if d.role == drCore: continue
    echo d.path

proc catConfigCmd(args: seq[string]): int =
  if args.len == 0:
    stderr.writeLine "Too few arguments."
    return 1
  let r = systemRoots()
  let dirs = [r.etc, r.run, r.usrLib.parentDir / "local/lib", r.usrLib]
  var first = true
  for raw in args:
    let name = raw.strip(chars = {'/'}, trailing = false)
    var main = ""
    for d in dirs:
      if fileExists(d / name):
        main = d / name
        break
    var drop = initOrderedTable[string, string]()
    for d in dirs:
      let dd = d / (name & ".d")
      if not dirExists(dd): continue
      for k, p in walkDir(dd):
        if k in {pcFile, pcLinkToFile} and p.endsWith(".conf") and p.extractFilename notin drop:
          drop[p.extractFilename] = p
    if main.len == 0 and drop.len == 0:
      stderr.writeLine "Cannot find configuration file '" & raw & "'."
      result = 1
      continue
    var names = toSeq(drop.keys)
    names.sort()
    var files: seq[string]
    if main.len > 0: files.add main
    for n in names: files.add drop[n]
    for f in files:
      if not first: echo ""
      first = false
      echo "# " & f
      stdout.write readFile(f)

# ---- timing ---------------------------------------------------------------------
type TimeRow = object
  name: string
  activating, active: int64

proc fmtDur*(usec: int64): string =
  if usec < 1000: return $usec & "us"
  if usec < 1_000_000: return $(usec div 1000) & "ms"
  let totalMs = usec div 1000
  if usec < 60_000_000:
    return $(totalMs div 1000) & "." & align($(totalMs mod 1000), 3, '0') & "s"
  let mins = totalMs div 60_000
  let rest = totalMs mod 60_000
  $mins & "min " & $(rest div 1000) & "." & align($(rest mod 1000), 3, '0') & "s"

proc timingRows(c: SdcClient): tuple[userspace: int64, rows: seq[TimeRow]] =
  let r = c.request("timing")
  if not r.ok:
    stderr.writeLine r.message
    quit(1)
  result.userspace = r.result{"userspace_usec"}.getBiggestInt
  for u in r.result["units"]:
    result.rows.add TimeRow(name: u["name"].strVal, activating: u{"activating_usec"}.getBiggestInt,
      active: u{"active_usec"}.getBiggestInt)

proc timeCmd(c: SdcClient): int =
  let (user, rows) = timingRows(c)
  echo "Startup finished in " & fmtDur(user) & " (userspace) = " & fmtDur(user)
  let def = c.request("get-default")
  if def.ok:
    let n = def.result["name"].strVal
    for r in rows:
      if r.name == n and r.active > 0:
        echo n & " reached after " & fmtDur(r.active) & " in userspace."

proc blameCmd(c: SdcClient): int =
  var (_, rows) = timingRows(c)
  rows = rows.filterIt(it.active > 0 and it.activating > 0)
  rows.sort(proc(a, b: TimeRow): int = cmp(b.active - b.activating, a.active - a.activating))
  var w = 0
  for r in rows: w = max(w, fmtDur(r.active - r.activating).len)
  for r in rows: echo fmtDur(r.active - r.activating).align(w) & " " & r.name

proc afterOf(c: SdcClient; unit: string): seq[string] =
  let r = c.request("unit-show", %*{"names": [unit], "properties": ["After"]})
  if r.ok: result = r.result["units"][0]["properties"]{"After"}.strVal.splitWhitespace

proc criticalChainCmd(c: SdcClient; args: seq[string]): int =
  let (_, rows) = timingRows(c)
  var by = initTable[string, TimeRow]()
  for r in rows: by[r.name] = r
  var targets = args.mapIt(mangle(it))
  if targets.len == 0:
    let d = c.request("get-default")
    targets = @[(if d.ok: d.result["name"].strVal else: "default.target")]
  echo "The time when unit became active or started is printed after the \"@\" character."
  echo "The time the unit took to start is printed after the \"+\" character.\n"
  for t in targets:
    var chain: seq[string]
    var cur = t
    var seen = initHashSet[string]()
    while cur.len > 0 and cur notin seen:
      seen.incl cur
      chain.add cur
      var best = ""
      var bestT = 0'i64
      for dep in afterOf(c, cur):
        if dep in by and by[dep].active > bestT and dep notin seen:
          best = dep
          bestT = by[dep].active
      cur = best
    for i, n in chain:
      let r = by.getOrDefault(n)
      var line = n
      if r.active > 0:
        line.add " @" & fmtDur(r.active)
        if r.activating > 0 and r.active > r.activating: line.add " +" & fmtDur(r.active - r.activating)
      if i == 0: echo line
      else: echo repeat("  ", i - 1) & "\xe2\x94\x94\xe2\x94\x80" & line

# ---- security -------------------------------------------------------------------
type Check = tuple[prop, desc: string, weight: float, ok: proc(v: string): bool {.nimcall.}]

proc notEmptyNo(v: string): bool = v.len > 0 and v != "no" and v != "false"
proc isYes(v: string): bool = v in ["yes", "true", "1", "on"]
proc nonRoot(v: string): bool = v.len > 0 and v != "root" and v != "0"

let SecurityChecks: seq[Check] = @[
  ("User", "Service runs as a non-root user", 10.0, nonRoot),
  ("NoNewPrivileges", "Service processes cannot acquire new privileges", 10.0, isYes),
  ("PrivateTmp", "Service has no access to other software's temporary files", 6.0, isYes),
  ("PrivateNetwork", "Service has no access to the host's network", 8.0, isYes),
  ("PrivateDevices", "Service has no access to hardware devices", 6.0, isYes),
  ("ProtectSystem", "Service has strict read-only access to the OS file hierarchy", 10.0,
    proc(v: string): bool = v in ["yes", "full", "strict", "true"]),
  ("ProtectHome", "Service has no access to home directories", 10.0,
    proc(v: string): bool = v in ["yes", "read-only", "tmpfs", "true"]),
  ("ProtectKernelTunables", "Service cannot alter kernel tunables", 10.0, isYes),
  ("ProtectKernelModules", "Service cannot load or read kernel modules", 10.0, isYes),
  ("ProtectKernelLogs", "Service cannot read from or write to the kernel log ring buffer", 10.0, isYes),
  ("ProtectControlGroups", "Service cannot modify the control group file system", 10.0, isYes),
  ("ProtectClock", "Service cannot change the system clock", 10.0, isYes),
  ("ProtectHostname", "Service cannot change the hostname", 5.0, isYes),
  ("RestrictSUIDSGID", "Service cannot create SUID/SGID files", 10.0, isYes),
  ("RestrictRealtime", "Service realtime scheduling access is restricted", 10.0, isYes),
  ("RestrictNamespaces", "Service cannot create namespaces", 8.0, notEmptyNo),
  ("LockPersonality", "Service cannot change ABI personality", 5.0, isYes),
  ("MemoryDenyWriteExecute", "Service cannot create writable executable memory mappings", 10.0, isYes),
  ("SystemCallFilter", "Service system calls are filtered", 10.0, notEmptyNo),
  ("CapabilityBoundingSet", "Service capabilities are restricted", 10.0,
    proc(v: string): bool = v.len > 0 and v != "~" and "cap_sys_admin" notin v.toLowerAscii)]

proc verdict(e: float): string =
  if e >= 9.0: "UNSAFE" elif e >= 7.0: "EXPOSED" elif e >= 5.0: "MEDIUM" else: "OK"

proc securityOf(c: SdcClient; unit: string): tuple[exposure: float, missing: seq[int], props: JsonNode] =
  let r = c.request("unit-show", %*{"names": [unit], "all": true})
  let props = if r.ok: r.result["units"][0]["properties"] else: newJObject()
  var total, unmet = 0.0
  for i, ch in SecurityChecks:
    total += ch.weight
    var v = props{ch.prop}.strVal
    if ch.prop == "User" and props{"DynamicUser"}.strVal == "yes": v = "dynamic"
    if not ch.ok(v):
      unmet += ch.weight
      result.missing.add i
  result.exposure = if total > 0: 10.0 * unmet / total else: 10.0
  result.props = props

proc securityCmd(c: SdcClient; args: seq[string]): int =
  var units = args.mapIt(mangle(it))
  if units.len == 1:
    let (e, missing, _) = securityOf(c, units[0])
    echo "  NAME  DESCRIPTION" & repeat(" ", 52) & "EXPOSURE"
    for i, ch in SecurityChecks:
      echo (if i in missing: "\xe2\x9c\x97 " else: "\xe2\x9c\x93 ") & ch.prop & "=  " & ch.desc & " " &
        (if i in missing: formatFloat(ch.weight / 10.0, ffDecimal, 1) else: "")
    echo "\n\xe2\x86\x92 Overall exposure level for " & units[0] & ": " & formatFloat(e, ffDecimal, 1) & " " & verdict(e)
    return 0
  if units.len == 0:
    var rows: seq[JsonNode]
    discard c.request("unit-list", %*{"states": ["active"], "types": ["service"], "all": false},
      proc(x: JsonNode) = rows.add x)
    units = rows.mapIt(it["name"].strVal)
  echo "UNIT".alignLeft(40) & " EXPOSURE PREDICATE"
  for u in units:
    let (e, _, _) = securityOf(c, u)
    echo u.alignLeft(40) & " " & formatFloat(e, ffDecimal, 1).align(8) & " " & verdict(e)

proc analyzeMain*(args: seq[string]): int =
  var user, system = false
  var iterations = 1
  var pos: seq[string]
  for a in args:
    if a == "--user": user = true
    elif a == "--system": system = true
    elif a.startsWith("--iterations="): iterations = (try: parseInt(a.split('=')[1]) except ValueError: 1)
    elif a in ["--no-pager", "--no-legend", "--quiet", "-q", "--no-ask-password"]: discard
    elif a in ["--help", "-h"]:
      echo "systemd-analyze [OPTIONS...] COMMAND ...\n\nProfile systemd, show unit dependencies, check unit files."
      return 0
    elif a == "--version":
      echo "systemd 255 (255.0-jumpstart-core)"
      return 0
    else: pos.add a
  let verb = if pos.len > 0: pos[0] else: "time"
  let rest = if pos.len > 0: pos[1 .. ^1] else: @[]
  case verb
  of "calendar": return calendarCmd(rest, iterations)
  of "timespan": return timespanCmd(rest)
  of "timestamp": return timestampCmd(rest)
  of "verify": return verifyCmd(rest, user)
  of "unit-paths": return unitPathsCmd(user)
  of "cat-config": return catConfigCmd(rest)
  of "time", "blame", "critical-chain", "security":
    let c = connectOrDie(user, system)
    try:
      case verb
      of "time": return timeCmd(c)
      of "blame": return blameCmd(c)
      of "critical-chain": return criticalChainCmd(c, rest)
      else: return securityCmd(c, rest)
    except IOError as e:
      stderr.writeLine "Failed to talk to the manager: " & e.msg
      return 1
  else:
    stderr.writeLine "Unknown command '" & verb & "'."
    return 1
