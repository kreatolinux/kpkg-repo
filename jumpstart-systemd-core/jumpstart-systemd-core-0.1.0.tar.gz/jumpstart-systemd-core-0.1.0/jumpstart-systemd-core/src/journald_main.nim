## Entry point of `systemd-compat-journald` (section 12, Appendix C).
import journal/daemon

runJournald()
