## Pure parts of the service state machine (spec §9.1, §9.6, §9.10): sub-state
## names, exit classification, restart decision and delay. No manager access.
import std/[math]
import ../unitfile/model
import ../engine/types

type
  ServiceState* = enum
    svDead = "dead", svCondition = "condition", svStartPre = "start-pre", svStart = "start",
    svStartPost = "start-post", svRunning = "running", svExited = "exited",
    svReload = "reload", svReloadSignal = "reload-signal", svReloadNotify = "reload-notify",
    svStop = "stop", svStopWatchdog = "stop-watchdog", svStopSigterm = "stop-sigterm",
    svStopSigkill = "stop-sigkill", svStopPost = "stop-post",
    svFinalWatchdog = "final-watchdog", svFinalSigterm = "final-sigterm",
    svFinalSigkill = "final-sigkill", svFailed = "failed",
    svDeadBeforeAutoRestart = "dead-before-auto-restart",
    svFailedBeforeAutoRestart = "failed-before-auto-restart",
    svAutoRestart = "auto-restart", svAutoRestartQueued = "auto-restart-queued",
    svCleaning = "cleaning"

  ExitKind* = enum xkNone = "", xkExited = "exited", xkKilled = "killed", xkDumped = "dumped"
  ExitClass* = enum xcClean, xcUncleanExit, xcUncleanSignal, xcCoreDump, xcTimeout, xcWatchdog

proc activeStateOf*(s: ServiceState): ActiveState =
  case s
  of svDead: asInactive
  of svCondition, svStartPre, svStart, svStartPost, svAutoRestart, svAutoRestartQueued: asActivating
  of svRunning, svExited: asActive
  of svReload, svReloadSignal, svReloadNotify: asReloading
  of svStop, svStopWatchdog, svStopSigterm, svStopSigkill, svStopPost, svFinalWatchdog,
     svFinalSigterm, svFinalSigkill, svCleaning: asDeactivating
  of svFailed, svFailedBeforeAutoRestart: asFailed
  of svDeadBeforeAutoRestart: asInactive

proc isStopping*(s: ServiceState): bool = activeStateOf(s) == asDeactivating
proc isStarting*(s: ServiceState): bool = s in {svCondition, svStartPre, svStart, svStartPost}

proc isSuccessSignal(sig: int; set: ExitSet): bool =
  sig in [1, 2, 15, 13] or (sig in 1 .. 255 and uint8(sig) in set.signals)

proc classifyExit*(kind: ExitKind; code: int; success: ExitSet): ExitClass =
  ## §9.6: clean exit, unclean exit, unclean signal, core dump.
  case kind
  of xkExited:
    if code == 0 or (code in 0 .. 255 and uint8(code) in success.statuses): xcClean else: xcUncleanExit
  of xkKilled: (if isSuccessSignal(code, success): xcClean else: xcUncleanSignal)
  of xkDumped: xcCoreDump
  of xkNone: xcUncleanExit

proc resultOfExit*(kind: ExitKind; code: int; success: ExitSet): string =
  ## The unit `Result=` a main or control process end implies.
  case classifyExit(kind, code, success)
  of xcClean: "success"
  of xcUncleanExit: "exit-code"
  of xcUncleanSignal: "signal"
  of xcCoreDump: "core-dump"
  of xcTimeout: "timeout"
  of xcWatchdog: "watchdog"

proc inExitSet(kind: ExitKind; code: int; set: ExitSet): bool =
  case kind
  of xkExited: code in 0 .. 255 and uint8(code) in set.statuses
  of xkKilled, xkDumped: code in 1 .. 255 and uint8(code) in set.signals
  of xkNone: false

proc shouldRestart*(policy: RestartPolicy; cls: ExitClass; kind: ExitKind; code: int;
                    prevent, force: ExitSet): bool =
  ## The table of §9.6 with the prevent/force overrides (prevent wins).
  if inExitSet(kind, code, prevent): return false
  if inExitSet(kind, code, force): return true
  case policy
  of rpNo: false
  of rpOnSuccess: cls == xcClean
  of rpOnFailure: cls != xcClean
  of rpOnAbnormal: cls in {xcUncleanSignal, xcCoreDump, xcTimeout, xcWatchdog}
  of rpOnAbort: cls in {xcUncleanSignal, xcCoreDump}
  of rpOnWatchdog: cls == xcWatchdog
  of rpAlways: true

proc restartDelayUsec*(restartUsec, maxDelayUsec: int64; steps, k: int): int64 =
  ## Delay before the k-th (1-based) consecutive automatic restart.
  if steps <= 0 or maxDelayUsec <= restartUsec or restartUsec <= 0: return restartUsec
  let frac = float(min(k, steps)) / float(steps)
  int64(round(float(restartUsec) * pow(float(maxDelayUsec) / float(restartUsec), frac)))

proc signalName*(sig: int): string =
  case sig
  of 1: "HUP"
  of 2: "INT"
  of 3: "QUIT"
  of 4: "ILL"
  of 6: "ABRT"
  of 7: "BUS"
  of 8: "FPE"
  of 9: "KILL"
  of 10: "USR1"
  of 11: "SEGV"
  of 12: "USR2"
  of 13: "PIPE"
  of 14: "ALRM"
  of 15: "TERM"
  of 18: "CONT"
  of 19: "STOP"
  else: $sig

proc exitCodeFor*(kind: ExitKind; code: int): int =
  ## What Jumpstart's `exit_code` reports: the status, or 128 + signal.
  case kind
  of xkExited: code
  of xkKilled, xkDumped: 128 + code
  of xkNone: -1

proc statusWord*(kind: ExitKind; code: int): string =
  ## `status=0/SUCCESS` or `status=15/TERM` as `systemctl status` prints it.
  case kind
  of xkExited: $code & (if code == 0: "/SUCCESS" else: "/FAILURE")
  of xkKilled, xkDumped: $code & "/" & signalName(code)
  of xkNone: ""
