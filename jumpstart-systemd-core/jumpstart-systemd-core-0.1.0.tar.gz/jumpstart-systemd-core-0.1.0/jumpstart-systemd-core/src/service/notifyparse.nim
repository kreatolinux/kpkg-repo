## sd_notify datagram parsing (spec §9.9). Pure.
import std/[options, strutils]

type
  WatchdogKind* = enum wdNone, wdPing, wdTrigger
  NotifyMessage* = object
    ready*, reloading*, stopping*, fdStore*, fdStoreRemove*, barrier*: bool
    status*: Option[string]
    mainPid*: Option[int]
    errNo*: Option[int]
    watchdog*: WatchdogKind
    watchdogUsec*, extendTimeoutUsec*, monotonicUsec*: Option[int64]
    fdName*, notifyAccess*: Option[string]

const
  MaxDatagram* = 4096
  MaxStatusDisplay* = 255
  MaxTimeoutExtensionUsec* = 24'i64 * 3600 * 1_000_000

proc parseInt64(s: string): Option[int64] =
  try: some(parseBiggestInt(s.strip))
  except ValueError: none(int64)

proc sanitizeStatus*(s: string): string =
  ## Control characters become spaces; truncated to 255 bytes at a UTF-8 boundary.
  for c in s: result.add (if c < ' ' or c == '\x7f': ' ' else: c)
  if result.len > MaxStatusDisplay:
    var n = MaxStatusDisplay
    while n > 0 and (ord(result[n]) and 0xC0) == 0x80: dec n
    result.setLen n

proc parseNotify*(datagram: string): NotifyMessage =
  ## Lines without `=` are ignored, unknown keys too. A datagram larger than
  ## `MaxDatagram` yields an empty message (callers drop it).
  if datagram.len > MaxDatagram: return
  for line in datagram.split('\n'):
    let eq = line.find('=')
    if eq <= 0: continue
    let (k, v) = (line[0 ..< eq], line[eq + 1 .. ^1])
    case k
    of "READY": result.ready = v == "1"
    of "RELOADING": result.reloading = v == "1"
    of "STOPPING": result.stopping = v == "1"
    of "STATUS": result.status = some(v)
    of "MAINPID":
      let n = parseInt64(v)
      if n.isSome and n.get > 0 and n.get < 1 shl 22: result.mainPid = some(int(n.get))
    of "ERRNO":
      let n = parseInt64(v)
      if n.isSome: result.errNo = some(int(n.get))
    of "WATCHDOG":
      if v == "1": result.watchdog = wdPing
      elif v == "trigger": result.watchdog = wdTrigger
    of "WATCHDOG_USEC": result.watchdogUsec = parseInt64(v)
    of "EXTEND_TIMEOUT_USEC":
      let n = parseInt64(v)
      if n.isSome and n.get > 0: result.extendTimeoutUsec = some(min(n.get, MaxTimeoutExtensionUsec))
    of "MONOTONIC_USEC": result.monotonicUsec = parseInt64(v)
    of "FDSTORE": result.fdStore = v == "1"
    of "FDSTOREREMOVE": result.fdStoreRemove = v == "1"
    of "FDNAME": result.fdName = some(v)
    of "NOTIFYACCESS": result.notifyAccess = some(v)
    of "BARRIER": result.barrier = v == "1"
    else: discard
