## Starts the executor for one unit process (spec §10.1): verified executable,
## sealed-in-memory exec context, status pipe, unit cgroup placement, passed
## descriptors. The only spawn site of unit processes.
import std/[os, posix, options, strutils]
import jumpstartcore/[reaper, spawn]
import ../executor/context

when defined(linux):
  proc syscall(n: clong): clong {.importc, header: "<unistd.h>", varargs.}

const
  ContextFd* = 100
  StatusFd* = 101

type
  ExecHandle* = ref object
    pid*: Pid
    statusFd*: cint          ## read end; EOF without data = setup finished, execve done

proc makeContextFd(text: string): cint =
  ## An anonymous, immutable-ish file holding the context: memfd on Linux, an
  ## unlinked temporary file elsewhere. Never visible in the file system.
  when defined(linux):
    var fd = cint(syscall(when defined(arm64): 279 else: 319, cstring"sdc-context", 1))  # MFD_CLOEXEC
    if fd < 0: raiseOSError(osLastError())
  else:
    var tmpl = getTempDir() / "sdc-context-XXXXXX"
    let fd = mkstemp(cstring(tmpl))
    if fd < 0: raiseOSError(osLastError())
    discard unlink(cstring(tmpl))
  var done = 0
  while done < text.len:
    let n = write(fd, unsafeAddr text[done], text.len - done)
    if n <= 0: raiseOSError(osLastError())
    done += n
  discard lseek(fd, 0, SEEK_SET)
  fd

proc spawnExec*(r: Reaper; executorPath: string; trustedUid: Uid; beneath: string;
                spec: ExecSpec; stdio: array[3, cint]; passFds: seq[PassedFd];
                cgroupProcs: string; owner: string; onExit: ChildCallback): ExecHandle =
  ## `stdio` descriptors become 0..2 in the executor (the caller keeps them).
  ## Raises SpawnError / OSError / ValueError; nothing is leaked on failure.
  var exe = openVerifiedExecutable(executorPath, trustedUid, beneath)
  defer: exe.close()
  var ctx = spec
  ctx.statusFd = StatusFd
  ctx.version = ContextVersion
  let ctxFd = makeContextFd(toContextJson(ctx))
  var pipeFds: array[2, cint]
  if pipe(pipeFds) != 0:
    discard close(ctxFd)
    raiseOSError(osLastError())
  discard fcntl(pipeFds[0], F_SETFD, FD_CLOEXEC)
  var ps = ProcessSpec(executable: executorPath, executableFd: some(exe.fd),
    arguments: @["--context-fd", $ContextFd],
    environment: @[("PATH", "/usr/bin:/bin")], workingDirectory: "/",
    cgroupProcs: cgroupProcs, explicitStdio: some(stdio),
    passFds: passFds & @[(ctxFd, cint(ContextFd)), (pipeFds[1], cint(StatusFd))])
  try:
    let sp = spawn.spawn(ps, r, owner, onExit)
    result = ExecHandle(pid: sp.pid, statusFd: pipeFds[0])
  except CatchableError:
    discard close(pipeFds[0])
    raise
  finally:
    discard close(ctxFd)
    discard close(pipeFds[1])

proc readExecFailure*(h: ExecHandle): Option[(int, string)] =
  ## Drains the status pipe (non-blocking use: call after EOF/readability).
  ## `some((status, step))` when the executor reported a setup failure.
  var buf = newString(256)
  let n = read(h.statusFd, addr buf[0], buf.len)
  if n <= 0: return none((int, string))
  let parts = buf[0 ..< n].splitWhitespace()
  if parts.len >= 2:
    try: return some((parseInt(parts[0]), parts[1]))
    except ValueError: discard
  none((int, string))

proc closeStatus*(h: ExecHandle) =
  if h.statusFd >= 0:
    discard close(h.statusFd)
    h.statusFd = -1
