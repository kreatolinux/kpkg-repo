## Builds the executor's `ExecSpec` (executor/context.nim) from a unit's
## `ExecContext`, one command, and the runtime facts only the manager knows
## (spec §10.1.1, §10.2, §9.3.2).
import std/[options, strutils, tables, os]
import ../common/[roots, logging]
import ../unitfile/model
import ../executor/context as ex
import ../executor/seccomp as sc
import ../engine/types

type RunFacts* = object
  ## What the manager knows about this particular run.
  unit*: string
  invocationId*: string
  kind*: ExecKind
  mainPid*: int
  serviceResult*, exitCode*, exitStatus*: string
  watchdogUsec*: int64
  extraEnv*: seq[(string, string)]
  fds*: seq[ex.FdSpec]
  journalStream*: string                ## `DEV:INO` when stdout/stderr is the journal
  expectedCgroup*: string
  inheritedStdio*: array[3, bool]

const
  ProtectedNames = ["NOTIFY_SOCKET", "LISTEN_PID", "LISTEN_FDS", "LISTEN_FDNAMES", "INVOCATION_ID",
                    "WATCHDOG_PID", "WATCHDOG_USEC", "MAINPID", "MANAGERPID"]

proc ioClass(s: string): Option[int] =
  case s
  of "none": some(0)
  of "realtime": some(1)
  of "best-effort": some(2)
  of "idle": some(3)
  else: none(int)

proc stdioOf(s: model.StdioSpec; inherited: bool): ex.StdioSpec =
  let kind = case s.kind
    of sioNull: "null"
    of sioTty, sioTtyForce, sioTtyFail: "tty"
    of sioFile: "file"
    of sioAppend: "append"
    of sioTruncate: "truncate"
    of sioSocket: "socket"
    of sioJournal, sioJournalConsole, sioSyslog, sioSyslogConsole, sioKmsg, sioKmsgConsole: "journal"
    else: "inherit"
  ex.StdioSpec(kind: kind, path: s.path, inherited: inherited)

proc dirSpec(names: seq[string]; mode: int): DirSpec =
  for n in names: result.names.add n.split(':')[0]
  result.mode = mode

proc nativeArch(w: string): bool = w == "native" or w == sc.NativeArchName

proc unsupportedFor*(c: ExecContext; scope: Scope): seq[string] =
  ## Confinement settings this release cannot apply (spec §2.5, §10.4, §10.7):
  ## the unit fails closed instead of running unconfined. Everything else in
  ## those sections is applied by the executor (sandbox.nim, caps.nim, seccomp.nim).
  template ns(name: string; cond: bool) =
    if cond: result.add "NAMESPACE:" & name
  template sec(step, name: string; cond: bool) =
    if cond: result.add step & ":" & name
  ns "PrivateUsers=yes (user namespaces with an id mapping are not implemented)", c.privateUsers
  ns "DynamicUser=yes (needs the system scope: a user manager cannot switch uids)",
    c.dynamicUser and scope == scUser
  var foreign: seq[string]
  for w in c.systemCallArchitectures:
    if not nativeArch(w): foreign.add w
  sec "SECCOMP", "SystemCallArchitectures=" & foreign.join(" ") & " (only the native architecture is supported)",
    foreign.len > 0

proc sandboxOf*(c: ExecContext; r: Roots; kind: ExecKind): ex.SandboxSpec =
  result = ex.SandboxSpec(
    rootDirectory: if c.rootDirectoryStartOnly and kind != ekStart: "" else: c.rootDirectory,
    mountApiVfs: c.mountAPIVFS,
    bindPaths: c.bindPaths, bindReadOnlyPaths: c.bindReadOnlyPaths,
    temporaryFileSystem: c.temporaryFileSystem, readWritePaths: c.readWritePaths,
    readOnlyPaths: c.readOnlyPaths, inaccessiblePaths: c.inaccessiblePaths,
    execPaths: c.execPaths, noExecPaths: c.noExecPaths,
    protectSystem: if c.protectSystem == psNo: "" else: $c.protectSystem,
    protectHome: if c.protectHome == phNo: "" else: $c.protectHome,
    protectProc: if c.protectProc == ppDefault: "" else: $c.protectProc,
    procSubset: if c.procSubset == pssAll: "" else: $c.procSubset,
    mountFlags: c.mountFlags,
    privateTmp: c.privateTmp, privateDevices: c.privateDevices, privateMounts: c.privateMounts,
    privateIpc: c.privateIPC, privateNetwork: c.privateNetwork,
    protectKernelTunables: c.protectKernelTunables, protectKernelModules: c.protectKernelModules,
    protectKernelLogs: c.protectKernelLogs, protectControlGroups: c.protectControlGroups,
    protectClock: c.protectClock, protectHostname: c.protectHostname,
    networkNamespacePath: c.networkNamespacePath, ipcNamespacePath: c.ipcNamespacePath,
    sysrun: r.sysrun)
  if result.rootDirectory.len > 0:
    result.extraBinds = @[r.sysrun / "journal", r.sysrun / "notify"]

proc buildSpec*(m: Manager; u: Unit; cmd: ExecCommand; ctx: ExecContext; facts: RunFacts): ExecSpec =
  let r = m.roots
  var c = ctx
  if c.dynamicUser:                    # settings DynamicUser= implies (§10.6); "no" cannot be told from unset
    c.privateTmp = true
    if c.protectSystem == psNo: c.protectSystem = psStrict
    if c.protectHome == phNo: c.protectHome = phReadOnly
    c.noNewPrivileges = true
    c.restrictSUIDSGID = true
  result = ExecSpec(version: ex.ContextVersion, unit: facts.unit, invocationId: facts.invocationId,
    scope: if r.scope == scUser: "user" else: "system", kind: $facts.kind,
    path: cmd.path, argv0: cmd.argv0, args: cmd.args,
    noEnvSubst: efColon in cmd.flags, privileged: efPlus in cmd.flags,
    skipIdentity: cmd.flags * {efPlus, efBang} != {} or r.scope == scUser,
    umask: c.umask, ignoreSigpipe: c.ignoreSIGPIPE, noNewPrivileges: c.noNewPrivileges,
    workingDirectory: c.workingDirectory, user: c.user, group: c.group,
    supplementaryGroups: c.supplementaryGroups, expectedCgroup: facts.expectedCgroup,
    environmentFiles: c.environmentFile, passEnvironment: c.passEnvironment,
    unsetEnvironment: c.unsetEnvironment, fds: facts.fds, listenFds: facts.fds.len > 0,
    ttyReset: c.ttyReset, ttyVhangup: c.ttyVHangup, dynamicUser: c.dynamicUser,
    dynamicUsersDir: r.st / "dynamic-users",
    credentials: ex.CredentialSpec(root: (if r.scope == scUser: r.runtime else: r.run) / "credentials",
      loadCredential: c.loadCredential, setCredential: c.setCredential, importCredential: c.importCredential))
  # environment: manager, Environment=, specials last so they win
  for k, v in m.env: result.managerEnvironment.add (k, v); result.environment.add (k, v)
  for entry in c.environment:
    let eq = entry.find('=')
    if eq > 0: result.environment.add (entry[0 ..< eq], entry[eq + 1 .. ^1])
  template special(k, v: string) =
    result.environment.add (k, v)
    result.protectedEnv.add k
  special "INVOCATION_ID", facts.invocationId
  special "NOTIFY_SOCKET", r.sysrun / "notify"
  special "MANAGERPID", $os.getCurrentProcessId()
  if facts.mainPid > 0 and facts.kind in {ekStartPost, ekReload, ekStop, ekStopPost}:
    special "MAINPID", $facts.mainPid
  if facts.kind == ekStopPost:
    if facts.serviceResult.len > 0: result.environment.add ("SERVICE_RESULT", facts.serviceResult)
    if facts.exitCode.len > 0: result.environment.add ("EXIT_CODE", facts.exitCode)
    if facts.exitStatus.len > 0: result.environment.add ("EXIT_STATUS", facts.exitStatus)
  if facts.watchdogUsec > 0 and facts.kind == ekStart:
    special "WATCHDOG_USEC", $facts.watchdogUsec
  if facts.journalStream.len > 0: result.environment.add ("JOURNAL_STREAM", facts.journalStream)
  for (k, v) in facts.extraEnv: result.environment.add (k, v)
  if u.id == "systemd-journald.service":          # §12.1 handoff, journald only
    for (k, v) in [("SDC_RUNTIME_DIR", r.rt), ("SDC_STATE_DIR", r.st), ("SDC_SYSRUN", r.sysrun),
                   ("SDC_UNITS_CGROUP", r.unitsCgroup), ("SDC_SCOPE", (if r.scope == scUser: "user" else: "system"))]:
      result.environment.add (k, v)
  if r.scope == scUser:
    let xdg = getEnv("XDG_RUNTIME_DIR", r.runtime)
    result.environment.add ("XDG_RUNTIME_DIR", xdg)
  # scheduling, limits
  result.nice = c.nice
  result.oomScoreAdjust = c.oomScoreAdjust
  result.ioSchedulingClass = ioClass(c.ioSchedulingClass)
  result.ioSchedulingPriority = c.ioSchedulingPriority
  if c.cpuSchedulingPolicy.isSome:
    result.cpuSchedulingPolicy = some(case c.cpuSchedulingPolicy.get
      of spOther: 0
      of spFifo: 1
      of spRr: 2
      of spBatch: 3
      of spIdle: 5)
    result.cpuSchedulingPriority = some(c.cpuSchedulingPriority.get(0))
  result.cpuSchedulingResetOnFork = c.cpuSchedulingResetOnFork
  if c.timerSlackNSec >= 0: result.timerSlackNsec = some(c.timerSlackNSec)
  var haveNofile = false
  for l in m.conf.defaultLimits & c.limits:
    if l.resource == "NOFILE": haveNofile = true
    result.limits.add ex.LimitSpec(resource: l.resource,
      soft: if l.soft == Infinity: -1 else: l.soft, hard: if l.hard == Infinity: -1 else: l.hard)
  if not haveNofile:
    result.limits.add ex.LimitSpec(resource: "NOFILE", soft: 1024, hard: 524288)
  # directories (§10.5)
  result.runtimeRoot = if r.scope == scUser: r.runtime else: r.run
  result.stateRoot = r.varLib
  result.cacheRoot = r.varCache
  result.logsRoot = r.varLog
  result.configRoot = r.etc
  result.runtimeDirectory = dirSpec(c.runtimeDirectory, c.runtimeDirectoryMode)
  result.stateDirectory = dirSpec(c.stateDirectory, c.stateDirectoryMode)
  result.cacheDirectory = dirSpec(c.cacheDirectory, c.cacheDirectoryMode)
  result.logsDirectory = dirSpec(c.logsDirectory, c.logsDirectoryMode)
  result.configurationDirectory = dirSpec(c.configurationDirectory, c.configurationDirectoryMode)
  # stdio
  result.stdin = stdioOf(c.standardInput, facts.inheritedStdio[0])
  result.stdout = stdioOf(c.standardOutput, facts.inheritedStdio[1])
  result.stderr = stdioOf(c.standardError, facts.inheritedStdio[2])
  if c.ttyPath.len > 0:
    for s in [addr result.stdin, addr result.stdout, addr result.stderr]:
      if s.kind == "tty" and s.path.len == 0: s.path = c.ttyPath
  if cmd.flags.contains(efPlus):
    result.unsupported = @[]
  else:
    result.sandbox = sandboxOf(c, r, facts.kind)
    result.capabilityBoundingSet = c.capabilityBoundingSet
    result.ambientCapabilities = c.ambientCapabilities
    result.secureBits = c.secureBits
    result.seccomp = ex.SeccompSpec(systemCallFilter: c.systemCallFilter,
      systemCallErrorNumber: c.systemCallErrorNumber, systemCallArchitectures: c.systemCallArchitectures,
      restrictAddressFamilies: c.restrictAddressFamilies,
      restrictNamespaces: if c.restrictNamespaces == @["no"]: @[] else: c.restrictNamespaces,
      memoryDenyWriteExecute: c.memoryDenyWriteExecute, lockPersonality: c.lockPersonality,
      restrictRealtime: c.restrictRealtime, restrictSuidSgid: c.restrictSUIDSGID)
    result.unsupported = unsupportedFor(c, r.scope)
    if result.unsupported.len > 0:
      logWarn(u.id, "unit uses settings this release cannot apply: " & result.unsupported.join(", "))
