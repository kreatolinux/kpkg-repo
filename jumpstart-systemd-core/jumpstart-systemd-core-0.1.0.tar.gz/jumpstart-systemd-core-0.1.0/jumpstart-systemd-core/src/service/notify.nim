## The sd_notify datagram socket (spec §9.9): one `SOCK_DGRAM` socket for all
## units, sender credentials from `SCM_CREDENTIALS`, sender -> unit mapping
## by the manager's process table first and the cgroup second.
import std/[posix, options, tables]
import ../engine/[types]
import ./cgroupmgr
when defined(linux):
  import std/os
  import ../common/[roots, fdutil, logging]
  import ../engine/eventloop

when defined(linux):
  {.emit: """
  #define _GNU_SOURCE
  #include <sys/types.h>
  #include <sys/socket.h>
  #include <string.h>
  #include <errno.h>
  /* Receives one datagram. Returns its length, or -1 (errno set). `pid` is -1
     when the kernel passed no credentials; received descriptors are stored in
     `fds` (at most `maxfds`) and counted in `nfds`. */
  static int sdc_recv(int fd, char *buf, int len, int *pid, int *fds, int maxfds, int *nfds) {
    struct iovec iov = { buf, (size_t)len };
    char ctl[CMSG_SPACE(sizeof(struct ucred)) + CMSG_SPACE(sizeof(int) * 64)];
    struct msghdr msg;
    memset(&msg, 0, sizeof msg);
    msg.msg_iov = &iov; msg.msg_iovlen = 1;
    msg.msg_control = ctl; msg.msg_controllen = sizeof ctl;
    ssize_t n = recvmsg(fd, &msg, MSG_DONTWAIT | MSG_CMSG_CLOEXEC);
    *pid = -1; *nfds = 0;
    if (n < 0) return -1;
    if (msg.msg_flags & MSG_TRUNC) n = len + 1;
    for (struct cmsghdr *c = CMSG_FIRSTHDR(&msg); c; c = CMSG_NXTHDR(&msg, c)) {
      if (c->cmsg_level != SOL_SOCKET) continue;
      if (c->cmsg_type == SCM_CREDENTIALS) {
        struct ucred u; memcpy(&u, CMSG_DATA(c), sizeof u); *pid = u.pid;
      } else if (c->cmsg_type == SCM_RIGHTS) {
        int cnt = (int)((c->cmsg_len - CMSG_LEN(0)) / sizeof(int));
        for (int i = 0; i < cnt; i++) {
          int f; memcpy(&f, CMSG_DATA(c) + i * sizeof(int), sizeof f);
          if (*nfds < maxfds) fds[(*nfds)++] = f; else close(f);
        }
      }
    }
    return (int)n;
  }
  """.}

when defined(linux):
  const
    SO_PASSCRED = 16.cint
    SO_RCVBUFFORCE = 33.cint
  proc sdcRecv(fd: cint; buf: ptr char; len: cint; pid: ptr cint; fds: ptr cint; maxfds: cint;
               nfds: ptr cint): cint {.importc: "sdc_recv", nodecl.}

const MaxNotifyBytes = 4096

proc ownerOf*(m: Manager; pid: int): string =
  ## Unit that owns `pid`: the process table, then the cgroup.
  result = m.pids.getOrDefault(pid)
  if result.len == 0:
    let o = m.ownerOfPid(pid)
    if o.isSome: result = o.get

proc dispatch*(m: Manager; pid: int; datagram: string; fds: seq[cint]) =
  ## Delivers one datagram from `pid` to the owning unit's handler.
  if pid <= 0:
    for f in fds: discard close(f)
    return
  let id = m.ownerOf(pid)
  let u = if id.len > 0: m.units.getOrDefault(id) else: nil
  if u == nil or m.notifyHandler == nil:
    for f in fds: discard close(f)
    return
  m.notifyHandler(m, u, pid, datagram, fds)

when defined(linux):
  proc startNotifySocket*(m: Manager): cint =
    ## Binds `SYSRUN/notify` (mode 0777). Returns the descriptor (-1 on failure).
    let path = m.roots.sysrun / "notify"
    createDir(m.roots.sysrun)
    discard unlink(path.cstring)
    let fd = (try: bindUnix(path, false, 0o777) except ValueError: -1.cint)
    if fd < 0:
      logErr("", "cannot bind " & path & ": " & $strerror(errno))
      return -1
    var one: cint = 1
    discard setsockopt(SocketHandle(fd), SOL_SOCKET, SO_PASSCRED, addr one, SockLen(sizeof(one)))
    var rcv: cint = 8 * 1024 * 1024
    discard setsockopt(SocketHandle(fd), SOL_SOCKET, SO_RCVBUFFORCE, addr rcv, SockLen(sizeof(rcv)))
    discard m.loop.addFd(fd, EvIn, proc(ev: uint32) =
      var buf = newString(MaxNotifyBytes + 1)
      for _ in 0 ..< 64:
        var pid, nfds: cint
        var fds: array[64, cint]
        let n = sdcRecv(fd, addr buf[0], cint(buf.len), addr pid, addr fds[0], 64, addr nfds)
        if n < 0: break
        var received: seq[cint]
        for i in 0 ..< int(nfds): received.add fds[i]
        if n > MaxNotifyBytes:
          for f in received: discard close(f)
          continue
        m.dispatch(int(pid), buf[0 ..< n], received))
    fd
else:
  proc startNotifySocket*(m: Manager): cint = -1
