## The only way anything starts a process for a unit (spec §18.2.4): resolves
## the standard descriptors in the manager, builds the exec context, spawns
## the executor into the unit's cgroup and reports exec success/failure and
## the exit through callbacks.
import std/[options, os, posix, strutils]
import jumpstartcore/[reaper, spawn]
import ../common/[roots, logging]
import ../unitfile/model
import ../executor/context as ex
import ../journal/[client, intake_stream]
import ../engine/[types, eventloop]
import ./[execcontext, spawnexec, cgroupmgr]

type
  PassedFdSpec* = object
    source*: cint
    name*: string
  RunOptions* = object
    kind*: ExecKind
    facts*: RunFacts
    fds*: seq[PassedFdSpec]       ## socket-activation / stored descriptors, passed at 3..
    socketFd*: cint = -1          ## `StandardInput=socket` (Accept=yes)
  RunHandle* = ref object
    pid*: Pid
    exec: ExecHandle
    watch: WatchId
    loop: EventLoop
    execFailure*: Option[(int, string)]

proc priorityOf(s: string): int =
  case s
  of "emerg": 0
  of "alert": 1
  of "crit": 2
  of "err": 3
  of "warning": 4
  of "notice": 5
  of "info": 6
  of "debug": 7
  else: 6

proc facilityOf(s: string): int =
  case s
  of "kern": 0
  of "user": 1
  of "mail": 2
  of "daemon": 3
  of "auth": 4
  of "syslog": 5
  of "lpr": 6
  of "news": 7
  of "uucp": 8
  of "cron": 9
  of "authpriv": 10
  of "ftp": 11
  else: 3

proc openJournal(m: Manager; u: Unit; c: ExecContext; cmdPath: string; kind: StdioKind): cint =
  var h = defaultHeader()
  h.identifier = if c.syslogIdentifier.len > 0: c.syslogIdentifier else: cmdPath.extractFilename
  h.unit = u.id
  h.priority = priorityOf(c.syslogLevel)
  h.levelPrefix = c.syslogLevelPrefix
  h.facility = facilityOf(c.syslogFacility)
  h.forwardConsole = kind in {sioJournalConsole, sioKmsgConsole, sioSyslogConsole}
  h.forwardKmsg = kind in {sioKmsg, sioKmsgConsole}
  h.forwardSyslog = kind in {sioSyslog, sioSyslogConsole}
  if c.logLevelMax.len > 0: h.levelMax = priorityOf(c.logLevelMax)
  for f in c.logExtraFields:
    let eq = f.find('=')
    if eq > 0: h.extraFields.add (f[0 ..< eq], f[eq + 1 .. ^1])
  if c.logRateLimitIntervalSec != UnsetInt: h.rateIntervalUsec = c.logRateLimitIntervalSec
  if c.logRateLimitBurst != UnsetInt: h.rateBurst = c.logRateLimitBurst
  openStream(m.roots.sysrun, h)

proc memfdWith(text: string): cint =
  var tmpl = getTempDir() / "sdc-stdin-XXXXXX"
  let fd = mkstemp(cstring(tmpl))
  if fd < 0: return -1
  discard unlink(cstring(tmpl))
  if text.len > 0: discard write(fd, unsafeAddr text[0], text.len)
  discard lseek(fd, 0, SEEK_SET)
  fd

var warnedNoJournal = false

proc runCommand*(m: Manager; u: Unit; cmd: ExecCommand; c: ExecContext; opts: RunOptions;
                 onExec: proc(ok: bool) {.closure.}; onExit: proc(st: ChildStatus) {.closure.}): RunHandle =
  ## Raises on spawn failure (the caller turns it into `resources`).
  var opened: seq[cint]
  var stdio: array[3, cint]
  var facts = opts.facts
  let nul = open("/dev/null", O_RDWR or O_CLOEXEC)
  opened.add nul
  let specs = [c.standardInput, c.standardOutput, c.standardError]
  for i in 0 .. 2:
    stdio[i] = nul
    let s = specs[i]
    case s.kind
    of sioJournal, sioJournalConsole, sioSyslog, sioSyslogConsole, sioKmsg, sioKmsgConsole:
      if i == 0: continue
      var fd = openJournal(m, u, c, cmd.path, s.kind)
      if fd < 0:
        if not warnedNoJournal:
          warnedNoJournal = true
          logWarn(u.id, "journal is not reachable; standard output goes to the manager's log")
        fd = dup(2)
      if fd >= 0:
        opened.add fd
        stdio[i] = fd
        facts.inheritedStdio[i] = true
    of sioSocket:
      let src = if opts.socketFd >= 0: opts.socketFd elif opts.fds.len > 0: opts.fds[0].source else: -1.cint
      if src >= 0:
        stdio[i] = src
        facts.inheritedStdio[i] = true
    of sioData:
      if i == 0:
        let fd = memfdWith(c.standardInputText.join("\n") & (if c.standardInputText.len > 0: "\n" else: ""))
        if fd >= 0:
          opened.add fd
          stdio[0] = fd
          facts.inheritedStdio[0] = true
    of sioInherit:
      if i == 2 and c.standardOutput.kind != sioNull and facts.inheritedStdio[1]:
        stdio[2] = stdio[1]
        facts.inheritedStdio[2] = true
    else: discard
  var passFds: seq[PassedFd]
  facts.fds = @[]
  for i, f in opts.fds:
    # the executor is a helper, so 3, 4, 5, ... are free: LISTEN_FDS descriptors go straight to their final numbers
    passFds.add (f.source, cint(3 + i))
    facts.fds.add ex.FdSpec(name: f.name)
  let cg = m.cgroupPath(u)
  if cg.len > 0: facts.expectedCgroup = cg.extractFilename
  let spec = buildSpec(m, u, cmd, c, facts)
  let handle = RunHandle(loop: m.loop)
  let procs = if cg.len > 0: cg / "cgroup.procs" else: ""
  let exe = m.roots.coreRoot / "bin" / "systemd-compat-exec"
  try:
    handle.exec = spawnExec(m.reaper, exe, geteuid(), m.roots.coreRoot, spec, stdio, passFds,
      procs, u.id, onExit)
    handle.pid = handle.exec.pid
  finally:
    for fd in opened: discard close(fd)
  let h = handle
  h.watch = m.loop.addFd(h.exec.statusFd, EvIn or EvHup, proc(ev: uint32) =
    h.execFailure = readExecFailure(h.exec)
    m.loop.delFd(h.watch)
    h.exec.closeStatus()
    onExec(h.execFailure.isNone))
  h

proc cancelWatch*(m: Manager; h: RunHandle) =
  ## Stop watching the status pipe (the process was killed before exec finished).
  if h != nil and h.exec != nil and h.exec.statusFd >= 0:
    m.loop.delFd(h.watch)
    h.exec.closeStatus()
