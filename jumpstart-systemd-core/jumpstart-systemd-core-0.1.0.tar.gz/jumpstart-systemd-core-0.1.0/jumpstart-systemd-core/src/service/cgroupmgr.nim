## Unit cgroups (spec §5.2, §18.2.4): slice chains below the core's `units/`,
## pids, kill, removal, `populated` watching, and attributing a pid to a unit.
## A manager whose roots name no `units/` cgroup runs "cgroup-less" (unit
## tests, macOS): placement is skipped and pids come from tracked children.
import std/[os, options, strutils, tables, posix, algorithm]
import jumpstartcore/cgroups
import ../common/[names, logging, roots]
import ../unitfile/model
import ../engine/[types, eventloop]
when defined(linux):
  import std/inotify

type
  CgroupManager* = ref object of RootObj
    layout*: CoreCgroups
    sys*: CgroupSystem
    enabled*: bool
    ino: cint
    watchId: WatchId
    watches: Table[cint, string]            ## inotify wd -> unit id
    paths: Table[string, string]            ## unit id -> cgroup dir
    callbacks: Table[string, proc(populated: bool) {.closure.}]
    last: Table[string, bool]

proc newCgroupManager*(roots: Roots): CgroupManager =
  result = CgroupManager(sys: defaultCgroupSystem(), ino: -1)
  if roots.unitsCgroup.len > 0 and dirExists(roots.unitsCgroup):
    result.enabled = true
    let units = roots.unitsCgroup
    result.layout = CoreCgroups(core: units.parentDir, control: units.parentDir / "control", units: units)

proc cgm*(m: Manager): CgroupManager =
  if m.cg of CgroupManager: CgroupManager(m.cg) else: nil

proc sliceOf*(u: Unit): string =
  let s = u.def.common.slice
  if s.len > 0: s else: "system.slice"

proc unitParts*(m: Manager; u: Unit): seq[string] =
  ## Cgroup components below `units/`: slice chain, then the unit (a slice is
  ## its own last component). `-.slice` is `units/` itself.
  let slice = if u.kind == ukSlice: u.id else: sliceOf(u)
  if slice != "-.slice":
    for p in sliceParents(slice): result.add cgroupComponent(p)
    result.add cgroupComponent(slice)
  if u.kind != ukSlice: result.add cgroupComponent(u.id)

proc ensureUnitCgroup*(m: Manager; u: Unit): string =
  ## The unit's cgroup directory, created with its slice chain; "" without cgroups.
  let g = m.cgm
  if g == nil or not g.enabled: return ""
  let parts = m.unitParts(u)
  if parts.len == 0: return g.layout.units
  result = ensureNestedUnitCgroup(g.layout, parts, g.sys, enableLast = u.kind == ukSlice)
  g.paths[u.id] = result

proc cgroupPath*(m: Manager; u: Unit): string =
  let g = m.cgm
  if g == nil or not g.enabled: return ""
  g.paths.getOrDefault(u.id, "")

proc procsOf(dir: string): seq[int] =
  for line in (try: readFile(dir / "cgroup.procs") except IOError: "").splitLines:
    if line.len > 0:
      try: result.add parseInt(line.strip) except ValueError: discard
  for kind, p in walkDir(dir):
    if kind == pcDir: result.add procsOf(p)

proc unitPids*(m: Manager; u: Unit): seq[int] =
  let dir = m.cgroupPath(u)
  if dir.len == 0: return
  result = procsOf(dir)
  result.sort()

proc cgroupEmpty*(m: Manager; u: Unit): bool =
  let dir = m.cgroupPath(u)
  if dir.len == 0 or not dirExists(dir): return true
  try: not cgroupPopulated(dir, m.cgm.sys)
  except CatchableError: unitPids(m, u).len == 0

proc killCgroup*(m: Manager; u: Unit) =
  ## SIGKILL to everything in the unit's cgroup, atomically with cgroup.kill.
  let dir = m.cgroupPath(u)
  if dir.len == 0 or not dirExists(dir): return
  try: writeFile(dir / "cgroup.kill", "1")
  except IOError:
    for pid in unitPids(m, u): discard kill(Pid(pid), SIGKILL)

proc removeUnitCgroup*(m: Manager; u: Unit) =
  let g = m.cgm
  if g == nil or not g.enabled: return
  let parts = m.unitParts(u)
  if parts.len == 0 or not g.paths.hasKey(u.id): return
  try:
    discard removeNestedUnitCgroup(g.layout, parts, g.sys)
    g.paths.del u.id
  except CatchableError as e:
    logWarn(u.id, "cannot remove cgroup: " & e.msg)

proc ownerOfPid*(m: Manager; pid: int): Option[string] =
  ## §5.2 rule 7: the unit whose cgroup chain owns `pid`.
  let g = m.cgm
  if g == nil or not g.enabled: return
  let text = try: readFile(m.roots.procfs / $pid / "cgroup") except IOError: ""
  let chain = unitOfPid(g.layout, text)
  if chain.isNone: return
  unitOfCgroupComponent(chain.get[^1])

when defined(linux):
  proc watchPopulated*(m: Manager; u: Unit; cb: proc(populated: bool) {.closure.}) =
    ## Calls `cb` whenever `populated` of the unit's cgroup changes.
    let g = m.cgm
    let dir = m.cgroupPath(u)
    if g == nil or dir.len == 0: return
    if g.ino < 0:
      g.ino = inotify_init1(O_NONBLOCK or O_CLOEXEC)
      if g.ino < 0: return
      g.watchId = m.loop.addFd(g.ino, EvIn, proc(ev: uint32) =
        var buf = newString(4096)
        let n = read(g.ino, addr buf[0], buf.len)
        var off = 0
        while n > 0 and off + sizeof(InotifyEvent) <= n:
          let e = cast[ptr InotifyEvent](addr buf[off])
          off += sizeof(InotifyEvent) + int(e.len)
          let id = g.watches.getOrDefault(e.wd)
          if id.len == 0 or not g.callbacks.hasKey(id): continue
          let uu = m.units.getOrDefault(id)
          if uu == nil: continue
          let pop = try: cgroupPopulated(g.paths.getOrDefault(id), g.sys) except CatchableError: false
          if g.last.getOrDefault(id, not pop) != pop:
            g.last[id] = pop
            g.callbacks[id](pop))
    let wd = inotify_add_watch(g.ino, (dir / "cgroup.events").cstring, IN_MODIFY)
    if wd >= 0:
      g.watches[wd] = u.id
      g.callbacks[u.id] = cb
      g.last[u.id] = true

  proc unwatchPopulated*(m: Manager; u: Unit) =
    let g = m.cgm
    if g == nil: return
    g.callbacks.del u.id
    g.last.del u.id
    var mine: seq[cint]
    for wd, id in g.watches:
      if id == u.id: mine.add wd
    for wd in mine:
      discard inotify_rm_watch(g.ino, wd)
      g.watches.del wd
else:
  proc watchPopulated*(m: Manager; u: Unit; cb: proc(populated: bool) {.closure.}) = discard
  proc unwatchPopulated*(m: Manager; u: Unit) = discard
