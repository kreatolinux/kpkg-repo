## The service state machine (spec §9): all types, commands, timeouts,
## restart, killing, watchdog, sd_notify handling and results. One `Unit` of
## kind `ukService` has a `ServiceData` in `Unit.data`; `attach` wires the
## behavior into `Unit.ops`.
import std/[os, options, posix, strutils, tables, sets]
import jumpstartcore/reaper
import ../common/[logging, clock, roots, names]
import ../unitfile/model
import ../engine/[types, jobs, unitstate, eventloop]
import ./[states, notifyparse, execrun, cgroupmgr, execcontext]
import ../executor/[sandbox, creds]

type
  StoredFd* = object
    fd*: cint
    name*: string
  ExecRecord* = object
    ## The last command run for one ExecKind (§9.3.3).
    pid*: int
    path*: string
    args*: seq[string]
    startReal*, startMono*, exitReal*: int64
    kind*: ExitKind
    status*: int
  ServiceData* = ref object of RootObj
    state*: ServiceState
    mainPid*, controlPid*: int
    mainHandle, controlHandle: RunHandle
    ctlKind: ExecKind
    ctlIdx: int
    ctlFailedIgnored: bool
    timer, watchdogTimer, runtimeTimer, restartTimer, pollTimer: TimerId
    deadline: int64
    nRestarts*, consecutiveRestarts: int
    notifyAccess*: NotifyAccess
    statusText*: string
    notifyErrno*: int
    stopRequested, autoRestartJob, forcedRestartKill: bool
    invocationId*: string
    mainKnown: bool                   ## a main PID is (or was) being tracked
    watchdogUsec: int64
    reloadMono: int64
    priorState: ServiceState          ## running/exited before a reload
    lastKind*: ExitKind               ## how the main process last ended
    lastCode*: int
    mainExitSeen: bool
    records*: array[ExecKind, ExecRecord]
    stopIsRestart: bool
    cleaned: bool
    execFailure: Option[(int, string)]
    populatedWatch: bool
    ctlCmds: seq[ExecCommand]
    stored: seq[StoredFd]             ## FDSTORE=1 descriptors (FileDescriptorStoreMax=)

  SocketFdsHook* = proc(m: Manager; u: Unit): seq[PassedFdSpec] {.closure.}

var socketFdsHook*: SocketFdsHook   ## set by the socket unit module

proc sd*(u: Unit): ServiceData = ServiceData(u.data)

proc storedFds*(u: Unit): seq[StoredFd] = sd(u).stored

proc releaseFdStore(d: ServiceData) =
  for f in d.stored: discard close(f.fd)
  d.stored.setLen 0
proc cfg(u: Unit): var ServiceConfig = u.def.service

proc execKindOfState(s: ServiceState): ExecKind =
  case s
  of svCondition: ekCondition
  of svStartPre: ekStartPre
  of svStart: ekStart
  of svStartPost: ekStartPost
  of svReload: ekReload
  of svStop: ekStop
  else: ekStopPost

proc setSub(m: Manager; u: Unit; s: ServiceState; result = "") =
  sd(u).state = s
  m.setState(u, activeStateOf(s), $s, result)

proc setResult(u: Unit; f: string) =
  if f != "success" and u.result == "success": u.result = f

# ---- timers -------------------------------------------------------------------
proc cancel(m: Manager; t: var TimerId) =
  m.loop.cancelTimer(t)
  t = TimerId(0)

proc armTimer(m: Manager; u: Unit; usec: int64; handler: proc()) =
  let d = sd(u)
  m.cancel(d.timer)
  if usec == Infinity or usec < 0:
    d.deadline = 0
    return
  d.deadline = m.clock.monoUsec + usec
  d.timer = m.loop.addTimerIn(usec, handler)

# ---- process bookkeeping ------------------------------------------------------
proc trackPid(m: Manager; u: Unit; pid: int) = m.pids[pid] = u.id
proc untrackPid(m: Manager; pid: int) = m.pids.del pid

proc childKind(st: ChildStatus): (ExitKind, int) =
  case st.kind
  of cekExited: (xkExited, st.code)
  of cekSignaled: ((if st.coreDumped: xkDumped else: xkKilled), st.code)
  else: (xkNone, 0)

proc mainAlive(u: Unit): bool = sd(u).mainPid > 0
proc controlAlive(u: Unit): bool = sd(u).controlPid > 0

proc signalPid(pid: int; sig: cint) =
  if pid <= 0: return
  discard kill(Pid(pid), sig)
  if sig notin [SIGKILL, SIGSTOP, SIGCONT]: discard kill(Pid(pid), SIGCONT)

proc livePids(m: Manager; u: Unit; scopeAll: bool): seq[int] =
  ## Processes a signal reaches: tracked main/control, plus the whole cgroup.
  let d = sd(u)
  if d.mainPid > 0: result.add d.mainPid
  if d.controlPid > 0: result.add d.controlPid
  if scopeAll:
    for p in m.unitPids(u):
      if p notin result: result.add p

proc killScope(m: Manager; u: Unit; sig: cint; sigkillPhase: bool): int =
  ## §9.7. Returns the number of processes signalled.
  let kc = u.def.service.kill
  var scopeAll = false
  case kc.killMode
  of kmNone: return 0
  of kmControlGroup: scopeAll = true
  of kmMixed: scopeAll = sigkillPhase
  of kmProcess: scopeAll = false
  let pids = livePids(m, u, scopeAll)
  if pids.len == 0: return 0
  if sigkillPhase and sig == SIGKILL and scopeAll:
    m.killCgroup(u)
  if kc.sendSigHup and not sigkillPhase:
    for p in pids: discard kill(Pid(p), SIGHUP)
  for p in pids: signalPid(p, sig)
  pids.len

proc scopeEmpty(m: Manager; u: Unit; sigkillPhase: bool): bool =
  let kc = u.def.service.kill
  let d = sd(u)
  case kc.killMode
  of kmNone: return true
  of kmControlGroup: discard
  of kmMixed: (if not sigkillPhase: return d.mainPid == 0 and d.controlPid == 0)
  of kmProcess: return d.mainPid == 0 and d.controlPid == 0
  d.mainPid == 0 and d.controlPid == 0 and m.cgroupEmpty(u)

# ---- forward declarations ---------------------------------------------------------
proc enterDead(m: Manager; u: Unit; f: string)
proc enterSignal(m: Manager; u: Unit; s: ServiceState; f: string)
proc enterStopPost(m: Manager; u: Unit; f: string)
proc enterStop(m: Manager; u: Unit; f: string)
proc enterStartPost(m: Manager; u: Unit)
proc enterRunning(m: Manager; u: Unit)
proc enterStartPre(m: Manager; u: Unit)
proc enterStart(m: Manager; u: Unit)
proc onTimeout(m: Manager; u: Unit)
proc runSeq(m: Manager; u: Unit; kind: ExecKind; idx: int)
proc checkStopProgress(m: Manager; u: Unit)

proc startTimeout(u: Unit): int64 = u.def.service.timeoutStartUsec
proc stopTimeout(u: Unit): int64 = u.def.service.timeoutStopUsec

# ---- running commands ---------------------------------------------------------------
proc recordStart(d: ServiceData; kind: ExecKind; pid: int; cmd: ExecCommand; real, mono: int64) =
  d.records[kind] = ExecRecord(pid: pid, path: cmd.path, args: cmd.args, startReal: real, startMono: mono)

proc recordExit(d: ServiceData; kind: ExecKind; pid: int; k: ExitKind; code: int; real: int64) =
  if d.records[kind].pid == pid:
    d.records[kind].exitReal = real
    d.records[kind].kind = k
    d.records[kind].status = code

proc factsFor(m: Manager; u: Unit; kind: ExecKind): RunFacts =
  let d = sd(u)
  result = RunFacts(unit: u.id, invocationId: d.invocationId, kind: kind, mainPid: d.mainPid,
    serviceResult: u.result, watchdogUsec: u.def.service.watchdogUsec)
  if kind == ekStopPost:
    result.exitCode = $d.lastKind
    result.exitStatus = (if d.lastKind in {xkKilled, xkDumped}: signalName(d.lastCode) else: $d.lastCode)
  if u.id in m.monitor:
    result.extraEnv = m.monitor[u.id]
    m.monitor.del u.id

proc spawnProc(m: Manager; u: Unit; cmd: ExecCommand; kind: ExecKind;
               onExit: proc(st: ChildStatus) {.closure.};
               onExec: proc(ok: bool) {.closure.}): RunHandle =
  var opts = RunOptions(kind: kind, facts: factsFor(m, u, kind))
  # systemd's service_spawn collects the socket descriptors for every command of the unit
  # (ExecStartPre/Start/StartPost/Reload/Stop/StopPost, and Type=oneshot's ExecStart).
  if socketFdsHook != nil: opts.fds = socketFdsHook(m, u)
  # stored descriptors follow the socket descriptors (FDSTORE=1, sd_pid_notify_with_fds)
  for f in sd(u).stored: opts.fds.add PassedFdSpec(source: f.fd, name: f.name)
  let c = u.def.service.exec
  runCommand(m, u, cmd, c, opts, onExec, onExit)

proc mainExited(m: Manager; u: Unit; pid: int; st: ChildStatus)
proc controlExited(m: Manager; u: Unit; pid: int; st: ChildStatus)

proc startMainProcess(m: Manager; u: Unit; cmd: ExecCommand; onExec: proc(ok: bool) {.closure.}): bool =
  let d = sd(u)
  try:
    let h = spawnProc(m, u, cmd, ekStart,
      proc(st: ChildStatus) = m.mainExited(u, int(st.pid), st), onExec)
    d.mainHandle = h
    d.mainPid = int(h.pid)
    d.mainKnown = true
    d.mainExitSeen = false
    m.trackPid(u, d.mainPid)
    d.recordStart(ekStart, d.mainPid, cmd, m.clock.realUsec, m.clock.monoUsec)
    true
  except CatchableError as e:
    logErr(u.id, "Failed to spawn " & cmd.path & ": " & e.msg)
    false

proc startControlProcess(m: Manager; u: Unit; cmd: ExecCommand; kind: ExecKind): bool =
  let d = sd(u)
  try:
    let h = spawnProc(m, u, cmd, kind,
      proc(st: ChildStatus) = m.controlExited(u, int(st.pid), st), proc(ok: bool) = discard)
    d.controlHandle = h
    d.controlPid = int(h.pid)
    m.trackPid(u, d.controlPid)
    d.recordStart(kind, d.controlPid, cmd, m.clock.realUsec, m.clock.monoUsec)
    true
  except CatchableError as e:
    logErr(u.id, "Failed to spawn " & cmd.path & ": " & e.msg)
    false

proc ignorableFailure(cmd: ExecCommand): bool = efMinus in cmd.flags

proc phaseTimeout(m: Manager; u: Unit; kind: ExecKind): int64 =
  if kind in {ekStop, ekStopPost}: stopTimeout(u) else: startTimeout(u)

proc spawnFailed(m: Manager; u: Unit; kind: ExecKind) =
  ## A command could not even be forked/placed: `resources` (§9.10).
  case sd(u).state
  of svCondition, svStartPre, svStart, svStartPost: enterSignal(m, u, svStopSigterm, "resources")
  of svReload, svReloadSignal, svReloadNotify:
    u.reloadResult = "resources"
    setSub(m, u, sd(u).priorState)
  of svStop: enterSignal(m, u, svStopSigterm, "resources")
  of svStopPost: enterSignal(m, u, svFinalSigterm, "resources")
  else: discard

proc runSeq(m: Manager; u: Unit; kind: ExecKind; idx: int) =
  ## Runs command `idx` of `kind` as the control process, or finishes the phase.
  let d = sd(u)
  let cmds = u.def.service.commands[kind]
  d.ctlKind = kind
  d.ctlIdx = idx
  if idx >= cmds.len: return
  m.armTimer(u, m.phaseTimeout(u, kind), proc() = m.onTimeout(u))
  if not m.startControlProcess(u, cmds[idx], kind): m.spawnFailed(u, kind)

# ---- entering states ------------------------------------------------------------------
proc cleanupRuntime(m: Manager; u: Unit; restarting: bool) =
  let c = u.def.service.exec
  if c.privateTmp or c.dynamicUser: removePrivateTmp(sd(u).invocationId, u.id)
  if c.loadCredential.len + c.setCredential.len + c.importCredential.len > 0:
    removeCredentials((if m.roots.scope == scUser: m.roots.runtime else: m.roots.run) / "credentials", u.id)
  let keep = c.runtimeDirectoryPreserve == dpYes or (c.runtimeDirectoryPreserve == dpRestart and restarting)
  if c.runtimeDirectory.len > 0 and not keep:
    let root = if m.roots.scope == scUser: m.roots.runtime else: m.roots.run
    for n in c.runtimeDirectory:
      let p = root / n.split(':')[0]
      try: removeDir(p) except OSError: discard

proc invocationLink(m: Manager; u: Unit): string = m.roots.sysrun / "units" / ("invocation:" & u.id)

proc writeInvocation(m: Manager; u: Unit) =
  try:
    createDir(m.roots.sysrun / "units")
    let link = m.invocationLink(u)
    discard unlink(link.cstring)
    createSymlink(sd(u).invocationId, link)
  except OSError, IOError: discard

proc decideRestart(m: Manager; u: Unit): bool =
  let d = sd(u)
  let c = u.def.service
  if d.stopRequested or m.stopping: return false
  let cls = case u.result
    of "success": xcClean
    of "exit-code": xcUncleanExit
    of "signal": xcUncleanSignal
    of "core-dump": xcCoreDump
    of "timeout": xcTimeout
    of "watchdog": xcWatchdog
    else: xcUncleanExit
  shouldRestart(c.restart, cls, d.lastKind, d.lastCode, c.restartPreventExit, c.restartForceExit)

proc restartFired(m: Manager; u: Unit) =
  let d = sd(u)
  if d.state != svAutoRestart: return
  setSub(m, u, svAutoRestartQueued)
  d.autoRestartJob = true
  try: discard submitJob(m, u, jtStart, jmReplace, joDependency)
  except CatchableError as e:
    logErr(u.id, "automatic restart not queued: " & e.msg)
    d.autoRestartJob = false
    setSub(m, u, svFailed, "resources")

proc enterDead(m: Manager; u: Unit; f: string) =
  let d = sd(u)
  setResult(u, f)
  for t in [addr d.timer, addr d.watchdogTimer, addr d.runtimeTimer, addr d.pollTimer]:
    m.cancel(t[])
  d.deadline = 0
  if d.mainPid > 0: m.untrackPid(d.mainPid)
  if d.controlPid > 0: m.untrackPid(d.controlPid)
  d.mainPid = 0
  d.controlPid = 0
  let restart = m.decideRestart(u)
  case u.def.service.fdStorePreserve
  of fpNo: (if not restart: d.releaseFdStore())
  of fpRestart:
    # kept across automatic restarts and restart jobs, released by an explicit stop or a failed start
    let restarting = u.job != nil and u.job.typ in {jtRestart, jtTryRestart}
    if not restart and not restarting and (d.stopRequested or u.result != "success"): d.releaseFdStore()
  of fpYes: discard
  m.cleanupRuntime(u, restart)
  discard unlink(m.invocationLink(u).cstring)
  if restart:
    inc d.nRestarts
    inc d.consecutiveRestarts
    let c = u.def.service
    let delay = restartDelayUsec(c.restartUsec, c.restartMaxDelayUsec, c.restartSteps, d.consecutiveRestarts)
    logInfo(u.id, "Scheduled restart job, restart counter is at " & $d.nRestarts)
    let failed = u.result != "success"
    setSub(m, u, if failed: svFailedBeforeAutoRestart else: svDeadBeforeAutoRestart)
    setSub(m, u, svAutoRestart)
    m.cancel(d.restartTimer)
    d.restartTimer = m.loop.addTimerIn(delay, proc() = m.restartFired(u))
  else:
    d.consecutiveRestarts = 0
    let kc = u.def.service.kill.killMode
    if kc == kmProcess and not m.cgroupEmpty(u):
      logWarn(u.id, "Unit process remains running after unit stopped.")
    else:
      m.removeUnitCgroup(u)
    if u.result == "success": setSub(m, u, svDead)
    else: setSub(m, u, svFailed)

proc enterSignal(m: Manager; u: Unit; s: ServiceState; f: string) =
  let d = sd(u)
  setResult(u, f)
  let kc = u.def.service.kill
  let sigkill = s in {svStopSigkill, svFinalSigkill}
  var sig: cint
  case s
  of svStopSigterm, svFinalSigterm:
    sig = cint(if d.stopIsRestart and kc.restartKillSignal != 0: kc.restartKillSignal else: kc.killSignal)
  of svStopWatchdog, svFinalWatchdog: sig = cint(kc.watchdogSignal)
  else: sig = cint(kc.finalKillSignal)
  # the main process is expected to die with the signals below: drop leftover timers
  m.cancel(d.watchdogTimer)
  m.cancel(d.runtimeTimer)
  discard killScope(m, u, sig, sigkill)
  if scopeEmpty(m, u, sigkill):
    m.cancel(d.timer)
    case s
    of svStopSigterm, svStopWatchdog, svStopSigkill: enterStopPost(m, u, "success")
    else: enterDead(m, u, "success")
    return
  setSub(m, u, s)
  let usec = if s in {svStopWatchdog, svFinalWatchdog}: u.def.service.timeoutAbortUsec else: stopTimeout(u)
  m.armTimer(u, usec, proc() = m.onTimeout(u))

proc enterStopPost(m: Manager; u: Unit; f: string) =
  let d = sd(u)
  setResult(u, f)
  d.ctlCmds = @[]
  if u.def.service.commands[ekStopPost].len == 0:
    enterSignal(m, u, svFinalSigterm, "success")
    return
  setSub(m, u, svStopPost)
  runSeq(m, u, ekStopPost, 0)

proc enterStop(m: Manager; u: Unit; f: string) =
  setResult(u, f)
  if u.def.service.commands[ekStop].len == 0:
    enterSignal(m, u, svStopSigterm, "success")
    return
  setSub(m, u, svStop)
  runSeq(m, u, ekStop, 0)

proc armWatchdog(m: Manager; u: Unit) =
  let d = sd(u)
  m.cancel(d.watchdogTimer)
  if d.watchdogUsec > 0 and d.state in {svRunning, svReload, svReloadNotify, svReloadSignal}:
    d.watchdogTimer = m.loop.addTimerIn(d.watchdogUsec, proc() =
      logWarn(u.id, "Watchdog timeout (limit " & $d.watchdogUsec & "us)!")
      enterSignal(m, u, svStopWatchdog, "watchdog"))

proc serviceGood(m: Manager; u: Unit): bool =
  let d = sd(u)
  if d.mainPid > 0: return true
  # forking service without a tracked main PID lives while its cgroup is populated
  u.def.service.effectiveType == stForking and not d.mainKnown and not m.cgroupEmpty(u)

proc enterRunning(m: Manager; u: Unit) =
  let d = sd(u)
  let c = u.def.service
  if u.result != "success":
    enterSignal(m, u, svStopSigterm, u.result)
  elif serviceGood(m, u):
    m.cancel(d.timer)
    d.consecutiveRestarts = d.consecutiveRestarts
    setSub(m, u, svRunning)
    armWatchdog(m, u)
    m.cancel(d.runtimeTimer)
    if c.runtimeMaxUsec != Infinity:
      var extra = 0'i64
      if c.runtimeRandomExtraUsec > 0 and c.runtimeRandomExtraUsec != Infinity:
        extra = m.rng.uniform(0, c.runtimeRandomExtraUsec)
      d.runtimeTimer = m.loop.addTimerIn(c.runtimeMaxUsec + extra, proc() =
        logWarn(u.id, "Service reached runtime time limit. Stopping.")
        enterSignal(m, u, svStopSigterm, "timeout"))
    if c.exitType == etCgroup or (c.effectiveType == stForking and not d.mainKnown):
      d.populatedWatch = true
  elif c.remainAfterExit:
    m.cancel(d.timer)
    setSub(m, u, svExited)
  else:
    enterStop(m, u, "success")

proc enterStartPost(m: Manager; u: Unit) =
  let d = sd(u)
  if u.def.service.commands[ekStartPost].len == 0:
    enterRunning(m, u)
    return
  setSub(m, u, svStartPost)
  runSeq(m, u, ekStartPost, 0)

proc discoverMainPid(m: Manager; u: Unit): bool

proc enterStart(m: Manager; u: Unit) =
  let d = sd(u)
  let c = u.def.service
  setSub(m, u, svStart)
  case c.effectiveType
  of stOneshot:
    if c.commands[ekStart].len == 0:
      enterStartPost(m, u)
    else:
      runSeq(m, u, ekStart, 0)
  of stForking:
    m.armTimer(u, startTimeout(u), proc() = m.onTimeout(u))
    if not m.startControlProcess(u, c.commands[ekStart][0], ekStart): m.spawnFailed(u, ekStart)
    d.ctlKind = ekStart
    d.ctlIdx = 0
  else:
    if c.commands[ekStart].len == 0:
      enterSignal(m, u, svStopSigterm, "protocol")
      return
    let t = c.effectiveType
    m.armTimer(u, startTimeout(u), proc() = m.onTimeout(u))
    let cmd = c.commands[ekStart][0]
    proc spawnMain() =
      if not m.startMainProcess(u, cmd, proc(ok: bool) =
          if not ok or sd(u).state != svStart: return
          if t in {stExec}: enterStartPost(m, u)):
        enterSignal(m, u, svStopSigterm, "resources")
        return
      if t in {stSimple, stIdle}: enterStartPost(m, u)
    if t == stIdle:
      # §9.2.6: wait until no other job runs, at most 5 seconds
      let began = m.clock.monoUsec
      proc poll() =
        if sd(u).state != svStart: return
        var busy = false
        for j in m.jobs.values:
          if j.unit != u and j.state == jsRunning: busy = true
        if not busy or m.clock.monoUsec - began >= 5_000_000: spawnMain()
        else: sd(u).pollTimer = m.loop.addTimerIn(50_000, poll)
      poll()
    else:
      spawnMain()

proc enterStartPre(m: Manager; u: Unit) =
  if u.def.service.commands[ekStartPre].len == 0:
    enterStart(m, u)
    return
  setSub(m, u, svStartPre)
  runSeq(m, u, ekStartPre, 0)

proc enterCondition(m: Manager; u: Unit) =
  if u.def.service.commands[ekCondition].len == 0:
    enterStartPre(m, u)
    return
  setSub(m, u, svCondition)
  runSeq(m, u, ekCondition, 0)

# ---- main PID discovery for forking services -----------------------------------------
proc readPidFile(path: string): Option[int] =
  try:
    let line = readFile(path).splitLines()[0].strip
    some(parseInt(line))
  except CatchableError: none(int)

proc adoptMain(m: Manager; u: Unit; pid: int) =
  let d = sd(u)
  d.mainPid = pid
  d.mainKnown = true
  d.mainExitSeen = false
  m.trackPid(u, pid)
  try:
    m.reaper.register(Pid(pid), u.id, proc(st: ChildStatus) = m.mainExited(u, int(st.pid), st))
  except CatchableError:
    # not our child (or already registered): poll for its end
    proc poll() =
      if sd(u).mainPid != pid: return
      if kill(Pid(pid), 0) != 0 and errno == ESRCH:
        m.mainExited(u, pid, ChildStatus(pid: Pid(pid), kind: cekExited, code: 0))
      else: sd(u).pollTimer = m.loop.addTimerIn(500_000, poll)
    sd(u).pollTimer = m.loop.addTimerIn(500_000, poll)

proc pidInUnit(m: Manager; u: Unit; pid: int): bool =
  if kill(Pid(pid), 0) != 0: return false
  let o = m.ownerOfPid(pid)
  (o.isSome and o.get == u.id) or (m.cgm == nil or not m.cgm.enabled)

proc discoverMainPid(m: Manager; u: Unit): bool =
  ## After the parent of a forking service exited successfully. False: keep waiting.
  let d = sd(u)
  let c = u.def.service
  if c.pidFile.len > 0:
    let path = if c.pidFile.isAbsolute: c.pidFile else: m.roots.run / c.pidFile
    if not fileExists(path): return false
    let pid = readPidFile(path)
    if pid.isNone or pid.get <= 0:
      setResult(u, "protocol")
      enterSignal(m, u, svStopSigterm, "protocol")
      return true
    if not pidInUnit(m, u, pid.get):
      logWarn(u.id, "PID " & $pid.get & " read from file " & path & " is not in the unit's cgroup")
      enterSignal(m, u, svStopSigterm, "protocol")
      return true
    adoptMain(m, u, pid.get)
  elif c.guessMainPid:
    for p in m.unitPids(u):
      if p != d.controlPid and kill(Pid(p), 0) == 0:
        adoptMain(m, u, p)
        break
  enterStartPost(m, u)
  true

proc waitForPidFile(m: Manager; u: Unit) =
  if sd(u).state != svStart: return
  if not discoverMainPid(m, u):
    sd(u).pollTimer = m.loop.addTimerIn(100_000, proc() = waitForPidFile(m, u))

# ---- process exits ---------------------------------------------------------------------
proc afterMainEnded(m: Manager; u: Unit; res: string) =
  ## The main process is gone while the unit was `running`/`reload` (§9.4.1).
  if res != "success":
    enterSignal(m, u, svStopSigterm, res)
  elif u.def.service.remainAfterExit:
    setSub(m, u, svExited)
  else:
    enterStop(m, u, "success")

proc mainExited(m: Manager; u: Unit; pid: int; st: ChildStatus) =
  let d = sd(u)
  if d.mainPid != pid: return
  let (kind, code) = childKind(st)
  d.mainPid = 0
  d.mainHandle = nil
  m.untrackPid(pid)
  d.lastKind = kind
  d.lastCode = code
  d.mainExitSeen = true
  d.recordExit(ekStart, pid, kind, code, m.clock.realUsec)
  let res = resultOfExit(kind, code, u.def.service.successExit)
  if res != "success":
    logInfo(u.id, "Main process exited, code=" & $kind & ", status=" & statusWord(kind, code))
  case d.state
  of svStart:
    if u.def.service.effectiveType == stForking: discard
    else:
      m.cancel(d.pollTimer)
      enterSignal(m, u, svStopSigterm, res)
  of svStartPost: enterSignal(m, u, svStopSigterm, res)
  of svRunning:
    if u.def.service.exitType == etCgroup and not m.cgroupEmpty(u):
      discard                       # stays running until the cgroup is empty
    else: afterMainEnded(m, u, res)
  of svReload, svReloadSignal, svReloadNotify:
    if d.controlPid > 0: signalPid(d.controlPid, SIGKILL)
    afterMainEnded(m, u, res)
  of svStop, svStopWatchdog, svStopSigterm, svStopSigkill, svFinalWatchdog, svFinalSigterm,
     svFinalSigkill:
    if res != "success" and d.state in {svStopWatchdog}: discard
    m.checkStopProgress(u)
  else: discard

proc nextCommand(m: Manager; u: Unit): bool =
  ## Starts the next command of the current phase; false when none is left.
  let d = sd(u)
  if d.ctlIdx + 1 < u.def.service.commands[d.ctlKind].len:
    runSeq(m, u, d.ctlKind, d.ctlIdx + 1)
    return true
  false

proc controlExited(m: Manager; u: Unit; pid: int; st: ChildStatus) =
  let d = sd(u)
  if d.controlPid != pid: return
  let (kind, code) = childKind(st)
  d.controlPid = 0
  d.controlHandle = nil
  m.untrackPid(pid)
  let ek = d.ctlKind
  d.recordExit(ek, pid, kind, code, m.clock.realUsec)
  let cmds = u.def.service.commands[ek]
  let cmd = if d.ctlIdx < cmds.len: cmds[d.ctlIdx] else: ExecCommand()
  var res = resultOfExit(kind, code, u.def.service.successExit)
  if kind == xkExited and res == "success" and u.def.service.effectiveType == stForking and ek == ekStart:
    res = "success"
  let failed = res != "success"
  let ignored = failed and ignorableFailure(cmd)
  if failed and not ignored:
    logInfo(u.id, $ek & " process exited, code=" & $kind & ", status=" & statusWord(kind, code))
  case d.state
  of svCondition:
    if not failed or ignored:
      m.cancel(d.timer)
      if not nextCommand(m, u): enterStartPre(m, u)
    elif kind == xkExited and code in 1 .. 254:
      u.failedCondition = "ExecCondition=" & cmd.raw
      m.cancel(d.timer)
      enterDead(m, u, "success")
    else:
      m.cancel(d.timer)
      setResult(u, res)
      setSub(m, u, svFailed, res)
  of svStartPre:
    if not failed or ignored:
      m.cancel(d.timer)
      if not nextCommand(m, u): enterStart(m, u)
    else: enterSignal(m, u, svStopSigterm, res)
  of svStart:
    if u.def.service.effectiveType == stForking:
      if failed and not ignored:
        enterSignal(m, u, svStopSigterm, res)
      else:
        m.cancel(d.pollTimer)
        waitForPidFile(m, u)
    else:                            # oneshot
      if not failed or ignored:
        if not nextCommand(m, u): enterStartPost(m, u)
      else: enterSignal(m, u, svStopSigterm, res)
  of svStartPost:
    if not failed or ignored:
      m.cancel(d.timer)
      if not nextCommand(m, u): enterRunning(m, u)
    else: enterSignal(m, u, svStopSigterm, res)
  of svReload:
    if not failed or ignored:
      if not nextCommand(m, u):
        m.cancel(d.timer)
        if u.def.service.typ == stNotifyReload and d.mainPid > 0:
          signalPid(d.mainPid, cint(u.def.service.reloadSignal))
          d.reloadMono = m.clock.monoUsec
          setSub(m, u, svReloadSignal)
          m.armTimer(u, startTimeout(u), proc() = m.onTimeout(u))
        else:
          u.reloadResult = "success"
          setSub(m, u, d.priorState)
          armWatchdog(m, u)
    else:
      m.cancel(d.timer)
      u.reloadResult = res
      setSub(m, u, d.priorState)
      armWatchdog(m, u)
  of svStop:
    if not failed or ignored:
      m.cancel(d.timer)
      if not nextCommand(m, u): enterSignal(m, u, svStopSigterm, "success")
    else:
      enterSignal(m, u, svStopSigterm, res)
  of svStopPost:
    if not failed or ignored:
      m.cancel(d.timer)
      if not nextCommand(m, u): enterSignal(m, u, svFinalSigterm, "success")
    else:
      setResult(u, res)
      if not nextCommand(m, u): enterSignal(m, u, svFinalSigterm, res)
  of svStopWatchdog, svStopSigterm, svStopSigkill, svFinalWatchdog, svFinalSigterm, svFinalSigkill:
    m.checkStopProgress(u)
  else: discard

proc checkStopProgress(m: Manager; u: Unit) =
  let d = sd(u)
  let s = d.state
  if s notin {svStopWatchdog, svStopSigterm, svStopSigkill, svFinalWatchdog, svFinalSigterm, svFinalSigkill}:
    return
  if not scopeEmpty(m, u, s in {svStopSigkill, svFinalSigkill}): return
  m.cancel(d.timer)
  case s
  of svStopWatchdog, svStopSigterm, svStopSigkill: enterStopPost(m, u, "success")
  else: enterDead(m, u, "success")

proc onPopulated(m: Manager; u: Unit; populated: bool) =
  let d = sd(u)
  if populated: return
  case d.state
  of svRunning:
    if d.mainPid == 0:
      let res = if d.mainExitSeen: resultOfExit(d.lastKind, d.lastCode, u.def.service.successExit) else: "success"
      afterMainEnded(m, u, res)
  of svStop, svStopWatchdog, svStopSigterm, svStopSigkill, svFinalWatchdog, svFinalSigterm,
     svFinalSigkill: m.checkStopProgress(u)
  of svDead, svFailed: m.removeUnitCgroup(u)
  else: discard

proc onTimeout(m: Manager; u: Unit) =
  let d = sd(u)
  d.timer = TimerId(0)
  let c = u.def.service
  let startMode = c.timeoutStartFailure
  let stopMode = c.timeoutStopFailure
  proc modeState(mode: FailureMode): ServiceState =
    case mode
    of fmTerminate: svStopSigterm
    of fmAbort: svStopWatchdog
    of fmKill: svStopSigkill
  case d.state
  of svCondition, svStartPre, svStart, svStartPost:
    logWarn(u.id, "Start operation timed out. Terminating.")
    enterSignal(m, u, modeState(startMode), "timeout")
  of svReload:
    if d.controlPid > 0: signalPid(d.controlPid, SIGKILL)
    u.reloadResult = "timeout"
    setSub(m, u, d.priorState)
  of svReloadSignal, svReloadNotify:
    logWarn(u.id, "Reload operation timed out. Stopping.")
    u.reloadResult = "timeout"
    enterSignal(m, u, svStopSigterm, "timeout")
  of svStop:
    logWarn(u.id, "Stopping timed out. Terminating.")
    enterSignal(m, u, modeState(stopMode), "timeout")
  of svStopWatchdog: enterSignal(m, u, svStopSigkill, "timeout")
  of svStopSigterm:
    if c.kill.sendSigKill: enterSignal(m, u, svStopSigkill, "timeout") else: enterStopPost(m, u, "timeout")
  of svStopSigkill:
    logWarn(u.id, "Processes still around after SIGKILL. Ignoring.")
    enterStopPost(m, u, "timeout")
  of svStopPost: enterSignal(m, u, svFinalSigterm, "timeout")
  of svFinalWatchdog: enterSignal(m, u, svFinalSigkill, "timeout")
  of svFinalSigterm:
    if c.kill.sendSigKill: enterSignal(m, u, svFinalSigkill, "timeout") else: enterDead(m, u, "timeout")
  of svFinalSigkill: enterDead(m, u, "timeout")
  else: discard

# ---- sd_notify ---------------------------------------------------------------------------
proc senderAllowed(u: Unit; pid: int): bool =
  let d = sd(u)
  case d.notifyAccess
  of naNone: false
  of naMain: pid == d.mainPid
  of naExec: pid == d.mainPid or pid == d.controlPid
  of naAll: true

proc extendTimer(m: Manager; u: Unit; usec: int64) =
  let d = sd(u)
  if d.deadline == 0: return                       # no active timer: no effect
  let want = m.clock.monoUsec + usec
  if want > d.deadline:
    d.deadline = want
    m.loop.cancelTimer(d.timer)
    d.timer = m.loop.addTimerIn(usec, proc() = m.onTimeout(u))

proc handleNotify*(m: Manager; u: Unit; pid: int; datagram: string; fds: seq[cint]) =
  ## §9.9: one datagram from `pid`, already mapped to `u`.
  let d = sd(u)
  let msg = parseNotify(datagram)
  var keepFds = false
  defer:
    if not keepFds:
      for f in fds: discard close(f)
  if not senderAllowed(u, pid):
    if d.notifyAccess == naNone: return
    logWarn(u.id, "Got notification message from PID " & $pid & ", but reception is not permitted")
    return
  if msg.notifyAccess.isSome:
    let v = msg.notifyAccess.get
    for a in NotifyAccess:
      if $a == v: d.notifyAccess = a
  let fdName = if msg.fdName.isSome and msg.fdName.get.len > 0 and ':' notin msg.fdName.get: msg.fdName.get
               else: "stored"
  if msg.fdStore and fds.len > 0:
    let max = u.def.service.fdStoreMax
    if d.state in {svDead, svFailed, svAutoRestart, svDeadBeforeAutoRestart, svFailedBeforeAutoRestart,
                   svAutoRestartQueued}:
      logWarn(u.id, "Ignoring FDSTORE=1: service is not running")
    elif d.stored.len + fds.len > max:
      logWarn(u.id, "Cannot store more file descriptors, the limit of " & $max & " (FileDescriptorStoreMax=) is reached")
    else:
      keepFds = true
      for f in fds: d.stored.add StoredFd(fd: f, name: fdName)
  if msg.fdStoreRemove and msg.fdName.isSome:
    var kept: seq[StoredFd]
    for f in d.stored:
      if f.name == msg.fdName.get: discard close(f.fd) else: kept.add f
    d.stored = kept
  if msg.status.isSome:
    d.statusText = sanitizeStatus(msg.status.get)
    m.dirty.incl u.id
  if msg.errNo.isSome: d.notifyErrno = msg.errNo.get
  if msg.mainPid.isSome and d.state in {svStart, svStartPost, svRunning, svReload, svReloadSignal, svReloadNotify}:
    let np = msg.mainPid.get
    let okSender = pidInUnit(m, u, np) or (geteuid() == 0 and kill(Pid(np), 0) == 0 and
      (try: readFile(m.roots.procfs / $np / "status").contains("Uid:\t0") except IOError: false))
    if okSender and np != d.mainPid:
      if d.mainPid > 0: m.untrackPid(d.mainPid)
      adoptMain(m, u, np)
      logInfo(u.id, "Main PID changed to " & $np)
    elif not okSender:
      logWarn(u.id, "Ignoring MAINPID=" & $np & " (not in the unit)")
  if msg.watchdogUsec.isSome and msg.watchdogUsec.get > 0:
    d.watchdogUsec = msg.watchdogUsec.get
    armWatchdog(m, u)
  case msg.watchdog
  of wdPing: armWatchdog(m, u)
  of wdTrigger: enterSignal(m, u, svStopWatchdog, "watchdog")
  of wdNone: discard
  if msg.extendTimeoutUsec.isSome: extendTimer(m, u, msg.extendTimeoutUsec.get)
  if msg.ready:
    case d.state
    of svStart:
      if u.def.service.effectiveType in {stNotify, stNotifyReload}:
        m.cancel(d.timer)
        enterStartPost(m, u)
    of svReloadSignal, svReloadNotify:
      m.cancel(d.timer)
      u.reloadResult = "success"
      setSub(m, u, svRunning)
      armWatchdog(m, u)
    else: discard
  if msg.reloading:
    case d.state
    of svReloadSignal:
      if msg.monotonicUsec.isNone or msg.monotonicUsec.get >= d.reloadMono:
        setSub(m, u, svReloadNotify)
        m.armTimer(u, startTimeout(u), proc() = m.onTimeout(u))
    of svRunning:
      d.priorState = svRunning
      setSub(m, u, svReloadNotify)
      m.armTimer(u, startTimeout(u), proc() = m.onTimeout(u))
    else: discard
  if msg.stopping and d.state == svRunning:
    setSub(m, u, svStopSigterm)
    m.armTimer(u, stopTimeout(u), proc() = m.onTimeout(u))

# ---- unit operations -----------------------------------------------------------------------
proc newInvocationId(m: Manager): string =
  for c in m.rng.bytes(16): result.add toHex(ord(c), 2).toLowerAscii

proc serviceStart(m: Manager; u: Unit): StartOutcome =
  let d = sd(u)
  case d.state
  of svRunning, svExited, svReload, svReloadSignal, svReloadNotify:
    return StartOutcome(kind: skAlreadyActive)
  of svCondition, svStartPre, svStart, svStartPost:
    return StartOutcome(kind: skStarted)
  of svStop, svStopWatchdog, svStopSigterm, svStopSigkill, svStopPost, svFinalWatchdog, svFinalSigterm,
     svFinalSigkill, svCleaning:
    return StartOutcome(kind: skRefused, text: "Unit " & u.id & " is stopping.", code: "E_UNIT_STATE")
  else: discard
  let manualStart = not d.autoRestartJob
  m.cancel(d.restartTimer)
  d.autoRestartJob = false
  if manualStart: d.consecutiveRestarts = 0
  if manualStart or d.state in {svDead, svFailed}:
    if manualStart: d.nRestarts = 0
  d.stopRequested = false
  d.stopIsRestart = false
  d.cleaned = false
  d.mainKnown = false
  d.mainExitSeen = false
  d.lastKind = xkNone
  d.lastCode = 0
  d.statusText = ""
  d.notifyErrno = 0
  d.watchdogUsec = u.def.service.watchdogUsec
  d.notifyAccess = u.def.service.notifyAccess
  d.populatedWatch = false
  d.invocationId = newInvocationId(m)
  u.result = "success"
  u.failedCondition = ""
  u.reloadResult = ""
  m.writeInvocation(u)
  let cg = m.ensureUnitCgroup(u)
  if cg.len > 0: m.watchPopulated(u, proc(p: bool) = onPopulated(m, u, p))
  logInfo(u.id, "Starting " & (if u.def.common.description.len > 0: u.def.common.description else: u.id) & "...")
  enterCondition(m, u)
  StartOutcome(kind: skStarted)

proc serviceStop(m: Manager; u: Unit) =
  let d = sd(u)
  d.stopRequested = true
  case d.state
  of svDead, svFailed, svDeadBeforeAutoRestart, svFailedBeforeAutoRestart: discard
  of svAutoRestart, svAutoRestartQueued:
    m.cancel(d.restartTimer)
    d.autoRestartJob = false
    setSub(m, u, svDead)
  of svCondition, svStartPre, svStart, svStartPost:
    enterSignal(m, u, svStopSigterm, "success")
  of svRunning, svExited:
    d.stopIsRestart = false
    enterStop(m, u, "success")
  of svReload, svReloadSignal, svReloadNotify:
    if d.controlPid > 0: signalPid(d.controlPid, SIGKILL)
    enterStop(m, u, "success")
  else: discard                      # already stopping

proc serviceReload(m: Manager; u: Unit): bool =
  let d = sd(u)
  if d.state notin {svRunning, svExited}: return false
  let c = u.def.service
  d.priorState = d.state
  u.reloadResult = ""
  m.cancel(d.watchdogTimer)
  if c.commands[ekReload].len == 0:
    if c.typ != stNotifyReload or d.mainPid == 0: return false
    signalPid(d.mainPid, cint(c.reloadSignal))
    d.reloadMono = m.clock.monoUsec
    setSub(m, u, svReloadSignal)
    m.armTimer(u, startTimeout(u), proc() = m.onTimeout(u))
    return true
  setSub(m, u, svReload)
  runSeq(m, u, ekReload, 0)
  true

proc serviceKill(m: Manager; u: Unit; whom: KillWhom; sig: cint): int =
  let d = sd(u)
  var pids: seq[int]
  case whom
  of kwMain: (if d.mainPid > 0: pids.add d.mainPid)
  of kwControl: (if d.controlPid > 0: pids.add d.controlPid)
  of kwAll: pids = livePids(m, u, true)
  for p in pids:
    if kill(Pid(p), sig) == 0: inc result
  if whom == kwAll and sig notin [SIGKILL, SIGSTOP, SIGCONT]:
    for p in pids: discard kill(Pid(p), SIGCONT)

proc serviceFail(m: Manager; u: Unit; result: string) =
  let d = sd(u)
  for t in [addr d.timer, addr d.restartTimer, addr d.pollTimer]: m.cancel(t[])
  d.state = svFailed
  m.setState(u, asFailed, "failed", result)

proc serviceResetFailed(m: Manager; u: Unit) =
  let d = sd(u)
  if d.state in {svFailed, svDead, svFailedBeforeAutoRestart, svDeadBeforeAutoRestart}:
    d.nRestarts = 0
    d.state = svDead
    u.result = "success"
    m.setState(u, asInactive, "dead", "success")

proc serviceStatus(m: Manager; u: Unit): StatusExtras =
  let d = sd(u)
  result = StatusExtras(mainPid: d.mainPid, controlPid: d.controlPid, exitCode: -1,
    statusText: d.statusText, nRestarts: d.nRestarts, cgroup: m.cgroupPath(u))
  result.pids = m.unitPids(u)
  if d.mainPid > 0 and d.mainPid notin result.pids: result.pids.add d.mainPid
  if d.mainExitSeen or d.lastKind != xkNone:
    result.exitCode = exitCodeFor(d.lastKind, d.lastCode)
    result.execMainStatus = d.lastCode
    result.execMainCode = ord(d.lastKind)

proc serviceBusy(u: Unit): bool =
  let d = sd(u)
  d.mainPid > 0 or d.controlPid > 0 or d.state notin {svDead, svFailed}

proc stamp(usec: int64): string =
  if usec == 0: "n/a" else: $usec

proc serviceProperties(m: Manager; u: Unit): seq[(string, string)] =
  let d = sd(u)
  let c = u.def.service
  result = @[("Type", $c.typ), ("Result", u.result), ("MainPID", $d.mainPid),
    ("ControlPID", $d.controlPid), ("ExecMainPID", $(if d.mainPid > 0: d.mainPid else: d.records[ekStart].pid)),
    ("ExecMainStatus", $d.lastCode), ("ExecMainCode", $ord(d.lastKind)),
    ("ExecMainStartTimestampMonotonic", $d.records[ekStart].startMono),
    ("NRestarts", $d.nRestarts), ("StatusText", d.statusText), ("StatusErrno", $d.notifyErrno),
    ("NotifyAccess", $d.notifyAccess), ("InvocationID", d.invocationId),
    ("ReloadResult", (if u.reloadResult.len == 0: "success" else: u.reloadResult)),
    ("WatchdogUSec", $d.watchdogUsec), ("RemainAfterExit", (if c.remainAfterExit: "yes" else: "no")),
    ("Restart", $c.restart), ("RestartUSec", $c.restartUsec),
    ("TimeoutStartUSec", $c.timeoutStartUsec), ("TimeoutStopUSec", $c.timeoutStopUsec),
    ("ControlGroup", m.cgroupPath(u))]

proc serviceShutdown(m: Manager; u: Unit) =
  let d = sd(u)
  for t in [addr d.timer, addr d.watchdogTimer, addr d.runtimeTimer, addr d.restartTimer, addr d.pollTimer]:
    m.cancel(t[])
  d.releaseFdStore()

proc serviceRedefine(m: Manager; u: Unit; old, fresh: UnitDef) =
  ## After daemon-reload the running unit keeps running with the new definition.
  u.def = fresh

proc attach*(m: Manager; u: Unit) =
  ## Wires the service behavior into `u` (called by the manager after loading).
  if u.kind != ukService: return
  u.data = ServiceData(state: svDead, notifyAccess: u.def.service.notifyAccess,
    watchdogUsec: u.def.service.watchdogUsec)
  u.sub = "dead"
  u.ops = UnitOps(start: serviceStart, stop: serviceStop, reload: serviceReload,
    canReload: proc(u: Unit): bool = u.def.service.commands[ekReload].len > 0 or u.def.service.typ == stNotifyReload,
    kill: serviceKill, fail: serviceFail, resetFailed: serviceResetFailed, status: serviceStatus,
    properties: serviceProperties, shutdown: serviceShutdown, isBusy: serviceBusy,
    redefine: serviceRedefine)

proc installNotifyHandler*(m: Manager) =
  m.notifyHandler = proc(m: Manager; u: Unit; pid: int; datagram: string; fds: seq[cint]) =
    if u.kind == ukService and u.data of ServiceData: handleNotify(m, u, pid, datagram, fds)
    else:
      for f in fds: discard close(f)
