## System call names, numbers and the `@group` sets of systemd 255. Numbers come from
## `<sys/syscall.h>` of the build's architecture: the C table is generated from the
## names below with `#ifdef SYS_name`, so a name the architecture lacks is simply
## absent (as with libseccomp).
import std/[strutils, tables]

const GroupSource = [
  ("@aio", "io_cancel io_destroy io_getevents io_pgetevents io_pgetevents_time64 io_setup io_submit io_uring_enter io_uring_register io_uring_setup"),
  ("@basic-io", "_llseek close close_range dup dup2 dup3 lseek pread64 preadv preadv2 pwrite64 pwritev pwritev2 read readv write writev"),
  ("@chown", "chown chown32 fchown fchown32 fchownat lchown lchown32"),
  ("@clock", "adjtimex clock_adjtime clock_adjtime64 clock_settime clock_settime64 settimeofday stime"),
  ("@cpu-emulation", "modify_ldt subpage_prot switch_endian vm86 vm86old"),
  ("@debug", "lookup_dcookie perf_event_open pidfd_getfd ptrace rtas s390_runtime_instr sys_debug_setcontext"),
  ("@default", "execve exit exit_group getrlimit rt_sigreturn sigreturn restart_syscall ugetrlimit rseq"),
  ("@file-system", "access chdir chmod close creat faccessat faccessat2 fallocate fchdir fchmod fchmodat fchmodat2 fcntl fcntl64 fgetxattr flistxattr fremovexattr fsetxattr fstat fstat64 fstatat64 fstatfs fstatfs64 ftruncate ftruncate64 futimesat getcwd getdents getdents64 getxattr inotify_add_watch inotify_init inotify_init1 inotify_rm_watch lgetxattr link linkat listxattr llistxattr lremovexattr lsetxattr lstat lstat64 mkdir mkdirat mknod mknodat newfstatat oldfstat oldlstat oldstat open openat openat2 readlink readlinkat removexattr rename renameat renameat2 rmdir setxattr stat stat64 statfs statfs64 statx symlink symlinkat truncate truncate64 unlink unlinkat utime utimensat utimensat_time64 utimes"),
  ("@io-event", "_newselect epoll_create epoll_create1 epoll_ctl epoll_ctl_old epoll_pwait epoll_pwait2 epoll_wait epoll_wait_old eventfd eventfd2 poll ppoll ppoll_time64 pselect6 pselect6_time64 select"),
  ("@ipc", "ipc memfd_create mq_getsetattr mq_notify mq_open mq_timedreceive mq_timedreceive_time64 mq_timedsend mq_timedsend_time64 mq_unlink msgctl msgget msgrcv msgsnd pipe pipe2 process_madvise process_vm_readv process_vm_writev semctl semget semop semtimedop semtimedop_time64 shmat shmctl shmdt shmget"),
  ("@keyring", "add_key keyctl request_key"),
  ("@memlock", "mlock mlock2 mlockall munlock munlockall"),
  ("@module", "delete_module finit_module init_module"),
  ("@mount", "chroot fsconfig fsmount fsopen fspick mount mount_setattr move_mount open_tree pivot_root umount umount2"),
  ("@network-io", "accept accept4 bind connect getpeername getsockname getsockopt listen recv recvfrom recvmmsg recvmmsg_time64 recvmsg send sendmmsg sendmsg sendto setsockopt shutdown socket socketcall socketpair"),
  ("@obsolete", "_sysctl afs_syscall bdflush break create_module ftime get_kernel_syms getpmsg gtty idle lock mpx prof profil putpmsg query_module security sgetmask ssetmask stty sysfs tuxcall ulimit uselib ustat vserver"),
  ("@pkey", "pkey_alloc pkey_free pkey_mprotect"),
  ("@privileged", "@chown @clock @module @raw-io @reboot @swap @setuid _sysctl acct bpf capset chroot fanotify_init fanotify_mark nfsservctl open_by_handle_at pivot_root quotactl quotactl_fd setdomainname setfsuid setfsuid32 sethostname vhangup"),
  ("@process", "arch_prctl capget clone clone3 execveat exit fork getrusage kill pidfd_open pidfd_send_signal prctl rt_sigqueueinfo rt_tgsigqueueinfo setns swapcontext tgkill times tkill unshare vfork wait4 waitid waitpid"),
  ("@raw-io", "ioperm iopl pciconfig_iobase pciconfig_read pciconfig_write s390_pci_mmio_read s390_pci_mmio_write"),
  ("@reboot", "kexec_file_load kexec_load reboot"),
  ("@resources", "ioprio_set mbind migrate_pages move_pages nice sched_setaffinity sched_setattr sched_setparam sched_setscheduler set_mempolicy set_mempolicy_home_node setpriority setrlimit"),
  ("@sandbox", "landlock_add_rule landlock_create_ruleset landlock_restrict_self seccomp"),
  ("@setuid", "setgid setgid32 setgroups setgroups32 setregid setregid32 setresgid setresgid32 setresuid setresuid32 setreuid setreuid32 setuid setuid32"),
  ("@signal", "rt_sigaction rt_sigpending rt_sigprocmask rt_sigsuspend rt_sigtimedwait rt_sigtimedwait_time64 sigaction sigaltstack signal signalfd signalfd4 sigpending sigprocmask sigsuspend"),
  ("@swap", "swapoff swapon"),
  ("@sync", "fdatasync fsync msync sync sync_file_range sync_file_range2 syncfs"),
  ("@system-service", "@aio @basic-io @chown @default @file-system @io-event @ipc @keyring @memlock @network-io @process @resources @setuid @signal @sync @timer @pkey brk capset copy_file_range fadvise64 fadvise64_64 flock get_mempolicy get_robust_list getcpu getegid getegid32 geteuid geteuid32 getgid getgid32 getgroups getgroups32 getpgid getpgrp getpid getppid getpriority getrandom getresgid getresgid32 getresuid getresuid32 getsid gettid getuid getuid32 ioctl kcmp madvise mincore mmap mmap2 mprotect mremap munmap name_to_handle_at oldolduname olduname personality prlimit64 readahead readdir remap_file_pages sched_get_priority_max sched_get_priority_min sched_getaffinity sched_getattr sched_getparam sched_getscheduler sched_rr_get_interval sched_yield set_robust_list set_thread_area set_tid_address setpgid setsid splice sysinfo tee umask uname userfaultfd vmsplice membarrier futex futex_time64 futex_waitv get_thread_area uretprobe cachestat map_shadow_stack mseal"),
  ("@timer", "alarm getitimer setitimer timer_create timer_delete timer_getoverrun timer_gettime timer_gettime64 timer_settime timer_settime64 timerfd_create timerfd_gettime timerfd_gettime64 timerfd_settime timerfd_settime64 times clock_getres clock_getres_time64 clock_gettime clock_gettime64 clock_nanosleep clock_nanosleep_time64 gettimeofday nanosleep time"),
]

const ExtraNames = "syslog sethostname setdomainname sched_setscheduler sched_setattr mknod mknodat socket chmod fchmod fchmodat fchmodat2 clone clone3 unshare setns mmap mprotect pkey_mprotect shmat personality execve"

proc groupNames*(): seq[string] =
  for (g, _) in GroupSource: result.add g

func allSyscallNames(): seq[string] =
  var seen: seq[string]
  for (_, body) in GroupSource:
    for w in (body & " " & ExtraNames).split(' '):
      if w.len > 0 and w[0] != '@' and w notin seen: seen.add w
  seen

func cTable(): string =
  result = "/*TYPESECTION*/\n#ifdef __linux__\n#include <sys/syscall.h>\n#include <string.h>\n" &
    "typedef struct { const char *name; int nr; } sdc_sc_t;\nstatic const sdc_sc_t sdc_sc_table[] = {\n"
  for n in allSyscallNames():
    result.add "#ifdef SYS_" & n & "\n{\"" & n & "\", SYS_" & n & "},\n#endif\n"
  result.add "{0, 0}};\n" &
    "static int sdc_syscall_nr(const char *n) { for (const sdc_sc_t *p = sdc_sc_table; p->name; p++) if (!strcmp(p->name, n)) return p->nr; return -1; }\n" &
    "#else\nstatic int sdc_syscall_nr(const char *n) { (void)n; return -1; }\n#endif\n"

const cSource = cTable()
{.emit: cSource.}
proc sdcSyscallNr(name: cstring): cint {.importc: "sdc_syscall_nr", nodecl.}

proc syscallNumber*(name: string): int =
  ## -1 when this architecture has no such system call.
  int(sdcSyscallNr(name.cstring))

proc buildGroups(): Table[string, seq[string]] =
  for (g, body) in GroupSource: result[g] = body.split(' ')

let groups = buildGroups()

proc groupMembers*(name: string): seq[string] =
  ## The members of a `@group` in table order; a member that is itself a
  ## `@group` stays as it is. Empty for an unknown group.
  if name notin groups: return @[]
  for w in groups[name]:
    if w.len > 0: result.add w

proc expandSyscallEntry*(entry: string; seen: seq[string] = @[]): seq[string] =
  ## `@group` (recursively) or a plain name. Raises KeyError for an unknown group.
  if entry.len > 0 and entry[0] == '@':
    if entry == "@known":
      for g in groups.keys:
        if g != "@known": result.add expandSyscallEntry(g, seen)
      return
    if entry in seen: return
    if entry notin groups: raise newException(KeyError, "unknown system call group " & entry)
    for w in groups[entry]:
      if w.len > 0: result.add expandSyscallEntry(w, seen & entry)
  else:
    result.add entry
