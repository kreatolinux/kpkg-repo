## The executor (spec §10.1): sets up one process and `execve`s the program.
## Runs with the manager's privileges inside the unit's cgroup. Exit statuses
## 200..245 follow Appendix D; the step name is printed to standard error.
##
## Environment, identity (also `DynamicUser=`), credentials, rlimits,
## scheduling, umask, working directory, stdio, state directories, descriptor
## passing, namespaces and the mount sandbox (sandbox.nim), capabilities
## (caps.nim) and seccomp filters (seccomp.nim). A setting that cannot be applied
## is listed in `unsupported` by the manager and fails closed (226/218/228).
import std/[algorithm, os, posix, strutils, tables, options]
import ./[caps, context, creds, dynuser, envsubst, failure, sandbox, seccomp]

# ---- libc pieces missing from std/posix --------------------------------------
proc setpriorityC(which: cint; who: cuint; prio: cint): cint {.importc: "setpriority", header: "<sys/resource.h>".}
proc umaskC(mask: Mode): Mode {.importc: "umask", header: "<sys/stat.h>".}
proc getgrouplistC(user: cstring; group: Gid; groups: ptr Gid; n: ptr cint): cint
  {.importc: "getgrouplist", header: "<grp.h>".}
proc setgroupsC(n: csize_t; groups: ptr Gid): cint {.importc: "setgroups", header: "<grp.h>".}
proc prctlC(option: cint; a2, a3, a4, a5: culong): cint {.importc: "prctl", header: "<sys/prctl.h>".}
proc syscallC(n: clong): clong {.importc: "syscall", header: "<unistd.h>", varargs.}
when defined(linux):
  type SchedParam {.importc: "struct sched_param", header: "<sched.h>", pure.} = object
    sched_priority: cint
  proc schedSetscheduler(pid: Pid; policy: cint; param: ptr SchedParam): cint
    {.importc: "sched_setscheduler", header: "<sched.h>".}

type Rlim = typeof(RLimit().rlim_cur)
var RLIM_INFINITY {.importc, header: "<sys/resource.h>".}: Rlim

const BuiltinPath = ["/usr/local/sbin", "/usr/local/bin", "/usr/sbin", "/usr/bin", "/sbin", "/bin"]

proc rlimitResource(name: string): int =
  case name
  of "CPU": 0
  of "FSIZE": 1
  of "DATA": 2
  of "STACK": 3
  of "CORE": 4
  of "RSS": 5
  of "NPROC": 6
  of "NOFILE": 7
  of "MEMLOCK": 8
  of "AS": 9
  of "LOCKS": 10
  of "SIGPENDING": 11
  of "MSGQUEUE": 12
  of "NICE": 13
  of "RTPRIO": 14
  of "RTTIME": 15
  else: -1

# ---- steps -------------------------------------------------------------------
proc checkCgroup(ctx: ExecSpec) =
  if ctx.expectedCgroup.len == 0: return
  let text = try: readFile("/proc/self/cgroup") except IOError: ""
  for line in text.splitLines:
    if line.startsWith("0::") and line.endsWith(ctx.expectedCgroup): return
  fail("CGROUP", 219, "process is not in cgroup " & ctx.expectedCgroup)

proc openFlags(kind: string; input: bool): cint =
  case kind
  of "append": O_WRONLY or O_CREAT or O_APPEND
  of "truncate": O_WRONLY or O_CREAT or O_TRUNC
  of "file": (if input: O_RDONLY else: O_WRONLY or O_CREAT or O_APPEND)
  else: (if input: O_RDONLY else: O_WRONLY)

proc setupStdio(ctx: ExecSpec) =
  let specs = [ctx.stdin, ctx.stdout, ctx.stderr]
  let steps = [("STDIN", 208), ("STDOUT", 209), ("STDERR", 222)]
  for i in 0 .. 2:
    let s = specs[i]
    if s.inherited or s.kind in ["", "inherit", "journal", "kmsg", "socket"]: continue
    var fd: cint
    case s.kind
    of "null": fd = open("/dev/null", if i == 0: O_RDONLY else: O_RDWR)
    of "tty", "tty-force", "tty-fail":
      fd = open(if s.path.len > 0: s.path.cstring else: "/dev/console", O_RDWR or O_NOCTTY)
      if fd >= 0 and i == 0:
        when defined(linux):
          discard ioctl(fd, 0x540E.culong, 1)      # TIOCSCTTY, steal=1
    of "file", "append", "truncate":
      fd = open(s.path.cstring, openFlags(s.kind, i == 0), 0o666)
    else: fail(steps[i][0], steps[i][1], "unsupported standard stream kind " & s.kind)
    if fd < 0: fail(steps[i][0], steps[i][1], errnoMsg())
    if fd != cint(i):
      if dup2(fd, cint(i)) < 0: fail(steps[i][0], steps[i][1], errnoMsg())
      discard close(fd)

type Identity = object
  set: bool
  uid: Uid
  gid: Gid
  home, shell, name: string
  groups: seq[Gid]
  dynamic: bool

proc dynamicIdentity(ctx: ExecSpec): Identity =
  let id = allocateDynamicId(ctx.unit, ctx.dynamicUsersDir)
  result.set = true
  result.uid = Uid(id)
  result.gid = Gid(id)
  result.name = ctx.unit.rsplit('.', maxsplit = 1)[0]
  result.home = "/"
  result.shell = "/usr/sbin/nologin"
  result.dynamic = true
  for g in ctx.supplementaryGroups:
    let gr = if g.allCharsInSet({'0'..'9'}): getgrgid(Gid(parseInt(g))) else: getgrnam(g.cstring)
    if gr == nil: fail("GROUP", 216, "no such group: " & g)
    result.groups.add gr.gr_gid

proc resolveIdentity(ctx: ExecSpec): Identity =
  if ctx.dynamicUser and not ctx.skipIdentity and
      (ctx.user.len == 0 or (not ctx.user.allCharsInSet({'0'..'9'}) and getpwnam(ctx.user.cstring) == nil)):
    return dynamicIdentity(ctx)
  if ctx.skipIdentity or (ctx.user.len == 0 and ctx.group.len == 0 and
      ctx.supplementaryGroups.len == 0): return
  result.set = true
  result.uid = getuid()
  result.gid = getgid()
  if ctx.user.len > 0:
    var pw: ptr Passwd
    if ctx.user.allCharsInSet({'0'..'9'}):
      pw = getpwuid(Uid(parseInt(ctx.user)))
      result.uid = Uid(parseInt(ctx.user))
    else:
      pw = getpwnam(ctx.user.cstring)
      if pw == nil: fail("USER", 217, "no such user: " & ctx.user)
    if pw != nil:
      result.uid = pw.pw_uid
      result.gid = pw.pw_gid
      result.home = $pw.pw_dir
      result.shell = $pw.pw_shell
      result.name = $pw.pw_name
  if ctx.group.len > 0:
    let gr = if ctx.group.allCharsInSet({'0'..'9'}): getgrgid(Gid(parseInt(ctx.group)))
             else: getgrnam(ctx.group.cstring)
    if gr != nil: result.gid = gr.gr_gid
    elif ctx.group.allCharsInSet({'0'..'9'}): result.gid = Gid(parseInt(ctx.group))
    else: fail("GROUP", 216, "no such group: " & ctx.group)
  for g in ctx.supplementaryGroups:
    let gr = if g.allCharsInSet({'0'..'9'}): getgrgid(Gid(parseInt(g))) else: getgrnam(g.cstring)
    if gr == nil: fail("GROUP", 216, "no such group: " & g)
    result.groups.add gr.gr_gid
  if result.name.len > 0:
    var n: cint = 64
    var buf = newSeq[Gid](64)
    if getgrouplistC(result.name.cstring, result.gid, addr buf[0], addr n) < 0 and n > 64:
      buf = newSeq[Gid](n)
      discard getgrouplistC(result.name.cstring, result.gid, addr buf[0], addr n)
    for i in 0 ..< max(0, int(n)):
      if buf[i] notin result.groups: result.groups.add buf[i]

proc makeDirs(ctx: ExecSpec; id: Identity; env: var Table[string, string]) =
  ## `RuntimeDirectory=` and friends (§10.5): created below the root, owned
  ## by the service user, `*_DIRECTORY` variable set.
  let kinds = [("RUNTIME_DIRECTORY", ctx.runtimeRoot, ctx.runtimeDirectory, "RUNTIME_DIRECTORY", 233),
               ("STATE_DIRECTORY", ctx.stateRoot, ctx.stateDirectory, "STATE_DIRECTORY", 238),
               ("CACHE_DIRECTORY", ctx.cacheRoot, ctx.cacheDirectory, "CACHE_DIRECTORY", 239),
               ("LOGS_DIRECTORY", ctx.logsRoot, ctx.logsDirectory, "LOGS_DIRECTORY", 240),
               ("CONFIGURATION_DIRECTORY", ctx.configRoot, ctx.configurationDirectory,
                "CONFIGURATION_DIRECTORY", 241)]
  for (varName, root, spec, step, status) in kinds:
    if spec.names.len == 0: continue
    var paths: seq[string]
    for name in spec.names:
      # with DynamicUser= state, cache and logs live below `private/` (§10.5), the usual name a symlink
      let priv = id.dynamic and varName in ["STATE_DIRECTORY", "CACHE_DIRECTORY", "LOGS_DIRECTORY"]
      let p = if priv: root / "private" / name else: root / name
      try:
        if priv:
          createDir(root / "private")
          discard chmod((root / "private").cstring, 0o700)
        createDir(p)
      except OSError: fail(step, status, "cannot create " & p & ": " & errnoMsg())
      if priv:
        let link = root / name
        if not symlinkExists(link) and not dirExists(link):
          if symlink(("private" / name).cstring, link.cstring) != 0:
            fail(step, status, "cannot create " & link & ": " & errnoMsg())
      discard chmod(p.cstring, Mode(if spec.mode == 0: 0o755 else: spec.mode))
      if id.set and chown(p.cstring, id.uid, id.gid) != 0:
        fail("CHOWN", 235, "cannot chown " & p & ": " & errnoMsg())
      paths.add (if priv: root / name else: p)
    env[varName] = paths.join(":")

proc buildEnvironment(ctx: ExecSpec; id: Identity): Table[string, string] =
  var protectedSet: seq[string] = ctx.protectedEnv
  var final = initTable[string, string]()
  if id.set and id.name.len > 0:
    final["HOME"] = id.home
    final["LOGNAME"] = id.name
    final["USER"] = id.name
    final["SHELL"] = if id.shell.len == 0: "/bin/sh" else: id.shell
  for (k, v) in ctx.environment: final[k] = v
  for f in ctx.environmentFiles:
    var path = f
    var optional = false
    if path.startsWith("-"):
      optional = true
      path = path[1 .. ^1]
    var files: seq[string]
    if '*' in path or '?' in path or '[' in path:
      for p in walkPattern(path): files.add p
      files.sort
    else: files.add path
    for file in files:
      let text = try: readFile(file)
                 except IOError:
                   if optional: "" else: fail("FDS", 202, "cannot read " & file)
      var bad: seq[string]
      for (k, v) in parseEnvFile(text, bad):
        if k notin protectedSet: final[k] = v
      for b in bad: stderr.writeLine "Ignoring invalid line in " & file & ": " & b
  var managerEnv = initTable[string, string]()
  for (k, v) in ctx.managerEnvironment: managerEnv[k] = v
  for name in ctx.passEnvironment:
    if name notin protectedSet and managerEnv.hasKey(name): final[name] = managerEnv[name]
  for (k, v) in ctx.environment:
    if k in protectedSet: final[k] = v
  for u in ctx.unsetEnvironment:
    let eq = u.find('=')
    let name = if eq < 0: u else: u[0 ..< eq]
    if name in protectedSet: continue
    if eq < 0 or final.getOrDefault(name) == u[eq + 1 .. ^1]: final.del name
  final

proc applyLimits(ctx: ExecSpec) =
  for l in ctx.limits:
    let r = rlimitResource(l.resource)
    if r < 0: fail("LIMITS", 205, "unknown limit " & l.resource)
    let inf = RLIM_INFINITY
    var lim = RLimit(rlim_cur: if l.soft < 0: inf else: Rlim(l.soft),
                     rlim_max: if l.hard < 0: inf else: Rlim(l.hard))
    if setrlimit(cint(r), lim) != 0:
      when defined(linux): fail("LIMITS", 205, l.resource & ": " & errnoMsg())
      else: stderr.writeLine "ignoring limit " & l.resource & ": " & errnoMsg()   # macOS clamps differently

proc applyScheduling(ctx: ExecSpec) =
  if ctx.nice.isSome and setpriorityC(0, 0, cint(ctx.nice.get)) != 0:
    fail("NICE", 201, errnoMsg())
  if ctx.oomScoreAdjust.isSome:
    try: writeFile("/proc/self/oom_score_adj", $ctx.oomScoreAdjust.get)
    except IOError: fail("OOM_ADJUST", 206, errnoMsg())
  when defined(linux):
    if ctx.ioSchedulingClass.isSome or ctx.ioSchedulingPriority.isSome:
      let cls = ctx.ioSchedulingClass.get(2)
      let prio = ctx.ioSchedulingPriority.get(4)
      # ioprio_set(IOPRIO_WHO_PROCESS=1, 0, class << 13 | prio)
      when defined(arm64): (const sys = 30)
      elif defined(amd64): (const sys = 251)
      else: (const sys = 251)
      if syscallC(sys, 1, 0, (cls shl 13) or prio) != 0: fail("IOPRIO", 211, errnoMsg())
    if ctx.timerSlackNsec.isSome and prctlC(29, culong(ctx.timerSlackNsec.get), 0, 0, 0) != 0:
      fail("TIMERSLACK", 212, errnoMsg())
    if ctx.cpuSchedulingPolicy.isSome:
      var prio = SchedParam(sched_priority: cint(ctx.cpuSchedulingPriority.get(0)))
      var policy = cint(ctx.cpuSchedulingPolicy.get)
      if ctx.cpuSchedulingResetOnFork: policy = policy or 0x40000000
      if schedSetscheduler(0, policy, addr prio) != 0: fail("SETSCHEDULER", 214, errnoMsg())

proc applyIdentity(id: Identity) =
  if not id.set: return
  var groups = id.groups
  let gp: ptr Gid = if groups.len == 0: nil else: addr groups[0]
  if setgroupsC(csize_t(groups.len), gp) != 0 and geteuid() == 0:
    fail("GROUP", 216, "setgroups: " & errnoMsg())
  if setgid(id.gid) != 0 and getgid() != id.gid: fail("GROUP", 216, "setgid: " & errnoMsg())
  if setuid(id.uid) != 0 and getuid() != id.uid: fail("USER", 217, "setuid: " & errnoMsg())

proc unsupportedStep(entry: string): (string, int) =
  case entry.split(':')[0]
  of "CAPABILITIES": ("CAPABILITIES", 218)
  of "SECCOMP": ("SECCOMP", 228)
  of "ADDRESS_FAMILIES": ("ADDRESS_FAMILIES", 232)
  of "NETWORK": ("NETWORK", 225)
  else: ("NAMESPACE", 226)

proc findExecutable(path: string): string =
  if '/' in path: return path
  for d in BuiltinPath:
    let candidate = d / path
    if fileExists(candidate) and access(candidate.cstring, X_OK) == 0: return candidate
  path

proc runContext*(ctx: ExecSpec) =
  ## Applies the steps of §10.1.2 and never returns on success (execve).
  checkCgroup(ctx)
  setupStdio(ctx)
  if ctx.unsupported.len > 0:
    let (step, status) = unsupportedStep(ctx.unsupported[0])
    fail(step, status, "not supported by this core: " & ctx.unsupported.join(", "))
  let id = resolveIdentity(ctx)
  var env = buildEnvironment(ctx, id)
  let credDir = setupCredentials(ctx, if id.set: id.uid else: getuid(), if id.set: id.gid else: getgid(), id.set)
  if credDir.len > 0: env["CREDENTIALS_DIRECTORY"] = credDir
  makeDirs(ctx, id, env)
  applyLimits(ctx)
  applyScheduling(ctx)
  let confine = not ctx.privileged
  if confine:
    applyNetwork(ctx)
    applyNamespaces(ctx)
  let capPlan = if confine: planCapabilities(ctx) else: CapPlan()
  dropBounding(capPlan, id.set and ctx.ambientCapabilities.len > 0)
  applyIdentity(id)
  finishCapabilities(capPlan, ctx)
  when defined(linux):
    if ctx.noNewPrivileges and prctlC(38, 1, 0, 0, 0) != 0:
      fail("NO_NEW_PRIVILEGES", 227, errnoMsg())
  if ctx.workingDirectory.len > 0:
    var wd = ctx.workingDirectory
    let optional = wd.startsWith("-")
    if optional: wd = wd[1 .. ^1]
    if wd == "~": wd = (if id.home.len > 0: id.home else: "/")
    if chdir(wd.cstring) != 0 and not optional: fail("CHDIR", 200, wd & ": " & errnoMsg())
  discard umaskC(Mode(if ctx.umask < 0: 0o022 else: ctx.umask))
  if ctx.ignoreSigpipe: signal(SIGPIPE, SIG_IGN)
  # §10.1.2 step 16: the manager passed the socket descriptors at 3, 4, ... already; only the environment is set here
  if ctx.listenFds and ctx.fds.len > 0:
    env["LISTEN_PID"] = $getpid()
    env["LISTEN_FDS"] = $ctx.fds.len
    var names: seq[string]
    for f in ctx.fds: names.add f.name
    env["LISTEN_FDNAMES"] = names.join(":")
  if confine: installFilters(ctx)
  var words = if ctx.noEnvSubst: ctx.args else: expandArgs(ctx.args, env)
  let exe = findExecutable(ctx.path)
  var argv = @[if ctx.argv0.len > 0: ctx.argv0 else: exe] & words
  var envp: seq[string]
  for k, v in env: envp.add k & "=" & v
  let cargv = allocCStringArray(argv)
  let cenv = allocCStringArray(envp)
  if ctx.statusFd > 2: discard fcntl(cint(ctx.statusFd), F_SETFD, FD_CLOEXEC)
  discard execve(exe.cstring, cargv, cenv)
  fail("EXEC", 203, exe & ": " & errnoMsg())

proc readAllFd(fd: cint): string =
  var buf = newString(4096)
  while true:
    let n = read(fd, addr buf[0], buf.len)
    if n > 0: result.add buf[0 ..< n]
    elif n == 0: break
    elif errno != EINTR: break

proc reportFailure(ctx: ExecSpec; status: int; step, msg: string) =
  ## Standard error gets systemd's message; the status descriptor gets
  ## `STATUS STEP` so the manager can tell a setup failure from a program exit.
  stderr.writeLine "Failed at step " & step & " spawning " & ctx.path & ": " & msg
  if ctx.statusFd > 2:
    let line = $status & " " & step & "\n"
    discard write(cint(ctx.statusFd), line.cstring, line.len)

proc executorMain*(args: seq[string]): int =
  ## `systemd-compat-exec --context-fd N [--status-fd M]`. Returns only on failure.
  var ctxFd = -1
  var i = 0
  while i < args.len:
    if args[i] == "--context-fd" and i + 1 < args.len:
      ctxFd = parseInt(args[i + 1]); i += 2
    else: inc i
  if ctxFd < 0:
    stderr.writeLine "usage: systemd-compat-exec --context-fd N"
    return 126
  var ctx: ExecSpec
  try:
    ctx = parseContext(readAllFd(cint(ctxFd)))
    discard close(cint(ctxFd))
  except CatchableError as e:
    stderr.writeLine "systemd-compat-exec: bad context: " & e.msg
    return 126
  try:
    runContext(ctx)
  except StepFailure as e:
    reportFailure(ctx, e.status, e.step, e.msg)
    return e.status
  except CatchableError as e:
    reportFailure(ctx, 203, "EXEC", e.msg)
    return 203
  203
