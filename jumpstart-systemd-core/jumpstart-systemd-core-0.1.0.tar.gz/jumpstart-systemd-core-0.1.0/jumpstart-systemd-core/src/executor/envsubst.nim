## `EnvironmentFile=` parsing (spec §10.2) and `$VAR` / `${VAR}` expansion in
## command arguments (spec §9.3.1). Pure.
import std/[strutils, tables]

proc validEnvName*(s: string): bool =
  if s.len == 0 or s[0] in {'0'..'9'}: return false
  for c in s:
    if c notin {'A'..'Z', 'a'..'z', '0'..'9', '_'}: return false
  true

proc unquote(raw: string): string =
  ## Value rules of systemd environment files: single quotes are literal,
  ## double quotes honour a few escapes, outside quotes `\x` is `x`.
  var i = 0
  var quote = '\0'
  while i < raw.len:
    let c = raw[i]
    if quote == '\'':
      if c == '\'': quote = '\0' else: result.add c
    elif quote == '"':
      if c == '"': quote = '\0'
      elif c == '\\' and i + 1 < raw.len:
        inc i
        case raw[i]
        of 'n': result.add '\n'
        of 't': result.add '\t'
        of '\n': discard
        else: result.add raw[i]
      else: result.add c
    elif c in {'\'', '"'}: quote = c
    elif c == '\\' and i + 1 < raw.len:
      inc i
      if raw[i] != '\n': result.add raw[i]
    else: result.add c
    inc i

proc parseEnvFile*(text: string; bad: var seq[string]): seq[(string, string)] =
  ## Lines of KEY=VALUE; `#`/`;` comments; a trailing backslash continues the
  ## line. Invalid lines are collected in `bad` and skipped.
  var lines = text.splitLines
  var i = 0
  while i < lines.len:
    var line = lines[i].strip(leading = true, trailing = false)
    inc i
    if line.len == 0 or line[0] in {'#', ';'}: continue
    while line.endsWith("\\") and i < lines.len:        # continuation
      line = line[0 ..< line.len - 1] & "\n" & lines[i]
      inc i
    let eq = line.find('=')
    if eq <= 0:
      bad.add line
      continue
    let key = line[0 ..< eq].strip
    if not validEnvName(key):
      bad.add line
      continue
    result.add (key, unquote(line[eq + 1 .. ^1].strip))

proc expandArgs*(words: seq[string]; env: Table[string, string]): seq[string] =
  ## `$VAR` as a whole word splits at white space (unset: no argument),
  ## `${VAR}` is replaced verbatim (a whole-word unset one yields no argument),
  ## `$$` is a literal dollar.
  for w in words:
    if w.len > 1 and w[0] == '$' and w[1] notin {'$', '{'} and validEnvName(w[1 .. ^1]):
      let name = w[1 .. ^1]
      if env.hasKey(name): result.add env[name].splitWhitespace
      continue
    var out1 = ""
    var i = 0
    var anyUnset = false
    var onlyRef = w.startsWith("${") and w.endsWith("}") and w.count("${") == 1
    while i < w.len:
      if w[i] == '$' and i + 1 < w.len and w[i + 1] == '$':
        out1.add '$'; i += 2
      elif w[i] == '$' and i + 1 < w.len and w[i + 1] == '{':
        let close = w.find('}', i + 2)
        if close < 0: out1.add w[i]; inc i; continue
        let name = w[i + 2 ..< close]
        if env.hasKey(name): out1.add env[name]
        else: anyUnset = true
        i = close + 1
      else:
        out1.add w[i]; inc i
    if onlyRef and anyUnset: continue
    result.add out1
