## `DynamicUser=` (spec §10.6): a uid (and gid of the same value) from
## 61184..65519, stable for a unit name, recorded below `ST/dynamic-users/`.
import std/[os, posix, strutils]
import ./failure

const
  First = 61184
  Count = 4336

proc crc32*(s: string): uint32 =
  var crc = 0xffffffff'u32
  for ch in s:
    crc = crc xor uint32(ord(ch))
    for _ in 0 .. 7:
      crc = if (crc and 1) != 0: (crc shr 1) xor 0xedb88320'u32 else: crc shr 1
  not crc

proc idsInFile(path: string; field: int): seq[int] =
  try:
    for line in lines(path):
      let f = line.split(':')
      if f.len > field:
        try: result.add parseInt(f[field])
        except ValueError: discard
  except IOError: discard

proc allocateDynamicId*(unit, recordDir: string): int =
  ## Reuses the unit's record, else claims the first free id from the unit's
  ## hash (an id is taken when another unit recorded it or a passwd/group entry
  ## uses it).
  let name = unit
  try: createDir(recordDir)
  except OSError as e: fail("USER", 217, "cannot create " & recordDir & ": " & e.msg)
  for kind, p in walkDir(recordDir):
    if kind == pcFile:
      try:
        if readFile(p).strip == name: return parseInt(p.extractFilename)
      except CatchableError: discard
  let used = idsInFile("/etc/passwd", 2) & idsInFile("/etc/group", 2)
  let start = int(crc32(name) mod uint32(Count))
  for i in 0 ..< Count:
    let id = First + (start + i) mod Count
    if id in used: continue
    let rec = recordDir / $id
    let fd = open(rec.cstring, O_WRONLY or O_CREAT or O_EXCL or O_CLOEXEC, 0o644)
    if fd < 0:
      if errno == EEXIST: continue
      fail("USER", 217, "cannot record dynamic user " & rec & ": " & errnoMsg())
    let line = name & "\n"
    discard write(fd, line.cstring, line.len)
    discard close(fd)
    return id
  fail("USER", 217, "no free dynamic user id")
