## Namespaces and the filesystem sandbox (spec §10.4, executor steps 9 and 10).
##
## Network, IPC and UTS namespaces, and a mount namespace in which the mount
## operations of the unit's settings are applied parents first. Raw `mount(2)`,
## `unshare(2)`, `setns(2)` and `pivot_root(2)`. Every failure is step
## NAMESPACE (226) or NETWORK (225): the executor never runs a unit with a
## weaker sandbox than asked for.
##
## Host paths needed after other mounts have hidden them (bind sources, the
## private `/tmp` directories, the host `/dev`) are opened with `O_PATH` first
## and mounted from `/proc/self/fd/N`. With `RootDirectory=` the old root stays
## at `/.sdc-oldroot` until every operation is done.
import std/os
when defined(linux):
  import std/[algorithm, posix, sequtils, strutils]
import ./[context, failure]

proc needsMountNamespace*(sb: SandboxSpec): bool =
  sb.rootDirectory.len > 0 or sb.privateTmp or sb.privateDevices or sb.privateMounts or
    sb.protectSystem.len > 0 or sb.protectHome.len > 0 or sb.protectKernelTunables or
    sb.protectKernelModules or sb.protectKernelLogs or sb.protectControlGroups or sb.protectClock or
    sb.protectProc.len > 0 or sb.procSubset.len > 0 or sb.mountFlags.len > 0 or
    sb.bindPaths.len > 0 or sb.bindReadOnlyPaths.len > 0 or sb.temporaryFileSystem.len > 0 or
    sb.readWritePaths.len > 0 or sb.readOnlyPaths.len > 0 or sb.inaccessiblePaths.len > 0 or
    sb.execPaths.len > 0 or sb.noExecPaths.len > 0

proc privateTmpPaths*(invocationId, unit: string): seq[string] =
  ## The two host directories `PrivateTmp=` binds on `/tmp` and `/var/tmp`.
  let name = "systemd-private-" & (if invocationId.len > 0: invocationId else: "noinvocation") &
    "-" & unit & "-sdc"
  @["/tmp" / name, "/var/tmp" / name]

proc removePrivateTmp*(invocationId, unit: string) =
  ## For the manager, when the unit's cgroup is empty after a stop.
  for d in privateTmpPaths(invocationId, unit):
    try: removeDir(d)
    except OSError: discard

when not defined(linux):
  proc applyNetwork*(ctx: ExecSpec) =
    let sb = ctx.sandbox
    if sb.privateNetwork or sb.networkNamespacePath.len > 0:
      fail("NETWORK", 225, "network namespaces need Linux")
  proc applyNamespaces*(ctx: ExecSpec) =
    let sb = ctx.sandbox
    if needsMountNamespace(sb) or sb.privateIpc or sb.ipcNamespacePath.len > 0 or sb.protectHostname:
      fail("NAMESPACE", 226, "namespaces need Linux")
else:
  const
    MS_RDONLY = 1.culong
    MS_NOSUID = 2.culong
    MS_NODEV = 4.culong
    MS_NOEXEC = 8.culong
    MS_REMOUNT = 32.culong
    MS_NOATIME = 1024.culong
    MS_NODIRATIME = 2048.culong
    MS_BIND = 4096.culong
    MS_REC = 16384.culong
    MS_PRIVATE = 262144.culong
    MS_SLAVE = 524288.culong
    MS_SHARED = 1048576.culong
    MNT_DETACH = 2.cint
    CloneNewNs = 0x00020000.cint
    CloneNewUts = 0x04000000.cint
    CloneNewIpc = 0x08000000.cint
    CloneNewUser = 0x10000000.cint
    CloneNewNet = 0x40000000.cint
    OPath = 0x200000.cint
    OldRoot = "/.sdc-oldroot"

  proc mountC(src, target, fstype: cstring; flags: culong; data: pointer): cint
    {.importc: "mount", header: "<sys/mount.h>".}
  proc umount2C(target: cstring; flags: cint): cint {.importc: "umount2", header: "<sys/mount.h>".}
  proc syscallC(n: clong): clong {.importc: "syscall", header: "<unistd.h>", varargs.}
  proc prctlC(option: cint; a2, a3, a4, a5: culong): cint {.importc: "prctl", header: "<sys/prctl.h>".}
  var SysUnshare {.importc: "SYS_unshare", header: "<sys/syscall.h>".}: clong
  var SysSetns {.importc: "SYS_setns", header: "<sys/syscall.h>".}: clong
  var SysPivotRoot {.importc: "SYS_pivot_root", header: "<sys/syscall.h>".}: clong

  template nsFail(msg: string) = fail("NAMESPACE", 226, msg)

  var gOld = ""                       ## prefix of the host's root while it is still mounted
  var gUserNs = false

  # ---- small helpers ----------------------------------------------------------
  proc doMount(src, target, fstype: string; flags: culong; data = "") =
    let d: pointer = if data.len > 0: cast[pointer](data.cstring) else: nil
    let s: cstring = if src.len > 0: src.cstring else: nil
    let f: cstring = if fstype.len > 0: fstype.cstring else: nil
    if mountC(s, target.cstring, f, flags, d) != 0:
      nsFail("mount " & (if fstype.len > 0: fstype elif src.len > 0: src else: "remount") &
             " on " & target & ": " & errnoMsg())

  proc pathExists(p: string): bool =
    var st: Stat
    lstat(p.cstring, st) == 0

  proc isDirectory(p: string): bool =
    var st: Stat
    stat(p.cstring, st) == 0 and S_ISDIR(st.st_mode)

  proc mkdirP(p: string; mode: Mode = 0o755) =
    var cur = ""
    for part in p.split('/'):
      if part.len == 0: continue
      cur.add "/" & part
      if mkdir(cur.cstring, mode) != 0 and errno != EEXIST:
        nsFail("cannot create " & cur & ": " & errnoMsg())

  proc parentOf(p: string): string =
    let i = p.rfind('/')
    if i <= 0: "/" else: p[0 ..< i]

  proc resolvePath(path: string): string =
    ## `path` with the symbolic links of its existing prefix resolved, below the
    ## current root. The missing rest is appended unchanged.
    var todo: seq[string]
    for c in path.split('/'):
      if c.len > 0: todo.add c
    var cur = "/"
    var hops = 0
    var i = 0
    while i < todo.len:
      let c = todo[i]
      inc i
      if c == ".": continue
      if c == "..":
        cur = parentOf(cur)
        continue
      let cand = if cur == "/": "/" & c else: cur & "/" & c
      var st: Stat
      if lstat(cand.cstring, st) != 0:
        cur = cand
        while i < todo.len:
          cur.add "/" & todo[i]
          inc i
        break
      if S_ISLNK(st.st_mode):
        inc hops
        if hops > 40: nsFail("too many symbolic links in " & path)
        var buf = newString(4096)
        let n = readlink(cand.cstring, cast[cstring](addr buf[0]), buf.len)
        if n < 0: nsFail("cannot read link " & cand & ": " & errnoMsg())
        buf.setLen n
        var rest: seq[string]
        for p in buf.split('/'):
          if p.len > 0: rest.add p
        if buf.startsWith("/"): cur = "/"
        todo = rest & todo[i .. ^1]
        i = 0
        continue
      cur = cand
    cur

  proc cleanPath(p: string): string =
    var s = normalizedPath("/" & p)
    if s.len > 1 and s.endsWith("/"): s.setLen s.len - 1
    s

  type MountEntry = object
    mountPoint: string
    flags: culong

  proc unescapeMountinfo(s: string): string =
    var i = 0
    while i < s.len:
      if s[i] == '\\' and i + 3 < s.len and s[i + 1] in {'0'..'3'}:
        result.add char(parseOctInt(s[i + 1 .. i + 3]))
        i += 4
      else:
        result.add s[i]
        inc i

  proc readMountInfo(): seq[MountEntry] =
    var text: string
    try: text = readFile("/proc/self/mountinfo")
    except IOError:
      try: text = readFile(gOld & "/proc/self/mountinfo")
      except IOError: nsFail("cannot read /proc/self/mountinfo")
    for line in text.splitLines:
      let f = line.split(' ')
      if f.len < 6: continue
      var e = MountEntry(mountPoint: unescapeMountinfo(f[4]))
      for o in f[5].split(','):
        case o
        of "ro": e.flags = e.flags or MS_RDONLY
        of "nosuid": e.flags = e.flags or MS_NOSUID
        of "nodev": e.flags = e.flags or MS_NODEV
        of "noexec": e.flags = e.flags or MS_NOEXEC
        of "noatime": e.flags = e.flags or MS_NOATIME
        of "nodiratime": e.flags = e.flags or MS_NODIRATIME
        else: discard
      result.add e

  proc isMountPoint(p: string): bool =
    for e in readMountInfo():
      if e.mountPoint == p: return true

  proc remountTree(path: string; setFlags, clearFlags: culong; topOnly = false; tolerant = false) =
    ## Changes the per-mount flags of `path` and of every mount below it (a
    ## recursive bind remount keeps no submounts, so each one is visited).
    var entries = readMountInfo()
    var seen: seq[string]
    var picked: seq[MountEntry]
    for i in countdown(entries.high, 0):
      let e = entries[i]
      if e.mountPoint in seen: continue
      if e.mountPoint == path or (not topOnly and (path == "/" or e.mountPoint.startsWith(path & "/"))):
        seen.add e.mountPoint
        picked.add e
    picked.reverse
    for e in picked:
      let fl = (e.flags or setFlags) and not clearFlags
      if mountC(nil, e.mountPoint.cstring, nil, MS_REMOUNT or MS_BIND or fl, nil) != 0:
        # a mount hidden by an earlier step (a tmpfs over /dev for PrivateDevices=
        # hides /dev/hugepages, /dev/mqueue ...) is gone from the namespace: nothing to remount
        if errno == ENOENT or tolerant: continue
        nsFail("cannot remount " & e.mountPoint & ": " & errnoMsg())

  proc ensureMount(path: string) =
    if not isMountPoint(path): doMount(path, path, "", MS_BIND or MS_REC)

  # ---- capabilities of this process ---------------------------------------------
  proc hasSysAdmin(): bool =
    try:
      for line in readFile("/proc/self/status").splitLines:
        if line.startsWith("CapEff:"):
          return (parseHexInt(line.split(':')[1].strip) and (1 shl 21)) != 0
    except CatchableError: discard

  proc ensureNsPrivilege(step: string; status: int) =
    ## Root with CAP_SYS_ADMIN unshares directly; anyone else enters a user
    ## namespace that maps their own uid and gid to themselves (§10.4 item 1).
    if gUserNs or hasSysAdmin(): return
    let uid = getuid()
    let gid = getgid()
    # /proc/self is root-owned for a process that changed uid (not dumpable) and would refuse the id maps
    let dumpable = prctlC(3, 0, 0, 0, 0)                    # PR_GET_DUMPABLE
    discard prctlC(4, 1, 0, 0, 0)                           # PR_SET_DUMPABLE
    defer: discard prctlC(4, culong(max(dumpable, 0)), 0, 0, 0)
    if syscallC(SysUnshare, CloneNewUser) != 0:
      fail(step, status, "cannot create a user namespace: " & errnoMsg())
    try:
      writeFile("/proc/self/setgroups", "deny")
      writeFile("/proc/self/uid_map", $uid & " " & $uid & " 1\n")
      writeFile("/proc/self/gid_map", $gid & " " & $gid & " 1\n")
    except IOError as e:
      fail(step, status, "cannot map ids into the user namespace: " & e.msg)
    gUserNs = true

  # ---- network ---------------------------------------------------------------
  proc bringLoopbackUp() =
    let s = socket(AF_INET, SOCK_DGRAM, 0)
    if s == SocketHandle(-1): fail("NETWORK", 225, "socket: " & errnoMsg())
    var req: array[40, byte]
    req[0] = byte('l'); req[1] = byte('o')
    if ioctl(cint(s), 0x8913.culong, addr req) != 0:        # SIOCGIFFLAGS
      fail("NETWORK", 225, "cannot read the flags of lo: " & errnoMsg())
    req[16] = req[16] or 1                             # IFF_UP
    if ioctl(cint(s), 0x8914.culong, addr req) != 0:        # SIOCSIFFLAGS
      fail("NETWORK", 225, "cannot bring lo up: " & errnoMsg())
    discard close(cint(s))

  proc joinNamespace(path: string; kind: cint; step: string; status: int) =
    let fd = open(path.cstring, O_RDONLY or O_CLOEXEC)
    if fd < 0: fail(step, status, "cannot open " & path & ": " & errnoMsg())
    if syscallC(SysSetns, fd, kind) != 0:
      fail(step, status, "setns " & path & ": " & errnoMsg())
    discard close(fd)

  proc applyNetwork*(ctx: ExecSpec) =
    let sb = ctx.sandbox
    if sb.networkNamespacePath.len > 0:
      joinNamespace(sb.networkNamespacePath, CloneNewNet, "NETWORK", 225)
    elif sb.privateNetwork:
      ensureNsPrivilege("NETWORK", 225)
      if syscallC(SysUnshare, CloneNewNet) != 0:
        fail("NETWORK", 225, "cannot create a network namespace: " & errnoMsg())
      bringLoopbackUp()

  # ---- mount operations --------------------------------------------------------
  type
    OpKind = enum okBind, okTmpfs, okProc, okDev, okRw, okRo, okNoExec, okExec, okInaccessible
    MountOp = object
      kind: OpKind
      path: string                 ## target below the (new) root
      ignoreMissing: bool
      src: string                  ## okBind: path in the host view (`/proc/self/fd/N...`)
      srcIsDir: bool
      recursive: bool
      readOnly: bool
      flags: culong                ## okTmpfs
      data: string                 ## okTmpfs, okProc
      order: int

  func rank(k: OpKind): int =
    case k
    of okBind, okTmpfs, okProc, okDev: 0
    of okRw: 1
    of okRo: 2
    of okNoExec, okExec: 3
    of okInaccessible: 4

  var gFds: seq[cint]

  proc openSource(host: string; ignoreMissing: bool): string =
    ## "" when the path is missing and may be.
    let fd = open(host.cstring, OPath or O_CLOEXEC)
    if fd < 0:
      if ignoreMissing and errno == ENOENT: return ""
      nsFail("cannot open " & host & ": " & errnoMsg())
    gFds.add fd
    "/proc/self/fd/" & $fd

  proc stripPrefix(p: string; ignore: var bool): string =
    var s = p
    ignore = false
    while s.len > 0 and s[0] in {'-', '+'}:
      if s[0] == '-': ignore = true
      s = s[1 .. ^1]
    s

  proc parseTmpfsOptions(opts: string): (culong, string) =
    var flags = MS_NOSUID or MS_NODEV
    var data: seq[string]
    var haveMode = false
    for o in opts.split(','):
      case o
      of "": discard
      of "ro": flags = flags or MS_RDONLY
      of "rw": flags = flags and not MS_RDONLY
      of "noexec": flags = flags or MS_NOEXEC
      of "exec": flags = flags and not MS_NOEXEC
      of "nosuid": flags = flags or MS_NOSUID
      of "suid": flags = flags and not MS_NOSUID
      of "nodev": flags = flags or MS_NODEV
      of "dev": flags = flags and not MS_NODEV
      of "noatime": flags = flags or MS_NOATIME
      else:
        if o.startsWith("mode="): haveMode = true
        data.add o
    if not haveMode: data.add "mode=0755"
    (flags, data.join(","))

  proc inaccessibleDir(sb: SandboxSpec): string =
    (if sb.sysrun.len > 0: sb.sysrun else: "/run/systemd") / "inaccessible"

  proc buildOps(ctx: ExecSpec; privTmp: seq[string]; devFd: string): seq[MountOp] =
    let sb = ctx.sandbox
    var ops: seq[MountOp]
    template push(o: MountOp) =
      var x = o
      x.order = ops.len
      ops.add x
    proc paths(list: seq[string]; kind: OpKind) =
      for raw in list:
        var ign: bool
        let p = stripPrefix(raw, ign)
        if p.len == 0 or p[0] != '/': nsFail(raw & " is not an absolute path")
        push MountOp(kind: kind, path: cleanPath(p), ignoreMissing: ign)
    proc quiet(list: openArray[string]; kind: OpKind) =
      for p in list: push MountOp(kind: kind, path: p, ignoreMissing: true)
    # TemporaryFileSystem=
    for raw in sb.temporaryFileSystem:
      let colon = raw.find(':')
      let path = if colon < 0: raw else: raw[0 ..< colon]
      let (fl, data) = parseTmpfsOptions(if colon < 0: "" else: raw[colon + 1 .. ^1])
      if path.len == 0 or path[0] != '/': nsFail("TemporaryFileSystem= " & raw & " is not absolute")
      push MountOp(kind: okTmpfs, path: cleanPath(path), flags: fl, data: data)
    # PrivateTmp=
    if sb.privateTmp:
      for (i, target) in [(0, "/tmp"), (1, "/var/tmp")]:
        push MountOp(kind: okBind, path: target, src: privTmp[i], srcIsDir: true, recursive: true)
    # PrivateDevices=
    if sb.privateDevices: push MountOp(kind: okDev, path: "/dev", src: devFd)
    # ProtectSystem=
    case sb.protectSystem
    of "yes": quiet(["/usr", "/boot", "/efi"], okRo)
    of "full": quiet(["/usr", "/boot", "/efi", "/etc"], okRo)
    of "strict":
      push MountOp(kind: okRo, path: "/")
      quiet(["/dev", "/proc", "/sys"], okRw)
    else: discard
    if sb.protectSystem in ["full", "strict"]:
      let kinds = [(ctx.runtimeRoot, ctx.runtimeDirectory), (ctx.stateRoot, ctx.stateDirectory),
                   (ctx.cacheRoot, ctx.cacheDirectory), (ctx.logsRoot, ctx.logsDirectory)]
      for (root, spec) in kinds:
        for n in spec.names:
          push MountOp(kind: okRw, path: cleanPath(root / n), ignoreMissing: true)

    # DynamicUser=: state, cache and logs live in the root-only `private/`; inside the namespace it shows
    # just this unit's directories, traversable by the dynamic user (§10.5)
    if ctx.dynamicUser:
      for (root, spec) in [(ctx.stateRoot, ctx.stateDirectory), (ctx.cacheRoot, ctx.cacheDirectory),
                           (ctx.logsRoot, ctx.logsDirectory)]:
        if spec.names.len == 0: continue
        let priv = cleanPath(root / "private")
        push MountOp(kind: okTmpfs, path: priv, flags: MS_NOSUID or MS_NODEV, data: "mode=0755")
        for n in spec.names:
          let src = openSource(cleanPath(priv / n), true)
          if src.len > 0:
            push MountOp(kind: okBind, path: cleanPath(priv / n), src: src, srcIsDir: true, recursive: true)
    # ProtectHome=
    case sb.protectHome
    of "yes": quiet(["/home", "/root", "/run/user"], okInaccessible)
    of "read-only": quiet(["/home", "/root", "/run/user"], okRo)
    of "tmpfs":
      for p in ["/home", "/root", "/run/user"]:
        push MountOp(kind: okTmpfs, path: p, ignoreMissing: true,
                    flags: MS_RDONLY or MS_NOSUID or MS_NODEV or MS_NOEXEC, data: "mode=0755")
    else: discard
    # kernel and control group protections
    if sb.protectKernelTunables:
      quiet(["/proc/sys", "/proc/sysrq-trigger", "/proc/latency_stats", "/proc/acpi",
             "/proc/timer_stats", "/proc/fs", "/proc/irq", "/proc/bus", "/sys"], okRo)
      quiet(["/proc/kcore", "/proc/kallsyms", "/proc/sched_debug"], okInaccessible)
    if sb.protectKernelModules: quiet(["/usr/lib/modules", "/lib/modules"], okInaccessible)
    if sb.protectKernelLogs: quiet(["/proc/kmsg", "/dev/kmsg"], okInaccessible)
    if sb.protectControlGroups: quiet(["/sys/fs/cgroup"], okRo)
    if sb.protectClock:
      var rtc = @["/dev/rtc"]
      for p in walkPattern("/dev/rtc*"): rtc.add p
      for p in rtc:
        push MountOp(kind: okInaccessible, path: p, ignoreMissing: true)
    # /proc
    if sb.protectProc.len > 0 or sb.procSubset.len > 0:
      var d: seq[string]
      case sb.protectProc
      of "noaccess": d.add "hidepid=1"
      of "invisible": d.add "hidepid=2"
      of "ptraceable": d.add "hidepid=4"
      else: discard
      if sb.procSubset == "pid": d.add "subset=pid"
      push MountOp(kind: okProc, path: "/proc", flags: MS_NOSUID or MS_NODEV or MS_NOEXEC, data: d.join(","))
    # explicit path lists
    paths(sb.readWritePaths, okRw)
    paths(sb.readOnlyPaths, okRo)
    paths(sb.inaccessiblePaths, okInaccessible)
    paths(sb.noExecPaths, okNoExec)
    paths(sb.execPaths, okExec)
    # BindPaths=
    for (list, ro) in [(sb.bindPaths, false), (sb.bindReadOnlyPaths, true)]:
      for raw in list:
        var ign: bool
        let spec = stripPrefix(raw, ign)
        let parts = spec.split(':')
        let src = parts[0]
        let dst = if parts.len > 1 and parts[1].len > 0: parts[1] else: src
        var rec = true
        var rdonly = ro
        if parts.len > 2:
          for o in parts[2].split(','):
            case o
            of "rbind": rec = true
            of "norbind": rec = false
            of "ro": rdonly = true
            of "": discard
            else: nsFail("BindPaths= " & raw & ": unknown option " & o)
        if src.len == 0 or src[0] != '/' or dst[0] != '/': nsFail("BindPaths= " & raw & " needs absolute paths")
        let fdPath = openSource(cleanPath(src), ign)
        if fdPath.len == 0: continue
        push MountOp(kind: okBind, path: cleanPath(dst), src: fdPath, srcIsDir: isDirectory(cleanPath(src)),
                    recursive: rec, readOnly: rdonly)
    # MountAPIVFS= (only meaningful below a root directory)
    if sb.mountApiVfs and sb.rootDirectory.len > 0:
      if sb.procSubset.len == 0 and sb.protectProc.len == 0:
        push MountOp(kind: okProc, path: "/proc", flags: MS_NOSUID or MS_NODEV or MS_NOEXEC)
      for p in ["/sys", "/dev"]:
        if not ops.anyIt(it.path == p and it.kind in {okDev, okBind}):
          push MountOp(kind: okBind, path: p, src: openSource(p, false), srcIsDir: true, recursive: true)
    # below a root directory the manager's sockets and the unit's directories stay reachable
    if sb.rootDirectory.len > 0:
      for p in sb.extraBinds:
        let fdPath = openSource(p, true)
        if fdPath.len > 0:
          push MountOp(kind: okBind, path: cleanPath(p), src: fdPath, srcIsDir: isDirectory(p), recursive: true)
    ops

  proc applyOp(op: MountOp; inaccReg, inaccDir: string; roTmpfs: var seq[string]) =
    let target = resolvePath(op.path)
    if not pathExists(target):
      if op.ignoreMissing: return
      nsFail(op.path & " does not exist")
    case op.kind
    of okTmpfs:
      # mounted writable so that later operations can create their mount points inside; read-only at the end
      doMount("tmpfs", target, "tmpfs", op.flags and not MS_RDONLY, op.data)
      if (op.flags and MS_RDONLY) != 0: roTmpfs.add target
    of okProc:
      doMount("proc", target, "proc", op.flags, op.data)
    of okBind:
      let flags = MS_BIND or (if op.recursive and op.srcIsDir: MS_REC else: 0.culong)
      doMount(gOld & op.src, target, "", flags)
      if op.readOnly: remountTree(target, MS_RDONLY, 0)
      else: remountTree(target, 0, MS_RDONLY, topOnly = true, tolerant = true)
    of okRw:
      ensureMount(target)
      remountTree(target, 0, MS_RDONLY)
    of okRo:
      ensureMount(target)
      remountTree(target, MS_RDONLY, 0)
    of okNoExec:
      ensureMount(target)
      remountTree(target, MS_NOEXEC, 0)
    of okExec:
      ensureMount(target)
      remountTree(target, 0, MS_NOEXEC)
    of okInaccessible:
      let node = if isDirectory(target): inaccDir else: inaccReg
      doMount(gOld & node, target, "", MS_BIND)
      remountTree(target, MS_RDONLY or MS_NOSUID or MS_NODEV or MS_NOEXEC, 0)
    of okDev:
      doMount("tmpfs", target, "tmpfs", MS_NOSUID or MS_NOEXEC, "mode=0755,size=4m,nr_inodes=1m")
      let hostDev = gOld & op.src
      for n in ["null", "zero", "full", "random", "urandom", "tty"]:
        if not pathExists(hostDev / n): continue
        let node = target / n
        let fd = open(node.cstring, O_WRONLY or O_CREAT or O_CLOEXEC, 0o600)
        if fd < 0: nsFail("cannot create " & node & ": " & errnoMsg())
        discard close(fd)
        doMount(hostDev / n, node, "", MS_BIND)
      for n in ["pts", "shm", "mqueue"]:
        if not pathExists(hostDev / n): continue
        let dir = target / n
        mkdirP(dir)
        doMount(hostDev / n, dir, "", MS_BIND or MS_REC)
      for (name, to) in [("ptmx", "pts/ptmx"), ("fd", "/proc/self/fd"), ("stdin", "/proc/self/fd/0"),
                         ("stdout", "/proc/self/fd/1"), ("stderr", "/proc/self/fd/2"), ("core", "/proc/kcore")]:
        if symlink(to.cstring, (target / name).cstring) != 0 and errno != EEXIST:
          nsFail("cannot create /dev/" & name & ": " & errnoMsg())

  proc createDestination(op: MountOp) =
    ## Bind and tmpfs targets that do not exist yet are created before any
    ## mount, while the filesystem is still writable.
    let target = resolvePath(op.path)
    if pathExists(target):
      return
    case op.kind
    of okBind:
      if op.srcIsDir: mkdirP(target)
      else:
        mkdirP(parentOf(target))
        let fd = open(target.cstring, O_WRONLY or O_CREAT or O_CLOEXEC, 0o644)
        if fd < 0: nsFail("cannot create " & target & ": " & errnoMsg())
        discard close(fd)
    of okTmpfs, okProc, okDev:
      if not op.ignoreMissing: mkdirP(target)
    else: discard

  proc prepareInaccessible(sb: SandboxSpec): (string, string) =
    ## Persistent mode-0 nodes (as systemd's `/run/systemd/inaccessible`) bound
    ## over what must not be reachable.
    let dir = inaccessibleDir(sb)
    mkdirP(dir)
    let reg = dir / "reg"
    let d = dir / "dir"
    if not pathExists(reg):
      let fd = open(reg.cstring, O_WRONLY or O_CREAT or O_CLOEXEC, 0)
      if fd < 0: nsFail("cannot create " & reg & ": " & errnoMsg())
      discard close(fd)
    discard chmod(reg.cstring, 0)
    if not pathExists(d) and mkdir(d.cstring, 0) != 0 and errno != EEXIST:
      nsFail("cannot create " & d & ": " & errnoMsg())
    discard chmod(d.cstring, 0)
    (openSource(reg, false), openSource(d, false))

  proc pivotInto(root: string) =
    let r = cleanPath(root)
    if not isDirectory(r): nsFail("RootDirectory= " & root & " is not a directory")
    doMount(r, r, "", MS_BIND or MS_REC)
    let old = r / OldRoot
    if mkdir(old.cstring, 0o700) != 0 and errno != EEXIST:
      nsFail("cannot create " & old & ": " & errnoMsg())
    if chdir(r.cstring) != 0: nsFail("chdir " & r & ": " & errnoMsg())
    if syscallC(SysPivotRoot, r.cstring, old.cstring) != 0:
      nsFail("pivot_root " & r & ": " & errnoMsg())
    if chdir("/") != 0: nsFail("chdir /: " & errnoMsg())
    gOld = OldRoot

  proc setupMounts(ctx: ExecSpec) =
    let sb = ctx.sandbox
    if mountC(nil, "/", nil, MS_REC or MS_SLAVE, nil) != 0:
      nsFail("cannot make the mount tree a slave: " & errnoMsg())
    # host side, before anything hides it
    var privTmp: seq[string]
    if sb.privateTmp:
      privTmp = privateTmpPaths(ctx.invocationId, ctx.unit)
      for d in privTmp:
        mkdirP(d, 0o700)
        discard chmod(d.cstring, 0o700)
        mkdirP(d / "tmp", 0o1777)
        discard chmod((d / "tmp").cstring, 0o1777)
      privTmp = @[openSource(privTmp[0] / "tmp", false), openSource(privTmp[1] / "tmp", false)]
    var devFd = ""
    if sb.privateDevices: devFd = openSource("/dev", false)
    var inaccReg, inaccDir: string
    let needInaccessible = sb.protectHome == "yes" or sb.protectKernelModules or sb.protectKernelLogs or
      sb.protectClock or sb.inaccessiblePaths.len > 0 or sb.protectKernelTunables
    if needInaccessible: (inaccReg, inaccDir) = prepareInaccessible(sb)
    var ops = buildOps(ctx, privTmp, devFd)
    if sb.rootDirectory.len > 0: pivotInto(sb.rootDirectory)
    for op in ops: createDestination(op)
    ops.sort(proc(a, b: MountOp): int =
      result = cmp(a.path, b.path)
      if result == 0: result = cmp(rank(a.kind), rank(b.kind))
      if result == 0: result = cmp(a.order, b.order))
    var roTmpfs: seq[string]
    for op in ops:
      createDestination(op)
      applyOp(op, inaccReg, inaccDir, roTmpfs)
    for t in roTmpfs: remountTree(t, MS_RDONLY, 0, topOnly = true)
    if sb.rootDirectory.len > 0:
      if umount2C(OldRoot, MNT_DETACH) != 0: nsFail("cannot detach the old root: " & errnoMsg())
      discard rmdir(OldRoot)
      gOld = ""
    for fd in gFds: discard close(fd)
    gFds.setLen 0
    # final propagation (§10.4 item 2): private for PrivateMounts=, else as MountFlags=
    if sb.privateMounts or sb.mountFlags == "private":
      if mountC(nil, "/", nil, MS_REC or MS_PRIVATE, nil) != 0:
        nsFail("cannot make the mount tree private: " & errnoMsg())
    elif sb.mountFlags == "slave": discard
    else: discard mountC(nil, "/", nil, MS_REC or MS_SHARED, nil)

  proc applyNamespaces*(ctx: ExecSpec) =
    let sb = ctx.sandbox
    var flags = 0.cint
    let mountNs = needsMountNamespace(sb)
    if mountNs: flags = flags or CloneNewNs
    if sb.ipcNamespacePath.len > 0:
      joinNamespace(sb.ipcNamespacePath, CloneNewIpc, "NAMESPACE", 226)
    elif sb.privateIpc: flags = flags or CloneNewIpc
    if sb.protectHostname: flags = flags or CloneNewUts
    if flags == 0: return
    ensureNsPrivilege("NAMESPACE", 226)
    if syscallC(SysUnshare, flags) != 0:
      nsFail("unshare: " & errnoMsg())
    if mountNs: setupMounts(ctx)
