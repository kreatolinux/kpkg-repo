## Credentials: `LoadCredential=`, `SetCredential=` and `ImportCredential=` are
## written as files below `<root>/<unit>`, mode 0400, owned by the service user;
## `$CREDENTIALS_DIRECTORY` points there. An existing credential is replaced
## atomically, never deleted, so a control process does not pull files from under
## the main process.
import std/[algorithm, os, posix, strutils]
import ./[context, failure]

const
  CredStores = ["/run/credstore", "/etc/credstore", "/usr/lib/credstore", "/run/credentials/@system"]
  MaxCredential = 1024 * 1024

proc credFail(msg: string) {.noreturn.} = fail("CREDENTIALS", 243, msg)

proc validId(id: string): bool =
  id.len in 1 .. 255 and '/' notin id and id notin [".", ".."] and '\0' notin id

proc unescapeData(s: string): string =
  ## C-style escapes of `SetCredential=` data.
  var i = 0
  while i < s.len:
    if s[i] == '\\' and i + 1 < s.len:
      inc i
      case s[i]
      of 'n': result.add '\n'
      of 't': result.add '\t'
      of 'r': result.add '\r'
      of '\\': result.add '\\'
      of 'x':
        if i + 2 < s.len + 0 and s[i + 1] in HexDigits and s[i + 2] in HexDigits:
          result.add char(parseHexInt(s[i + 1 .. i + 2]))
          i += 2
        else: result.add "\\x"
      else:
        result.add '\\'
        result.add s[i]
    else: result.add s[i]
    inc i

proc globMatch(pat, s: string): bool =
  proc rec(p, q: int): bool =
    if p == pat.len: return q == s.len
    if pat[p] == '*':
      for k in q .. s.len:
        if rec(p + 1, k): return true
      return false
    if q < s.len and (pat[p] == '?' or pat[p] == s[q]): return rec(p + 1, q + 1)
    false
  rec(0, 0)

proc readCredential(path: string): string =
  var st: Stat
  if stat(path.cstring, st) != 0: credFail("cannot open " & path & ": " & errnoMsg())
  if not S_ISREG(st.st_mode): credFail(path & " is not a regular file")
  if st.st_size > MaxCredential: credFail(path & " is larger than 1M")
  try: readFile(path)
  except IOError as e: credFail("cannot read " & path & ": " & e.msg)

proc writeCredential(dir, id, data: string; uid: Uid; gid: Gid; chownIt: bool) =
  let tmp = dir / ("." & id & ".tmp")
  let fd = open(tmp.cstring, O_WRONLY or O_CREAT or O_TRUNC or O_CLOEXEC, 0o600)
  if fd < 0: credFail("cannot create " & tmp & ": " & errnoMsg())
  var off = 0
  while off < data.len:
    let n = write(fd, unsafeAddr data[off], data.len - off)
    if n < 0:
      if errno == EINTR: continue
      discard close(fd)
      credFail("cannot write " & tmp & ": " & errnoMsg())
    off += n
  if fchmod(fd, 0o400) != 0 or (chownIt and fchown(fd, uid, gid) != 0):
    discard close(fd)
    credFail("cannot set up " & tmp & ": " & errnoMsg())
  discard close(fd)
  try: moveFile(tmp, dir / id)
  except OSError as e: credFail("cannot install credential " & id & ": " & e.msg)

proc setupCredentials*(ctx: ExecSpec; uid: Uid; gid: Gid; chownIt: bool): string =
  ## Returns the credentials directory ("" when the unit has no credentials).
  let c = ctx.credentials
  if c.loadCredential.len == 0 and c.setCredential.len == 0 and c.importCredential.len == 0: return ""
  if c.root.len == 0: credFail("no credentials directory is configured")
  var ids: seq[string]
  var values: seq[string]
  proc put(id, data: string) =
    if not validId(id): credFail("invalid credential name '" & id & "'")
    if id notin ids:                 # the first definition wins: Load, Set, Import
      ids.add id
      values.add data
  for raw in c.loadCredential:
    let colon = raw.find(':')
    let id = if colon < 0: raw else: raw[0 ..< colon]
    var path = if colon < 0: "" else: raw[colon + 1 .. ^1]
    if not validId(id): credFail("invalid credential name '" & id & "'")
    if path.len == 0:
      for d in CredStores:
        if fileExists(d / id): (path = d / id; break)
      if path.len == 0: credFail("credential " & id & " not found in the credential stores")
    elif not path.startsWith("/"):
      var found = ""
      for d in CredStores:
        if fileExists(d / path): (found = d / path; break)
      if found.len == 0: credFail("credential file " & path & " not found in the credential stores")
      path = found
    if dirExists(path):
      var names: seq[string]
      for kind, p in walkDir(path):
        if kind in {pcFile, pcLinkToFile}: names.add p.extractFilename
      names.sort
      for n in names: put(id & "_" & n, readCredential(path / n))
    else: put(id, readCredential(path))
  for raw in c.setCredential:
    let colon = raw.find(':')
    if colon <= 0: credFail("SetCredential= needs ID:DATA, got '" & raw & "'")
    put(raw[0 ..< colon], unescapeData(raw[colon + 1 .. ^1]))
  for pat in c.importCredential:
    for d in CredStores:
      if not dirExists(d): continue
      var names: seq[string]
      for kind, p in walkDir(d):
        if kind in {pcFile, pcLinkToFile} and globMatch(pat, p.extractFilename): names.add p.extractFilename
      names.sort
      for n in names: put(n, readCredential(d / n))
  let dir = c.root / ctx.unit
  try: createDir(c.root)
  except OSError as e: credFail("cannot create " & c.root & ": " & e.msg)
  discard chmod(c.root.cstring, 0o755)
  if mkdir(dir.cstring, 0o700) != 0 and errno != EEXIST: credFail("cannot create " & dir & ": " & errnoMsg())
  discard chmod(dir.cstring, 0o700)
  if chownIt and chown(dir.cstring, uid, gid) != 0: credFail("cannot chown " & dir & ": " & errnoMsg())
  for i in 0 ..< ids.len: writeCredential(dir, ids[i], values[i], uid, gid, chownIt)
  dir

proc removeCredentials*(root, unit: string) =
  ## For the manager, once the unit's cgroup is empty after a stop.
  try: removeDir(root / unit)
  except OSError: discard
