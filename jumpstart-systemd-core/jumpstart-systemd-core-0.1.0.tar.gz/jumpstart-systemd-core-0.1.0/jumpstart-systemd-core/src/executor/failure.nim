## The error a failing executor step raises; shared by every step module.
import std/posix

type StepFailure* = object of CatchableError
  step*: string
  status*: int

proc fail*(step: string; status: int; msg: string) {.noreturn.} =
  var e = newException(StepFailure, msg)
  e.step = step
  e.status = status
  raise e

proc errnoMsg*(): string = $strerror(errno)
