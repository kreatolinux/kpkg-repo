## The exec context (spec §10.1.1): everything the executor needs to set up
## one process, as plain data. Written by service/execcontext.nim from the
## unit's ExecContext, read by executor/main.nim. Shared so both ends agree.
## It travels over an inherited descriptor (a sealed memfd on Linux) and never
## touches a file, because it carries `Environment=` values.
import std/[json, jsonutils, options]

const ContextVersion* = 1

type
  StdioSpec* = object
    kind*: string        ## null, inherit, tty, file, append, truncate, journal, kmsg, socket
    path*: string        ## file kinds and tty
    inherited*: bool     ## the manager already installed the descriptor
  DirSpec* = object
    names*: seq[string]  ## relative names, as written
    mode*: int           ## octal value, default 0o755
  LimitSpec* = object
    resource*: string    ## "NOFILE", "CORE", ...
    soft*, hard*: int64  ## -1 is infinity
  FdSpec* = object
    name*: string        ## LISTEN_FDNAMES entry; descriptor i is already at 3 + i (passed by the manager)
  SandboxSpec* = object
    ## Namespace and filesystem confinement; applied by executor/sandbox.nim.
    rootDirectory*: string
    mountApiVfs*: bool
    bindPaths*, bindReadOnlyPaths*, temporaryFileSystem*, readWritePaths*, readOnlyPaths*,
      inaccessiblePaths*, execPaths*, noExecPaths*: seq[string]
    protectSystem*: string            ## "", yes, full, strict
    protectHome*: string              ## "", yes, read-only, tmpfs
    protectProc*, procSubset*: string ## "", noaccess/invisible/ptraceable; "", pid
    mountFlags*: string               ## "", shared, slave, private
    privateTmp*, privateDevices*, privateMounts*, privateIpc*, privateNetwork*: bool
    protectKernelTunables*, protectKernelModules*, protectKernelLogs*, protectControlGroups*,
      protectClock*, protectHostname*: bool
    networkNamespacePath*, ipcNamespacePath*: string
    sysrun*: string                   ## SYSRUN: `journal` and `notify` stay reachable below a root directory
    extraBinds*: seq[string]          ## host paths bound at the same path below a root directory
  SeccompSpec* = object
    systemCallFilter*: seq[string]    ## words as written (`~` marks a deny entry, `:ERRNO` suffix)
    systemCallErrorNumber*: string
    systemCallArchitectures*: seq[string]
    restrictAddressFamilies*, restrictNamespaces*: seq[string]
    memoryDenyWriteExecute*, lockPersonality*, restrictRealtime*, restrictSuidSgid*: bool
  CredentialSpec* = object
    root*: string                     ## directory that holds one subdirectory per unit
    loadCredential*, setCredential*, importCredential*: seq[string]
  ExecSpec* = object
    version*: int
    unit*, invocationId*, scope*, kind*: string
    path*, argv0*: string
    args*: seq[string]                ## raw words, `$VAR` references unexpanded
    noEnvSubst*, privileged*, skipIdentity*: bool
    environment*: seq[(string, string)]
    protectedEnv*: seq[string]        ## names Environment*/Pass* may not override
    environmentFiles*, passEnvironment*, unsetEnvironment*: seq[string]
    managerEnvironment*: seq[(string, string)]   ## source for PassEnvironment=
    user*, group*: string
    supplementaryGroups*: seq[string]
    workingDirectory*: string
    umask*: int                       ## -1: default 022
    nice*, oomScoreAdjust*: Option[int]
    ioSchedulingClass*, ioSchedulingPriority*: Option[int]
    cpuSchedulingPolicy*, cpuSchedulingPriority*: Option[int]
    cpuSchedulingResetOnFork*, noNewPrivileges*: bool
    timerSlackNsec*: Option[int64]
    limits*: seq[LimitSpec]
    ignoreSigpipe*: bool
    runtimeDirectory*, stateDirectory*, cacheDirectory*, logsDirectory*,
      configurationDirectory*: DirSpec
    runtimeRoot*, stateRoot*, cacheRoot*, logsRoot*, configRoot*: string
    runtimeDirectoryPreserve*: bool
    stdin*, stdout*, stderr*: StdioSpec
    stdinText*: string
    ttyReset*, ttyVhangup*: bool
    fds*: seq[FdSpec]
    listenFds*: bool                  ## set LISTEN_PID/LISTEN_FDS/LISTEN_FDNAMES
    unsupported*: seq[string]         ## sandbox directives set but not applied: exit 226
    expectedCgroup*: string           ## expected `/proc/self/cgroup` path suffix (§10.1.2 step 2)
    statusFd*: int
    sandbox*: SandboxSpec
    seccomp*: SeccompSpec
    capabilityBoundingSet*, ambientCapabilities*, secureBits*: seq[string]
    dynamicUser*: bool
    dynamicUsersDir*: string          ## records of allocated dynamic uids (`ST/dynamic-users`)
    credentials*: CredentialSpec

proc toContextJson*(s: ExecSpec): string = $toJson(s)

proc parseContext*(text: string): ExecSpec =
  ## Raises ValueError/JsonParsingError for a malformed or wrong-version context.
  result = jsonTo(parseJson(text), ExecSpec, Joptions(allowMissingKeys: true, allowExtraKeys: true))
  if result.version != ContextVersion:
    raise newException(ValueError, "unsupported exec context version " & $result.version)
