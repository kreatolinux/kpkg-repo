## Capability bounding and ambient sets, `SecureBits=`.
import std/strutils
import ./[context, failure]

const CapNames* = ["chown", "dac_override", "dac_read_search", "fowner", "fsetid", "kill", "setgid",
  "setuid", "setpcap", "linux_immutable", "net_bind_service", "net_broadcast", "net_admin", "net_raw",
  "ipc_lock", "ipc_owner", "sys_module", "sys_rawio", "sys_chroot", "sys_ptrace", "sys_pacct",
  "sys_admin", "sys_boot", "sys_nice", "sys_resource", "sys_time", "sys_tty_config", "mknod", "lease",
  "audit_write", "audit_control", "setfcap", "mac_override", "mac_admin", "syslog", "wake_alarm",
  "block_suspend", "audit_read", "perfmon", "bpf", "checkpoint_restore"]

const
  CapMknod = 27
  CapSysRawio = 17
  CapSysModule = 16
  CapSyslog = 34
  CapSysTime = 25
  CapWakeAlarm = 35

proc capNumber*(word: string): int =
  ## -1 for an unknown name; accepts `CAP_NET_ADMIN`, `cap_net_admin`.
  var w = word.toLowerAscii
  if w.startsWith("cap_"): w = w[4 .. ^1]
  for i, n in CapNames:
    if n == w: return i
  -1

proc setOf*(words: seq[string]; bad: var string): uint64 =
  ## The set a CapabilityBoundingSet=/AmbientCapabilities= value names. Allow
  ## words give the base (all capabilities when there is none); words with `~` and
  ## the words after them (see seccomp.splitSets) are subtracted.
  var allow, deny: uint64
  var haveAllow, inverted = false
  for w in words:
    var x = w
    if x.startsWith("~"):
      inverted = true
      x = x[1 .. ^1]
    if x.len == 0: continue
    let n = capNumber(x)
    if n < 0:
      bad = w
      return 0
    if inverted: deny = deny or (1'u64 shl n)
    else:
      allow = allow or (1'u64 shl n)
      haveAllow = true
  let all = (1'u64 shl CapNames.len) - 1
  (if haveAllow: allow else: all) and not deny

type CapPlan* = object
  active*: bool
  bounding*: uint64            ## capabilities that stay in the bounding set
  ambient*: uint64
  lastCap*: int

proc lastCapability(): int =
  try: parseInt(readFile("/proc/sys/kernel/cap_last_cap").strip)
  except CatchableError: CapNames.len - 1

proc planCapabilities*(ctx: ExecSpec): CapPlan =
  var bad = ""
  let all = (1'u64 shl CapNames.len) - 1
  result.bounding = all
  if ctx.capabilityBoundingSet.len > 0:
    result.bounding = setOf(ctx.capabilityBoundingSet, bad)
    if bad.len > 0: fail("CAPABILITIES", 218, "unknown capability " & bad)
  let sb = ctx.sandbox
  if sb.privateDevices:
    result.bounding = result.bounding and not ((1'u64 shl CapMknod) or (1'u64 shl CapSysRawio))
  if sb.protectKernelModules: result.bounding = result.bounding and not (1'u64 shl CapSysModule)
  if sb.protectKernelLogs: result.bounding = result.bounding and not (1'u64 shl CapSyslog)
  if sb.protectClock:
    result.bounding = result.bounding and not ((1'u64 shl CapSysTime) or (1'u64 shl CapWakeAlarm))
  if ctx.ambientCapabilities.len > 0:
    result.ambient = setOf(ctx.ambientCapabilities, bad)
    if bad.len > 0: fail("CAPABILITIES", 218, "unknown capability " & bad)
    if (result.ambient and not result.bounding) != 0:
      fail("CAPABILITIES", 218, "AmbientCapabilities= is not a subset of CapabilityBoundingSet=")
  result.active = result.bounding != all or result.ambient != 0 or ctx.secureBits.len > 0
  result.lastCap = lastCapability()

proc prctlC(option: cint; a2, a3, a4, a5: culong): cint {.importc: "prctl", header: "<sys/prctl.h>".}
proc syscallC(n: clong): clong {.importc: "syscall", header: "<unistd.h>", varargs.}
when defined(linux):
  var SysCapget {.importc: "SYS_capget", header: "<sys/syscall.h>".}: clong
  var SysCapset {.importc: "SYS_capset", header: "<sys/syscall.h>".}: clong

type
  CapHeader = object
    version: uint32
    pid: int32
  CapData = object
    effective, permitted, inheritable: uint32

const SecureBitNames = [("noroot", 1), ("noroot-locked", 2), ("no-setuid-fixup", 4),
  ("no-setuid-fixup-locked", 8), ("keep-caps", 16), ("keep-caps-locked", 32)]

proc dropBounding*(plan: CapPlan; hasKeepCaps: bool) =
  ## Before the identity change (the bounding set needs CAP_SETPCAP). Ambient
  ## capabilities of a changing identity need PR_SET_KEEPCAPS across `setuid`.
  if not plan.active: return
  when defined(linux):
    for c in 0 .. plan.lastCap:
      if c < CapNames.len and (plan.bounding and (1'u64 shl c)) == 0:
        if prctlC(24, culong(c), 0, 0, 0) != 0:      # PR_CAPBSET_DROP
          fail("CAPABILITIES", 218, "cannot drop CAP_" & CapNames[c].toUpperAscii & ": " & errnoMsg())
    if plan.ambient != 0 and hasKeepCaps and prctlC(8, 1, 0, 0, 0) != 0:   # PR_SET_KEEPCAPS
      fail("CAPABILITIES", 218, "PR_SET_KEEPCAPS: " & errnoMsg())
  else:
    fail("CAPABILITIES", 218, "capabilities are not available on this platform")

proc applySecureBits(words: seq[string]) =
  var bits = 0
  for w in words:
    var found = false
    for (n, v) in SecureBitNames:
      if n == w: (bits = bits or v; found = true)
    if not found: fail("CAPABILITIES", 218, "unknown secure bit " & w)
  when defined(linux):
    if prctlC(28, culong(bits), 0, 0, 0) != 0:       # PR_SET_SECUREBITS
      fail("CAPABILITIES", 218, "PR_SET_SECUREBITS: " & errnoMsg())

proc finishCapabilities*(plan: CapPlan; ctx: ExecSpec) =
  ## After the identity change: clamp effective/permitted/inheritable to the
  ## bounding set, raise the ambient set, undo KEEPCAPS.
  if not plan.active: return
  when defined(linux):
    var hdr = CapHeader(version: 0x20080522'u32, pid: 0)
    var data: array[2, CapData]
    if syscallC(SysCapget, addr hdr, addr data[0]) != 0:
      fail("CAPABILITIES", 218, "capget: " & errnoMsg())
    let lo = uint32(plan.bounding and 0xffffffff'u64)
    let hi = uint32(plan.bounding shr 32)
    let aLo = uint32(plan.ambient and 0xffffffff'u64)
    let aHi = uint32(plan.ambient shr 32)
    data[0].permitted = data[0].permitted and lo
    data[1].permitted = data[1].permitted and hi
    data[0].inheritable = (data[0].inheritable and lo) or aLo
    data[1].inheritable = (data[1].inheritable and hi) or aHi
    data[0].permitted = data[0].permitted or aLo
    data[1].permitted = data[1].permitted or aHi
    data[0].effective = data[0].permitted
    data[1].effective = data[1].permitted
    hdr = CapHeader(version: 0x20080522'u32, pid: 0)
    if syscallC(SysCapset, addr hdr, addr data[0]) != 0:
      fail("CAPABILITIES", 218, "capset: " & errnoMsg())
    for c in 0 ..< CapNames.len:
      if (plan.ambient and (1'u64 shl c)) != 0 and
          prctlC(47, 2, culong(c), 0, 0) != 0:        # PR_CAP_AMBIENT, PR_CAP_AMBIENT_RAISE
        fail("CAPABILITIES", 218, "cannot raise ambient CAP_" & CapNames[c].toUpperAscii & ": " & errnoMsg())
    if plan.ambient != 0: discard prctlC(8, 0, 0, 0, 0)
    if ctx.secureBits.len > 0: applySecureBits(ctx.secureBits)
  else:
    fail("CAPABILITIES", 218, "capabilities are not available on this platform")
