## seccomp-bpf filters built from raw instructions (spec §10.7); no libseccomp.
## `buildPrograms` is pure (system call numbers come through a lookup
## parameter) so the rules can be tested with a BPF interpreter on any host;
## `installFilters` is Linux only.
import std/[options, strutils, tables]
import ./[context, failure, syscalls]

type
  Insn* = object
    code*: uint16
    jt*, jf*: uint8
    k*: uint32
  CondKind* = enum ckMaskEq, ckAny
  Cond* = object
    arg*: int
    kind*: CondKind
    mask*, value*: uint32        ## ckMaskEq: (arg & mask) == value; ckAny: (arg & mask) != 0
  Rule* = object
    nr*: uint32
    action*: uint32
    conds*: seq[Cond]            ## all must hold; empty matches every call
  Program* = object
    rules*: seq[Rule]            ## first match wins
    default*: uint32
  NrLookup* = proc(name: string): int {.closure.}

const
  RetKillProcess* = 0x80000000'u32
  RetAllow* = 0x7fff0000'u32
  RetErrnoBase* = 0x00050000'u32
  BpfLdAbsW = 0x20'u16
  BpfAndK = 0x54'u16
  BpfJeqK = 0x15'u16
  BpfJsetK = 0x45'u16
  BpfRetK = 0x06'u16
  MaxInsns = 4096
when defined(arm64):
  const NativeArch* = 0xC00000B7'u32
  const NativeArchName* = "arm64"
elif defined(amd64):
  const NativeArch* = 0xC000003E'u32
  const NativeArchName* = "x86-64"
else:
  const NativeArch* = 0'u32
  const NativeArchName* = ""

func errnoAction*(e: int): uint32 = RetErrnoBase or uint32(e and 0xffff)

func insn(code: uint16; k: uint32; jt: uint8 = 0; jf: uint8 = 0): Insn =
  Insn(code: code, jt: jt, jf: jf, k: k)

proc assemble*(p: Program): seq[Insn] =
  ## Architecture check, then the rules in order, then the default verdict.
  result.add insn(BpfLdAbsW, 4)                    # seccomp_data.arch
  result.add insn(BpfJeqK, NativeArch, 1, 0)
  result.add insn(BpfRetK, RetKillProcess)
  result.add insn(BpfLdAbsW, 0)                    # seccomp_data.nr
  when defined(amd64):
    result.add insn(BpfJsetK, 0x40000000'u32, 0, 1)   # x32 system calls
    result.add insn(BpfRetK, RetKillProcess)
  for r in p.rules:
    if r.conds.len == 0:
      result.add insn(BpfJeqK, r.nr, 0, 1)
      result.add insn(BpfRetK, r.action)
    else:
      var block1: seq[Insn]
      var testAt: seq[int]
      for c in r.conds:
        block1.add insn(BpfLdAbsW, uint32(16 + 8 * c.arg))   # low word, little endian
        case c.kind
        of ckMaskEq:
          block1.add insn(BpfAndK, c.mask)
          testAt.add block1.len
          block1.add insn(BpfJeqK, c.value, 0, 0)
        of ckAny:
          testAt.add block1.len
          block1.add insn(BpfJsetK, c.mask, 1, 0)
      block1.add insn(BpfRetK, r.action)
      block1.add insn(BpfLdAbsW, 0)
      let last = block1.len - 1
      for t in testAt:
        let off = uint8(last - t - 1)
        if block1[t].code == BpfJsetK:
          block1[t].jt = 0
          block1[t].jf = off
        else:
          block1[t].jf = off
      result.add insn(BpfJeqK, r.nr, 0, uint8(block1.len))
      result.add block1
  result.add insn(BpfRetK, p.default)

# ---- a BPF interpreter, for tests --------------------------------------------
proc evaluate*(prog: seq[Insn]; arch, nr: uint32; args: array[6, uint64]): uint32 =
  ## What the kernel would answer for this call (classic BPF subset used above).
  var a = 0'u32
  var pc = 0
  while pc < prog.len:
    let i = prog[pc]
    inc pc
    case i.code
    of BpfLdAbsW:
      if i.k == 0: a = nr
      elif i.k == 4: a = arch
      elif i.k >= 16 and i.k < 64: a = uint32(args[int((i.k - 16) div 8)] and 0xffffffff'u64)
    of BpfAndK: a = a and i.k
    of BpfJeqK: pc += (if a == i.k: int(i.jt) else: int(i.jf))
    of BpfJsetK: pc += (if (a and i.k) != 0: int(i.jt) else: int(i.jf))
    of BpfRetK: return i.k
    else: raise newException(ValueError, "bad opcode")
  RetKillProcess

# ---- translation of unit settings --------------------------------------------
const ErrnoTable = {
  "EPERM": 1, "ENOENT": 2, "ESRCH": 3, "EINTR": 4, "EIO": 5, "ENXIO": 6, "E2BIG": 7, "ENOEXEC": 8,
  "EBADF": 9, "ECHILD": 10, "EAGAIN": 11, "EWOULDBLOCK": 11, "ENOMEM": 12, "EACCES": 13, "EFAULT": 14,
  "EBUSY": 16, "EEXIST": 17, "EXDEV": 18, "ENODEV": 19, "ENOTDIR": 20, "EISDIR": 21, "EINVAL": 22,
  "ENFILE": 23, "EMFILE": 24, "ENOTTY": 25, "EFBIG": 27, "ENOSPC": 28, "ESPIPE": 29, "EROFS": 30,
  "EMLINK": 31, "EPIPE": 32, "EDOM": 33, "ERANGE": 34, "EDEADLK": 35, "ENAMETOOLONG": 36,
  "ENOSYS": 38, "ENOTEMPTY": 39, "ELOOP": 40, "EOVERFLOW": 75, "EOPNOTSUPP": 95, "ENOTSUP": 95,
  "EAFNOSUPPORT": 97, "EPROTONOSUPPORT": 93, "EADDRINUSE": 98, "ECONNREFUSED": 111, "ETIMEDOUT": 110,
  "EACCESS": 13}.toTable

proc parseErrno*(s: string): Option[int] =
  if s.len == 0: return none(int)
  if s.allCharsInSet({'0'..'9'}): return some(parseInt(s))
  if s.toUpperAscii in ErrnoTable: return some(ErrnoTable[s.toUpperAscii])
  none(int)

const AddressFamilies = {
  "AF_UNSPEC": 0, "AF_UNIX": 1, "AF_LOCAL": 1, "AF_INET": 2, "AF_AX25": 3, "AF_IPX": 4, "AF_APPLETALK": 5,
  "AF_NETROM": 6, "AF_BRIDGE": 7, "AF_ATMPVC": 8, "AF_X25": 9, "AF_INET6": 10, "AF_ROSE": 11,
  "AF_DECNET": 12, "AF_NETBEUI": 13, "AF_SECURITY": 14, "AF_KEY": 15, "AF_NETLINK": 16, "AF_ROUTE": 16,
  "AF_PACKET": 17, "AF_ASH": 18, "AF_ECONET": 19, "AF_ATMSVC": 20, "AF_RDS": 21, "AF_SNA": 22,
  "AF_IRDA": 23, "AF_PPPOX": 24, "AF_WANPIPE": 25, "AF_LLC": 26, "AF_IB": 27, "AF_MPLS": 28,
  "AF_CAN": 29, "AF_TIPC": 30, "AF_BLUETOOTH": 31, "AF_IUCV": 32, "AF_RXRPC": 33, "AF_ISDN": 34,
  "AF_PHONET": 35, "AF_IEEE802154": 36, "AF_CAIF": 37, "AF_ALG": 38, "AF_NFC": 39, "AF_VSOCK": 40,
  "AF_KCM": 41, "AF_QIPCRTR": 42, "AF_SMC": 43, "AF_XDP": 44, "AF_MCTP": 45}.toTable

const
  NsFlags = {"cgroup": 0x02000000'u32, "ipc": 0x08000000'u32, "net": 0x40000000'u32,
             "mnt": 0x00020000'u32, "pid": 0x20000000'u32, "user": 0x10000000'u32,
             "uts": 0x04000000'u32, "time": 0x00000080'u32}.toTable
  AllNsFlags = 0x02000000'u32 or 0x08000000'u32 or 0x40000000'u32 or 0x00020000'u32 or
               0x20000000'u32 or 0x10000000'u32 or 0x04000000'u32 or 0x00000080'u32

type
  SeccompInput* = object
    spec*: SeccompSpec
    privateDevices*, protectKernelModules*, protectKernelLogs*, protectClock*,
      protectHostname*: bool
    currentPersonality*: uint32
  FilterError* = object of CatchableError
    status*: int                  ## 228 (seccomp) or 232 (address families)

proc filterError(status: int; msg: string) {.noreturn.} =
  var e = newException(FilterError, msg)
  e.status = status
  raise e

proc splitSets*(words: seq[string]): tuple[allow, deny: seq[string]] =
  ## A word with `~` (and every word after it, as `~` covers the rest of its
  ## assignment) goes to the deny set. The unit model keeps no assignment
  ## boundaries, so a later bare word of a `~` line cannot be told from a new
  ## assignment: it stays a deny entry (the safe reading).
  var inverted = false
  for w in words:
    var x = w
    if x.startsWith("~"):
      inverted = true
      x = x[1 .. ^1]
    if x.len == 0: continue
    if inverted: result.deny.add x else: result.allow.add x

proc ruleFor(nr: int; action: uint32; conds: seq[Cond] = @[]): Rule =
  Rule(nr: uint32(nr), action: action, conds: conds)

proc addNamed(p: var Program; nrOf: NrLookup; names: openArray[string]; action: uint32;
              conds: seq[Cond] = @[]) =
  for n in names:
    let nr = nrOf(n)
    if nr >= 0: p.rules.add ruleFor(nr, action, conds)

proc buildPrograms*(inp: SeccompInput; nrOf: NrLookup): seq[Program] =
  let s = inp.spec
  let eperm = errnoAction(1)
  # 1. system call filter
  let globalErr = parseErrno(s.systemCallErrorNumber)
  if s.systemCallErrorNumber.len > 0 and globalErr.isNone:
    filterError(228, "invalid SystemCallErrorNumber=" & s.systemCallErrorNumber)
  let denyDefault = if globalErr.isSome: errnoAction(globalErr.get) else: RetKillProcess
  if s.systemCallFilter.len > 0:
    let (allowW, denyW) = splitSets(s.systemCallFilter)
    proc entryParts(e: string): (string, Option[int]) =
      let c = e.rfind(':')
      if c > 0 and e[0 ..< c].len > 0 and parseErrno(e[c + 1 .. ^1]).isSome:
        (e[0 ..< c], parseErrno(e[c + 1 .. ^1]))
      else: (e, none(int))
    var p = Program(default: RetAllow)
    var denied: seq[string]
    for w in denyW:
      let (name, er) = entryParts(w)
      var names: seq[string]
      try: names = expandSyscallEntry(name)
      except KeyError as e: filterError(228, e.msg)
      let act = if er.isSome: errnoAction(er.get) else: denyDefault
      for n in names:
        if n notin denied:
          denied.add n
          p.addNamed(nrOf, [n], act)
    if allowW.len > 0:
      p.default = denyDefault
      var allowed: seq[string]
      for w in allowW & expandSyscallEntry("@default"):
        let (name, er) = entryParts(w)
        if er.isSome: p.default = errnoAction(er.get)
        var names: seq[string]
        try: names = expandSyscallEntry(name)
        except KeyError as e: filterError(228, e.msg)
        for n in names:
          if n notin allowed and n notin denied:
            allowed.add n
            p.addNamed(nrOf, [n], RetAllow)
    result.add p
  # 2. address families
  if s.restrictAddressFamilies.len > 0:
    let (allowW, denyW) = splitSets(s.restrictAddressFamilies)
    let sock = nrOf("socket")
    var p = Program(default: RetAllow)
    proc fam(w: string): int =
      let up = w.toUpperAscii
      if up in AddressFamilies: AddressFamilies[up]
      else: filterError(232, "unknown address family " & w)
    let notAllowed = errnoAction(97)         # EAFNOSUPPORT
    proc famCond(w: string): seq[Cond] =
      @[Cond(arg: 0, kind: ckMaskEq, mask: 0xffffffff'u32, value: uint32(fam(w)))]
    if sock >= 0:
      for w in denyW:
        if w != "none": p.rules.add ruleFor(sock, notAllowed, famCond(w))
      if allowW.len > 0:
        # an allow list (`none` is the empty one): everything not listed is refused
        for w in allowW:
          if w != "none": p.rules.add ruleFor(sock, RetAllow, famCond(w))
        p.rules.add ruleFor(sock, notAllowed)
      result.add p
  # 3. namespaces
  if s.restrictNamespaces.len > 0 and not (s.restrictNamespaces == @["no"] or
                                           s.restrictNamespaces == @["false"]):
    var denyMask = 0'u32
    let (allowW, denyW) = splitSets(s.restrictNamespaces)
    if allowW == @["yes"] or allowW == @["true"] or allowW == @["1"]:
      denyMask = AllNsFlags
    else:
      if allowW.len > 0 or denyW.len == 0:
        var okMask = 0'u32
        for w in allowW:
          if w notin NsFlags: filterError(228, "unknown namespace type " & w)
          okMask = okMask or NsFlags[w]
        denyMask = AllNsFlags and not okMask
      for w in denyW:
        if w notin NsFlags: filterError(228, "unknown namespace type " & w)
        denyMask = denyMask or NsFlags[w]
    if denyMask != 0:
      var p = Program(default: RetAllow)
      p.addNamed(nrOf, ["clone"], eperm, @[Cond(arg: 0, kind: ckAny, mask: denyMask)])
      p.addNamed(nrOf, ["unshare"], eperm, @[Cond(arg: 0, kind: ckAny, mask: denyMask)])
      p.addNamed(nrOf, ["setns"], eperm, @[Cond(arg: 1, kind: ckAny, mask: denyMask)])
      p.addNamed(nrOf, ["setns"], eperm, @[Cond(arg: 1, kind: ckMaskEq, mask: 0xffffffff'u32, value: 0)])
      # clone3 takes its flags in a structure that BPF cannot read: ENOSYS makes libc fall back to clone
      p.addNamed(nrOf, ["clone3"], errnoAction(38))
      result.add p
  # 4. simple restrictions and implied denials, one program
  var p = Program(default: RetAllow)
  var denyAll: seq[string]
  if inp.protectKernelModules: denyAll.add expandSyscallEntry("@module")
  if inp.protectKernelLogs: denyAll.add "syslog"
  if inp.protectClock: denyAll.add expandSyscallEntry("@clock")
  if inp.protectHostname: denyAll.add ["sethostname", "setdomainname"]
  if inp.privateDevices: denyAll.add expandSyscallEntry("@raw-io")
  p.addNamed(nrOf, denyAll, eperm)
  if inp.privateDevices:
    for (name, argi) in [("mknod", 1), ("mknodat", 2)]:
      for t in [0o020000'u32, 0o060000'u32]:       # S_IFCHR, S_IFBLK
        p.addNamed(nrOf, [name], eperm, @[Cond(arg: argi, kind: ckMaskEq, mask: 0o170000'u32, value: t)])
  if s.restrictRealtime:
    for pol in [1'u32, 2, 6]:                       # SCHED_FIFO, SCHED_RR, SCHED_DEADLINE
      p.addNamed(nrOf, ["sched_setscheduler"], eperm,
                 @[Cond(arg: 1, kind: ckMaskEq, mask: 0x3fffffff'u32, value: pol)])
    p.addNamed(nrOf, ["sched_setattr"], eperm)
  if s.restrictSuidSgid:
    for (name, argi) in [("chmod", 1), ("fchmod", 1), ("fchmodat", 2), ("fchmodat2", 2)]:
      p.addNamed(nrOf, [name], eperm, @[Cond(arg: argi, kind: ckAny, mask: 0o6000'u32)])
  if s.memoryDenyWriteExecute:
    for n in ["mmap", "mmap2"]:
      p.addNamed(nrOf, [n], eperm, @[Cond(arg: 2, kind: ckMaskEq, mask: 6'u32, value: 6'u32)])
    for n in ["mprotect", "pkey_mprotect"]:
      p.addNamed(nrOf, [n], eperm, @[Cond(arg: 2, kind: ckAny, mask: 4'u32)])
    p.addNamed(nrOf, ["shmat"], eperm, @[Cond(arg: 2, kind: ckAny, mask: 0x8000'u32)])   # SHM_EXEC
  if s.lockPersonality:
    p.addNamed(nrOf, ["personality"], RetAllow,
               @[Cond(arg: 0, kind: ckMaskEq, mask: 0xffffffff'u32, value: 0xffffffff'u32)])
    p.addNamed(nrOf, ["personality"], RetAllow,
               @[Cond(arg: 0, kind: ckMaskEq, mask: 0xffffffff'u32, value: inp.currentPersonality)])
    p.addNamed(nrOf, ["personality"], eperm)
  if p.rules.len > 0: result.add p
  # 5. architecture check alone, when nothing else needs a program
  if result.len == 0 and s.systemCallArchitectures.len > 0:
    result.add Program(default: RetAllow)

proc wantsSeccomp*(ctx: ExecSpec): bool =
  let s = ctx.seccomp
  let sb = ctx.sandbox
  s.systemCallFilter.len > 0 or s.restrictAddressFamilies.len > 0 or s.restrictNamespaces.len > 0 or
    s.memoryDenyWriteExecute or s.lockPersonality or s.restrictRealtime or s.restrictSuidSgid or
    s.systemCallArchitectures.len > 0 or sb.privateDevices or sb.protectKernelModules or
    sb.protectKernelLogs or sb.protectClock or sb.protectHostname

# ---- installation ------------------------------------------------------------
type SockFilter {.pure.} = object
  code: uint16
  jt, jf: uint8
  k: uint32
type SockFprog {.pure.} = object
  len: uint16
  filter: ptr SockFilter

proc prctlC(option: cint; a2, a3, a4, a5: culong): cint {.importc: "prctl", header: "<sys/prctl.h>".}

proc installFilters*(ctx: ExecSpec) =
  ## Step 13: one program per family, each installed with PR_SET_SECCOMP. Needs
  ## NoNewPrivileges (set here when the process has no CAP_SYS_ADMIN left).
  if not wantsSeccomp(ctx): return
  when not defined(linux) or NativeArch == 0'u32:
    fail("SECCOMP", 228, "seccomp is not available on this platform")
  else:
    var inp = SeccompInput(spec: ctx.seccomp, privateDevices: ctx.sandbox.privateDevices,
      protectKernelModules: ctx.sandbox.protectKernelModules, protectKernelLogs: ctx.sandbox.protectKernelLogs,
      protectClock: ctx.sandbox.protectClock, protectHostname: ctx.sandbox.protectHostname)
    proc personalityC(p: culong): cint {.importc: "personality", header: "<sys/personality.h>".}
    inp.currentPersonality = uint32(personalityC(0xffffffff'u32))
    var programs: seq[Program]
    try:
      programs = buildPrograms(inp, proc(n: string): int = syscallNumber(n))
    except FilterError as e:
      fail(if e.status == 232: "ADDRESS_FAMILIES" else: "SECCOMP", e.status, e.msg)
    # NoNewPrivileges is implied unless the process still holds CAP_SYS_ADMIN
    var hasAdmin = false
    try:
      for line in readFile("/proc/self/status").splitLines:
        if line.startsWith("CapEff:"):
          hasAdmin = (parseHexInt(line.split(':')[1].strip) and (1 shl 21)) != 0
    except CatchableError: discard
    if not hasAdmin and prctlC(38, 1, 0, 0, 0) != 0:
      fail("SECCOMP", 228, "cannot set NoNewPrivileges: " & errnoMsg())
    for prog in programs:
      let insns = assemble(prog)
      if insns.len > MaxInsns:
        fail("SECCOMP", 228, "seccomp program too long (" & $insns.len & " instructions)")
      var filter = newSeq[SockFilter](insns.len)
      for i, x in insns: filter[i] = SockFilter(code: x.code, jt: x.jt, jf: x.jf, k: x.k)
      var fprog = SockFprog(len: uint16(filter.len), filter: addr filter[0])
      if prctlC(22, 2, cast[culong](addr fprog), 0, 0) != 0:     # PR_SET_SECCOMP, SECCOMP_MODE_FILTER
        let (step, status) = if ctx.seccomp.restrictAddressFamilies.len > 0 and programs.len == 1:
          ("ADDRESS_FAMILIES", 232) else: ("SECCOMP", 228)
        fail(step, status, "cannot install the system call filter: " & errnoMsg())
