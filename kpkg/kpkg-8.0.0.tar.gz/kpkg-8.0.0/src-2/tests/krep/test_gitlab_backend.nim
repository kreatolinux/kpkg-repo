## GitLab backend tests. Every case runs against a recorded GitLab REST API
## document, so no network access is needed.
import std/[json, os, unittest, tempfiles]
import ../../kpkg/modules/run3/run3
import ../../krep/modules/backends/gitlab
import ../../krep/modules/backends/stability

const fixtureDir = currentSourcePath().parentDir / "fixtures" / "gitlab"

proc fixture(name: string): JsonNode =
  parseJson(readFile(fixtureDir / (name & ".tags.json")))

proc config(host, project: string, tagPrefix = "", tagPattern = "",
    module = "", series = "", stability = ""): GitlabConfig =
  GitlabConfig(host: host, project: project, tagPrefix: tagPrefix,
    tagPattern: tagPattern, module: module, series: series,
    stability: stability)

proc newest(document: JsonNode, cfg: GitlabConfig): string =
  selectGitlabVersion(document, cfg)

suite "gitlab backend: archive URL parsing":
  test "group/project and ref come out of an archive URL":
    let parts = splitArchiveUrl(
      "https://gitlab.gnome.org/GNOME/gtk/-/archive/${version}/gtk-${version}.tar.gz")
    check parts.host == "gitlab.gnome.org"
    check parts.project == "GNOME/gtk"
    check parts.tagRef == "${version}"

  test "nested namespaces keep their full path":
    # gitlab.freedesktop.org nests x.org projects one level deeper.
    let parts = splitArchiveUrl(
      "https://gitlab.freedesktop.org/xorg/lib/libx11/-/archive/libX11-1.8.14/libX11-1.8.14.tar.gz")
    check parts.host == "gitlab.freedesktop.org"
    check parts.project == "xorg/lib/libx11"
    check parts.tagRef == "libX11-1.8.14"

  test "a pinned commit ref is not mistaken for a version":
    let parts = splitArchiveUrl(
      "https://gitlab.gnome.org/GNOME/gvdb/-/archive/4758f6fb7f889e074e13df3f914328f3eecb1fd3/gvdb-4758f6fb.tar.gz")
    check parts.project == "GNOME/gvdb"
    check parts.tagRef == "4758f6fb7f889e074e13df3f914328f3eecb1fd3"

  test "non-archive and non-GitLab URLs yield nothing":
    check splitArchiveUrl("fix-build.patch").host == ""
    check splitArchiveUrl("https://download.gnome.org/sources/gtk/4.24/gtk-4.24.1.tar.xz").host == ""
    check splitArchiveUrl(
      "https://github.com/foo/bar/archive/v1.tar.gz").project == ""
    # A plain project page is not an archive URL.
    check splitArchiveUrl("https://gitlab.gnome.org/GNOME/gtk").project == ""

  test "known GitLab hosts are recognised":
    check isGitlabHost("gitlab.gnome.org")
    check isGitlabHost("gitlab.freedesktop.org")
    check isGitlabHost("salsa.debian.org")
    check isGitlabHost("invent.kde.org")
    check isGitlabHost("gitlab.com")
    check not isGitlabHost("download.gnome.org")
    check not isGitlabHost("github.com")

suite "gitlab backend: API URLs":
  test "the project path is URL-encoded for the API":
    check gitlabProjectPath("GNOME/gtk") == "projects/GNOME%2Fgtk"
    check tagsUrl("gitlab.gnome.org", "GNOME/gtk") ==
      "https://gitlab.gnome.org/api/v4/projects/GNOME%2Fgtk/repository/tags?per_page=100&page=1"
    check releasesUrl("gitlab.freedesktop.org", "polkit/polkit") ==
      "https://gitlab.freedesktop.org/api/v4/projects/polkit%2Fpolkit/releases?per_page=100&page=1"

  test "a nested namespace is encoded as one path segment":
    check gitlabProjectPath("xorg/lib/libx11") ==
      "projects/xorg%2Flib%2Flibx11"

suite "gitlab backend: tag normalization":
  test "a leading v is dropped only when a digit follows":
    let cfg = config("gitlab.freedesktop.org", "glvnd/libglvnd")
    check normalizeTag("v1.7.0", cfg) == "1.7.0"
    check normalizeTag("1.7.0", cfg) == "1.7.0"
    # "vte" is a name, not a version prefix.
    check normalizeTag("vte", cfg) == "vte"
    check normalizeTag("  v2.0.1  ", cfg) == "2.0.1"

  test "an explicit tagPrefix is honoured":
    let cfg = config("gitlab.freedesktop.org", "xorg/lib/libx11",
      tagPrefix = "libX11-")
    check normalizeTag("libX11-1.8.14", cfg) == "1.8.14"
    # The prefix is removed once, at the beginning only.
    check normalizeTag("1.8.14", cfg) == "1.8.14"

  test "tagPattern handles irregular tag spellings":
    # Capture groups are joined with ".", so one pattern covers a whole
    # project's tag convention.
    let gtk = config("gitlab.gnome.org", "GNOME/gtk",
      tagPattern = "GTK_(\\d+)_(\\d+)_(\\d+)")
    check normalizeTag("GTK_4_24_1", gtk) == "4.24.1"
    let dashed = config("gitlab.gnome.org", "GNOME/gtk",
      tagPattern = "gtk-(\\d+)-(\\d+)-(\\d+)")
    check normalizeTag("gtk-4-24-1", dashed) == "4.24.1"
    let polkit = config("gitlab.freedesktop.org", "polkit/polkit",
      tagPattern = "polkit-(\\d+)")
    check normalizeTag("polkit-124", polkit) == "124"
    # A tag the pattern does not match normalizes to nothing, never to the tag.
    check normalizeTag("nightly", polkit) == ""
    check normalizeTag("polkit-124-1", polkit) == ""

  test "plain numeric tags need no configuration":
    let cfg = config("gitlab.gnome.org", "GNOME/gtk")
    check normalizeTag("4.24.1", cfg) == "4.24.1"
    check normalizeTag("49.2", cfg) == "49.2"

suite "gitlab backend: version selection":
  test "the greatest stable tag wins over an unstable newer one":
    # GTK's newest tag is 4.25.0, the first snapshot of the development cycle.
    let cfg = config("gitlab.gnome.org", "GNOME/gtk", module = "gtk",
      series = "4")
    check newest(fixture("gtk"), cfg) == "4.24.1"
    check selectGitlabVersion(fixture("gtk"), cfg) != "4.25.0"

  test "without the module rule the development series would win":
    let loose = config("gitlab.gnome.org", "GNOME/gtk", series = "4")
    check newest(fixture("gtk"), loose) == "4.25.0"

  test "series pinning keeps the previous stable line":
    # The recorded gtk tags reach 3.24.52; the recipe ships 3.24.43.
    let gtk3 = config("gitlab.gnome.org", "GNOME/gtk", module = "gtk",
      series = "3.24")
    check newest(fixture("gtk"), gtk3) == "3.24.52"
    check not seriesMatches("4.24.1", "3.24")

  test "alpha, beta and rc tags are rejected":
    let cfg = config("gitlab.gnome.org", "GNOME/glycin", module = "glycin")
    check newest(fixture("glycin"), cfg) == "2.2.6"
    check not isStable("2.3.0.beta", stAny)
    check not isStable("51.alpha", stAny)

  test "a project whose tags are all pre-releases yields nothing":
    let cfg = config("gitlab.gnome.org", "GNOME/demo", series = "9")
    check newest(fixture("prerelease-only"), cfg) == ""

  test "non-version tags are skipped rather than ranked":
    let cfg = config("gitlab.gnome.org", "GNOME/demo")
    check newest(fixture("mixed-tags"), cfg) == "2.1.0"

  test "releases documents use tag_name":
    # polkit publishes plain numeric tags ("124"), and its /releases endpoint
    # carries them as tag_name rather than name.
    let cfg = config("gitlab.freedesktop.org", "polkit/polkit")
    check newest(fixture("polkit-releases"), cfg) == "124"
    check tagCandidates(fixture("polkit-releases"), cfg)[0] == "124"

  test "a releases document is read from tag_name, not the release title":
    # /releases calls the release TITLE `name` and the tag `tag_name`. Real
    # fontconfig releases are {"name": "Release 2.18.3", "tag_name": "2.18.3"},
    # so reading `name` first yields a title that does not normalize at all.
    let cfg = GitlabConfig(host: "gitlab.freedesktop.org",
      project: "fontconfig/fontconfig", useReleases: true)
    check newest(fixture("fontconfig-releases"), cfg) == "2.18.3"
    check tagCandidates(fixture("fontconfig-releases"), cfg)[0] == "2.18.3"
    # The same document read as /repository/tags would be titles, not versions.
    let asTags = GitlabConfig(host: "gitlab.freedesktop.org",
      project: "fontconfig/fontconfig")
    check tagCandidates(fixture("fontconfig-releases"), asTags).len == 0

  test "an empty or malformed document yields nothing":
    check newest(parseJson("[]"), config("gitlab.gnome.org", "GNOME/gtk")) == ""
    check newest(parseJson("{}"), config("gitlab.gnome.org", "GNOME/gtk")) == ""
    check tagCandidates(parseJson("""[{"name":null}]"""),
      config("gitlab.gnome.org", "GNOME/gtk")).len == 0

suite "gitlab backend: configuration":
  test "host and project derive from the recipe's archive source":
    let work = createTempDir("krep-gitlab-config-", "")
    defer: removeDir(work)
    let packageDir = work / "gtk4"
    createDir(packageDir)
    writeFile(packageDir / "run3", """name: "gtk4"
version: "4.24.1"
release: "1"
sources:
 - "https://gitlab.gnome.org/GNOME/gtk/-/archive/${version}/gtk-${version}.tar.gz"
sha256sum:
 - "abc"
""")
    let recipe = parseRun3(packageDir)
    let cfg = gitlabConfig(packageDir, recipe.getSources())
    check cfg.host == "gitlab.gnome.org"
    check cfg.project == "GNOME/gtk"
    check cfg.tagPrefix == ""
    check projectNameFor(cfg) == "gtk"

  test "chkupd.cfg overrides and completes the derivation":
    let work = createTempDir("krep-gitlab-cfg-", "")
    defer: removeDir(work)
    let packageDir = work / "gtk4"
    createDir(packageDir)
    writeFile(packageDir / "run3", """name: "gtk4"
version: "4.24.1"
release: "1"
sources:
 - "https://download.gnome.org/sources/gtk/4.24/gtk-${version}.tar.xz"
sha256sum:
 - "abc"
""")
    writeFile(packageDir / "chkupd.cfg", """[autoUpdater]
mechanism="gitlab"

[gitlab]
host="gitlab.gnome.org"
project="GNOME/gtk"
module="gtk"
series="4"
tagPrefix="v"
useReleases="true"
archive="gitlab"
""")
    let recipe = parseRun3(packageDir)
    let cfg = gitlabConfig(packageDir, recipe.getSources())
    check cfg.host == "gitlab.gnome.org"
    check cfg.project == "GNOME/gtk"
    check cfg.module == "gtk"
    check cfg.series == "4"
    check cfg.tagPrefix == "v"
    check cfg.useReleases
    check cfg.archive == "gitlab"

  test "trimString is accepted as the tagPrefix spelling":
    let work = createTempDir("krep-gitlab-trim-", "")
    defer: removeDir(work)
    let packageDir = work / "demo"
    createDir(packageDir)
    writeFile(packageDir / "run3", """name: "demo"
version: "1.0.0"
release: "1"
sources:
 - "https://gitlab.example.org/grp/demo/-/archive/${version}/demo-${version}.tar.gz"
sha256sum:
 - "abc"
""")
    writeFile(packageDir / "chkupd.cfg", """[autoUpdater]
mechanism="gitlab"
trimString="v"
""")
    let cfg = gitlabConfig(packageDir, parseRun3(packageDir).getSources())
    check cfg.host == "gitlab.example.org"
    check cfg.tagPrefix == "v"

  test "stability and series come from the module when not set explicitly":
    let cfg = config("gitlab.gnome.org", "GNOME/gtk", module = "gtk")
    check stabilityRule(cfg) == stEvenMinor
    check seriesPin(cfg) == "4"
    let explicit = config("gitlab.gnome.org", "GNOME/gtk", module = "gtk",
      series = "3.24", stability = "any")
    check stabilityRule(explicit) == stAny
    check seriesPin(explicit) == "3.24"
    let bare = config("gitlab.gnome.org", "GNOME/demo")
    check stabilityRule(bare) == stAny
    check seriesPin(bare) == ""

  test "archive URLs are rebuilt from the observed raw tag":
    # The archive path needs the real tag, not the normalized version, so the
    # raw tag is looked up in the response that produced the version.
    let plain = config("gitlab.gnome.org", "GNOME/gtk")
    check rawTagFor(fixture("gtk"), plain, "4.24.1") == "4.24.1"
    check rawTagFor(fixture("gtk"), plain, "9.9.9") == ""
    check archiveUrl(plain, "4.24.1", "gtk") ==
      "https://gitlab.gnome.org/GNOME/gtk/-/archive/4.24.1/gtk-4.24.1.tar.gz"
    # libglvnd tags carry a v that the version drops.
    let glvnd = config("gitlab.freedesktop.org", "glvnd/libglvnd")
    check rawTagFor(fixture("libglvnd"), glvnd, "1.7.0") == "v1.7.0"
    # The raw tag keeps the v: .../-/archive/1.7.0/... is a real 404, while
    # .../-/archive/v1.7.0/... is a real 200, so pass the tag through.
    check archiveUrl(glvnd, rawTagFor(fixture("libglvnd"), glvnd, "1.7.0"),
      "libglvnd") ==
      "https://gitlab.freedesktop.org/glvnd/libglvnd/-/archive/v1.7.0/libglvnd-v1.7.0.tar.gz"
    # libX11 tags carry a libX11- prefix, which tagPrefix supplies.
    let x11 = config("gitlab.freedesktop.org", "xorg/lib/libx11",
      tagPrefix = "libX11-")
    check rawTagFor(fixture("libx11"), x11, "1.8.14") == "libX11-1.8.14"
    check newest(fixture("libx11"), x11) == "1.8.14"
    # Without tagPrefix/tagPattern a NAME-1.2.3 tag set yields NOTHING, because
    # the normalized tag does not start with a digit. That is a configuration
    # error, not "upstream has no releases".
    let unconfigured = config("gitlab.freedesktop.org", "xorg/lib/libx11")
    check tagCandidates(fixture("libx11"), unconfigured).len == 0
    check newest(fixture("libx11"), unconfigured) == ""

  test "the rewrite emits a template so the NEXT update still works":
    # autoupdater refuses to bump a recipe whose source URL has no ${version},
    # so writing the literal tag would make archive="gitlab" one-shot.
    let plain = config("gitlab.gnome.org", "GNOME/gtk")
    check tagTemplateFor(plain, "4.24.1", "4.24.1") == "${version}"
    check tagTemplateFor(plain, "v1.7.0", "1.7.0") == "v${version}"
    check tagTemplateFor(plain, "libX11-1.8.14", "1.8.14") == "libX11-${version}"
    check tagTemplateFor(plain, "GTK_4_24_1", "4.24.1") == "GTK_4_24_1"
    # An explicit archiveTemplate wins, for tag shapes that cannot be inverted.
    let explicit = GitlabConfig(host: "gitlab.gnome.org",
      project: "GNOME/gtk", archiveTemplate: "GTK_${version}")
    check tagTemplateFor(explicit, "GTK_4_24_1", "4.24.1") == "GTK_${version}"

  test "the archive stem comes from the recipe's own source URL":
    # The stem selects the extracted root directory, so it must not be guessed
    # from the project path: a wrong stem yields a commit-hash-suffixed root.
    let cfg = config("gitlab.freedesktop.org", "xorg/lib/libx11")
    # A recipe that does not fetch this project at all falls back to the
    # project path's last segment.
    check archiveStemFor(
      @["https://www.x.org/releases/individual/lib/libX11-${version}.tar.gz"],
      cfg, "libx11") == "libx11"
    check archiveStemFor(
      @["https://gitlab.freedesktop.org/xorg/lib/libx11/-/archive/libX11-1.8.14/libX11-libX11-1.8.14.tar.gz"],
      cfg, "libx11") == "libX11"
    # A recipe that already fetches this project keeps ITS stem, whatever the
    # project path's case is.
    check archiveStemFor(
      @["https://gitlab.freedesktop.org/xorg/lib/libx11/-/archive/${version}/libX11-${version}.tar.gz"],
      cfg, "libx11") == "libX11"

  test "a series pin older than the first page is still found":
    # The backend pages past position 100 only when a series pin needs it; a
    # pin whose releases are on page 1 must not cost a second request.
    let many = fixture("many-tags")
    let onPage1 = config("gitlab.gnome.org", "GNOME/demo", series = "4")
    check seriesSatisfied(many, onPage1)
    let deep = config("gitlab.gnome.org", "GNOME/demo", series = "3.22")
    check not seriesSatisfied(mergePages(@[parseJson(
      $many[0 ..< 100])]), deep)
    check seriesSatisfied(many, deep)
    check selectGitlabVersion(many, deep) == "3.22.30"

  test "a tagPrefix is only stripped when a digit follows":
    # A prefix that would eat part of a word is not a version prefix.
    let v = config("gitlab.gnome.org", "GNOME/demo", tagPrefix = "v")
    check normalizeTag("v1.2.3", v) == "1.2.3"
    check normalizeTag("version-2", v) == "version-2"
    check tagCandidates(parseJson("""[{"name":"version-2"}]"""), v).len == 0

  test "a tagPattern with no capture group uses the whole match":
    # Returning "" here would silently disable every tag.
    let cfg = config("gitlab.gnome.org", "GNOME/demo",
      tagPattern = r"\d+\.\d+\.\d+")
    check normalizeTag("4.24.1", cfg) == "4.24.1"
    check normalizeTag("nightly", cfg) == ""

suite "gitlab backend: shared stability rules":
  test "the gitlab backend and the gnome backend agree on stability":
    # Both backends import ./stability, so this pins the shared contract.
    check stabilityFor("glib") == stEvenMinor
    check stabilityFor("librsvg") == stAny
    check defaultSeriesFor("gtk") == "4"
    check parseStability("even-minor") == stEvenMinor
    expect ValueError:
      discard parseStability("sometimes")
