## Transaction and validation tests for the krep run3 autoupdater.
import std/[os, strutils, tempfiles, unittest]
import ../../kpkg/modules/run3/run3
import ../../krep/modules/autoupdater

proc makePackage(root, body: string): string =
  result = root / "package"
  createDir(result)
  writeFile(result / "run3", body)

suite "transactional krep autoupdater":
  setup:
    let work = createTempDir("krep autoupdater test-", "")
  teardown:
    removeDir(work)

  test "local and SKIP sources are retained while metadata changes atomically":
    let packageDir = makePackage(work, """name: sample
version: "1.0"
release: "1"
sources:
        - "local.patch"
        - "https://invalid.example/${version}.tar.gz"
sha256sum:
        - "local-checksum"
        - "SKIP"
""")
    writeFile(packageDir / "local.patch", "patch")
    let recipe = parseRun3(packageDir)

    autoUpdater(recipe, packageDir, "2.0", false, "2")

    let updated = readFile(packageDir / "run3")
    check updated.contains("version: \"2.0\"")
    check updated.contains("release: \"2\"")
    check "local-checksum" in updated
    check "SKIP" in updated

  test "source checksum mismatch fails before changing recipe":
    let packageDir = makePackage(work, """name: mismatch
version: 1.0
release: 1
sources:
        - "one.patch"
        - "two.patch"
sha256sum:
        - "first"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)

    expect ValueError:
      autoUpdater(recipe, packageDir, "2.0", false)
    check readFile(packageDir / "run3") == original

  test "ambiguous version metadata fails without changing recipe":
    let packageDir = makePackage(work, """name: ambiguous
version: 1.0
version: 1.0
release: 1
sources:
        - "local.patch"
sha256sum:
        - "SKIP"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)

    expect ValueError:
      autoUpdater(recipe, packageDir, "2.0", false)
    check readFile(packageDir / "run3") == original

  test "download failure rolls back all checksum and metadata changes":
    let packageDir = makePackage(work, """name: rollback
version: 1.0
release: 1
sources:
        - "https://example.invalid/${version}-one.tar.gz"
        - "https://example.invalid/${version}-two.tar.gz"
sha256sum:
        - "old-one"
        - "old-two"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    var calls = 0
    let failingFetcher: SourceFetcher = proc(source, destination: string) =
      inc calls
      if calls == 1:
        writeFile(destination, "first source")
      else:
        raise newException(IOError, "second source failed")

    autoUpdaterWithFetcher(recipe, packageDir, "2.0", true, "",
      failingFetcher)
    check calls == 2
    check readFile(packageDir / "run3") == original
    check getCurrentDir() != packageDir

  test "download failure propagates without changing the recipe":
    let packageDir = makePackage(work, """name: propagate
version: 1.0
release: 1
sources:
        - "https://example.invalid/${version}.tar.gz"
sha256sum:
        - "old-sum"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let failingFetcher: SourceFetcher = proc(source, destination: string) =
      raise newException(IOError, "fetch failed")

    expect IOError:
      autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "",
        failingFetcher)
    check readFile(packageDir / "run3") == original

  test "duplicate old checksums are replaced by list position":
    let packageDir = makePackage(work, """name: duplicate-sums
version: 1.0
release: 1
sources:
        - "https://example.invalid/${version}-one.tar.gz"
        - "https://example.invalid/${version}-two.tar.gz"
sha256sum:
        - "same-old-sum"
        - "same-old-sum"
""")
    let recipe = parseRun3(packageDir)
    let fetcher: SourceFetcher = proc(source, destination: string) =
      writeFile(destination, source)
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", fetcher)
    let updated = parseRun3(packageDir)
    check updated.getVersion() == "2.0"
    check updated.getSha256sum().len == 2
    check updated.getSha256sum()[0] != "same-old-sum"
    check updated.getSha256sum()[1] != "same-old-sum"
    check updated.getSha256sum()[0] != updated.getSha256sum()[1]
    let bytes = readFile(packageDir / "run3")
    check bytes.endsWith("\n")
    check not bytes.endsWith("\n\n")

suite "krep autoupdater: multi-source and templated recipes":
  setup:
    let work = createTempDir("krep autoupdater multi-", "")
  teardown:
    removeDir(work)

  test "only the upstream tarball is fetched, local patches are untouched":
    let packageDir = makePackage(work, """name: gdm
version: "50.3"
release: "8"
sources:
 - "https://download.gnome.org/sources/gdm/${version.split('.')[0]}/gdm-${version}.tar.xz"
 - "gdm-dynamic-user.patch"
sha256sum:
 - "old-tarball-sum"
 - "patch-sum"
""")
    writeFile(packageDir / "gdm-dynamic-user.patch", "patch body")
    let recipe = parseRun3(packageDir)
    var fetched: seq[string] = @[]
    let fetcher: SourceFetcher = proc(source, destination: string) =
      fetched.add(source)
      writeFile(destination, "tarball")
    autoUpdaterWithFetcher(recipe, packageDir, "51.1.1", false, "1", fetcher)
    check fetched == @[
      "https://download.gnome.org/sources/gdm/51/gdm-51.1.1.tar.xz"]
    let updated = readFile(packageDir / "run3")
    check updated.contains("version: \"51.1.1\"")
    check updated.contains("release: \"1\"")
    check updated.contains(" - \"gdm-dynamic-user.patch\"")
    check updated.contains(" - \"patch-sum\"")
    check not updated.contains("old-tarball-sum")
    # The templated URL line is kept verbatim: the new version flows through
    # ${version.split('.')[0]} at build time.
    check updated.contains(
      "https://download.gnome.org/sources/gdm/${version.split('.')[0]}/gdm-${version}.tar.xz")

  test "a templated URL with a series function resolves for the new version":
    let packageDir = makePackage(work, """name: gtk4
version: "4.20.4"
release: "2"
sources:
 - "https://download.gnome.org/sources/gtk/${version.split('.')[0:2].join('.')}/gtk-${version}.tar.xz"
sha256sum:
 - "old-sum"
""")
    let recipe = parseRun3(packageDir)
    check recipe.getSourcesWithVersion("4.24.1") == @[
      "https://download.gnome.org/sources/gtk/4.24/gtk-4.24.1.tar.xz"]
    var fetched: seq[string] = @[]
    let fetcher: SourceFetcher = proc(source, destination: string) =
      fetched.add(source)
      writeFile(destination, "tarball")
    autoUpdaterWithFetcher(recipe, packageDir, "4.24.1", false, "", fetcher)
    check fetched == @["https://download.gnome.org/sources/gtk/4.24/gtk-4.24.1.tar.xz"]

  test "a source rewrite replaces exactly one entry":
    let packageDir = makePackage(work, """name: librsvg
version: "2.63.3"
release: "4"
sources:
 - "https://gitlab.gnome.org/GNOME/librsvg/-/archive/${version}/librsvg-${version}.tar.gz"
 - "librsvg-fix.patch"
sha256sum:
 - "old-sum"
 - "patch-sum"
""")
    writeFile(packageDir / "librsvg-fix.patch", "patch body")
    let recipe = parseRun3(packageDir)
    var fetched: seq[string] = @[]
    let fetcher: SourceFetcher = proc(source, destination: string) =
      fetched.add(source)
      writeFile(destination, "tarball")
    autoUpdaterWithFetcher(recipe, packageDir, "2.63.4", false, "",
      fetcher, SourceRewrite(index: 0,
        url: "https://download.gnome.org/sources/librsvg/2.63/librsvg-2.63.4.tar.xz"))
    check fetched == @[
      "https://download.gnome.org/sources/librsvg/2.63/librsvg-2.63.4.tar.xz"]
    let updated = readFile(packageDir / "run3")
    check updated.contains(
      " - \"https://download.gnome.org/sources/librsvg/2.63/librsvg-2.63.4.tar.xz\"")
    check updated.contains(" - \"librsvg-fix.patch\"")
    check updated.contains(" - \"patch-sum\"")
    check not updated.contains("gitlab.gnome.org")

  test "an out-of-range source rewrite fails before changing the recipe":
    let packageDir = makePackage(work, """name: small
version: "1.0"
release: "1"
sources:
 - "https://example.invalid/${version}.tar.gz"
sha256sum:
 - "old-sum"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let fetcher: SourceFetcher = proc(source, destination: string) =
      writeFile(destination, "tarball")
    expect ValueError:
      autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "",
        fetcher, SourceRewrite(index: 3, url: "https://example.invalid/x.tar.gz"))
    check readFile(packageDir / "run3") == original

  test "an unchanged release is not rewritten":
    let packageDir = makePackage(work, """name: keep
version: "1.0"
release: "7"
sources:
 - "https://example.invalid/${version}.tar.gz"
sha256sum:
 - "old-sum"
""")
    let recipe = parseRun3(packageDir)
    let fetcher: SourceFetcher = proc(source, destination: string) =
      writeFile(destination, "tarball")
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "7", fetcher)
    let updated = readFile(packageDir / "run3")
    check updated.contains("release: \"7\"")
    check updated.contains("version: \"2.0\"")

suite "krep autoupdater: hardcoded source URLs":
  setup:
    let work = createTempDir("krep autoupdater hardcoded-", "")
  teardown:
    removeDir(work)

  test "a hardcoded source URL blocks the version bump":
    # gpgme/sqlite/libnl in the real repository claim a version the source URL
    # does not carry, so bumping would keep fetching the old tarball.
    let packageDir = makePackage(work, """name: gpgme
version: "2.2.0"
release: "1"
sources:
 - "https://gnupg.org/ftp/gcrypt/gpgme/gpgme-1.23.2.tar.bz2"
sha256sum:
 - "old-sum"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let fetcher: SourceFetcher = proc(source, destination: string) =
      writeFile(destination, "tarball")
    expect ValueError:
      autoUpdaterWithFetcher(recipe, packageDir, "2.3.0", false, "", fetcher)
    check readFile(packageDir / "run3") == original

  test "a templated source URL still updates":
    let packageDir = makePackage(work, """name: grep
version: "3.11"
release: "1"
sources:
 - "https://ftp.gnu.org/gnu/grep/grep-${version}.tar.xz"
sha256sum:
 - "old-sum"
""")
    let recipe = parseRun3(packageDir)
    let fetcher: SourceFetcher = proc(source, destination: string) =
      writeFile(destination, "tarball")
    autoUpdaterWithFetcher(recipe, packageDir, "3.12", false, "1", fetcher)
    check parseRun3(packageDir).getVersion() == "3.12"

  test "local sources are exempt from the placeholder rule":
    let packageDir = makePackage(work, """name: withpatch
version: "1.0"
release: "1"
sources:
 - "https://example.invalid/${version}.tar.gz"
 - "local.patch"
sha256sum:
 - "old-sum"
 - "patch-sum"
""")
    writeFile(packageDir / "local.patch", "patch")
    let recipe = parseRun3(packageDir)
    let fetcher: SourceFetcher = proc(source, destination: string) =
      writeFile(destination, "tarball")
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "1", fetcher)
    check parseRun3(packageDir).getVersion() == "2.0"
