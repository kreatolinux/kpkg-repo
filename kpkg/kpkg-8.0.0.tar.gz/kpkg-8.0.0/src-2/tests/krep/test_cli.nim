## Native, offline integration tests for the prebuilt krep executable.
## Build out/krep first, or set KREP_TEST_BINARY to an executable path.
## No command here builds images, cleans host archives, or contacts upstreams.
import std/[algorithm, json, os, osproc, streams, strutils, tables, tempfiles,
            unittest]

const sourceRoot = currentSourcePath().parentDir.parentDir.parentDir
let binary = absolutePath(getEnv("KREP_TEST_BINARY", sourceRoot / "out/krep"))
if not fileExists(binary):
  quit("krep CLI tests require a prebuilt executable: " & binary &
       "\nBuild out/krep first or set KREP_TEST_BINARY.", QuitFailure)
when defined(posix):
  if (getFilePermissions(binary) * {fpUserExec, fpGroupExec, fpOthersExec}) == {}:
    quit("KREP_TEST_BINARY is not executable: " & binary, QuitFailure)

type
  CommandResult = tuple[output: string, exitCode: int]
  FileSnapshot = object
    isFile, isDir, isLink: bool
    contents, target: string

proc snapshot(path: string): FileSnapshot =
  ## Read only. Never create or restore a host configuration or lock file.
  result.isFile = fileExists(path)
  result.isDir = dirExists(path)
  result.isLink = symlinkExists(path)
  if result.isLink:
    result.target = expandSymlink(path)
  if result.isFile:
    result.contents = readFile(path)

proc repositorySnapshot(path: string): Table[string, FileSnapshot] =
  result = initTable[string, FileSnapshot]()
  for kind, entry in walkDir(path):
    result[relativePath(entry, path)] = snapshot(entry)
    if kind == pcDir:
      for child, state in repositorySnapshot(entry):
        result[relativePath(entry, path) / child] = state

proc runCli(work: string, args: openArray[string]): CommandResult =
  ## Pass literal arguments directly: wildcard patterns must not reach a shell.
  let process = startProcess(binary, workingDir = work, args = args,
                            options = {poStdErrToStdOut})
  defer: close(process)
  result.output = process.outputStream.readAll()
  result.exitCode = process.waitForExit()

proc expectExit(work: string, args: openArray[string],
    code: int): CommandResult =
  result = runCli(work, args)
  checkpoint "krep " & args.join(" ") & "\n" & result.output
  check result.exitCode == code

proc expectFailure(work: string, args: openArray[string]): CommandResult =
  result = runCli(work, args)
  checkpoint "krep " & args.join(" ") & "\n" & result.output
  check result.exitCode != 0
  check result.output.strip.len > 0

const canonicalRunfile = "name: demo\nversion: 1.2.3\nrelease: 1\n" &
                        "description: \"CLI fixture\"\n"

const archRunfile = canonicalRunfile & """
sources:
  - "common-patch"
sha256sum:
  - "common-sum"
sources_aarch64:
  - "arm-tarball"
sha256sum_aarch64:
  - "arm-sum"
sources_x86_64:
  - "x86-tarball"
sha256sum_x86_64:
  - "x86-sum"
depends:
  - "glib"
depends_aarch64:
  - "arm-dep"
build_depends_x86_64:
  - "x86-build-dep"
depends_aarch64_linux_gnu_glibc:
  - "aarch64-linux-gnu-linux-headers"
depends_demo:
  - "demo-subpackage-dep"
"""

proc packageFixture(repo: string, name = "demo", filename = "run3"): string =
  result = repo / name
  createDir(result)
  writeFile(result / filename, canonicalRunfile.replace("name: demo", "name: " & name))

suite "krep native CLI (offline)":
  setup:
    # Spaces in all fixture paths exercise argument handling without shell quoting.
    let work = createTempDir("krep cli tests-", "")
  teardown:
    removeDir(work)

  test "top-level help lists all commands and preserves host state":
    let configBefore = snapshot("/etc/kpkg/kpkg.conf")
    let lockBefore = snapshot("/tmp/kpkg.lock")
    let response = expectExit(work, ["--help"], 0)
    for command in ["check", "update", "clean", "lint", "fmt", "convert",
                    "generate", "rootfs", "iso", "disk"]:
      check command in response.output
    check snapshot("/etc/kpkg/kpkg.conf") == configBefore
    check snapshot("/tmp/kpkg.lock") == lockBefore

  test "every command and generation subcommand has side-effect-free help":
    let commands = @[@["check"], @["update"], @["clean"], @["lint"],
                     @["fmt"], @["convert"], @["generate"], @["rootfs"],
                     @["iso"], @["disk"], @["generate", "matrix"],
                     @["generate", "markdown"], @["generate", "manpage"]]
    for command in commands:
      let configBefore = snapshot("/etc/kpkg/kpkg.conf")
      let lockBefore = snapshot("/tmp/kpkg.lock")
      let response = expectExit(work, command & @["--help"], 0)
      check response.output.strip.len > 0
      check command[^1] in response.output.toLowerAscii
      check snapshot("/etc/kpkg/kpkg.conf") == configBefore
      check snapshot("/tmp/kpkg.lock") == lockBefore

  test "image help exposes resource overrides without loading or modifying them":
    let resources = work / "resource directory"
    createDir(resources)
    writeFile(resources / "sentinel", "must remain untouched\n")
    let before = repositorySnapshot(work)
    let configBefore = snapshot("/etc/kpkg/kpkg.conf")
    let lockBefore = snapshot("/tmp/kpkg.lock")
    let hadDataDir = existsEnv("KREP_DATA_DIR")
    let oldDataDir = getEnv("KREP_DATA_DIR")
    # This invalid resource path must never be resolved merely to display help.
    putEnv("KREP_DATA_DIR", work / "nonexistent resources")
    try:
      let rootfsHelp = expectExit(work,
          ["rootfs", "--help", "--dataDir=" & resources], 0)
      for flag in ["--buildType", "--arch", "--noSandbox", "--dataDir",
                   "--configPath", "--overlayPath"]:
        check flag in rootfsHelp.output
      let isoHelp = expectExit(work,
          ["iso", "--help", "--dataDir=" & resources], 0)
      for flag in ["--rootfs", "--output", "--init", "--dataDir", "--grubConfig",
                   "--kernelVersion", "--kernelImage", "--initramfs",
                   "--workDir",
                   "--imageSizeMiB", "--clearRootPassword", "--name",
                   "--overwrite"]:
        check flag in isoHelp.output
    finally:
      if hadDataDir: putEnv("KREP_DATA_DIR", oldDataDir)
      else: delEnv("KREP_DATA_DIR")
    check repositorySnapshot(work) == before
    check snapshot("/etc/kpkg/kpkg.conf") == configBefore
    check snapshot("/tmp/kpkg.lock") == lockBefore

  test "nested help targets one generator":
    let response = expectExit(work, ["generate", "help", "matrix"], 0)
    check "--repo" in response.output
    check "--pkgPath" notin response.output
    check "--file" notin response.output
    discard expectFailure(work, ["generate", "help", "not-a-generator"])

  test "version identifies krep and its commit":
    let response = expectExit(work, ["--version"], 0)
    check "krep " in response.output
    check "commit " in response.output

  test "unknown command and unknown options fail":
    discard expectFailure(work, ["not-a-krep-command"])
    discard expectFailure(work, ["--not-a-krep-option"])
    for command in ["check", "update", "lint", "fmt", "convert"]:
      discard expectFailure(work, [command, "--not-a-krep-option"])
    discard expectFailure(work, ["generate", "not-a-generator"])
    discard expectFailure(work, ["generate", "matrix", "--not-a-krep-option"])

  test "repository commands require package and repo options":
    for command in ["check", "update"]:
      discard expectFailure(work, [command])
      discard expectFailure(work, [command, "--package=never-matches-*"])
      discard expectFailure(work, [command, "--repo=" & work])

  test "generation and conversion required arguments are validated":
    discard expectFailure(work, ["generate", "matrix"])
    discard expectFailure(work, ["generate", "manpage"])
    discard expectFailure(work, ["generate", "manpage", "--file=" & work / "missing.md"])
    discard expectFailure(work, ["generate", "manpage", "--output=" & work / "out.md"])
    discard expectFailure(work, ["convert"])
    discard expectFailure(work, ["convert", "--fromVer=2"])
    discard expectFailure(work, ["convert", "--toVer=3"])
    discard expectFailure(work, ["convert", "--fromVer=not-an-int", "--toVer=3"])
    discard expectFailure(work, ["generate", "matrix", "--repo=" & work,
                                 "--limit=not-an-int"])

  test "check cannot opt into updates and update exposes its flags":
    let repo = work / "repo"
    discard packageFixture(repo)
    let before = repositorySnapshot(repo)
    let response = expectFailure(work, ["check", "--package=never-matches-*",
                                       "--repo=" & repo, "--autoUpdate"])
    check "autoUpdate".toLowerAscii in response.output.toLowerAscii
    check repositorySnapshot(repo) == before
    let checkHelp = expectExit(work, ["check", "--help"], 0)
    check "autoupdate" notin checkHelp.output.toLowerAscii
    let updateHelp = expectExit(work, ["update", "--help"], 0)
    for flag in ["--package", "--repo", "--backend", "--skipIfDownloadFails", "--verbose"]:
      check flag in updateHelp.output

  test "check with no wildcard matches is offline and read-only":
    let repo = work / "repo"
    let pkg = packageFixture(repo)
    writeFile(pkg / "chkupd.cfg", "[autoUpdater]\nmechanism=repology\n")
    writeFile(repo / "sentinel", "do not change\n")
    let before = repositorySnapshot(repo)
    let configBefore = snapshot("/etc/kpkg/kpkg.conf")
    let lockBefore = snapshot("/tmp/kpkg.lock")
    for backend in ["repology", "arch", "githubReleases"]:
      let response = expectExit(work, ["check", "--package=never-matches-*?",
                                      "--repo=" & repo, "--backend=" & backend], 0)
      check "No packages found matching pattern" in response.output
      check repositorySnapshot(repo) == before
    check snapshot("/etc/kpkg/kpkg.conf") == configBefore
    check snapshot("/tmp/kpkg.lock") == lockBefore

  test "fmt check succeeds for canonical input without writing":
    let pkg = packageFixture(work / "repo")
    let before = repositorySnapshot(pkg)
    discard expectExit(work, ["fmt", "--path=" & pkg / "run3", "--check"], 0)
    check repositorySnapshot(pkg) == before

  test "fmt check returns one for changes and fmt makes them canonical":
    let pkg = packageFixture(work / "repo")
    let path = pkg / "run3"
    let unformatted = "release: 1\nversion: \"1.2.3\"\nname: \"demo\"\n" &
                      "description: \"CLI fixture\"\n"
    writeFile(path, unformatted)
    let response = expectExit(work, ["fmt", "--path=" & path, "--check"], 1)
    check "would reformat" in response.output
    check readFile(path) == unformatted
    discard expectExit(work, ["fmt", "--path=" & path], 0)
    check readFile(path) == canonicalRunfile
    discard expectExit(work, ["fmt", "--path=" & path, "--check"], 0)

  test "fmt and lint return one for malformed input and missing paths":
    let path = work / "broken.run3"
    let malformed = "name: demo\nbuild {\n"
    writeFile(path, malformed)
    for command in ["fmt", "lint"]:
      let response = expectExit(work, [command, "--path=" & path], 1)
      check "error" in response.output.toLowerAscii
      check readFile(path) == malformed
      discard expectExit(work, [command, "--path=" & work / "missing"], 1)

  test "lint returns zero for valid input and one for missing required fields":
    let pkg = packageFixture(work / "repo")
    discard expectExit(work, ["lint", "--path=" & pkg / "run3"], 0)
    writeFile(pkg / "run3", "description: \"Missing required fields\"\n")
    let response = expectExit(work, ["lint", "--path=" & pkg], 1)
    for field in ["name", "version", "release"]:
      check "missing required variable: " & field in response.output

  test "lint accepts a correct per-architecture recipe":
    let pkg = packageFixture(work / "repo")
    writeFile(pkg / "run3", archRunfile)
    let response = expectExit(work, ["lint", "--path=" & pkg / "run3"], 0)
    check "No issues found" in response.output
    # A qualifier that is a sub-package name is not an architecture attempt.
    check "unknown architecture" notin response.output

  test "lint rejects a per-architecture checksum list of the wrong length":
    let pkg = packageFixture(work / "repo")
    # One source, two sums: the lists of a group must line up.
    writeFile(pkg / "run3", archRunfile.replace(
        "sha256sum_aarch64:\n  - \"arm-sum\"\n",
        "sha256sum_aarch64:\n  - \"arm-sum\"\n  - \"extra-sum\"\n"))
    let response = expectExit(work, ["lint", "--path=" & pkg / "run3"], 1)
    check "sha256sum_aarch64 has 2 entries but sources_aarch64 has 1" in
        response.output

  test "lint warns about an unknown architecture qualifier":
    let pkg = packageFixture(work / "repo")
    writeFile(pkg / "run3", archRunfile & """
sources_mips64:
  - "mips-tarball"
sha256sum_mips64:
  - "mips-sum"
depends_mips64:
  - "mips-dep"
""")
    # Warnings alone keep the exit code at zero.
    let response = expectExit(work, ["lint", "--path=" & pkg / "run3"], 0)
    for key in ["sources_mips64", "sha256sum_mips64", "depends_mips64"]:
      check "unknown architecture 'mips64' in " & key in response.output
    check "3 warning(s)" in response.output
    # The sub-package qualifiers in archRunfile are not architecture attempts:
    # a multi-token name (`aarch64_linux_gnu_glibc`) and `depends_demo`.
    check "linux_gnu_glibc" notin response.output
    check "depends_demo" notin response.output

  test "lint warns about a stray arch checksum list and duplicate arch groups":
    let pkg = packageFixture(work / "repo")
    writeFile(pkg / "run3", canonicalRunfile & """
sources:
  - "common-patch"
sha256sum:
  - "common-sum"
sha256sum_aarch64:
  - "arm-sum"
""")
    let stray = expectExit(work, ["lint", "--path=" & pkg / "run3"], 0)
    check "sha256sum_aarch64 has no matching sources_aarch64 list" in stray.output

    # `arm64` and `aarch64` are the same architecture, so only one group can
    # ever be selected: an error, not a warning.
    writeFile(pkg / "run3", canonicalRunfile & """
sources_aarch64:
  - "arm-tarball"
sha256sum_aarch64:
  - "arm-sum"
sources_arm64:
  - "arm-tarball-2"
sha256sum_arm64:
  - "arm-sum-2"
""")
    let duplicate = expectExit(work, ["lint", "--path=" & pkg / "run3"], 1)
    check "duplicate source group for architecture 'aarch64'" in duplicate.output

  test "lint flags a group with no checksums even when another group has them":
    let pkg = packageFixture(work / "repo")
    # The global "sources defined but no checksums" warning cannot see this: the
    # common list has sums, the arch group does not.
    writeFile(pkg / "run3", canonicalRunfile & """
sources:
  - "common-patch"
sha256sum:
  - "common-sum"
sources_aarch64:
  - "arm-tarball"
""")
    let response = expectExit(work, ["lint", "--path=" & pkg / "run3"], 0)
    check "sources_aarch64 has no checksums" in response.output
    check "sources defined but no checksums" notin response.output

  test "lint accepts a sub-package whose name matches neither name nor directory":
    # The `src` recipe in the real repository: directory `src`, `name: "src"`,
    # but `depends_kpkg:` addresses the `kpkg` sub-package it implements with
    # `package_kpkg {}`, so lint must not warn.
    let pkg = packageFixture(work / "repo", "src")
    writeFile(pkg / "run3", """name: "src"
version: "8.0.0"
release: "1"
description: "CLI fixture"
sources:
  - "src-tarball"
sha256sum:
  - "src-sum"
depends:
  - "libarchive"
depends_kpkg:
  - "bubblewrap"
depends_jumpstart:
  - "jimtcl"

package {
}

func build_kpkg {
  exec "true"
}

package_kpkg {
  exec "true"
}

func build_jumpstart {
  exec "true"
}

package_jumpstart {
  exec "true"
}
""")
    let response = expectExit(work, ["lint", "--path=" & pkg / "run3"], 0)
    check "No issues found" in response.output
    check "unknown architecture" notin response.output
    # The directory form must agree with the bare file form.
    let byDir = expectExit(work, ["lint", "--path=" & pkg], 0)
    check "unknown architecture" notin byDir.output

  test "lint still warns for a genuinely unknown single-token qualifier":
    # The sub-package allowances must not swallow a typo: `mips64` names no
    # architecture, package or sub-package of this recipe.
    let pkg = packageFixture(work / "repo", "src")
    writeFile(pkg / "run3", """name: "src"
version: "8.0.0"
release: "1"
description: "CLI fixture"
sources:
  - "src-tarball"
sha256sum:
  - "src-sum"
depends:
  - "libarchive"
depends_kpkg:
  - "bubblewrap"
depends_mips64:
  - "mips-dep"

package {
}

package_kpkg {
  exec "true"
}
""")
    let response = expectExit(work, ["lint", "--path=" & pkg / "run3"], 0)
    check "unknown architecture 'mips64' in depends_mips64" in response.output
    check "depends_kpkg" notin response.output
    check "1 warning(s)" in response.output

  test "lint rejects two checksum families in one source group":
    let pkg = packageFixture(work / "repo")
    writeFile(pkg / "run3", archRunfile & """
b2sum_aarch64:
  - "arm-b2"
""")
    let response = expectExit(work, ["lint", "--path=" & pkg / "run3"], 1)
    check "declares more than one checksum family" in response.output
    check "sha256sum_aarch64" in response.output
    check "b2sum_aarch64" in response.output

  test "fmt orders arch lists after their common counterpart and is idempotent":
    let pkg = packageFixture(work / "repo")
    let path = pkg / "run3"
    # Deliberately scrambled, and with the space-qualifier spelling that
    # `krep fmt` canonicalizes.
    writeFile(path, """
description: "CLI fixture"
backup:
  - "/etc/demo-conf"
sources_x86_64:
  - "x86-tarball"
sources:
  - "common-patch"
sha256sum_x86_64:
  - "x86-sum"
sha256sum:
  - "common-sum"
sources aarch64:
  - "arm-tarball"
sha256sum aarch64:
  - "arm-sum"
depends:
  - "glib"
depends_demo:
  - "subpkg-dep"
release: "1"
version: "1"
name: "demo"
""")
    discard expectExit(work, ["fmt", "--path=" & path], 0)
    let formatted = readFile(path)
    check formatted == """name: demo
version: 1
release: 1
description: "CLI fixture"
sources:
  - common-patch
sources_aarch64:
  - arm-tarball
sources_x86_64:
  - x86-tarball
sha256sum:
  - common-sum
sha256sum_aarch64:
  - arm-sum
sha256sum_x86_64:
  - x86-sum
depends:
  - glib
backup:
  - /etc/demo-conf
depends_demo:
  - subpkg-dep
"""
    # A second pass must not change a single byte.
    discard expectExit(work, ["fmt", "--path=" & path, "--check"], 0)
    discard expectExit(work, ["fmt", "--path=" & path], 0)
    check readFile(path) == formatted
    # The formatted recipe is still a valid per-architecture recipe.
    discard expectExit(work, ["lint", "--path=" & path], 0)

  test "fmt re-quotes an exec command, keeps the comments, and is stable":
    let pkg = packageFixture(work / "repo")
    let path = pkg / "run3"
    writeFile(path, """name: "demo"
version: "1.2.3"
release: "1"
description: "CLI fixture"
# one job: the sandbox has two cores and make oversubscribes them
build {
  exec "mkdir -p $ROOT/x && make -j1"
  print "built $version"
}
""")
    discard expectExit(work, ["fmt", "--path=" & path], 0)
    let formatted = readFile(path)
    # `exec` takes a quoted command; the AST holds it unquoted, so the writer
    # must put the quotes back or the rest of the command becomes statements.
    check "  exec \"mkdir -p $ROOT/x && make -j1\"\n" in formatted
    check "# one job: the sandbox has two cores and make oversubscribes them\n" in
      formatted
    # `print` keeps its literal: the runtime decodes it.
    check "  print \"built $version\"\n" in formatted
    # A second pass is a no-op, and the result is still a valid recipe.
    discard expectExit(work, ["fmt", "--path=" & path, "--check"], 0)
    check readFile(path) == formatted
    discard expectExit(work, ["lint", "--path=" & path], 0)

  test "convert rejects unsupported versions without changing input":
    let path = work / "run"
    let original = "NAME=demo\nVERSION=1.2.3\nRELEASE=1\n"
    writeFile(path, original)
    for versions in [(1, 3), (3, 2), (2, 2), (2, 4)]:
      let response = expectExit(work, ["convert", "--fromVer=" & $versions[0],
                                      "--toVer=" & $versions[1], "--path=" &
                                          path,
                                      "--inPlace"], 1)
      check "unsupported conversion" in response.output
      check readFile(path) == original
      check not fileExists(work / "run3")

  test "convert rejects conflicting write modes":
    let path = work / "run"
    writeFile(path, "NAME=demo\n")
    let response = expectExit(work, ["convert", "--fromVer=2", "--toVer=3",
                                    "--path=" & path, "--write", "--inPlace"], 1)
    check "cannot be used together" in response.output
    check readFile(path) == "NAME=demo\n"
    check not fileExists(work / "run3")

  test "matrix emits parseable JSON from run3 and fallback run fixtures":
    let repo = work / "repo"
    let demo = packageFixture(repo)
    # Both files in one directory must produce only one package entry.
    writeFile(demo / "run", canonicalRunfile)
    discard packageFixture(repo, "fallback", "run")
    let before = repositorySnapshot(repo)
    let output = work / "matrix output.json"
    discard expectExit(work, ["generate", "matrix", "--repo=" & repo,
                              "--output=" & output], 0)
    require fileExists(output)
    let matrix = parseFile(output)
    require matrix.kind == JObject
    require matrix.hasKey("include")
    require matrix["include"].kind == JArray
    var packages: seq[string]
    for entry in matrix["include"]:
      require entry.kind == JObject
      require entry.hasKey("packages")
      require entry["packages"].kind == JString
      packages.add(entry["packages"].getStr)
    packages.sort()
    check packages == @["demo", "fallback", "glibc", "musl"]
    check repositorySnapshot(repo) == before

  test "markdown generation writes package documentation":
    # A dependency-free package avoids host repository/database resolution.
    let pkg = packageFixture(work / "repo")
    let output = work / "package output.md"
    let before = repositorySnapshot(pkg)
    discard expectExit(work, ["generate", "markdown", "--pkgPath=" & pkg,
                              "--output=" & output], 0)
    require fileExists(output)
    let document = readFile(output)
    for text in ["title: demo", "CLI fixture", "1.2.3", "# Dependencies",
                 "No dependencies", "kpkg install demo", "kpkg build demo",
                 "# Dependency Graph", "```mermaid"]:
      check text in document
    check repositorySnapshot(pkg) == before

  test "manpage generation preserves body and adds website front matter":
    let input = work / "demo.1.md"
    let output = work / "manpage output.md"
    let source = "% DEMO(1)\n\n# NAME\ndemo - CLI fixture\n"
    writeFile(input, source)
    discard expectExit(work, ["generate", "manpage", "--file=" & input,
                              "--output=" & output], 0)
    require fileExists(output)
    check readFile(output) == "---\ntitle: \"DEMO(1)\"\ndraft: false\n---\n\n" &
                              "# NAME\ndemo - CLI fixture\n"
    check readFile(input) == source

  test "manpage generation rejects non-manpage input":
    let input = work / "not a manpage.md"
    let output = work / "must not exist.md"
    writeFile(input, "# Not a manpage\n")
    let response = expectExit(work, ["generate", "manpage", "--file=" & input,
                                    "--output=" & output], 1)
    check "is not a manpage" in response.output
    check not fileExists(output)
