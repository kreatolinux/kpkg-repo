## Live image overlays: `krep iso` stages exactly what its data directory names,
## and the bundled data directory names nothing. Live-medium policy (host name,
## live accounts, machine ID, getty and sshd rules) is package content, so
## staging a rootfs must leave an installed system's files alone.
import std/[os, tables, tempfiles, unittest]
import ../../krep/modules/bootconfig

const bundledData = currentSourcePath().parentDir / "../../krep/data/iso"

proc put(root, relative, content: string) =
  createDir(root / relative.parentDir)
  writeFile(root / relative, content)

proc link(root, relative, target: string) =
  createDir(root / relative.parentDir)
  createSymlink(target, root / relative)

proc fixture(base: string): string =
  ## A jumpstart rootfs skeleton, as kreato-fs-essentials leaves it.
  result = base / "rootfs"
  put(result, "sbin/init", "#!/bin/sh\n")
  setFilePermissions(result / "sbin/init", {fpUserRead, fpUserExec})
  put(result, "etc/passwd", "root:x:0:0:root:/root:/bin/sh\n")
  put(result, "etc/group", "root:x:0:\ntty:x:5:\n")
  put(result, "etc/shadow", "root:!locked:19000:0:99999:7:::\n")
  put(result, "etc/jumpstart/getty-tty1.kg", "service {\n  exec \"/bin/busybox getty\"\n}\n")
  link(result, "etc/jumpstart/enabled/getty-tty1.kg", "../getty-tty1.kg")

type Snapshot = Table[string, string]

proc snapshot(root: string): Snapshot =
  ## Every entry below root with its content (files) or target (links), so a
  ## staging run that changes anything at all shows up.
  var pending = @[""]
  while pending.len > 0:
    let relative = pending.pop()
    for kind, path in walkDir(root / relative):
      let child = if relative.len == 0: path.extractFilename
                  else: relative / path.extractFilename
      case kind
      of pcDir:
        result[child & "/"] = ""
        pending.add child
      of pcLinkToFile, pcLinkToDir: result[child] = "-> " & expandSymlink(path)
      of pcFile: result[child] = readFile(path) & " " & $getFilePermissions(path)

proc fragment(dir, name, manifest: string) =
  createDir(dir / "fragments" / name)
  writeFile(dir / "fragments" / name / "fragment.kg", manifest)

proc fragmentFile(dir, name, relative, content: string) =
  let path = dir / "fragments" / name / "overlay" / relative
  createDir(path.parentDir)
  writeFile(path, content)

suite "live overlay staging":
  setup:
    let work = createTempDir("krep-liveov-", "")
    let rootfs = fixture(work)
  teardown:
    removeDir(work)

  test "the bundled data directory carries no live policy":
    # An overlay that shipped accounts or a host name would also apply to an
    # installed system imaged by krep, and would shadow the packages that own
    # those files.
    check not dirExists(bundledData / "overlay")
    check not dirExists(bundledData / "overlays")
    check discoverFragments(bundledData).len == 0
    check fileExists(bundledData / "grub.cfg")
    check fileExists(bundledData / "grub-kickoff.cfg")

  test "staging with the bundled data changes nothing":
    let before = snapshot(rootfs)
    for initSystem in ["jumpstart", "systemd", "custom", ""]:
      check prepareLiveRootfs(rootfs, bundledData, initSystem,
          "/sbin/init").len == 0
      check snapshot(rootfs) == before
    check not fileExists(rootfs / "etc/hostname")
    check not fileExists(rootfs / "etc/machine-id")
    check not fileExists(rootfs / "etc/motd")
    check not fileExists(rootfs / "etc/jumpstart/live-accounts.kg")
    check not fileExists(rootfs / "etc/jumpstart/enabled/live-accounts.kg")
    check not dirExists(rootfs / "etc/systemd")
    check not dirExists(rootfs / "etc/sysusers.d")
    check not fileExists(rootfs / "etc/ssh/sshd_config.d/20-live.conf")
    check readFile(rootfs / "etc/shadow") == "root:!locked:19000:0:99999:7:::\n"

  test "a data directory without overlays is not an error":
    let data = work / "data-empty"
    createDir(data)
    check prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init").len == 0

  test "the shared overlay applies to every init, the init overlay only to its own":
    let data = work / "data-init"
    put(data, "overlay/etc/motd", "live\n")
    put(data, "overlays/systemd/etc/systemd/live.conf", "systemd only\n")
    put(data, "overlays/jumpstart/etc/hostname", "box\n")
    check prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init").len == 0
    check readFile(rootfs / "etc/motd") == "live\n"
    check readFile(rootfs / "etc/hostname") == "box\n"
    check not dirExists(rootfs / "etc/systemd")
    check prepareLiveRootfs(rootfs, data, "systemd", "/sbin/init").len == 0
    check fileExists(rootfs / "etc/systemd/live.conf")

  test "fragments are selected by the paths the rootfs has":
    let data = work / "data-select"
    fragment(data, "always", "description: \"unconditional\"\n")
    fragmentFile(data, "always", "etc/marker-always", "x")
    fragment(data, "needs-sshd", "description: \"needs sshd\"\nrequires:\n  - \"usr/sbin/sshd\"\n")
    fragmentFile(data, "needs-sshd", "etc/marker-sshd", "x")
    fragment(data, "needs-any", "description: \"one of\"\nrequires_any:\n  - \"usr/bin/true\"\n  - \"usr/bin/sshd\"\n")
    fragmentFile(data, "needs-any", "etc/marker-any", "x")
    fragment(data, "not-with-gdm", "description: \"excluded\"\nexcludes:\n  - \"usr/bin/gdm\"\n")
    fragmentFile(data, "not-with-gdm", "etc/marker-tty", "x")
    fragment(data, "other-init", "description: \"other init\"\ninit: \"systemd\"\n")
    fragmentFile(data, "other-init", "etc/marker-init", "x")

    var applied = prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init")
    check applied == @["always", "not-with-gdm"]
    check fileExists(rootfs / "etc/marker-always")
    check fileExists(rootfs / "etc/marker-tty")
    check not fileExists(rootfs / "etc/marker-sshd")
    check not fileExists(rootfs / "etc/marker-any")
    check not fileExists(rootfs / "etc/marker-init")

    # A fresh rootfs with sshd and GDM installed, /usr/sbin a link to bin as in
    # a usr-merged rootfs.
    let merged = fixture(work / "merged")
    link(merged, "usr/sbin", "bin")
    put(merged, "usr/bin/sshd", "#!/bin/sh\n")
    put(merged, "usr/bin/gdm", "#!/bin/sh\n")
    applied = prepareLiveRootfs(merged, data, "jumpstart", "/sbin/init")
    check applied == @["always", "needs-any", "needs-sshd"]
    check fileExists(merged / "etc/marker-sshd")
    check fileExists(merged / "etc/marker-any")
    check not fileExists(merged / "etc/marker-tty")

  test "host files never satisfy a condition":
    let data = work / "data-host"
    fragment(data, "needs-host-file", "description: \"host only\"\nrequires_any:\n  - \"usr/bin/true\"\n")
    fragmentFile(data, "needs-host-file", "etc/host-marker", "x")
    check prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init").len == 0
    check not fileExists(rootfs / "etc/host-marker")

  test "fragments are applied after the init overlay":
    let data = work / "data-order"
    put(data, "overlays/jumpstart/etc/jumpstart/getty-tty1.kg", "package\n")
    fragment(data, "override", "description: \"override\"\n")
    fragmentFile(data, "override", "etc/jumpstart/getty-tty1.kg", "live\n")
    let applied = prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init")
    check applied == @["override"]
    check readFile(rootfs / "etc/jumpstart/getty-tty1.kg") == "live\n"

  test "existing rootfs directory modes are not rewritten":
    # /etc/jumpstart/enabled is 0755 in a real rootfs; keep it whatever the
    # overlay's own mode is.
    setFilePermissions(rootfs / "etc/jumpstart/enabled",
      {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec})
    let data = work / "data-modes"
    put(data, "overlay/etc/jumpstart/enabled/extra.kg", "x")
    discard prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init")
    check getFilePermissions(rootfs / "etc/jumpstart/enabled") ==
      {fpUserRead, fpUserWrite, fpUserExec, fpGroupRead, fpGroupExec}
    # A directory the overlay creates keeps the overlay's own mode.
    put(data, "overlay/etc/fresh-dir/content", "x")
    setFilePermissions(data / "overlay/etc/fresh-dir", {fpUserRead, fpUserExec})
    discard prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init")
    check getFilePermissions(rootfs / "etc/fresh-dir") ==
      {fpUserRead, fpUserExec}

  test "macOS sidecar files in an overlay are ignored, not copied":
    let data = work / "data-junk"
    put(data, "overlay/etc/motd", "plain\n")
    writeFile(data / "overlay/etc/._motd", "junk")
    writeFile(data / "overlay/.DS_Store", "junk")
    fragment(data, "one", "description: \"one\"\n")
    put(data, "fragments/one/overlay/._etc", "junk")
    fragment(data, "two", "description: \"two\"\n")
    put(data, "fragments/two/overlay/._etc", "junk")
    # Both fragments would collide on ._etc if the sidecars were content.
    check prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init") ==
      @["one", "two"]
    check readFile(rootfs / "etc/motd") == "plain\n"
    check not fileExists(rootfs / "etc/._motd")
    check not fileExists(rootfs / "._etc")
    check not fileExists(rootfs / ".DS_Store")

  test "manifests reject unknown fields and unsafe condition paths":
    expect ValueError:
      discard parseFragmentManifest("description: \"x\"\nunknown: \"y\"\n", "t.kg")
    expect ValueError:
      discard parseFragmentManifest("init: \"jumpstart\"\n", "t.kg")
    for path in ["/etc/passwd", "../etc/passwd", "etc/../passwd", "etc/", "usr/*",
                 ""]:
      expect ValueError:
        discard parseFragmentManifest(
          "description: \"x\"\nrequires:\n  - \"" & path & "\"\n", "t.kg")
    expect ValueError:
      discard parseFragmentManifest("description: \"x\"\nrequires_any: []\n", "t.kg")
    # A commented-out list must not silently turn the fragment unconditional.
    expect ValueError:
      discard parseFragmentManifest(
        "description: \"x\"\nrequires:\n# - \"usr/bin/x\"\n", "t.kg")
    check parseFragmentManifest("description: \"x\"\ninit: \"a\"\n", "t.kg").init == "a"

  test "a fragment directory without a manifest is rejected":
    let data = work / "data-broken"
    createDir(data / "fragments/nameless")
    expect ValueError: discard discoverFragments(data)

  test "two fragments writing one path are rejected":
    let data = work / "data-collision"
    for name in ["first", "second"]:
      fragment(data, name, "description: \"" & name & "\"\n")
      fragmentFile(data, name, "etc/shared", name)
    expect ValueError: discard prepareLiveRootfs(rootfs, data, "jumpstart", "/sbin/init")

  test "collisions are detected after chroot resolution":
    # /etc is a link to /usr/etc here, so etc/x and usr/etc/x are one file.
    let linked = fixture(work / "linked")
    removeDir(linked / "etc")
    createDir(linked / "usr/etc")
    link(linked, "etc", "/usr/etc")
    let data = work / "data-linked"
    fragment(data, "first", "description: \"first\"\n")
    fragmentFile(data, "first", "etc/x", "first")
    fragment(data, "second", "description: \"second\"\n")
    fragmentFile(data, "second", "usr/etc/x", "second")
    expect ValueError: discard prepareLiveRootfs(linked, data, "jumpstart", "/sbin/init")
