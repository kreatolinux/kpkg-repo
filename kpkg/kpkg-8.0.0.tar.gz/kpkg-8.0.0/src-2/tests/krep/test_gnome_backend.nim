## GNOME backend tests. Every case runs against a recorded
## download.gnome.org cache.json fixture: no network access.
import std/[json, os, strutils, unittest, tempfiles]
import ../../kpkg/modules/run3/run3
import ../../krep/modules/backends/gnome
import ../../krep/modules/upstreamVersions

const fixtureDir = currentSourcePath().parentDir / "fixtures" / "gnome"

proc fixture(module: string): JsonNode =
  parseJson(readFile(fixtureDir / (module & ".cache.json")))

proc newest(module: string, stability: GnomeStability, series = ""): string =
  selectGnomeVersion(fixture(module), module, stability, series)

suite "gnome backend: stability rules":
  test "alpha, beta and rc components are never stable":
    for version in ["51.alpha", "51.beta", "51.rc", "51.alpha.1", "1.10.beta.1",
        "2.2.beta", "47.alpha", "1.2.0-rc1", "3.0.preview"]:
      check hasPrereleaseMarker(version)
      check not isStable(version, gsAny)
    for version in ["51.0", "51.1.1", "1.10.0", "2.2.6", "47.2", "0.21.8.2"]:
      check not hasPrereleaseMarker(version)

  test "historical 90-99 micro numbers are development releases":
    check hasPrereleaseMarker("2.61.90")
    check hasPrereleaseMarker("1.2.92")
    check not hasPrereleaseMarker("2.62.1")
    check not hasPrereleaseMarker("2.62.0.1")

  test "even-minor modules drop odd development series":
    check newest("glib", gsEvenMinor) == "2.90.1"
    check newest("at-spi2-core", gsEvenMinor) == "2.62.1"
    check newest("libsoup", gsEvenMinor, "3") == "3.8.1"
    # pango keeps the even/odd convention, but 1.90.0 is an even minor: only
    # the default series pin keeps the 1.58 line.
    check newest("pango", gsEvenMinor, "1.58") == "1.58.2"
    # 2.89.x is the development series leading to 2.90.
    check "2.89.4" notin selectGnomeVersion(fixture("glib"), "glib",
      gsEvenMinor)

  test "modules without the even/odd convention keep odd minors":
    check newest("librsvg", gsAny) == "2.63.4"
    check newest("gdm", gsAny) == "51.1.1"
    check newest("gnome-bluetooth", gsAny, "47") == "47.2"

  test "series pinning":
    check seriesMatches("4.24.1", "4")
    check not seriesMatches("3.24.43", "4")
    check seriesMatches("3.24.43", "3.24")
    check not seriesMatches("3.94.0", "3.24")
    check seriesMatches("51.1.1", "")
    check not seriesMatches("4", "4.24")
    check newest("gtk", gsEvenMinor, "4") == "4.24.1"
    # The gtk+ module holds 3.24.x next to the abandoned 3.9x GTK4 series.
    check newest("gtk", gsEvenMinor, "3.24") == ""

  test "gtk4 skips the unstable 4.25 series":
    check newest("gtk", gsEvenMinor, "4") == "4.24.1"
    check not isStable("4.25.0", gsEvenMinor, "4")
    check isStable("4.24.1", gsEvenMinor, "4")

  test "pango 1.90 is only reachable without the series pin":
    # 1.90 is the unstable series leading to Pango 2.0 (its own release notes
    # say so); the default pin keeps the 1.58 line.
    check newest("pango", gsAny, "1.58") == "1.58.2"
    check newest("pango", gsAny) == "1.90.0"
    check defaultSeriesFor("pango") == "1.58"

suite "gnome backend: cache.json handling":
  test "entries without a tarball are ignored":
    # librsvg's cache.json carries "2.7.0.tar.gz" as a stale directory key.
    check selectGnomeVersion(fixture("librsvg"), "librsvg", gsAny) == "2.63.4"
    check tarballPath(fixture("librsvg"), "librsvg", "2.7.0.tar.gz") == ""

  test "tarball URL comes from the cache entry":
    check tarballPath(fixture("gtk"), "gtk", "4.24.1") == "4.24/gtk-4.24.1.tar.xz"
    check tarballUrl(fixture("gtk"), "gtk", "4.24.1") ==
      "https://download.gnome.org/sources/gtk/4.24/gtk-4.24.1.tar.xz"
    # Old librsvg releases only exist as .tar.gz/.tar.bz2.
    check tarballPath(fixture("librsvg"), "librsvg", "2.9.5") ==
      "2.9/librsvg-2.9.5.tar.gz"
    check tarballUrl(fixture("librsvg"), "librsvg", "2.9.5") ==
      "https://download.gnome.org/sources/librsvg/2.9/librsvg-2.9.5.tar.gz"

  test "unknown module and malformed documents raise":
    expect ValueError:
      discard selectGnomeVersion(fixture("gtk"), "gtk4", gsAny)
    expect ValueError:
      discard selectGnomeVersion(parseJson("""{"gtk": {}}"""), "gtk", gsAny)
    check tarballUrl(parseJson("""[1, {}]"""), "gtk", "4.24.1") == ""

  test "empty result when nothing is stable in the series":
    check newest("gdm", gsAny, "49") == ""

suite "gnome backend: configuration":
  test "module names derive from both source URL shapes":
    check moduleFromSource(
      "https://download.gnome.org/sources/gtk/${version.split('.')[0:2].join('.')}/gtk-${version}.tar.xz") ==
      "gtk"
    check moduleFromSource(
      "https://gitlab.gnome.org/GNOME/librsvg/-/archive/${version}/librsvg-${version}.tar.gz") ==
      "librsvg"
    check moduleFromSource("gdm-dynamic-user.patch") == ""
    check moduleFromSource("https://github.com/foo/bar/archive/v1.tar.gz") == ""

  test "stability parsing and per-module defaults":
    check parseStability("") == gsAny
    check parseStability("even-minor") == gsEvenMinor
    check parseStability(" ODD ") == gsOddMinor
    expect ValueError:
      discard parseStability("sometimes")
    check stabilityFor("glib") == gsEvenMinor
    check stabilityFor("gtksourceview") == gsEvenMinor
    check stabilityFor("librsvg") == gsAny
    check stabilityFor("libadwaita") == gsAny
    check defaultSeriesFor("gtk") == "4"
    check defaultSeriesFor("gtk+") == "3.24"
    check defaultSeriesFor("libsoup") == "3"
    check defaultSeriesFor("librsvg") == ""
    check defaultSeriesFor("gnome-bluetooth") == "47"

  test "recipe module resolution prefers chkupd.cfg":
    let work = createTempDir("krep-gnome-module-", "")
    defer: removeDir(work)
    let packageDir = work / "gtk4"
    createDir(packageDir)
    writeFile(packageDir / "run3", """name: "gtk4"
version: "4.20.4"
release: "2"
sources:
 - "https://download.gnome.org/sources/gtk/${version.split('.')[0:2].join('.')}/gtk-${version}.tar.xz"
sha256sum:
 - "abc"
""")
    let recipe = parseRun3(packageDir)
    check recipeModule(recipe, "") == "gtk"
    check recipeModule(recipe, "gtk4") == "gtk4"

suite "gnome backend: version ordering":
  test "natural ordering across GNOME's mixed version shapes":
    check compareUpstreamVersions("51.1.1", "51.1") > 0
    check compareUpstreamVersions("0.21.8.2", "0.21.8") > 0
    check compareUpstreamVersions("2.62.0.1", "2.62.0") > 0
    check compareUpstreamVersions("2.63.4", "2.62.91") > 0

suite "gnome backend: tarball rewrite":
  test "the rewrite target keeps the source's archive format":
    # librsvg publishes .tar.xz on download.gnome.org, but the recipe fetches
    # the .tar.gz gitlab archive and unpacks it by name, so the backend must
    # not swap the container format.
    let url = tarballUrl(fixture("librsvg"), "librsvg", "2.63.4")
    check url.endsWith(".tar.xz")
    check "gitlab.gnome.org/GNOME/librsvg/-/archive/${version}/librsvg-${version}.tar.gz".
      splitFile.ext == ".gz"
    check url.splitFile.ext !=
      "https://gitlab.gnome.org/GNOME/librsvg/-/archive/${version}/librsvg-${version}.tar.gz".
      splitFile.ext
