## Tests for `krep fmt` (krep/commands/fmtcmd.nim).
##
## The writer works from the AST, which keeps values decoded (an `exec` command
## without its quotes, a list item without its quotes) and expressions as source.
## Everything it writes must read back as the same script and must be a fixed
## point, or a format pass quietly changes or destroys a recipe.
import std/[algorithm, sequtils, strutils, unittest]

import ../../krep/commands/fmtcmd
import ../../kongue/ast
import ../../kongue/lexer
import ../../kongue/parser

const tq = "\"\"\""

proc q(s: string): string =
  ## One value as a single comparable token.
  s.escape

proc canon(n: AstNode): string =
  ## Canonical text of one node: every field the writer must preserve.
  case n.kind
  of nkVariable:
    return "var " & getFullVarName(n) & " " & $n.varOp & " " & q(n.varValue) & "\n"
  of nkListVariable:
    return "list " & getFullVarName(n) & " " & $n.listOp & " " &
      n.listItems.mapIt(q(it)).join(" ") & "\n"
  of nkObject:
    result = "object " & n.objectName & "\n"
    for prop in n.objectProperties:
      result.add "  " & prop.key & " " & q(prop.value) & "\n"
  of nkFunction:
    result = "fn " & getFullFuncName(n) & "\n"
    for stmt in n.funcBody: result.add canon(stmt)
  of nkCustomFunc:
    result = "func " & n.customFuncName & "\n"
    for stmt in n.customFuncBody: result.add canon(stmt)
  of nkExec:
    return "exec " & q(n.execCmd) & "\n"
  of nkMacro:
    return "macro " & n.macroName & " " & n.macroArgs.mapIt(q(it)).join(" ") & "\n"
  of nkPrint:
    return "print " & q(n.printText) & "\n"
  of nkCd:
    return "cd " & q(n.cdPath) & "\n"
  of nkEnv:
    return "env " & n.envVar & " " & q(n.envValue) & "\n"
  of nkLocal:
    return "local " & n.localVar & " " & q(n.localValue) & "\n"
  of nkGlobal:
    return "global " & n.globalVar & " " & q(n.globalValue) & "\n"
  of nkWrite:
    return "write " & q(n.writePath) & " " & q(n.writeContent) & "\n"
  of nkAppend:
    return "append " & q(n.appendPath) & " " & q(n.appendContent) & "\n"
  of nkIf:
    result = "if " & q(n.condition) & "\n"
    for stmt in n.thenBranch: result.add canon(stmt)
    result.add "else\n"
    for stmt in n.elseBranch: result.add canon(stmt)
  of nkFor:
    result = "for " & n.iterVar & " in " & q(n.iterList) & " " &
      n.iterListLiteral.mapIt(q(it)).join(" ") & "\n"
    for stmt in n.forBody: result.add canon(stmt)
  of nkFuncCall:
    return "call " & n.callName & " " & n.callArgs.mapIt(q(it)).join(" ") & "\n"
  of nkContinue:
    return "continue\n"
  of nkBreak:
    return "break\n"
  else:
    return "other " & $n.kind & "\n"

proc canonScript(text: string): string =
  ## Canonical text of a whole script. Header fields are compared sorted,
  ## because formatting puts them in the canonical order.
  var p = initParser(tokenize(text))
  let parsed = p.parse()
  var variables: seq[string] = @[]
  for node in parsed.variables: variables.add canon(node)
  variables.sort()
  for variable in variables: result.add variable
  for node in parsed.customFuncs: result.add canon(node)
  for node in parsed.functions: result.add canon(node)

proc checkRoundTrip(source: string) =
  ## The formatted script reads back unchanged, and a second pass is a no-op.
  let formatted = formatRunfileText(source)
  check canonScript(formatted) == canonScript(source)
  check formatRunfileText(formatted) == formatted

suite "krep fmt: an exec command keeps its quoting":
  const spacedExec = "build {\n  exec \"mkdir -p $ROOT/x\"\n}\n"

  test "a multi-word command is written back as one string":
    # `execCmd` holds the command without its quotes, so writing it raw turned
    # `exec "mkdir -p $ROOT/x"` into `exec mkdir -p $ROOT/x`, which reads back
    # as one `mkdir` statement and a parse error.
    let formatted = formatRunfileText(spacedExec)
    check "exec \"mkdir -p $ROOT/x\"" in formatted
    checkRoundTrip(spacedExec)

  test "a one-word command stays bare":
    checkRoundTrip("build {\n  exec make\n}\n")
    check "exec make\n" in formatRunfileText("build {\n  exec make\n}\n")

  test "quotes and a literal dollar inside the command survive":
    let source = "build {\n  exec \"make CXXFLAGS=\\\"\\${CXXFLAGS} -g\\\"\"\n}\n"
    let formatted = formatRunfileText(source)
    check "\\$" in formatted
    checkRoundTrip(source)

  test "a command that is a keyword is quoted":
    # `exec print` would lex `print` as a statement keyword.
    let formatted = formatRunfileText("build {\n  exec \"print\"\n}\n")
    check "exec \"print\"" in formatted
    checkRoundTrip("build {\n  exec \"print\"\n}\n")

suite "krep fmt: values one token each":
  test "print keeps its literal for the runtime to decode":
    checkRoundTrip("build {\n  print \"$target\"\n}\n")

  test "a macro argument holding a space is quoted":
    let source = "build {\n  macro set name \"a b\"\n}\n"
    check "macro set name \"a b\"" in formatRunfileText(source)
    checkRoundTrip(source)

  test "an empty macro flag value stays empty":
    let source = "build {\n  macro build --with-root-prefix=\"\"\n}\n"
    check formatRunfileText(source) == "build {\n  macro build --with-root-prefix=\n}\n"

  test "for-list items that are not one word keep their quotes":
    # `[g++, certdata.txt]` reads back as `g`, `+`, `+`, `certdata`, `.txt`, so
    # an item that is not one bare word is always written quoted.
    let source = "build {\n  for i in [\"g++\", \"certdata.txt\", glib] {\n" &
      "    exec \"ln $i\"\n  }\n}\n"
    check "[\"g++\", \"certdata.txt\", glib]" in formatRunfileText(source)
    checkRoundTrip(source)

  test "a list item is read as the rest of its line, so it stays as written":
    let source = "sources:\n  - glib\n  - \"a-b_c\"\n  - \"/etc/demo.conf\"\n"
    check formatRunfileText(source) ==
      "sources:\n  - glib\n  - a-b_c\n  - /etc/demo.conf\n"

  test "a write path that is not one token is quoted":
    # The path is read as one token: `../ln` written bare stops parsing at the
    # dot, and `$ROOT/usr` would be read as `$ROOT` plus loose text.
    for path in ["../ln", "$ROOT/etc/pam.d/sudo", "a b"]:
      let source = "build {\n  write \"" & path & "\" \"x\"\n}\n"
      check "write \"" & path & "\"" in formatRunfileText(source)
      checkRoundTrip(source)
    checkRoundTrip("build {\n  write \"$ROOT/ln\" \"x\"\n}\n")
    check "write $ROOT " notin formatRunfileText(
      "build {\n  write \"$ROOT/ln\" \"x\"\n}\n")

  test "a for loop over a quoted expression keeps it":
    let source = "build {\n  for unit in \"${exec(\"ls\").output()}\" {\n" &
      "    exec \"echo $unit\"\n  }\n}\n"
    checkRoundTrip(source)

  test "a triple-quoted write body round-trips":
    let source = "build {\n  write \"$ROOT/a.txt\" " & tq & "\nline 1\nline 2\n" &
      tq & "\n}\n"
    checkRoundTrip(source)
    checkRoundTrip(formatRunfileText(source))

suite "krep fmt: name spellings":
  test "a space-qualified header key is written with an underscore":
    let source = "sources aarch64:\n  - arm\nsources:\n  - common\n"
    check formatRunfileText(source) ==
      "sources:\n  - common\nsources_aarch64:\n  - arm\n"
    checkRoundTrip(source)

  test "a space-qualified function head is written with an underscore":
    let source = "build test2 {\n  exec make\n}\n"
    check formatRunfileText(source) == "build_test2 {\n  exec make\n}\n"
    checkRoundTrip(source)

  test "an object declaration keeps its name and properties":
    let source = "object demo {\n  a: 1\n  b: two words\n}\n"
    checkRoundTrip(source)
    check "object demo {" in formatRunfileText(source)

suite "krep fmt: comments":
  test "a comment above a field travels with that field":
    let source = "# the patch list\nsources:\n  - patch\n"
    check formatRunfileText(source) == source

  test "a comment inside a body keeps its indentation":
    let source = "build {\n  # sandbox has no network\n  exec \"make\"\n}\n"
    check formatRunfileText(source) == "build {\n  # sandbox has no network\n" &
      "  exec make\n}\n"

  test "a trailing comment moves above its statement":
    let source = "build {\n  exec make # one job\n}\n"
    check "  # one job\n  exec make\n" in formatRunfileText(source)

  test "a comment the sorted header moves stays with its field":
    let source = "sources:\n  - a.patch\n# the build needs gmake\nbuild_depends:\n  - gmake\nname: demo\n"
    let formatted = formatRunfileText(source)
    check "# the build needs gmake\nbuild_depends:" in formatted

  test "a comment at the end of the file is kept":
    check formatRunfileText("name: demo\n# nothing below\n").endsWith(
      "# nothing below\n")
