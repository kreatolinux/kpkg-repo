## Per-architecture source groups in the krep run3 autoupdater.
##
## Every group (`sources:` and each `sources_<arch>:`) is re-fetched with the
## new version substituted and its own checksum list rewritten in place.
import std/[os, strutils, tempfiles, unittest]
import ../../kpkg/modules/run3/run3
import ../../kpkg/modules/sourcegroups
import ../../kpkg/modules/checksums
import ../../krep/modules/autoupdater

proc makePackage(root, body: string): string =
  result = root / "package"
  createDir(result)
  writeFile(result / "run3", body)

proc sumOf(body: string): string =
  ## The checksum the autoupdater must compute for a fetcher that writes
  ## `body` to the destination file.
  let scratch = createTempDir("krep-sum-", "")
  defer: removeDir(scratch)
  writeFile(scratch / "body", body)
  getSum(scratch / "body", "sha256")

type FetchLog = ref object
  ## URLs the offline fetcher was asked for, in call order. A ref keeps the
  ## closure safe to capture.
  urls: seq[string]

proc urlFetcher(log: FetchLog): SourceFetcher =
  ## Offline fetcher: records the URL and writes it as the body, so the
  ## resulting checksum is deterministic and per-URL unique.
  result = proc(source, destination: string) =
    log.urls.add(source)
    writeFile(destination, source)

proc groupFor(parsed: ParsedScript, arch: string): SourceGroup =
  for group in sourceGroups(parsed):
    if group.arch == arch: return group
  raise newException(ValueError, "no source group for arch '" & arch & "'")

suite "krep autoupdater: per-architecture source groups":
  setup:
    let work = createTempDir("krep autoupdater arch-", "")
  teardown:
    removeDir(work)

  test "each group is re-fetched and its own list updated in place":
    let packageDir = makePackage(work, """name: multiarch
version: "1.0"
release: "1"
sources:
  - "local.patch"
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "patch-sum"
  - "common-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
sources_x86_64:
  - "https://example.invalid/${version}-amd64.tar.gz"
sha256sum_x86_64:
  - "amd-old-sum"
""")
    writeFile(packageDir / "local.patch", "patch")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log))

    check log.urls == @[
      "https://example.invalid/2.0-common.tar.gz",
      "https://example.invalid/2.0-arm64.tar.gz",
      "https://example.invalid/2.0-amd64.tar.gz"]

    let updated = parseRun3(packageDir)
    check updated.getVersion() == "2.0"
    let common = groupFor(updated.parsed, "")
    check common.sources == @["local.patch",
      "https://example.invalid/${version}-common.tar.gz"]
    check common.sha256sum == @["patch-sum",
      sumOf("https://example.invalid/2.0-common.tar.gz")]
    let arm = groupFor(updated.parsed, "aarch64")
    check arm.sha256sum == @[sumOf("https://example.invalid/2.0-arm64.tar.gz")]
    let amd = groupFor(updated.parsed, "x86_64")
    check amd.sha256sum == @[sumOf("https://example.invalid/2.0-amd64.tar.gz")]

    # The templated URLs are kept verbatim; the new version flows through
    # ${version} at build time.
    let bytes = readFile(packageDir / "run3")
    check bytes.contains("${version}-arm64.tar.gz")
    check bytes.endsWith("\n")
    check not bytes.endsWith("\n\n")

  test "SKIP and local entries inside an arch group are left alone":
    let packageDir = makePackage(work, """name: archskip
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "common-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
  - "arm-local.patch"
  - "https://example.invalid/${version}-arm64-extra.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
  - "arm-patch-sum"
  - "SKIP"
""")
    writeFile(packageDir / "arm-local.patch", "patch")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log))
    check log.urls == @[
      "https://example.invalid/2.0-common.tar.gz",
      "https://example.invalid/2.0-arm64.tar.gz"]
    let updated = parseRun3(packageDir)
    let arm = groupFor(updated.parsed, "aarch64")
    check arm.sha256sum == @[sumOf("https://example.invalid/2.0-arm64.tar.gz"),
      "arm-patch-sum", "SKIP"]

  test "the space-qualifier spelling is rewritten on its own line":
    let packageDir = makePackage(work, """name: spaced
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "common-old-sum"
sources aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum aarch64:
  - "arm-old-sum"
""")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log))
    let bytes = readFile(packageDir / "run3")
    check bytes.contains("\nsources aarch64:")
    check bytes.contains("\nsha256sum aarch64:")
    check bytes.contains(sumOf("https://example.invalid/2.0-arm64.tar.gz"))
    check bytes.contains(sumOf("https://example.invalid/2.0-common.tar.gz"))
    let updated = parseRun3(packageDir)
    let arm = groupFor(updated.parsed, "aarch64")
    check arm.sourcesKey == "sources aarch64"
    check arm.sha256sumKey == "sha256sum aarch64"
    check arm.sha256sum == @[sumOf("https://example.invalid/2.0-arm64.tar.gz")]

  test "sha256sum and sha256sum_aarch64 are not confused":
    # Both lists hold the same old value; only the arch list may change, so a
    # rewriter that matched the common key would corrupt the local entry.
    let packageDir = makePackage(work, """name: samevalue
version: "1.0"
release: "1"
sources:
  - "local.patch"
sha256sum:
  - "same-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "same-old-sum"
""")
    writeFile(packageDir / "local.patch", "patch")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log))
    let updated = parseRun3(packageDir)
    check groupFor(updated.parsed, "").sha256sum == @["same-old-sum"]
    check groupFor(updated.parsed, "aarch64").sha256sum == @[
      sumOf("https://example.invalid/2.0-arm64.tar.gz")]

  test "an arch list declared before the common list is not confused":
    # The arch group comes first in the file and both lists hold the same old
    # value, so a rewriter that stops at the first `sha256sum` prefix match
    # would put the local patch's old sum into the arch list.
    let packageDir = makePackage(work, """name: archfirst
version: "1.0"
release: "1"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "same-old-sum"
sources:
  - "local.patch"
sha256sum:
  - "same-old-sum"
""")
    writeFile(packageDir / "local.patch", "patch")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log))
    check log.urls == @["https://example.invalid/2.0-arm64.tar.gz"]
    let updated = parseRun3(packageDir)
    check groupFor(updated.parsed, "").sha256sum == @["same-old-sum"]
    check groupFor(updated.parsed, "aarch64").sha256sum == @[
      sumOf("https://example.invalid/2.0-arm64.tar.gz")]

  test "a common local patch stays untouched while the arch tarball is fetched":
    let packageDir = makePackage(work, """name: withpatch
version: "1.0"
release: "1"
sources:
  - "fix-build.patch"
sha256sum:
  - "patch-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
""")
    writeFile(packageDir / "fix-build.patch", "patch")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log))
    check log.urls == @["https://example.invalid/2.0-arm64.tar.gz"]
    let bytes = readFile(packageDir / "run3")
    check bytes.contains("  - \"fix-build.patch\"")
    check bytes.contains("  - \"patch-sum\"")
    check bytes.contains(sumOf("https://example.invalid/2.0-arm64.tar.gz"))

  test "a download failure in an arch group leaves the recipe byte-identical":
    let packageDir = makePackage(work, """name: archfail
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "common-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let failingFetcher: SourceFetcher = proc(source, destination: string) =
      if source.contains("arm64"):
        raise newException(IOError, "arm download failed")
      writeFile(destination, source)

    expect IOError:
      autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "",
        failingFetcher)
    check readFile(packageDir / "run3") == original

    # skipIfDownloadFails turns the same failure into a silent no-op.
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", true, "", failingFetcher)
    check readFile(packageDir / "run3") == original

  test "a hardcoded URL inside an arch group blocks the version bump":
    let packageDir = makePackage(work, """name: archpinned
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "common-old-sum"
sources_aarch64:
  - "https://example.invalid/prebuilt-0.9-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    var message = ""
    try:
      autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "",
        urlFetcher(log))
    except ValueError as error:
      message = error.msg
    check message.contains("sources_aarch64")
    check message.contains("hardcoded")
    check log.urls.len == 0
    check readFile(packageDir / "run3") == original

  test "a group with two checksum families is rejected":
    let packageDir = makePackage(work, """name: twofamilies
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "common-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
b2sum_aarch64:
  - "arm-old-b2"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    expect ValueError:
      autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "",
        urlFetcher(log))
    check readFile(packageDir / "run3") == original

  test "an arch group count mismatch is rejected before any download":
    let packageDir = makePackage(work, """name: armmismatch
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "common-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-one-arm64.tar.gz"
  - "https://example.invalid/${version}-two-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    expect ValueError:
      autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "",
        urlFetcher(log))
    check log.urls.len == 0
    check readFile(packageDir / "run3") == original

  test "a mixed-family recipe updates each group in its own family":
    let packageDir = makePackage(work, """name: mixedfamily
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-common.tar.gz"
sha256sum:
  - "common-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
b2sum_aarch64:
  - "arm-old-b2"
""")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log))
    let updated = parseRun3(packageDir)
    let arm = groupFor(updated.parsed, "aarch64")
    check arm.checksumFamily() == "b2"
    check arm.b2sum.len == 1
    check arm.b2sum[0] != "arm-old-b2"
    check arm.sha256sum.len == 0
    check groupFor(updated.parsed, "").sha256sum == @[
      sumOf("https://example.invalid/2.0-common.tar.gz")]

suite "krep autoupdater: SourceRewrite addresses the common list":
  setup:
    let work = createTempDir("krep autoupdater rewrite-", "")
  teardown:
    removeDir(work)

  test "an arch group does not shift the rewrite index":
    let packageDir = makePackage(work, """name: rewriteindex
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-one.tar.gz"
  - "https://example.invalid/${version}-two.tar.gz"
sha256sum:
  - "one-old-sum"
  - "two-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
""")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "", urlFetcher(log),
      SourceRewrite(index: 1, url: "https://example.invalid/2.0-two-rewritten.tar.gz"))
    check log.urls == @[
      "https://example.invalid/2.0-one.tar.gz",
      "https://example.invalid/2.0-two-rewritten.tar.gz",
      "https://example.invalid/2.0-arm64.tar.gz"]
    let bytes = readFile(packageDir / "run3")
    check bytes.contains("  - \"https://example.invalid/${version}-one.tar.gz\"")
    check bytes.contains(
      "  - \"https://example.invalid/2.0-two-rewritten.tar.gz\"")
    check bytes.contains("  - \"https://example.invalid/${version}-arm64.tar.gz\"")

  test "a rewrite index beyond the common list is out of range":
    # Two common entries plus one arch entry: index 2 is valid for the merged
    # build-time list but not for the common `sources:` list.
    let packageDir = makePackage(work, """name: rewriteoob
version: "1.0"
release: "1"
sources:
  - "https://example.invalid/${version}-one.tar.gz"
  - "https://example.invalid/${version}-two.tar.gz"
sha256sum:
  - "one-old-sum"
  - "two-old-sum"
sources_aarch64:
  - "https://example.invalid/${version}-arm64.tar.gz"
sha256sum_aarch64:
  - "arm-old-sum"
""")
    let original = readFile(packageDir / "run3")
    let recipe = parseRun3(packageDir)
    let log = FetchLog()
    expect ValueError:
      autoUpdaterWithFetcher(recipe, packageDir, "2.0", false, "",
        urlFetcher(log), SourceRewrite(index: 2,
          url: "https://example.invalid/x.tar.gz"))
    check readFile(packageDir / "run3") == original
