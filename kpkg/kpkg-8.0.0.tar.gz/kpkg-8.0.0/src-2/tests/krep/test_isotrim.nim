import std/[os, strutils, tempfiles, unittest, sequtils, algorithm]
import ../../krep/modules/isotrim
import ../../kpkg/modules/rootfs/types

const
  repoRoot = currentSourcePath().parentDir.parentDir.parentDir
  isoResources = repoRoot / "krep/data/iso"

proc policyText(extra: string): string =
  "schema_version: \"1\"\n" & extra

proc writeElf(path: string, etype: int, bigEndian = false, size = 96) =
  ## Minimal fake ELF header: magic, EI_CLASS=2 (64-bit), EI_DATA, e_type at 16.
  createDir(path.parentDir)
  var data = newString(size)
  data[0] = '\x7f'; data[1] = 'E'; data[2] = 'L'; data[3] = 'F'
  data[4] = '\x02'
  data[5] = (if bigEndian: '\x02' else: '\x01')
  data[6] = '\x01'
  if bigEndian:
    data[16] = '\x00'; data[17] = char(etype)
  else:
    data[16] = char(etype); data[17] = '\x00'
  writeFile(path, data)

proc writeText(path, content: string) =
  createDir(path.parentDir)
  writeFile(path, content)

# parsing

suite "parseTrimPolicy":
  test "valid policy":
    let p = parseTrimPolicy(policyText("""
remove:
  - "usr/include"
  - "**/*.a"
keep_locales:
  - "en"
  - "pt_BR"
locale_dirs:
  - "usr/share/locale"
strip_elf: "yes"
strip_exclude:
  - "usr/lib/keep/*.so"
firmware: "trim"
firmware_exclude:
  - "netronome"
squashfs_compression: "xz"
squashfs_block_size: "128K"
"""), "/x/custom.kg")
    check p.name == "custom"
    check p.remove == @["usr/include", "**/*.a"]
    check p.keepLocales == @["en", "pt_BR"]
    check p.localeDirs == @["usr/share/locale"]
    check p.stripElf
    check p.stripExclude == @["usr/lib/keep/*.so"]
    check p.firmware == fwTrim
    check p.firmwareExclude == @["netronome"]
    check p.squashfsCompression == "xz"
    check p.squashfsBlockSize == "128K"
    check p.squashfsCompressionLevel == ""
    check not p.isEmpty

  test "defaults give an empty policy":
    let p = parseTrimPolicy(policyText(""))
    check p.isEmpty
    check not p.stripElf
    check p.firmware == fwKeep
    check noTrim().isEmpty
    check noTrim().name == "none"

  test "unknown fields are rejected":
    expect DeclarativeKongueError:
      discard parseTrimPolicy(policyText("bogus: \"1\"\n"))
    expect DeclarativeKongueError:
      discard parseTrimPolicy(policyText("removes:\n  - \"usr/include\"\n"))

  test "unsupported schema_version":
    expect ValueError:
      discard parseTrimPolicy("schema_version: \"2\"\n")

  test "bad patterns are rejected":
    for bad in ["/abs", "../x", "a//b", "a/./b", "a/..", "trailing/", "."]:
      for key in ["remove", "strip_exclude", "firmware_exclude"]:
        expect ValueError:
          discard parseTrimPolicy(policyText(key & ":\n  - \"" & bad & "\"\n"))
      expect ValueError:
        discard parseTrimPolicy(policyText("keep_locales:\n  - \"en\"\n" &
            "locale_dirs:\n  - \"" & bad & "\"\n"))

  test "bad keep_locales entries are rejected":
    for bad in ["en/US", "..", "."]:
      expect ValueError:
        discard parseTrimPolicy(policyText("keep_locales:\n  - \"" & bad & "\"\n"))

  test "locale_dirs without keep_locales is rejected":
    expect ValueError:
      discard parseTrimPolicy(policyText("locale_dirs:\n  - \"usr/share/locale\"\n"))

  test "bad booleans and firmware modes are rejected":
    expect ValueError:
      discard parseTrimPolicy(policyText("strip_elf: \"maybe\"\n"))
    expect ValueError:
      discard parseTrimPolicy(policyText("firmware: \"some\"\n"))
    check parseFirmwareMode("KEEP") == fwKeep
    check parseFirmwareMode("") == fwKeep
    check parseFirmwareMode("Trim") == fwTrim

  test "bad squashfs settings are rejected":
    for bad in ["squashfs_compression: \"brotli\"",
                "squashfs_block_size: \"1G\"",
                "squashfs_block_size: \"M\"",
                "squashfs_block_size: \"-1M\"",
                "squashfs_compression: \"zstd\"\nsquashfs_compression_level: \"x9\"",
                "squashfs_compression: \"xz\"\nsquashfs_compression_level: \"9\"",
                "squashfs_compression: \"lz4\"\nsquashfs_compression_level: \"9\""]:
      expect ValueError:
        discard parseTrimPolicy(policyText(bad & "\n"))
    for good in ["squashfs_compression: \"gzip\"\nsquashfs_compression_level: \"9\"",
                 "squashfs_compression: \"lzo\"\nsquashfs_block_size: \"4096\"",
                 "squashfs_block_size: \"64k\""]:
      discard parseTrimPolicy(policyText(good & "\n"))

  test "shipped live.kg loads":
    let p = loadTrimPolicy(isoResources / "trim/live.kg")
    check p.name == "live"
    check p.stripElf
    check p.firmware == fwTrim
    check p.squashfsCompression == "zstd"
    check p.squashfsCompressionLevel == "19"
    check p.squashfsBlockSize == "1M"
    check "en" in p.keepLocales
    check "usr/include" in p.remove
    check "**/*.a" in p.remove
    check "netronome" in p.firmwareExclude

suite "resolveTrimPolicy":
  test "none and empty mean no trimming":
    check resolveTrimPolicy("none", isoResources).isEmpty
    check resolveTrimPolicy("", isoResources).isEmpty

  test "a bare name resolves under <resources>/trim":
    let p = resolveTrimPolicy("live", isoResources)
    check p.name == "live"
    check p.stripElf

  test "a path is used as-is":
    let dir = createTempDir("krep-trim-resolve-", "")
    defer: removeDir(dir)
    writeFile(dir / "mine.kg", policyText("strip_elf: \"true\"\n"))
    let p = resolveTrimPolicy(dir / "mine.kg", "/nonexistent")
    check p.name == "mine"
    check p.stripElf

  test "missing policies raise":
    expect ValueError:
      discard resolveTrimPolicy("does-not-exist", isoResources)
    expect ValueError:
      discard resolveTrimPolicy("/nonexistent/policy.kg", isoResources)

# matching

suite "matchGlob":
  test "**/*.a matches at any depth":
    check matchGlob("**/*.a", "a.a")
    check matchGlob("**/*.a", "usr/lib/x/y.a")
    check matchGlob("**/*.a", "usr/lib/libc.a")
    check not matchGlob("**/*.a", "usr/lib/libc.so")
    check not matchGlob("**/*.a", "usr/lib/libjs_static.ajs")

  test "* stays within one component":
    check matchGlob("usr/lib/*/include", "usr/lib/glib-2.0/include")
    check not matchGlob("usr/lib/*/include", "usr/lib/clang/21/include")
    check not matchGlob("usr/lib/*/include", "usr/lib/include")
    check not matchGlob("usr/lib/*/include", "usr/lib/glib-2.0/include/x.h")
    check matchGlob("usr/lib/python3*/test", "usr/lib/python3.13/test")
    check matchGlob("ql2*_fw.bin", "ql2500_fw.bin")
    check matchGlob("usr/lib/?ib", "usr/lib/lib")
    check matchGlob("usr/[a-z]*", "usr/share")

  test "** semantics":
    check matchGlob("**", "anything/at/all")
    check matchGlob("**", "x")
    check matchGlob("**/x", "x")
    check matchGlob("**/x", "a/b/c/x")
    check not matchGlob("**/x", "a/b/c/xy")
    check matchGlob("a/**/b", "a/b")
    check matchGlob("a/**/b", "a/x/y/b")
    check not matchGlob("a/**/b", "a/x/y/c")
    check matchGlob("a/**", "a/x/y")
    check not matchGlob("a/**", "b/x")

  test "exact patterns match only the exact path":
    check matchGlob("usr/include", "usr/include")
    check not matchGlob("usr/include", "usr/include/stdio.h")
    check not matchGlob("usr/include", "usr")

  test "matchAny":
    check matchAny(["usr/include", "**/*.la"], "usr/lib/libz.la")
    check matchAny(["usr/include", "**/*.la"], "usr/include")
    check not matchAny(["usr/include", "**/*.la"], "usr/lib/libz.so")
    check not matchAny(newSeq[string](), "usr")

suite "localeKept":
  test "language prefixes":
    for kept in ["en", "en_US", "en@quot", "en_GB.UTF-8", "en.UTF-8"]:
      check localeKept(kept, ["en"])
    for dropped in ["eo", "enx", "de", "e", "EN"]:
      check not localeKept(dropped, ["en"])

  test "C and POSIX are always kept":
    for kept in ["C", "POSIX", "C.UTF-8"]:
      check localeKept(kept, newSeq[string]())

  test "region-specific codes":
    check localeKept("pt_BR", ["pt_BR"])
    check localeKept("pt_BR.UTF-8", ["pt_BR"])
    check not localeKept("pt", ["pt_BR"])
    check not localeKept("pt_PT", ["pt_BR"])

suite "squashfsArgs":
  test "argument construction":
    check squashfsArgs("zstd", "1M", "19") ==
        @["-comp", "zstd", "-b", "1M", "-Xcompression-level", "19"]
    check squashfsArgs("xz", "", "") == @["-comp", "xz"]
    check squashfsArgs("", "128K", "") == @["-b", "128K"]
    check squashfsArgs("", "", "").len == 0

  test "invalid settings raise":
    expect ValueError: discard squashfsArgs("brotli", "", "")
    expect ValueError: discard squashfsArgs("zstd", "1MB", "")
    expect ValueError: discard squashfsArgs("xz", "", "6")
    expect ValueError: discard squashfsArgs("zstd", "", "high")

# applyTrim

const fixturePolicy = """
schema_version: "1"
remove:
  - "usr/include"
  - "usr/lib/*/include"
  - "**/*.a"
  - "usr/share/doc"
  - "usr/share/outside-link"
keep_locales:
  - "en"
locale_dirs:
  - "usr/share/locale"
strip_elf: "true"
strip_exclude:
  - "usr/lib/keepme.so"
firmware: "trim"
firmware_exclude:
  - "netronome"
  - "ql2*_fw.bin"
"""

type StripCall = tuple[exe: string, args: seq[string]]

proc buildFixture(base: string): string =
  ## Returns the rootfs path. `base/outside` lives next to the rootfs and must
  ## never be modified.
  let r = base / "rootfs"
  let outside = base / "outside"
  writeText(outside / "keep.txt", "outside data")
  writeElf(outside / "outside.so", 3)
  writeText(outside / "real.a", "outside archive")
  # Pattern removal.
  writeText(r / "usr/include/stdio.h", "header")
  writeText(r / "usr/lib/glib-2.0/include/glibconfig.h", "header")
  writeText(r / "usr/lib/clang/21/include/stddef.h", "header")
  writeText(r / "usr/lib/libfoo.a", "archive")
  writeText(r / "usr/lib/x/y/libbar.a", "archive")
  writeText(r / "usr/share/doc/pkg/README", "docs")
  writeText(r / "usr/share/keep.txt", "kept")
  createSymlink(outside, r / "usr/share/outside-link")     # matched, to dir
  createSymlink(outside / "real.a", r / "usr/lib/link.a")  # matched, to file
  createSymlink(outside, r / "usr/lib/extlink")            # unmatched, to dir
  # Locales.
  let loc = r / "usr/share/locale"
  for name in ["en", "en_US", "en@quot", "en_GB.UTF-8", "eo", "de", "fr",
               "C.UTF-8"]:
    writeText(loc / name / "LC_MESSAGES/x.mo", name)
  writeText(loc / "locale.alias", "alias")
  # Firmware.
  let fw = r / "usr/lib/firmware"
  writeText(fw / "netronome/nic.bin", "nfp")
  writeText(fw / "ql2500_fw.bin", "qlogic")
  writeElf(fw / "amdgpu/gsp.bin", 2)          # ELF firmware: never stripped
  createSymlink("netronome/nic.bin", fw / "nfp.bin")      # becomes dangling
  createSymlink("../firmware/netronome", fw / "amdgpu/nfp-dir") # dangling dir
  createSymlink("amdgpu/gsp.bin", fw / "gsp-link.bin")    # stays valid
  createSymlink("/nonexistent/abs.bin", fw / "abs.bin")   # absolute: kept
  # ELF files.
  writeElf(r / "boot/vmlinux", 2)
  writeElf(r / "usr/bin/prog", 2)
  createHardlink(r / "usr/bin/prog", r / "usr/bin/prog-hl")
  writeElf(r / "usr/lib/libx.so.1", 3)
  writeElf(r / "usr/lib/libbe.so", 3, bigEndian = true)
  writeElf(r / "usr/lib/keepme.so", 3)
  writeElf(r / "usr/lib/modules/6.1/kernel/m.ko", 1)
  writeElf(r / "usr/lib/modules/6.1/build/vmlinux", 2)
  writeElf(r / "usr/lib/crt1.o", 1)
  writeElf(r / "usr/lib/core", 4)             # ET_CORE: not stripped
  writeElf(r / "usr/bin/tiny", 2, size = 32)  # shorter than an ELF header
  writeText(r / "usr/bin/script", "#!/bin/sh\n" & repeat('#', 100) & "\n")
  setFilePermissions(r / "usr/bin/prog", {fpUserRead, fpUserWrite, fpUserExec,
      fpGroupRead, fpGroupExec, fpOthersRead, fpOthersExec})
  result = r

proc fileArgs(call: StripCall): seq[string] =
  let sep = call.args.find("--")
  call.args[sep + 1 .. ^1]

suite "applyTrim":
  setup:
    let base = createTempDir("krep-trim-", "")
    let rootfs = buildFixture(base)
    let outside = base / "outside"
    var calls: seq[StripCall]
    var failStrip = false
    let fake: TrimRunner = proc(exe: string, args: seq[string]) =
      calls.add((exe, args))
      if failStrip: raise newException(IOError, "injected strip failure")
    let hostStrip = findExe("strip")
  teardown:
    removeDir(base)

  test "empty policy does nothing":
    let stats = applyTrim(rootfs, noTrim(), fake)
    check stats.removedEntries == 0
    check calls.len == 0
    check dirExists(rootfs / "usr/include")

  test "patterns, locales, firmware and strip":
    let policy = parseTrimPolicy(fixturePolicy, "fixture.kg")
    if hostStrip.len == 0:
      expect OSError:
        discard applyTrim(rootfs, policy, fake)
      skip()
    else:
      let stats = applyTrim(rootfs, policy, fake)
      # Pattern removal.
      check not dirExists(rootfs / "usr/include")
      check not dirExists(rootfs / "usr/lib/glib-2.0/include")
      check dirExists(rootfs / "usr/lib/glib-2.0")
      check fileExists(rootfs / "usr/lib/clang/21/include/stddef.h")
      check not fileExists(rootfs / "usr/lib/libfoo.a")
      check not fileExists(rootfs / "usr/lib/x/y/libbar.a")
      check dirExists(rootfs / "usr/lib/x/y")
      check not dirExists(rootfs / "usr/share/doc")
      check fileExists(rootfs / "usr/share/keep.txt")
      # Symlinks are removed, never followed.
      check not symlinkExists(rootfs / "usr/share/outside-link")
      check not symlinkExists(rootfs / "usr/lib/link.a")
      check symlinkExists(rootfs / "usr/lib/extlink")
      check readFile(outside / "keep.txt") == "outside data"
      check readFile(outside / "real.a") == "outside archive"
      check fileExists(outside / "outside.so")
      # Locales.
      let loc = rootfs / "usr/share/locale"
      for kept in ["en", "en_US", "en@quot", "en_GB.UTF-8", "C.UTF-8"]:
        check dirExists(loc / kept)
      for gone in ["eo", "de", "fr"]:
        check not dirExists(loc / gone)
      check readFile(loc / "locale.alias") == "alias"
      # Firmware.
      let fw = rootfs / "usr/lib/firmware"
      check not dirExists(fw / "netronome")
      check not fileExists(fw / "ql2500_fw.bin")
      check fileExists(fw / "amdgpu/gsp.bin")
      check not symlinkExists(fw / "nfp.bin")
      check not symlinkExists(fw / "amdgpu/nfp-dir")
      check symlinkExists(fw / "gsp-link.bin")
      check symlinkExists(fw / "abs.bin")
      # Strip: host tool, absolute paths, linked batch then relocatable batch.
      check calls.len == 2
      check calls.allIt(it.exe == hostStrip)
      check calls[0].args[0] == "--strip-unneeded"
      check calls[0].args[1 .. 2] == @["-p", "--"]
      check calls[1].args[0] == "--strip-debug"
      let linked = fileArgs(calls[0])
      let reloc = fileArgs(calls[1])
      check linked.allIt(it.isAbsolute and it.startsWith(rootfs & "/"))
      let progs = linked.filterIt(it.endsWith("/usr/bin/prog") or
          it.endsWith("/usr/bin/prog-hl"))
      check progs.len == 1                       # hard links stripped once
      check (rootfs / "usr/lib/libx.so.1") in linked
      check (rootfs / "usr/lib/libbe.so") in linked
      check linked.len == 3
      check reloc.sorted == @[rootfs / "usr/lib/crt1.o",
          rootfs / "usr/lib/modules/6.1/kernel/m.ko"].sorted
      for never in ["boot/vmlinux", "usr/lib/firmware/amdgpu/gsp.bin",
                    "usr/lib/keepme.so", "usr/lib/modules/6.1/build/vmlinux",
                    "usr/lib/core", "usr/bin/tiny", "usr/bin/script"]:
        check (rootfs / never) notin linked & reloc
      check not (linked & reloc).anyIt(it.startsWith(outside) or
          "extlink" in it)
      check stats.strippedFiles == 5
      check stats.removedEntries > 0
      check stats.removedBytes > 0
      # Mode bits survive.
      check fpOthersExec in getFilePermissions(rootfs / "usr/bin/prog")
      check "stripped 5 ELF files" in stats.summary

  test "firmware keep leaves firmware alone":
    let policy = parseTrimPolicy(fixturePolicy.replace(
        "firmware: \"trim\"", "firmware: \"keep\"").replace(
        "strip_elf: \"true\"", "strip_elf: \"false\""), "keep.kg")
    discard applyTrim(rootfs, policy, fake)
    let fw = rootfs / "usr/lib/firmware"
    check fileExists(fw / "netronome/nic.bin")
    check fileExists(fw / "ql2500_fw.bin")
    check symlinkExists(fw / "nfp.bin")
    check calls.len == 0
    check not dirExists(rootfs / "usr/include")   # other trimming still ran

  test "target strip refuses to run when its own libraries are unknown":
    # The chroot strip rewrites files in place, so stripping its own mapped
    # libc/libbfd would corrupt them. Without a working `ldd` in the rootfs
    # the closure cannot be listed and nothing may be stripped.
    writeText(rootfs / "usr/bin/strip", "#!/bin/sh\n")
    setFilePermissions(rootfs / "usr/bin/strip", {fpUserRead, fpUserExec})
    let policy = parseTrimPolicy(policyText("strip_elf: \"true\"\n"))
    if findExe("chroot").len == 0:
      skip()
    else:
      check stripTool(rootfs).inRoot
      expect OSError:
        discard applyTrim(rootfs, policy, fake)
      # Only the up-front `strip --version` probe ran; no file was touched.
      check calls.allIt("--version" in it.args)

  test "host strip is used without usr/bin/strip, OSError without any strip":
    let policy = parseTrimPolicy(policyText("strip_elf: \"true\"\n"))
    let tool = stripTool(rootfs)
    if hostStrip.len == 0:
      check tool.exe == ""
      expect OSError:
        discard applyTrim(rootfs, policy, fake)
    else:
      check tool == (hostStrip, newSeq[string](), false)
      discard applyTrim(rootfs, policy, fake)
      check calls.allIt(it.exe == hostStrip)
    # Without strip anywhere (empty PATH) the trim must refuse.
    let savedPath = getEnv("PATH")
    putEnv("PATH", base / "empty-path")
    try:
      check stripTool(rootfs).exe == ""
      expect OSError:
        discard applyTrim(rootfs, policy, fake)
    finally:
      putEnv("PATH", savedPath)

  test "strip errors in a batch are tolerated":
    if hostStrip.len == 0: skip()
    else:
      failStrip = true
      let stats = applyTrim(rootfs,
          parseTrimPolicy(policyText("strip_elf: \"true\"\n")), fake)
      check calls.len == 2
      check stats.strippedFiles == 6   # prog, libx, libbe, keepme, crt1.o, m.ko

  test "cancellation hook is called and can abort":
    var ticks = 0
    let policy = parseTrimPolicy(policyText("remove:\n  - \"usr/include\"\n"))
    discard applyTrim(rootfs, policy, fake, proc() = inc ticks)
    check ticks > 0
    expect IOError:
      discard applyTrim(rootfs, parseTrimPolicy(policyText(
          "remove:\n  - \"usr/share/doc\"\n")), fake,
          proc() = raise newException(IOError, "cancelled"))

  test "missing locale_dirs entries are skipped":
    let policy = parseTrimPolicy(policyText(
        "keep_locales:\n  - \"en\"\nlocale_dirs:\n  - \"usr/share/help\"\n" &
        "  - \"usr/share/locale\"\n"))
    discard applyTrim(rootfs, policy, fake)
    check not dirExists(rootfs / "usr/share/locale/de")

  test "a symlinked locale dir is not followed":
    let policy = parseTrimPolicy(policyText(
        "keep_locales:\n  - \"en\"\nlocale_dirs:\n  - \"usr/share/locale\"\n"))
    removeDir(rootfs / "usr/share/locale")
    createDir(outside / "locale/de")
    createSymlink(outside / "locale", rootfs / "usr/share/locale")
    discard applyTrim(rootfs, policy, fake)
    check dirExists(outside / "locale/de")

  test "a locale dir under a symlinked parent is not followed":
    let policy = parseTrimPolicy(policyText(
        "keep_locales:\n  - \"en\"\nlocale_dirs:\n  - \"usr/share/locale\"\n"))
    createDir(outside / "share/locale/de")
    removeDir(rootfs / "usr/share")
    createSymlink(outside / "share", rootfs / "usr/share")
    discard applyTrim(rootfs, policy, fake)
    check dirExists(outside / "share/locale/de")

  test "a symlinked firmware dir is not followed":
    let policy = parseTrimPolicy(policyText(
        "firmware: \"trim\"\nfirmware_exclude:\n  - \"netronome\"\n"))
    createDir(outside / "firmware/netronome")
    writeFile(outside / "firmware/netronome/nic.bin", "host firmware")
    removeDir(rootfs / "usr/lib/firmware")
    createSymlink(outside / "firmware", rootfs / "usr/lib/firmware")
    discard applyTrim(rootfs, policy, fake)
    check fileExists(outside / "firmware/netronome/nic.bin")

suite "policy guards":
  test "match-everything patterns and bad squashfs values are refused":
    for pattern in ["**", "*", "*/**", "?"]:
      expect ValueError:
        discard parseTrimPolicy("schema_version: \"1\"\nremove:\n  - \"" &
            pattern & "\"\n")
    for (comp, size, level) in [("zstd", "2M", ""), ("zstd", "100K", ""),
        ("zstd", "", "23"), ("zstd", "", "0"), ("gzip", "", "10"),
        ("xz", "", "5")]:
      expect ValueError:
        validateSquashfs(comp, size, level)
    validateSquashfs("", "", "9")      # gzip default accepts a level
    validateSquashfs("zstd", "1M", "19")
    validateSquashfs("gzip", "131072", "")
    check squashfsArgs("", "", "9") == @["-comp", "gzip",
        "-Xcompression-level", "9"]
