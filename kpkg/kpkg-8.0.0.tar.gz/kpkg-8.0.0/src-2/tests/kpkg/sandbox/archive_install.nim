## Integration tests for installing planned sandbox dependencies from their
## archives: the archive version must replace the stale root copy (bug: a
## dependency seeded from the host kept its old version) and must be visible to
## a root that has no copy at all (bug: --dontInstall dependencies).
import std/[os, tempfiles, unittest, tables, strutils, parsecfg, sequtils]
import ../../../kpkg/modules/builder/[sandbox, types]
import ../../../kpkg/modules/[sqlite, libarchive, checksums, commonPaths,
    processes, isolation]
import ../../../kpkg/commands/installcmd

proc writeSums(buildRoot: string) =
  ## pkgsums.ini in the transport format kpkg installs: one quoted path per
  ## line, directories without a checksum.
  var dict = newConfig()
  for file in toSeq(walkDirRec(buildRoot, {pcFile, pcLinkToFile, pcDir,
      pcLinkToDir})):
    let rel = relativePath(file, buildRoot)
    if rel == "pkgsums.ini" or rel == "pkgInfo.ini":
      continue
    if dirExists(file) or symlinkExists(file):
      dict.setSectionKey("", "\"" & rel & "\"", "")
    else:
      dict.setSectionKey("", "\"" & rel & "\"", getSum(file, "b2"))
  dict.writeConfig(buildRoot & "/pkgsums.ini")

proc writeInfo(buildRoot, version: string) =
  var dict = newConfig()
  dict.setSectionKey("", "pkgVer", version)
  dict.setSectionKey("", "apiVer", "8.0.0")
  dict.setSectionKey("", "depends", "")
  dict.writeConfig(buildRoot & "/pkgInfo.ini")

proc buildArchive(archivePath, version, payloadFile, extraFile: string) =
  ## Create a binary package archive whose only payload file carries `version`.
  let buildRoot = archivePath & ".d"
  removeDir(buildRoot)
  createDir(buildRoot & "/usr/share/sbxdep")
  writeFile(buildRoot & "/usr/share/sbxdep/version", version & "\n")
  if extraFile.len > 0:
    writeFile(buildRoot & "/usr/share/sbxdep/" & extraFile, "old\n")
  writeInfo(buildRoot, version)
  writeSums(buildRoot)
  createDir(parentDir(archivePath))
  createArchive(archivePath, buildRoot, format = "gnutar", filter = "gzip")
  removeDir(buildRoot)

proc writeRecipe(repoRoot, version: string) =
  createDir(repoRoot & "/sbxdep")
  writeFile(repoRoot & "/sbxdep/run3",
    "name: \"sbxdep\"\nversion: \"" & version &
    "\"\nrelease: \"1\"\ndescription: \"sandbox dependency fixture\"\n")

suite "sandbox dependency archive install":
  let fixture = createTempDir("kpkg-sandbox-archive-", "")
  let repo = fixture & "/repo"
  let archives = fixture & "/archives"
  let kTarget = "test-arch-linux-gnu"
  let v1 = archives & "/sbxdep-1.0-1.kpkg"
  let v2 = archives & "/sbxdep-2.0-1.kpkg"

  setup:
    if isAdmin() and not fileExists(v2):
      writeRecipe(repo, "1.0")
      buildArchive(v1, "1.0-1", "", "old-only")
      writeRecipe(repo, "2.0")
      buildArchive(v2, "2.0-1", "", "")

  teardown:
    closeDb()
    # installPkg stages its transaction outside the throwaway roots: drop the
    # journals, payload copies and backups this package left in the shared
    # locations so a suite run does not accumulate them.
    if dirExists(kpkgJournalDir):
      for kind, path in walkDir(kpkgJournalDir):
        if kind == pcFile and path.extractFilename.startsWith("sbxdep-"):
          removeFile(path)
    removeDir(kpkgTempDir1 & "/install-sbxdep")
    if dirExists(kpkgBackupDir):
      for kind, path in walkDir(kpkgBackupDir):
        if kind in {pcDir, pcLinkToDir} and
            path.extractFilename.startsWith("sbxdep-"):
          removeDir(path)
    # The installer may leave the process cwd inside a temp root.
    setCurrentDir("/")
    removeDir(fixture)

  test "installed stale version is upgraded from its archive":
    if not isAdmin():
      skip()
    else:
      let root = fixture & "/stale-root"
      let sandbox = fixture & "/stale-sandbox"
      for dir in [root, sandbox]:
        removeDir(dir)
        createDir(dir)
      # Install the old version into the build root the way a real root has it.
      installPkg(repo, "sbxdep", root, manualInstallList = @[],
          kTarget = kTarget, tarballPath = v1, version = "1.0-1",
          ignorePostInstall = true, deferPostInstall = true)
      check getPackage("sbxdep", root).version == "1.0-1"
      check fileExists(root & "/usr/share/sbxdep/old-only")

      # The sandbox side of the copy: payload plus package metadata, but no
      # file rows, exactly like installFromRoot() seeds the overlay.
      discard installFromRoot("sbxdep", root, sandbox)
      check packageExists("sbxdep", sandbox)
      check getListFiles("sbxdep", sandbox).len == 0
      check fileExists(sandbox & "/usr/share/sbxdep/old-only")

      let plan = @[SandboxArchiveDep(package: "sbxdep", version: "2.0-1",
          archive: v2)]
      let installed = applySandboxArchiveDeps(plan, sandbox, kTarget, "",
          proc(pkg: string): string = repo,
          proc(pkg: string): seq[string] =
            if packageExists(pkg, root): getListFiles(pkg, root) else: @[])
      check installed == @["sbxdep"]

      check readFile(sandbox & "/usr/share/sbxdep/version") == "2.0-1\n"
      check getPackage("sbxdep", sandbox).version == "2.0-1"
      # The superseded version must be gone, not accumulated next to the new
      # one: a plain extract would leave it behind.
      check not fileExists(sandbox & "/usr/share/sbxdep/old-only")

  test "a truncated archive keeps the copied dependency in place":
    if not isAdmin():
      skip()
    else:
      let root = fixture & "/truncated-root"
      let sandbox = fixture & "/truncated-sandbox"
      for dir in [root, sandbox]:
        removeDir(dir)
        createDir(dir)
      installPkg(repo, "sbxdep", root, manualInstallList = @[],
          kTarget = kTarget, tarballPath = v1, version = "1.0-1",
          ignorePostInstall = true, deferPostInstall = true)
      discard installFromRoot("sbxdep", root, sandbox)
      # A download that stopped halfway is not installable.
      let truncated = fixture & "/sbxdep-2.0-1.kpkg.partial"
      let content = readFile(v2)
      writeFile(truncated, content[0 ..< content.len div 2])
      let plan = @[SandboxArchiveDep(package: "sbxdep", version: "2.0-1",
          archive: truncated)]
      let installed = applySandboxArchiveDeps(plan, sandbox, kTarget, "",
          proc(pkg: string): string = repo,
          proc(pkg: string): seq[string] = getListFiles(pkg, root))
      check installed.len == 0
      # The old copy is the only one in the sandbox and must survive.
      check fileExists(sandbox & "/usr/share/sbxdep/version")
      check readFile(sandbox & "/usr/share/sbxdep/version") == "1.0-1\n"
      check getPackage("sbxdep", sandbox).version == "1.0-1"

  test "a file row escaping the sandbox removes nothing outside it":
    if not isAdmin():
      skip()
    else:
      let sandbox = fixture & "/escape-sandbox"
      removeDir(sandbox)
      createDir(sandbox & "/usr/share/sbxdep")
      writeFile(sandbox & "/usr/share/sbxdep/old-only", "old\n")
      let canary = fixture & "/canary"
      writeFile(canary, "keep\n")
      # The copied file list comes from the build root's database, so a `..`
      # or absolute entry must not reach outside the overlay.
      let plan = @[SandboxArchiveDep(package: "sbxdep", version: "2.0-1",
          archive: v2)]
      let installed = applySandboxArchiveDeps(plan, sandbox, kTarget, "",
          proc(pkg: string): string = repo,
          proc(pkg: string): seq[string] =
            @["../canary", "../../canary", canary, "..", ""])
      check installed == @["sbxdep"]
      check fileExists(canary)
      check readFile(canary) == "keep\n"

  test "a dependency installed nowhere is registered in the sandbox":
    # --dontInstall: the dependency exists only as an archive, and the
    # dependency metadata of the consumer requires it resolvable in the root.
    if not isAdmin():
      skip()
    else:
      let root = fixture & "/empty-root"
      removeDir(root)
      createDir(root)
      check not packageExists("sbxdep", root)

      let plan = @[SandboxArchiveDep(package: "sbxdep", version: "2.0-1",
          archive: v2)]
      discard applySandboxArchiveDeps(plan, root, kTarget, "",
          proc(pkg: string): string = repo)

      check packageExists("sbxdep", root)
      check readFile(root & "/usr/share/sbxdep/version") == "2.0-1\n"
