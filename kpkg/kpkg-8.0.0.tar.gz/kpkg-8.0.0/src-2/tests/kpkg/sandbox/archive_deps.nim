## Unit tests for the sandbox dependency planner: which dependencies are
## installed from their archives instead of being copied out of the build root.
import std/[tables, sequtils, unittest]
import ../../../kpkg/modules/builder/sandbox
import ../../../kpkg/modules/[dephandler, runparser]

type
  World = ref object
    installed: Table[string, string]
    recipes: Table[string, string]
    localArchives: Table[string, string]
    mirrorArchives: Table[string, string]
    fetched: seq[string]
    archiveLookups: seq[string]

proc key(pkg, version: string): string = pkg & "-" & version

proc fixture(): World =
  World(installed: initTable[string, string](),
    recipes: initTable[string, string](),
    localArchives: initTable[string, string](),
    mirrorArchives: initTable[string, string]())

proc plan(w: World, candidates: seq[string],
        includeStaleInstalled = true): seq[SandboxArchiveDep] =
  proc installedVersion(pkg: string): string =
    w.installed.getOrDefault(pkg, "")

  proc recipeVersion(pkg: string): string =
    w.recipes.getOrDefault(pkg, "")

  proc localArchive(pkg, version: string): string =
    w.archiveLookups.add(key(pkg, version))
    w.localArchives.getOrDefault(key(pkg, version), "")

  proc fetchArchive(pkg, version: string): string =
    w.fetched.add(key(pkg, version))
    w.mirrorArchives.getOrDefault(key(pkg, version), "")

  planSandboxArchiveDeps(candidates, installedVersion, recipeVersion,
    localArchive, fetchArchive, includeStaleInstalled)

suite "sandbox archive dependency plan":
  test "a dependency matching the recipe stays on the root copy":
    let w = fixture()
    w.installed["gtk4"] = "4.24.1-1"
    w.recipes["gtk4"] = "4.24.1-1"
    w.localArchives[key("gtk4", "4.24.1-1")] = "/archives/gtk4-4.24.1-1.kpkg"
    check w.plan(@["gtk4"]).len == 0
    check w.archiveLookups.len == 0

  test "a stale installed dependency is installed from its local archive":
    let w = fixture()
    w.installed["gtk4"] = "4.20.4-1"
    w.recipes["gtk4"] = "4.24.1-1"
    w.localArchives[key("gtk4", "4.24.1-1")] = "/archives/gtk4-4.24.1-1.kpkg"
    let deps = w.plan(@["gtk4"])
    check deps.len == 1
    check deps[0].package == "gtk4"
    check deps[0].version == "4.24.1-1"
    check deps[0].archive == "/archives/gtk4-4.24.1-1.kpkg"
    check w.fetched.len == 0

  test "a stale dependency without a local archive is fetched from the mirror":
    let w = fixture()
    w.installed["gtk4"] = "4.20.4-1"
    w.recipes["gtk4"] = "4.24.1-1"
    w.mirrorArchives[key("gtk4", "4.24.1-1")] = "/mirror/gtk4-4.24.1-1.kpkg"
    let deps = w.plan(@["gtk4"])
    check deps.len == 1
    check deps[0].archive == "/mirror/gtk4-4.24.1-1.kpkg"
    check w.fetched == @["gtk4-4.24.1-1"]

  test "a dependency ahead of its recipe is not downgraded":
    # Recipe 10.47-1, root 10.49-2: the root copy is the newer one, and
    # replacing it would remove libraries the root still provides.
    let w = fixture()
    w.installed["pcre"] = "10.49-2"
    w.recipes["pcre"] = "10.47-1"
    w.localArchives[key("pcre", "10.47-1")] = "/archives/pcre-10.47-1.kpkg"
    check w.plan(@["pcre"]).len == 0
    check w.archiveLookups.len == 0
    check w.fetched.len == 0

  test "a newer release of the same version is not downgraded":
    let w = fixture()
    w.installed["gtk4"] = "4.24.1-2"
    w.recipes["gtk4"] = "4.24.1-1"
    w.localArchives[key("gtk4", "4.24.1-1")] = "/archives/gtk4-4.24.1-1.kpkg"
    check w.plan(@["gtk4"]).len == 0

  test "a dependency installed nowhere comes from the local archive":
    # --dontInstall: the dependency was built earlier in this run and exists
    # only as a fresh archive.
    let w = fixture()
    w.recipes["liberation-fonts"] = "1.0.0-1"
    w.localArchives[key("liberation-fonts", "1.0.0-1")] =
        "/archives/liberation-fonts-1.0.0-1.kpkg"
    let deps = w.plan(@["liberation-fonts"])
    check deps.len == 1
    check deps[0].package == "liberation-fonts"
    check w.fetched.len == 0

  test "a dependency missing without a local archive is not fetched":
    # Nothing was built for it in this run, so the build order produces it
    # before this package; a mirror download would be unrelated work.
    let w = fixture()
    w.recipes["liberation-fonts"] = "1.0.0-1"
    w.mirrorArchives[key("liberation-fonts", "1.0.0-1")] = "/mirror/lib.kpkg"
    check w.plan(@["liberation-fonts"]).len == 0
    check w.fetched.len == 0

  test "a dependency without a recipe is left alone":
    let w = fixture()
    w.installed["local-thing"] = "1-1"
    w.localArchives[key("local-thing", "2-1")] = "/archives/local-thing-2-1.kpkg"
    check w.plan(@["local-thing"]).len == 0

  test "version constraints are stripped and repeats collapse":
    let w = fixture()
    w.installed["gtk4"] = "4.20.4-1"
    w.recipes["gtk4"] = "4.24.1-1"
    w.localArchives[key("gtk4", "4.24.1-1")] = "/archives/gtk4-4.24.1-1.kpkg"
    let deps = w.plan(@["gtk4>=4.23.1", "gtk4", "", "  "])
    check deps.len == 1
    check w.archiveLookups == @["gtk4-4.24.1-1"]

  test "a cross sandbox keeps installed dependencies and adds the missing ones":
    # On a cross target the host copy is the wrong architecture, so the normal
    # dependency install already takes every installed dependency from its
    # archive; only packages installed nowhere are left to add here.
    let w = fixture()
    w.installed["gtk4"] = "4.20.4-1"
    w.recipes["gtk4"] = "4.24.1-1"
    w.recipes["liberation-fonts"] = "1.0.0-1"
    w.localArchives[key("gtk4", "4.24.1-1")] = "/archives/gtk4-4.24.1-1.kpkg"
    w.localArchives[key("liberation-fonts", "1.0.0-1")] =
        "/archives/liberation-fonts-1.0.0-1.kpkg"
    let deps = w.plan(@["gtk4", "liberation-fonts"],
        includeStaleInstalled = false)
    check deps.mapIt(it.package) == @["liberation-fonts"]

suite "declared dependency closure":
  test "names lose their version constraints":
    check dependencyName("gtk4>=4.23.1") == "gtk4"
    check dependencyName("gtk4 <= 4.23.1") == "gtk4"
    check dependencyName("gtk4=4.24") == "gtk4"
    check dependencyName("gtk4") == "gtk4"
    check dependencyName("  gtk4  ") == "gtk4"
    check dependencyName("") == ""

  test "the closure is resolved through versioned dependencies":
    let metadata = {
      "app": runFile(bdeps: @["meson"], deps: @["libadwaita>=1.10"]),
      "libadwaita": runFile(deps: @["gtk4>=4.23.1"]),
      "gtk4": runFile(deps: @["libepoxy"]),
      "libepoxy": runFile(deps: @[]),
      "meson": runFile(deps: @["python"])
    }.toTable
    let deps = collectDynamicSandboxDeps("app",
      proc(pkg: string): runFile = metadata.getOrDefault(pkg, runFile()))
    check deps == @["meson", "libadwaita", "gtk4", "libepoxy"]
