## Test program for run3 module
## Uses unittest module for structured testing

import unittest
import os
import times
import strutils
import tables

import ../../../kpkg/modules/run3/run3
import ../../../kpkg/modules/telemetry/main
import ../../../kongue/utils

suite "run3 lexer":
  test "tokenizes basic input":
    let testInput = "name: \"test\"\n" &
                    "version: \"1.0\"\n" &
                    "build {\n" &
                    "    print \"Hello\"\n" &
                    "    write \"file.txt\" \"\"\"\n" &
                    "Multi-line\n" &
                    "String\n" &
                    "\"\"\"\n" &
                    "}\n"

    let tokens = tokenize(testInput)
    check tokens.len > 0
    # Verify first few tokens exist
    check tokens.len >= 10

suite "run3 parser":
  var testDir: string

  setup:
    testDir = "/tmp/test-run3-parser-" & $getTime().toUnix()
    createDir(testDir)

  teardown:
    removeDir(testDir)

  test "parses run3 file correctly":
    let testContent = """
name: "test-pkg"
version: "1.0.0"
release: "1"
description: "Test package"
sources:
        - "https://example.com/test.tar.gz"
depends:
        - "dep1"
        - "dep2"
sha256sum:
        - "abc123"

func helper {
        print "Helper function called"
}

build {
        print "Building package"
        exec "echo Test build"
        cd /tmp
}

package {
        print "Installing package"
}
"""
    writeFile(testDir / "run3", testContent)

    let rf = parseRun3(testDir)

    check rf.getName() == "test-pkg"
    check rf.getVersion() == "1.0.0"
    check rf.getRelease() == "1"
    check rf.getDescription() == "Test package"
    check rf.getSources().len == 1
    check rf.getSources()[0] == "https://example.com/test.tar.gz"
    check rf.getDepends().len == 2
    check "dep1" in rf.getDepends()
    check "dep2" in rf.getDepends()
    check rf.getVersionString() == "1.0.0-1"
    check rf.getAllFunctions().len > 0
    check "helper" in rf.getAllCustomFunctions()

suite "run3 telemetry":
  var telemetryTestDir: string

  setup:
    telemetryTestDir = "/tmp/test-run3-telemetry-" & $getTime().toUnix()
    createDir(telemetryTestDir)
    initializeTelemetry(TelemetrySettings(enabled: true,
      failurePolicy: telemetryContinue))

  teardown:
    shutdownTelemetry()
    removeDir(telemetryTestDir)

  test "execution records only package identity telemetry":
    writeFile(telemetryTestDir / "run3", """
name: "telemetry-package"
version: "1.2.3"
release: "1"

build {
  print "token=secret"
}
""")

    let runfile = parseRun3(telemetryTestDir)
    let parent = startSpan("kpkg.command")
    check runfile.executeFunction("build") == 0
    let span = lastCompletedSpanForTesting()
    check span.parentSpanId == parent.spanId
    endSpan(parent)

    check not span.isNil
    check span.name == "kpkg.run3.execute"
    check span.attributes["package.name"] == "telemetry-package"
    check span.attributes["package.version"] == "1.2.3-1"
    check "token=secret" notin $span.attributes

  test "nonzero execution result records an error span":
    writeFile(telemetryTestDir / "run3", """
name: "failing-package"
version: "1"
release: "1"

build { macro unsupported }
""")

    let runfile = parseRun3(telemetryTestDir)
    check runfile.executeFunction("build") != 0

    let span = lastCompletedSpanForTesting()
    check span.status == spanError
    check span.errorType == "ExecutionError"

suite "run3 variables":
  test "split method":
    let strVal = newStringValue("1.2.3")
    let splitResult = applyMethod(strVal, "split", @["."])
    check splitResult.toList() == @["1", "2", "3"]

  test "join method":
    let listVal = newListValue(@["a", "b", "c"])
    let joinResult = applyMethod(listVal, "join", @["-"])
    check joinResult.toString() == "a-b-c"

  test "cut method":
    let strVal = newStringValue("1.2.3")
    let cutResult = applyMethod(strVal, "cut", @["0", "3"])
    check cutResult.toString() == "1.2"

  test "replace method":
    let strVal = newStringValue("1.2.3")
    let replaceResult = applyMethod(strVal, "replace", @[".", "_"])
    check replaceResult.toString() == "1_2_3"

  test "indexing":
    let strVal = newStringValue("1.2.3")
    let splitResult = applyMethod(strVal, "split", @["."])
    let indexResult = applyIndex(splitResult, "0")
    check indexResult.toString() == "1"

  test "slicing":
    let strVal = newStringValue("1.2.3")
    let splitResult = applyMethod(strVal, "split", @["."])
    let sliceResult = applyIndex(splitResult, "0:2")
    check sliceResult.toList() == @["1", "2"]

suite "run3 builtins":
  test "variable set/get":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("test_var", "hello")
    check ctx.getVariable("test_var") == "hello"

  test "list variable":
    let ctx = initRun3Context()
    ctx.silent = true

    ctx.setListVariable("test_list", @["a", "b", "c"])
    check ctx.getListVariable("test_list") == @["a", "b", "c"]

  test "variable resolution":
    let ctx = initRun3Context()
    ctx.silent = true

    ctx.setVariable("name", "world")
    let resolved = ctx.resolveVariables("Hello $name and ${name}!")
    check resolved == "Hello world and world!"

  test "cd builtin":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    let originalDir = getCurrentDir()
    discard ctx.builtinCd("/tmp")
    check ctx.currentDir == "/tmp"
    setCurrentDir(originalDir)

  test "write builtin":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    let testFile = "test_write_unittest.txt"
    let writeContent = "Line 1"

    ctx.builtinWrite(testFile, writeContent)
    check readFile(ctx.currentDir / testFile) == writeContent

    removeFile(ctx.currentDir / testFile)

  test "append builtin":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    let testFile = "test_append_unittest.txt"
    let writeContent = "Line 1"
    let appendContent = "\nLine 2"

    ctx.builtinWrite(testFile, writeContent)
    ctx.builtinAppend(testFile, appendContent)
    check readFile(ctx.currentDir / testFile) == writeContent & appendContent

    removeFile(ctx.currentDir / testFile)

  test "write/append in a run3 stage keep multi-line content (regression)":
    # Triple-quoted write bodies must keep their newlines: writing them as one
    # line with literal backslash-n sequences corrupts the file.
    let dir = getTempDir() / "test-run3-write-" & $getCurrentProcessId()
    createDir(dir / "etc/polkit-1/rules.d")
    defer: removeDir(dir)
    let tq = "\"\"\""
    writeFile(dir / "run3", "name: \"t\"\nversion: \"1\"\nrelease: \"1\"\n\n" &
      "package {\n" &
      " write \"$ROOT/etc/polkit-1/rules.d/40-wheel.rules\" " & tq & "\n" &
      "polkit.addAdminRule(function(action, subject) {\n" &
      " return [\"unix-group:wheel\"];\n" &
      "});\n" & tq & "\n" &
      " append \"$ROOT/etc/polkit-1/rules.d/40-wheel.rules\" \"// $name\\n\"\n" &
      "}\n")
    let rf = parseRun3(dir)
    check rf.executeFunction("package", destDir = dir, buildRoot = dir) == 0
    check readFile(dir / "etc/polkit-1/rules.d/40-wheel.rules") ==
      "polkit.addAdminRule(function(action, subject) {\n" &
      " return [\"unix-group:wheel\"];\n" &
      "});\n" &
      "// t\n"

suite "run3 macros":
  test "macro argument parsing - internal args only":
    let ctx = initRun3Context()
    ctx.silent = true

    let args = parseMacroArgs(@["--meson", "--autocd=true",
        "--prefix=/usr/local"])
    check args.buildSystem == bsMeson
    check args.autocd == true
    check args.prefix == "/usr/local"
    check args.passthroughArgs == ""
    check args.sourceDir == "."

  test "macro argument parsing - mixed args":
    let args = parseMacroArgs(@["--ninja", "-Dplatforms=wayland,x11",
        "-Dgallium-drivers=auto", "--enable-foo", "install.prefix=/usr"])

    check args.buildSystem == bsNinja
    check "-Dplatforms=wayland,x11" in args.passthroughArgs
    check "-Dgallium-drivers=auto" in args.passthroughArgs
    check "--enable-foo" in args.passthroughArgs
    check "install.prefix=/usr" in args.passthroughArgs
    check "--ninja" notin args.passthroughArgs
    check args.sourceDir == "."

  test "macro argument parsing - set style args":
    let args = parseMacroArgs(@["--set", "install.prefix=/usr", "--set",
        "llvm.link-shared=true", "--llvm-config=/usr/bin/llvm-config"])

    check "--set" in args.passthroughArgs
    check "install.prefix=/usr" in args.passthroughArgs
    check "--llvm-config=/usr/bin/llvm-config" in args.passthroughArgs

  test "macro argument parsing - sourceDir with equals":
    let args = parseMacroArgs(@["--configure=.."])
    check args.buildSystem == bsAutotools
    check args.sourceDir == ".."

  test "macro argument parsing - sourceDir with space":
    let args = parseMacroArgs(@["--meson", ".."])
    check args.buildSystem == bsMeson
    check args.sourceDir == ".."

  test "macro argument parsing - sourceDir default":
    let args = parseMacroArgs(@["--cmake"])
    check args.buildSystem == bsCMake
    check args.sourceDir == "."

  test "macro argument parsing - sourceDir not consumed from flags":
    let args = parseMacroArgs(@["--configure", "--prefix=/opt"])
    check args.buildSystem == bsAutotools
    check args.sourceDir == "."
    check args.prefix == "/opt"

  test "macro argument parsing - sourceDir with extra args":
    let args = parseMacroArgs(@["--meson", "..", "-Dfoo=bar"])
    check args.buildSystem == bsMeson
    check args.sourceDir == ".."
    check "-Dfoo=bar" in args.passthroughArgs

suite "run3 macro hook: arguments are resolved in kongue context":
  ## `macro build --libdir=/usr/lib -Dadmin_group=wheel ${extraArgs}`
  ## (accountsservice) must not hand `-Dadmin_group=wheel${extraArgs}` to the
  ## macro, which the shell would expand to `-Dadmin_group=wheel-Delogind=true`.
  ## Each argument is resolved as Kongue text, so a reference becomes the value
  ## it holds and an undefined name disappears instead of reaching the build
  ## system as literal `${name}` (polkit).

  proc hookCtx(): Run3Context =
    result = initRun3Context()
    result.silent = true

  var seenArgs: seq[seq[string]] = @[]
  proc recordMacro(ctx: ExecutionContext, name: string,
                   args: seq[string]): int {.nimcall.} =
    ## Macro hook that records the resolved argument list instead of building.
    seenArgs.add(resolveMacroArgs(ctx, args))
    return 0

  var seenCommands: seq[string] = @[]
  proc recordExec2(ctx: ExecutionContext, command: string,
                   silent: bool): tuple[output: string, exitCode: int] {.nimcall.} =
    ## Exec hook that records the command line instead of running it.
    seenCommands.add(command)
    return ("", 0)

  proc capturedMacroArgs(script, stage: string,
                         setup: proc(ctx: Run3Context)): seq[seq[string]] =
    ## Run `stage` and return the argument list of every macro statement.
    var p = initParser(tokenize(script))
    let parsed = p.parse()
    let ctx = hookCtx()
    if setup != nil: setup(ctx)
    seenArgs = @[]
    ctx.macroHook = recordMacro
    # Conditions use `${exec(...)}`, which would otherwise reach kpkg's sandbox
    # runner; record instead of running.
    seenCommands = @[]
    ctx.execHook = recordExec2
    ctx.loadVariablesFromParsed(parsed)
    ctx.loadAllFunctions(parsed)
    check ctx.executeFunctionByName(parsed, stage) == 0
    seenArgs

  test "a defined variable becomes the flags it holds":
    let script = """
name: "pkg"
build {
  local extraArgs = "-Delogind=true -Dsystemdsystemunitdir=no"
  macro build --libdir=/usr/lib -Dadmin_group=wheel ${extraArgs}
}
"""
    let seen = capturedMacroArgs(script, "build", nil)
    check seen.len == 1
    check seen[0] == @["--libdir=/usr/lib", "-Dadmin_group=wheel",
                       "-Delogind=true -Dsystemdsystemunitdir=no"]

  test "an undefined variable leaves no argument behind (polkit)":
    # polkit sets extraArgs only when systemctl exists; its `if` is false on
    # this system, so `${extraArgs}` must vanish rather than stay literal.
    let script = """
name: "polkit"
build {
  if ${exec("command -v definitely-not-installed-xyz")}.exit() == 0 {
    local extraArgs = "-Dsession_tracking=libsystemd-login"
  }
  macro build --libdir=/usr/lib ${extraArgs}
}
"""
    let seen = capturedMacroArgs(script, "build", nil)
    check seen.len == 1
    check seen[0] == @["--libdir=/usr/lib"]

  test "a variable set in an earlier branch survives (libxcrypt)":
    let script = """
name: "libxcrypt"
func common_build {
  local prefix = "/usr"
  if "$1" != "${exec("uname -m").output()}-linux-gnu" {
    local prefix = "$prefix/$1"
    local extraArgs = "--target=$1 --host=$1"
  }
  macro build $extraArgs --enable-obsolete-api=yes --prefix=$prefix
}
build {
  common_build "aarch64-linux-gnu"
}
"""
    let seen = capturedMacroArgs(script, "build", nil)
    check seen.len == 1
    check seen[0] == @["--target=aarch64-linux-gnu --host=aarch64-linux-gnu",
                       "--enable-obsolete-api=yes", "--prefix=/usr/aarch64-linux-gnu"]

  test "kpkg variables resolve in macro arguments":
    let script = """
name: "libatasmart"
build {
  macro build --configure --build=$KPKG_TARGET
}
"""
    let seen = capturedMacroArgs(script, "build", proc(ctx: Run3Context) =
      ctx.envVars["KPKG_TARGET"] = "aarch64-linux-gnu")
    check seen.len == 1
    check seen[0] == @["--configure", "--build=aarch64-linux-gnu"]

  test "the resolved arguments reach the build command":
    let script = """
name: "pkg"
build {
  local extraArgs = "-Delogind=true"
  macro build --meson --libdir=/usr/lib ${extraArgs}
}
"""
    var p = initParser(tokenize(script))
    let parsed = p.parse()
    let ctx = hookCtx()
    seenCommands = @[]
    ctx.execHook = recordExec2
    ctx.loadVariablesFromParsed(parsed)
    ctx.loadAllFunctions(parsed)
    check ctx.executeFunctionByName(parsed, "build") == 0
    check seenCommands.len == 2
    check "meson setup build --prefix=/usr --default-library=both " &
      "--libdir=/usr/lib -Delogind=true" in seenCommands[0]
    check "meson compile -C build" in seenCommands[1]

suite "run3 exec: shell variables are left for the shell":
  ## kongue must leave shell variables in `exec` alone: resolving every $NAME
  ## (unknown names to "") turns `sh -c 'X=1 && echo "$X"'` into `echo ""`,
  ## loses the loop variable in `for f in ...; do ... $f`, and eats awk's `$1`.

  var lastCommand = ""
  proc recordExec(ctx: ExecutionContext, command: string,
                  silent: bool): tuple[output: string, exitCode: int] {.nimcall.} =
    lastCommand = command
    return ("", 0)

  proc execCommand(script: string): string =
    var p = initParser(tokenize(script))
    let parsed = p.parse()
    let ctx = initRun3Context()
    ctx.silent = true
    lastCommand = ""
    ctx.execHook = recordExec
    ctx.loadVariablesFromParsed(parsed)
    ctx.loadAllFunctions(parsed)
    check ctx.executeFunctionByName(parsed, "build") == 0
    lastCommand

  test "a shell variable assigned in the same command survives":
    let cmd = execCommand("name: \"p\"\nbuild {\n  exec \"sh -c 'X=1 && echo \\\"$X\\\"'\"\n}\n")
    check "sh -c 'X=1 && echo \"$X\"'" in cmd

  test "a shell loop variable survives":
    let cmd = execCommand("name: \"p\"\nbuild {\n  exec \"for f in a b; do echo $f; done\"\n}\n")
    check "for f in a b; do echo $f; done" in cmd

  test "awk's positional parameter survives":
    let cmd = execCommand("name: \"p\"\nbuild {\n  exec \"awk '{print $1}' file\"\n}\n")
    check "awk '{print $1}' file" in cmd

  test "the gptfdisk CXXFLAGS reference reaches the shell":
    let cmd = execCommand("name: \"p\"\nbuild {\n" &
      "  exec \"make CXXFLAGS=\\\"\\${CXXFLAGS} -D_FILE_OFFSET_BITS=64\\\"\"\n}\n")
    check "make CXXFLAGS=\"${CXXFLAGS} -D_FILE_OFFSET_BITS=64\"" in cmd

  test "recipe and kpkg variables still resolve":
    var p = initParser(tokenize("name: \"pkg\"\nversion: \"1.2\"\nbuild {\n" &
      "  local dest = \"$ROOT/usr/bin\"\n" &
      "  exec \"install -Dm755 x $dest/$version/thing $DESTDIR\"\n}\n"))
    let parsed = p.parse()
    let ctx = initRun3Context(destDir = "/DEST", buildRoot = "/ROOT")
    ctx.silent = true
    lastCommand = ""
    ctx.execHook = recordExec
    ctx.loadVariablesFromParsed(parsed)
    ctx.loadAllFunctions(parsed)
    check ctx.executeFunctionByName(parsed, "build") == 0
    check "install -Dm755 x /ROOT/usr/bin/1.2/thing /DEST" in lastCommand

  test "an escaped dollar reaches the shell as a literal":
    let cmd = execCommand("name: \"p\"\nbuild {\n  exec \"echo \\$EXAMPLE\"\n}\n")
    check "echo $EXAMPLE" in cmd

suite "run3 variable operations":
  var testDir: string

  setup:
    testDir = "/tmp/test-run3-ops-" & $getTime().toUnix()
    createDir(testDir)

  teardown:
    removeDir(testDir)

  test "list append and remove operators":
    let testContent = """
name: "test-pkg"
depends:
    - "dep1"
    - "dep2"

depends+:
    - "dep3"

depends-:
    - "dep1"

cflags: "-O2"
cflags+: "-g"
"""
    writeFile(testDir / "run3", testContent)

    let rf = parseRun3(testDir)
    let ctx = initRun3ContextFromParsed(rf.parsed)

    let depends = ctx.getListVariable("depends")
    check "dep3" in depends
    check "dep1" notin depends

    let cflags = ctx.getVariable("cflags")
    check cflags == "-O2 -g"

suite "run3 exec manipulation":
  test "exec output":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    let output = ctx.resolveVariables("Hello ${exec(\"echo world\").output()}!")
    check output == "Hello world!"

  test "exec exit code":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    let exitCode = ctx.resolveVariables("Exit code: ${exec(\"true\").exit()}")
    check exitCode == "Exit code: 0"

  test "exec chaining with strip":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    let output = ctx.resolveVariables("${exec(\"echo ' test '\").strip()}")
    check output == "test"

suite "run3 conditions":
  test "basic boolean true":
    let ctx = initRun3Context()
    ctx.silent = true

    ctx.setVariable("enabled", "true")
    check ctx.evaluateCondition("$enabled")

  test "basic boolean false":
    let ctx = initRun3Context()
    ctx.silent = true

    ctx.setVariable("disabled", "false")
    check not ctx.evaluateCondition("$disabled")

  test "equality check":
    let ctx = initRun3Context()
    ctx.silent = true

    ctx.setVariable("version", "1.0.0")
    check ctx.evaluateCondition("$version == \"1.0.0\"")

  test "inequality check":
    let ctx = initRun3Context()
    ctx.silent = true

    ctx.setVariable("name", "pkg")
    check ctx.evaluateCondition("$name != \"other\"")

suite "run3 condition operators":
  test "OR operator - first true":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("name", "grep")
    check ctx.evaluateCondition("\"$name\" == \"grep\" || \"$name\" == \"tar\"")

  test "OR operator - second true":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("name", "tar")
    check ctx.evaluateCondition("\"$name\" == \"grep\" || \"$name\" == \"tar\"")

  test "OR operator - both false":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("name", "other")
    check not ctx.evaluateCondition("\"$name\" == \"grep\" || \"$name\" == \"tar\"")

  test "AND operator - both true":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("debug", "true")
    ctx.setVariable("verbose", "true")
    check ctx.evaluateCondition("\"$debug\" == \"true\" && \"$verbose\" == \"true\"")

  test "AND operator - one false":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("debug", "true")
    ctx.setVariable("verbose", "false")
    check not ctx.evaluateCondition("\"$debug\" == \"true\" && \"$verbose\" == \"true\"")

  test "regex match operator - matches":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("name", "grep")
    check ctx.evaluateCondition("\"$name\" =~ e\"grep|tar|bzip2\"")

    ctx.setVariable("name", "tar")
    check ctx.evaluateCondition("\"$name\" =~ e\"grep|tar|bzip2\"")

  test "regex match operator - no match":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("name", "other")
    check not ctx.evaluateCondition("\"$name\" =~ e\"grep|tar|bzip2\"")

suite "run3 control flow":
  var testDir: string

  setup:
    testDir = "/tmp/test-run3-control-" & $getTime().toUnix()
    createDir(testDir)

  teardown:
    removeDir(testDir)

  test "continue and break":
    let testContent = """
name: "test-pkg"
version: "1.0.0"
release: "1"
description: "Test"
items:
    - "a"
    - "SKIP"
    - "b"
    - "STOP"
    - "c"
    - "d"
result: ""
count: "0"

package {
    for item in items {
        if "$item" == "SKIP" {
            continue
        }
        if "$item" == "STOP" {
            break
        }
        global result = "$result$item "
        print "Processing: $item"
    }
    print "Result: $result"
}
"""
    writeFile(testDir / "run3", testContent)

    let rf = parseRun3(testDir)
    let ctx = initRun3ContextFromParsed(rf.parsed)
    ctx.silent = false
    ctx.passthrough = true

    discard ctx.executeFunctionByName(rf.parsed, "package")

    let result = ctx.getVariable("result").strip()
    check result == "a b"

suite "run3 utils helpers":
  test "stripQuotes":
    check stripQuotes("\"hello\"") == "hello"
    check stripQuotes("'world'") == "world"
    check stripQuotes("noquotes") == "noquotes"
    check stripQuotes("\"\"") == ""
    check stripQuotes("''") == ""
    check stripQuotes("\"only start") == "\"only start"
    check stripQuotes("only end\"") == "only end\""

  test "extractBraceExpr":
    let (expr1, end1) = extractBraceExpr("${foo}", 0)
    check expr1 == "foo"
    check end1 == 6

    let (expr2, end2) = extractBraceExpr("prefix${bar}suffix", 6)
    check expr2 == "bar"
    check end2 == 12

    let (expr3, end3) = extractBraceExpr("${nested.method()}", 0)
    check expr3 == "nested.method()"
    check end3 == 18

    let (expr4, end4) = extractBraceExpr("nope", 0)
    check expr4 == ""
    check end4 == 0

  test "parseConditionOperator":
    let cp1 = parseConditionOperator("left == right")
    check cp1.valid
    check cp1.left == "left"
    check cp1.op == "=="
    check cp1.right == "right"

    let cp2 = parseConditionOperator("foo != bar")
    check cp2.valid
    check cp2.left == "foo"
    check cp2.op == "!="
    check cp2.right == "bar"

    let cp3 = parseConditionOperator("value =~ e\"pattern\"")
    check cp3.valid
    check cp3.left == "value"
    check cp3.op == "=~"
    check cp3.right == "e\"pattern\""

    let cp4 = parseConditionOperator("no operator here")
    check not cp4.valid

  test "stripPatternWrapper":
    check stripPatternWrapper("e\"pattern\"") == "pattern"
    check stripPatternWrapper("e'pattern'") == "pattern"
    check stripPatternWrapper("\"quoted\"") == "quoted"
    check stripPatternWrapper("'single'") == "single"
    check stripPatternWrapper("plain") == "plain"

  test "isTrueBoolean and isFalseBoolean":
    check isTrueBoolean("true")
    check isTrueBoolean("TRUE")
    check isTrueBoolean("1")
    check isTrueBoolean("yes")
    check isTrueBoolean("on")
    check not isTrueBoolean("false")
    check not isTrueBoolean("maybe")

    check isFalseBoolean("false")
    check isFalseBoolean("FALSE")
    check isFalseBoolean("0")
    check isFalseBoolean("no")
    check isFalseBoolean("off")
    check isFalseBoolean("")
    check not isFalseBoolean("true")
    check not isFalseBoolean("maybe")

  test "splitLogicalOr and splitLogicalAnd":
    let orParts = splitLogicalOr("a || b || c")
    check orParts == @["a", "b", "c"]

    let andParts = splitLogicalAnd("x && y && z")
    check andParts == @["x", "y", "z"]

    let single = splitLogicalOr("single")
    check single == @["single"]

  test "isSimpleVarName":
    check isSimpleVarName("foo")
    check isSimpleVarName("_bar")
    check isSimpleVarName("test123")
    check isSimpleVarName("my-var")
    check isSimpleVarName("my_var")
    check not isSimpleVarName("")
    check not isSimpleVarName("123abc")
    check not isSimpleVarName("has.dot")
    check not isSimpleVarName("has space")
    check not isSimpleVarName("has(paren)")

  test "findMatchingBrace":
    check findMatchingBrace("${foo}", 1) == 5
    check findMatchingBrace("${a{b}c}", 1) == 7
    check findMatchingBrace("${unclosed", 1) == -1

suite "run3 for loop":
  test "for loop with variable expression":
    let ctx = initRun3Context()
    ctx.silent = true
    ctx.passthrough = true

    ctx.setVariable("items", "apple\nbanana\ncherry")

    var collected: seq[string] = @[]
    let itemsStr = ctx.getVariable("items")
    let items = itemsStr.splitLines()

    for item in items:
      if item.strip().len > 0:
        collected.add(item)

    check collected == @["apple", "banana", "cherry"]

suite "run3 package metadata: the \\$ escape never reaches a package":
  ## The lexer stores a ``\\$`` written in a recipe string as kongue's
  ## escapedDollar marker (0x01) and ``resolveVariables`` turns it back into
  ## ``$``. The header accessors (``getVariable``/``getListVariable``)
  ## substitute with ``substituteVariablesWithTable``, which never calls
  ## ``resolveVariables``, so the marker must not survive into package
  ## metadata: a ``description: "costs \\$5"`` or an escaped ``$`` in a source
  ## URL would otherwise hold a literal 0x01 byte.
  proc leakDir(name: string): string =
    result = getTempDir() / ("test-run3-escape-" & name & "-" &
      $getCurrentProcessId())
    removeDir(result)
    createDir(result)

  test "a literal dollar in the description is a dollar":
    let dir = leakDir("desc")
    defer: removeDir(dir)
    writeFile(dir / "run3", "name: \"esc\"\nversion: \"1.0\"\n" &
      "release: \"1\"\ndescription: \"costs \\$5 for \\$name\"\n\n" &
      "build {\n  exec \"true\"\n}\n")
    let rf = parseRun3(dir)
    check rf.getDescription() == "costs $5 for $name"

  test "a literal dollar in a source URL is a dollar":
    let dir = leakDir("src")
    defer: removeDir(dir)
    writeFile(dir / "run3", "name: \"esc\"\nversion: \"2.1\"\nrelease: \"1\"\n" &
      "sources:\n - \"https://example.org/${version}-\\$literal.tar.xz\"\n\n" &
      "build {\n  exec \"true\"\n}\n")
    let rf = parseRun3(dir)
    # ${version} still interpolates; only the escaped dollar is literal.
    check rf.getSources() == @["https://example.org/2.1-$literal.tar.xz"]

  test "the escape marker never reaches the autoupdater or the raw accessors":
    # getSourcesRaw/getSourcesWithVersion feed krep's autoupdater, and
    # getAllVariables feeds runparser's optdepends. They bypass
    # substituteVariables, so they must restore \$ themselves: a 0x01 byte
    # breaks a download URL.
    let dir = getTempDir() / ("test-run3-escape-raw-" & $getCurrentProcessId())
    removeDir(dir)
    createDir(dir)
    defer: removeDir(dir)
    writeFile(dir / "run3", "name: \"esc\"\nversion: \"1.0\"\nrelease: \"1\"\n" &
      "sources:\n - \"https://example.org/\\$literal-${version}.tar.xz\"\n\n" &
      "build {\n  exec \"true\"\n}\n")
    let rf = parseRun3(dir)
    for value in rf.getSourcesRaw():
      check escapedDollar notin value
      check value == "https://example.org/$literal-${version}.tar.xz"
    for value in rf.getSourcesWithVersion("2.0"):
      check escapedDollar notin value
      check value == "https://example.org/$literal-2.0.tar.xz"
    for key, value in rf.getAllVariables():
      if value.kind == vvkString:
        check escapedDollar notin value.strVal
      elif value.kind == vvkList:
        for item in value.listVal:
          check escapedDollar notin item

  test "no metadata field ever contains the escape marker":
    let dir = leakDir("all")
    defer: removeDir(dir)
    writeFile(dir / "run3", "name: \"esc\"\nversion: \"1\"\nrelease: \"1\"\n" &
      "description: \"a \\$b\"\nsources:\n - \"https://e.org/\\$x\"\n\n" &
      "build {\n  exec \"true\"\n}\n")
    let rf = parseRun3(dir)
    for value in [rf.getName(), rf.getVersion(), rf.getRelease(),
                  rf.getDescription()]:
      check escapedDollar notin value
    for value in rf.getSources():
      check escapedDollar notin value
