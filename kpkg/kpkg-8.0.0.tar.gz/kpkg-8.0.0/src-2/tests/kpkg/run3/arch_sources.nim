## Per-architecture runfile keys: `sources_<arch>`, `sha256sum_<arch>`,
## `depends_<arch>` and friends. The common list always applies and arch
## entries are appended after it; only the *target* architecture's group is
## selected, never the host's. `amd64`/`arm64` alias `x86_64`/`aarch64`, and a
## qualifier that is not a known architecture still means "sub-package"
## (glibc's `depends_aarch64_linux_gnu_glibc`).

import std/[os, sequtils, strutils, tempfiles, unittest]
import ../../../kpkg/modules/arch
import ../../../kpkg/modules/runparser
import ../../../kpkg/modules/sourcegroups
import ../../../kpkg/modules/run3/run3

proc writeRecipe(recipe: string, packageDir = "pkg"): string =
  ## Write a run3 file into a fresh temporary package directory.
  ## The directory name matters: `depends_<pkg>` is matched against it.
  let root = createTempDir("kpkg-arch-", "")
  result = root / packageDir
  createDir(result)
  writeFile(result / "run3", recipe)

proc urls(pkg: runFile): seq[string] =
  for entry in pkg.sources:
    result.add(entry.url)

suite "arch name normalization":
  test "canonical names pass through":
    for name in ["x86_64", "aarch64", "riscv64", "armv7l"]:
      check normalizeArch(name) == name

  test "upstream aliases normalize to kpkg spelling":
    check normalizeArch("amd64") == "x86_64"
    check normalizeArch("x64") == "x86_64"
    check normalizeArch("x86-64") == "x86_64"
    check normalizeArch("arm64") == "aarch64"
    check normalizeArch("ARM64") == "aarch64"
    check normalizeArch("i686") == "x86"
    check normalizeArch("loong64") == "loongarch64"

  test "unknown names are lowercased and kept":
    check normalizeArch("mips64") == "mips64"
    check not isKnownArch("mips64")
    check isKnownArch("arm64")

  test "target arch comes from the target, not the host":
    check archNameFromTarget("aarch64-linux-gnu-jumpstart-openssl") == "aarch64"
    check archNameFromTarget("amd64-linux-gnu-jumpstart-openssl") == "x86_64"
    check archNameFromTarget("default") == hostArch()
    check archNameFromTarget("") == hostArch()

suite "per-architecture sources":
  test "arch entries are appended after the common list":
    let dir = writeRecipe("""
name: "vivaldi"
version: "8.3"
release: "1"
sources:
  - "fix-build.patch"
sources_aarch64:
  - "https://example.com/vivaldi-${version}-arm64.deb"
sha256sum_aarch64:
  - "arm-sum"
sources_x86_64:
  - "https://example.com/vivaldi-${version}-amd64.deb"
sha256sum_x86_64:
  - "x86-sum"
""")
    defer: removeDir(dir.parentDir)

    let arm = parseRunfile(dir, arch = "aarch64")
    check arm.sources.len == 2
    check arm.sources[0].url == "fix-build.patch"
    check arm.sources[1].url == "https://example.com/vivaldi-8.3-arm64.deb"
    check arm.sources[1].sha256sum == "arm-sum"
    check arm.sources[1].b2sum == ""
    check arm.arch == "aarch64"
    check arm.archSources == @["aarch64", "x86_64"]

    let x86 = parseRunfile(dir, arch = "x86_64")
    check x86.sources.len == 2
    check x86.sources[1].url == "https://example.com/vivaldi-8.3-amd64.deb"
    check x86.sources[1].sha256sum == "x86-sum"

  test "the target arch is what selects the group, not the host":
    # Whatever this machine is, asking for the other architecture must return
    # that architecture's file only.
    let dir = writeRecipe("""
name: "tool"
version: "1"
release: "1"
sources_aarch64:
  - "tool-arm64.tar.gz"
sources_x86_64:
  - "tool-amd64.tar.gz"
sha256sum_aarch64:
  - "arm"
sha256sum_x86_64:
  - "x86"
""")
    defer: removeDir(dir.parentDir)
    check urls(parseRunfile(dir, arch = "aarch64")) == @["tool-arm64.tar.gz"]
    check urls(parseRunfile(dir, arch = "x86_64")) == @["tool-amd64.tar.gz"]
    # An architecture the recipe does not support contributes nothing.
    check urls(parseRunfile(dir, arch = "riscv64")).len == 0

  test "amd64/arm64 aliases select the canonical group":
    let dir = writeRecipe("""
name: "tool"
version: "1"
release: "1"
sources_arm64:
  - "tool-arm64.tar.gz"
sha256sum_arm64:
  - "arm"
""")
    defer: removeDir(dir.parentDir)
    # Asking by the alias and by the canonical name must both work, whatever
    # spelling the recipe used.
    check urls(parseRunfile(dir, arch = "arm64")) == @["tool-arm64.tar.gz"]
    check urls(parseRunfile(dir, arch = "aarch64")) == @["tool-arm64.tar.gz"]
    check urls(parseRunfile(dir, arch = "amd64")).len == 0

  test "a common-only recipe is unchanged":
    let dir = writeRecipe("""
name: "plain"
version: "1"
release: "1"
sources:
  - "https://example.com/plain.tar.gz"
sha256sum:
  - "sum"
""")
    defer: removeDir(dir.parentDir)
    for arch in ["aarch64", "x86_64", "riscv64"]:
      let pkg = parseRunfile(dir, arch = arch)
      check urls(pkg) == @["https://example.com/plain.tar.gz"]
      check pkg.sources[0].sha256sum == "sum"
      check pkg.archSources.len == 0

  test "checksum lists stay aligned per group":
    let dir = writeRecipe("""
name: "aligned"
version: "1"
release: "1"
sources:
  - "shared.patch"
sha256sum:
  - "shared-sum"
sources_aarch64:
  - "one.tar.gz"
  - "two.tar.gz"
sha256sum_aarch64:
  - "one-sum"
  - "two-sum"
""")
    defer: removeDir(dir.parentDir)
    let pkg = parseRunfile(dir, arch = "aarch64")
    check pkg.sources.len == 3
    check pkg.sources.mapIt(it.sha256sum) == @["shared-sum", "one-sum", "two-sum"]

  test "b2sum and sha512sum groups are read too":
    let dir = writeRecipe("""
name: "families"
version: "1"
release: "1"
sources_x86_64:
  - "x86.tar.gz"
b2sum_x86_64:
  - "x86-b2"
sources_aarch64:
  - "arm.tar.gz"
sha512sum_aarch64:
  - "arm-sha512"
""")
    defer: removeDir(dir.parentDir)
    let x86 = parseRunfile(dir, arch = "x86_64")
    check x86.sources[0].b2sum == "x86-b2"
    check x86.sources[0].sha256sum == ""
    let arm = parseRunfile(dir, arch = "aarch64")
    check arm.sources[0].sha512sum == "arm-sha512"

  test "the space-qualifier spelling is equivalent":
    # Kongue parses `sources aarch64:` exactly like `sources_aarch64:`.
    let dir = writeRecipe("""
name: "spaced"
version: "1"
release: "1"
sources aarch64:
  - "arm.tar.gz"
sha256sum aarch64:
  - "arm-sum"
""")
    defer: removeDir(dir.parentDir)
    let pkg = parseRunfile(dir, arch = "aarch64")
    check urls(pkg) == @["arm.tar.gz"]
    check pkg.sources[0].sha256sum == "arm-sum"
    check pkg.archSources == @["aarch64"]

suite "per-architecture dependencies":
  test "depends_<arch> applies to the target arch only":
    let dir = writeRecipe("""
name: "vivaldi"
version: "1"
release: "1"
depends:
  - "glib"
depends_aarch64:
  - "arm-only"
depends_x86_64:
  - "x86-only"
""")
    defer: removeDir(dir.parentDir)
    check parseRunfile(dir, arch = "aarch64").deps == @["glib", "arm-only"]
    check parseRunfile(dir, arch = "x86_64").deps == @["glib", "x86-only"]
    check parseRunfile(dir, arch = "riscv64").deps == @["glib"]

  test "build_depends_<arch> and bootstrap_depends_<arch> are supported":
    let dir = writeRecipe("""
name: "toolchain"
version: "1"
release: "1"
build_depends:
  - "gmake"
build_depends_aarch64:
  - "aarch64-linux-gnu-gcc"
bootstrap_depends_aarch64:
  - "aarch64-bootstrap"
""")
    defer: removeDir(dir.parentDir)
    let arm = parseRunfile(dir, arch = "aarch64")
    check arm.bdeps == @["gmake", "aarch64-linux-gnu-gcc"]
    check arm.bsdeps == @["aarch64-bootstrap"]
    let x86 = parseRunfile(dir, arch = "x86_64")
    check x86.bdeps == @["gmake"]
    check x86.bsdeps.len == 0

  test "a qualifier that is neither the package nor an arch is inert":
    # glibc and gcc carry `depends_aarch64_linux_gnu_glibc` /
    # `depends_aarch64_linux_gnu_gcc` next to their sub-package functions.
    # That qualifier names a sub-package, not an arch: applying it to every
    # build would pull a cross toolchain into a native build.
    let dir = writeRecipe("""
name: "glibc"
version: "1"
release: "1"
depends:
  - "bash"
depends_aarch64_linux_gnu_glibc:
  - "aarch64-linux-gnu-linux-headers"
""", "glibc")
    defer: removeDir(dir.parentDir)
    for arch in ["aarch64", "x86_64"]:
      check parseRunfile(dir, arch = arch).deps == @["bash"]

  test "an arch qualifier on a sub-package list is not mistaken for an arch":
    # `depends_<pkg>` where the package name itself looks like an arch alias
    # keeps working: the package qualifier wins for its own sub-package.
    let dir = writeRecipe("""
name: "arm64"
version: "1"
release: "1"
depends:
  - "base"
depends_arm64:
  - "subpkg-dep"
""", "arm64")
    defer: removeDir(dir.parentDir)
    # "arm64" is both the package name and an alias of aarch64, so the list
    # applies to the package's own sub-package on every arch.
    for arch in ["aarch64", "x86_64"]:
      check "subpkg-dep" in parseRunfile(dir, arch = arch).deps

  test "depends_<pkg> and depends_<arch> can be combined":
    let dir = writeRecipe("""
name: "multi"
version: "1"
release: "1"
depends:
  - "base"
depends_multi:
  - "subpkg-dep"
depends_aarch64:
  - "arm-dep"
""", "multi")
    defer: removeDir(dir.parentDir)
    let arm = parseRunfile(dir, arch = "aarch64")
    check "subpkg-dep" in arm.deps
    check "arm-dep" in arm.deps
    check "base" in arm.deps
    let x86 = parseRunfile(dir, arch = "x86_64")
    check "subpkg-dep" in x86.deps
    check "arm-dep" notin x86.deps

suite "source group introspection":
  test "groups are reported with their exact key spelling":
    let dir = writeRecipe("""
name: "groups"
version: "1"
release: "1"
sources:
  - "common.patch"
sha256sum:
  - "common-sum"
sources aarch64:
  - "arm.tar.gz"
b2sum aarch64:
  - "arm-b2"
""")
    defer: removeDir(dir.parentDir)
    let recipe = parseRun3(dir)
    let groups = sourceGroups(recipe.parsed)
    check groups.len == 2
    check groups[0].arch == ""
    check groups[0].sourcesKey == "sources"
    check groups[0].checksumFamily() == "sha256"
    check groups[1].arch == "aarch64"
    # The recipe used the space-qualifier spelling, so that is what a rewriter
    # has to find; the lookup name is the underscore form Kongue also accepts.
    check groups[1].sourcesKey == "sources aarch64"
    check groups[1].sourcesLookup == "sources_aarch64"
    check groups[1].checksumKey("b2") == "b2sum aarch64"
    check groups[1].checksumLookup("b2") == "b2sum_aarch64"
    check groups[1].checksumFamily() == "b2"
    check archNames(recipe.parsed) == @["aarch64"]

  test "two checksum families in one group are rejected":
    let dir = writeRecipe("""
name: "twofamilies"
version: "1"
release: "1"
sources_aarch64:
  - "arm.tar.gz"
sha256sum_aarch64:
  - "arm-sha256"
b2sum_aarch64:
  - "arm-b2"
""")
    defer: removeDir(dir.parentDir)
    let recipe = parseRun3(dir)
    let groups = archGroups(recipe.parsed)
    check groups.len == 1
    expect ValueError:
      discard groups[0].checksumFamily()
