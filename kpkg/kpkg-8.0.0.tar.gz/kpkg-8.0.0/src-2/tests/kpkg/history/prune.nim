import std/[unittest, os, posix, json, times, algorithm]
import ../../../kpkg/modules/[sqlite, commonPaths]
import ../../../kpkg/modules/transactions/[main, history]

proc makeEntry(root, name: string, ageDays: float): Transaction =
  ## Committed, undoable transaction with a backdated history record.
  createDir(root / "owned")
  let session = beginHistory(root)
  result = newTransaction(name & "-" & $getpid(), root)
  let payload = root / "owned" / (name & ".file")
  result.recordFileCreated(payload)
  writeFile(payload, name)
  discard newPackage(name, "1", "1", "0", "", "", "", "", "", "", true,
      false, false, root)
  finishHistory(session, @[result])
  if ageDays > 0:
    let path = session.path / "entry.json"
    var data = parseJson(readFile(path))
    data["timestamp"] = %(epochTime() - ageDays * 86400.0)
    writeFile(path, $data)

suite "history prune":
  test "--keep removes only the oldest records":
    let root = getTempDir() / ("kpkg-prune-keep-" & $getpid())
    createDir(root)
    defer:
      closeDb()
      removeDir(root)
    var txs: seq[Transaction]
    for i, age in [40.0, 30.0, 20.0, 10.0]:
      txs.add(makeEntry(root, "keep" & $i, age))
    check pruneHistory(root, keep = 2, dryRun = true).len == 2
    check listHistory(root).len == 4
    check pruneHistory(root, keep = 2).len == 2
    check listHistory(root).len == 2
    for i in 0 .. 1:
      check not dirExists(kpkgBackupDir / txs[i].id)
      check not fileExists(kpkgJournalDir / (txs[i].id & ".journal"))
    for entry in listHistory(root):
      check loadHistoryMember(entry.path, entry.id).operations.len == 1

  test "--older-than keeps records newer than the cutoff":
    let root = getTempDir() / ("kpkg-prune-age-" & $getpid())
    createDir(root)
    defer:
      closeDb()
      removeDir(root)
    var txs: seq[Transaction]
    for i, age in [40.0, 30.0, 5.0, 1.0]:
      txs.add(makeEntry(root, "age" & $i, age))
    check pruneHistory(root, olderThan = 25).len == 2
    let entries = listHistory(root)
    check entries.len == 2
    var retained: seq[string]
    for entry in entries:
      for name in entry.packages: retained.add(name)
    retained.sort()
    var expected = @[txs[2].packageName, txs[3].packageName]
    expected.sort()
    check retained == expected

  test "retained entries stay undoable":
    let root = getTempDir() / ("kpkg-prune-undo-" & $getpid())
    createDir(root)
    defer:
      closeDb()
      removeDir(root)
    let first = makeEntry(root, "undo0", 30)
    let second = makeEntry(root, "undo1", 20)
    let last = makeEntry(root, "undo2", 10)
    check pruneHistory(root, keep = 1).len == 2
    check not dirExists(kpkgBackupDir / first.id)
    check not dirExists(kpkgBackupDir / second.id)
    undoHistory(last.id, root)
    check not fileExists(root / "owned" / "undo2.file")
    check readFile(root / "owned" / "undo1.file") == "undo1"
    check readFile(root / "owned" / "undo0.file") == "undo0"
    check listHistory(root)[0].state == "undone"

  test "prune requires a bound and refuses pending operations":
    let root = getTempDir() / ("kpkg-prune-guard-" & $getpid())
    createDir(root)
    defer:
      closeDb()
      removeDir(root)
    expect ValueError: discard pruneHistory(root)
    discard makeEntry(root, "guard", 30)
    let pending = beginHistory(root)
    expect IOError: discard pruneHistory(root, keep = 0)
    cancelHistory(pending)
    check listHistory(root).len == 1
    check pruneHistory(root, keep = 1).len == 0
    check pruneHistory(root, keep = 0).len == 1
    check listHistory(root).len == 0
