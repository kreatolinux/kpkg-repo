import std/[unittest, os, posix, json, times, strutils]
import ../../../kpkg/modules/[sqlite, commonPaths]
import ../../../kpkg/modules/transactions/[main, history]

proc writeJournal(id, root: string, state: TransactionState) =
  ## Minimal journal fixture with one operation and a final state record.
  writeFile(kpkgJournalDir / (id & ".journal"), $( %* {
    "record": "header", "version": "2", "id": id, "packageName": "fixture",
    "state": $tsActive, "root": root, "historyPath": "", "timestamp": epochTime()}) &
    "\n" & $( %* {"record": "operation", "kind": $opFileCreated,
      "path": root & "/fixture-file", "backupPath": "", "mode": 0, "uid": 0,
      "gid": 0, "timestamp": epochTime()}) & "\n" & $( %* {"record": "state",
      "state": $state, "timestamp": epochTime()}) & "\n")

suite "settled transaction journals":
  test "committed journal is retired once the history record is durable":
    let root = getTempDir() / ("kpkg-settled-finalize-" & $getpid())
    createDir(root / "var/lib/kpkg")
    defer:
      closeDb()
      removeDir(root)
    let payload = root / "payload"
    let session = beginHistory(root)
    let tx = newTransaction("settle-" & $getpid(), root)
    tx.recordFileCreated(payload)
    writeFile(payload, "new")
    discard newPackage("settle", "1", "1", "0", "", "", "", "", "", "",
        true, false, false, root)
    finishHistory(session, @[tx])
    check not fileExists(tx.journalPath)
    let archive = historyArchivePath(session.path, tx.id)
    check fileExists(archive)
    check loadHistoryArchive(session.path, tx.id).operations.len == 1
    # Undo still works: the operation log lives with the history record.
    undoHistory(tx.id, root)
    check not fileExists(payload)
    check listHistory(root)[0].state == "undone"
    check not fileExists(tx.journalPath)
    check loadHistoryArchive(session.path, tx.id).state == tsRolledBack

  test "interrupted transaction recovers alongside committed journals":
    let root = getTempDir() / ("kpkg-settled-recover-" & $getpid())
    createDir(root)
    defer:
      closeDb()
      removeDir(root)
    for n in 0 ..< 3:
      writeJournal("committed-" & $getpid() & "-" & $n, root, tsCommitted)
    let tx = newTransaction("interrupted-" & $getpid(), root)
    let payload = root / "interrupted-file"
    tx.recordFileCreated(payload)
    writeFile(payload, "partial")
    check recoverFromCrash()
    check not fileExists(payload) # Rolled back to the pre-transaction state.
    check not fileExists(tx.journalPath) # A rolled-back journal is settled too.
    removeDir(kpkgBackupDir / tx.id)

  test "recovery does not slow down with committed journals":
    let root = getTempDir() / ("kpkg-settled-many-" & $getpid())
    createDir(root)
    defer:
      closeDb()
      removeDir(root)
    for n in 0 ..< 1000:
      writeJournal("settled-" & $getpid() & "-" & $n, root, tsCommitted)
    let started = epochTime()
    check not recoverFromCrash()
    let elapsed = epochTime() - started
    var remaining = 0
    for journal in walkFiles(kpkgJournalDir / "*.journal"):
      if lastPathPart(journal).startsWith("settled-" & $getpid()): inc remaining
    check remaining == 0
    check elapsed < 5.0
    # A second pass has nothing left to classify.
    let again = epochTime()
    check not recoverFromCrash()
    check epochTime() - again < 5.0

  test "legacy committed journal is archived into its history record":
    let root = getTempDir() / ("kpkg-settled-legacy-" & $getpid())
    createDir(root)
    defer:
      closeDb()
      removeDir(root)
    let id = "legacy-" & $getpid()
    let session = root / "var/lib/kpkg/history/pending-legacy"
    createDir(session)
    writeFile(session / "entry.json", $( %* {"id": id, "ids": [id],
      "packages": ["fixture"], "root": root, "state": "committed", "reason": "",
      "timestamp": epochTime(), "hadDatabase": false, "afterDatabase": false,
      "fingerprint": "", "paths": {}, "action": "install"}))
    writeJournal(id, root, tsCommitted)
    let journal = kpkgJournalDir / (id & ".journal")
    check fileExists(journal)
    check pruneSettledJournals() == 1
    check not fileExists(journal)
    let evidence = loadHistoryMember(session, id)
    check evidence.operations.len == 1
    check evidence.operations[0].path == root / "fixture-file"

  test "committed journal of a pending session is kept for recovery":
    let root = getTempDir() / ("kpkg-settled-pending-" & $getpid())
    createDir(root / "var/lib/kpkg")
    let payload = root / "pending-payload"
    let session = beginHistory(root)
    let tx = newTransaction("pending-" & $getpid(), root)
    tx.recordFileCreated(payload)
    writeFile(payload, "new")
    tx.commit() # Committed, but the history entry was never published.
    check fileExists(tx.journalPath)
    discard pruneSettledJournals()
    check fileExists(tx.journalPath)
    check inspectPendingHistory(root).len > 0
    # Fixture cleanup: cancel is refused because the journal is a member.
    expect IOError: cancelHistory(session)
    removeFile(tx.journalPath)
    removeDir(session.path)
    removeDir(kpkgBackupDir / tx.id)
    removeDir(root)
