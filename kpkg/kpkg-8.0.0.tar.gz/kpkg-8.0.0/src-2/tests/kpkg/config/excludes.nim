# Exclude patterns must also apply to packages kpkg adds on its own
# (dependencies, dependents scheduled for reinstall or rebuild).
import std/[os, unittest]
include ../../../kpkg/modules/config

when kpkgConfigPath == "/etc/kpkg/kpkg.conf":
  {.error: "compile with an isolated -d:kpkgConfigPath".}

proc repoOf(name: string): string = "/etc/kpkg/repos/main"

suite "partitionExcluded":
  setup:
    config = nil
    createDir(parentDir(configPath))
    # Unquoted on purpose: parsecfg alone would read `linux-*` as `linux-`.
    writeFile(configPath, "[Options]\nexcludePkgs=linux-*\n")
    setDisableExcludes(false)
    addCliExcludePatterns(@[])
  teardown:
    config = nil
    removeFile(configPath)

  test "nothing excluded keeps every package":
    addCliExcludePatterns(@[])
    let r = partitionExcluded(@["shadow", "cups"], repoOf,
        proc(n: string): bool = true)
    check r.kept == @["shadow", "cups"]
    check r.skipped.len == 0 and r.missing.len == 0

  test "an excluded installed dependent is skipped, not installed":
    addCliExcludePatterns(@["kpkg"])
    let r = partitionExcluded(@["bubblewrap", "kpkg", "cups"], repoOf,
        proc(n: string): bool = true)
    check r.kept == @["bubblewrap", "cups"]
    check r.skipped == @["kpkg"]
    check r.missing.len == 0

  test "an excluded package that is not installed is reported missing":
    addCliExcludePatterns(@["kpkg"])
    let r = partitionExcluded(@["kpkg"], repoOf,
        proc(n: string): bool = false)
    check r.missing == @["kpkg"]
    check r.kept.len == 0

  test "kpkg.conf patterns and globs apply too":
    let r = partitionExcluded(@["linux-firmware", "linux", "gdm"], repoOf,
        proc(n: string): bool = true)
    check r.skipped == @["linux-firmware"]
    check r.kept == @["linux", "gdm"]

  test "disableExcludes turns filtering off":
    addCliExcludePatterns(@["kpkg"])
    setDisableExcludes(true)
    let r = partitionExcluded(@["kpkg"], repoOf,
        proc(n: string): bool = true)
    check r.kept == @["kpkg"]

  test "blank names are dropped":
    let r = partitionExcluded(@["", "  "], repoOf,
        proc(n: string): bool = true)
    check r.kept.len == 0 and r.skipped.len == 0 and r.missing.len == 0
