## Unit tests for kpkg/modules/fileowners.nim: path canonicalization across
## merged-/usr directory symlinks and the symlink-vs-real-file ownership policy.
## Pure filesystem tests on throwaway temp roots; no database is opened.
import std/[os, tempfiles, unittest, tables, sets, strutils, algorithm]
import ../../../kpkg/modules/fileowners

proc mkRoot(): string = createTempDir("kpkg-fileowners-", "")

proc mergedUsr(root: string) =
  ## bin -> usr/bin, sbin -> usr/bin (relative links), usr/bin is real.
  createDir(root / "usr/bin")
  createSymlink("usr/bin", root / "bin")
  createSymlink("usr/bin", root / "sbin")

proc owner(name: string, id: int64, isLink: bool): FileOwner =
  (name: name, id: id, isLink: isLink)

proc idx(rows: varargs[(string, FileOwner)]): OwnerIndex =
  result = initTable[string, seq[FileOwner]]()
  for (path, o) in rows:
    result.mgetOrPut(path, @[]).add(o)

proc sortedAliases(s: seq[string]): seq[string] =
  result = s
  result.sort()

suite "canonicalRelPath":
  test "relative dir link: bin/passwd -> usr/bin/passwd":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/passwd", "real")
    check canonicalRelPath(root, "bin/passwd") == "usr/bin/passwd"
    check canonicalRelPath(root, "usr/bin/passwd") == "usr/bin/passwd"

  test "sbin -> usr/bin":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    check canonicalRelPath(root, "sbin/fdisk") == "usr/bin/fdisk"

  test "absolute dir link resolves inside the temp root":
    let root = mkRoot()
    defer: removeDir(root)
    createDir(root / "usr/bin")
    createSymlink("/usr/bin", root / "bin")
    let c = canonicalRelPath(root, "bin/passwd")
    check c == "usr/bin/passwd"
    check not c.startsWith("/")
    check not c.contains(root.strip(chars = {'/'}))

  test "absolute link with .. never escapes the root":
    let root = mkRoot()
    defer: removeDir(root)
    createDir(root / "usr/bin")
    createSymlink("/../../../usr/bin", root / "bin")
    check canonicalRelPath(root, "bin/passwd") == "usr/bin/passwd"
    createSymlink("../../../../usr/bin", root / "sbin")
    check canonicalRelPath(root, "sbin/passwd") == "usr/bin/passwd"

  test "final component symlink is not followed":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/busybox", "bb")
    createSymlink("busybox", root / "usr/bin/sh")
    check canonicalRelPath(root, "bin/sh") == "usr/bin/sh"
    check canonicalRelPath(root, "usr/bin/sh") == "usr/bin/sh"
    # A directory symlink as the final component also stays unresolved.
    check canonicalRelPath(root, "bin") == "bin"

  test "chained links: sbin -> usr/sbin, usr/sbin -> bin, bin -> usr/bin":
    let root = mkRoot()
    defer: removeDir(root)
    createDir(root / "usr/bin")
    createSymlink("usr/bin", root / "bin")
    createSymlink("bin", root / "usr/sbin")      # relative to usr/
    createSymlink("usr/sbin", root / "sbin")
    check canonicalRelPath(root, "usr/sbin/fdisk") == "usr/bin/fdisk"
    check canonicalRelPath(root, "sbin/fdisk") == "usr/bin/fdisk"
    check canonicalRelPath(root, "bin/fdisk") == "usr/bin/fdisk"

  test "chained links through a top-level link inside the target":
    let root = mkRoot()
    defer: removeDir(root)
    createDir(root / "usr/bin")
    createSymlink("usr/bin", root / "bin")
    createSymlink("../bin", root / "usr/sbin")   # -> bin -> usr/bin
    check canonicalRelPath(root, "usr/sbin/mkfs") == "usr/bin/mkfs"

  test "missing paths are returned normalized, unresolved":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    check canonicalRelPath(root, "opt/nothing/here") == "opt/nothing/here"
    check canonicalRelPath(root, "bin/not-installed") == "usr/bin/not-installed"
    check canonicalRelPath(root, "./usr//bin/./x") == "usr/bin/x"
    check canonicalRelPath(root, "") == ""
    check canonicalRelPath(root, "\"\"") == ""

  test "quoted input is unquoted":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    check canonicalRelPath(root, "\"bin/passwd\"") == "usr/bin/passwd"
    check canonicalRelPath(root, "\"usr/bin/passwd\"") == "usr/bin/passwd"

  test "symlink loops terminate":
    let root = mkRoot()
    defer: removeDir(root)
    createSymlink("b", root / "a")
    createSymlink("a", root / "b")
    discard canonicalRelPath(root, "a/x")    # must not hang
    check true

  test "no root symlinks: identity":
    let root = mkRoot()
    defer: removeDir(root)
    createDir(root / "bin")
    createDir(root / "usr/bin")
    check canonicalRelPath(root, "bin/passwd") == "bin/passwd"

suite "pathAliases / dirAliases":
  test "canonical first plus bin/ and sbin/ spellings":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    let a = pathAliases(root, "usr/bin/passwd")
    check a[0] == "usr/bin/passwd"
    check sortedAliases(a) == @["bin/passwd", "sbin/passwd", "usr/bin/passwd"]

  test "usr/sbin and lib aliases are found too":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createDir(root / "usr/lib")
    createSymlink("bin", root / "usr/sbin")
    createSymlink("usr/lib", root / "lib")
    let a = pathAliases(root, "usr/bin/fdisk")
    check a[0] == "usr/bin/fdisk"
    check sortedAliases(a) ==
      @["bin/fdisk", "sbin/fdisk", "usr/bin/fdisk", "usr/sbin/fdisk"]
    check sortedAliases(pathAliases(root, "usr/lib/libc.so")) ==
      @["lib/libc.so", "usr/lib/libc.so"]

  test "paths outside aliased dirs have only themselves":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    check pathAliases(root, "etc/passwd") == @["etc/passwd"]
    # Prefix match must be on a path boundary.
    check pathAliases(root, "usr/binx/foo") == @["usr/binx/foo"]

  test "dirAliases lists only directory links with canonical targets":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/busybox", "bb")
    createSymlink("usr/bin/busybox", root / "init")   # file link: ignored
    var got: seq[string]
    for (link, target) in dirAliases(root):
      got.add(link & "=" & target)
    got.sort()
    check got == @["bin=usr/bin", "sbin=usr/bin"]

  test "absolute directory link whose target is absent on the host":
    # The target exists only inside the root. Classification must not
    # depend on the host filesystem.
    let root = mkRoot()
    defer: removeDir(root)
    createDir(root / "usr/kpkg-fileowners-only-in-root")
    createSymlink("/usr/kpkg-fileowners-only-in-root", root / "kbin")
    check not dirExists("/usr/kpkg-fileowners-only-in-root")
    check canonicalRelPath(root, "kbin/x") == "usr/kpkg-fileowners-only-in-root/x"
    check sortedAliases(pathAliases(root, "usr/kpkg-fileowners-only-in-root/x")) ==
      @["kbin/x", "usr/kpkg-fileowners-only-in-root/x"]

suite "planOwnership":
  test "busybox symlink over shadow's regular file is skipped":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/passwd", "real")
    let index = idx(("usr/bin/passwd", owner("shadow", 1, false)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "bin/passwd", isSymlink: true)], index)
    check "bin/passwd" in plan.skip
    check plan.skip.len == 1
    check plan.drops.len == 0
    check plan.notes.len == 0
    check plan.warnings.len == 1
    check "shadow" in plan.warnings[0]
    check "usr/bin/passwd" in plan.warnings[0]

  test "sbin spelling over a real file is skipped too":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/fdisk", "real")
    let index = idx(("usr/bin/fdisk", owner("util-linux", 3, false)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "sbin/fdisk", isSymlink: true)], index)
    check plan.skip == toHashSet(["sbin/fdisk"])
    check plan.drops.len == 0

  test "shadow regular file over busybox symlink takes ownership":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/busybox", "bb")
    createSymlink("busybox", root / "usr/bin/passwd")
    let bb = owner("busybox", 2, true)
    let index = idx(("bin/passwd", bb), ("usr/bin/busybox", owner("busybox", 2, false)))
    let plan = planOwnership(root, "shadow",
        @[(relPath: "usr/bin/passwd", isSymlink: false)], index)
    check plan.skip.len == 0
    check plan.warnings.len == 0
    check plan.drops.len == 1
    check plan.drops[0].path == "bin/passwd"
    check plan.drops[0].owner == bb
    check plan.notes.len == 1
    check "busybox" in plan.notes[0]
    check "shadow" in plan.notes[0]

  test "symlink over another package's symlink takes ownership of all alias rows":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/busybox", "bb")
    createSymlink("busybox", root / "usr/bin/sh")
    let index = idx(("bin/sh", owner("busybox", 2, true)),
                    ("sbin/sh", owner("busybox", 2, true)))
    let plan = planOwnership(root, "dash",
        @[(relPath: "usr/bin/sh", isSymlink: true)], index)
    check plan.skip.len == 0
    check plan.drops.len == 2
    var paths: seq[string]
    for d in plan.drops:
      check d.owner.name == "busybox"
      paths.add(d.path)
    paths.sort()
    check paths == @["bin/sh", "sbin/sh"]
    check plan.notes.len == 1

  test "stale isLink-only owner with a regular file on disk: not skipped":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/passwd", "real")
    let index = idx(("bin/passwd", owner("busybox", 2, true)))
    # Another applet provider installing a symlink.
    let p1 = planOwnership(root, "toybox",
        @[(relPath: "sbin/passwd", isSymlink: true)], index)
    check p1.skip.len == 0
    check p1.drops.len == 0
    check p1.warnings.len == 0
    # The real package reinstalling its regular file.
    let p2 = planOwnership(root, "shadow",
        @[(relPath: "usr/bin/passwd", isSymlink: false)], index)
    check p2.skip.len == 0
    check p2.drops.len == 0
    check p2.warnings.len == 0
    check p2.notes.len == 0

  test "real vs real: no skip, no drops":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/su", "real")
    let index = idx(("usr/bin/su", owner("util-linux", 3, false)))
    let plan = planOwnership(root, "shadow",
        @[(relPath: "bin/su", isSymlink: false)], index)
    check plan.skip.len == 0
    check plan.drops.len == 0
    check plan.warnings.len == 0
    check plan.notes.len == 0

  test "own package rows are excluded":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/passwd", "real")
    createSymlink("passwd", root / "usr/bin/chpasswd")
    let index = idx(("usr/bin/passwd", owner("busybox", 2, false)),
                    ("bin/chpasswd", owner("busybox", 2, true)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "bin/passwd", isSymlink: true),
          (relPath: "usr/bin/chpasswd", isSymlink: false)], index)
    check plan.skip.len == 0
    check plan.drops.len == 0
    check plan.warnings.len == 0
    check plan.notes.len == 0

  test "entries without other owners are untouched; only conflicts are reported":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/passwd", "real")
    writeFile(root / "usr/bin/newtool", "x")
    let index = idx(("usr/bin/passwd", owner("shadow", 1, false)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "bin/newtool", isSymlink: true),
          (relPath: "bin/missing", isSymlink: true),
          (relPath: "bin/passwd", isSymlink: true),
          (relPath: "", isSymlink: true)], index)
    check plan.skip == toHashSet(["bin/passwd"])
    check plan.drops.len == 0
    check plan.warnings.len == 1

  test "symlink entry where nothing is on disk yet is not skipped":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    let index = idx(("usr/bin/passwd", owner("shadow", 1, false)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "bin/passwd", isSymlink: true)], index)
    check plan.skip.len == 0
    check plan.drops.len == 0

  test "symlink over a clobbered real file keeps the real owner's claim":
    ## A busybox link can sit on a path cups records as a real file.
    ## Reinstalling busybox must not take the path from cups, or a cups
    ## reinstall could never restore it.
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createSymlink("/bin/busybox", root / "usr/bin/lpr")
    let index = idx(("usr/bin/lpr", owner("cups", 2, false)),
                    ("bin/lpr", owner("busybox", 3, true)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "bin/lpr", isSymlink: true)], index)
    check plan.skip.len == 0
    check plan.drops.len == 0
    let back = planOwnership(root, "cups",
        @[(relPath: "usr/bin/lpr", isSymlink: false)], index)
    check back.drops.len == 1
    check back.drops[0].owner.name == "busybox"

suite "removalProtected":
  test "removing busybox keeps shadow's real usr/bin/passwd":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/passwd", "real")
    let index = idx(("usr/bin/passwd", owner("shadow", 1, false)),
                    ("bin/passwd", owner("busybox", 2, true)))
    let links = dirAliases(root)
    check removalProtected(root, "busybox", "bin/passwd", index, links)
    check removalProtected(root, "busybox", "\"bin/passwd\"", index, links)

  test "removing shadow is not blocked by busybox's stale isLink row":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/passwd", "real")
    let index = idx(("usr/bin/passwd", owner("shadow", 1, false)),
                    ("bin/passwd", owner("busybox", 2, true)))
    let links = dirAliases(root)
    check not removalProtected(root, "shadow", "usr/bin/passwd", index, links)
    check not removalProtected(root, "shadow", "\"usr/bin/passwd\"", index, links)

  test "symlink on disk with another isLink owner is protected":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/busybox", "bb")
    createSymlink("busybox", root / "usr/bin/sh")
    let index = idx(("usr/bin/sh", owner("dash", 4, true)),
                    ("bin/sh", owner("busybox", 2, true)))
    let links = dirAliases(root)
    check removalProtected(root, "busybox", "bin/sh", index, links)
    check removalProtected(root, "dash", "usr/bin/sh", index, links)

  test "symlink on disk is not pinned by a stale checksummed row":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/busybox", "bb")
    createSymlink("busybox", root / "usr/bin/passwd")
    let index = idx(("usr/bin/passwd", owner("shadow", 1, false)),
                    ("bin/passwd", owner("busybox", 2, true)))
    check not removalProtected(root, "busybox", "bin/passwd", index, dirAliases(root))

  test "directories are never protected":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createDir(root / "usr/share/doc")
    let index = idx(("usr/share/doc", owner("shadow", 1, false)),
                    ("usr/bin", owner("filesystem", 5, false)),
                    ("usr/share/doc", owner("filesystem", 5, true)))
    let links = dirAliases(root)
    check not removalProtected(root, "busybox", "usr/share/doc", index, links)
    check not removalProtected(root, "busybox", "usr/bin", index, links)

  test "missing files and unowned files are not protected":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/onlymine", "x")
    let index = idx(("usr/bin/onlymine", owner("busybox", 2, false)),
                    ("usr/bin/gone", owner("shadow", 1, false)))
    let links = dirAliases(root)
    check not removalProtected(root, "busybox", "bin/onlymine", index, links)
    check not removalProtected(root, "busybox", "bin/gone", index, links)
    check not removalProtected(root, "busybox", "", index, links)

  test "real vs real: another checksummed owner protects":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    writeFile(root / "usr/bin/su", "real")
    let index = idx(("usr/bin/su", owner("util-linux", 3, false)),
                    ("bin/su", owner("shadow", 1, false)))
    check removalProtected(root, "shadow", "bin/su", index, dirAliases(root))

proc samePlan(a, b: OwnershipPlan): bool =
  a.skip == b.skip and a.drops == b.drops and a.warnings == b.warnings and
    a.notes == b.notes

proc sortedLinks(d: DirAliases): seq[string] =
  for (link, target) in d: result.add(link & "=" & target)
  result.sort()

suite "root \"\" means \"/\" (read-only against /)":
  test "\"\" resolves against /, never the process cwd":
    # A decoy cwd whose layout would give different answers if "" were
    # resolved relative to the working directory.
    let decoy = mkRoot()
    let saved = getCurrentDir()
    defer:
      setCurrentDir(saved)
      removeDir(decoy)
    createDir(decoy / "decoyusr/bin")
    writeFile(decoy / "decoyusr/bin/sh", "decoy")
    createSymlink("decoyusr/bin", decoy / "bin")
    createSymlink("decoyusr/bin", decoy / "sbin")
    createSymlink("decoyusr/bin", decoy / "lib")
    setCurrentDir(decoy)
    for rel in ["bin/sh", "sbin/fdisk", "lib/libc.so", "usr/bin/env",
                "\"bin/passwd\"", "etc/passwd", "var/run/x"]:
      let viaEmpty = canonicalRelPath("", rel)
      check viaEmpty == canonicalRelPath("/", rel)
      check not viaEmpty.contains("decoyusr")
    check sortedLinks(dirAliases("")) == sortedLinks(dirAliases("/"))
    for (link, target) in dirAliases(""):
      check not target.contains("decoyusr")
    let canon = canonicalRelPath("/", "bin/sh")
    check sortedAliases(pathAliases("", canon)) ==
      sortedAliases(pathAliases("/", canon))

  test "planOwnership and removalProtected agree for \"\" and \"/\"":
    let decoy = mkRoot()
    let saved = getCurrentDir()
    defer:
      setCurrentDir(saved)
      removeDir(decoy)
    createDir(decoy / "decoyusr/bin")
    writeFile(decoy / "decoyusr/bin/sh", "decoy")
    createSymlink("decoyusr/bin", decoy / "bin")
    setCurrentDir(decoy)
    # Only the index is synthetic; the filesystem is the real / (read-only).
    let shCanon = canonicalRelPath("/", "bin/sh")
    let envCanon = canonicalRelPath("/", "bin/env")
    let index = idx((shCanon, owner("realsh", 1, false)),
                    ("bin/sh", owner("applets", 2, true)),
                    (envCanon, owner("coreutils", 3, false)),
                    ("decoyusr/bin/sh", owner("decoy", 4, false)))
    let entries = @[(relPath: "bin/sh", isSymlink: true),
                    (relPath: "sbin/sh", isSymlink: false),
                    (relPath: "bin/env", isSymlink: true),
                    (relPath: "usr/bin/env", isSymlink: false)]
    check samePlan(planOwnership("", "incoming", entries, index),
                   planOwnership("/", "incoming", entries, index))
    let linksEmpty = dirAliases("")
    let linksSlash = dirAliases("/")
    for (pkg, rel) in [("applets", "bin/sh"), ("realsh", "usr/bin/sh"),
                       ("decoy", "bin/sh"), ("incoming", "bin/env"),
                       ("coreutils", "usr/bin/env"), ("x", "usr")]:
      check removalProtected("", pkg, rel, index, linksEmpty) ==
        removalProtected("/", pkg, rel, index, linksSlash)

suite "self-pointing and cyclic directory links":
  test "usr/X11R6 -> . does not hang and aliases stay bounded":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createSymlink(".", root / "usr/X11R6")
    writeFile(root / "usr/bin/xterm", "real")
    check canonicalRelPath(root, "usr/X11R6/bin/xterm") == "usr/bin/xterm"
    check canonicalRelPath(root, "usr/X11R6/X11R6/X11R6/bin/xterm") == "usr/bin/xterm"
    let a = pathAliases(root, "usr/bin/xterm")
    check a.len <= 64
    check a[0] == "usr/bin/xterm"
    check "bin/xterm" in a
    check "sbin/xterm" in a
    for (link, target) in dirAliases(root):
      check link != "usr/X11R6"

  test "planOwnership with a self link still applies the policy":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createSymlink(".", root / "usr/X11R6")
    createSymlink("..", root / "usr/up")
    createSymlink(".", root / "self")
    writeFile(root / "usr/bin/xterm", "real")
    let index = idx(("usr/bin/xterm", owner("xterm", 1, false)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "usr/X11R6/bin/xterm", isSymlink: true),
          (relPath: "self/self/bin/xterm", isSymlink: true)], index)
    check plan.skip == toHashSet(["usr/X11R6/bin/xterm", "self/self/bin/xterm"])
    check plan.drops.len == 0
    check removalProtected(root, "busybox", "usr/X11R6/bin/xterm", index,
                           dirAliases(root))

  test "many links to one directory are capped at 64 aliases":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    for i in 0 ..< 80:
      createSymlink("usr/bin", root / ("b" & $i))
    let a = pathAliases(root, "usr/bin/x")
    check a.len <= 64
    check a[0] == "usr/bin/x"

  test "mutually pointing links terminate":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createSymlink("b", root / "usr/a")
    createSymlink("a", root / "usr/b")
    discard dirAliases(root)
    discard canonicalRelPath(root, "usr/a/x")
    let a = pathAliases(root, "usr/bin/x")
    check a.len <= 64
    discard planOwnership(root, "p", @[(relPath: "usr/a/x", isSymlink: true)],
                          idx(("usr/a/x", owner("q", 1, false))))
    check true

suite "directory entries are not planned":
  test "a package's directory-symlink row is not dropped or noted":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    # filesystem lists `bin` and `sbin` (symlinks, no checksum).
    let index = idx(("bin", owner("filesystem", 1, true)),
                    ("sbin", owner("filesystem", 1, true)),
                    ("usr/bin", owner("filesystem", 1, true)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "bin", isSymlink: true),
          (relPath: "sbin", isSymlink: false),
          (relPath: "usr/bin", isSymlink: true)], index)
    check plan.skip.len == 0
    check plan.drops.len == 0
    check plan.notes.len == 0
    check plan.warnings.len == 0

  test "an entry landing on a real directory is left alone":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createDir(root / "usr/share/info")
    let index = idx(("usr/share/info", owner("texinfo", 2, true)),
                    ("usr/share/info", owner("man", 3, false)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "usr/share/info", isSymlink: true)], index)
    check plan.skip.len == 0
    check plan.drops.len == 0
    check plan.notes.len == 0

  test "removalProtected is false for a directory symlink":
    let root = mkRoot()
    defer: removeDir(root)
    mergedUsr(root)
    createDir(root / "usr/lib")
    createSymlink("usr/lib", root / "lib")
    let index = idx(("bin", owner("filesystem", 1, true)),
                    ("lib", owner("filesystem", 1, true)),
                    ("lib", owner("glibc", 2, false)))
    let links = dirAliases(root)
    check not removalProtected(root, "busybox", "bin", index, links)
    check not removalProtected(root, "busybox", "sbin", index, links)
    check not removalProtected(root, "glibc", "lib", index, links)
    check not removalProtected(root, "busybox", "\"lib\"", index, links)

suite "literal spelling is always consulted":
  proc varRunRoot(): string =
    result = mkRoot()
    createDir(result / "run")
    createDir(result / "var")
    createSymlink("../run", result / "var/run")

  test "canonicalRelPath resolves a nested link that dirAliases ignores":
    let root = varRunRoot()
    defer: removeDir(root)
    check canonicalRelPath(root, "var/run/foo") == "run/foo"
    check dirAliases(root).len == 0

  test "planOwnership finds an owner of the identical spelling var/run/foo":
    let root = varRunRoot()
    defer: removeDir(root)
    writeFile(root / "run/foo", "real")
    let index = idx(("var/run/foo", owner("daemon", 1, false)))
    let plan = planOwnership(root, "busybox",
        @[(relPath: "var/run/foo", isSymlink: true)], index)
    check plan.skip == toHashSet(["var/run/foo"])
    check plan.warnings.len == 1
    check plan.drops.len == 0

  test "taking over a symlink owned under var/run/foo drops that row":
    let root = varRunRoot()
    defer: removeDir(root)
    writeFile(root / "run/target", "t")
    createSymlink("target", root / "run/foo")
    let o = owner("busybox", 2, true)
    let index = idx(("var/run/foo", o))
    let plan = planOwnership(root, "daemon",
        @[(relPath: "\"var/run/foo\"", isSymlink: false)], index)
    check plan.skip.len == 0
    check plan.drops.len == 1
    check plan.drops[0].path == "var/run/foo"
    check plan.drops[0].owner == o
    check plan.notes.len == 1

  test "removalProtected finds another owner of var/run/foo":
    let root = varRunRoot()
    defer: removeDir(root)
    writeFile(root / "run/foo", "real")
    let index = idx(("var/run/foo", owner("daemon", 1, false)),
                    ("var/run/foo", owner("other", 3, false)))
    let links = dirAliases(root)
    check removalProtected(root, "other", "var/run/foo", index, links)
    check removalProtected(root, "other", "\"var/run/foo\"", index, links)
    check removalProtected(root, "daemon", "var/run/./foo", index, links)
