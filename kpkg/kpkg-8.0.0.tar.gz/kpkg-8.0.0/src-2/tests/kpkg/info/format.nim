## `kpkg info` source-group lines.
##
## `info` prints one line per source group (`sources: 1 entry`,
## `sources_aarch64: 2 entries`), formatted by the exported proc
## `formatSourceGroups` so it can be pinned without a repository or database.

import std/[os, tempfiles, unittest]
import ../../../kpkg/commands/infocmd
import ../../../kpkg/modules/arch
import ../../../kpkg/modules/run3/run3
import ../../../kpkg/modules/runparser as runparser

proc writeRecipe(recipe: string): string =
  ## Write a run3 file into a fresh temporary package directory.
  let root = createTempDir("kpkg-info-", "")
  result = root / "pkg"
  createDir(result)
  writeFile(result / "run3", recipe)

proc infoLines(recipe: string): seq[string] =
  ## The lines `kpkg info` would add for `recipe`, in order.
  let dir = writeRecipe(recipe)
  defer: removeDir(dir.parentDir)
  formatSourceGroups(parseRun3(dir))

suite "kpkg info source groups":
  test "a common-only recipe prints one line":
    check infoLines("""
name: "plain"
version: "1"
release: "1"
sources:
  - "https://example.com/plain.tar.gz"
sha256sum:
  - "sum"
""") == @["sources: 1 entry"]

  test "arch groups are listed after the common list, sorted by arch":
    # Written out of order and with the space-qualifier spelling on purpose:
    # the output follows `sourceGroups`, not the recipe's line order.
    check infoLines("""
name: "vivaldi"
version: "8.3"
release: "1"
sources_x86_64:
  - "vivaldi-amd64.deb"
sha256sum_x86_64:
  - "x86-sum"
sources:
  - "fix-build.patch"
sha256sum:
  - "common-sum"
sources aarch64:
  - "vivaldi-arm64.deb"
sha256sum aarch64:
  - "arm-sum"
""") == @["sources: 1 entry", "sources_aarch64: 1 entry",
           "sources_x86_64: 1 entry"]

  test "the entry count is the recipe's, not the target's":
    # `info` resolves the host architecture, so a cross build would select one
    # group; the report still shows every group a recipe declares.
    check infoLines("""
name: "multi"
version: "1"
release: "1"
sources_aarch64:
  - "one.tar.gz"
  - "two.tar.gz"
sha256sum_aarch64:
  - "one-sum"
  - "two-sum"
sources_riscv64:
  - "riscv.tar.gz"
sha256sum_riscv64:
  - "riscv-sum"
""") == @["sources_aarch64: 2 entries", "sources_riscv64: 1 entry"]

  test "a recipe without sources prints nothing":
    check infoLines("""
name: "meta"
version: "1"
release: "1"
type: "meta"
""").len == 0

  test "the host architecture resolves to its own group":
    # `parseRunfile` without an explicit arch must pick the host's group, which
    # is what `info` relies on.
    let dir = writeRecipe("""
name: "host"
version: "1"
release: "1"
sources_aarch64:
  - "arm.tar.gz"
sha256sum_aarch64:
  - "arm-sum"
sources_x86_64:
  - "x86.tar.gz"
sha256sum_x86_64:
  - "x86-sum"
""")
    defer: removeDir(dir.parentDir)
    let pkg = runparser.parseRunfile(dir)
    check pkg.arch == hostArch()
    check pkg.archSources == @["aarch64", "x86_64"]
    let expected = if hostArch() == "aarch64": "arm.tar.gz" else: "x86.tar.gz"
    if hostArch() in ["aarch64", "x86_64"]:
      check pkg.sources.len == 1
      check pkg.sources[0].url == expected
