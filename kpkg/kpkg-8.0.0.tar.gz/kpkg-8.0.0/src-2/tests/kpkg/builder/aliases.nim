## Recipe identity: the repository directory is the package identity, and a
## symlinked alias directory shares its recipe with another package name.
import std/[os, strutils, tempfiles, unittest]
import ../../../kpkg/modules/commonTasks

const run3Body = """
name: "$1"
version: "2.62.1"
release: "1"
description: "test recipe"
sources:
  - "test.tar.gz"
sha256sum:
  - "SKIP"
"""

proc makeRepo(): string =
  result = createTempDir("kpkg-alias-repo-", "")
  createDir(result / "atk")

proc writeRecipe(repo, directory, declaredName: string) =
  createDir(repo / directory)
  writeFile(repo / directory / "run3", run3Body % [declaredName])

suite "recipeDeclaredName":
  test "reads the name a recipe declares":
    let repo = makeRepo()
    defer: removeDir(repo)
    writeRecipe(repo, "atk", "atk")
    check recipeDeclaredName(repo, "atk") == "atk"

  test "a missing recipe directory declares nothing":
    let repo = makeRepo()
    defer: removeDir(repo)
    check recipeDeclaredName(repo, "nosuchpackage") == ""
    check recipeDeclaredName("", "atk") == ""

suite "recipeAliases":
  test "a name is its own only alias":
    let repo = makeRepo()
    defer: removeDir(repo)
    writeRecipe(repo, "atk", "atk")
    check recipeAliases(repo, "atk") == @["atk"]

  test "a symlinked alias directory shares the recipe":
    ## at-spi2-core -> atk: two package names, one recipe.
    let repo = makeRepo()
    defer: removeDir(repo)
    writeRecipe(repo, "atk", "atk")
    createSymlink("atk", repo / "at-spi2-core")
    check recipeAliases(repo, "atk") == @["atk", "at-spi2-core"]
    check recipeAliases(repo, "at-spi2-core") == @["at-spi2-core", "atk"]

  test "distinct recipe directories are not aliases":
    let repo = makeRepo()
    defer: removeDir(repo)
    writeRecipe(repo, "atk", "atk")
    writeRecipe(repo, "glib", "glib")
    check recipeAliases(repo, "atk") == @["atk"]
    check recipeAliases(repo, "") == newSeq[string]()

  test "a name without a recipe has no aliases":
    let repo = makeRepo()
    defer: removeDir(repo)
    check recipeAliases(repo, "nosuchpackage") == newSeq[string]()

suite "recipeIdentityNote":
  test "a matching name and recipe produce no note":
    let repo = makeRepo()
    defer: removeDir(repo)
    writeRecipe(repo, "atk", "atk")
    check recipeIdentityNote(repo, "atk") == ""

  test "a differing declared name is reported with the archive rule":
    ## linux-headers and atk keep their own identity; the note only says which
    ## recipe and archive name the build uses.
    let repo = makeRepo()
    defer: removeDir(repo)
    writeRecipe(repo, "linux-headers", "linux")
    let note = recipeIdentityNote(repo, "linux-headers")
    check "'linux-headers'" in note
    check "'linux'" in note
    check "one archive per requested name" in note

  test "a shared recipe lists the other published names":
    let repo = makeRepo()
    defer: removeDir(repo)
    writeRecipe(repo, "atk", "atk")
    createSymlink("atk", repo / "at-spi2-core")
    let note = recipeIdentityNote(repo, "atk")
    check note == ""

    writeRecipe(repo, "pcre", "pcre2")
    createSymlink("pcre", repo / "pcre-old")
    let shared = recipeIdentityNote(repo, "pcre-old")
    check "at-spi2-core" notin shared
    check "pcre" in shared
