## Exclude patterns prune the dependents kpkg scheduled for a rebuild by itself;
## a dropped name that is also a build dependency of a requested package must
## stay in the build order.
import std/unittest
import ../../../kpkg/modules/builder/main

suite "exclude pruning":
  test "dependents are pruned and build dependencies stay":
    let pruned = pruneExcluded(@["meson", "ninja", "gtk4"],
        @["gtk4", "gnome-shell"], @["gtk4"])
    check pruned.deps == @["meson", "ninja", "gtk4"]
    check pruned.dependents == @["gnome-shell"]

  test "nothing dropped leaves both lists alone":
    let pruned = pruneExcluded(@["gtk4"], @["gnome-shell"], @[])
    check pruned.deps == @["gtk4"]
    check pruned.dependents == @["gnome-shell"]
