## Deferred host installs: the record a SONAME rebuild leaves behind when the
## run stops before the provider is installed, and how a later run completes
## it. Pure filesystem tests against a throwaway store and injected hooks.
import std/[json, os, strutils, tempfiles, unittest]
import ../../../kpkg/modules/builder/pendingInstalls

proc newStore(): string =
  let dir = createTempDir("kpkg-pending-", "")
  return dir / "pending-installs.json"

proc newRoot(withArchive: bool, storeDir: string): tuple[root, archive: string] =
  result.root = createTempDir("kpkg-pending-root-", "")
  result.archive = storeDir / "gtk4-4.24.1-1.kpkg"
  if withArchive:
    writeFile(result.archive, "archive")

proc entry(root, archive: string, package = "gtk4",
           version = "4.24.1-1"): PendingInstall =
  PendingInstall(package: package, version: version,
      kTarget: "aarch64-linux-gnu-jumpstart-openssl", root: canonicalRoot(root),
      archive: archive, reason: pendingInstallsReasonSoname,
      sonames: @["libgtk-4.so.1.2000.4"], consumers: @["gnome-shell"],
      recordedAt: 1.0)

proc hooksOf(installed = "", recipe = true, installOk = true,
             affected: seq[string] = @[]): PendingHooks =
  PendingHooks(
    installedVersion: proc(package, root: string): string = installed,
    recipePresent: proc(package: string): bool = recipe,
    installPackage: proc(e: PendingInstall): bool = installOk,
    affectedConsumers: proc(e: PendingInstall): seq[string] = affected)

suite "pendingInstall store":
  test "a recorded deferred install survives a reload":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let loaded = loadPendingInstalls(store)
    check loaded.entries.len == 1
    check loaded.entries[0].package == "gtk4"
    check loaded.entries[0].version == "4.24.1-1"
    check loaded.entries[0].root == canonicalRoot(root)
    check loaded.entries[0].sonames == @["libgtk-4.so.1.2000.4"]
    check loaded.entries[0].consumers == @["gnome-shell"]
    check loaded.entries[0].installed == false

  test "a missing store is empty":
    check loadPendingInstalls(newStore()).entries.len == 0

  test "an unreadable store is kept aside, not fatal":
    let store = newStore()
    defer: removeDir(parentDir(store))
    writeFile(store, "{not json")
    check loadPendingInstalls(store).entries.len == 0
    check fileExists(store & ".corrupt")

  test "one unreadable entry does not discard the others":
    let store = newStore()
    defer: removeDir(parentDir(store))
    let (root, archive) = newRoot(true, parentDir(store))
    defer: removeDir(root)
    writeFile(store, $(%*{"version": 1, "entries": [
      {"package": 5, "version": "1-1", "root": root, "archive": archive,
       "recordedAt": 1.0},
      {"version": "1-1", "root": root, "archive": archive, "recordedAt": 1.0},
      {"package": "gtk4", "version": "4.24.1-1", "root": root,
       "archive": archive, "recordedAt": 1.0}]}))
    let loaded = loadPendingInstalls(store)
    check loaded.entries.len == 1
    check loaded.entries[0].version == "4.24.1-1"
    # The store itself is readable, so it is not moved aside.
    check not fileExists(store & ".corrupt")

  test "a store with an unknown schema version is still read":
    let store = newStore()
    defer: removeDir(parentDir(store))
    let (root, archive) = newRoot(true, parentDir(store))
    defer: removeDir(root)
    writeFile(store, $(%*{"version": 99, "entries": [
      {"package": "gtk4", "version": "4.24.1-1", "root": root,
       "archive": archive, "recordedAt": 1.0}]}))
    check loadPendingInstalls(store).entries.len == 1

  test "an invalid record is ignored":
    ## A hand-edited store must not turn a package into a repository path or
    ## an archive into a relative path.
    let store = newStore()
    defer: removeDir(parentDir(store))
    let (root, archive) = newRoot(true, parentDir(store))
    defer: removeDir(root)
    writeFile(store, $(%*{"version": 1, "entries": [
      {"package": "../../etc", "version": "1-1", "root": root,
       "archive": archive, "recordedAt": 1.0},
      {"package": "gtk4", "version": "1-1", "root": "relative/root",
       "archive": archive, "recordedAt": 1.0},
      {"package": "gtk4", "version": "4.24.1-1", "root": root,
       "archive": "relative.kpkg", "recordedAt": 1.0},
      {"package": "gtk4", "version": "4.24.1-1", "root": root,
       "archive": archive, "recordedAt": 1.0}]}))
    let loaded = loadPendingInstalls(store)
    check loaded.entries.len == 1
    check loaded.entries[0].package == "gtk4"
    check loaded.entries[0].root == root

  test "recording the same package and root replaces the record":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive, version = "4.24.1-1"), store)
    upsertPendingInstall(entry(root, archive, version = "4.26.0-1"), store)
    let loaded = loadPendingInstalls(store)
    check loaded.entries.len == 1
    check loaded.entries[0].version == "4.26.0-1"

  test "forget removes one record and keeps the others":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    let (root2, archive2) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(root2)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    upsertPendingInstall(entry(root2, archive2), store)
    forgetPendingInstall("gtk4", canonicalRoot(root), store)
    let loaded = loadPendingInstalls(store)
    check loaded.entries.len == 1
    check loaded.entries[0].root == canonicalRoot(root2)

  test "describe names the package, version, state and root":
    let text = describePending(PendingInstall(package: "gtk4",
        version: "4.24.1-1", root: "/out", kTarget: "x-linux-gnu-init-tls",
        reason: pendingInstallsReasonSoname, consumers: @["gnome-shell"]))
    check "gtk4" in text
    check "4.24.1-1" in text
    check "/out" in text
    check "gnome-shell" in text
    let installedText = describePending(PendingInstall(package: "gtk4",
        version: "4.24.1-1", root: "/out", installed: true))
    check "installed, consumer rebuild outstanding" in installedText

suite "pendingInstall classification":
  test "an install already satisfied is forgotten":
    let e = PendingInstall(package: "gtk4", version: "4.24.1-1", root: "/x")
    check classifyPending(e, "4.24.1-1", true, true, false) == paForgotten
    check classifyPending(e, "4.26.0-1", true, true, false) == paForgotten

  test "an install with consumers outstanding only needs the rebuilds":
    let e = PendingInstall(package: "gtk4", version: "4.24.1-1", root: "/x")
    check classifyPending(e, "4.24.1-1", true, true, true) == paRebuild

  test "an older installed version wants the archive":
    let e = PendingInstall(package: "gtk4", version: "4.24.1-1", root: "/x")
    check classifyPending(e, "4.20.4-1", true, true, false) == paInstall

  test "a missing archive holds the record":
    let e = PendingInstall(package: "gtk4", version: "4.24.1-1", root: "/x")
    check classifyPending(e, "", false, true, false) == paHold

  test "a removed root forgets the record":
    let e = PendingInstall(package: "gtk4", version: "4.24.1-1", root: "/x")
    check classifyPending(e, "", true, false, false) == paForgotten

suite "pendingInstall completion":
  test "an interrupted run is completed by the next one":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)

    var installed: seq[string]
    let plan = planPendingInstalls(root, hooksOf(affected = @["gnome-shell"]),
        store = store)
    check plan.toInstall.len == 1
    check plan.rebuild == @["gnome-shell"]
    # Planning must not install: a declined prompt changes nothing.
    check installed.len == 0

    let hooks = PendingHooks(
      installedVersion: proc(package, root: string): string = "",
      recipePresent: proc(package: string): bool = true,
      installPackage: proc(e: PendingInstall): bool =
        installed.add(e.package & " " & e.version)
        return true,
      affectedConsumers: proc(e: PendingInstall): seq[string] = @["gnome-shell"])
    let completion = applyPendingInstalls(root, plan, hooks, store = store)
    check completion.installed.len == 1
    check installed == @["gtk4 4.24.1-1"]
    # The consumer rebuild is still owed, so the record stays.
    let left = loadPendingInstalls(store)
    check left.entries.len == 1
    check left.entries[0].installed == true

    # Once the consumers are rebuilt the record disappears.
    let settle = planPendingInstalls(root, hooksOf(installed = "4.24.1-1"),
        store = store)
    check settle.toInstall.len == 0
    check settle.rebuild.len == 0
    check loadPendingInstalls(store).entries.len == 0

  test "a completed install without consumers is forgotten immediately":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let completion = completePendingInstalls(root, hooksOf(), store = store)
    check completion.installed.len == 1
    check loadPendingInstalls(store).entries.len == 0

  test "an installed provider with consumers outstanding is reported":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let plan = planPendingInstalls(root, hooksOf(installed = "4.24.1-1",
        affected = @["gnome-shell", "nautilus"]), store = store)
    check plan.toInstall.len == 0
    check plan.outstanding.len == 1
    check plan.rebuild == @["gnome-shell", "nautilus"]
    check "consumer rebuild outstanding" in pendingSummary(plan)
    check loadPendingInstalls(store).entries[0].installed

  test "a record whose recipe is gone is held, not installed":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let plan = planPendingInstalls(root, hooksOf(recipe = false), store = store)
    check plan.toInstall.len == 0
    check plan.held.len == 1
    check loadPendingInstalls(store).entries.len == 1

  test "a wiped archive keeps the record pending":
    let store = newStore()
    let (root, archive) = newRoot(false, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let plan = planPendingInstalls(root, hooksOf(), store = store)
    check plan.toInstall.len == 0
    check plan.held.len == 1
    check "gtk4" in pendingSummary(plan)
    check loadPendingInstalls(store).entries.len == 1

  test "a provider whose consumer cannot be rebuilt is held":
    ## Installing it would leave the installed consumer broken for good.
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    var installed: seq[string]
    let hooks = PendingHooks(
      installedVersion: proc(package, root: string): string = "",
      recipePresent: proc(package: string): bool = true,
      rebuildable: proc(package: string): bool = package != "gnome-shell",
      installPackage: proc(e: PendingInstall): bool =
        installed.add(e.package)
        return true,
      affectedConsumers: proc(e: PendingInstall): seq[string] =
        @["gnome-shell"])
    let plan = planPendingInstalls(root, hooks, store = store)
    check plan.toInstall.len == 0
    check plan.held.len == 1
    check plan.rebuild.len == 0
    check installed.len == 0
    check loadPendingInstalls(store).entries.len == 1

  test "a consumer that can be rebuilt lets the provider through":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let hooks = PendingHooks(
      installedVersion: proc(package, root: string): string = "",
      recipePresent: proc(package: string): bool = true,
      rebuildable: proc(package: string): bool = true,
      installPackage: proc(e: PendingInstall): bool = true,
      affectedConsumers: proc(e: PendingInstall): seq[string] =
        @["gnome-shell"])
    let plan = planPendingInstalls(root, hooks, store = store)
    check plan.toInstall.len == 1
    check plan.rebuild == @["gnome-shell"]

  test "a corrupt archive is held with a message naming it":
    let e = PendingInstall(package: "gtk4", version: "4.24.1-1", root: "/x",
        archive: "/var/cache/kpkg/gtk4-4.24.1-1.kpkg")
    let reason = holdReason(e, true, true, true, false, @[], PendingHooks())
    check "corrupt or truncated" in reason
    check e.archive in reason

  test "a failing install keeps the record":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let plan = planPendingInstalls(root, hooksOf(), store = store)
    let completion = applyPendingInstalls(root, plan,
        hooksOf(installOk = false), store = store)
    check completion.installed.len == 0
    check completion.failed.len == 1
    check loadPendingInstalls(store).entries.len == 1

  test "a build that must not install only reports":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    let plan = planPendingInstalls(root, hooksOf(), allowInstall = false,
        store = store)
    check plan.toInstall.len == 0
    check plan.held.len == 1
    check loadPendingInstalls(store).entries.len == 1

  test "another root's record is reported and left alone":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    let (other, otherArchive) = newRoot(true, parentDir(store))
    defer:
      removeDir(root)
      removeDir(other)
      removeDir(parentDir(store))
    upsertPendingInstall(entry(other, otherArchive), store)
    let plan = planPendingInstalls(root, hooksOf(), store = store)
    check plan.toInstall.len == 0
    check plan.otherRoots.len == 1
    check loadPendingInstalls(store).entries.len == 1
    check "gtk4" in pendingSummary(plan)

  test "a record for a root that no longer exists is forgotten":
    let store = newStore()
    let (root, archive) = newRoot(true, parentDir(store))
    defer: removeDir(parentDir(store))
    upsertPendingInstall(entry(root, archive), store)
    removeDir(root)
    let plan = planPendingInstalls(root, hooksOf(), store = store)
    check plan.toInstall.len == 0
    check loadPendingInstalls(store).entries.len == 0
