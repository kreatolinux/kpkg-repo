## A corrupt archive named by the pending store must hold the record instead of
## aborting the build: the plan probes the archive before the installer sees it.
import std/[os, parsecfg, posix_utils, sequtils, tempfiles, unittest]
import ../../../kpkg/modules/builder/[cache, pendingInstalls]
import ../../../kpkg/modules/[checksums, commonPaths, libarchive]

proc buildArchive(path, version: string) =
  ## A binary package archive shaped like the one a build publishes.
  let buildRoot = path & ".d"
  removeDir(buildRoot)
  createDir(buildRoot & "/usr/share/probe")
  writeFile(buildRoot & "/usr/share/probe/version", version & "\n")
  var info = newConfig()
  info.setSectionKey("", "pkgVer", version)
  info.setSectionKey("", "apiVer", "8.0.0")
  info.setSectionKey("", "depends", "")
  info.writeConfig(buildRoot & "/pkgInfo.ini")
  var sums = newConfig()
  for file in toSeq(walkDirRec(buildRoot, {pcFile, pcLinkToFile})):
    let rel = relativePath(file, buildRoot)
    if rel in ["pkgInfo.ini", "pkgsums.ini"]:
      continue
    sums.setSectionKey("", "\"" & rel & "\"", getSum(file, "b2"))
  sums.writeConfig(buildRoot & "/pkgsums.ini")
  createDir(parentDir(path))
  createArchive(path, buildRoot, format = "gnutar", filter = "gzip")
  removeDir(buildRoot)

suite "pending install archive probe":
  test "a truncated archive is held, not handed to the installer":
    if not isAdmin():
      skip()
    else:
      let dir = createTempDir("kpkg-pending-probe-", "")
      defer: removeDir(dir)
      let root = dir / "root"
      createDir(root)
      let good = dir / "gtk4-4.24.1-1.kpkg"
      buildArchive(good, "4.24.1-1")
      let truncated = dir / "gtk4-4.24.1-1.kpkg.partial"
      let content = readFile(good)
      writeFile(truncated, content[0 ..< content.len div 2])
      check not archiveUsable(truncated)
      check archiveUsable(good)

      let store = dir / "pending-installs.json"
      let recorded = PendingInstall(package: "gtk4", version: "4.24.1-1",
          root: canonicalRoot(root), archive: truncated, recordedAt: 1.0)
      upsertPendingInstall(recorded, store)

      var installAttempts = 0
      let hooks = PendingHooks(
        installedVersion: proc(package, root: string): string = "",
        recipePresent: proc(package: string): bool = true,
        archiveUsable: proc(entry: PendingInstall): bool =
          return archiveUsable(entry.archive),
        installPackage: proc(entry: PendingInstall): bool =
          inc installAttempts
          return true)
      let plan = planPendingInstalls(root, hooks, store = store)
      check plan.toInstall.len == 0
      check plan.held.len == 1
      check plan.held[0].archive == truncated
      check installAttempts == 0
      # The obligation is kept: the provider is still not installed.
      check loadPendingInstalls(store).entries.len == 1

      # Applying a plan that still names the corrupt archive must not install it
      # either, so a store edited between the plan and the prompt is harmless.
      let stale = PendingPlan(toInstall: @[PlannedInstall(entry: recorded)])
      let completion = applyPendingInstalls(root, stale, hooks, store = store)
      check completion.failed.len == 1
      check completion.installed.len == 0
      check installAttempts == 0
      check loadPendingInstalls(store).entries.len == 1

      # The same record with a readable archive is installed as before.
      var fixed = loadPendingInstalls(store).entries[0]
      fixed.archive = good
      upsertPendingInstall(fixed, store)
      var installed: seq[string]
      let fixedHooks = PendingHooks(
        installedVersion: proc(package, root: string): string = "",
        recipePresent: proc(package: string): bool = true,
        archiveUsable: proc(entry: PendingInstall): bool =
          return archiveUsable(entry.archive),
        installPackage: proc(entry: PendingInstall): bool =
          installed.add(entry.package & " " & entry.version)
          return true)
      let fixedPlan = planPendingInstalls(root, fixedHooks, store = store)
      check fixedPlan.toInstall.len == 1
      let completed = applyPendingInstalls(root, fixedPlan, fixedHooks,
          store = store)
      check completed.installed.len == 1
      check installed == @["gtk4 4.24.1-1"]
      check loadPendingInstalls(store).entries.len == 0
