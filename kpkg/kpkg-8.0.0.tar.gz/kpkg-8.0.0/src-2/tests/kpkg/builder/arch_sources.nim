## Builder-side selection of per-architecture sources.
##
## `runparser` decides *which* entries a build gets; the builder must act on
## exactly those: only the target arch's archive is staged into the source
## directory, its checksum is verified against that group's list, and the other
## architecture's file is never touched.

import std/[os, strutils, tempfiles, unittest]
import ../../../kpkg/modules/runparser
import ../../../kpkg/modules/checksums
import ../../../kpkg/modules/builder/sources

proc makeRecipe(root, archBody: string): string =
  ## A recipe directory with one common local patch and arch-specific "binary"
  ## files, which the builder stages as local sources (no download).
  result = root / "vivaldi"
  createDir(result)
  writeFile(result / "shared.patch", "patch body\n")
  writeFile(result / "tool-arm64.tar.gz", "arm64 payload\n")
  writeFile(result / "tool-amd64.tar.gz", "amd64 payload\n")
  writeFile(result / "run3", """
name: "vivaldi"
version: "1.0"
release: "1"
extract: false
sources:
  - "shared.patch"
sha256sum:
  - "common-sum"
""" & archBody)

suite "builder per-architecture source selection":
  setup:
    let work = createTempDir("kpkg-builder-arch-", "")
  teardown:
    removeDir(work)

  test "only the target arch's archive is staged":
    let recipe = makeRecipe(work, """
sources_arm64:
  - "tool-arm64.tar.gz"
sha256sum_arm64:
  - "arm-sum"
sources_amd64:
  - "tool-amd64.tar.gz"
sha256sum_amd64:
  - "amd-sum"
""")
    let sourceDir = work / "src-arm"
    createDir(sourceDir)

    let arm = parseRunfile(recipe, arch = "aarch64")
    check arm.sources.len == 2
    # Local files are staged by verifyChecksum; SKIP keeps the sums unfetched
    # while still exercising the staging path.
    var local: runFile = arm
    for i in 0 ..< local.sources.len:
      local.sources[i].sha256sum = "SKIP"
    sourceDownloader(local, "vivaldi", sourceDir, recipe)

    check fileExists(sourceDir / "shared.patch")
    check fileExists(sourceDir / "tool-arm64.tar.gz")
    check not fileExists(sourceDir / "tool-amd64.tar.gz")

  test "the other architecture's archive is the one staged when it is the target":
    let recipe = makeRecipe(work, """
sources_arm64:
  - "tool-arm64.tar.gz"
sha256sum_arm64:
  - "arm-sum"
sources_amd64:
  - "tool-amd64.tar.gz"
sha256sum_amd64:
  - "amd-sum"
""")
    let sourceDir = work / "src-x86"
    createDir(sourceDir)

    var x86 = parseRunfile(recipe, arch = "x86_64")
    for i in 0 ..< x86.sources.len:
      x86.sources[i].sha256sum = "SKIP"
    sourceDownloader(x86, "vivaldi", sourceDir, recipe)

    check fileExists(sourceDir / "shared.patch")
    check fileExists(sourceDir / "tool-amd64.tar.gz")
    check not fileExists(sourceDir / "tool-arm64.tar.gz")

  test "an unsupported architecture stages only the common sources":
    let recipe = makeRecipe(work, """
sources_arm64:
  - "tool-arm64.tar.gz"
sha256sum_arm64:
  - "arm-sum"
""")
    let sourceDir = work / "src-riscv"
    createDir(sourceDir)

    var riscv = parseRunfile(recipe, arch = "riscv64")
    check riscv.sources.len == 1
    riscv.sources[0].sha256sum = "SKIP"
    sourceDownloader(riscv, "vivaldi", sourceDir, recipe)

    check fileExists(sourceDir / "shared.patch")
    check not fileExists(sourceDir / "tool-arm64.tar.gz")

  test "an arch group checksum mismatch fails the build":
    # The arch group's own sum is what gets verified: a sum from the other
    # group must not be accepted.
    let recipe = makeRecipe(work, """
sources_arm64:
  - "tool-arm64.tar.gz"
sha256sum_arm64:
  - "0000000000000000000000000000000000000000000000000000000000000000"
""")
    let sourceDir = work / "src-bad"
    createDir(sourceDir)

    let arm = parseRunfile(recipe, arch = "aarch64")
    # verifyChecksum calls quit(1) on a mismatch, so drive the comparison the
    # way the builder does and assert on the result instead of exiting.
    check arm.sources[1].url == "tool-arm64.tar.gz"
    check arm.sources[1].sha256sum ==
      "0000000000000000000000000000000000000000000000000000000000000000"
    check not cachedSourceMatches(recipe / "tool-arm64.tar.gz", arm.sources[1])

  test "a matching arch group checksum is accepted by the cache check":
    let recipe = makeRecipe(work, "")
    let sums = getSum(recipe / "tool-arm64.tar.gz", "sha256")
    let entry: SourceEntry = (url: "tool-arm64.tar.gz", sha256sum: sums,
      sha512sum: "", b2sum: "")
    check cachedSourceMatches(recipe / "tool-arm64.tar.gz", entry)
    let wrong: SourceEntry = (url: "tool-arm64.tar.gz", sha256sum: "beef",
      sha512sum: "", b2sum: "")
    check not cachedSourceMatches(recipe / "tool-arm64.tar.gz", wrong)
