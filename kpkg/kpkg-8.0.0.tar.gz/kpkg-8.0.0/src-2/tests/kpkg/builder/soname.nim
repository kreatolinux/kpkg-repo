import unittest
import std/os
import ../../../kpkg/modules/builder/soname

suite "SONAME change detection":

  test "getBuildSonames finds versioned .so files":
    let testDir = getTempDir() / "kpkg_soname_test"
    createDir(testDir / "usr" / "lib")

    writeFile(testDir / "usr" / "lib" / "libssl.so.4", "")
    writeFile(testDir / "usr" / "lib" / "libcrypto.so.81", "")
    writeFile(testDir / "usr" / "lib" / "libfoo.a", "")
    writeFile(testDir / "usr" / "lib" / "libbar.so", "")

    let sonames = getBuildSonames(testDir)

    check sonames.len == 2
    check "libssl.so.4" in sonames
    check "libcrypto.so.81" in sonames

    removeDir(testDir)

  test "getBuildSonames counts libfoo.so.N symlinks like installed lists do":
    ## The installed side lists libpam.so.0 (a symlink) and libpam.so.0.85.1.
    ## Without the symlink an unchanged library looks like a SONAME change
    ## and queues consumer rebuilds.
    let testDir = getTempDir() / "kpkg_soname_links"
    createDir(testDir / "usr" / "lib64")
    writeFile(testDir / "usr" / "lib64" / "libpam.so.0.85.1", "")
    createSymlink("libpam.so.0.85.1", testDir / "usr" / "lib64" / "libpam.so.0")
    createSymlink("libpam.so.0", testDir / "usr" / "lib64" / "libpam.so")

    let sonames = getBuildSonames(testDir)
    check sonames.len == 2
    check "libpam.so.0" in sonames
    check "libpam.so.0.85.1" in sonames

    removeDir(testDir)

  test "getBuildSonames returns empty for non-library builds":
    let testDir = getTempDir() / "kpkg_soname_test2"
    createDir(testDir / "usr" / "bin")
    writeFile(testDir / "usr" / "bin" / "git", "")

    let sonames = getBuildSonames(testDir)
    check sonames.len == 0

    removeDir(testDir)

  test "parseNeededSonames finds ELF NEEDED libraries":
    let readelfOutput = """
Dynamic section at offset 0x2dd8 contains 29 entries:
  Tag        Type                         Name/Value
 0x0000000000000001 (NEEDED)             Shared library: [libssl.so.3]
 0x0000000000000001 (NEEDED)             Shared library: [libcrypto.so.3]
 0x000000000000001d (RUNPATH)            Library runpath: [/usr/lib]
"""

    let needed = parseNeededSonames(readelfOutput)

    check needed == @["libssl.so.3", "libcrypto.so.3"]

  test "orderSonameConsumers places rebuilt runtime deps first":
    let ordered = orderSonameConsumers(@["git", "curl", "libarchive"],
        proc(pkg: string): seq[string] =
      if pkg == "git":
        return @["curl", "openssl"]
      return @[])

    check ordered == @["curl", "git", "libarchive"]

  test "parseSoname reads DT_SONAME":
    let readelfOutput = """
Dynamic section at offset 0x1c3d58 contains 30 entries:
  Tag        Type                         Name/Value
 0x0000000000000001 (NEEDED)             Shared library: [libglib-2.0.so.0]
 0x000000000000000e (SONAME)             Library soname: [libgtk-4.so.1]
"""
    check parseSoname(readelfOutput) == "libgtk-4.so.1"
    check parseSoname("no dynamic section") == ""

  test "sonameFromFileName keeps only the major version":
    check sonameFromFileName("libgtk-4.so.1.2400.1") == "libgtk-4.so.1"
    check sonameFromFileName("libssl.so.3") == "libssl.so.3"
    check sonameFromFileName("libpython3.14.so.1.0") == "libpython3.14.so.1"
    check sonameFromFileName("libfoo.so") == ""
    check sonameFromFileName("gdk-pixbuf-loader.so.1") == ""

  test "a minor library upgrade is not a SONAME change":
    let oldDir = getTempDir() / "kpkg_soname_old"
    let newDir = getTempDir() / "kpkg_soname_new"
    for d in [oldDir, newDir]:
      removeDir(d)
      createDir(d / "usr" / "lib")
    writeFile(oldDir / "usr/lib/libgtk-4.so.1.2000.4", "")
    createSymlink("libgtk-4.so.1.2000.4", oldDir / "usr/lib/libgtk-4.so.1")
    writeFile(newDir / "usr/lib/libgtk-4.so.1.2400.1", "")
    createSymlink("libgtk-4.so.1.2400.1", newDir / "usr/lib/libgtk-4.so.1")
    var oldFiles, newFiles: seq[string]
    for f in walkDirRec(oldDir, yieldFilter = {pcFile, pcLinkToFile}): oldFiles.add(f)
    for f in walkDirRec(newDir, yieldFilter = {pcFile, pcLinkToFile}): newFiles.add(f)
    check sonamesOf(oldFiles) == @["libgtk-4.so.1"]
    check sonamesOf(newFiles) == sonamesOf(oldFiles)
    removeDir(oldDir)
    removeDir(newDir)

  test "a major bump is a SONAME change":
    let d = getTempDir() / "kpkg_soname_bump"
    removeDir(d)
    createDir(d / "usr" / "lib")
    writeFile(d / "usr/lib/libssl.so.4.0.0", "")
    check sonamesOf(@[d / "usr/lib/libssl.so.4.0.0"]) == @["libssl.so.4"]
    check "libssl.so.3" notin sonamesOf(@[d / "usr/lib/libssl.so.4.0.0"])
    removeDir(d)

  test "real ELF libraries report their DT_SONAME":
    # Uses the build host's own libc when readelf is available.
    for lib in ["/usr/lib/libc.so.6", "/lib/libc.so.6"]:
      if fileExists(lib) and not symlinkExists(lib) and findExe("readelf").len > 0:
        check sonamesOf(@[lib]) == @["libc.so.6"]
        break
