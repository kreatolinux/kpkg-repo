## The store is written by more than one kpkg process, so every read-modify-write
## holds a lock next to it; a second writer waits instead of losing an update.
import std/[os, osproc, posix, strutils, tempfiles, unittest]
import ../../../kpkg/modules/builder/pendingInstalls

const recorderArg = "--record-pending"

if isMainModule and paramCount() >= 4 and paramStr(1) == recorderArg:
  ## Recorder process of the lock test below: one store write, then exit.
  upsertPendingInstall(PendingInstall(package: paramStr(3), version: "1-1",
      root: paramStr(4), archive: paramStr(4) & "/a.kpkg", recordedAt: 1.0),
      paramStr(2))
  quit(0)

proc holdStoreLock(store: string): cint =
  ## Take the store lock the way another kpkg process would.
  createDir(parentDir(store))
  result = posix.open((store & ".lock").cstring, O_CREAT or O_RDWR, Mode(0o600))
  if result < 0:
    return result
  var lock = Tflock(l_type: cshort(F_WRLCK), l_whence: cshort(SEEK_SET),
      l_start: Off(0), l_len: Off(0))
  if fcntl(result, F_SETLK, addr lock) != 0:
    discard posix.close(result)
    return -1

proc releaseStoreLock(fd: cint) =
  var lock = Tflock(l_type: cshort(F_UNLCK), l_whence: cshort(SEEK_SET),
      l_start: Off(0), l_len: Off(0))
  discard fcntl(fd, F_SETLK, addr lock)
  discard posix.close(fd)

suite "pending install store locking":
  test "a second writer waits for the store lock":
    let dir = createTempDir("kpkg-pending-lock-", "")
    let store = dir / "pending-installs.json"
    let root = dir / "root"
    createDir(root)
    defer: removeDir(dir)
    let fd = holdStoreLock(store)
    check fd >= 0
    let child = startProcess(getAppFilename(),
        args = @[recorderArg, store, "gtk4", canonicalRoot(root)],
        options = {poUsePath})
    defer:
      if running(child):
        terminate(child)
      discard waitForExit(child)
    sleep(500)
    # The child is blocked on the lock, so nothing was written yet.
    check running(child)
    check loadPendingInstalls(store).entries.len == 0
    releaseStoreLock(fd)
    check waitForExit(child) == 0
    let recorded = loadPendingInstalls(store)
    check recorded.entries.len == 1
    check recorded.entries[0].package == "gtk4"

  test "a completed write leaves no partial file behind":
    let dir = createTempDir("kpkg-pending-write-", "")
    let store = dir / "pending-installs.json"
    defer: removeDir(dir)
    upsertPendingInstall(PendingInstall(package: "gtk4", version: "1-1",
        root: "/x", archive: "/x/a.kpkg", recordedAt: 1.0), store)
    for kind, path in walkDir(dir):
      check ".partial-" notin path
