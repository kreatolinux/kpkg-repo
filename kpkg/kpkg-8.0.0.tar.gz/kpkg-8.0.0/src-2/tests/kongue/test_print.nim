## Tests for kongue `print`: a statement argument is kept as expression source,
## so a quoted literal has to be decoded before it reaches stdout -- `print "x"`
## must write `x`, not `"x"`.
import std/[os, strutils, unittest]

import posix

import ../../kongue/builtins
import ../../kongue/context
import ../../kongue/executor
import ../../kongue/lexer
import ../../kongue/parser

var root: string

proc runScript(script: string, setup: proc(ctx: ExecutionContext) = nil): int =
  var p = initParser(tokenize(script))
  let parsed = p.parse()
  let ctx = initExecutionContext(destDir = root, buildRoot = root)
  ctx.loadVariablesFromParsed(parsed)
  ctx.loadAllFunctions(parsed)
  if setup != nil: setup(ctx)
  ctx.executeFunctionByName(parsed, "build")

proc printed(script: string, setup: proc(ctx: ExecutionContext) = nil): string =
  ## Run the script's build function and return everything it wrote to stdout.
  var fds: array[2, cint]
  check pipe(fds) == 0
  flushFile(stdout)
  let saved = dup(STDOUT_FILENO)
  check saved >= 0
  discard dup2(fds[1], STDOUT_FILENO)
  try:
    check runScript(script, setup) == 0
  finally:
    flushFile(stdout)
    discard dup2(saved, STDOUT_FILENO)
    discard close(saved)
    discard close(fds[1])
  var buffer: array[512, char]
  while true:
    let count = read(fds[0], addr buffer[0], buffer.len)
    if count <= 0:
      break
    for i in 0 ..< int(count): result.add buffer[i]
  discard close(fds[0])

suite "kongue print: a literal is printed as its text":
  setup:
    root = getTempDir() / "kongue-print-test-" & $getCurrentProcessId()
    createDir(root)
  teardown:
    removeDir(root)

  test "a quoted literal prints without its quotes":
    check printed("build {\n  print \"hello\"\n}\n") == "hello\n"

  test "a quoted literal holding a reference prints the value":
    check printed("NAME: \"world\"\nbuild {\n  print \"hello $NAME\"\n}\n") ==
      "hello world\n"

  test "a quoted literal holding an expression prints its result":
    check printed("NAME: \"world\"\nbuild {\n  print \"${NAME.upper()}\"\n}\n") ==
      "WORLD\n"

  test "an unquoted reference and text keep working":
    check printed("NAME: \"world\"\nbuild {\n  print hello ${NAME}\n}\n") ==
      "hello world\n"

  test "a bare reference prints its value":
    check printed("V: \"a b\"\nbuild {\n  print $V\n}\n") == "a b\n"

  test "escaping inside the literal is decoded once":
    check printed("build {\n  print \"a\\nb\\tc\"\n}\n") == "a\nb\tc\n"

  test "an escaped dollar is printed literally":
    check printed("build {\n  print \"cost \\$5\"\n}\n") == "cost $5\n"

  test "padding written inside the quotes is kept":
    check printed("build {\n  print \"  padded  \"\n}\n") == "  padded  \n"

  test "a value that looks like a reference is not resolved twice":
    # The interpolated value is inserted verbatim, so its own `$` stays.
    check printed("build {\n  print \"[$V]\"\n}\n", proc(ctx: ExecutionContext) =
      ctx.setVariable("V", "$NAME")) == "[$NAME]\n"

  test "two literals written on one line print with the space between them":
    check printed("build {\n  print \"a\" \"b\"\n}\n") == "a b\n"

  test "silent mode prints nothing at all":
    var fds: array[2, cint]
    check pipe(fds) == 0
    flushFile(stdout)
    let saved = dup(STDOUT_FILENO)
    check saved >= 0
    discard dup2(fds[1], STDOUT_FILENO)
    var ctx: ExecutionContext
    try:
      ctx = initExecutionContext(destDir = root, buildRoot = root)
      ctx.silent = true
      ctx.builtinPrint("\"quiet\"")
    finally:
      flushFile(stdout)
      discard dup2(saved, STDOUT_FILENO)
      discard close(saved)
      discard close(fds[1])
    var buffer: array[64, char]
    check read(fds[0], addr buffer[0], buffer.len) == 0
    discard close(fds[0])
