## Header values: a `key:` value and a list item are the rest of their line, so
## a reference such as `- $dep`, a `${...}` or an unquoted multi-word value is
## kept as text instead of being cut at the first token.

import std/[unittest, strutils]
import ../../kongue/[lexer, parser, ast]
import ../../kongue/[context, builtins]
import ../../kongue/utils

proc parseAll(script: string): ParsedScript =
  var p = initParser(tokenize(script))
  p.parse()

proc variablesOf(script: string): seq[AstNode] =
  parseAll(script).variables

proc valueOf(script, name: string): string =
  for v in variablesOf(script):
    if v.kind == nkVariable and v.varName == name:
      return v.varValue

proc listOf(script, name: string): seq[string] =
  for v in variablesOf(script):
    if v.kind == nkListVariable and v.listName == name:
      return v.listItems

# Warnings are collected through utils.warnProc instead of stderr.
var warnings: seq[string] = @[]

proc captureWarn(msg: string) =
  warnings.add(msg)

proc warningsOf(script: string): seq[string] =
  warnings = @[]
  utils.warnProc = captureWarn
  try:
    discard parseAll(script)
  finally:
    utils.warnProc = nil
  warnings

suite "kongue header values: a list item keeps its text":
  test "a reference is kept for the reader that resolves it":
    let script = """dep: "glib"
depends:
  - $dep
"""
    let items: seq[string] = listOf(script, "depends")
    check items == @["$dep"]

  test "a braced reference is kept too":
    let script = """dep: "glib"
depends:
  - ${dep}
  - $dep$version
"""
    let items: seq[string] = listOf(script, "depends")
    check items == @["${dep}", "$dep$version"]

  test "an unquoted multi-word item is the whole line":
    let script = """test2:
  - this is a test
  - foo bar
"""
    let items: seq[string] = listOf(script, "test2")
    check items == @["this is a test", "foo bar"]

  test "quoted parts are joined with the source's own spacing":
    let script = """s:
  - "a" "b"
  - "c"
"""
    let items: seq[string] = listOf(script, "s")
    check items == @["a b", "c"]

  test "punctuation inside an unquoted item is part of it":
    let script = """s:
  - foo/bar
  - a.b
"""
    let items: seq[string] = listOf(script, "s")
    check items == @["foo/bar", "a.b"]

  test "a list item with a reference does not warn":
    let script = """depends:
  - $dep
"""
    let w: seq[string] = warningsOf(script)
    check w.len == 0

  test "the reader that resolves values still sees them":
    var ctx = initExecutionContext()
    ctx.setVariable("dep", "glib")
    check ctx.resolveVariables("$dep") == "glib"

suite "kongue header values: a key's value is the rest of its line":
  test "an unquoted multi-word value keeps every word":
    let script = "summary: words here\n"
    check valueOf(script, "summary") == "words here"
    check warningsOf(script).len == 0

  test "a braced reference is kept as text":
    check valueOf("""base: "/usr"
prefix: ${base}/local
""", "prefix") == "${base}/local"

  test "a bare reference is kept as text":
    check valueOf("""base: "/usr"
prefix: $base/local
""", "prefix") == "$base/local"

  test "a quoted value loses its quotes, as before":
    check valueOf("""name: "example"
""", "name") == "example"

  test "a value glued to a quoted string keeps its spacing":
    check valueOf("""version: "1.0"
tag: "v"${version}-rc
""", "tag") == "v${version}-rc"

  test "a lone number and a lone word are unchanged":
    check valueOf("""release: "1"
arch: x86_64
""", "arch") == "x86_64"

  test "a key with nothing on its line stays empty":
    let vals = variablesOf("""empty:
  # nothing here
""")
    check vals.len == 1
    check vals[0].varValue == ""

  test "a value on the following line is not the key's value":
    # A nested block belongs to the key; a bare value must be written on the
    # key's line (kongue(5), STRUCTURED HEADER VALUES).
    let w = warningsOf("""name:
  "example"
""")
    check w.len == 1
    check "outside a header field or function block" in w[0]

suite "kongue header values: object properties":
  test "an object property keeps the whole value":
    let vars = variablesOf("""object o {
  k: a b
}
""")
    check vars.len == 1
    check vars[0].kind == nkObject
    check vars[0].objectProperties[0].value == "a b"

  test "an object property takes a reference":
    check variablesOf("""object o {
  k: ${base}
}
""")[0].objectProperties[0].value == "${base}"

  test "an inline object's property takes only its own line":
    let script = """supervisor:
  executable: "bin/x"
  supported_ops:
    - name: "a"
"""
    let vars = variablesOf(script)
    check vars[0].kind == nkObject
    check vars[0].objectProperties.len == 2
    check vars[0].objectProperties[0].key == "executable"
    check vars[0].objectProperties[0].value == "bin/x"
    # The nested sequence is not part of the inline-object form: it is reported,
    # never absorbed as the previous key's value.
    check vars[0].objectProperties[1].key == "supported_ops"
    check vars[0].objectProperties[1].value == ""
    check warningsOf(script).len == 1
