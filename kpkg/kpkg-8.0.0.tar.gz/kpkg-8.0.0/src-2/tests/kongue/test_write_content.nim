## Tests for kongue `write` / `append` content handling.
##
## The parser keeps statement arguments as expression source, re-quoting every
## string literal and re-escaping its contents (parser.nim
## escapeStringForOutput), so the builtins must undo that before writing: a
## multi-line """...""" body has to reach the file with real newlines.
import unittest
import os
import strutils

import ../../kongue/context
import ../../kongue/builtins
import ../../kongue/lexer
import ../../kongue/parser
import ../../kongue/executor
import ../../kongue/utils

const tq = "\"\"\""

var root: string

proc newCtx(): ExecutionContext =
  result = initExecutionContext(destDir = root, buildRoot = root)
  result.silent = true

proc runScript(script: string, setup: proc(ctx: ExecutionContext) = nil): int =
  var p = initParser(tokenize(script))
  let parsed = p.parse()
  let ctx = newCtx()
  ctx.loadVariablesFromParsed(parsed)
  ctx.loadAllFunctions(parsed)
  if setup != nil: setup(ctx)
  ctx.executeFunctionByName(parsed, "build")

proc runWrite(path, body: string): string =
  ## Run `write "<path>" """\n<body>"""` and return the written bytes.
  let script = "build {\n  write \"" & path & "\" " & tq & "\n" & body & tq & "\n}\n"
  check runScript(script) == 0
  readFile(path.replace("$ROOT", root))

suite "kongue write: string literal decoding":
  setup:
    root = getTempDir() / "kongue-write-test-" & $getCurrentProcessId()
    createDir(root)
  teardown:
    removeDir(root)

  test "triple-quoted multi-line content keeps real newlines":
    check runWrite("$ROOT/a.txt", "line 1\nline 2\n\n  indented\n") ==
      "line 1\nline 2\n\n  indented\n"

  test "triple-quoted strings are raw: backslashes and quotes verbatim":
    let body = "#!/bin/sh\nprintf '%s\\n' \"$@\" | tr -d \"\\\\\"\necho \"a\\tb\" \\\n  done\n"
    check runWrite("$ROOT/raw.sh", body) == body

  test "triple-quoted content interpolates $VAR and ${...}":
    let script = "NAME: \"pkg\"\nbuild {\n  local V = \"val\"\n  write \"$ROOT/i.txt\" " &
      tq & "\nname=$NAME v=$V up=${V.upper()} cut=${NAME.cut(0, 2)}\n" & tq & "\n}\n"
    check runScript(script) == 0
    check readFile(root / "i.txt") == "name=pkg v=val up=VAL cut=pk\n"

  test "normal double-quoted string processes documented escapes":
    let script = "build {\n  write \"$ROOT/n.txt\" \"a\\nb\\tc \\\"q\\\" \\\\ d\"\n}\n"
    check runScript(script) == 0
    check readFile(root / "n.txt") == "a\nb\tc \"q\" \\ d"

  test "single-quoted string behaves like double-quoted":
    let script = "build {\n  write \"$ROOT/s.txt\" 'x\\ny \"z\"'\n}\n"
    check runScript(script) == 0
    check readFile(root / "s.txt") == "x\ny \"z\""

  test "interpolated values are inserted verbatim (no escape processing)":
    let script = "build {\n  write \"$ROOT/v.txt\" \"[$V]\"\n}\n"
    check runScript(script, proc(ctx: ExecutionContext) =
      ctx.setVariable("V", "C:\\new \"x\"")) == 0
    check readFile(root / "v.txt") == "[C:\\new \"x\"]"

  test "${...} with nested quoted arguments still resolves":
    let script = "NAME: \"a-b-c\"\nbuild {\n  write \"$ROOT/m.txt\" \"${NAME.replace(\"-\", \"_\")}\\n\"\n}\n"
    check runScript(script) == 0
    check readFile(root / "m.txt") == "a_b_c\n"

  test "append decodes the same way (systemd ln-wrapper style)":
    let script = "build {\n" &
      "  write \"$ROOT/ln\" \"#!/bin/sh\\n\"\n" &
      "  append \"$ROOT/ln\" \"ARGS=$(echo $@ | sed \\\"s/--relative/-r/g;s/--help//g\\\")\\n\"\n" &
      "  append \"$ROOT/ln\" " & tq & "\nexit 0\n" & tq & "\n" &
      "}\n"
    check runScript(script) == 0
    check readFile(root / "ln") ==
      "#!/bin/sh\nARGS=$(echo $@ | sed \"s/--relative/-r/g;s/--help//g\")\nexit 0\n"

  test "bare variable content is written unchanged":
    let script = "build {\n  write \"$ROOT/b.txt\" $V\n}\n"
    check runScript(script, proc(ctx: ExecutionContext) =
      ctx.setVariable("V", "one\ntwo")) == 0
    check readFile(root / "b.txt") == "one\ntwo"

  test "direct builtin call with unquoted content keeps legacy behaviour":
    let ctx = newCtx()
    ctx.builtinWrite(root / "d.txt", "Line 1")
    ctx.builtinAppend(root / "d.txt", "\nLine 2")
    check readFile(root / "d.txt") == "Line 1\nLine 2"

suite "decodeStringExpr":
  test "unescapes a parser-quoted literal":
    check decodeStringExpr("\"a\\nb\\t\\\"c\\\" \\\\\"") == ("a\nb\t\"c\" \\", true)
  test "keeps ${...} regions verbatim, inside and outside literals":
    check decodeStringExpr("\"x ${f(\\\"a\\\")} y\"").text == "x ${f(\\\"a\\\")} y"
    check decodeStringExpr("${V.split(\".\")}").text == "${V.split(\".\")}"
  test "unquoted text and regex literals are untouched":
    check decodeStringExpr("$V") == ("$V", false)
    check decodeStringExpr("e\"a\\nb\"") == ("e\"a\\nb\"", false)

suite "kongue write: Kreato recipe bodies are written byte-exact":
  setup:
    root = getTempDir() / "kongue-recipe-test-" & $getCurrentProcessId()
    createDir(root / "etc/pam.d")
    createDir(root / "etc/polkit-1/rules.d")
    createDir(root / "usr/aarch64-linux-gnu")
  teardown:
    removeDir(root)

  test "sudo: etc/pam.d/sudo":
    let body =
      "# Begin /etc/pam.d/sudo\n" &
      "\n" &
      "# include the default auth settings\n" &
      "auth      include     system-auth\n" &
      "\n" &
      "# include the default account settings\n" &
      "account   include     system-account\n" &
      "\n" &
      "# Set default environment variables for the service user\n" &
      "session   required    pam_env.so\n" &
      "\n" &
      "# include system session defaults\n" &
      "session   include     system-session\n" &
      "\n" &
      "# End /etc/pam.d/sudo\n"
    check runWrite("$ROOT/etc/pam.d/sudo", body) == body

  test "accountsservice: etc/polkit-1/rules.d/40-wheel.rules":
    let body =
      "polkit.addAdminRule(function(action, subject) {\n" &
      " return [\"unix-group:wheel\"];\n" &
      "});\n"
    check runWrite("$ROOT/etc/polkit-1/rules.d/40-wheel.rules", body) == body

  test "gcc: usr/aarch64-linux-gnu/aarch64-linux-gnu-meson.txt":
    let body =
      "[binaries]\n" &
      "c = 'aarch64-linux-gnu-gcc'\n" &
      "cpp = 'aarch64-linux-gnu-g++'\n" &
      "ar = 'aarch64-linux-gnu-ar'\n" &
      "strip = 'aarch64-linux-gnu-strip'\n" &
      "\n" &
      "[host_machine]\n" &
      "system = 'linux'\n" &
      "cpu_family = 'aarch64'\n" &
      "cpu = 'aarch64'\n" &
      "endian = 'little'\n"
    check runWrite("$ROOT/usr/aarch64-linux-gnu/aarch64-linux-gnu-meson.txt", body) == body

  test "gcc: usr/aarch64-linux-gnu/aarch64-linux-gnu.cmake":
    let body =
      "# the name of the target operating system\n" &
      "set(CMAKE_SYSTEM_NAME Linux)\n" &
      "\n" &
      "# which compilers to use for C and C++\n" &
      "set(CMAKE_C_COMPILER   aarch64-linux-gnu-gcc)\n" &
      "set(CMAKE_CXX_COMPILER aarch64-linux-gnu-g++)\n" &
      "\n" &
      "# where is the target environment located\n" &
      "set(CMAKE_FIND_ROOT_PATH /usr/aarch64-linux-gnu)\n" &
      "\n" &
      "# adjust the default behavior of the FIND_XXX() commands:\n" &
      "# search programs in the host environment\n" &
      "set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)\n" &
      "\n" &
      "# search headers and libraries in the target environment\n" &
      "set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)\n" &
      "set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)\n"
    check runWrite("$ROOT/usr/aarch64-linux-gnu/aarch64-linux-gnu.cmake", body) == body

  test "opendoas: etc/pam.d/doas":
    let body =
      "# Begin /etc/pam.d/doas\n" &
      "\n" &
      "# include the default auth settings\n" &
      "auth      include     system-auth\n" &
      "\n" &
      "# include the default account settings\n" &
      "account   include     system-account\n" &
      "\n" &
      "# Set default environment variables for the service user\n" &
      "session   required    pam_env.so\n" &
      "\n" &
      "# include system session defaults\n" &
      "session   include     system-session\n" &
      "\n" &
      "# End /etc/pam.d/doas\n"
    check runWrite("$ROOT/etc/pam.d/doas", body) == body

  test "systemd: etc/pam.d/systemd-user":
    let body =
      "# Begin /etc/pam.d/systemd-user\n" &
      "\n" &
      "account  required    pam_access.so\n" &
      "account  include     system-account\n" &
      "\n" &
      "session  required    pam_env.so\n" &
      "session  required    pam_limits.so\n" &
      "session  required    pam_unix.so\n" &
      "session  required    pam_loginuid.so\n" &
      "session  optional    pam_keyinit.so force revoke\n" &
      "session  optional    pam_systemd.so\n" &
      "\n" &
      "auth     required    pam_deny.so\n" &
      "password required    pam_deny.so\n" &
      "\n" &
      "# End /etc/pam.d/systemd-user\n"
    check runWrite("$ROOT/etc/pam.d/systemd-user", body) == body
