import std/unittest
import ../../kongue/[lexer, parser, ast]

proc listOf(script, name: string): seq[string] =
  var p = initParser(tokenize(script))
  for v in p.parse().variables:
    if v.kind == nkListVariable and v.listName == name:
      return v.listItems

suite "Kongue lists with comments":
  test "comment lines between items keep the following items":
    let script = """
build_depends:
  - "meson"
  - "ninja"
  # msgfmt, for the translations
  - "gettext"
  # man pages
  - "libxslt"
  - "docbook-xsl"
"""
    check listOf(script, "build_depends") ==
        @["meson", "ninja", "gettext", "libxslt", "docbook-xsl"]

  test "comment right after the key":
    let script = """
depends:
  # runtime
  - "glib"
  - "gtk4"
"""
    check listOf(script, "depends") == @["glib", "gtk4"]

  test "a trailing comment does not swallow the next declaration":
    let script = """
depends:
  - "glib"
  # end of list
release: "2"
"""
    var p = initParser(tokenize(script))
    let parsed = p.parse()
    check parsed.variables.len == 2
    check listOf(script, "depends") == @["glib"]
