## Statement shapes: the spacing `print` and `if` keep, a `${...}` written as
## source (`${spawn("x")}`, `${v[${i}]}`), what an `exec(...)` argument list
## means, and the two statements that must not swallow the rest of their line.

import std/[unittest, strutils, tables]
import ../../kongue/[lexer, parser, ast, manifest]
import ../../kongue/[context, executor, builtins, variables, utils]

const header = "name: \"pkg\"\nversion: \"1.0\"\n\n"

var
  execLog: seq[string]
  execOutput: string
  errors: seq[string]

proc stubExec(ctx: ExecutionContext, command: string, silent: bool):
    tuple[output: string, exitCode: int] {.nimcall.} =
  execLog.add command
  (execOutput, 0)

proc captureError(msg: string) =
  errors.add(msg)

proc statementsOf(body: string): seq[AstNode] =
  var p = initParser(tokenize(header & "build {\n" & body & "}\n"))
  for fn in p.parse().functions:
    if fn.funcName == "build":
      return fn.funcBody
  return @[]

proc runBuild(body: string, output = "out"): ExecutionContext =
  ## Parse and run ``build { <body> }`` against the stub shell.
  execLog = @[]
  errors = @[]
  execOutput = output
  var p = initParser(tokenize(header & "build {\n" & body & "}\n"))
  let parsed = p.parse()
  result = initExecutionContext()
  result.silent = true
  result.execHook = stubExec
  result.loadVariablesFromParsed(parsed)
  result.loadAllFunctions(parsed)
  # Resolution reports a bad `${...}` through utils.errorProc.
  utils.errorProc = captureError
  try:
    check result.executeFunctionByName(parsed, "build") == 0
  finally:
    utils.errorProc = nil

type ParseFailure = object
  raised: bool
  msg: string
  line: int

proc failureOf(script: string): ParseFailure =
  try:
    var p = initParser(tokenize(script))
    discard p.parse()
  except ParseError as e:
    return ParseFailure(raised: true, msg: e.msg, line: e.line)
  ParseFailure(raised: false)

suite "kongue statements: print keeps the source's spacing":
  test "a reference stays glued to its neighbours":
    let stmts = statementsOf("print hello${name}!\n")
    check stmts[0].printText == "hello${name}!"

  test "spacing the source wrote is kept":
    check statementsOf("print hello ${name} !\n")[0].printText == "hello ${name} !"

  test "quoted strings keep the adjacency they were written with":
    check statementsOf("print \"a\"${name}\"b\"\n")[0].printText == "\"a\"${name}\"b\""

  test "a trailing ! is part of the text, not the next statement":
    let ctx = runBuild("print done${name}!\n")
    let got: seq[string] = errors
    check got.len == 0

  test "the runtime resolves it to one word":
    var ctx = initExecutionContext()
    ctx.setVariable("name", "N")
    check ctx.resolveVariables("hello${name}!") == "helloN!"

suite "kongue statements: a ${...} argument is one expression":
  test "print takes a call that is not exec":
    check statementsOf("print ${spawn(\"x\", \"-y\")}\n")[0].printText ==
      "${spawn(\"x\", \"-y\")}"

  test "an if condition takes one too":
    check statementsOf("if ${spawn(\"x\")} {\n  exec \"true\"\n}\n")[0].condition ==
      "${spawn(\"x\")}"

  test "a documented condition keeps its shape":
    check statementsOf("if ${exec(\"command -v x\").exit()} == 0 {\n  exec \"true\"\n}\n")[0].condition ==
      "${exec(\"command -v x\").exit()} == 0"

  test "a nested index reference stays inside its braces":
    check statementsOf("print ${v[${i}]}\n")[0].printText == "${v[${i}]}"

  test "a call in a condition reports itself instead of answering empty":
    let ctx = runBuild("if ${spawn(\"x\")} {\n  exec \"true\"\n}\n")
    check errors.len == 1
    check "unsupported function call" in errors[0]
    check "spawn" in errors[0]

suite "kongue: an exec in a ${...} uses every argument":
  test "the extra arguments are not dropped":
    let ctx = runBuild("print ${exec(\"a\", \"b\")}\n")
    check execLog.len == 1
    check execLog[0].endsWith("a b")

  test "an argument with a space stays one word":
    let ctx = runBuild("print ${exec(\"sh\", \"-c\", \"ls | head\")}\n")
    check "sh -c" in execLog[0]
    check "'ls | head'" in execLog[0]

  test "one argument is still a shell command as written":
    let ctx = runBuild("print ${exec(\"ls -1 | head -n 1\").output()}\n")
    check execLog[0].endsWith("ls -1 | head -n 1")

suite "kongue: a ${...} that cannot be resolved says so":
  test "a literal string is its own value":
    let ctx = runBuild("print ${ \"literal\" }\n")
    check ctx.resolveVariables("${ \"literal\" }") == "literal"
    check errors.len == 0

  test "an index may be a reference":
    var ctx = runBuild("print ${v[${i}]}\n")
    ctx.setListVariable("v", @["zero", "one"])
    ctx.setVariable("i", "1")
    check ctx.resolveVariables("${v[${i}]}") == "one"

  test "an object key may be a reference":
    var ctx = runBuild("print ${o[${k}]}\n")
    var props = initTable[string, VarValue]()
    props["a"] = newStringValue("ay")
    ctx.setObjectVariable("o", newObjectValue(props))
    ctx.setVariable("k", "a")
    check ctx.resolveVariables("${o[${k}]}") == "ay"

  test "a method that does not exist is reported":
    let ctx = runBuild("print ${exec(\"ls\").output().length}\n")
    check errors.len == 1
    check "Unknown method: length" in errors[0]

  test "a suffix other than .output()/.exit() after exec is reported":
    let ctx = runBuild("print ${exec(\"ls\").output.length}\n")
    check errors.len == 1
    check ".output()" in errors[0] and ".exit()" in errors[0]

suite "kongue statements: continue and break take no arguments":
  test "continue with a word is an error":
    let f = failureOf("""name: "p"
build {
  for i in ["a"] {
    continue foo
  }
}
""")
    check f.raised
    check "continue takes no arguments" in f.msg
    check f.line == 4

  test "break with a word is an error":
    let f = failureOf("""name: "p"
build {
  for i in ["a"] {
    break foo
  }
}
""")
    check f.raised
    check "break takes no arguments" in f.msg

  test "a comment after continue is fine":
    let stmts = statementsOf("for i in [\"a\"] {\n  continue # next one\n}\n")
    check stmts[0].kind == nkFor
    check stmts[0].forBody.len == 1
    check stmts[0].forBody[0].kind == nkContinue

suite "kongue parser: a function body closes on a line of its own":
  test "a stray } after a statement is an error":
    let f = failureOf("""name: "p"
build {
  local X = "a" }
  print "rest"
}
""")
    check f.raised
    check "on a line of its own" in f.msg
    check f.line == 3

  test "a one-line body is not accepted either":
    let f = failureOf("name: \"p\"\nbuild { exec \"true\" }\n")
    check f.raised
    check "on a line of its own" in f.msg

  test "an empty body still parses":
    let f = failureOf("name: \"p\"\nbuild {\n}\n")
    check not f.raised

  test "a nested block's } does not count as the body's":
    let stmts = statementsOf("if test1 {\n  exec \"a\"\n}\nexec \"b\"\n")
    check stmts.len == 2
    check stmts[1].kind == nkExec

suite "kongue manifest: the header scan reads text, not braces":
  test "a column-0 line with a ${...} is header text":
    # The `{` inside `${...}` used to start a function block, so the header
    # stopped there and the rest of the line was parsed as a function body.
    try:
      discard parseManifest("""manifest_version: "1"
core_name: "test"
core_version: "0.1.0"
version ${x}
init {
  print "hi"
}
""")
      check false
    except ManifestParseError as e:
      check "expected key: value" in e.msg
      check e.line == 4

  test "a ${...} in a comment is text, not a call":
    let parsed = parseManifest("""manifest_version: "1"
core_name: "test"
core_version: "0.1.0"
init {
  # see ${spawn(x)}
  print "${op.unit}"
}
""")
    check parsed.functions.len == 1
    check parsed.manifestCalls.len == 0
