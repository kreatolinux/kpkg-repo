## Tests for two variable-handling rules: a macro argument value is one shell
## word, and command text for a shell is resolved in shell mode
## (ExecutionContext.shellVariables), which leaves a name the script does not
## define for the shell and keeps `\$` a literal dollar.
##
## Standalone (imports only kongue modules).

import unittest
import os
import strutils
import tables

import ../../kongue/ast
import ../../kongue/context
import ../../kongue/variables
import ../../kongue/builtins
import ../../kongue/lexer
import ../../kongue/parser
import ../../kongue/executor
import ../../kongue/utils

const header = "name: \"pkg\"\nversion: \"1.2\"\nrelease: \"3\"\n\n"

proc newCtx(): ExecutionContext =
  result = initExecutionContext()
  result.silent = true

proc parseBody(body: string): seq[AstNode] =
  ## Parse `build { <body> }` and return the statements of the block.
  var p = initParser(tokenize(header & "build {\n" & body & "\n}\n"))
  let parsed = p.parse()
  for fn in parsed.functions:
    if fn.funcName == "build":
      return fn.funcBody
  return @[]

proc macroArgsOf(body: string): seq[string] =
  ## Parse a single `macro` statement and return the argument list the executor
  ## hands to the macro hook.
  for stmt in parseBody(body):
    if stmt.kind == nkMacro:
      return stmt.macroArgs
  return @[]

suite "kongue macro arguments: a value is one shell word":

  test "the space before a variable reference splits the argument (accountsservice)":
    # Glued together these expand into admin_group "wheel-Delogind=true".
    let args = macroArgsOf(
      "macro build --libdir=/usr/lib -Dadmin_group=wheel ${extraArgs}")
    check args == @["--libdir=/usr/lib", "-Dadmin_group=wheel", "${extraArgs}"]

  test "a defined variable supplies the arguments it expands to":
    # The reference is its own argument, so the macro hook expands it.
    let ctx = newCtx()
    ctx.setVariable("extraArgs", "-Delogind=true -Dsystemdsystemunitdir=no")
    let args = macroArgsOf(
      "macro build --libdir=/usr/lib -Dadmin_group=wheel ${extraArgs}")
    check ctx.resolveVariables(args[2]) == "-Delogind=true -Dsystemdsystemunitdir=no"

  test "--flag= with no value does not eat the next argument":
    let args = macroArgsOf(
      "macro build -Ddocumentation= --wrap-mode=nodownload")
    check args == @["-Ddocumentation=", "--wrap-mode=nodownload"]

  test "adjacent tokens still form a single word":
    check macroArgsOf("macro build -Wl,-z,relro") == @["-Wl,-z,relro"]
    check macroArgsOf("macro build -j4 -O2") == @["-j4", "-O2"]
    check macroArgsOf("macro build -Dplatforms=wayland,x11") ==
      @["-Dplatforms=wayland,x11"]
    check macroArgsOf("macro build -I/usr/include") == @["-I/usr/include"]
    check macroArgsOf("macro build -Dprefix=/usr${suffix}") ==
      @["-Dprefix=/usr${suffix}"]

  test "a following positional argument is not swallowed":
    check macroArgsOf("macro build --prefix=/usr/local install.prefix=/usr") ==
      @["--prefix=/usr/local", "install.prefix=/usr"]

  test "a build-system source directory stays its own argument":
    check macroArgsOf("macro build --configure .. --prefix=/opt") ==
      @["--configure", "..", "--prefix=/opt"]
    check macroArgsOf("macro build --meson .. -Dfoo=bar") ==
      @["--meson", "..", "-Dfoo=bar"]

  test "a bare variable argument is not merged with its neighbour":
    check macroArgsOf("macro build $extraArgs --prefix=/usr") ==
      @["$extraArgs", "--prefix=/usr"]
    check macroArgsOf("macro build --with-mozilla $extraArgs") ==
      @["--with-mozilla", "$extraArgs"]

  test "empty and quoted values are preserved":
    check macroArgsOf("macro build --with-root-prefix=\"\" -Dvulkan-drivers=\"\"") ==
      @["--with-root-prefix=", "-Dvulkan-drivers="]

suite "kongue shell variables in exec commands":

  test "an undefined name is left for the shell":
    let ctx = newCtx()
    check ctx.resolveVariables("sh -c 'X=1 && echo \"$X\"'",
        shellVariables = true) == "sh -c 'X=1 && echo \"$X\"'"
    check ctx.resolveVariables("for f in a b; do echo $f; done",
        shellVariables = true) == "for f in a b; do echo $f; done"
    check ctx.resolveVariables("awk '{print $1}' file",
        shellVariables = true) == "awk '{print $1}' file"

  test "shell positional and special parameters are left alone":
    let ctx = newCtx()
    check ctx.resolveVariables("echo $1 $2 ${3} $@ $? $# $$ $(nproc)",
        shellVariables = true) == "echo $1 $2 ${3} $@ $? $# $$ $(nproc)"

  test "shell parameter expansion is left alone":
    let ctx = newCtx()
    check ctx.resolveVariables(
        "echo ${1} ${@} ${?} ${#} ${#name} ${name:-fallback} ${name%%.*}",
        shellVariables = true) ==
      "echo ${1} ${@} ${?} ${#} ${#name} ${name:-fallback} ${name%%.*}"

  test "a defined name still wins over a shell expansion":
    let ctx = newCtx()
    ctx.setVariable("name", "pkg")
    check ctx.resolveVariables("${name:-fallback}", shellVariables = true) == "pkg"

  test "kongue variables still resolve in shell mode":
    let ctx = newCtx()
    ctx.setVariable("version", "1.2")
    ctx.setVariable("extraArgs", "-Delogind=true")
    check ctx.resolveVariables("make -C build-$version ${extraArgs} $UNSET",
        shellVariables = true) == "make -C build-1.2 -Delogind=true $UNSET"

  test "kpkg built-in variables still resolve in shell mode":
    let ctx = initExecutionContext(destDir = "/DEST", srcDir = "/SRC",
        buildRoot = "/ROOT", packageName = "pkg")
    ctx.silent = true
    ctx.envVars["KPKG_ARCH"] = "aarch64"
    ctx.envVars["CXXFLAGS"] = "-O2 -pipe"
    let cmd = "install -Dm755 x $DESTDIR/usr/bin && echo $ROOT $SRCDIR " &
      "$PACKAGENAME ${KPKG_ARCH} \"${CXXFLAGS}\""
    check ctx.resolveVariables(cmd, shellVariables = true) ==
      "install -Dm755 x /DEST/usr/bin && echo /ROOT /SRC pkg aarch64 \"-O2 -pipe\""

  test "a recipe variable shadows a shell name":
    let ctx = newCtx()
    ctx.setVariable("prefix", "/usr")
    check ctx.resolveVariables("--prefix=$prefix --libdir=$libdir",
        shellVariables = true) == "--prefix=/usr --libdir=$libdir"

  test "manifest/lifecycle mode keeps unknown -> empty":
    # kongue(5) MANIFEST MODE requires exact resolution; the default context
    # must not start leaving dollars behind.
    let ctx = newCtx()
    check ctx.resolveVariables("echo $UNSETNAME ${ALSO_UNSET}") == "echo  "

  test "a method call is never handed to the shell":
    let ctx = newCtx()
    ctx.setVariable("version", "1.2.3")
    check ctx.resolveVariables("${version.split('.')[0]}", shellVariables = true) ==
      "1"

suite "kongue \\$ escape for a literal dollar":

  test "exec keeps a literal dollar":
    # kongue(5), CUSTOM FUNCTIONS: exec "echo you know this is a \$EXAMPLE right?"
    let ctx = newCtx()
    ctx.envVars["EXAMPLE"] = "test"
    for stmt in parseBody("exec \"echo \\$EXAMPLE and \\${EXAMPLE}\""):
      if stmt.kind == nkExec:
        check ctx.resolveVariables(stmt.execCmd, shellVariables = true) ==
          "echo $EXAMPLE and ${EXAMPLE}"

  test "the escape also works outside exec":
    # `\$` is a lexer escape, so it is exercised through a parsed string:
    # print resolves an unknown name to empty and keeps an escaped dollar.
    let ctx = newCtx()
    ctx.envVars["EXAMPLE"] = "test"
    var p = initParser(tokenize(header & "build {\n  print \"a \\$EXAMPLE b\"\n}\n"))
    let parsed = p.parse()
    for stmt in parsed.functions[0].funcBody:
      if stmt.kind == nkPrint:
        check ctx.resolveVariables(stmt.printText) == "\"a $EXAMPLE b\""

  test "an unescaped reference next to an escaped one still resolves":
    let ctx = newCtx()
    ctx.envVars["EXAMPLE"] = "test"
    var p = initParser(tokenize(header &
      "build {\n  print \"\\$EXAMPLE=$EXAMPLE\"\n}\n"))
    let parsed = p.parse()
    for stmt in parsed.functions[0].funcBody:
      if stmt.kind == nkPrint:
        check ctx.resolveVariables(stmt.printText) == "\"$EXAMPLE=test\""

  test "an escaped dollar never turns into an object access":
    # ``\$`` reaches resolveVariables as the lexer's marker byte, and the
    # bare-object-access pass must not treat the identifier after that marker as
    # a reference: ``\$kpkg["x"]`` stays literal. Exercised through the lexer,
    # which is how a recipe's text arrives.
    let ctx = newCtx()
    var props = initTable[string, VarValue]()
    props["isBootstrap"] = newStringValue("0")
    ctx.setObjectVariable("kpkg", newObjectValue(props))
    var cmds: seq[string] = @[]
    for stmt in parseBody("exec \"echo \\$kpkg[\\\"isBootstrap\\\"]\"\n" &
        "exec \"echo kpkg[\\\"isBootstrap\\\"]\""):
      if stmt.kind == nkExec:
        cmds.add(ctx.resolveVariables(stmt.execCmd, shellVariables = true))
    check cmds.len == 2
    # The escaped one is literal text; the plain one is a real object access.
    check cmds[0] == "echo $kpkg[\"isBootstrap\"]"
    check cmds[1] == "echo 0"

  test "a shell positional parameter is the shell's even inside a func":
    # kongue(5) promises `$1`/`$@` are always left alone, but a `func` binds
    # localVars["1"] to its own first argument, so the guard must not rewrite
    # `awk '{print $1}'` into the function's argument.
    var p = initParser(tokenize("name: \"p\"\n" &
      "func helper {\n  exec \"awk '{print $1}' file\"\n}\n" &
      "build {\n  helper \"ARGONE\"\n}\n"))
    let parsed = p.parse()
    let ctx = newCtx()
    ctx.shellVariables = true
    ctx.loadVariablesFromParsed(parsed)
    ctx.loadAllFunctions(parsed)
    var cmds: seq[string] = @[]
    ctx.execHook = proc(c: ExecutionContext, command: string,
                        silent: bool): tuple[output: string, exitCode: int] =
      cmds.add(command)
      return ("", 0)
    check ctx.executeFunctionByName(parsed, "build") == 0
    check cmds.len == 1
    check "awk '{print $1}' file" in cmds[0]

  test "$$ is left for the shell":
    let ctx = newCtx()
    ctx.setVariable("version", "1.2.3")
    check ctx.resolveVariables("echo $$version", shellVariables = true) ==
      "echo $$version"
    check ctx.resolveVariables("echo $$", shellVariables = true) == "echo $$"

  test "a non-colon shell operator is left for the shell even when the name is defined":
    # Kongue cannot evaluate `${version-2.0}` / `${name=x}`,
    # so the shell must get them; the documented `:` forms keep resolving.
    let ctx = newCtx()
    ctx.setVariable("version", "1.2.3")
    check ctx.resolveVariables("echo ${version-2.0}", shellVariables = true) ==
      "echo ${version-2.0}"
    check ctx.resolveVariables("echo ${version:-fallback}",
        shellVariables = true) == "echo 1.2.3"
    # Outside shell mode nothing changes.
    check ctx.resolveVariables("echo ${version-2.0}") == "echo "

  test "a header value keeps a literal dollar through substitution":
    # The header accessors substitute with substituteVariablesWithTable, which
    # does not call resolveVariables, so this pins the marker restoration where
    # a recipe's header becomes package metadata (kpkg's Run3File.getVariable).
    # See tests/kpkg/run3/main.nim.
    var p = initParser(tokenize("name: \"pkg\"\ndescription: \"costs \\$5\"\n\n" &
      "build {\n  exec \"true\"\n}\n"))
    let parsed = p.parse()
    let ctx = newCtx()
    ctx.loadVariablesFromParsed(parsed)
    # The marker is gone and the value is the literal text the recipe wrote.
    # A value is resolved once, where it is produced.
    check escapedDollar notin ctx.getVariable("description")
    check ctx.getVariable("description") == "costs $5"

  test "write content keeps a literal dollar":
    let dir = getTempDir() / "kongue-dollar-" & $getCurrentProcessId()
    createDir(dir)
    defer: removeDir(dir)
    var p = initParser(tokenize(header &
      "build {\n  write \"" & dir & "/ln\" \"/bin/ln \\$ARGS\"\n}\n"))
    let parsed = p.parse()
    let ctx = newCtx()
    ctx.loadVariablesFromParsed(parsed)
    ctx.loadAllFunctions(parsed)
    check ctx.executeFunctionByName(parsed, "build") == 0
    check readFile(dir / "ln") == "/bin/ln $ARGS"
