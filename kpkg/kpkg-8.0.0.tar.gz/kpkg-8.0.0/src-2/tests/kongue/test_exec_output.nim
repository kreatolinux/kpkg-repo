## Tests for an unquoted ``${exec("...").method()}`` assignment value: the whole
## expression is the value, and the ``}`` that closes it must not end the
## enclosing block (kongue(5), VARIABLE MANIPULATION: the `local first_file =
## ${exec(...).output()}` example). Standalone (imports only kongue modules).
##
## A body written as a triple-quoted string ends with a newline so that a
## closing `"` of the script never touches the closing delimiter.

import std/[strutils, unittest]
import ../../kongue/kongue

const header = "name: \"pkg\"\nversion: \"1.0\"\n\n"

var
  execLog: seq[string]
  execOutput: string

proc stubExec(ctx: ExecutionContext, command: string, silent: bool):
    tuple[output: string, exitCode: int] {.nimcall.} =
  ## Stand-in for the shell: records each command, returns a fixed output.
  execLog.add(command)
  (execOutput, 0)

proc statementsOf(body: string): seq[AstNode] =
  ## Parse ``func run { <body> }`` and return the statements of the body.
  var p = initParser(tokenize(header & "func run {\n" & body & "}\n"))
  for fn in p.parse().customFuncs:
    if fn.customFuncName == "run":
      return fn.customFuncBody
  return @[]

proc runBuild(body: string, output = "out"): ExecutionContext =
  ## Parse and run ``build { <body> }`` against the stub shell.
  execLog = @[]
  execOutput = output
  var p = initParser(tokenize(header & "build {\n" & body & "}\n"))
  let parsed = p.parse()
  result = initExecutionContext()
  result.silent = true
  result.execHook = stubExec
  result.loadVariablesFromParsed(parsed)
  result.loadAllFunctions(parsed)
  check result.executeFunctionByName(parsed, "build") == 0

suite "unquoted exec in an assignment value":

  test "the documented unquoted form keeps its value and the rest of the body":
    let stmts = statementsOf("""local first_file = ${exec("ls -1 | head -n 1").output()}
global copy = $first_file
exec "after"
print "last"
""")
    check stmts.len == 4
    check stmts[0].kind == nkLocal
    check stmts[0].localVar == "first_file"
    check stmts[0].localValue == "${exec(\"ls -1 | head -n 1\").output()}"
    check stmts[1].kind == nkGlobal
    check stmts[2].kind == nkExec
    check stmts[2].execCmd == "after"
    check stmts[3].kind == nkPrint

  test "the value resolves to the command output":
    let ctx = runBuild("""local first_file = ${exec("ls -1").output()}
global copy = $first_file
exec "after"
""", output = "file.txt")
    check ctx.getVariable("copy") == "file.txt"
    check execLog.len == 2
    check execLog[^1].endsWith("after")

  test "the quoted form is unchanged":
    let ctx = runBuild("""local first_file = "${exec("ls -1").output()}"
global copy = $first_file
exec "after"
""", output = "file.txt")
    check ctx.getVariable("copy") == "file.txt"
    check execLog.len == 2

  test "env and global assignments take the same form":
    let stmts = statementsOf("""env Z = ${exec("date").output()}
global G = ${exec("date").exit()}
exec "after"
""")
    check stmts.len == 3
    check stmts[0].kind == nkEnv
    check stmts[0].envValue == "${exec(\"date\").output()}"
    check stmts[1].kind == nkGlobal
    check stmts[1].globalValue == "${exec(\"date\").exit()}"
    check stmts[2].execCmd == "after"

  test "an expression stays one value when text surrounds it":
    let ctx = runBuild("""local X = pre-${exec("a").output()}-post
global copy = $X
exec "after"
""", output = "A")
    check ctx.getVariable("copy") == "pre-A-post"
    check execLog.len == 2

  test "indexing an object keeps the closing brace":
    let stmts = statementsOf("""local X = ${obj["key"]}
exec "after"
""")
    check stmts.len == 2
    check stmts[0].localValue == "${obj[\"key\"]}"
    check stmts[1].execCmd == "after"

suite "unquoted exec inside nested blocks":

  test "inside an if body":
    let stmts = statementsOf("""if "1" == "1" {
  local X = ${exec("a").output()}
  exec "inner"
}
exec "after"
""")
    check stmts.len == 2
    check stmts[0].kind == nkIf
    check stmts[0].thenBranch.len == 2
    check stmts[1].execCmd == "after"
    let ctx = runBuild("""if "1" == "1" {
  local X = ${exec("a").output()}
  global copy = $X
  exec "inner"
}
""", output = "A")
    check ctx.getVariable("copy") == "A"
    check execLog.len == 2

  test "inside a for body, and the loop still runs to the end":
    let stmts = statementsOf("""for i in items {
  local X = ${exec("a").output()}
  global copy = $X
  exec "inner"
}
exec "after"
""")
    check stmts.len == 2
    check stmts[0].kind == nkFor
    check stmts[0].forBody.len == 3
    let ctx = runBuild("""for i in ["one", "two"] {
  local X = ${exec("a").output()}
  global copy = $i-$X
}
exec "after"
""", output = "A")
    check ctx.getVariable("copy") == "two-A"
    check execLog.len == 3

  test "a nested block after the assignment is not swallowed":
    let stmts = statementsOf("""local X = ${exec("a").output()}
if "$X" == "A" {
  exec "inner"
} else {
  exec "other"
}
exec "after"
""")
    check stmts.len == 3
    check stmts[1].kind == nkIf
    check stmts[1].thenBranch.len == 1
    check stmts[1].elseBranch.len == 1
    check stmts[2].execCmd == "after"

suite "unquoted exec: other positions":

  test "the last statement before the closing brace keeps its value":
    let stmts = statementsOf("""exec "first"
local X = ${exec("a").output()}
""")
    check stmts.len == 2
    check stmts[1].localValue == "${exec(\"a\").output()}"

  test "a body that closes on the same line is an error":
    # The `}` that closes a function body stands on its own line, so a body
    # cannot end after a statement (kongue(5), FUNCTIONS).
    try:
      var p = initParser(tokenize(header &
        "func run { local X = ${exec(\"a\").output()} }\n"))
      discard p.parse()
      check false
    except ParseError as e:
      check "on a line of its own" in e.msg

  test "a for loop over an exec expression runs once per output line":
    let ctx = runBuild("""for line in ${exec("printf a b").output()} {
  global seen = $seen-$line
}
exec "after"
""", output = "a\nb")
    check ctx.getVariable("seen") == "-a-b"
    check execLog.len == 2

suite "expressions in other statements keep their text":

  test "a manipulation keeps the quotes of its argument":
    let stmts = statementsOf("""print ${v.replace("a b","c")}
exec "after"
""")
    check stmts.len == 2
    check "\"a b\"" in stmts[0].printText
    check "\"c\"" in stmts[0].printText

  test "a nested brace expression no longer truncates the body":
    let stmts = statementsOf("""print ${a.${b}}
exec "after"
""")
    check stmts.len == 2
    check stmts[1].execCmd == "after"

  test "an unterminated expression in a print is an error":
    try:
      discard statementsOf("""print ${v.
exec "after"
""")
      check false
    except ParseError as e:
      check "Unterminated ${...} expression" in e.msg

  test "a macro argument keeps the quotes inside its expression":
    let stmts = statementsOf("""macro build -Dfoo=${version.split('.').join('-')}
exec "after"
""")
    check stmts.len == 2
    check stmts[0].macroArgs == @["-Dfoo=${version.split('.').join('-')}"]

suite "unquoted exec: error handling":

  test "an unterminated expression is a parse error, not a truncated body":
    try:
      discard statementsOf("""local X = ${exec("a").output()
exec "after"
""")
      check false
    except ParseError as e:
      check "Unterminated ${...} expression" in e.msg

suite "unquoted exec in manifest mode":

  test "a manifest function body keeps the statements after the assignment":
    let parsed = parseManifest("""name: "example"
init {
  local X = ${exec("cat /proc/uptime").output()}
  respond state "active"
}
""")
    check parsed.functions.len == 1
    check parsed.functions[0].funcBody.len == 2
    check parsed.functions[0].funcBody[0].localValue ==
      "${exec(\"cat /proc/uptime\").output()}"
    check parsed.functions[0].funcBody[1].kind == nkFuncCall
    check parsed.manifestCalls.len == 1
    check parsed.manifestCalls[0].name == "exec"

suite "stray text outside a function block":

  test "the correct form reports nothing":
    var warnings: seq[string] = @[]
    warnProc = proc(msg: string) =
      warnings.add(msg)
    defer:
      warnProc = nil
    let stmts = statementsOf("""local X = ${exec("a").output()}
exec "after"
""")
    check stmts.len == 2
    check warnings.len == 0

  test "a stray closing brace is an error, not a truncated body":
    # It ends the body where it stands, so what follows stops being part of the
    # function; the statement after it must not be dropped instead.
    try:
      discard statementsOf("""local X = "a" }
exec "after"
""")
      check false
    except ParseError as e:
      check "on a line of its own" in e.msg
