## Parser diagnostics: list items, multi-line ``${...}``, comments after a
## key, and the one warning per script about text the parser steps over.

import std/unittest
import std/strutils
import ../../kongue/[lexer, parser, ast, utils]

type ParseFailure = object
  raised: bool
  msg: string
  line: int

proc parseAll(script: string): ParsedScript =
  var p = initParser(tokenize(script))
  p.parse()

proc failureOf(script: string): ParseFailure =
  ## Parse ``script`` expecting a ParseError, and report what it said.
  try:
    discard parseAll(script)
  except ParseError as e:
    return ParseFailure(raised: true, msg: e.msg, line: e.line)
  ParseFailure(raised: false)

proc variablesOf(script: string): seq[AstNode] =
  parseAll(script).variables

proc listOf(script, name: string): seq[string] =
  for v in variablesOf(script):
    if v.kind == nkListVariable and v.listName == name:
      return v.listItems

# Warnings are collected through utils.warnProc instead of stderr.
var warnings: seq[string] = @[]

proc captureWarn(msg: string) =
  warnings.add(msg)

proc warningsOf(script: string): seq[string] =
  warnings = @[]
  utils.warnProc = captureWarn
  try:
    discard parseAll(script)
  finally:
    utils.warnProc = nil
  warnings

suite "kongue parser: a list item '-' needs its value on its line":
  test "a lone '-' is an error, not the next line's token":
    let f = failureOf("""build_depends:
  - "a"
  # note
  -
build {
  exec "true"
}
""")
    check f.raised
    check "needs a value on the same line" in f.msg
    check f.line == 4

  test "a lone '-' at the end of the file is an error too":
    let f = failureOf("depends:\n  - \"glib\"\n  -")
    check f.raised
    check f.line == 3

  test "a list with comments keeps its items and the next function":
    let script = """build_depends:
  - "meson"
  # msgfmt, for the translations
  - "gettext"
build {
  exec "true"
}
"""
    let parsed = parseAll(script)
    check listOf(script, "build_depends") == @["meson", "gettext"]
    check parsed.functions.len == 1
    check parsed.functions[0].funcName == "build"

suite "kongue parser: a ${...} closes on the line it opens":
  test "a line break inside the expression names the line break":
    let f = failureOf("""func run {
print ${v.
exec "after"
}
""")
    check f.raised
    check "Unterminated ${...} expression" in f.msg
    check "before the end of the line" in f.msg
    check f.line == 2

  test "end of file inside the expression names the end of the file":
    let f = failureOf("""func run {
print ${v.""")
    check f.raised
    check "Unterminated ${...} expression" in f.msg
    check "before the end of the file" in f.msg

suite "kongue parser: comments after a key":
  test "the comment is skipped and the list is still a list":
    let items = listOf("""depends:
  # runtime
  # - "glib"  (commented out)
  - "glib-2.0"
release: "2"
""", "depends")
    check items == @["glib-2.0"]

  test "a comment-only value is an empty value, not a parse error":
    let vars = variablesOf("""empty:
  # nothing here
""")
    check vars.len == 1
    check vars[0].kind == nkVariable
    check vars[0].varName == "empty"
    check vars[0].varValue == ""

  test "a comment before an inline object leaves the object intact":
    let vars = variablesOf("""pkg:
  # metadata
  name: "example"
""")
    check vars.len == 1
    check vars[0].kind == nkObject
    check vars[0].objectName == "pkg"
    check vars[0].objectProperties.len == 1
    check vars[0].objectProperties[0].key == "name"
    check vars[0].objectProperties[0].value == "example"

suite "kongue parser: text it steps over warns once per script":
  test "stray text in the header warns with its line":
    let w = warningsOf("""name: "example"
}
=
build {
  exec "true"
}
""")
    check w.len == 1
    check "outside a header field or function block" in w[0]
    check "line 2" in w[0]
    check "'}'" in w[0]

  test "the warning is shared with the function-body loop":
    let w = warningsOf("""name: "example"
build {
  exec "true"
}
=
%
""")
    check w.len == 1
    check "outside a function block" in w[0]
    check "line 5" in w[0]

  test "the excerpt cuts between runes":
    let long = "日".repeat(30)
    let w = warningsOf("\"" & long & "\"\n")
    check w.len == 1
    check ("'" & "日".repeat(24) & "...'") in w[0]

  test "the excerpt escapes control bytes":
    let w = warningsOf("\"a\\nb\"\n")
    check w.len == 1
    check "'a\\nb'" in w[0]

  test "a short token gets no ellipsis":
    let w = warningsOf("\"ok\"\n")
    check w.len == 1
    check "'ok'" in w[0]
    check "..." notin w[0]
