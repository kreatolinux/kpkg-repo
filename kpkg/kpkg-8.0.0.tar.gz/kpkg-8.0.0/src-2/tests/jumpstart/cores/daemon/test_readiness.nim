## `jumpstart` arguments and the user daemon readiness pipe.
import std/[posix, unittest]
import ../../../../jumpstart/cores/daemon/readiness

proc usageOf(args: openArray[string]): string =
  try:
    discard parseDaemonArgs(args)
    ""
  except ValueError as e: e.msg

proc readAll(fd: cint): string =
  var buffer: array[16, char]
  while true:
    let n = posix.read(fd, addr buffer[0], buffer.len)
    if n <= 0: break
    for i in 0 ..< n: result.add buffer[i]

suite "daemon arguments":
  test "no arguments, --user, and --user --ready-fd N":
    check parseDaemonArgs([]) == DaemonArgs(user: false, readyFd: -1)
    check parseDaemonArgs(["--user"]) == DaemonArgs(user: true, readyFd: -1)
    check parseDaemonArgs(["--user", "--ready-fd", "3"]) == DaemonArgs(user: true, readyFd: 3)
    check parseDaemonArgs(["--ready-fd", "17", "--user"]) == DaemonArgs(user: true, readyFd: 17)

  test "every other combination is a usage error":
    check usageOf(["--ready-fd", "3"]) == "--ready-fd requires --user"
    check usageOf(["--user", "--ready-fd", "2"]) == "--ready-fd must be 3 or greater"
    check usageOf(["--user", "--ready-fd", "0"]) == "--ready-fd must be 3 or greater"
    check usageOf(["--user", "--ready-fd"]) == "--ready-fd requires a file descriptor"
    for bad in ["", "x", "-3", "3x", "+4", "1234567890"]:
      check usageOf(["--user", "--ready-fd", bad]) == "invalid --ready-fd: " & bad
    check usageOf(["--user", "--user"]) == "too many arguments"
    check usageOf(["--user", "--ready-fd", "3", "--ready-fd", "4"]) == "too many arguments"
    check usageOf(["--user", "--ready-fd", "3", "extra"]) == "unknown argument: extra"
    check usageOf(["--ready-fd=3", "--user"]) == "unknown argument: --ready-fd=3"
    check usageOf(["single"]) == "unknown argument: single"

suite "readiness notifier":
  test "the descriptor is made close-on-exec and gets exactly one 'R'":
    var fds: array[2, cint]
    check posix.pipe(fds) == 0
    check (fcntl(fds[1], F_GETFD) and FD_CLOEXEC) == 0
    let n = newReadyNotifier(int(fds[1]))
    check n.active
    check (fcntl(fds[1], F_GETFD) and FD_CLOEXEC) != 0
    check n.notifyReady()
    check not n.active
    check not n.notifyReady()          # once only
    check fcntl(fds[1], F_GETFD) < 0   # closed
    check readAll(fds[0]) == "R"        # then EOF
    discard posix.close(fds[0])

  test "closing without notifying gives the reader EOF":
    var fds: array[2, cint]
    check posix.pipe(fds) == 0
    let n = newReadyNotifier(int(fds[1]))
    n.close()
    check readAll(fds[0]) == ""
    check not n.notifyReady()
    discard posix.close(fds[0])

  test "a reader that went away is not an error":
    var fds: array[2, cint]
    check posix.pipe(fds) == 0
    discard posix.close(fds[0])
    signal(SIGPIPE, SIG_IGN)
    let n = newReadyNotifier(int(fds[1]))
    check not n.notifyReady()
    check not n.active

  test "no descriptor, or one that is not open":
    check not newReadyNotifier(-1).active
    check not newReadyNotifier(-1).notifyReady()
    expect OSError: discard newReadyNotifier(987)
