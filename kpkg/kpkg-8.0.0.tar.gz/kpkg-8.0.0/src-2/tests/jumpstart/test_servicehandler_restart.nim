## Automatic restarts of native services: what is restarted, what is not, and
## the start-rate limit that stops a service that cannot stay up. Real
## processes through the central reaper; no root needed.
import std/[os, strutils, times, unittest]
import ../../jumpstart/serviceHandler/[globalVariables, restart, start, stop, status,
  status_text]
import jumpstartcore/reaper

proc newContext(label: string): NativeContext =
  let root = getTempDir() / ("jumpstart-restart-" & label & "-" &
    $getCurrentProcessId() & "-" & $int(epochTime() * 1000))
  createDir(root / "etc")
  newNativeContext(root / "etc", root / "run", newReaper(), stopTimeoutMs = 3000)

proc decfile(ctx: NativeContext; name, body: string) =
  writeFile(ctx.configRoot / (name & ".kg"), body)

proc unit(name: string; policy = ""; delay = 0; kind = "simple";
          exec = "/bin/sh -c 'exit 1'"; extra = ""): string =
  ## A decfile with an optional restart policy and exec_post.
  result = "description: \"" & name & "\"\ntype: \"" & kind & "\"\n"
  if policy.len > 0: result.add "restart: \"" & policy & "\"\n"
  if delay > 0: result.add "restart_delay: " & $delay & "\n"
  result.add "service {\n  exec \"" & exec & "\"\n"
  if extra.len > 0: result.add "  " & extra & "\n"
  result.add "}\n"

proc waitExit(ctx: NativeContext; name: string; timeoutMs = 5000): bool =
  ## Pump the reaper until the service's main process exited.
  ctx.waitUntil(proc(): bool = not ctx.isRunning(name), timeoutMs)

proc waitFor(ctx: NativeContext; done: proc(): bool {.closure.};
             timeoutMs = 5000): bool =
  ctx.waitUntil(done, timeoutMs)

suite "restart policy":
  test "no policy leaves an exiting service stopped":
    let ctx = newContext("plain")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("once", unit("once"))
    ctx.startService("once")
    check ctx.waitExit("once")
    let record = ctx.findService("once")
    check record.exitCode == 1
    check record.restartDueMs == 0
    check ctx.nextRestartInMs() == -1
    ctx.runDueRestarts()
    check not ctx.isRunning("once")
    check readFile(ctx.serviceStateDir("once") / "status") ==
      ExitCodePrefix & "1"

  test "always restarts a service that exits":
    let ctx = newContext("always")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("flap", unit("flap", policy = "always", delay = 10))
    ctx.startService("flap")
    check ctx.waitExit("flap")
    check ctx.findService("flap").restartDueMs > 0
    let pending = ctx.nextRestartInMs()
    check pending >= 0 and pending <= 10
    sleep(20)
    ctx.runDueRestarts()
    check ctx.isRunning("flap") # restarted; it exits again on its own
    check ctx.restartAttempts.getOrDefault("flap").len == 1

  test "on-failure restarts a non-zero exit only":
    let ctx = newContext("on-failure")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("ok", unit("ok", policy = "on-failure", delay = 10,
      exec = "/bin/sh -c 'exit 0'"))
    ctx.decfile("bad", unit("bad", policy = "on-failure", delay = 10))
    ctx.startService("ok")
    check ctx.waitExit("ok")
    check ctx.findService("ok").restartDueMs == 0
    ctx.startService("bad")
    check ctx.waitExit("bad")
    check ctx.findService("bad").restartDueMs > 0

  test "a requested stop is never restarted":
    let ctx = newContext("stop")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("svc", unit("svc", policy = "always", exec = "sleep 30"))
    ctx.startService("svc")
    ctx.stopService("svc")
    check not ctx.isRunning("svc")
    check ctx.findService("svc").restartDueMs == 0
    check ctx.nextRestartInMs() == -1
    ctx.runDueRestarts()
    check not ctx.isRunning("svc")

  test "oneshot units are never restarted":
    let ctx = newContext("oneshot")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("job", unit("job", policy = "always", kind = "oneshot",
      exec = "/bin/sh -c 'exit 0'"))
    ctx.startService("job")
    check ctx.waitExit("job")
    check ctx.findService("job").restartDueMs == 0

  test "execPost is not cut short by a restart":
    let ctx = newContext("post")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("posted", unit("posted", policy = "always", delay = 10,
      exec = "/bin/sh -c 'exit 0'", extra = "exec_post \"sleep 0.4\""))
    ctx.startService("posted")
    let record = ctx.findService("posted")
    check ctx.waitExit("posted")
    check record.postRunning
    sleep(20)
    ctx.runDueRestarts()
    check not ctx.isRunning("posted") # the post still runs
    check record.restartDueMs > 0
    check ctx.waitFor(proc(): bool = not record.postRunning)
    sleep(20)
    ctx.runDueRestarts()
    check ctx.isRunning("posted")
    ctx.stopService("posted")

  test "the start-rate limit gives up on a service that cannot stay up":
    let ctx = newContext("rate-limit")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("spin", unit("spin", policy = "always", delay = 1))
    ctx.startService("spin")
    var restarts = 0
    while restarts < 20:
      check ctx.waitExit("spin")
      if ctx.findService("spin").restartDueMs == 0: break
      sleep(3)
      ctx.runDueRestarts()
      if not ctx.isRunning("spin"): break # given up: no new process
      inc restarts
    check restarts == RestartStartLimitBurst
    check ctx.restartAttempts.getOrDefault("spin").len == RestartStartLimitBurst
    check not ctx.isRunning("spin")
    check ctx.nextRestartInMs() == -1

  test "an explicit start opens a fresh rate window":
    let ctx = newContext("fresh-window")
    defer: removeDir(parentDir(ctx.configRoot))
    ctx.decfile("svc", unit("svc", policy = "always", delay = 10,
      exec = "sleep 30"))
    for i in 1 .. RestartStartLimitBurst:
      ctx.restartAttempts["svc"] = ctx.restartAttempts.getOrDefault("svc") & @[restartNowMs()]
    ctx.startService("svc")
    check ctx.restartAttempts.getOrDefault("svc").len == 0
    ctx.stopService("svc")

  test "nextRestartInMs is -1 without a pending restart":
    let ctx = newContext("empty")
    defer: removeDir(parentDir(ctx.configRoot))
    check ctx.nextRestartInMs() == -1
    ctx.runDueRestarts() # nothing to do, no records
    check ctx.nextRestartInMs() == -1
