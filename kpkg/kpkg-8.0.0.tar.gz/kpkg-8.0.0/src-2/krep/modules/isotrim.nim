## Live-image trimming: drop build-only files, documentation, unused locales and
## optional firmware from a *staged* rootfs copy, and strip debug information
## from ELF files. Never pointed at the input rootfs: callers run it on the
## private workspace copy that `krep iso` already makes.
##
## A trim policy is a declarative Kongue file (krep/data/iso/trim/<name>.kg):
## `remove` holds rootfs-relative globs (`*`/`?`/`[..]` within one component,
## `**` across any number), `keep_locales` + `locale_dirs` select locales,
## `strip_elf` + `strip_exclude` control stripping, `firmware` (keep|trim) with
## `firmware_exclude`, and `squashfs_compression`/`_block_size`/`_level` the
## image.
import std/[os, osproc, streams, strutils, sets, algorithm]
import posix
import ./bootconfig
import ../../kpkg/modules/rootfs/kongue_document

type
  FirmwareMode* = enum fwKeep = "keep", fwTrim = "trim"
  TrimPolicy* = object
    name*: string
    remove*: seq[string]
    keepLocales*: seq[string]
    localeDirs*: seq[string]
    stripElf*: bool
    stripExclude*: seq[string]
    firmware*: FirmwareMode
    firmwareExclude*: seq[string]
    squashfsCompression*: string
    squashfsBlockSize*: string
    squashfsCompressionLevel*: string
  TrimStats* = object
    removedEntries*: int
    removedBytes*: int64
    strippedFiles*: int
    strippedBytesBefore*, strippedBytesAfter*: int64
    skippedStrip*: int
  TrimRunner* = proc(exe: string, args: seq[string]) {.closure.}

const
  firmwareDir* = "usr/lib/firmware"
  trimScalars = ["schema_version", "strip_elf", "firmware",
    "squashfs_compression", "squashfs_block_size", "squashfs_compression_level"]
  trimLists = ["remove", "keep_locales", "locale_dirs", "strip_exclude",
    "firmware_exclude"]
  squashfsCompressors* = ["gzip", "xz", "zstd", "lz4", "lzo"]
  ## Never stripped, whatever the policy says: firmware blobs can be ELF
  ## (NVIDIA GSP images) and must stay byte-identical; /boot holds the kernel.
  builtinStripExclude = [firmwareDir, "boot", "usr/lib/modules/*/build",
    "usr/lib/modules/*/source"]
  stripBatch = 400

proc noTrim*(): TrimPolicy = TrimPolicy(name: "none")

proc isEmpty*(policy: TrimPolicy): bool =
  policy.remove.len == 0 and policy.localeDirs.len == 0 and
    not policy.stripElf and policy.firmware == fwKeep

proc validatePattern(pattern, source: string) =
  if pattern.len == 0 or pattern.startsWith("/") or pattern.endsWith("/"):
    raise newException(ValueError, source &
        ": patterns must be non-empty rootfs-relative paths: '" & pattern & "'")
  for part in pattern.split('/'):
    if part in ["", ".", ".."]:
      raise newException(ValueError, source &
          ": pattern components must not be empty, '.' or '..': '" & pattern & "'")
  for ch in pattern:
    if ch in {'\0', '\n', '\r'}:
      raise newException(ValueError, source & ": invalid pattern")
  var matchesEverything = true
  for part in pattern.split('/'):
    if not part.allCharsInSet({'*', '?'}): matchesEverything = false
  if matchesEverything:
    raise newException(ValueError, source &
        ": pattern would match everything: '" & pattern & "'")

proc validateSquashfs*(compression, blockSize, level: string) =
  ## Reject values mksquashfs 4.6 would refuse, before the long staging work.
  if compression.len > 0 and compression notin squashfsCompressors:
    raise newException(ValueError, "Unsupported squashfs compression '" &
        compression & "' (use " & squashfsCompressors.join(", ") & ")")
  let comp = if compression.len == 0: "gzip" else: compression
  if blockSize.len > 0:
    var digits = blockSize
    var multiplier = 1
    if digits[^1] in {'K', 'k'}:
      multiplier = 1024
      digits.setLen(digits.len - 1)
    elif digits[^1] in {'M', 'm'}:
      multiplier = 1024 * 1024
      digits.setLen(digits.len - 1)
    if digits.len == 0 or digits.len > 7 or not digits.allCharsInSet(Digits):
      raise newException(ValueError, "Invalid squashfs block size '" &
          blockSize & "' (e.g. 128K or 1M)")
    let bytes = parseInt(digits) * multiplier
    if bytes < 4096 or bytes > 1024 * 1024 or (bytes and (bytes - 1)) != 0:
      raise newException(ValueError,
          "squashfs block size must be a power of two from 4K to 1M")
  if level.len > 0:
    let maxLevel = case comp
      of "gzip", "lzo": 9
      of "zstd": 22
      else: raise newException(ValueError,
          "squashfs compression level applies to gzip, zstd and lzo only")
    if level.len > 2 or not level.allCharsInSet(Digits) or
        parseInt(level) notin 1..maxLevel:
      raise newException(ValueError, comp &
          " squashfs compression level must be 1.." & $maxLevel)

proc parseBool(value, key, source: string): bool =
  case value.toLowerAscii()
  of "true", "yes": true
  of "false", "no": false
  else: raise newException(ValueError, source & ": invalid boolean '" & value &
      "' for '" & key & "'")

proc parseFirmwareMode*(value: string): FirmwareMode =
  case value.toLowerAscii()
  of "keep", "": fwKeep
  of "trim": fwTrim
  else: raise newException(ValueError, "firmware must be 'keep' or 'trim', not '" &
      value & "'")

proc parseTrimPolicy*(content: string, source = "<memory>"): TrimPolicy =
  let doc = parseDeclarativeKongue(content, source)
  requireKnownFields(doc, source, trimScalars, trimLists)
  if doc.scalar("schema_version", "1") != "1":
    raise newException(ValueError, source & ": unsupported schema_version")
  result.name = source.extractFilename.changeFileExt("")
  result.remove = doc.list("remove")
  result.keepLocales = doc.list("keep_locales")
  result.localeDirs = doc.list("locale_dirs")
  result.stripElf = parseBool(doc.scalar("strip_elf", "false"), "strip_elf", source)
  result.stripExclude = doc.list("strip_exclude")
  result.firmware = parseFirmwareMode(doc.scalar("firmware", "keep"))
  result.firmwareExclude = doc.list("firmware_exclude")
  result.squashfsCompression = doc.scalar("squashfs_compression", "")
  result.squashfsBlockSize = doc.scalar("squashfs_block_size", "")
  result.squashfsCompressionLevel = doc.scalar("squashfs_compression_level", "")
  for pattern in result.remove & result.localeDirs & result.stripExclude &
      result.firmwareExclude:
    validatePattern(pattern, source)
  for language in result.keepLocales:
    if language.len == 0 or '/' in language or language in [".", ".."]:
      raise newException(ValueError, source & ": invalid keep_locales entry '" &
          language & "'")
  if result.localeDirs.len > 0 and result.keepLocales.len == 0:
    raise newException(ValueError, source &
        ": locale_dirs needs keep_locales (refusing to delete every locale)")
  validateSquashfs(result.squashfsCompression, result.squashfsBlockSize,
      result.squashfsCompressionLevel)

proc loadTrimPolicy*(path: string): TrimPolicy =
  result = parseTrimPolicy(readFile(path), path)

proc resolveTrimPolicy*(value, resources: string): TrimPolicy =
  ## "" or "none": no trimming. A bare name selects <resources>/trim/<name>.kg;
  ## anything containing '/' or ending in .kg is a policy file path.
  if value.len == 0 or value == "none": return noTrim()
  let path = if '/' in value or value.endsWith(".kg"): absolutePath(value)
             else: resources / "trim" / value & ".kg"
  if not fileExists(path):
    raise newException(ValueError, "Trim policy does not exist: " & path)
  result = loadTrimPolicy(path)

proc squashfsArgs*(compression, blockSize, level: string): seq[string] =
  ## Extra mksquashfs arguments; empty compression keeps mksquashfs's gzip.
  validateSquashfs(compression, blockSize, level)
  if compression.len > 0: result.add(@["-comp", compression])
  elif level.len > 0: result.add(@["-comp", "gzip"])  # -X options need -comp
  if blockSize.len > 0: result.add(@["-b", blockSize])
  if level.len > 0: result.add(@["-Xcompression-level", level])

proc fnmatchC(pattern, name: cstring, flags: cint): cint
    {.importc: "fnmatch", header: "<fnmatch.h>".}

proc segmentMatch(pattern, name: string): bool =
  fnmatchC(pattern.cstring, name.cstring, 0) == 0

proc matchParts(pattern, path: openArray[string]): bool =
  if pattern.len == 0: return path.len == 0
  if pattern[0] == "**":
    for skip in 0 .. path.len:
      if matchParts(pattern.toOpenArray(1, pattern.high),
          path.toOpenArray(skip, path.high)): return true
    return false
  if path.len == 0: return false
  segmentMatch(pattern[0], path[0]) and
    matchParts(pattern.toOpenArray(1, pattern.high), path.toOpenArray(1, path.high))

proc matchGlob*(pattern, path: string): bool =
  ## Match a rootfs-relative path ("usr/lib/libx.a") against a pattern.
  matchParts(pattern.split('/'), path.split('/'))

proc matchAny*(patterns: openArray[string], path: string): bool =
  for pattern in patterns:
    if matchGlob(pattern, path): return true

proc localeKept*(entry: string, keep: openArray[string]): bool =
  ## "en" keeps en, en_US, en_GB.UTF-8, en@quot; "pt_BR" keeps only pt_BR*.
  ## C and POSIX are always kept.
  if entry in ["C", "POSIX"] or entry.startsWith("C."): return true
  for language in keep:
    if entry == language: return true
    if entry.startsWith(language) and entry.len > language.len and
        entry[language.len] in {'_', '@', '.'}: return true

proc treeBytes(path: string): int64 =
  let info = getFileInfo(path, followSymlink = false)
  if info.kind == pcDir:
    for kind, child in walkDir(path):
      result += treeBytes(child)
  elif info.kind == pcFile:
    result = info.size

proc removeEntry(path: string, stats: var TrimStats) =
  ## Remove a file, symlink or directory tree without following links.
  stats.removedBytes += treeBytes(path)
  inc stats.removedEntries
  if getFileInfo(path, followSymlink = false).kind == pcDir:
    removeDir(path, checkDir = true)
  else:
    removeFile(path)

proc removeMatchingIn(dir, rel: string, patterns: seq[string],
    stats: var TrimStats, checkCancelled: proc() {.closure.}) =
  var entries: seq[(PathComponent, string)]
  for kind, child in walkDir(dir, relative = true): entries.add((kind, child))
  entries.sort()
  for (kind, name) in entries:
    let childRel = if rel.len == 0: name else: rel & "/" & name
    let path = dir / name
    if matchAny(patterns, childRel):
      removeEntry(path, stats)
    elif kind == pcDir:
      removeMatchingIn(path, childRel, patterns, stats, checkCancelled)
  if checkCancelled != nil: checkCancelled()

proc removeMatching(rootfs: string, patterns: seq[string],
    stats: var TrimStats, checkCancelled: proc() {.closure.}) =
  if patterns.len == 0: return
  removeMatchingIn(rootfs, "", patterns, stats, checkCancelled)

proc realDirInRoot(rootfs, rel: string): bool =
  ## True when every component of rel below rootfs is a real directory. A
  ## symlink makes it false: it could point at the build host (an absolute
  ## usr/lib/firmware -> /lib/firmware).
  var path = rootfs
  for part in rel.split('/'):
    path = path / part
    var st: Stat
    if lstat(path.cstring, st) != 0 or not S_ISDIR(st.st_mode): return false
  true

proc removeLocales(rootfs: string, policy: TrimPolicy, stats: var TrimStats) =
  for dirPattern in policy.localeDirs:
    let dir = rootfs / dirPattern
    if not realDirInRoot(rootfs, dirPattern): continue
    for kind, name in walkDir(dir, relative = true):
      # Only language directories go; locale.alias and other files stay.
      if kind == pcDir and not localeKept(name, policy.keepLocales):
        removeEntry(dir / name, stats)

proc removeDanglingLinks(dir: string, stats: var TrimStats) =
  ## Firmware symlinks into removed vendor directories would only confuse
  ## the firmware loader's fallback search.
  if getFileInfo(dir, followSymlink = false).kind != pcDir: return
  for kind, child in walkDir(dir):
    case kind
    of pcDir: removeDanglingLinks(child, stats)
    of pcLinkToFile, pcLinkToDir:
      let target = expandSymlink(child)
      let resolved = if target.isAbsolute: target  # never resolved on the host
                     else: child.parentDir / target
      if not target.isAbsolute and not fileExists(resolved) and
          not dirExists(resolved):
        removeFile(child)
        inc stats.removedEntries
    else: discard

type ElfKind = enum ekNone, ekRelocatable, ekLinked

proc elfKind(path: string): ElfKind =
  var f: File
  if not open(f, path, fmRead): return ekNone
  defer: f.close()
  var header: array[18, uint8]
  if f.readBytes(header, 0, header.len) != header.len: return ekNone
  if header[0] != 0x7f or header[1] != uint8('E') or header[2] != uint8('L') or
      header[3] != uint8('F'): return ekNone
  # e_type is at offset 16, in the file's byte order (EI_DATA at offset 5).
  let etype = if header[5] == 2: (uint16(header[16]) shl 8) or header[17]
              else: (uint16(header[17]) shl 8) or header[16]
  case etype
  of 1: ekRelocatable   # .ko / .o: --strip-debug keeps the symbols they need
  of 2, 3: ekLinked     # executables and shared objects
  else: ekNone

when defined(linux):
  proc llistxattr(path: cstring, list: cstring, size: csize_t): int
      {.importc, header: "<sys/xattr.h>".}
  proc hasXattrs(path: string): bool =
    ## strip replaces files by rename, which drops xattrs such as
    ## security.capability. Such files are left alone.
    llistxattr(path.cstring, nil, 0) > 0
else:
  proc hasXattrs(path: string): bool = false

type StripTarget = object
  path, rel: string
  mode: Mode
  uid: Uid
  gid: Gid
  size: int64

proc stripTool*(rootfs: string): tuple[exe: string, prefix: seq[string],
    inRoot: bool] =
  ## Prefer the target's own binutils (right architecture, runs in a chroot of
  ## the staged copy), fall back to the build host's strip.
  let target = rootfs / "usr/bin/strip"
  if fileExists(target) and fpUserExec in getFilePermissions(target) and
      findExe("chroot").len > 0:
    return ("chroot", @[rootfs, "/usr/bin/strip"], true)
  let host = findExe("strip")
  if host.len > 0: return (host, @[], false)
  return ("", @[], false)

type StripTargets = object
  linked, relocatable: seq[StripTarget]
  skipped: int

proc collectStripTargets(dir, rel: string, exclude: seq[string],
    found: var StripTargets) =
  for kind, name in walkDir(dir, relative = true):
    let childRel = if rel.len == 0: name else: rel & "/" & name
    let path = dir / name
    if matchAny(exclude, childRel) or matchAny(builtinStripExclude, childRel):
      continue
    case kind
    of pcDir: collectStripTargets(path, childRel, exclude, found)
    of pcFile:
      var st: Stat
      if lstat(path.cstring, st) != 0 or not S_ISREG(st.st_mode) or
          st.st_size < 64: continue
      let elf = elfKind(path)
      if elf == ekNone: continue
      if hasXattrs(path):
        inc found.skipped
        continue
      let target = StripTarget(path: path, rel: "/" & childRel,
          mode: st.st_mode, uid: st.st_uid, gid: st.st_gid,
          size: int64(st.st_size))
      if elf == ekLinked: found.linked.add(target)
      else: found.relocatable.add(target)
    else: discard

proc stripClosure*(rootfs: string): HashSet[(Dev, Ino)] =
  ## Inodes of the strip binary, its ELF interpreter and its shared libraries
  ## inside the rootfs. GNU strip rewrites files in place, so stripping a
  ## library the running strip has mapped (libc, libbfd, ld.so) truncates it
  ## under the process; those are stripped out of place instead.
  result = initHashSet[(Dev, Ino)]()
  proc addPath(path: string, into: var HashSet[(Dev, Ino)]) =
    var st: Stat
    let resolved = resolveRootfsPath(rootfs, path)
    if lstat(resolved.cstring, st) == 0 and S_ISREG(st.st_mode):
      into.incl((st.st_dev, st.st_ino))
  addPath("/usr/bin/strip", result)
  var output = ""
  var code = -1
  try:
    let process = startProcess("chroot", args = [rootfs, "/usr/bin/ldd",
        "/usr/bin/strip"], options = {poUsePath, poStdErrToStdOut})
    output = process.outputStream.readAll()
    code = process.waitForExit()
    process.close()
  except OSError:
    code = -1
  if code != 0:
    raise newException(OSError, "Cannot list the libraries of the rootfs " &
        "strip (chroot ldd /usr/bin/strip failed); refusing to strip in place")
  var found = 0
  for line in output.splitLines():
    for token in line.splitWhitespace():
      if token.startsWith("/"):
        addPath(token, result)
        inc found
  if found == 0:
    raise newException(OSError, "ldd listed no libraries for the rootfs " &
        "strip; refusing to strip in place")

proc stripOutOfPlace(rootfs: string, target: StripTarget, flags: seq[string],
    run: TrimRunner): int64 =
  ## strip to a temporary file, then copy the result over the original from
  ## krep itself, keeping the inode (hard links, owner, mode, xattrs).
  let temporaryRel = target.rel & ".krep-strip"
  let temporary = rootfs / temporaryRel.strip(chars = {'/'}, trailing = false)
  try:
    run("chroot", @[rootfs, "/usr/bin/strip"] & flags &
        @["-p", "-o", temporaryRel, "--", target.rel])
    let mtime = getLastModificationTime(target.path)
    writeFile(target.path, readFile(temporary))
    setLastModificationTime(target.path, mtime)
    result = getFileInfo(target.path, followSymlink = false).size
  except IOError, OSError:
    result = target.size
    stderr.writeLine("krep: could not strip " & target.rel & "; left as is")
  finally:
    if fileExists(temporary) or symlinkExists(temporary): removeFile(temporary)

proc stripElfFiles(rootfs: string, policy: TrimPolicy, run: TrimRunner,
    stats: var TrimStats, checkCancelled: proc() {.closure.}) =
  let tool = stripTool(rootfs)
  if tool.exe.len == 0:
    raise newException(OSError, "strip_elf needs binutils strip in the rootfs " &
        "(/usr/bin/strip) or on the build host")
  if tool.inRoot:
    # Fails early when the rootfs cannot run here (foreign arch, no binfmt)
    # instead of silently stripping nothing.
    try:
      run(tool.exe, tool.prefix & @["--version"])
    except IOError:
      if checkCancelled != nil: checkCancelled()
      raise newException(OSError, "The rootfs strip does not run on this " &
          "host (foreign architecture?); disable strip_elf or build natively")
  var found: StripTargets
  collectStripTargets(rootfs, "", policy.stripExclude, found)
  # The host strip runs nothing from the rootfs; the chroot one maps its own
  # closure from the very tree it is rewriting.
  let closure = if tool.inRoot: stripClosure(rootfs)
                else: initHashSet[(Dev, Ino)]()
  var deferred: seq[(StripTarget, seq[string])]
  var local = TrimStats(skippedStrip: found.skipped)
  # Hard links: strip copies over multi-link files in place, so every name
  # still shares one inode; strip each inode once.
  var seen = initHashSet[(Dev, Ino)]()
  proc batches(targets: seq[StripTarget], flags: seq[string]) =
    var group: seq[StripTarget]
    proc flush() =
      if group.len == 0: return
      var args = tool.prefix & flags & @["-p", "--"]
      for target in group:
        args.add(if tool.inRoot: target.rel else: target.path)
      try:
        run(tool.exe, args)
      except IOError:
        # strip keeps going after a file it cannot handle and exits nonzero
        # at the end; the other files of the batch are already stripped.
        if checkCancelled != nil: checkCancelled()
        stderr.writeLine("krep: strip reported errors in a batch; continuing")
      for target in group:
        # Restore exact mode bits (setuid included) and ownership.
        var st: Stat
        if lstat(target.path.cstring, st) != 0: continue
        if st.st_uid != target.uid or st.st_gid != target.gid:
          discard lchown(target.path.cstring, target.uid, target.gid)
        if (st.st_mode and 0o7777) != (target.mode and 0o7777):
          discard chmod(target.path.cstring, target.mode and 0o7777)
        inc local.strippedFiles
        local.strippedBytesBefore += target.size
        local.strippedBytesAfter += int64(st.st_size)
      group.setLen(0)
      if checkCancelled != nil: checkCancelled()
    for target in targets:
      var st: Stat
      if lstat(target.path.cstring, st) != 0: continue
      if (st.st_dev, st.st_ino) in seen: continue
      seen.incl((st.st_dev, st.st_ino))
      if (st.st_dev, st.st_ino) in closure:
        deferred.add((target, flags))
        continue
      group.add(target)
      if group.len >= stripBatch: flush()
    flush()
  batches(found.linked, @["--strip-unneeded"])
  batches(found.relocatable, @["--strip-debug"])
  for (target, flags) in deferred:
    let after = stripOutOfPlace(rootfs, target, flags, run)
    inc local.strippedFiles
    local.strippedBytesBefore += target.size
    local.strippedBytesAfter += after
    if checkCancelled != nil: checkCancelled()
  if tool.inRoot:
    # Smoke test: the target's strip (and with it libc and ld.so) still runs.
    run("chroot", @[rootfs, "/usr/bin/strip", "--version"])
  stats.strippedFiles += local.strippedFiles
  stats.strippedBytesBefore += local.strippedBytesBefore
  stats.strippedBytesAfter += local.strippedBytesAfter
  stats.skippedStrip += local.skippedStrip

proc applyTrim*(rootfs: string, policy: TrimPolicy, run: TrimRunner,
    checkCancelled: proc() {.closure.} = nil): TrimStats =
  ## Trim a staged rootfs copy in place. Order: patterns, locales, firmware,
  ## then strip (so removed files are never stripped).
  if policy.isEmpty: return
  removeMatching(rootfs, policy.remove, result, checkCancelled)
  removeLocales(rootfs, policy, result)
  if policy.firmware == fwTrim and policy.firmwareExclude.len > 0:
    let fw = rootfs / firmwareDir
    if realDirInRoot(rootfs, firmwareDir):
      removeMatching(fw, policy.firmwareExclude, result, checkCancelled)
      removeDanglingLinks(fw, result)
  if policy.stripElf:
    stripElfFiles(rootfs, policy, run, result, checkCancelled)

proc summary*(stats: TrimStats): string =
  let mib = 1024'i64 * 1024
  result = "removed " & $stats.removedEntries & " entries (" &
      $(stats.removedBytes div mib) & " MiB)"
  if stats.strippedFiles > 0:
    result.add(", stripped " & $stats.strippedFiles & " ELF files (" &
        $(stats.strippedBytesBefore div mib) & " -> " &
        $(stats.strippedBytesAfter div mib) & " MiB)")
  if stats.skippedStrip > 0:
    result.add(", left " & $stats.skippedStrip & " files with xattrs unstripped")
