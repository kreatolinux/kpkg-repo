## Init-independent live boot configuration. No kpkg or CLI initialization here.
import std/[algorithm, os, strutils, tables]
import ../../kpkg/modules/rootfs/[kongue_document, types]

proc validateInitPath*(init: string) =
  ## Keep the path safe for a single kernel command-line argument.
  if init.len < 2 or init[0] != '/':
    raise newException(ValueError, "Init must be an absolute path inside the rootfs")
  for ch in init:
    if ch notin {'a'..'z', 'A'..'Z', '0'..'9', '/', '.', '_', '-', '+'}:
      raise newException(ValueError, "Invalid character in init path")
  for part in init.split('/'):
    if part == "..":
      raise newException(ValueError, "Init path must not contain '..'")

proc resolveRootfsPath*(rootfs, path: string): string =
  ## Resolve symlinks with chroot semantics, including absolute /sbin/init links
  ## and usr-merged /sbin directories. Never resolve against the host root.
  var pending = path.split('/')
  var parts: seq[string]
  var links = 0
  while pending.len > 0:
    let part = pending[0]
    pending.delete(0)
    case part
    of "", ".": continue
    of "..":
      if parts.len > 0: parts.setLen(parts.len - 1)
    else:
      let candidate = rootfs / parts.join("/") / part
      if symlinkExists(candidate):
        inc links
        if links > 40:
          raise newException(ValueError, "Too many symlinks in rootfs path: " & path)
        let target = expandSymlink(candidate)
        if target.isAbsolute: parts.setLen(0)
        pending = target.split('/') & pending
      else:
        parts.add(part)
  result = rootfs / parts.join("/")

proc validateRootfsInit*(rootfs, init: string) =
  validateInitPath(init)
  let resolved = resolveRootfsPath(rootfs, init)
  if not fileExists(resolved):
    raise newException(ValueError, "Rootfs init does not exist: " & init)
  if (getFilePermissions(resolved) * {fpUserExec, fpGroupExec, fpOthersExec}) == {}:
    raise newException(ValueError, "Rootfs init is not executable: " & init)

proc initOverlayPath*(dataDir, initSystem: string): string =
  ## Metadata selects optional customizations, not which init systems may boot.
  if initSystem.len == 0 or initSystem in [".", ".."]: return ""
  for ch in initSystem:
    if ch notin {'a'..'z', 'A'..'Z', '0'..'9', '_', '-'}: return ""
  result = dataDir / "overlays" / initSystem

proc isForeignMetadata(name: string): bool =
  ## AppleDouble sidecars and Finder state is filesystem bookkeeping, never
  ## image content, even when an overlay tree was copied from macOS.
  name == ".DS_Store" or name.startsWith("._")

proc copyRootfsOverlay(source, rootfs: string, relative = "") =
  ## Resolve destination directories with chroot semantics. In particular, an
  ## absolute /etc symlink in the image must never direct writes into host /etc.
  let destinationDir = resolveRootfsPath(rootfs, relative)
  let existed = fileExists(destinationDir) or dirExists(destinationDir) or
      symlinkExists(destinationDir)
  createDir(destinationDir)
  for kind, sourcePath in walkDir(source):
    let child = relative / sourcePath.extractFilename
    if isForeignMetadata(sourcePath.extractFilename): continue
    if kind == pcDir:
      copyRootfsOverlay(sourcePath, rootfs, child)
    else:
      # Resolve the parent, not the final entry: replacing an existing symlink
      # must replace the link itself, rather than writing through its target.
      let destination = resolveRootfsPath(rootfs, child.parentDir) /
          child.extractFilename
      if symlinkExists(destination) or fileExists(destination):
        removeFile(destination)
      case kind
      of pcLinkToFile, pcLinkToDir:
        createSymlink(expandSymlink(sourcePath), destination)
      of pcFile:
        copyFileWithPermissions(sourcePath, destination,
            ignorePermissionErrors = false)
      of pcDir: discard
  # Only the directories this overlay creates take its modes; an existing
  # rootfs directory such as /etc keeps the permissions it was built with.
  if not existed:
    setFilePermissions(destinationDir, getFilePermissions(source))

type
  OverlayFragment* = object
    ## One optional piece of the live image, selected by the features the staged
    ## rootfs has. The manifest is declarative Kongue; conditions are literal
    ## rootfs-relative paths that are resolved with chroot semantics.
    name*, description*, init*: string
    requires*, requiresAny*, excludes*: seq[string]
    dir*: string            ## Fragment directory: the manifest and overlay/

const
  fragmentManifestName* = "fragment.kg"
  fragmentOverlayDir* = "overlay"
  fragmentScalars = ["description", "init"]
  fragmentLists = ["requires", "requires_any", "excludes"]

proc validateFragmentPath(value, field, source: string) =
  ## Conditions name files in the rootfs being staged, not patterns or host paths.
  template fail(why: string) =
    raise newException(ValueError, source & ": " & field & ": " & why & ": '" &
      value & "'")
  if value.len == 0 or value.startsWith("/") or value.endsWith("/"):
    fail("condition paths must be non-empty rootfs-relative paths")
  for part in value.split('/'):
    if part in ["", ".", ".."]:
      fail("condition path components must not be empty, '.' or '..'")
  for ch in value:
    if ch in {'\0', '\n', '\r', '*', '?'}:
      fail("condition paths are literal, not patterns")

proc parseFragmentManifest*(content, source: string): OverlayFragment =
  ## Callers get one error type, whatever the Kongue layer reports.
  var doc: KongueDocument
  try:
    doc = parseDeclarativeKongue(content, source)
    requireKnownFields(doc, source, fragmentScalars, fragmentLists)
  except DeclarativeKongueError as e:
    raise newException(ValueError, e.msg)
  result.description = doc.scalar("description")
  if result.description.len == 0:
    raise newException(ValueError, source & ": missing required field 'description'")
  result.init = doc.scalar("init")
  result.requires = doc.list("requires")
  result.requiresAny = doc.list("requires_any")
  result.excludes = doc.list("excludes")
  # An empty list would read as "no condition" and make the fragment
  # unconditional, which is never what an author meant.
  for field in fragmentLists:
    if doc.lists.hasKey(field) and doc.lists[field].len == 0:
      raise newException(ValueError, source & ": " & field &
          " needs at least one path")
  for path in result.requires:
    validateFragmentPath(path, "requires", source)
  for path in result.requiresAny:
    validateFragmentPath(path, "requires_any", source)
  for path in result.excludes:
    validateFragmentPath(path, "excludes", source)

proc loadFragment*(dir: string): OverlayFragment =
  let manifest = dir / fragmentManifestName
  result = parseFragmentManifest(readFile(manifest), manifest)
  result.name = dir.extractFilename
  result.dir = dir

proc discoverFragments*(dataDir: string): seq[OverlayFragment] =
  ## Every fragment below dataDir/fragments, in directory-name order.
  let root = dataDir / "fragments"
  if not dirExists(root): return
  var names: seq[string]
  for kind, path in walkDir(root):
    if kind == pcDir: names.add path.extractFilename
  names.sort(system.cmp[string])
  for name in names:
    if not fileExists(root / name / fragmentManifestName):
      raise newException(ValueError, "Live overlay fragment has no " &
          fragmentManifestName & ": " & (root / name))
    result.add loadFragment(root / name)

proc pathExistsInRootfs*(rootfs, relative: string): bool =
  ## Resolve inside the rootfs, so absolute links and usr-merged directories do
  ## not look at the host, and a dangling link does not count as present. A path
  ## that cannot be resolved (a link loop, an unreadable directory) counts as
  ## absent rather than failing the build.
  try:
    let resolved = resolveRootfsPath(rootfs, "/" & relative)
    fileExists(resolved) or dirExists(resolved)
  except CatchableError:
    false

proc fragmentApplies*(fragment: OverlayFragment, rootfs, initSystem: string): bool =
  if fragment.init.len > 0 and fragment.init != initSystem: return false
  for path in fragment.requires:
    if not pathExistsInRootfs(rootfs, path): return false
  if fragment.requiresAny.len > 0:
    var found = false
    for path in fragment.requiresAny:
      if pathExistsInRootfs(rootfs, path): found = true
    if not found: return false
  for path in fragment.excludes:
    if pathExistsInRootfs(rootfs, path): return false
  true

proc selectFragments*(rootfs, dataDir, initSystem: string): seq[OverlayFragment] =
  ## Select against the input rootfs, before any overlay is copied, so a
  ## condition always describes the image rather than what an overlay added.
  for fragment in discoverFragments(dataDir):
    if fragmentApplies(fragment, rootfs, initSystem): result.add fragment

proc overlayPaths(source, relative: string, paths: var seq[string]) =
  for kind, path in walkDir(source):
    if isForeignMetadata(path.extractFilename): continue
    let child = relative / path.extractFilename
    if kind == pcDir: overlayPaths(path, child, paths)
    else: paths.add child

proc applyFragments(rootfs: string, fragments: seq[OverlayFragment]): seq[string] =
  ## Fragments may replace base overlay files, but never each other's: two
  ## fragments writing one path is a data error, not a precedence rule. Paths
  ## are compared after chroot resolution, so etc/x and usr/etc/x collide when
  ## the rootfs links /etc to /usr/etc.
  var written = initTable[string, string]()
  for fragment in fragments:
    let overlay = fragment.dir / fragmentOverlayDir
    if dirExists(overlay):
      var paths: seq[string]
      overlayPaths(overlay, "", paths)
      for path in paths:
        let destination = resolveRootfsPath(rootfs, "/" & path)
        if written.hasKey(destination) and written[destination] != fragment.name:
          raise newException(ValueError, "Live overlay fragments '" &
            written[destination] & "' and '" & fragment.name &
            "' both write /" & path)
        written[destination] = fragment.name
      copyRootfsOverlay(overlay, rootfs)
    result.add fragment.name

proc prepareLiveRootfs*(rootfs, dataDir, initSystem, init: string): seq[string]
    {.discardable.} =
  ## Stage the shared overlay, the init-specific overlay, then the fragments
  ## whose conditions the rootfs meets. Returns the applied fragment names.
  ## Live policy (accounts, host name, getty, sshd) is package content, so the
  ## bundled data directory stages nothing; a user-supplied overlay can
  ## intentionally customize an image.
  let selected = selectFragments(rootfs, dataDir, initSystem)
  let sharedOverlay = dataDir / "overlay"
  if dirExists(sharedOverlay):
    copyRootfsOverlay(sharedOverlay, rootfs)
  let specificOverlay = initOverlayPath(dataDir, initSystem)
  if specificOverlay != "" and dirExists(specificOverlay):
    copyRootfsOverlay(specificOverlay, rootfs)
  result = applyFragments(rootfs, selected)
  validateRootfsInit(rootfs, init)

proc liveDracutArgs*(kernelVersion, output: string, modulesDir = "",
                     kernelImage = "", configDir = ""): seq[string] =
  ## Use dracut's shell init, independently of the host and target init systems.
  ## Callers select the target kernel explicitly; never use the running kernel.
  if kernelVersion.len == 0 or output.len == 0:
    raise newException(ValueError, "Dracut requires a kernel version and output path")
  result = @["--force", "--no-hostonly", "--no-hostonly-cmdline",
    "--modules", "base dmsquash-live kernel-modules",
    "--force-drivers", "loop dm_snapshot overlay",
    "--filesystems", "ext4 squashfs iso9660",
    "--omit", "systemd systemd-initrd",
    "--kver", kernelVersion]
  if modulesDir.len > 0: result.add(@["--kmoddir", modulesDir])
  if kernelImage.len > 0: result.add(@["--kernel-image", kernelImage])
  if configDir.len > 0:
    result.add(@["--conf", "/dev/null", "--confdir", configDir])
  result.add(output)

proc liveGrubConfig*(templateText, init: string): string =
  validateInitPath(init)
  if "@INIT@" notin templateText:
    raise newException(ValueError, "GRUB template is missing @INIT@")
  result = templateText.replace("@INIT@", init)

type
  InitramfsGenerator* = enum
    ## Which program produces the initramfs. Lives here, not in erofsimage,
    ## because the ISO builder needs it too and erofsimage imports isobuilder.
    igDracut = "dracut", igBooster = "booster", igKickoff = "kickoff"

proc parseGenerator*(value: string): InitramfsGenerator =
  case value.toLowerAscii
  of "", "dracut": igDracut
  of "booster": igBooster
  of "kickoff": igKickoff
  else:
    raise newException(ValueError,
        "Unknown initramfs generator '" & value &
        "' (use dracut, booster or kickoff)")

proc resolveKickoffTools*(): tuple[builder, init: string] =
  ## Locate the kickoff binaries. They are a pair: the builder writes the archive
  ## and the init goes inside it, so they must come from the same build. The init
  ## is looked for next to the builder first, then on PATH on its own.
  result.builder = findExe("kickoff")
  if result.builder.len == 0:
    raise newException(IOError,
        "kickoff not found on PATH (build it with build.sh -p kickoff, or install it)")
  let sibling = result.builder.parentDir / "kickoff-init"
  if fileExists(sibling):
    result.init = sibling
  else:
    result.init = findExe("kickoff-init")
  if result.init.len == 0:
    raise newException(IOError,
        "kickoff-init not found next to " & result.builder & " or on PATH")

proc kickoffArgs*(rootfs, initBinary, kernelVersion, output, layout: string,
                  isoLabel = ""): seq[string] =
  ## Arguments for `kickoff build`. Kept in one place so the disk and ISO paths
  ## cannot drift.
  result = @["build",
    "--rootfs=" & rootfs,
    "--init=" & initBinary,
    "--kernelVersion=" & kernelVersion,
    "--output=" & output,
    "--layout=" & layout]
  if isoLabel.len > 0:
    result.add("--isoLabel=" & isoLabel)
