## Transactional run3 recipe autoupdater.
##
## Each source group (`sources:` and every `sources_<arch>:`) is updated on its
## own: URLs are re-downloaded with the new version substituted and the group's
## checksum list rewritten positionally with its single family. Keys come from
## the AST (`SourceGroup`), so `sources aarch64:` never collides with
## `sources_aarch64:` or the common list.

import std/[os, strutils, tempfiles]
import regex
import ../../kpkg/modules/checksums
import ../../kpkg/modules/run3/run3
import ../../kpkg/modules/sourcegroups
import ../../kpkg/modules/downloader

proc escapeRegex(s: string): string =
  ## Escape special regex characters in a string.
  result = ""
  for c in s:
    case c
    of '.', '^', '$', '*', '+', '?', '(', ')', '[', ']', '{', '}', '|', '\\':
      result.add('\\')
      result.add(c)
    else:
      result.add(c)

proc normalizedKey(line: string): string =
  ## Whitespace-insensitive form of a list-variable key line.
  ##
  ## A recipe may write `sources  aarch64 :`, so collapsing whitespace finds
  ## the line the recipe wrote without matching a different list.
  let stripped = line.strip()
  if stripped.len == 0:
    return ""
  let colon = stripped.find(':')
  if colon < 0:
    return ""
  # Anything after the colon must be empty or a trailing comment; a list item
  # such as `- "https://example.com/x"` has content after its colon, so it is
  # not a key line.
  let rest = stripped[colon + 1 .. ^1].strip()
  if rest.len > 0 and not rest.startsWith("#"):
    return ""
  result = stripped[0 ..< colon].splitWhitespace().join(" ")

proc isKeyLine(line, key: string): bool =
  ## True when `line` declares the list variable `key`.
  ##
  ## Comparison is on the complete key, so `sha256sum:` never matches
  ## `sha256sum_aarch64:` and `sources:` never matches `sources aarch64:`.
  let wanted = key.strip().splitWhitespace().join(" ")
  result = wanted.len > 0 and normalizedKey(line) == wanted

proc replaceChecksumAtIndex(content, key: string, index: int,
                                oldValue, newValue: string): string =
  ## Replace one checksum list entry by position, inside the list named by the
  ## exact key spelling `key` (which may be the space-qualifier form). Duplicate
  ## values are valid and two lists may share one, so the key selects the list.
  var lines = content.splitLines()
  var inField = false
  var item = 0
  var replaced = false
  for lineIndex in 0 ..< lines.len:
    let stripped = lines[lineIndex].strip
    if not inField:
      if isKeyLine(lines[lineIndex], key): inField = true
      continue
    # A comment line neither ends the list nor counts as an entry; a
    # top-level key line does end it. Kongue rejects a comment inside a list,
    # so this only guards against a future parser change.
    if stripped.len == 0 or stripped.startsWith("#"):
      continue
    if not lines[lineIndex][0].isSpaceAscii:
      break
    if stripped.startsWith("-"):
      if item == index:
        let pattern = "^(\\s*-\\s*\"?)" & escapeRegex(oldValue) &
          "(\"?\\s*)$"
        let expression = re2(pattern)
        if not lines[lineIndex].match(expression):
          raise newException(ValueError, "checksum " & $index &
            " does not match parsed metadata")
        lines[lineIndex] = lines[lineIndex].replace(expression,
          "${1}" & newValue & "${2}")
        replaced = true
        break
      inc item
  if not replaced:
    raise newException(ValueError, "checksum " & $index & " was not found")
  # splitLines retains the terminal empty element, so join preserves the exact
  # final-newline shape; appending a newline here would add a blank EOF line.
  result = lines.join("\n")

proc replaceSourceAtIndex(content, key: string, index: int,
                                newValue: string): string =
  ## Replace one `sources:` list entry by position, retaining the entry's
  ## indentation and quoting. Only the common `sources:` list is passed here,
  ## and only when a backend changes the URL pattern; a bump leaves it alone.
  var lines = content.splitLines()
  var inField = false
  var item = 0
  var replaced = false
  for lineIndex in 0 ..< lines.len:
    let stripped = lines[lineIndex].strip
    if not inField:
      if isKeyLine(lines[lineIndex], key): inField = true
      continue
    # A comment line neither ends the list nor counts as an entry; a
    # top-level key line does end it. Kongue rejects a comment inside a list,
    # so this only guards against a future parser change.
    if stripped.len == 0 or stripped.startsWith("#"):
      continue
    if not lines[lineIndex][0].isSpaceAscii:
      break
    if stripped.startsWith("-"):
      if item == index:
        let line = lines[lineIndex]
        let dash = line.find('-')
        var after = dash + 1
        while after < line.len and line[after] == ' ': inc after
        let quote = if after < line.len and line[after] == '"': "\"" else: ""
        lines[lineIndex] = line[0 .. dash] & " " & quote & newValue & quote
        replaced = true
        break
      inc item
  if not replaced:
    raise newException(ValueError, "source " & $index & " was not found")
  result = lines.join("\n")

proc replaceMetadata(content, key, oldValue, newValue: string): string =
  ## Replace one complete run3 scalar, retaining its original quoting.
  let pattern = "^(" & escapeRegex(key) & ":\\s*\"?)" &
    escapeRegex(oldValue) & "(\"?\\s*)$"
  let expression = re2(pattern, {regexMultiline})
  var matches = 0
  for ignored in content.findAll(expression):
    discard ignored
    inc matches
  if matches != 1:
    raise newException(ValueError, key & " metadata does not occur exactly once")
  result = content.replace(expression, "${1}" & newValue & "${2}")

type SourceFetcher* = proc(source, destination: string) {.closure.}

type SourceRewrite* = object
  ## Replace one entry of the COMMON `sources:` list with a literal URL
  ## instead of letting the version substitution rewrite it.
  ##
  ## `index` counts common `sources:` entries only, the list `getSources()`
  ## returns; `sources_<arch>` groups are appended after them at build time, so
  ## they never shift these indices. `index < 0` disables the rewrite.
  index*: int
  url*: string

type PlannedGroup = object
  ## One source group resolved for the new version, before any download.
  group: SourceGroup
  family: string ## "sha256", "sha512" or "b2" ("" when the group is empty)
  sumKey: string ## Exact spelling of the checksum list to rewrite
  urls: seq[string] ## Version-substituted URLs, in list order
  oldSums: seq[string]
  newSums: seq[string]

proc autoUpdaterWithFetcher*(pkg: Run3File, packageDir: string,
                newVersion: string, skipIfDownloadFails: bool,
                release: string, fetcher: SourceFetcher,
                rewrite = SourceRewrite(index: -1, url: "")) =
  ## Update a run3 recipe as one transaction. All downloads, checksums, and
  ## validation finish before the recipe is atomically replaced.
  echo "Autoupdating.."

  let packageDir = absolutePath(packageDir)
  let runPath = packageDir / "run3"
  if not fileExists(runPath):
    raise newException(IOError, "run3 file not found at: " & runPath)

  # Parse the file that will actually be replaced, not the caller's possibly
  # stale `pkg`, which is kept only for the public signature.
  discard pkg
  let recipe = parseRun3(packageDir)
  let version = recipe.getVersion()
  let pkgRelease = recipe.getRelease()
  let pkgName = recipe.getName()

  # Every source group is updated on its own: the common list and each
  # `sources_<arch>` list have their own checksum family and positional index.
  let groups = sourceGroups(recipe.parsed)
  if groups.len == 0:
    raise newException(ValueError, "recipe defines no sources for '" & pkgName & "'")

  var planned: seq[PlannedGroup] = @[]
  var commonGroup = -1
  for group in groups:
    # Raises ValueError when a group declares two families: the builder would
    # silently prefer one, so such a recipe is invalid.
    let family = group.checksumFamily()
    if family.len == 0 and group.sources.len > 0:
      # An empty group needs no update and no checksums; anything else must
      # name exactly one family.
      raise newException(ValueError, "recipe must define exactly one checksum " &
        "family for '" & pkgName & "': '" & group.sourcesKey &
        "' has no checksum list")
    let sums = group.checksumItems(family)
    if group.sources.len != sums.len:
      raise newException(ValueError, "source/checksum count mismatch for '" &
        pkgName & "' in '" & group.sourcesKey & "': " & $group.sources.len &
        " sources, " & $sums.len & " checksums")
    var urls: seq[string] = @[]
    for source in group.sources:
      urls.add(recipe.substituteVariablesWithVersion(source, newVersion))
    if group.arch.len == 0:
      commonGroup = planned.len
    planned.add(PlannedGroup(group: group, family: family,
      sumKey: group.checksumKey(family), urls: urls, oldSums: sums,
      newSums: sums))

  # A SourceRewrite index addresses the common `sources:` list only, exactly
  # the list the backends computed it from.
  if rewrite.index >= 0:
    if commonGroup < 0:
      raise newException(ValueError, "source rewrite index " & $rewrite.index &
        " is out of range for '" & pkgName &
        "': the recipe has no common 'sources:' list")
    if rewrite.index >= planned[commonGroup].urls.len:
      raise newException(ValueError, "source rewrite index " & $rewrite.index &
        " is out of range for '" & pkgName & "'")
    planned[commonGroup].urls[rewrite.index] = rewrite.url

  # A version bump only changes the checksum of a source whose URL actually
  # depends on the version; a hardcoded URL would keep the old tarball and only
  # the version line would change. Arch groups behave the same.
  if newVersion != version:
    for plan in planned:
      for index, url in plan.urls:
        if not url.contains("://") or plan.oldSums[index] == "SKIP": continue
        let rawSource = plan.group.sources[index]
        if not rawSource.contains("version"):
          raise newException(ValueError, "source " & $index & " of '" &
            plan.group.sourcesKey & "' in '" & pkgName &
            "' has a hardcoded URL (" & rawSource &
            ") that does not use ${version}, so a version bump cannot update " &
            "it; fix the recipe first")

  let workDir = createTempDir("krep-autoupdate-", "")
  defer:
    if dirExists(workDir):
      removeDir(workDir)

  for planIndex in 0 ..< planned.len:
    let label = if planned[planIndex].group.arch.len == 0: "common"
      else: planned[planIndex].group.arch
    for index in 0 ..< planned[planIndex].urls.len:
      let source = planned[planIndex].urls[index]
      # Local entries and SKIP are intentionally not fetched or rewritten.
      if not source.contains("://") or planned[planIndex].oldSums[index] == "SKIP":
        continue

      let downloadPath = workDir / (label & "-" & $index & "-" &
        extractFilename(source).strip())
      try:
        fetcher(source, downloadPath)
        planned[planIndex].newSums[index] = getSum(downloadPath,
          planned[planIndex].family)
      except CatchableError as failure:
        if skipIfDownloadFails:
          echo "WARN: '" & pkgName & "' failed because of download. Skipping."
          return
        raise newException(IOError, "'" & pkgName &
          "' failed because of download: " & failure.msg)

  # Build and validate the complete new recipe in memory.
  var content = readFile(runPath)
  content = replaceMetadata(content, "version", version, newVersion)
  if not isEmptyOrWhitespace(release) and release != pkgRelease:
    content = replaceMetadata(content, "release", pkgRelease, release)
  if rewrite.index >= 0:
    content = replaceSourceAtIndex(content,
      planned[commonGroup].group.sourcesKey, rewrite.index, rewrite.url)

  for plan in planned:
    for index in 0 ..< plan.oldSums.len:
      if plan.newSums[index] == plan.oldSums[index]: continue
      content = replaceChecksumAtIndex(content, plan.sumKey, index,
        plan.oldSums[index], plan.newSums[index])

  # The temporary file is in the package directory, so rename is atomic and
  # can never cross filesystems.
  let (temporary, temporaryPath) = createTempFile(".run3-autoupdate-", ".tmp",
    packageDir)
  temporary.close()
  var installed = false
  defer:
    if not installed and fileExists(temporaryPath):
      removeFile(temporaryPath)
  writeFile(temporaryPath, content)
  let validationDir = createTempDir("krep-validate-", "")
  defer:
    if dirExists(validationDir): removeDir(validationDir)
  writeFile(validationDir / "run3", content)
  let validated = parseRun3(validationDir)
  # Read the rewritten lists back from the AST: a key-matching mistake would
  # otherwise land a checksum in the wrong list and only show up at build time.
  let validatedGroups = sourceGroups(validated.parsed)
  for plan in planned:
    var found = false
    for group in validatedGroups:
      if group.arch != plan.group.arch: continue
      found = true
      if group.checksumItems(plan.family) != plan.newSums:
        raise newException(ValueError, "autoupdate of '" & pkgName &
          "' did not rewrite the checksums of '" & plan.group.sourcesKey & "'")
    if not found:
      raise newException(ValueError, "autoupdate of '" & pkgName &
        "' lost the source group '" & plan.group.sourcesKey & "'")
  setFilePermissions(temporaryPath, getFilePermissions(runPath))
  moveFile(temporaryPath, runPath)
  installed = true

  echo "Autoupdate complete. As always, you should check if the package does build or not."


proc autoUpdater*(pkg: Run3File, packageDir: string, newVersion: string,
                skipIfDownloadFails: bool, release: string = "",
                rewrite = SourceRewrite(index: -1, url: "")) =
  autoUpdaterWithFetcher(pkg, packageDir, newVersion, skipIfDownloadFails,
    release, proc(source, destination: string) =
      download(source, destination, raiseWhenFail = true), rewrite)
