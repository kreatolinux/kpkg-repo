# chkupd v3 GNOME backend: download.gnome.org cache.json
import std/[json, strutils, os, httpclient, parsecfg]
import ../../../kpkg/modules/run3/run3
import ../[autoupdater, upstreamVersions]
import ./stability
import ../../../common/version

# The stability rules live in ./stability so the gitlab backend shares them.
# Re-exported here: they are part of this module's public surface.
export stability

const gnomeSourcesUrl* = "https://download.gnome.org/sources/"

# Aliases for the shared stability rules, used by the tests and call sites.
type GnomeStability* = Stability
const
  gsAny* = stAny
  gsEvenMinor* = stEvenMinor
  gsOddMinor* = stOddMinor

proc tarballPath*(cache: JsonNode, module, version: string): string =
  ## The cache.json entry lists the tarball under "tar.xz", "tar.gz" or
  ## "tar.bz2". Return the cache-relative path (e.g. "4.24/gtk-4.24.1.tar.xz").
  if cache.kind != JArray or cache.len < 2 or cache[1].kind != JObject:
    return ""
  let modules = cache[1]
  if not modules.hasKey(module): return ""
  let releases = modules[module]
  if releases.kind != JObject or not releases.hasKey(version): return ""
  let entry = releases[version]
  if entry.kind != JObject: return ""
  for key in ["tar.xz", "tar.gz", "tar.bz2"]:
    if entry.hasKey(key) and entry[key].kind == JString:
      return entry[key].getStr

proc tarballUrl*(cache: JsonNode, module, version: string): string =
  ## Absolute download URL for one release, or "" when cache.json does not
  ## list a tarball for it.
  let path = tarballPath(cache, module, version)
  if path.len == 0: return ""
  gnomeSourcesUrl & module & "/" & path

proc selectGnomeVersion*(cache: JsonNode, module: string,
    stability: Stability, series = ""): string =
  ## Select the greatest stable version from a download.gnome.org cache.json
  ## document, which is `[1, {"<module>": {"<version>": {...}}}]`. Versions
  ## without a tarball entry are skipped: some keys are stale directory names
  ## ("2.7.0.tar.gz") rather than releases.
  if cache.kind != JArray or cache.len < 2 or cache[1].kind != JObject:
    raise newException(ValueError,
      "download.gnome.org cache.json must be [1, {module: {...}}]")
  let modules = cache[1]
  if not modules.hasKey(module):
    raise newException(ValueError, "cache.json has no module '" & module & "'")
  let releases = modules[module]
  if releases.kind != JObject:
    raise newException(ValueError, "cache.json module '" & module &
      "' is not an object")
  for version in releases.keys:
    if not isStable(version, stability, series): continue
    if tarballPath(cache, module, version).len == 0: continue
    if result.len == 0 or compareUpstreamVersions(version, result) > 0:
      result = version

proc moduleFromSource*(source: string): string =
  ## Derive the download.gnome.org module directory from a source URL.
  ## Handles both tarball URLs and gitlab.gnome.org archive URLs.
  let stripped = source.strip
  if stripped.startsWith(gnomeSourcesUrl):
    let rest = stripped[gnomeSourcesUrl.len .. ^1]
    let slash = rest.find('/')
    if slash > 0: return rest[0 ..< slash]
    return ""
  const gitlabPrefix = "https://gitlab.gnome.org/"
  if stripped.startsWith(gitlabPrefix):
    # <group>/<project>/-/archive/<ref>/<name>.tar.gz
    let parts = stripped[gitlabPrefix.len .. ^1].split('/')
    if parts.len >= 5 and parts[2] == "-" and parts[3] == "archive":
      return parts[1]
  ""

proc recipeModule*(pkg: Run3File, configured: string): string =
  ## The module to query: explicit configuration wins, then the first source
  ## that names a GNOME module.
  result = configured.strip
  if result.len > 0: return
  for source in pkg.getSources():
    let module = moduleFromSource(source)
    if module.len > 0: return module

proc gnomeConfig(packageDir: string): tuple[module, series, stability,
    release, tarball: string] =
  let cfgPath = packageDir / "chkupd.cfg"
  if not fileExists(cfgPath): return
  let cfg = loadConfig(cfgPath)
  result.module = cfg.getSectionValue("gnome", "module", "").strip
  result.series = cfg.getSectionValue("gnome", "series", "").strip
  result.stability = cfg.getSectionValue("gnome", "stability", "").strip
  result.release = cfg.getSectionValue("gnome", "release", "").strip
  result.tarball = cfg.getSectionValue("gnome", "tarball", "").strip

proc gnomeCheck*(package: string, repo: string, autoUpdate = false,
                skipIfDownloadFails = true, verbose = false) =
  let pkgName = lastPathPart(package)
  let packageDir = repo / pkgName
  let pkg = parseRun3(packageDir)
  let config = gnomeConfig(packageDir)
  let module = recipeModule(pkg, config.module)
  if module.len == 0:
    raise newException(ValueError, "no download.gnome.org module found for '" &
      pkgName & "'; set [gnome] module= in chkupd.cfg")
  let stability = if config.stability.len > 0: parseStability(config.stability)
    else: stabilityFor(module)
  let series = if config.series.len > 0: config.series
    else: defaultSeriesFor(module)

  var client = newHttpClient(timeout = 30_000, userAgent = "Klinux chkupd/" & ver &
    " (issuetracker: https://github.com/kreatolinux/src/issues)")
  defer: client.close()
  var response: string
  try:
    response = client.getContent(gnomeSourcesUrl & module & "/cache.json")
  except CatchableError as e:
    raise newException(IOError, "download.gnome.org request failed for module '" &
      module & "': " & e.msg)
  var cache: JsonNode
  try: cache = parseJson(response)
  except JsonParsingError as e:
    raise newException(ValueError,
      "download.gnome.org returned invalid JSON for '" & module & "': " & e.msg)

  let upstream = selectGnomeVersion(cache, module, stability, series)
  let local = pkg.getVersion()
  if verbose:
    echo "chkupd v3 GNOME backend"
    let seriesLabel = if series.len == 0: "any" else: series
    echo "Module: " & module & " (series: " & seriesLabel & ", stability: " &
      $stability & ")"
    echo "Current package version: " & local
    echo "Latest version found: " & (if upstream.len == 0: "none" else: upstream)
  if upstream.len == 0:
    if verbose:
      echo "download.gnome.org has no stable release for module '" & module &
        "'" & (if series.len > 0: " in series " & series else: "") & "."
    return

  let outdated = compareUpstreamVersions(upstream, local) > 0
  if autoUpdate:
    if not outdated:
      echo "Package is already up-to-date."
    else:
      echo "Package is outdated. Updating..."
      # A version bump resets the release to 1 unless the recipe asks to keep
      # it (a rebuild-only recipe can pin release="keep").
      let release = if config.release.toLowerAscii == "keep": pkg.getRelease()
        else: "1"
      var rewrite = SourceRewrite(index: -1)
      if config.tarball.toLowerAscii in ["download", "gnome", "yes", "true"]:
        let url = tarballUrl(cache, module, upstream)
        if url.len > 0:
          for index, source in pkg.getSources():
            if moduleFromSource(source) != module or
                source.startsWith(gnomeSourcesUrl):
              continue
            # Recipes that set extract: false unpack the archive by name
            # (`tar -xf module-$version.tar.gz`), so a different container
            # format would leave nothing to unpack.
            if source.splitFile.ext.toLowerAscii != url.splitFile.ext.toLowerAscii:
              raise newException(ValueError, "cannot rewrite source " & $index &
                " of '" & pkgName & "' from " & source.splitFile.ext &
                " to " & url.splitFile.ext & ": the recipe unpacks it by name")
            rewrite = SourceRewrite(index: index, url: url)
            break
      autoUpdater(pkg, packageDir, upstream, skipIfDownloadFails, release,
        rewrite)
  else:
    if verbose or outdated: echo "Latest version found: " & upstream
    if outdated:
      echo "Package is outdated (current: " & local & ", latest: " & upstream & ")"
    elif verbose: echo "Package is up-to-date (version: " & local & ")"
