## chkupd v3 GitLab backend: any GitLab instance's REST API.
##
## Endpoint: GET https://<host>/api/v4/projects/<url-encoded group/project>/repository/tags
##
## The host and project are derived from a GitLab archive source URL when
## chkupd.cfg does not name them, so a recipe that already fetches
## `https://gitlab.gnome.org/GNOME/gtk/-/archive/<tag>/gtk-<tag>.tar.gz` needs no
## configuration at all. Release stability rules live in ./stability.
import std/[json, strutils, os, httpclient, uri, parsecfg]
import regex
import ../../../kpkg/modules/run3/run3
import ../[autoupdater, upstreamVersions]
import ./stability
import ../../../common/version

type GitlabConfig* = object
  ## Everything the backend needs to query one project, resolved from
  ## chkupd.cfg and the recipe's source URLs.
  host*: string        ## e.g. "gitlab.gnome.org"
  project*: string     ## e.g. "GNOME/gtk" (the full namespace path)
  tagPrefix*: string   ## literal prefix stripped from a tag ("v", "GTK_")
  tagPattern*: string  ## regex with one capture group; overrides tagPrefix
  module*: string      ## reuse this GNOME module's stability/series defaults
  series*: string      ## version series pin ("4", "3.24")
  stability*: string   ## "any" | "even-minor" | "odd-minor" ("" = derive)
  archive*: string     ## "gitlab" rewrites the source line on update
  archiveTemplate*: string ## tag template for the rewrite ("libX11-${version}")
  useReleases*: bool   ## query /releases instead of /repository/tags
  release*: string     ## "keep" keeps the recipe release on a version bump

proc isGitlabHost*(host: string): bool =
  ## True for the well-known public GitLab instances.
  ##
  ## Not a gate: `gitlabConfig` accepts any host from a `/-/archive/` source
  ## URL, so a self-hosted instance works without being listed here.
  const known = ["gitlab.gnome.org", "gitlab.freedesktop.org",
    "salsa.debian.org", "invent.kde.org", "gitlab.com", "framagit.org",
    "gitlab.xfce.org", "gitlab.archlinux.org"]
  host in known

proc splitArchiveUrl*(source: string): tuple[host, project, tagRef: string] =
  ## Decompose a GitLab archive URL:
  ##   https://<host>/<group>/<project>/-/archive/<ref>/<name>.tar.gz
  ## The group may be nested (`xorg/lib/libx11`), so everything before the
  ## `/-/archive/` marker is the project path.
  result = (host: "", project: "", tagRef: "")
  let stripped = source.strip
  if not stripped.startsWith("https://") and not stripped.startsWith("http://"):
    return
  let schemeEnd = stripped.find("://") + 3
  let rest = stripped[schemeEnd .. ^1]
  let slash = rest.find('/')
  if slash <= 0: return
  let host = rest[0 ..< slash]
  let tail = rest[slash + 1 .. ^1]
  let marker = tail.find("/-/archive/")
  # A host is only reported for a real archive URL: a plain project page or a
  # download.gnome.org tarball must not look like a usable GitLab source.
  if marker <= 0: return
  result.host = host
  result.project = tail[0 ..< marker]
  let afterMarker = tail[marker + "/-/archive/".len .. ^1]
  let refSlash = afterMarker.find('/')
  result.tagRef = if refSlash > 0: afterMarker[0 ..< refSlash] else: afterMarker

proc gitlabConfig*(packageDir: string, sources: seq[string]): GitlabConfig =
  ## Resolve the backend configuration: chkupd.cfg first, then the first
  ## GitLab archive source URL in the recipe.
  let cfgPath = packageDir / "chkupd.cfg"
  if fileExists(cfgPath):
    let cfg = loadConfig(cfgPath)
    result.host = cfg.getSectionValue("gitlab", "host", "").strip
    result.project = cfg.getSectionValue("gitlab", "project", "").strip
    result.tagPrefix = cfg.getSectionValue("gitlab", "tagPrefix", "").strip
    result.tagPattern = cfg.getSectionValue("gitlab", "tagPattern", "").strip
    result.module = cfg.getSectionValue("gitlab", "module", "").strip
    result.series = cfg.getSectionValue("gitlab", "series", "").strip
    result.stability = cfg.getSectionValue("gitlab", "stability", "").strip
    result.archive = cfg.getSectionValue("gitlab", "archive", "").strip
    result.archiveTemplate =
      cfg.getSectionValue("gitlab", "archiveTemplate", "").strip
    result.release = cfg.getSectionValue("gitlab", "release", "").strip
    let releases = cfg.getSectionValue("gitlab", "useReleases", "").strip
    result.useReleases = releases.toLowerAscii in ["true", "1", "yes", "y", "on"]
    # `trimString` is the githubReleases spelling of tagPrefix; accept it too so
    # a recipe moved from GitHub keeps working.
    if result.tagPrefix.len == 0:
      result.tagPrefix = cfg.getSectionValue("autoUpdater", "trimString", "").strip
  for source in sources:
    let parts = splitArchiveUrl(source)
    if parts.host.len == 0 or parts.project.len == 0: continue
    if result.host.len == 0: result.host = parts.host
    if result.project.len == 0: result.project = parts.project
    if result.host.len > 0 and result.project.len > 0: break

proc gitlabProjectPath*(project: string): string =
  ## The API path for one project with the namespace URL-encoded.
  ## GitLab requires `GNOME%2Fgtk`, not `GNOME/gtk`, on every instance, so no
  ## host parameter is taken.
  "projects/" & encodeUrl(project, usePlus = false)

proc tagsUrl*(host, project: string, perPage = 100, page = 1): string =
  "https://" & host & "/api/v4/" & gitlabProjectPath(project) &
    "/repository/tags?per_page=" & $perPage & "&page=" & $page

proc releasesUrl*(host, project: string, perPage = 100, page = 1): string =
  "https://" & host & "/api/v4/" & gitlabProjectPath(project) &
    "/releases?per_page=" & $perPage & "&page=" & $page

proc normalizeTag*(tag: string, config: GitlabConfig): string =
  ## Turn a GitLab tag into a bare version string.
  ##
  ## `tagPattern` wins when set: it must match the whole tag and its capture
  ## groups are joined with ".", e.g. `GTK_(\\d+)_(\\d+)_(\\d+)` turns
  ## `GTK_4_24_1` into `4.24.1`. A tag the pattern does not match normalizes to
  ## "", never to the raw tag, so a branch name or a "nightly" tag can never be
  ## mistaken for a version.
  ##
  ## Without `tagPattern` the literal `tagPrefix` is removed once, and a leading
  ## `v` is dropped when the rest starts with a digit, so `v1.2.3` and `1.2.3`
  ## both normalize to `1.2.3` while a tag such as `vte` is left alone.
  result = tag.strip
  if config.tagPattern.len > 0:
    var matched: RegexMatch2
    if not result.match(re2(config.tagPattern), matched):
      return ""
    if matched.groupsCount == 0:
      # A pattern with no capture group is a reasonable thing to write
      # (`\\d+\\.\\d+\\.\\d+`); the whole match is then the version.
      # `group(0)` is the FIRST CAPTURE GROUP, not the whole match, so recover
      # it from the match boundaries.
      let whole = matched.boundaries
      return if whole.a <= whole.b: result[whole.a .. whole.b] else: ""
    var groups: seq[string] = @[]
    for index in 0 ..< matched.groupsCount:
      let slice = matched.group(index)
      let text = if slice.a <= slice.b: result[slice.a .. slice.b] else: ""
      if text.len > 0: groups.add(text)
    if groups.len == 0: return ""
    return groups.join(".")
  if config.tagPrefix.len > 0 and result.startsWith(config.tagPrefix):
    # Only strip when a digit follows, exactly like the `v` rule below: a
    # prefix that would eat part of a word ("v" on "version-2") is not a
    # version prefix.
    let rest = result[config.tagPrefix.len .. ^1].strip
    if rest.len > 0 and rest[0].isDigit:
      result = rest
  if result.len > 1 and result[0] == 'v' and result[1].isDigit:
    result = result[1 .. ^1]

proc entryTag*(entry: JsonNode, useReleases: bool): string =
  ## The tag name carried by one API entry.
  ##
  ## `/repository/tags` calls the tag `name`, but `/releases` calls the release
  ## TITLE `name` and the tag `tag_name` (a fontconfig release is
  ## `{"name": "Release 2.18.3", "tag_name": "2.18.3"}`). Select the field by
  ## endpoint, never by presence, or `useReleases` finds nothing.
  if entry.kind != JObject: return ""
  let key = if useReleases: "tag_name" else: "name"
  if entry.hasKey(key) and entry[key].kind == JString:
    return entry[key].getStr
  ""

proc tagCandidates*(document: JsonNode, config: GitlabConfig): seq[string] =
  ## Every normalized version the API response offers, in document order.
  if document.kind != JArray: return
  for entry in document:
    let raw = entryTag(entry, config.useReleases)
    if raw.len == 0: continue
    let version = normalizeTag(raw, config)
    # A version always starts with a digit. This drops branch names and
    # bookkeeping tags ("nightly", "latest") without a tagPattern per project.
    if version.len == 0 or not version[0].isDigit: continue
    result.add(version)

proc stabilityRule*(config: GitlabConfig): Stability =
  ## The stability rule to apply: an explicit `stability=` wins, then the
  ## `module=`'s own convention, then "any".
  if config.stability.len > 0: return parseStability(config.stability)
  if config.module.len > 0: return stabilityFor(config.module)
  stAny

proc seriesPin*(config: GitlabConfig): string =
  ## The series pin: explicit `series=` wins, then the `module=`'s default.
  if config.series.len > 0: return config.series
  if config.module.len > 0: return defaultSeriesFor(config.module)
  ""

proc selectGitlabVersion*(document: JsonNode, config: GitlabConfig): string =
  ## Greatest stable version in the API response, after normalization.
  ## Tags that do not normalize to a version are skipped, not ranked as 0.
  let stability = stabilityRule(config)
  let series = seriesPin(config)
  for version in tagCandidates(document, config):
    if not isStable(version, stability, series): continue
    if result.len == 0 or compareUpstreamVersions(version, result) > 0:
      result = version

proc mergePages*(pages: seq[JsonNode]): JsonNode =
  ## One document holding every entry of `pages`, in order, so the selection
  ## rules see the whole tag list rather than only its first page.
  result = newJArray()
  for page in pages:
    if page.kind != JArray: continue
    for entry in page: result.add(entry)

proc seriesSatisfied*(document: JsonNode, config: GitlabConfig): bool =
  ## True when the document already yields a version in the pinned series, so a
  ## paged fetch can stop early. Without a series pin there is nothing to look
  ## for beyond the newest tag, which is always on page 1.
  let series = seriesPin(config)
  if series.len == 0: return true
  let stability = stabilityRule(config)
  for version in tagCandidates(document, config):
    if isStable(version, stability, series): return true
  false

proc archiveUrl*(config: GitlabConfig, rawTag, projectName: string): string =
  ## The GitLab archive URL for one release, from the RAW tag.
  ##
  ## The tag must be the one the API reported, not a version reconstructed from
  ## it: `v1.7.0` and `1.7.0` are different archives. Use `rawTagFor`.
  ##
  ## `projectName` is the `<name>` in `<name>-<tag>.tar.gz` and selects the
  ## extracted root directory, so a wrong stem breaks a recipe that unpacks the
  ## archive by name. See `archiveStemFor`.
  "https://" & config.host & "/" & config.project & "/-/archive/" & rawTag &
    "/" & projectName & "-" & rawTag & ".tar.gz"

proc archiveStemFor*(sources: seq[string], config: GitlabConfig,
    projectName: string): string =
  ## The `<name>` part of the archive filename, taken from the recipe's own
  ## source URL when it already points at this project.
  ##
  ## That URL is the only authority on the stem, because the recipe's
  ## `extract: false` step unpacks by that name. Only when the recipe does not
  ## fetch this project do we fall back to the project path's last segment.
  const containers = [".tar.gz", ".tar.xz", ".tar.bz2", ".tgz", ".tar.zst",
    ".zip"]
  for source in sources:
    let parts = splitArchiveUrl(source)
    if parts.host != config.host or parts.project != config.project: continue
    let tail = source.strip.split('/')
    if tail.len < 2: continue
    var file = tail[^1]
    for c in containers:
      if file.toLowerAscii.endsWith(c):
        file = file[0 ..< file.len - c.len]
        break
    # The filename is `<stem>-<tag>`; strip the tag the URL itself names, which
    # is the only reliable separator since a stem may contain dashes
    # (libX11-1.8.14 is the stem `libX11` plus the tag `1.8.14`).
    let tag = parts.tagRef
    if tag.len > 0 and file.endsWith("-" & tag):
      return file[0 ..< file.len - tag.len - 1]
    let dash = file.rfind('-')
    if dash > 0: return file[0 ..< dash]
  projectName

proc tagTemplateFor*(config: GitlabConfig, rawTag, version: string): string =
  ## The tag as a template that survives the NEXT version bump.
  ##
  ## `autoupdater` refuses to bump a recipe whose source URL does not contain
  ## `${version}`, so writing the literal tag would make `archive="gitlab"`
  ## one-shot. Replacing the version inside the observed tag keeps the tag's own
  ## decoration (`v`, `libX11-`). With `tagPattern` set the tag cannot be
  ## reconstructed, so the caller must supply `archiveTemplate=`.
  if config.archiveTemplate.len > 0: return config.archiveTemplate
  if version.len > 0 and rawTag.endsWith(version):
    return rawTag[0 ..< rawTag.len - version.len] & "${version}"
  # A tag that does not literally end in the version (a tagPattern with several
  # capture groups) cannot be templated safely; leave the raw tag.
  rawTag

proc rawTagFor*(document: JsonNode, config: GitlabConfig,
    version: string): string =
  ## The raw tag name whose normalized form is `version`. Needed to build the
  ## archive URL when `tagPattern` is set.
  if document.kind != JArray: return ""
  for entry in document:
    let raw = entryTag(entry, config.useReleases)
    if raw.len > 0 and normalizeTag(raw, config) == version: return raw

proc projectNameFor*(config: GitlabConfig): string =
  ## The archive's `<name>-<tag>.tar.gz` stem: the project path's last part.
  let parts = config.project.split('/')
  if parts.len == 0: return ""
  parts[^1]

proc gitlabCheck*(package: string, repo: string, autoUpdate = false,
                skipIfDownloadFails = true, verbose = false) =
  let pkgName = lastPathPart(package)
  let packageDir = repo / pkgName
  let pkg = parseRun3(packageDir)
  let config = gitlabConfig(packageDir, pkg.getSources())
  if config.host.len == 0 or config.project.len == 0:
    raise newException(ValueError, "no GitLab host/project found for '" & pkgName &
      "'; set [gitlab] host= and project= in chkupd.cfg")
  if not config.project.contains('/'):
    raise newException(ValueError, "GitLab project must be group/name: " &
      config.project)

  var client = newHttpClient(timeout = 30_000, userAgent = "Klinux chkupd/" & ver &
    " (issuetracker: https://github.com/kreatolinux/src/issues)")
  defer: client.close()
  # Report the status code, not just "request failed". The operator's correct
  # response to a 429 (wait or set a token) differs from a 404 (fix [gitlab]
  # project=), and gitlab.gnome.org rate-limits unauthenticated calls per IP.
  proc fetchPage(page: int): JsonNode =
    ## One API page, with the status code turned into an actionable error.
    let pageUrl = if config.useReleases:
      releasesUrl(config.host, config.project, page = page)
      else: tagsUrl(config.host, config.project, page = page)
    var body: string
    try:
      let raw = client.get(pageUrl)
      case raw.code
      of Http200:
        body = raw.body
      of Http429:
        # HttpHeaders maps a name to a list of values; take the first one, or
        # "?" when the header is absent (GitLab does not always send it).
        var retryAfter = "?"
        if raw.headers.hasKey("Retry-After"):
          let values = seq[string](raw.headers["Retry-After"])
          if values.len > 0 and values[0].len > 0: retryAfter = values[0]
        raise newException(IOError, "GitLab rate limit exhausted for " &
          config.host & " (retry after " & retryAfter & "s); unauthenticated " &
          "requests are limited per IP, so wait or configure a token")
      of Http404:
        raise newException(ValueError, "GitLab project not found: " & config.host &
          "/" & config.project & " (check [gitlab] project=)")
      else:
        raise newException(IOError, "GitLab returned HTTP " & $raw.code & " for " &
          config.host & "/" & config.project)
    except CatchableError as e:
      if e of IOError or e of ValueError: raise
      raise newException(IOError, "GitLab request failed for " & config.host &
        "/" & config.project & ": " & e.msg)
    try: result = parseJson(body)
    except JsonParsingError as e:
      # Include the head of the body: a captive portal, a proxy error page or a
      # login redirect all return 200 with HTML.
      let head = body.strip.replace("\n", " ")
      raise newException(ValueError, config.host & " returned invalid JSON for " &
        config.project & ": " & e.msg & " (body starts: " &
        head[0 ..< min(80, head.len)] & ")")
    if result.kind != JArray:
      raise newException(ValueError, config.host & " response for " &
        config.project & " is not a JSON array")

  # Page 1 holds the newest tag (GitLab orders tags by commit date), so one
  # request answers the common case. Only a series pin pointing at an older line
  # needs more pages, so stop as soon as the pinned series is satisfied.
  const maxPages = 5
  var pages: seq[JsonNode] = @[]
  for page in 1 .. maxPages:
    let chunk = fetchPage(page)
    pages.add(chunk)
    if chunk.len < 100: break
    if seriesSatisfied(mergePages(pages), config): break
  let document = mergePages(pages)

  let upstream = selectGitlabVersion(document, config)
  let local = pkg.getVersion()
  if verbose:
    echo "chkupd v3 GitLab backend"
    echo "Project: " & config.host & "/" & config.project
    echo "Stability: " & $stabilityRule(config) & " (series: " &
      (if seriesPin(config).len == 0: "any" else: seriesPin(config)) & ")"
    echo "Current package version: " & local
    echo "Latest version found: " & (if upstream.len == 0: "none" else: upstream)
  if upstream.len == 0:
    # Distinguish "upstream has no stable release" from "your configuration
    # cannot read these tags": a project whose tags are all `libX11-1.8.14`
    # yields zero candidates without a tagPattern, and silence would read as
    # "upstream has no releases" rather than "set tagPattern=".
    if document.len > 0 and tagCandidates(document, config).len == 0:
      raise newException(ValueError, "none of the " & $document.len & " tags of " &
        config.host & "/" & config.project & " look like a version; set [gitlab] " &
        "tagPattern= (for example tagPattern=\"" & projectNameFor(config) &
        "-(\\\\d+\\\\.\\\\d+\\\\.\\\\d+)\") or tagPrefix=")
    if verbose:
      echo "No stable release found for " & config.project &
        (if seriesPin(config).len > 0: " in series " & seriesPin(config) else: "") &
        "."
    return

  let outdated = compareUpstreamVersions(upstream, local) > 0
  if autoUpdate:
    if not outdated:
      echo "Package is already up-to-date."
    else:
      echo "Package is outdated. Updating..."
      let release = if config.release.toLowerAscii == "keep": pkg.getRelease()
        else: "1"
      var rewrite = SourceRewrite(index: -1)
      if config.archive.toLowerAscii in ["gitlab", "yes", "true", "download"]:
        let rawTag = rawTagFor(document, config, upstream)
        if rawTag.len > 0:
          # Emit a TEMPLATED url, not a literal one. `autoupdater` refuses to
          # bump a recipe whose source URL does not mention ${version}.
          let tagTemplate = tagTemplateFor(config, rawTag, upstream)
          let stem = archiveStemFor(pkg.getSources(), config,
            projectNameFor(config))
          let url = archiveUrl(config, tagTemplate, stem)
          for index, source in pkg.getSources():
            let parts = splitArchiveUrl(source)
            if parts.host != config.host or parts.project != config.project:
              continue
            # A recipe that unpacks the archive by name needs the same
            # container format. Compare the COMPOUND extension: splitFile.ext
            # is only ".gz", so ".tar.bz2" would look like a match.
            const containers = [".tar.gz", ".tar.xz", ".tar.bz2", ".tgz",
              ".tar.zst", ".zip"]
            proc containerOf(url: string): string =
              for c in containers:
                if url.toLowerAscii.endsWith(c): return c
              url.splitFile.ext.toLowerAscii
            if containerOf(source) != containerOf(url):
              raise newException(ValueError, "cannot rewrite source " & $index &
                " of '" & pkgName & "' from " & containerOf(source) & " to " &
                containerOf(url) & ": the recipe unpacks it by name")
            rewrite = SourceRewrite(index: index, url: url)
            break
      autoUpdater(pkg, packageDir, upstream, skipIfDownloadFails, release,
        rewrite)
  else:
    if verbose or outdated: echo "Latest version found: " & upstream
    if outdated:
      echo "Package is outdated (current: " & local & ", latest: " & upstream & ")"
    elif verbose: echo "Package is up-to-date (version: " & local & ")"
