## Shared upstream release-stability rules.
##
## Both GNOME numbering conventions also show up on the GitLab instances that
## host the projects, so the rules live here: `gnome` applies them to
## download.gnome.org cache.json keys, `gitlab` to GitLab tag names.
import std/[strutils]

type Stability* = enum
  ## How a module numbers its releases. GNOME uses two conventions.
  stAny = "any"               ## only alpha/beta/rc markers mean unstable
  stEvenMinor = "even-minor"  ## odd minor = unstable development series
  stOddMinor = "odd-minor"    ## even minor = unstable development series

proc stabilityFor*(module: string): Stability =
  ## Per-module stability convention, from each module's own release notes
  ## and branch layout.
  ##
  ## The modules listed below keep the historical even/odd minor scheme (glib
  ## 2.89.x -> 2.90.0, gtk 4.25.0 -> 4.26, libsoup 3.7.x -> 3.8, ...).
  ## Everything else publishes unstable releases with explicit alpha/beta/rc
  ## markers only, and its odd minors are long-lived stable series (librsvg
  ## 2.63.x, libadwaita 1.10.x, libsecret 0.21.x, libxml2 2.15.x, ...).
  case module
  of "glib", "gtk", "gtk+", "pango", "gdk-pixbuf", "gobject-introspection",
      "at-spi2-core", "libsoup", "gtksourceview", "vte", "json-glib", "gjs",
      "libgee", "libpeas", "gssdp", "gupnp", "gupnp-av", "gupnp-dlna",
      "libgdata", "template-glib", "libdazzle", "libnma", "libhandy", "vala",
      "evolution-data-server":
    stEvenMinor
  else:
    stAny

proc defaultSeriesFor*(module: string): string =
  ## Series pin used when chkupd.cfg does not set one: modules whose current
  ## stable line is not the greatest published line need it. The rest are
  ## filtered by the stability rule alone.
  case module
  of "gtk": "4"           ## 3.x is the previous stable line, 4.x the current
  of "gtk+": "3.24"       ## the module also carries the abandoned 3.9x GTK4
                          ## development series and 3.x below 3.24
  of "gcr": "4"           ## gcr-3 (the GTK3 flavour) pins its own series
  of "pango": "1.58"      ## 1.90 is the unstable series leading to Pango 2.0
  of "libsoup": "3"       ## libsoup2 lives in the separate libsoup2 recipe
  of "gtksourceview": "5"
  of "libgweather": "4"   ## 40.x is the abandoned 3.x-era line
  of "libhandy": "1"
  of "libnma": "1"
  of "gnome-bluetooth": "47"
  of "evolution-data-server": "3"
  of "libsecret": "0.21"
  of "vala": "0.56"
  of "libgtop": "2.41"
  of "libgudev": "238"
  of "libxslt": "1.1"
  of "cantarell-fonts": "0.303"
  of "libgxps": "0.3"
  of "libmediaart": "1.9"
  else: ""

proc parseStability*(value: string): Stability =
  let normalized = value.strip.toLowerAscii
  case normalized
  of "", "any", "all", "none": stAny
  of "even-minor", "even", "evenminor": stEvenMinor
  of "odd-minor", "odd", "oddminor": stOddMinor
  else:
    raise newException(ValueError, "unknown stability rule '" & value &
      "' (expected any, even-minor or odd-minor)")

proc versionParts*(version: string): seq[string] =
  ## Split a GNOME version into its components. A few very old cache.json
  ## entries carry the tarball suffix in the key, so strip it.
  var cleaned = version.strip
  for suffix in [".tar.xz", ".tar.gz", ".tar.bz2"]:
    if cleaned.endsWith(suffix):
      cleaned = cleaned[0 ..< cleaned.len - suffix.len]
  for part in cleaned.split({'.', '-', '_', '+', '~'}):
    if part.len > 0: result.add(part)

proc hasPrereleaseMarker*(version: string): bool =
  ## GNOME marks development releases with alpha/beta/rc components, or with
  ## the historical 90-99 micro numbers (1.2.90, 2.61.90) that predate them.
  let parts = versionParts(version)
  for part in parts:
    let lowered = part.toLowerAscii
    if lowered == "alpha" or lowered == "beta" or lowered == "rc" or
        lowered == "pre" or lowered == "preview" or lowered == "dev" or
        lowered == "snapshot":
      return true
    if lowered.startsWith("alpha") or lowered.startsWith("beta") or
        lowered.startsWith("rc"):
      return true
  if parts.len >= 3:
    let micro = parts[2]
    if micro.len > 0 and micro.allCharsInSet({'0'..'9'}):
      let value = parseInt(micro)
      if value >= 90 and value < 100: return true
  false

proc seriesMatches*(version, series: string): bool =
  ## True when `version` belongs to `series`. "4" matches 4.24.1 but not
  ## 5.0.0; "3.24" matches 3.24.43; an empty series matches everything.
  if series.len == 0: return true
  let versionParts = versionParts(version)
  let seriesParts = series.strip.split('.')
  if versionParts.len < seriesParts.len: return false
  for index, expected in seriesParts:
    if versionParts[index] != expected: return false
  true

proc isStable*(version: string, stability: Stability,
    series = ""): bool =
  ## Apply one module's release rules to a candidate version string.
  if version.len == 0 or hasPrereleaseMarker(version): return false
  if not seriesMatches(version, series): return false
  if stability == stAny: return true
  let parts = versionParts(version)
  if parts.len < 2: return true
  let minor = parts[1]
  if minor.len == 0 or not minor.allCharsInSet({'0'..'9'}): return true
  let isEven = parseInt(minor) mod 2 == 0
  if stability == stEvenMinor: isEven else: not isEven
