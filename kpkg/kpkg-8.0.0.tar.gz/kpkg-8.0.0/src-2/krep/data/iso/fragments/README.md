# Live overlay fragments

`krep iso` stages, in this order:

1. `overlay/` — shared files, applied to every image.
2. `overlays/<init>/` — the init named by `/etc/kreato-release` `[Core] init`
   (e.g. `jumpstart`).
3. the fragments in this directory whose conditions the input rootfs meets.

No Kreato live policy is bundled here. Host name, live accounts, machine ID,
getty and sshd rules belong to the packages that need them (for a Jumpstart
live medium: `kreato-live-essentials`), so an image gets them from the package
manager like any other file and an installed system is not mistaken for a live
one. What remains is the mechanism, for a `--dataDir` of your own.

Conditions are evaluated against the input rootfs, before any overlay is copied,
so a fragment can only test what the image's packages provide, never a file that
an overlay or another fragment adds.

A fragment is what makes an *optional* piece of an image modular, so an image
without that feature never gets its files.

## Layout

```
fragments/<name>/fragment.kg     manifest, describes when the fragment applies
fragments/<name>/overlay/...     rootfs-relative files copied onto the staged rootfs
```

Fragments are applied in directory-name order, after the init overlay, so a
fragment can replace a base file. Two fragments writing the same path is an
error, even when they spell it differently (`etc/x` and `usr/etc/x` are one file
when `/etc` links to `/usr/etc`).

## Manifest

```kongue
description: "One line, required"
init: "jumpstart"          # optional: apply only for this init; absent = any init
requires: [...]            # every rootfs-relative path must exist
requires_any: [...]        # at least one must exist
excludes: [...]            # none may exist
```

Only those five fields are accepted, a list may not be empty, and an unknown
field or a path that is absolute, contains `.`/`..` components or a `*`/`?` is
rejected. Conditions are literal rootfs-relative paths (no globs), resolved with
the same chroot semantics as the copy itself, so a usr-merged `usr/sbin -> bin`
link makes `usr/sbin/sshd` match `usr/bin/sshd`. Prefer a path that exists only
when the feature is installed (the unit file, the binary, the configuration
file) over a package-manager database, which is not available on an archive
input.

`fragment.kg` is a declarative Kongue document: scalars and `- "list"` items
only, comments allowed.
