import os
import strutils
import tables
import terminal
import ../../kongue/lexer
import ../../kongue/parser
import ../../kongue/ast
import ../../kpkg/modules/arch
import ../../kpkg/modules/sourcegroups

type
  LintSeverity = enum
    lsError = "error"
    lsWarning = "warning"
    lsInfo = "info"

  LintIssue = object
    severity: LintSeverity
    line: int
    col: int
    message: string

proc addIssue(issues: var seq[LintIssue], severity: LintSeverity, line: int,
    message: string, col: int = 0) =
  issues.add(LintIssue(severity: severity, line: line, col: col,
      message: message))

const
  # Checksum families in the order a message should list them.
  checksumFamilies = ["sha256", "sha512", "b2"]

  # Dependency list keys that may carry a qualifier. `depends_<x>` means either
  # architecture <x> or sub-package <x>, in every spelling runparser accepts.
  dependencyListBases = [
    "bootstrap_depends", "bootstrap-depends", "bootstrapdepends",
    "build_depends", "build-depends", "builddepends",
    "depends"
  ]

  # Keys the "dependency name contains spaces" check has always covered. It is
  # deliberately narrower than dependencyListBases: adding bootstrap_depends
  # would turn clean recipes into errors.
  spaceCheckedDependencyBases = ["build_depends", "build-depends",
    "builddepends", "depends"]

type
  ListKey = object
    ## A list-variable key split into its parts.
    base: string ## `sources`, `sha256sum`, `depends`, ...
    qualifier: string ## Exact qualifier spelling, "" when unqualified
    spelling: string ## The key exactly as the recipe wrote it
    lookup: string ## Full Kongue name both spellings share

proc decomposeListKey(node: AstNode): ListKey =
  ## Split a list-variable key into (base, qualifier, spelling, lookup).
  ##
  ## Mirrors the private `sourcegroups.splitKey`: `sources_aarch64:` parses as
  ## listName "sources_aarch64", `sources aarch64:` as listName "sources" with
  ## qualifier "aarch64"; both fold onto the same (base, qualifier) pair.
  let name = node.listName
  if node.listQualifier.len > 0:
    return ListKey(base: name, qualifier: node.listQualifier,
        spelling: name & " " & node.listQualifier,
        lookup: name & "_" & node.listQualifier)

  for base in @[sourcesBaseKey] & @checksumBaseKeys:
    if name.len > base.len and name.startsWith(base) and name[base.len] == '_':
      return ListKey(base: base, qualifier: name[base.len + 1 .. ^1],
          spelling: name, lookup: name)

  for base in dependencyListBases:
    if name.len > base.len and name.startsWith(base) and
        name[base.len] in {'_', '-'}:
      return ListKey(base: base, qualifier: name[base.len + 1 .. ^1],
          spelling: name, lookup: name)

  return ListKey(base: name, qualifier: "", spelling: name, lookup: name)

proc entryCount(count: int): string =
  ## "1 entry" / "2 entries", so lint messages read like sentences.
  $count & (if count == 1: " entry" else: " entries")

proc checksumKeyFor(group: SourceGroup, base: string): string =
  ## The checksum key that would match `group`'s sources key.
  ##
  ## A `SourceGroup` keeps only the normalized architecture, so the spelling is
  ## recovered from the sources key ("sources arm64" -> "sha256sum arm64"); a
  ## common group yields the bare base.
  base & group.sourcesKey[sourcesBaseKey.len .. ^1]

type
  RecipeContext = object
    ## What lint knows about the recipe a `depends_<qualifier>` key lives in.
    ##
    ## A qualifier is a sub-package name when the recipe implements that
    ## sub-package, so every name the recipe could be addressing is collected.
    packageNames: seq[string] ## Directory name and `name:`, normalized
    subPackages: seq[string] ## Names derived from `package_<x>` / `build_<x>`

proc normalizePackageName(name: string): string =
  ## kpkg compares dependency qualifiers against the package name with dashes
  ## turned into underscores (`runparser.parseRunfile`), so lint matches that.
  name.replace('-', '_').toLowerAscii()

proc recipeContext(parsed: ParsedScript, packageDir: string): RecipeContext =
  ## Collect the package names and sub-package names a recipe defines.
  ##
  ## kpkg's runparser matches `depends_<qualifier>` against the directory name
  ## (`lastPathPart(path)`), not `name:`, so both are accepted: they normally
  ## agree, and either one is evidence.
  if packageDir.len > 0:
    result.packageNames.add(normalizePackageName(packageDir))
  for varNode in parsed.variables:
    if varNode.kind == nkVariable and varNode.varName == "name":
      let normalized = normalizePackageName(varNode.varValue)
      if normalized.len > 0 and normalized notin result.packageNames:
        result.packageNames.add(normalized)
      break

  # A sub-package is defined by the functions that implement it: `src/run3`
  # has `package_kpkg {}` and `func build_kpkg`, so `depends_kpkg` addresses
  # the `kpkg` sub-package even though neither the directory nor `name:` does.
  var subPackages: seq[string] = @[]
  for funcNode in parsed.functions:
    if funcNode.kind == nkFunction:
      subPackages.add(getFullFuncName(funcNode))
  for funcNode in parsed.customFuncs:
    if funcNode.kind == nkCustomFunc:
      subPackages.add(funcNode.customFuncName)
  for fullName in subPackages:
    let separator = fullName.find('_')
    if separator <= 0 or separator == fullName.high:
      continue
    let name = fullName[separator + 1 .. ^1].toLowerAscii()
    if name.len > 0 and name notin result.subPackages:
      result.subPackages.add(name)

proc looksLikeArchAttempt(qualifier: string, context: RecipeContext): bool =
  ## Whether a dependency qualifier is an *architecture attempt* rather than a
  ## sub-package name.
  ##
  ## Only a qualifier equal to the package name or the target architecture is
  ## ever applied, so a known arch or alias, the package name, an implemented
  ## sub-package, or a non-alphanumeric qualifier is never reported; anything
  ## left names nothing and is a typo.
  if qualifier.len == 0:
    return false
  if isKnownArch(qualifier):
    return false
  let normalized = qualifier.toLowerAscii()
  if normalized in context.packageNames:
    return false
  if normalized in context.subPackages:
    return false
  for c in qualifier:
    if c notin {'a' .. 'z', 'A' .. 'Z', '0' .. '9'}:
      return false
  return true

proc lintSourceGroups(parsed: ParsedScript, packageDir: string,
    issues: var seq[LintIssue]) =
  ## Lint per-architecture source groups: `sources_<arch>` with their matching
  ## `sha256sum_<arch>` / `sha512sum_<arch>` / `b2sum_<arch>` lists.
  ##
  ## The raw variables are walked rather than `sourceGroups`, because lint needs
  ## line numbers and must see stray lists and duplicate keys.
  var lines = initTable[string, int]()
  var sourcesByArch =
      initTable[string, seq[tuple[spelling: string, line: int]]]()
  var anyChecksums = false

  for varNode in parsed.variables:
    if varNode.kind != nkListVariable:
      continue
    let key = decomposeListKey(varNode)
    if not lines.hasKey(key.lookup):
      lines[key.lookup] = varNode.line
    if key.base in checksumBaseKeys:
      anyChecksums = true
    if key.base == sourcesBaseKey and key.qualifier.len > 0:
      sourcesByArch.mgetOrPut(normalizeArch(key.qualifier), @[]).add(
          (spelling: key.spelling, line: varNode.line))

  # Two keys that normalize onto the same architecture are a hard error: kpkg
  # selects a group by normalized target arch, so the other one never applies.
  for arch, entries in sourcesByArch:
    if entries.len < 2:
      continue
    var names: seq[string] = @[]
    for entry in entries:
      names.add(entry.spelling)
    issues.addIssue(lsError, entries[^1].line,
        "duplicate source group for architecture '" & arch & "': " &
        names.join(", ") & " all normalize to '" & arch &
        "', only one of them is ever selected")

  let knownList = knownArchNames.join(", ")
  let groupArchs = archNames(parsed)

  for varNode in parsed.variables:
    if varNode.kind != nkListVariable:
      continue
    let key = decomposeListKey(varNode)
    if key.qualifier.len == 0:
      continue
    let isSourcesKey = key.base == sourcesBaseKey
    let isChecksumKey = key.base in checksumBaseKeys
    if not (isSourcesKey or isChecksumKey):
      continue
    if not isKnownArch(key.qualifier):
      issues.addIssue(lsWarning, varNode.line,
          "unknown architecture '" & key.qualifier & "' in " & key.spelling &
          " (known: " & knownList & ")")
    elif isChecksumKey and normalizeArch(key.qualifier) notin groupArchs:
      # An unknown qualifier is already reported above; reporting it as a stray
      # list too would double-report a typo. The separator comes from the
      # checksum key's own spelling, so the message names the key it wrote.
      let separator = if ' ' in key.spelling: " " else: "_"
      issues.addIssue(lsWarning, varNode.line,
          key.spelling & " has no matching " & sourcesBaseKey & separator &
          key.qualifier & " list")

  # `depends_<arch>` and friends. Only a qualifier that looks like a single
  # architecture token is reported; see looksLikeArchAttempt for the rule.
  let context = recipeContext(parsed, packageDir)

  for varNode in parsed.variables:
    if varNode.kind != nkListVariable:
      continue
    let key = decomposeListKey(varNode)
    if key.base notin dependencyListBases or key.qualifier.len == 0:
      continue
    if looksLikeArchAttempt(key.qualifier, context):
      issues.addIssue(lsWarning, varNode.line,
          "unknown architecture '" & key.qualifier & "' in " & key.spelling &
          " (known: " & knownList & ")")

  # Per-group checksum checks. The global "sources defined but no checksums"
  # warning in lintVariables stays; this one is per group, so a recipe whose
  # common list has sums but whose arch group has none is flagged too.
  for group in sourceGroups(parsed):
    let line = lines.getOrDefault(group.sourcesLookup, 0)
    var declared: seq[string] = @[]
    for family in checksumFamilies:
      let key = checksumKey(group, family)
      if key.len > 0:
        declared.add(key)

    if declared.len > 1:
      # Checked on the declared keys rather than through `checksumFamily`,
      # which counts items and would miss an empty second list; naming the keys
      # also tells the author exactly which lines to delete.
      issues.addIssue(lsError, line,
          "source group '" & group.sourcesKey &
          "' declares more than one checksum family: " & declared.join(", "))
    elif declared.len == 0 and (anyChecksums or group.arch.len > 0):
      # A recipe with no checksums anywhere and a common `sources:` list is
      # already reported by the global warning, so this fires only when that one
      # cannot: another group has sums, or the sources are arch-only.
      issues.addIssue(lsWarning, line,
          group.sourcesKey & " has no checksums (" &
          checksumKeyFor(group, "sha256sum") & "/" &
          checksumKeyFor(group, "sha512sum") & "/" &
          checksumKeyFor(group, "b2sum") & ")")

    for family in checksumFamilies:
      let key = checksumKey(group, family)
      if key.len == 0:
        continue
      let items = checksumItems(group, family)
      if items.len != group.sources.len:
        issues.addIssue(lsError,
            lines.getOrDefault(checksumLookup(group, family), line),
            key & " has " & entryCount(items.len) & " but " &
            group.sourcesKey & " has " & $group.sources.len)

proc lintVariables(parsed: ParsedScript, issues: var seq[LintIssue]) =
  ## Lint variable declarations
  var hasName = false
  var hasVersion = false
  var hasRelease = false
  var hasDescription = false
  var hasSources = false
  var hasChecksums = false

  for varNode in parsed.variables:
    case varNode.kind
    of nkVariable:
      case varNode.varName
      of "name":
        hasName = true
        if varNode.varValue.len == 0:
          issues.addIssue(lsError, varNode.line, "name cannot be empty")
      of "version":
        hasVersion = true
        if varNode.varValue.len == 0:
          issues.addIssue(lsError, varNode.line, "version cannot be empty")
      of "release":
        hasRelease = true
        if varNode.varValue.len == 0:
          issues.addIssue(lsError, varNode.line, "release cannot be empty")
        try:
          discard parseInt(varNode.varValue)
        except ValueError:
          issues.addIssue(lsWarning, varNode.line,
              "release should be a number, got: " & varNode.varValue)
      of "description":
        hasDescription = true
        if varNode.varValue.len == 0:
          issues.addIssue(lsWarning, varNode.line, "description is empty")
      of "epoch":
        if varNode.varValue != "no":
          try:
            discard parseInt(varNode.varValue)
          except ValueError:
            issues.addIssue(lsWarning, varNode.line,
                "epoch should be a number or 'no', got: " & varNode.varValue)
      of "extract":
        if varNode.varValue.toLowerAscii() notin ["true", "false", "1", "0",
            "yes", "no", "y", "n", "on", "off"]:
          issues.addIssue(lsWarning, varNode.line,
              "extract should be a boolean value, got: " & varNode.varValue)
      of "type":
        if varNode.varValue notin ["group", "meta", "normal", ""]:
          issues.addIssue(lsInfo, varNode.line,
              "unusual package type: " & varNode.varValue)
      else:
        discard

    of nkListVariable:
      # Keys are decomposed so the arch-qualified spellings
      # (`sources_aarch64:`, `sources aarch64:`, `depends_aarch64:`) get the
      # same treatment as their unqualified counterparts.
      let key = decomposeListKey(varNode)
      if key.base == sourcesBaseKey and key.qualifier.len == 0:
        hasSources = true
        if varNode.listItems.len == 0:
          issues.addIssue(lsInfo, varNode.line,
              "sources list is empty (meta/group package?)")
      elif key.base in checksumBaseKeys:
        hasChecksums = true
        for item in varNode.listItems:
          if item == "SKIP":
            issues.addIssue(lsInfo, varNode.line,
                "checksum verification is skipped for one or more sources")
            break
      elif key.base in spaceCheckedDependencyBases:
        # Covers `depends` / `build_depends` and every arch-qualified or
        # sub-package-qualified spelling of them (`depends_aarch64`,
        # `build_depends_x86_64`, `depends_glibc`, ...).
        for item in varNode.listItems:
          if item.contains(" "):
            issues.addIssue(lsError, varNode.line,
                "dependency name contains spaces: " & item)
      else:
        discard

    else:
      discard

  # Check required fields
  if not hasName:
    issues.addIssue(lsError, 0, "missing required variable: name")
  if not hasVersion:
    issues.addIssue(lsError, 0, "missing required variable: version")
  if not hasRelease:
    issues.addIssue(lsError, 0, "missing required variable: release")
  if not hasDescription:
    issues.addIssue(lsWarning, 0, "missing recommended variable: description")
  if hasSources and not hasChecksums:
    issues.addIssue(lsWarning, 0,
        "sources defined but no checksums (sha256sum/sha512sum/b2sum)")

proc lintStatement(node: AstNode, issues: var seq[LintIssue], funcName: string,
    customFuncs: seq[string]) =
  ## Lint a single statement
  case node.kind
  of nkExec:
    if node.execCmd.len == 0:
      issues.addIssue(lsError, node.line, "empty exec command")
    # Check for potentially unsafe patterns
    if "rm -rf /" in node.execCmd or "rm -rf /*" in node.execCmd:
      issues.addIssue(lsError, node.line,
          "potentially dangerous command: " & node.execCmd)

  of nkMacro:
    if node.macroName.len == 0:
      issues.addIssue(lsError, node.line, "empty macro name")

  of nkIf:
    if node.condition.len == 0:
      issues.addIssue(lsError, node.line, "empty if condition")
    for stmt in node.thenBranch:
      lintStatement(stmt, issues, funcName, customFuncs)
    for stmt in node.elseBranch:
      lintStatement(stmt, issues, funcName, customFuncs)

  of nkFor:
    if node.iterVar.len == 0:
      issues.addIssue(lsError, node.line, "empty for loop iterator variable")
    if node.iterList.len == 0 and node.iterListLiteral.len == 0:
      issues.addIssue(lsError, node.line, "empty for loop list")
    for stmt in node.forBody:
      lintStatement(stmt, issues, funcName, customFuncs)

  of nkFuncCall:
    if node.callName.len == 0:
      issues.addIssue(lsError, node.line, "empty function call name")
    # Check if calling a defined custom function
    if node.callName notin customFuncs:
      issues.addIssue(lsInfo, node.line,
          "calling undefined custom function: " & node.callName &
          " (may be defined elsewhere)")

  of nkLocal, nkGlobal:
    discard

  of nkEnv:
    if node.envVar.len == 0:
      issues.addIssue(lsError, node.line, "empty environment variable name")

  of nkCd:
    if node.cdPath.len == 0:
      issues.addIssue(lsWarning, node.line, "empty cd path")

  of nkWrite, nkAppend:
    discard

  of nkPrint:
    discard

  of nkContinue, nkBreak:
    discard

  else:
    discard

proc lintFunctions(parsed: ParsedScript, issues: var seq[LintIssue]) =
  ## Lint function definitions
  var hasBuild = false

  # Collect custom function names
  var customFuncs: seq[string] = @[]
  for funcNode in parsed.customFuncs:
    if funcNode.kind == nkCustomFunc:
      customFuncs.add(funcNode.customFuncName)

  # Lint regular functions
  for funcNode in parsed.functions:
    if funcNode.kind == nkFunction:
      if funcNode.funcName == "build":
        hasBuild = true

      if funcNode.funcBody.len == 0:
        issues.addIssue(lsInfo, funcNode.line,
            "function '" & funcNode.funcName & "' has empty body")

      for stmt in funcNode.funcBody:
        lintStatement(stmt, issues, funcNode.funcName, customFuncs)

  # Lint custom functions
  for funcNode in parsed.customFuncs:
    if funcNode.kind == nkCustomFunc:
      if funcNode.customFuncBody.len == 0:
        issues.addIssue(lsInfo, funcNode.line,
            "custom function '" & funcNode.customFuncName & "' has empty body")

      for stmt in funcNode.customFuncBody:
        lintStatement(stmt, issues, funcNode.customFuncName, customFuncs)

  # Check for build function (required for most packages)
  if not hasBuild:
    issues.addIssue(lsInfo, 0,
        "no 'build' function defined (may be intentional for meta packages)")

proc printIssues(issues: seq[LintIssue], path: string, verbose: bool): tuple[
    errors: int, warnings: int] =
  ## Print lint issues and return counts
  var errors = 0
  var warnings = 0

  for issue in issues:
    case issue.severity
    of lsError:
      errors += 1
      styledEcho(fgRed, "error", fgDefault, ": ", path, ":",
          $issue.line, ": ", issue.message)
    of lsWarning:
      warnings += 1
      styledEcho(fgYellow, "warning", fgDefault, ": ", path, ":",
          $issue.line, ": ", issue.message)
    of lsInfo:
      if verbose:
        styledEcho(fgBlue, "info", fgDefault, ": ", path, ":",
            $issue.line, ": ", issue.message)

  return (errors, warnings)

proc lintFile(path: string, verbose: bool,
    packageDir = ""): tuple[errors: int, warnings: int] =
  ## Lint a single run3 file.
  ##
  ## `packageDir` is the directory the run3 file lives in, the name kpkg's
  ## runparser matches `depends_<qualifier>` against. It defaults to the file's
  ## parent so a direct file argument works.
  var issues: seq[LintIssue] = @[]
  let packageName = if packageDir.len > 0: packageDir else: lastPathPart(
      path.parentDir)

  # Try to parse the file
  try:
    let content = readFile(path)
    let tokens = tokenize(content)
    var parser = initParser(tokens)
    let parsed = parser.parse()

    # Run linters
    lintVariables(parsed, issues)
    lintSourceGroups(parsed, packageName, issues)
    lintFunctions(parsed, issues)

  except IOError as e:
    issues.addIssue(lsError, 0, "cannot read file: " & e.msg)
  except ParseError as e:
    issues.addIssue(lsError, e.line, "parse error: " & e.msg)
  except CatchableError as e:
    issues.addIssue(lsError, 0, "unexpected error: " & e.msg)

  return printIssues(issues, path, verbose)

proc lint*(path = ".", recursive = true, verbose = false): int =
  ## Lint run3 runfiles for common issues.
  ## Returns 0 if no errors, 1 if errors found.
  var totalErrors = 0
  var totalWarnings = 0
  var filesChecked = 0

  let absPath = absolutePath(path)

  if fileExists(absPath):
    # Single file
    let (errors, warnings) = lintFile(absPath, verbose)
    totalErrors += errors
    totalWarnings += warnings
    filesChecked += 1
  elif dirExists(absPath):
    # Check for run3 file in directory
    let run3Path = absPath / "run3"
    let runPath = absPath / "run"

    if fileExists(run3Path):
      let (errors, warnings) = lintFile(run3Path, verbose, lastPathPart(absPath))
      totalErrors += errors
      totalWarnings += warnings
      filesChecked += 1
    elif fileExists(runPath):
      let (errors, warnings) = lintFile(runPath, verbose, lastPathPart(absPath))
      totalErrors += errors
      totalWarnings += warnings
      filesChecked += 1
    elif recursive:
      # Walk subdirectories
      for entry in walkDir(absPath):
        if entry.kind == pcDir and not isHidden(entry.path):
          let subRun3 = entry.path / "run3"
          let subRun = entry.path / "run"

          if fileExists(subRun3):
            let (errors, warnings) = lintFile(subRun3, verbose,
                lastPathPart(entry.path))
            totalErrors += errors
            totalWarnings += warnings
            filesChecked += 1
          elif fileExists(subRun):
            let (errors, warnings) = lintFile(subRun, verbose,
                lastPathPart(entry.path))
            totalErrors += errors
            totalWarnings += warnings
            filesChecked += 1
    else:
      styledEcho(fgRed, "error", fgDefault,
          ": no run3 or run file found in: ", absPath)
      return 1
  else:
    styledEcho(fgRed, "error", fgDefault, ": path does not exist: ", absPath)
    return 1

  # Summary
  if filesChecked == 0:
    echo "No run3 files found to lint"
    return 0

  echo ""
  if totalErrors > 0:
    styledEcho(fgRed, $totalErrors, " error(s)", fgDefault, " and ",
        fgYellow, $totalWarnings, " warning(s)", fgDefault,
        " in ", $filesChecked, " file(s)")
    return 1
  elif totalWarnings > 0:
    styledEcho(fgYellow, $totalWarnings, " warning(s)", fgDefault,
        " in ", $filesChecked, " file(s)")
    return 0
  else:
    styledEcho(fgGreen, "No issues found", fgDefault,
        " in ", $filesChecked, " file(s)")
    return 0
