import algorithm
import os
import sets
import strutils
import tables
import terminal
import ../../kongue/lexer
import ../../kongue/parser
import ../../kongue/ast
import ../../kongue/utils
import ../../kpkg/modules/arch

const
  # Canonical order for variables
  variableOrder = [
    "name",
    "version",
    "release",
    "epoch",
    "description",
    "type",
    "sources",
    "sha256sum",
    "sha512sum",
    "b2sum",
    "extract",
    "depends",
    "build_depends",
    "replaces",
    "conflicts",
    "provides",
    "backup"
  ]

  # Keys that may carry a per-architecture qualifier (`sources_aarch64:`).
  # They sort directly after their unqualified counterpart, by normalized
  # architecture name, so the arch groups stay with their list rather than
  # landing behind `backup`.
  archQualifiedBases = ["sources", "sha256sum", "sha512sum", "b2sum"]

type
  KeyParts = object
    ## A variable key split into its canonical base and arch qualifier.
    base: string ## `sources`, `sha256sum`, ... or the whole key
    arch: string ## Normalized architecture, "" when unqualified

proc splitKey(name: string): KeyParts =
  ## Decompose a variable key into (base, normalized arch).
  ##
  ## Both accepted spellings fold to the same pair: `sources_aarch64` (listName
  ## `sources_aarch64`) and `sources aarch64` (listName `sources` plus qualifier
  ## `aarch64`). `formatVariable` writes the underscore spelling, so `krep fmt`
  ## rewrites `sources aarch64:` and stays idempotent.
  for base in archQualifiedBases:
    if name.len > base.len and name.startsWith(base) and name[base.len] == '_':
      return KeyParts(base: base, arch: normalizeArch(name[base.len + 1 .. ^1]))
  return KeyParts(base: name, arch: "")

proc getVariableOrderIndex(name: string): int =
  ## Get the sort index for a variable name
  let base = splitKey(name).base
  for i, v in variableOrder:
    if v == base:
      return i
  return variableOrder.len # Unknown variables go at the end

proc compareVariables(a, b: AstNode): int =
  ## Compare two variable nodes for sorting
  ##
  ## The arch qualifier is read from the *full* key (`sources_aarch64`), so the
  ## space-qualifier spelling sorts with the arch groups instead of tying with
  ## the common list. The tie-break uses the plain key, keeping qualified
  ## non-arch variables in their existing order.
  let aName = case a.kind
    of nkVariable: a.varName
    of nkListVariable: a.listName
    else: ""
  let bName = case b.kind
    of nkVariable: b.varName
    of nkListVariable: b.listName
    else: ""

  let aParts = splitKey(getFullVarName(a))
  let bParts = splitKey(getFullVarName(b))
  let aIdx = getVariableOrderIndex(getFullVarName(a))
  let bIdx = getVariableOrderIndex(getFullVarName(b))

  if aIdx < bIdx: return -1
  elif aIdx > bIdx: return 1

  # Same base key: the unqualified list comes first, then the arch groups in
  # normalized architecture order (`sources_aarch64` before `sources_x86_64`);
  # raw names would order by the recipe's spelling instead.
  if aParts.arch.len == 0 and bParts.arch.len > 0: return -1
  if bParts.arch.len == 0 and aParts.arch.len > 0: return 1
  if aParts.arch != bParts.arch: return cmp(aParts.arch, bParts.arch)
  return cmp(aName, bName)

proc sortVariables(variables: seq[AstNode]): seq[AstNode] =
  ## Sort variables in canonical order
  result = variables
  result.sort(compareVariables)

proc needsQuotes(s: string): bool =
  ## Check if a string needs quotes
  if s.len == 0:
    return true
  for c in s:
    # escapedDollar is a byte that cannot appear in source text, so the only
    # way to write it back is the ``\$`` escape inside a quoted string.
    if c in {' ', '\t', '"', '\'', ':', '#', '{', '}', '[', ']', '$', '\n',
        escapedDollar}:
      return true
  return false

proc escapeString(s: string): string =
  ## Escape special characters in a string
  result = ""
  for c in s:
    case c
    of '\n': result.add("\\n")
    of '\t': result.add("\\t")
    of '\r': result.add("\\r")
    of '\\': result.add("\\\\")
    of '"': result.add("\\\"")
    of escapedDollar: result.add("\\$")
    else: result.add(c)

proc isBareWord(s: string): bool =
  ## True when the lexer reads ``s`` as one identifier or number token.
  ##
  ## A keyword lexes as a statement token, `g++` as three tokens, and
  ## `certdata.txt` as an identifier and a dot, so none of those is bare.
  if s.len == 0 or s in run3Keywords():
    return false
  if s[0].isDigit():
    for c in s:
      if not (c.isDigit() or c == '.'):
        return false
    return true
  if not (s[0].isAlphaAscii() or s[0] == '_'):
    return false
  for c in s:
    if not (c.isAlphaNumeric() or c == '_' or c == '-'):
      return false
  return true

proc formatValue(s: string): string =
  ## Format a value, quoting if necessary
  if needsQuotes(s):
    return "\"" & escapeString(s) & "\""
  return s

proc formatLiteral(s: string): string =
  ## Format one item of a `for` list literal, which `parseString` reads as one
  ## identifier, number or string: `[g++, certdata.txt]` would otherwise read
  ## back as `g`, `+`, `+`, `certdata`, `.txt`.
  if isBareWord(s):
    return s
  return "\"" & escapeString(s) & "\""

proc isVarRef(s: string): bool =
  ## True for ``$name``, the one reference a single-token value may hold.
  if s.len < 2 or s[0] != '$' or not (s[1].isAlphaAscii or s[1] == '_'):
    return false
  for i in 1 ..< s.len:
    if not (s[i].isAlphaNumeric or s[i] == '_' or s[i] == '-'):
      return false
  true

proc formatSingleToken(s: string): string =
  ## Format a value its reader takes one token for: a `write`/`append` path or
  ## the list of a `for`. A value that is not one bare word is quoted (`../ln`
  ## would read as a `.`, `$ROOT/usr` as `$ROOT` and a stray `/usr`), while an
  ## expression the parser kept as source is written back as written.
  if s.len == 0 or s.startsWith("\"") or s.startsWith("e\"") or
      s.startsWith("${") or isVarRef(s) or isBareWord(s):
    return s
  return "\"" & escapeString(s) & "\""

proc formatExpression(text: string): string =
  ## Write an expression kept as source (print text, condition, ...) back.
  ##
  ## Everything in it is already source -- quotes included -- except the literal
  ## dollar the lexer marks, which has no source spelling other than ``\$``.
  result = text.replace($escapedDollar, "\\$")

proc formatExecCommand(cmd: string): string =
  ## Format the command of an `exec` statement.
  ##
  ## The AST holds the command with its quotes removed, so a multi-word command
  ## must be made one string again: `exec "mkdir -p $ROOT/x"` written back as
  ## `exec mkdir -p $ROOT/x` stops parsing after `mkdir`.
  if isBareWord(cmd):
    return cmd
  return "\"" & escapeString(cmd) & "\""

proc formatMacroArg(arg: string): string =
  ## Format one macro argument, which is one shell word.
  ##
  ## The AST keeps the argument without its quotes, so anything that would not
  ## read back as exactly one word is quoted: a space splits arguments, a `#`
  ## starts a comment, and `}` would close the body.
  const needsQuote = {' ', '\t', '\n', '\r', '"', '\'', '#', '}',
      escapedDollar}
  if arg.len == 0:
    return arg
  for c in arg:
    if c in needsQuote:
      return "\"" & escapeString(arg) & "\""
  return formatExpression(arg)

type
  Formatter = object
    ## Comment lines of the script, keyed by the line of the node above which
    ## they are written, plus the ones no node follows.
    comments: Table[int, seq[string]]
    trailing: seq[string]
    used: HashSet[int]

proc collectAnchorLines(node: AstNode, lines: var seq[int]) =
  ## Lines a formatted node starts on. A comment belongs to the first node below
  ## it, so it travels with that node when the header is reordered.
  lines.add node.line
  case node.kind
  of nkFunction:
    for stmt in node.funcBody: collectAnchorLines(stmt, lines)
  of nkCustomFunc:
    for stmt in node.customFuncBody: collectAnchorLines(stmt, lines)
  of nkIf:
    for stmt in node.thenBranch: collectAnchorLines(stmt, lines)
    for stmt in node.elseBranch: collectAnchorLines(stmt, lines)
  of nkFor:
    for stmt in node.forBody: collectAnchorLines(stmt, lines)
  else:
    discard

proc collectComments(tokens: seq[Token], parsed: ParsedScript): Formatter =
  ## Attach every comment to a node: a formatter that drops them deletes what a
  ## recipe says about itself.
  var anchors: seq[int] = @[]
  for node in parsed.variables: collectAnchorLines(node, anchors)
  for node in parsed.customFuncs: collectAnchorLines(node, anchors)
  for node in parsed.functions: collectAnchorLines(node, anchors)
  anchors.sort()

  var previous = tkNewline
  for tok in tokens:
    if tok.kind == tkComment:
      # The first node below the comment takes it; a comment written after a
      # statement on its own line stays with that statement.
      var target = -1
      for anchor in anchors:
        if anchor > tok.line or (anchor == tok.line and previous != tkNewline):
          target = anchor
          break
      if target < 0:
        result.trailing.add(tok.value)
      else:
        result.comments.mgetOrPut(target, @[]).add(tok.value)
    previous = tok.kind

proc commentsAbove(f: var Formatter, line: int, indentStr: string): string =
  ## The comments written above a node, at that node's indentation.
  if line in f.used or not f.comments.hasKey(line):
    return ""
  f.used.incl(line)
  for text in f.comments[line]:
    result.add(indentStr & "#" & text & "\n")

proc formatVariable(node: AstNode, f: var Formatter): string =
  ## Format a single variable declaration
  ##
  ## The *full* key is written, including a space-qualifier: Kongue parses
  ## `sources aarch64:` into listName "sources" plus qualifier "aarch64", so
  ## emitting only the listName would silently merge that arch group into the
  ## common `sources:` list (same for `depends_<pkg>`). The underscore spelling
  ## is canonical, so the rewrite to `sources_aarch64:` is deliberate.
  let key = getFullVarName(node)
  var body = ""
  case node.kind
  of nkVariable:
    let op = case node.varOp
      of opSet: ":"
      of opAppend: "+:"
      of opRemove: "-:"
    body = key & op & " " & formatValue(node.varValue)

  of nkListVariable:
    let op = case node.listOp
      of opSet: ":"
      of opAppend: "+:"
      of opRemove: "-:"

    if node.listItems.len == 0:
      body = key & op
    elif node.listItems.len == 1 and not node.listItems[0].contains("\n"):
      # Single item can be on same line
      body = key & op & "\n  - " & formatValue(node.listItems[0])
    else:
      body = key & op
      for item in node.listItems:
        body.add("\n  - " & formatValue(item))

  of nkObject:
    # An `object` in the header is a declaration of its own, not a value.
    body = "object " & node.objectName & " {"
    for prop in node.objectProperties:
      body.add("\n  " & prop.key & ": " & formatValue(prop.value))
    body.add("\n}")

  else:
    raise newException(ValueError,
        "cannot format a " & $node.kind & " in the header (line " &
        $node.line & ")")

  return commentsAbove(f, node.line, "") & body

proc formatStatement(node: AstNode, indent: int, f: var Formatter): string

proc formatStatementBody(node: AstNode, indent: int,
    f: var Formatter): string =
  ## Format a single statement with given indentation, without its comments
  let indentStr = "  ".repeat(indent)

  case node.kind
  of nkExec:
    return indentStr & "exec " & formatExecCommand(node.execCmd)

  of nkMacro:
    result = indentStr & "macro " & node.macroName
    for arg in node.macroArgs:
      result.add(" " & formatMacroArg(arg))

  of nkPrint:
    return indentStr & "print " & formatExpression(node.printText)

  of nkCd:
    return indentStr & "cd " & formatExpression(node.cdPath)

  of nkEnv:
    return indentStr & "env " & node.envVar & " = " &
        formatExpression(node.envValue)

  of nkLocal:
    return indentStr & "local " & node.localVar & " = " &
        formatExpression(node.localValue)

  of nkGlobal:
    return indentStr & "global " & node.globalVar & " = " &
        formatExpression(node.globalValue)

  of nkWrite:
    return indentStr & "write " & formatSingleToken(node.writePath) & " " &
        formatExpression(node.writeContent)

  of nkAppend:
    return indentStr & "append " & formatSingleToken(node.appendPath) & " " &
        formatExpression(node.appendContent)

  of nkIf:
    result = indentStr & "if " & formatExpression(node.condition) & " {\n"
    for stmt in node.thenBranch:
      result.add(formatStatement(stmt, indent + 1, f) & "\n")
    result.add(indentStr & "}")
    if node.elseBranch.len > 0:
      result.add(" else {\n")
      for stmt in node.elseBranch:
        result.add(formatStatement(stmt, indent + 1, f) & "\n")
      result.add(indentStr & "}")

  of nkFor:
    if node.iterListLiteral.len > 0:
      result = indentStr & "for " & node.iterVar & " in ["
      for i, item in node.iterListLiteral:
        if i > 0:
          result.add(", ")
        result.add(formatLiteral(item))
      result.add("] {\n")
    else:
      result = indentStr & "for " & node.iterVar & " in " &
          formatSingleToken(node.iterList) & " {\n"
    for stmt in node.forBody:
      result.add(formatStatement(stmt, indent + 1, f) & "\n")
    result.add(indentStr & "}")

  of nkFuncCall:
    result = indentStr & node.callName
    for arg in node.callArgs:
      result.add(" " & formatExpression(arg))

  of nkObject:
    result = indentStr & "object " & node.objectName & " {"
    for prop in node.objectProperties:
      result.add("\n" & indentStr & "  " & prop.key & ": " &
          formatValue(prop.value))
    result.add("\n" & indentStr & "}")

  of nkContinue:
    return indentStr & "continue"

  of nkBreak:
    return indentStr & "break"

  else:
    raise newException(ValueError,
        "cannot format a " & $node.kind & " statement (line " & $node.line & ")")

proc formatStatement(node: AstNode, indent: int, f: var Formatter): string =
  ## Format a statement, with the comments written above it.
  commentsAbove(f, node.line, "  ".repeat(indent)) &
      formatStatementBody(node, indent, f)

proc formatFunction(node: AstNode, f: var Formatter): string =
  ## Format a function definition
  var body = commentsAbove(f, node.line, "")
  case node.kind
  of nkFunction:
    # The qualifier is part of the name: `build foo {` is `build_foo`, the same
    # underscore spelling a variable key is written with.
    body.add(getFullFuncName(node) & " {\n")
    for stmt in node.funcBody:
      body.add(formatStatement(stmt, 1, f) & "\n")
    body.add("}")

  of nkCustomFunc:
    body.add("func " & node.customFuncName & " {\n")
    for stmt in node.customFuncBody:
      body.add(formatStatement(stmt, 1, f) & "\n")
    body.add("}")

  else:
    raise newException(ValueError,
        "cannot format a " & $node.kind & " (line " & $node.line & ")")
  return body

proc formatRunfile(parsed: ParsedScript, sortVars: bool,
    f: var Formatter): string =
  ## Format a complete runfile
  result = ""

  # Format variables
  let variables = if sortVars: sortVariables(
      parsed.variables) else: parsed.variables
  for varNode in variables:
    result.add(formatVariable(varNode, f) & "\n")

  # Add blank line between variables and functions
  if parsed.variables.len > 0 and (parsed.functions.len > 0 or
      parsed.customFuncs.len > 0):
    result.add("\n")

  # Format custom functions first
  for i, funcNode in parsed.customFuncs:
    if i > 0:
      result.add("\n")
    result.add(formatFunction(funcNode, f) & "\n")

  # Add blank line between custom functions and regular functions
  if parsed.customFuncs.len > 0 and parsed.functions.len > 0:
    result.add("\n")

  # Format regular functions
  for i, funcNode in parsed.functions:
    if i > 0:
      result.add("\n")
    result.add(formatFunction(funcNode, f) & "\n")

  # Comments no node follows still belong to the file.
  for text in f.trailing:
    result.add("#" & text & "\n")

proc formatRunfileText*(content: string, sortVars = true): string =
  ## Format the text of a run3 runfile. A script that does not parse raises
  ## ParseError; a node the writer does not know raises ValueError.
  let tokens = tokenize(content)
  var p = initParser(tokens)
  let parsed = p.parse()
  var f = collectComments(tokens, parsed)
  formatRunfile(parsed, sortVars, f)

proc formatFile(path: string, check: bool, sortVars: bool): tuple[changed: bool,
    error: string] =
  ## Format a single run3 file
  ## Returns (changed, error) - changed is true if file was modified (or would be in check mode)

  # Try to parse the file
  try:
    let content = readFile(path)
    let formatted = formatRunfileText(content, sortVars)

    if formatted != content:
      if check:
        return (true, "")
      else:
        writeFile(path, formatted)
        return (true, "")
    else:
      return (false, "")

  except IOError as e:
    return (false, "cannot read file: " & e.msg)
  except ParseError as e:
    return (false, "parse error at line " & $e.line & ": " & e.msg)
  except CatchableError as e:
    return (false, "unexpected error: " & e.msg)

proc fmt*(path = ".", recursive = true, check = false, sortVars = true): int =
  ## Format run3 runfiles.
  ## Returns 0 if successful (or no changes needed), 1 if errors or check found changes.
  var totalChanged = 0
  var totalErrors = 0
  var filesChecked = 0

  let absPath = absolutePath(path)

  proc processFile(filePath: string) =
    let (changed, error) = formatFile(filePath, check, sortVars)
    filesChecked += 1
    if error.len > 0:
      totalErrors += 1
      styledEcho(fgRed, "error", fgDefault, ": ", filePath, ": ", error)
    elif changed:
      totalChanged += 1
      if check:
        styledEcho(fgYellow, "would reformat", fgDefault, ": ", filePath)
      else:
        styledEcho(fgGreen, "formatted", fgDefault, ": ", filePath)

  if fileExists(absPath):
    # Single file
    processFile(absPath)
  elif dirExists(absPath):
    # Check for run3 file in directory
    let run3Path = absPath / "run3"
    let runPath = absPath / "run"

    if fileExists(run3Path):
      processFile(run3Path)
    elif fileExists(runPath):
      processFile(runPath)
    elif recursive:
      # Walk subdirectories
      for entry in walkDir(absPath):
        if entry.kind == pcDir and not isHidden(entry.path):
          let subRun3 = entry.path / "run3"
          let subRun = entry.path / "run"

          if fileExists(subRun3):
            processFile(subRun3)
          elif fileExists(subRun):
            processFile(subRun)
    else:
      styledEcho(fgRed, "error", fgDefault,
          ": no run3 or run file found in: ", absPath)
      return 1
  else:
    styledEcho(fgRed, "error", fgDefault, ": path does not exist: ", absPath)
    return 1

  # Summary
  if filesChecked == 0:
    echo "No run3 files found to format"
    return 0

  echo ""
  if totalErrors > 0:
    styledEcho(fgRed, $totalErrors, " error(s)", fgDefault,
        " in ", $filesChecked, " file(s)")
    return 1
  elif check and totalChanged > 0:
    styledEcho(fgYellow, $totalChanged, " file(s) would be reformatted", fgDefault)
    return 1
  elif totalChanged > 0:
    styledEcho(fgGreen, $totalChanged, " file(s) formatted", fgDefault)
    return 0
  else:
    styledEcho(fgGreen, "All files already formatted", fgDefault)
    return 0
