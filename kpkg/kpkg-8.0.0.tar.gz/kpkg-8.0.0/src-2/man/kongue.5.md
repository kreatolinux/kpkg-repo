% kongue(5)

# NAME
Kongue - Scripting langauge of Kreato Linux

# DESCRIPTION
Kongue is the main scripting language made for use in Kreato Linux projects. It is inspired by YAML and sh among many other languages. It is currently used by kpkg as the main package format (see kpkg_run(5) for specific details).

# KONGUE STRUCTURE
Kongue scripts don't have a global file extension, though `.kg` or `.kongue` might be used.

## Example Kongue script

```bash
global_var_string: "test"
global_var_bool: true
global_var_array:
    - "hello"
    - "test"
    - "test2"

func custom_func {
    print "This is a test custom function, hello $1"
}

# Different projects will have different main functions, such as build for kpkg_run(5). This is just an example.
main { 
    custom_func "Kreato" # Can run custom functions just like commands
    print "Test"
    exec "command -v bash"
}
```

# SYNTAX AND LANGUAGE FEATURES

## VARIABLES
Variables must be declared at the top of the script. They can be any type (list, string, int, bool, etc.). Variables can be referenced in if statements, for loops, and inside functions. On commands, simple referencing is done via `$variable` or `${variable}`. Complex manipulation (splitting, slicing) works via `${variable.method()}` (or `variable.method()` on a non-command context) (see **VARIABLE MANIPULATION** below).

```yaml
test1: true
test2:
    - this is a test
    - test2
# and so on...
```

## OBJECTS
Objects are structured variable types that hold key-value pairs. They can be declared using the `object` keyword or inline in the header using YAML-like syntax.

Object properties are accessed using bracket notation `object["key"]` or dot notation `${object.key}` in commands and conditions.

### Using `object` keyword

```bash
object kpkg {
    isBootstrap: "1"
    arch: "x86_64"
}

build {
    if kpkg["isBootstrap"] == "1" {
        print "Building in bootstrap mode"
    }
    print "Architecture: ${kpkg.arch}"
}
```

### Inline object syntax

Objects can also be declared inline in the header, using `name:` followed by indented `key: value` pairs:

```yaml
name: "my-package"
version: "1.0.0"

kpkg:
    isBootstrap: "1"
    arch: "x86_64"

build {
    if kpkg["isBootstrap"] == "1" {
        print "Building in bootstrap mode"
    }
}
```

Objects are useful for grouping related configuration values and are used internally by kpkg to provide build context information (e.g., `kpkg["isBootstrap"]`).

Variables can be referenced in if statements, for loops, inside variables, and inside functions (including in commands).

```yaml
test1: true

# Additional stuff...

echo $test1
# Result: true
```

## STRUCTURED HEADER VALUES
Kongue headers can contain nested mappings, sequences, and sequences of mappings. Nesting is determined by spaces. Tabs in header indentation and inconsistent indentation are errors; function bodies are not header text, so tabs there are allowed. Keys in the same mapping must be unique. Continuation keys in a sequence item align with the first key after `- `; a block nested under an item's key must be indented further than that column.

```yaml
supervisor:
    executable: "bin/example-supervisor"

supported_ops:
    - name: "service.start"
      backend: "exec"
      options:
          executable: "bin/example-adapter"
          mode: "persistent"
          timeout: "90s"
      writable_paths:
          - "/run/example"
```

A header value and a list item are the rest of their line. A quoted string
contributes its text without the quotes, `$name` and `${...}` are kept as written
and resolved when the value is read, and whitespace between the pieces of an
unquoted value is kept as a single space. So `summary: words here` is one value,
`- $dep` is one item holding a reference, and `tag: "v"${version}` is `v`
followed by the version. A value belongs to the line of its key: a nested block
under a key is a nested value, never that key's value.

Existing flat headers and lists retain their ordinary Kongue behavior.

The structured-header grammar is:

```text
header       = *( field / comment-line / NL )
field        = key ":" SP value [ comment ] NL
             / key ":" [ comment ] NL [ INDENT block DEDENT ]
block        = mapping / sequence
mapping      = 1*( comment-line
                 / key ":" ( SP value [ comment ] NL
                           / [ comment ] NL [ INDENT block DEDENT ] ) )
sequence     = 1*( comment-line / "-" SP ( value [ comment ] NL / inline-map ) )
inline-map   = key ":" ( SP value [ comment ] NL
                       / [ comment ] NL [ INDENT block DEDENT ] )
               *( ALIGN key ":" ( SP value [ comment ] NL
                                 / [ comment ] NL [ INDENT block DEDENT ] ) )
value        = quoted-string / "true" / "false" / 1*DIGIT
key          = ALPHA *( ALPHA / DIGIT / "_" )
comment      = SP "#" *( any character except NL )
comment-line = *SP "#" *( any character except NL ) NL
```

`INDENT` and `DEDENT` are increases and decreases in leading spaces. `ALIGN` returns to the column of the first key after `- `. The typed `value` alternatives shown above apply in manifest mode; ordinary mode continues to interpret values such as `true` and `42` as strings.

A key followed by neither a value nor a nested block, or followed only by comment
lines, has an empty value. The application reading the header treats it as an empty
sequence or an empty mapping, whichever the key expects; for example `subsystems:` on
its own line is an empty list.

A lone `-` with no value on its line is a parse error. A `${...}` must close before
the end of its line. Text outside a function block is a once-per-script warning in
ordinary mode (`ignoring text outside a function block at line N`) and an error in
manifest mode.

## MANIFEST MODE
Manifest mode is a strict parser mode selected by the application loading a document, such as Jumpstart when it loads a core's `init.kg`. It is not enabled by a declaration inside the document. In manifest mode:

1. Header keys at every nesting level are exact and case-sensitive. Name-style folding is disabled.
2. An underscore is part of a key, not a qualifier separator. For example, `core_version` is one key.
3. Header modifiers `+:` and `-:` are rejected.
4. Strings must be quoted. The only unquoted header scalars are `true`, `false`, and non-negative decimal integers; these have boolean and integer types rather than string types.
5. Function names are exact and case-sensitive. `init` and `shutdown` cannot be qualified, and other function names cannot begin with `init_` or `shutdown_`. Defining both a qualified function and the equivalent underscore form, such as `start_unit mount` and `func start_unit_mount`, is an error.
6. Variable references, including `$name`, `${name}`, `${name.key}`, and bare names in conditions, are exact and case-sensitive.
7. Comments beginning with `#` are accepted on their own lines and after header values. A `${` inside a comment is text: nothing in a comment is validated. A `${...}` that never closes is an error.
8. Function and method names in expressions must be literal; computed call names are rejected.
9. The header ends at the first function block. Header fields after it, and any other text outside a function block, are errors rather than being ignored. Ordinary Kongue ignores that text with a warning (`ignoring text outside a function block at line N`); manifest mode makes it an error.
10. Escape sets differ between header values and function bodies. A header value accepts only `\n`, `\r`, `\t`, `\\`, `\"` and `\'`; any other escape, `\$` included, is an error, so a manifest writes a literal dollar sign unescaped, as in `description: "costs $5"`. In a function body `\$` is a literal dollar sign that is never resolved, as in ordinary Kongue.

Manifest mode also supports a multi-argument `spawn` expression:

```bash
init {
    if "${spawn(\"/usr/bin/test\", \"-x\", \"/usr/bin/example\").exit()}" == "0" {
        print "example is installed"
    }
}
```

The arguments are a comma-separated list of quoted strings and are stored as separate parse-tree tokens. Inside a double-quoted string, as in the example, each argument's quotes are written escaped (`\"`). An argument may contain interpolations such as `${op.unit}`; each is expanded within its own argument. Commas or quotes produced by interpolation cannot create additional arguments.

List variables can be filtered using `[start:end]` and can be indexed using `[index]`. Note that this cannot be used with the `$variable` syntax, only inside `${variable}`. See the example below.

```yaml
test2:
    - IGNORE1
    - IGNORE2
    - IGNORE3

echo ${test2[0:3].join('')}
# Result: IGNORE1IGNORE2IGNORE3

echo ${test2[0]}
# Result: IGNORE1
```

## IF ELSE STATEMENTS
If-else statements can be used inside all functions. You can utilize all variables defined in the script.

```bash
build {
    if test1 {
        print hello!
    } else {
        print bye!
    }
}   
```

You can also use any variable manipulation methods in if statements, including inline exec to execute commands and use their output or exit code in conditions. See **VARIABLE MANIPULATION** for details on available methods.

### CONDITION OPERATORS

The following operators are supported in conditions:

* **==** (equality): `if "$var" == "value" { ... }`
* **!=** (inequality): `if "$var" != "value" { ... }`
* **=~** (regex match): `if "$var" =~ e"pattern" { ... }`
* **||** (OR): `if "$var" == "a" || "$var" == "b" { ... }`
* **&&** (AND): `if "$var1" == "a" && "$var2" == "b" { ... }`

### REGEX MATCHING

Use the `=~` operator with `e"pattern"` syntax for regex matching. The pattern uses standard regex syntax with `|` for alternatives.

```bash
package {
    for APPLET in applets {
        # Skip applets provided by other packages
        if "$APPLET" =~ e"clear|grep|egrep|fgrep|tar|bzip2" {
            continue
        }
        exec "ln -s /bin/busybox $ROOT/bin/$APPLET"
    }
}
```

### COMBINING CONDITIONS

You can combine multiple conditions using `||` (OR) and `&&` (AND):

```bash
build {
    # OR: true if any condition is true
    if "$ARCH" == "x86_64" || "$ARCH" == "amd64" {
        print "Building for 64-bit x86"
    }
    
    # AND: true only if all conditions are true
    if "$DEBUG" == "true" && "$VERBOSE" == "true" {
        print "Debug mode with verbose output"
    }
}
```

## VARIABLE MANIPULATION
Variables can be manipulated directly within strings using object-style methods. This is particularly useful for constructing source URLs that require specific version formatting (e.g., extracting "Major.Minor" from a full version string). You can also use inline exec to execute commands and use their output or exit code.

The syntax for manipulation is `${variable.method(arguments)}` or `${exec("command").method()}`.
The base of a manipulation may be a quoted literal (`${"text"}`) and an index may be a
reference (`${v[${i}]}`); both are resolved before use.

**Note**: Global variables (defined at the top of the kongue script) cannot use exec directly. Exec can only be used within function blocks (like `build`, `prepare`, `package`, etc.) or inside custom functions.

### AVAILABLE METHODS

* **join(delimiter)**
  Joins a list into a string using the given delimiter. Only works with lists.
  * *Example:* `version: "2.78.1"`
  * `${version.split('.').join('!')}` returns `2!78!1`
  * `${version.split('.')[0:2].join('.')}` returns `2.78`

* **split(delimiter)**
  Splits the string by the given delimiter and returns the segments as a list. Only works with strings.
  * *Example:* `version: "2.78.1"`
  * `${version.split('.')[0]}` returns `2`
  * `${version.split('.')[1]}` returns `78`

* **cut(start, end)**
  Slices the string from the `start` index up to (but not including) the `end` index. Only works with strings.
  * *Example:* `commit: "543ee30eda80..."`
  * `${commit.cut(0, 7)}` returns `543ee30`

* **replace(old, new)**
  Replaces all occurrences of `old` substring with `new`. Only works with strings.
  * *Example:* `version: "1.0.5"`
  * `${version.replace('.', '_')}` returns `1_0_5`

* **exec(command).output()**
  Executes a shell command and returns its output. Can be used in conditionals, variable assignments, and string interpolation. Only works within function blocks, not in global variable definitions.
  * *Example:* `build { if ${exec("test -f config.h").output()} { print "config.h exists" } }`
  * `${exec("ls -1 | head -n 1").output()}` returns the first line of directory listing

* **exec(command).exit()**
  Executes a shell command and returns its exit code (0 for success, non-zero for failure). Can be used in conditionals and comparisons. Only works within function blocks, not in global variable definitions.
  * *Example:* `build { if ${exec("test -f config.h").exit()} == 0 { print "config.h exists" } }`
  * `${exec("ls nonexistent").exit()}` returns a non-zero exit code if the file doesn't exist

`exec(...)` takes one argument, a shell command as written:
`${exec("ls -1 | head -n 1").output()}`. Additional arguments are the words of
that command, each quoted before the shell sees it, so
`${exec("sh", "-c", "ls | head")}` runs `sh -c 'ls | head'`. A `${...}` that is not
a variable, a literal or `exec(...)` is reported when it is evaluated. After
`exec(...)` only `.output()` and `.exit()` are valid; a method that does not exist,
and an `exec` suffix that is neither, is reported rather than silently dropped.

### EXAMPLES
Combining methods to construct complex URLs:

```yaml
version: "2.78.1"
sources:
    - "https://download.acme.org/sources/acme/${version.split('.')[0:2].join('.')}/acme-$version.tar.xz"
```

Using inline exec in conditionals and variable assignments:

```bash
build {
    if ${exec("test -f config.h").exit()} == 0 {
        print "config.h exists"
    }
    
    local first_file = ${exec("ls -1 | head -n 1").output()}
    print "First file: $first_file"
}
```

An assignment value may be the whole `${...}` expression written without quotes; the
`}` that closes the expression closes only the expression, never the surrounding
block. The quoted form is equivalent. An expression must be closed on its own line;
an unterminated `${` is a parse error.

## FOR LOOPS
For loops can be used inside all functions. You can access all variables defined in the script.

```bash
build {
    for i in test2 {
        print $i
    }
}
```

You can also use inline list literals directly in for loops:

```bash
package {
    for file in ["tzselect", "zdump", "zic"] {
        exec "rm -f $ROOT/usr/bin/$file"
    }
}
```

### VARIABLE EXPRESSIONS IN FOR LOOPS

For loops support variable expressions that resolve to lists. This is useful when iterating over dynamic content like command output:

```bash
package {
    # Iterate over lines from command output
    for APPLET in "${exec(\"$ROOT/bin/busybox --list\").output()}" {
        print "Processing applet: $APPLET"
    }
    
    # Iterate over a variable that contains newline-separated values
    local items = ${exec("ls -1").output()}
    for item in "$items" {
        print "Item: $item"
    }
}
```

### LOOP CONTROL: CONTINUE AND BREAK

Use `continue` to skip to the next iteration and `break` to exit the loop entirely:

```bash
package {
    for APPLET in applets {
        # Skip certain applets
        if "$APPLET" =~ e"grep|tar|bzip2" {
            continue
        }
        
        # Stop processing if we hit a specific applet
        if "$APPLET" == "STOP" {
            break
        }
        
        exec "ln -s /bin/busybox $ROOT/bin/$APPLET"
    }
}
```

`continue` and `break` take no arguments; anything after them on the line is an
error.

## BUILTIN COMMANDS
These are the built-in commands available in all kongue environments:

* **exec**: Spawn shell commands. Usage: `exec [COMMAND]`
* **print**: Print output to stdout. Usage: `print [STRING]`
* **cd**: Change directory. Usage: `cd [DIRECTORY]`
* **echo**: Alias to `print`. Usage: `echo [STRING]`
* **local**: Allows you to set a local variable inside a function (see CUSTOM FUNCTIONS). Usage: `local [VAR]=[VALUE]`
* **global**: Allows you to set and override a global variable inside a function (see CUSTOM FUNCTIONS). Usage: `global [VAR]=[VALUE]`
* **env**: Allows you to set and override environment variables inside a function. Usage: `env [VAR]=[VALUE]`
* **write**: Write content to a file. Overwrites the file if it exists. Usage: `write [FILE] [STRING]`
* **append**: Append content to a file. Creates the file if it does not exist. Usage: `append [FILE] [STRING]`
* **continue**: Skip to the next iteration in a for loop. Usage: `continue`
* **break**: Exit from a for loop immediately. Usage: `break`

For `local`, `global` and `env`, `[VALUE]` may be a quoted string, a `$variable`
reference, or one unquoted `${...}` expression.

See **STRINGS** for information on multi-line content.

The rest of the shell commands (should you need them) can only be accessed using the `exec` parameter.

## SHELL VARIABLES IN COMMANDS
The text of an `exec` command is shell text, so it may use the shell's own variables
alongside Kongue's. A `$name` or `${name}` reference is resolved by Kongue when the
name is one Kongue knows -- a header variable, a `local`, `global` or `env` variable,
a built-in such as `$ROOT`, `$DESTDIR` or `$SRCDIR`, or a name in the environment
Kongue was started with. A reference to any other name is left exactly as written for
the shell to expand, and the shell's positional and special parameters (`$1`, `$@`,
`$?`, `$#`, `$$`) are always left alone.

```bash
build {
    exec "sh -c 'X=1 && echo $X'"       # the shell prints 1
    exec "for f in a b; do echo $f; done"
    exec "awk '{print $1}' file"
    exec "make CXXFLAGS=\"${CXXFLAGS} -D_FILE_OFFSET_BITS=64\""
}
```

Because `$` is also the interpolation character, write `\$` for a literal dollar sign
that must reach the shell unexpanded (see CUSTOM FUNCTIONS for the same escape in a
`print`):

```bash
build {
    exec "echo \$HOME is expanded by the shell, not by Kongue"
}
```

Outside `exec` -- in `print`, in a condition, in an assignment or in `write`/`append`
content -- a reference to an unknown name still resolves to the empty string, which is
what MANIFEST MODE requires.

In ordinary Kongue -- recipes, kpkg -- `\$` is a literal dollar everywhere a quoted
string is read, header values included, so a recipe can write a URL or a description
that contains a dollar:

```bash
description: "costs \$5"
sources:
    - "https://example.org/\${version}.tar.xz"   # a literal $ for the server
```

Manifest mode differs (see MANIFEST MODE, rule 10): there a header value accepts only
the escapes `\n`, `\r`, `\t`, `\\`, `\"` and `\'`, so `\$` in a header value is
rejected as an error and a manifest writes the dollar sign bare:

```bash
description: "costs $5"
```

In a function body, in manifest mode or not, `\$` stays a literal dollar that is
never resolved.

## STRINGS
Strings can be enclosed in double quotes (`"`) or single quotes (`'`). 

For multi-line strings, use triple quotes (`"""`).

```bash
write "file.txt" """
Line 1
Line 2
"""
```



# VARIABLES AND FUNCTIONS

## CUSTOM FUNCTIONS
Users can define their own reusable functions to avoid repetition. These function blocks follow the same syntax as lifecycle functions (like `build` or `prepare`) but require the `func` keyword.

### SYNTAX
Custom functions are defined at the top level of the script. They use standard POSIX-like shell argument handling (`$1`, `$2`, `$@`).

```bash
func test_function {
    print "Hello $1"
}
```

The `}` that closes a function or `func` body stands on a line of its own. A `}`
written after a statement closes the body there and is an error, because the
statements below it would silently stop being part of the function.

### USAGE
Once defined, custom functions can be called inside any other function block (`build`, `prepare`, `package`, etc.) by simply typing their name and arguments.

```bash
build {
    test_function "Kreato"
}
```

### SCOPE AND VARIABLES
* Global Variables: Custom functions can access (and modify using the `global` keyword) all variables defined in the YAML header. This way you can create subpackages that have different properties to the main package.
* Local Variables: You can define local variables inside a function using the `local` keyword to prevent exposing them to the rest of the script.
* Environment Variables: You can define environment variables inside a function using the `env` keyword to pass that automatically.

```bash
func test_variables {
    local awesome="yes!"
    global name="test2"
    env EXAMPLE="test"
    print "Is this local? $awesome"
    print "The package is named: $name"
    exec "echo you know this is a \$EXAMPLE right?"
}
```

# NAMING CONVENTIONS
Kongue variables are case-insensitive and support multiple naming styles:
* camelCase (e.g., `buildDepends`)
* PascalCase (e.g., `BuildDepends`)
* kebab-case (e.g., `build-depends`)
* snake_case (e.g., `build_depends`)

snake_case is recommended for most scripts.

**Important**: Functions are case-sensitive and do not support this flexibility.

## QUALIFIED NAMES
Variables and functions can have qualifiers to create variants. The space-separated syntax is preferred:

```bash
# Variables with qualifiers
depends:
    - "base-dep"

depends subpkg:
    - "subpkg-dep"

# Functions with qualifiers
build {
    exec "make"
}

build subpkg {
    exec "make subpkg"
}
```

The legacy underscore syntax (`depends_subpkg:`, `build_subpkg {}`) is also supported for backward compatibility. Both syntaxes are equivalent internally.

# AUTHOR
Written by Kreato.

# COPYRIGHT
Kreato Linux src is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Kreato Linux src is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Kreato Linux src.  If not, see <https://www.gnu.org/licenses/>.
