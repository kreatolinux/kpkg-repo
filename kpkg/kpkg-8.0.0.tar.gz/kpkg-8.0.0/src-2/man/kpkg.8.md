% kpkg(8)

# NAME
kpkg - package manager

# SYNOPSIS
**kpkg** [h] [b] [ins] [inf] [r] [upd] [upg] [PACKAGES] [-y] [-o] [-r] [ROOTFS]

# DESCRIPTION
kpkg is a package manager written in Nim.

kpkg uses simple build scripts called runfiles, similar to PKGBUILDs found in the pacman package manager. You can learn more about runfiles in kpkg_run(8).

# COMMANDS

**h**
    Output help

**b**
    build package

**ins**
    install binary package

**inf**
    get info about a package

**r** 
    remove package

**upd**
    update repository

**upg**
    upgrade packages

**v**
    print version

**-o**
    only build, dont install

**-r**
    Rootfs argument.

**-y**
    Auto-accept installation.

For full arguments, please see `kpkg help`

# TRANSACTION HISTORY

kpkg records the file and database changes of every install, upgrade and removal as a transaction. `kpkg history list` shows the recorded transactions newest first, `kpkg history info ID` describes one of them, `kpkg history undo ID` restores the state before the named transaction and `kpkg history rollback ID` restores the state after it. Restoring uses the rollback copies that kpkg keeps with each history record under `/var/lib/kpkg/history`, so only transactions that have not been pruned can be restored.

**kpkg history prune** [--keep N] [--older-than DAYS] [--dry-run] [--root PATH] [--yes]

Deletes the oldest recorded transactions together with their rollback copies. Records are always deleted oldest first, so the remaining history stays restorable.

* `--keep N`: keep the N newest transactions. `-1` disables the limit.
* `--older-than DAYS`: keep transactions newer than DAYS days. `-1` disables the limit. At least one of `--keep` and `--older-than` is required.
* `--dry-run`: print the transactions that would be deleted and change nothing.

Crash journals are not part of the history: kpkg deletes a transaction's journal as soon as the transaction is committed and its history record is durable, and it removes journals left behind by earlier versions the next time it recovers.

# ENVIRONMENT VARIABLES

* `KPKG_ENABLE_DEBUG`: Boolean that enables debug messages on kpkg. Is very useful for bug reports. Set to one of `y`, `yes`, `true` or `1` to enable.

# AUTHOR
Written by Kreato.

# COPYRIGHT
kpkg is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

kpkg is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with kpkg.  If not, see <https://www.gnu.org/licenses/>.
