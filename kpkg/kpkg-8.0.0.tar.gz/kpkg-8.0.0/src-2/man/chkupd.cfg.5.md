% chkupd.cfg(5)

# NAME
chkupd.cfg - Per package configuration file for krep upstream checks.

# DESCRIPTION
PACKAGEPATH/chkupd.cfg is a per package configuration file for krep upstream checks. It is used to configure the behavior of krep check and update for a specific package. If a configuration file is not found, krep will use the arguments passed to it.

# SYNTAX
chkupd.cfg uses a INI format.
There is no default configuration file, but you can create one in the package directory.
An example configuration file is below.

```ini
[autoUpdater]
mechanism="githubReleases"
trimString="v"

[githubReleases]
repo="kreatolinux/kpkg"
```

## AUTOUPDATER
* mechanism: The mechanism to use for checking for updates. Defaults to whatever is used while running `krep check`. One of `repology`, `arch`, `githubReleases`, `gnome` or `gitlab`.
* trimString: String to trim from the version string. Defaults to nothing.

## GITHUBRELEASES
* repo: The repository to check for updates. Must be in the format of `username/repo`.

## GITLAB
The `gitlab` mechanism queries the REST API of any GitLab instance, so packages
can be tracked at the project that actually publishes them instead of at a
mirror or a tarball server. It works for `gitlab.gnome.org`,
`gitlab.freedesktop.org`, `salsa.debian.org`, `invent.kde.org`, `gitlab.com` and
any other GitLab install, because the endpoint is the same everywhere:

    GET https://HOST/api/v4/projects/<url-encoded group/project>/repository/tags

The host and project are derived from a recipe's GitLab archive source URL when
the section does not name them, so a recipe that already fetches
`https://gitlab.gnome.org/GNOME/gtk/-/archive/<tag>/gtk-<tag>.tar.gz` needs no
configuration at all.

* host: The GitLab instance, e.g. `gitlab.gnome.org`. Defaults to the host of the first GitLab archive source URL.
* project: The full namespace path, e.g. `GNOME/gtk` or `xorg/lib/libx11`. Defaults to the project path of the first GitLab archive source URL.
* tagPrefix: A literal prefix stripped once from the start of a tag, e.g. `v` for `v1.7.0` or `libX11-` for `libX11-1.8.14`. A leading `v` is also dropped automatically when a digit follows it, so `v1.2.3` and `1.2.3` both normalize to `1.2.3`. The `[autoUpdater]` `trimString` is accepted as the same setting.
* tagPattern: A regular expression matched against the whole tag, for projects whose tags are not a plain prefix plus version. Its capture groups are joined with `.`, so one pattern covers a project's convention: `GTK_(\\d+)_(\\d+)_(\\d+)` turns `GTK_4_24_1` into `4.24.1`, `gtk-(\\d+)-(\\d+)-(\\d+)` turns `gtk-4-24-1` into `4.24.1`, and `polkit-(\\d+)` turns `polkit-124` into `124`. A tag the pattern does not match is ignored rather than treated as a version. A pattern with no capture group uses the whole match. Overrides `tagPrefix`.

  Write the backslashes doubled, as above: the configuration file parser consumes one level, so a single `\d` arrives at the regex engine as `d` and the pattern silently matches nothing.

  This key is REQUIRED for a project whose tags carry a name prefix, such as the whole x.org family on `gitlab.freedesktop.org` (`libX11-1.8.14`, `xorgproto-2026.1`, `xkbcomp-1.5.0`). Without it, or a matching `tagPrefix`, no tag normalizes to something starting with a digit and the backend reports that none of the tags look like a version.
* module: Reuse this GNOME module's stability and series defaults (see the `gnome` section). Use it for a project whose numbering follows GNOME's conventions, e.g. `module="gtk"` for `GNOME/gtk`.
* stability: `any`, `even-minor` or `odd-minor`, with the same meaning as in the `gnome` section. Defaults to the `module`'s own convention, or `any`.
* series: Restrict candidates to one version series, e.g. `series="4"` accepts `4.24.1` but not `5.0.0`. Defaults to the `module`'s current stable series, or no pin.
* useReleases: `true` queries `/releases` instead of `/repository/tags`. Use it for projects that publish releases without tags. The two endpoints name the tag differently: `/repository/tags` calls it `name`, while `/releases` calls the release title `name` and the tag `tag_name`, so the tag is read from `tag_name` when this is set.
* archive: `gitlab` rewrites the recipe's source entry to the GitLab archive URL of the new tag on update. The URL is written with `${version}` in place of the version, so later updates keep working. The default leaves the templated source line alone.
* archiveTemplate: The tag as a template for the `archive` rewrite, for a project whose tag cannot be derived from the version by prefixing, e.g. `archiveTemplate="GTK_${version}"`. Needed when `tagPattern` is set, because a pattern cannot be inverted.
* release: `keep` keeps the recipe's `release` when the version is bumped. The default resets it to `1`.

Tags that do not normalize to something starting with a digit (a branch name, a
`nightly` tag) are skipped, and `alpha`, `beta` and `rc` releases are rejected by
the shared stability rules. When no tag normalizes at all, the backend reports a
configuration error rather than "no release found", because the usual cause is a
missing `tagPattern`.

`gitlab.gnome.org` limits unauthenticated API requests per client address to a
small number per window, so a sweep over many recipes can be rate limited; the
backend reports that case separately from a missing project. Only the upstream archive's checksum is recalculated;
local sources (patches, service files) keep their entries and are never fetched.

```ini
[autoUpdater]
mechanism="gitlab"

[gitlab]
host="gitlab.gnome.org"
project="GNOME/gtk"
series="4"
```

## REPOLOGY
* project: The Repology project to query. Defaults to the runfile's `name`.

## ARCH
* package: The Arch Linux package to query. Defaults to the runfile's `name`.

## GNOME
The `gnome` mechanism queries `https://download.gnome.org/sources/MODULE/cache.json`
and applies GNOME's release rules. It works for both download.gnome.org tarball
sources and `gitlab.gnome.org` archive sources.

* module: The download.gnome.org module directory. Defaults to the module named by the first source URL, so `https://download.gnome.org/sources/gtk/...` and `https://gitlab.gnome.org/GNOME/librsvg/-/archive/...` need no configuration. Set it explicitly when the recipe name differs from the module (`gtk4` -> `gtk`, `gtksourceview5` -> `gtksourceview`, `gcr-4` -> `gcr`, `atk` -> `at-spi2-core`, `libgexiv2` -> `gexiv2`, `librest` -> `rest`).
* series: Restrict candidates to one version series. `series="4"` accepts `4.24.1` but not `5.0.0`; `series="3.24"` accepts `3.24.43` but not `3.94.0`. Defaults to the module's current stable series where the greatest published line is not the stable one (`gtk` -> `4`, `gtk+` -> `3.24`, `pango` -> `1.58`, `libsoup` -> `3`, `gtksourceview` -> `5`, `gcr` -> `4`, `gnome-bluetooth` -> `47`, `vala` -> `0.56`, ...) and to no pin otherwise.
* stability: `any`, `even-minor` or `odd-minor`. `alpha`, `beta`, `rc` and the historical `90`-`99` micro numbers are always rejected. `even-minor` additionally rejects odd minor versions, for the modules that still number development series that way (`glib`, `gtk`, `gtk+`, `pango`, `gdk-pixbuf`, `gobject-introspection`, `at-spi2-core`, `libsoup`, `gtksourceview`, `vte`, `json-glib`, `gjs`, `vala`, ...). Defaults to the module's own convention; see `stabilityFor` in `krep/modules/backends/gnome.nim`.
* release: `keep` keeps the recipe's `release` when the version is bumped. The default resets it to `1`.
* tarball: `download` rewrites the upstream source entry to the tarball URL that cache.json lists for the new version. Use it for recipes whose source is a `gitlab.gnome.org` archive URL when the release is also published on download.gnome.org. The default leaves the source line untouched, so templated URLs such as `${version.split('.')[0]}` keep working.

Only the upstream tarball's checksum is recalculated; local sources (patches,
service files, images) keep their entries and are never fetched.

```ini
[autoUpdater]
mechanism="gnome"

[gnome]
module="gtk"
series="4"
```

# AUTHOR
Written by Kreato.

# COPYRIGHT
kpkg is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

kpkg is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with kpkg.  If not, see <https://www.gnu.org/licenses/>.
