import strutils
import ../../common/logging
import ../modules/sqlite
import ../modules/arch
import ../modules/config
import ../modules/runparser
import ../modules/run3/run3
import ../modules/sourcegroups

proc formatSourceGroups*(rf: Run3File): seq[string] =
  ## One script-friendly line per source group of a recipe.
  ##
  ## `sources: 1 entry` / `sources_aarch64: 2 entries`, in `sourceGroups`
  ## order. The count is of the recipe's own entries, so a cross build still
  ## lists every group.
  ##
  ## The key uses its canonical underscore spelling (`sourcesLookup`), so a
  ## script matches it whichever way the recipe spelled the group.
  ##
  ## Exported so a test can check the lines without a database or a repository.
  for group in sourceGroups(rf.parsed):
    let count = group.sources.len
    result.add(group.sourcesLookup & ": " & $count &
        (if count == 1: " entry" else: " entries"))

proc info*(package: seq[string], testing = false): string =
  ## Get information about packages.

  if package.len == 0:
    error("Please enter a package name")
    quit(1)

  let repo = findPkgRepo(package[0])

  if repo == "":
    error("Package "&package[0]&" doesn't exist")
    quit(1)

  # `info` only inspects metadata, so it resolves the host architecture, which
  # is what a user reading `kpkg info` expects. A cross build passes its target
  # to parseRunfile and gets only that arch's entries.
  let pkg = parseRunfile(repo&"/"&package[0], arch = hostArch())

  echo "package name: "&pkg.pkg
  echo "package version: "&pkg.version
  echo "package release: "&pkg.release
  if pkg.license.len > 0:
    echo "license: "&pkg.license.join(" ")
  when declared(pkg.epoch):
    echo "package epoch: "&pkg.epoch
  for line in formatSourceGroups(pkg.run3Data):
    echo line
  if packageExists(package[0]):
    return "installed: yes"

  # don't error when package isn't installed during testing
  const ret = "installed: no"
  if testing:
    return ret

  # return err if package isn't installed (for scripting :p)
  error(ret)
  quit(1)
