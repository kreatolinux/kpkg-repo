import os
import strutils
import sequtils
import terminal
import tables
import algorithm
import ../../common/logging
import ../modules/config
import ../modules/sqlite
import ../modules/overrides
import ../modules/dephandler
import ../modules/arch
import ../modules/run3/run3
import rdstdin
when not defined(windows) and not defined(genode):
  import std/linenoise as linenoise

# base functions
#
# db.package.packageName.variable # eg. package.kpkg.version
# config.variable # eg. config.Repositories.repoLinks
# vars.variable # eg. internal.vars.envDir
# overrides.packageName.variable # eg. overrides.bash.cflags
# depends.packageName.build # eg. depends.bash.build (build dependencies)
# depends.packageName.install # eg. depends.bash.install (install dependencies)
#
# Can also get all variables
# `kpkg get config` # prints all config variables

const replCommands = ["get", "set", "history", "clear", "exit", "quit"]

type ReplCompletionCatalog = object
  topLevel: seq[string]
  commandTokens: Table[string, seq[string]]

proc addUnique(values: var seq[string], value: string) =
  if value notin values:
    values.add(value)

proc addPath(catalog: var ReplCompletionCatalog, commands,
        components: openArray[string]) =
  ## Register every usable dotted prefix of a command path.
  var token = ""
  for component in components:
    if token.len > 0: token.add('.')
    token.add(component)
    for command in commands:
      catalog.commandTokens.mgetOrPut(command, @[]).addUnique(token)

proc buildCompletionCatalog(packageNames,
        installedPackages: seq[string]): ReplCompletionCatalog =
  result.commandTokens = initTable[string, seq[string]]()
  for command in replCommands:
    result.topLevel.addUnique(command)
  for keyword in run3Keywords():
    result.topLevel.addUnique(keyword)

  result.commandTokens.mgetOrPut("get", @[]).addUnique("--all")

  for entity in ["package", "file"]:
    result.addPath(["get"], ["db", entity])

  for packageName in installedPackages:
    for field in packageFieldNames():
      result.addPath(["get"], ["db", "package", packageName, field])

  for section in configSectionNames():
    result.addPath(["get", "set"], ["config", section])
    for key in configKeyNames(section):
      result.addPath(["get", "set"], ["config", section, key])

  # Overrides are valid for repository packages, while dependency queries use
  # the same live repository package catalog.
  for packageName in packageNames:
    result.addPath(["get", "set"], ["overrides", packageName])
    for dependencyKind in ["build", "install"]:
      for outputFormat in ["graph", "json"]:
        result.addPath(["get"], ["depends", packageName, dependencyKind,
                outputFormat])

  result.topLevel.sort()
  for command, tokens in result.commandTokens.mpairs:
    tokens.sort()

proc completionCandidates(input: string,
        catalog: ReplCompletionCatalog): seq[string] =
  ## Generic linenoise matcher. Grammar knowledge lives only in the catalog.
  let tokenStart = block:
    let space = input.rfind({' ', '\t'})
    if space < 0: 0 else: space + 1
  let before = input[0 ..< tokenStart]
  let token = input[tokenStart .. ^1]

  if tokenStart == 0:
    for candidate in catalog.topLevel:
      if candidate.toLowerAscii().startsWith(token.toLowerAscii()):
        result.add(candidate)
    return

  let words = before.strip().splitWhitespace()
  if words.len == 0 or not catalog.commandTokens.hasKey(words[0]):
    return
  let depth = token.count('.')
  for candidate in catalog.commandTokens[words[0]]:
    if candidate.count('.') == depth and
        candidate.toLowerAscii().startsWith(token.toLowerAscii()):
      result.add(before & candidate)

proc replCompletionCandidates*(input: string, packageNames: seq[string] = @[],
        installedPackages: seq[string] = @[]): seq[string] =
  ## Return complete replacement lines accepted by linenoise.
  completionCandidates(input,
      buildCompletionCatalog(packageNames, installedPackages))

proc repositoryPackageNames(): seq[string] =
  for repoDir in getConfigValue("Repositories", "repoDirs").splitWhitespace():
    if not dirExists(repoDir): continue
    for kind, path in walkDir(repoDir):
      if kind in {pcDir, pcLinkToDir} and
          (fileExists(path / "run3") or fileExists(path / "run")):
        let name = lastPathPart(path)
        if name notin result: result.add(name)
  result.sort()

when not defined(windows) and not defined(genode):
  var replCompletionPackages: seq[string]
  var replCompletionInstalled: seq[string]

  proc replCompletionCallback(input: cstring,
          completions: ptr linenoise.Completions) {.cdecl.} =
    try:
      for candidate in replCompletionCandidates($input,
              replCompletionPackages, replCompletionInstalled):
        linenoise.addCompletion(completions, candidate.cstring)
    except CatchableError:
      discard

proc displayConfigQuery*(section, key, value: string): string =
  if section.toLowerAscii() != "telemetry":
    return value
  if key.len == 0:
    let redacted = redactTelemetrySecrets("[Telemetry]\n" & value)
    let newline = redacted.find('\n')
    return if newline >= 0: redacted[newline + 1 .. ^1] else: ""
  if key.toLowerAscii() in ["password", "bearertoken"]:
    return "REDACTED"
  value


proc dependencyQueryPackages*(value: string): seq[string] =
  ## Preserve a literal package name, including commas, when it exists.
  if findPkgRepo(value) != "":
    return @[value]
  result = value.split(',')
  if result.anyIt(it.len == 0):
    return @[]

proc get(args: seq[string]) =
  ## Gets a kpkg value. See kpkg_get(5) for more information.

  let showAll = args.anyIt(it == "--all")
  let invocs = args.filterIt(it != "--all" and it != "")

  if invocs.len < 1:
    echo "Usage: get [--all] [invocation]"
    return

  for invoc in invocs:
    let invocSplit = invoc.split(".")
    case invocSplit[0]:
      of "db":
        if invocSplit.len < 2:
          info("available invocations: db.package, db.file")
          continue

        case invocSplit[1]:
          of "package":
            case invocSplit.len:
              of 2:
                getPackageByValueAll("/")
              of 3:
                echo getPackageByValue(getPackage(invocSplit[2], "/"))
              of 4:
                echo getPackageByValue(getPackage(invocSplit[2],
                        "/"), invocSplit[3])
              else:
                error("'"&invoc&"': invalid invocation")
          of "file":
            case invocSplit.len:
              of 2:
                getFileByValueAll("/")
              of 3:
                echo getFileByValue(getFile(invocSplit[2], "/"))
              of 4:
                echo getFileByValue(getFile(invocSplit[2], "/"),
                        invocSplit[3])
              else:
                error("'"&invoc&"': invalid invocation")
      of "config":
        case invocSplit.len:
          of 1:
            echo returnConfig()
          of 2:
            echo displayConfigQuery(invocSplit[1], "", getConfigSection(invocSplit[1]))
          of 3:
            echo displayConfigQuery(invocSplit[1], invocSplit[2],
                getConfigValue(invocSplit[1], invocSplit[2]))
          else:
            error("'"&invoc&"': invalid invocation")
      of "overrides":
        case invocSplit.len:
          of 1:
            for override in allOverrides():
              echo readFile(override)
          of 2:
            echo returnOverride(invocSplit[1])
          of 3:
            echo getOverrideSection(invocSplit[1], invocSplit[2])
          of 4:
            echo getOverrideValue(invocSplit[1], invocSplit[2],
                    invocSplit[3])
          else:
            error("'"&invoc&"': invalid invocation")
      of "depends":
        case invocSplit.len:
          of 3:
            let packageNames = dependencyQueryPackages(invocSplit[1])
            let depType = invocSplit[2]

            if packageNames.len == 0:
              error("no package names specified")
              return
            for packageName in packageNames:
              if findPkgRepo(packageName) == "":
                error("'"&packageName&"': package not found")
                return

            var deps: seq[string]
            try:
              case depType:
                of "build":
                  deps = dephandler(packageNames,
                          isBuild = true, root = "/",
                          prevPkgName = packageNames[0],
                          ignoreCircularDeps = true,
                          forceInstallAll = showAll)
                of "install":
                  deps = dephandler(packageNames,
                          root = "/",
                          prevPkgName = packageNames[0],
                          ignoreCircularDeps = true,
                          forceInstallAll = showAll)
                else:
                  error("'"&depType&"': invalid dependency type. Use 'build' or 'install'")
                  return

              # Output the dependencies
              for dep in deps:
                echo dep
            except CatchableError:
              error("failed to resolve dependencies for '"&packageNames.join(",")&"'")
          of 4:
            let packageNames = dependencyQueryPackages(invocSplit[1])
            let depType = invocSplit[2]
            let outputFormat = invocSplit[3]

            if outputFormat notin ["graph", "json"]:
              error("'"&outputFormat&"': invalid output format. Use 'graph' or 'json'")
              return

            if packageNames.len == 0:
              error("no package names specified")
              return
            for packageName in packageNames:
              if findPkgRepo(packageName) == "":
                error("'"&packageName&"': package not found")
                return

            try:
              # Build the dependency graph
              let ctx = dependencyContext(
                  root: "/",
                  isBuild: (depType == "build"),
                  useBootstrap: false,
                  ignoreInit: false,
                  ignoreCircularDeps: true,
                  forceInstallAll: showAll,
                  init: "",
                  targetArch: hostArch()
              )

              var graph: dependencyGraph
              case depType:
                of "build":
                  # Build graph with build dependencies
                  graph = buildDependencyGraph(packageNames,
                          ctx, @["  "], false, false, packageNames[0])
                of "install":
                  # Build graph with install dependencies only
                  graph = buildDependencyGraph(packageNames,
                          ctx, @["  "], false, false, packageNames[0])
                else:
                  error("'"&depType&"': invalid dependency type. Use 'build' or 'install'")
                  return

              if outputFormat == "json":
                echo generateDependencyJson(graph, packageNames)
              else:
                # Keep the existing Mermaid output for .graph queries.
                echo generateMermaidChart(graph, packageNames)
            except CatchableError:
              error("failed to generate dependency graph for '"&packageNames.join(",")&"'")
          else:
            error("'"&invoc&"': invalid invocation. Usage: get [--all] depends.packageName[,packageName...].build[.graph|.json] or depends.packageName[,packageName...].install[.graph|.json]")
      else:
        error("'"&invoc&"': invalid invocation. Available invocations: db, config, overrides, depends. See kpkg_get(5) for more information.")

proc set(args: seq[string]) =
  ## Sets a kpkg value. See kpkg_set(5) for more information.
  if args.len < 2:
    echo "Usage: set [invocation] [value]"
    return

  try:
    let key = args[0]
    let val = args[1..^1].join(" ")
    let invocSplit = key.split(".")

    case invocSplit[0]:
      of "config":
        if invocSplit.len < 3:
          error("'"&key&"': invalid invocation.")
          return
        setConfigValue(invocSplit[1], invocSplit[2], val)
        echo displayConfigQuery(invocSplit[1], invocSplit[2],
            getConfigValue(invocSplit[1], invocSplit[2]))
      of "overrides":
        if invocSplit.len < 4:
          error("'"&key&"': invalid invocation.")
          return
        setOverrideValue(invocSplit[1], invocSplit[2], invocSplit[3], val)
        echo getOverrideValue(invocSplit[1], invocSplit[2], invocSplit[3])
  except CatchableError as e:
    error(e.msg)

proc handleRun3Statement(ctx: ExecutionContext, line: string) =
  ## Parses and executes a run3 statement or function definition.
  try:
    let tokens = tokenize(line)
    var parser = initParser(tokens)

    # Check if this is a function definition
    let firstTok = parser.peek()
    if firstTok.kind == tkFunc or (firstTok.kind == tkIdentifier and
        parser.peek(1).kind == tkLBrace):
      let isCustom = firstTok.kind == tkFunc
      let funcNode = parser.parseFunction(isCustom)

      # Load into context
      if funcNode.kind == nkFunction:
        ctx.customFuncs[funcNode.funcName] = funcNode.funcBody
        debug "Defined regular function: " & funcNode.funcName
      elif funcNode.kind == nkCustomFunc:
        ctx.customFuncs[funcNode.customFuncName] = funcNode.customFuncBody
        debug "Defined custom function: " & funcNode.customFuncName
    else:
      # Regular statement
      let node = parser.parseStatement()
      let res = executor.executeNode(ctx, node)
      if res != 0:
        debug "Command returned non-zero exit code: " & $res
  except ParseError as e:
    error("Parse error at line " & $e.line & ", col " & $e.col & ": " & e.msg)
  except ExecutionError as e:
    error("Execution error at line " & $e.line & ": " & e.msg)
  except CatchableError as e:
    error("Error: " & e.msg)

proc dispatchCommand(ctx: ExecutionContext, input: string) =
  ## Dispatches a command (get, set, or run3 statement).
  let inputTrimmed = input.strip()
  if inputTrimmed == "": return

  let parts = inputTrimmed.split(" ", 1)
  let cmd = parts[0]
  let args = if parts.len > 1: parts[1].split(" ") else: @[]

  case cmd
  of "get":
    get(args)
  of "set":
    set(args)
  else:
    handleRun3Statement(ctx, inputTrimmed)

proc repl*(args: seq[string] = @[]) =
  ## Starts the kpkg REPL with history support.
  let ctx = initExecutionContext()
  let historyPath = getCacheDir() / "kpkg"
  let historyFile = historyPath / "history"

  # Ensure config dir exists
  try:
    if not dirExists(historyPath):
      createDir(historyPath)
  except:
    discard

  if args.len > 0:
    # Process commands from arguments
    dispatchCommand(ctx, args.join(" "))
    return

  when not defined(windows) and not defined(genode):
    replCompletionPackages = repositoryPackageNames()
    try:
      replCompletionInstalled = getListPackages("/")
    except CatchableError:
      replCompletionInstalled = @[]
    linenoise.setCompletionCallback(replCompletionCallback)
    defer: linenoise.setCompletionCallback(nil)

  echo "kpkg REPL (run3)"
  echo "Type 'exit' or 'quit' to leave."

  var buffer = ""
  var braceCount = 0

  while true:
    var line: string
    let prompt = if braceCount > 0: "      " else: "kpkg> "
    let ok = readLineFromStdin(prompt, line)

    if not ok: # EOF
      break

    let trimmed = line.strip()
    if trimmed == "" and buffer == "":
      continue

    if (trimmed == "exit" or trimmed == "quit") and buffer == "":
      break

    if buffer != "":
      buffer.add("\n")
    buffer.add(line)

    # Simple brace counting to handle multi-line blocks
    for c in line:
      if c == '{': braceCount += 1
      elif c == '}': braceCount -= 1

    if braceCount > 0:
      continue

    let fullInput = buffer.strip()
    buffer = ""
    braceCount = 0 # Reset just in case it went negative

    if fullInput == "":
      continue

    # Save to history file (skip exit commands and very short single-word commands that might be typos)
    if fullInput notin ["exit", "quit", "help", "history", "clear"]:
      try:
        let f = open(historyFile, fmAppend)
        f.writeLine(fullInput)
        f.close()
      except:
        discard

    if fullInput == "history":
      try:
        echo readFile(historyFile)
      except:
        error("Could not read history file")
      continue

    if fullInput == "clear":
      eraseScreen()
      setCursorPos(0, 0)
      flushFile(stdout)
      continue

    # Dispatch commands
    dispatchCommand(ctx, fullInput)
