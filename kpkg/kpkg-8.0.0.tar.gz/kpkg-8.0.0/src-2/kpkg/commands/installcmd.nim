import ../modules/transactions/barrier
import os
import osproc
import std/httpclient
import std/typedthreads
import std/locks
import times
import posix
import strutils
import sequtils
import parsecfg
import tables
import ../modules/sqlite
import ../modules/fileowners
import std/sets
import ../modules/config
import ../../common/logging
import ../modules/lockfile
import ../modules/checksums
import ../modules/runparser
import ../modules/processes
import ../modules/downloader
import ../modules/config as kpkgConfig
import ../modules/dephandler
import ../modules/libarchive
import ../modules/commonTasks
import ../modules/commonPaths
import ../modules/removeInternal
import ../modules/transactions/main
import ../modules/transactions/history
import ../modules/run3/run3
import ../modules/staleprocs
import ../modules/builder/commitctx
import ../modules/telemetry/main as telemetry

type
  FileToInstall = object
    srcPath: string  # Path in the extracted temp directory
    destPath: string # Final destination path in root
    relPath: string  # Relative path for database
    checksum: string # Blake2 checksum
    isDir: bool      # Whether this is a directory
    isSymlink: bool  # Whether this is a symlink

proc validateExtractedFiles(kpkgInstallTemp: string, extractTarball: seq[string],
                            dict: Config, pkg: runFile,
                            raiseErrors = false): seq[FileToInstall] =
  ## Validate all extracted files and return a list of files to install.
  ## This is the "check" phase - no side effects on the target system.
  result = @[]

  for file in extractTarball:
    if "pkgsums.ini" == lastPathPart(file) or "pkgInfo.ini" == lastPathPart(file):
      continue

    # libarchive returns archive-relative names; only normalize absolute
    # names. This avoids resolving a relative entry against the process cwd.
    var relPath = if file.isAbsolute: relativePath(file, kpkgInstallTemp)
                  else: file
    # Archives created with "tar -C <parent> ." store entries with a leading
    # "./" while pkgsums.ini keys never carry it. Normalize so the manifest
    # lookup and destination paths match regardless of how the archive was
    # packed.
    while relPath.startsWith("./"):
      relPath = relPath[2 ..^ 1]
    let srcPath = kpkgInstallTemp & "/" & relPath
    let value = dict.getSectionValue("", relPath)

    let isSymlink = symlinkExists(srcPath)
    let isRegularFile = fileExists(srcPath) and not isSymlink
    let isDir = dirExists(srcPath) and not isSymlink

    # Validate checksums for regular files
    if isRegularFile:
      if isEmptyOrWhitespace(value):
        debug file
        if raiseErrors:
          raise newException(IOError, "package sums invalid - file exists but no checksum in manifest")
        fatal("package sums invalid - file exists but no checksum in manifest")

      let actualSum = getSum(srcPath, "b2")
      if actualSum != value:
        if raiseErrors:
          raise newException(IOError, "sum for file '" & file & "' invalid")
        fatal("sum for file '" & file & "' invalid")

      result.add(FileToInstall(
        srcPath: srcPath,
        destPath: "", # Will be set later with root
        relPath: relPath,
        checksum: value,
        isDir: false,
        isSymlink: false
      ))
    elif isSymlink:
      result.add(FileToInstall(
        srcPath: srcPath,
        destPath: "",
        relPath: relPath,
        checksum: "",
        isDir: false,
        isSymlink: true
      ))
    elif isDir:
      result.add(FileToInstall(
        srcPath: srcPath,
        destPath: "",
        relPath: relPath,
        checksum: "",
        isDir: true,
        isSymlink: false
      ))

proc backupExistingFiles(tx: Transaction, filesToInstall: var seq[FileToInstall],
                         root: string, pkg: runFile) =
  ## Backup existing files that will be replaced.
  ## This allows rollback if installation fails.
  for i in 0..<filesToInstall.len:
    let destPath = root & "/" & filesToInstall[i].relPath
    filesToInstall[i].destPath = destPath

    # Skip backup files
    if filesToInstall[i].relPath in pkg.backup:
      continue

    # Backup existing files/symlinks (not directories)
    if fileExists(destPath) or symlinkExists(destPath):
      let backupPath = tx.backupFile(destPath)
      if backupPath != "":
        tx.recordFileReplaced(destPath, backupPath)

proc installFilesAtomic(tx: Transaction, filesToInstall: seq[FileToInstall],
                        kpkgInstallTemp: string, root: string, backup: seq[string]) =
  ## Install files with transaction recording for rollback support.

  # Pre-flight before anything is written or journaled: a file or symlink
  # cannot replace a real directory. Failing here raises (so the caller rolls
  # back cleanly) instead of dying mid-install with a journal entry for an
  # operation that never happened, which `kpkg history recover` then refuses.
  for f in filesToInstall:
    if f.isDir:
      continue
    if dirExists(f.destPath) and not symlinkExists(f.destPath) and
        not (f.relPath in backup):
      raise newException(IOError, "'" & f.relPath &
          "' is a directory on the target, cannot replace it with a " &
          (if f.isSymlink: "symlink" else: "file") &
          "; the package needs a preinstall step that migrates it")

  # First pass: create directories
  for f in filesToInstall:
    if f.isDir:
      if not (dirExists(f.destPath) or symlinkExists(f.destPath)):
        tx.recordDirCreated(f.destPath)
        createDirWithPermissionsAndOwnership(f.srcPath, f.destPath)
        debug "Installed directory: " & f.relPath

  # Second pass: install files and symlinks
  for f in filesToInstall:
    if f.isDir:
      continue

    # Skip backup files if they already exist (preserve user configs)
    if f.relPath in backup and (fileExists(f.destPath) or symlinkExists(
        f.destPath) or dirExists(f.destPath)):
      debug "Skipping backup file (already exists): " & f.relPath
      continue

    # Ensure parent directory exists
    let parentDir = f.destPath.parentDir()
    if not dirExists(parentDir):
      let srcParentDir = f.srcPath.parentDir()
      tx.recordDirCreated(parentDir)
      createDirWithPermissionsAndOwnership(srcParentDir, parentDir)

    # Install through a same-directory temporary path and atomic rename.
    # This avoids exposing a partially copied file to other processes.
    if f.isSymlink:
      tx.recordSymlinkCreated(f.destPath)
      copyFileAtomicWithPermissionsAndOwnership(f.srcPath, f.destPath)
      debug "Installed symlink: " & f.relPath
    else:
      tx.recordFileCreated(f.destPath)
      copyFileAtomicWithPermissionsAndOwnership(f.srcPath, f.destPath)
      debug "Installed file: " & f.relPath

proc installProgress(index, percent, progressStart: int) =
  if index >= 0:
    let scaled = progressStart + percent * (100 - progressStart) div 100
    progressUpdate(index, scaled, detail = "installing")

proc configureHookRoot*(ctx: Run3Context, root: string) =
  ## Package hooks (pre/post install/upgrade) are written for the system they
  ## run on: `getent group gdm || groupadd gdm`, `chown /var/lib/gdm`,
  ## `systemctl preset`. When installing into another root (krep rootfs,
  ## `kpkg install --root=...`) they must run inside that root, or they
  ## silently change the build host instead. Once the root has a shell, run
  ## hooks in a bwrap sandbox rooted there with ROOT=/; before that (the first
  ## packages of a fresh root) there is nothing to run them with, so they keep
  ## the old host-side behaviour.
  let target = if root.len == 0: "/" else: root
  var isHost = false
  try:
    isHost = expandFilename(target) == "/"
  except OSError:
    isHost = false
  if isHost:
    return
  if fileExists(target & "/bin/sh") or symlinkExists(target & "/bin/sh"):
    ctx.passthrough = false
    ctx.sandboxPath = target
    ctx.asRoot = true
    ctx.remount = false
    ctx.destDir = "/"
    ctx.buildRoot = "/"
    ctx.builtinEnv("ROOT", "/")
    ctx.builtinEnv("DESTDIR", "/")
  else:
    warn "no /bin/sh in " & target & " yet: package hooks run on the host"

const deferredPostinstallFile = "/var/lib/kpkg/deferred-postinstall"

proc isForeignRootWithoutShell(root: string): bool =
  ## True while installing into another root that has no /bin/sh yet.
  let target = if root.len == 0: "/" else: root
  try:
    if expandFilename(target) == "/": return false
  except OSError:
    discard
  not (fileExists(target & "/bin/sh") or symlinkExists(target & "/bin/sh"))

proc deferPostinstall(root, package: string) =
  ## Remember a postinstall that cannot run yet: the first packages of a
  ## fresh root (glibc, ...) are installed before any shell exists there, and
  ## running their hooks on the build host would change the wrong system.
  let path = root & deferredPostinstallFile
  createDir(parentDir(path))
  let f = open(path, fmAppend)
  defer: f.close()
  f.writeLine(package)
  info "postinstall of " & package & " deferred until " & root & " has a shell"

proc runDeferredPostinstalls(root: string) =
  ## Run hooks deferred by deferPostinstall, inside the root, once it has a
  ## shell. Failures are reported but do not fail the current install.
  let path = root & deferredPostinstallFile
  if not fileExists(path) or isForeignRootWithoutShell(root):
    return
  var pending: seq[string]
  for line in lines(path):
    let name = line.strip()
    if name.len > 0 and name notin pending: pending.add(name)
  removeFile(path)
  for name in pending:
    let repo = findPkgRepo(name)
    if repo.len == 0:
      warn "deferred postinstall: no repository has " & name & ", skipping"
      continue
    try:
      let pkg = runparser.parseRunfile(repo & "/" & name)
      let fn = resolveHookFunction(pkg.run3Data.parsed, "postinstall", name)
      if fn == "": continue
      let hctx = initRun3ContextFromParsed(pkg.run3Data.parsed, destDir = root,
          srcDir = repo & "/" & name, buildRoot = root)
      hctx.passthrough = true
      configureHookRoot(hctx, root)
      info "running deferred postinstall of " & name
      if executeRun3Stage(hctx, pkg.run3Data.parsed, fn) != 0:
        warn "deferred postinstall of " & name & " failed"
    except CatchableError as e:
      warn "deferred postinstall of " & name & " failed: " & e.msg

proc installPkgImpl(repo: string, package: string, root: string, runf = runFile(
        isParsed: false), manualInstallList: seq[string], isUpgrade = false,
                kTarget = kpkgTarget(root), ignorePostInstall = false,
                disablePkgInfo = false, ignorePreInstall = false,
                basePackage = false, version = "", tarballPath = "",
                keepTransaction = false, progressIndex = -1,
                progressStart = 0, deferPostInstall = false) =
  ## Installs a package atomically with transaction support.
  ## If installation fails at any point, changes are rolled back.
  ## ignorePostInstall runs the hook and ignores failure. deferPostInstall
  ## skips it entirely for repair; callers must reinstall to run it later.
  ## Other hooks and ldconfig are deliberately unchanged.

  var pkg: runFile

  try:
    if runf.isParsed:
      pkg = runf
    else:
      debug "parseRunfile ran, installPkg"
      pkg = runparser.parseRunfile(repo&"/"&package)
  except CatchableError:
    if keepTransaction:
      raise newException(IOError,
          "Unknown error while trying to parse package on repository, possibly broken repo?")
    fatal("Unknown error while trying to parse package on repository, possibly broken repo?")

  debug "installPkg ran, repo: '"&repo&"', package: '"&package&"', root: '"&root&"', manualInstallList: '"&manualInstallList.join(
      " ")&"', kTarget: '"&kTarget&"'"

  # Resolve which release file describes the install root. A sandbox upperDir has
  # no release file of its own, so fall back to the env copy. When neither exists
  # (a foreign host during bootstrap) pass "" and let hostSystem synthesize one.
  let kreatoReleasePath =
    if fileExists(root / kreatoReleaseName):
      root / kreatoReleaseName
    elif fileExists(kpkgEnvPath / kreatoReleaseName):
      kpkgEnvPath / kreatoReleaseName
    else:
      ""

  let isUpgradeActual = (packageExists(package, root) and getPackage(package,
          root).version != pkg.versionString) or isUpgrade

  # Prepare Context for run3 scripts
  let ctx = initRun3ContextFromParsed(pkg.run3Data.parsed, destDir = root,
          srcDir = repo&"/"&package, buildRoot = root)
  ctx.builtinEnv("ROOT", root)
  ctx.builtinEnv("DESTDIR", root)
  ctx.passthrough = true
  configureHookRoot(ctx, root)

  # Check for conflicts
  for i in pkg.conflicts:
    if packageExists(i, root):
      if keepTransaction:
        raise newException(IOError, i&" conflicts with "&package)
      fatal(i&" conflicts with "&package)

  let historySession = if keepTransaction: nil else: beginHistory(root)
  var historyReason = ""
  for hook in ["preinstall", "postinstall", "preupgrade", "postupgrade"]:
    if resolveHookFunction(pkg.run3Data.parsed, hook, package) != "":
      historyReason = "package hooks may change untracked files"
  # Recursive init-package removal has additional file effects not yet journaled.
  let installedBase = root & "/var/cache/kpkg/installed"
  for removed in pkg.replaces & @[package]:
    if symlinkExists(installedBase / removed):
      historyReason = "replacement through a package alias is not supported by rollback"
  for kind, candidate in walkDir(installedBase):
    for removed in pkg.replaces & @[package]:
      if candidate.startsWith(installedBase & "/" & removed & "-"):
        historyReason = "init-specific package removal is not supported by rollback"

  markHistoryBarrier(root, historyReason)

  # Run preupgrade hook (before any changes)
  if isUpgradeActual:
    let preupgradeFunc = resolveHookFunction(pkg.run3Data.parsed, "preupgrade", package)
    if preupgradeFunc != "":
      if executeRun3Stage(ctx, pkg.run3Data.parsed, preupgradeFunc) != 0:
        fatal("preupgrade failed")

  # Run preinstall hook (before any changes)
  if not packageExists(package, root):
    let preinstallFunc = resolveHookFunction(pkg.run3Data.parsed, "preinstall", package)
    if preinstallFunc != "":
      if executeRun3Stage(ctx, pkg.run3Data.parsed, preinstallFunc) != 0:
        if ignorePreInstall:
          warn "preinstall failed"
        else:
          if keepTransaction:
            raise newException(IOError, "preinstall failed")
          fatal("preinstall failed")

  let isGroup = pkg.isGroup

  # Setup temp directories
  removeDir("/tmp/kpkg/reinstall/"&package&"-old")
  createDir("/tmp")
  createDir("/tmp/kpkg")

  var tarball: string
  var pkgVersion = pkg.versionString

  if not isEmptyOrWhitespace(version):
    pkgVersion = version

  if not isGroup:
    if tarballPath.len > 0:
      tarball = tarballPath
    else:
      tarball = kpkgArchivesDir&"/system/"&kTarget&"/"&package&"-"&pkgVersion&".kpkg"


  # Create transaction for atomic installation
  var tx = newTransaction(package, root)
  if historyReason.len > 0:
    durableWrite(tx.journalPath & ".reason", historyReason)

  try:
    # Handle package replacements with transaction support
    for i in pkg.replaces:
      if packageExists(i, root):
        let replacedInfo = isReplaced(i, root)
        if replacedInfo.replaced:
          debug "Package '"&i&"' is already replaced by '"&replacedInfo.package.name&"', skipping removal"
          continue

        # Backup files from replaced package before removal
        let replacedFiles = getListFiles(i, root)
        for f in replacedFiles:
          let fullPath = root & "/" & f
          if fileExists(fullPath) or symlinkExists(fullPath):
            let backupPath = tx.backupFile(fullPath)
            if backupPath != "":
              tx.recordFileDeleted(fullPath, backupPath)
          elif dirExists(fullPath):
            tx.recordDirDeleted(fullPath)

        if kTarget != kpkgTarget(root, releasePath = kreatoReleasePath):
          removeInternal(i, root, initCheck = false, historyTx = tx)
        else:
          removeInternal(i, root, kreatoPath = kreatoReleasePath,
              historyTx = tx)

    # Handle reinstallation - backup old package files
    let wasInstalled = packageExists(package, root) and (not isGroup)
    if wasInstalled:
      info "package already installed, reinstalling"

      # Backup all files from the old package
      let oldFiles = getListFiles(package, root)
      for f in oldFiles:
        let fullPath = root & "/" & f
        if fileExists(fullPath) or symlinkExists(fullPath):
          let backupPath = tx.backupFile(fullPath)
          if backupPath != "":
            tx.recordFileDeleted(fullPath, backupPath)
        elif dirExists(fullPath):
          tx.recordDirDeleted(fullPath)

      # Remove old package from database (but files are backed up)
      if kTarget != kpkgTarget(root, releasePath = kreatoReleasePath):
        removeInternal(package, root, ignoreReplaces = true,
                noRunfile = true, initCheck = false, historyTx = tx)
      else:
        removeInternal(package, root, ignoreReplaces = true,
                noRunfile = false, depCheck = false,
                kreatoPath = kreatoReleasePath, historyTx = tx)

    discard existsOrCreateDir(root&"/var")
    discard existsOrCreateDir(root&"/var/cache")
    discard existsOrCreateDir(root&kpkgCacheDir)

    let kpkgInstallTemp = kpkgTempDir1&"/install-"&package
    if not isGroup:
      var extractTarball: seq[string]
      if dirExists(kpkgInstallTemp):
        removeDir(kpkgInstallTemp)

      createDir(kpkgInstallTemp)

      # Phase 1: Extract using independent libarchive reader/writer handles.
      # extract() no longer changes process cwd, so independent package
      # archives can safely extract concurrently.
      try:
        extractTarball = extract(tarball, kpkgInstallTemp)
      except Exception:
        when defined(release):
          tx.rollback()
          if keepTransaction:
            raise newException(IOError, "extracting the tarball failed for "&package)
          fatal("extracting the tarball failed for "&package)
        else:
          tx.rollback()
          raise getCurrentException()

      installProgress(progressIndex, 22, progressStart)
      var dict = loadConfig(kpkgInstallTemp&"/pkgsums.ini")

      # Phase 2: Validate all files (no side effects)
      var filesToInstall = validateExtractedFiles(kpkgInstallTemp,
          extractTarball, dict, pkg, raiseErrors = keepTransaction)

      # Update destination paths
      for i in 0..<filesToInstall.len:
        filesToInstall[i].destPath = root & "/" & filesToInstall[i].relPath

      installProgress(progressIndex, 38, progressStart)

      # Phase 3: Check pkgInfo dependencies
      if fileExists(kpkgInstallTemp&"/pkgInfo.ini") and (not disablePkgInfo):
        var dict2 = loadConfig(kpkgInstallTemp&"/pkgInfo.ini")

        for dep in dict2.getSectionValue("", "depends").split(" "):
          if isEmptyOrWhitespace(dep):
            continue

          let depClean = dep.strip()
          if isEmptyOrWhitespace(depClean):
            continue

          let hashPos = depClean.find('#')

          if hashPos < 0 or hashPos == depClean.high:
            warn "pkgInfo lists dependency '"&depClean&"', but it is missing a version; skipping check"
            continue

          let depName = depClean[0 ..< hashPos].strip()
          let depVersion = depClean[(hashPos + 1) .. depClean.high].strip()

          if isEmptyOrWhitespace(depName) or isEmptyOrWhitespace(depVersion):
            warn "pkgInfo lists dependency '"&depClean&"', but it is missing a name or version; skipping check"
            continue

          if not packageExists(depName, root):
            warn "pkgInfo lists dependency '"&depName&"', but it is not installed at '"&root&"'; skipping version check"
            continue

          var db: Package
          try:
            db = getPackage(depName, root)
          except:
            if isEnabled(lvlDebug):
              debug "getPackage failed for '"&depName&"' at root '"&root&"'"
              debug "pkgInfo.ini content:"
              try:
                let pkgInfoContent = readFile(kpkgInstallTemp&"/pkgInfo.ini")
                for line in pkgInfoContent.splitLines():
                  debug "  "&line
              except:
                debug "  (could not read pkgInfo.ini file)"
            tx.rollback()
            raise

          if db.version != depVersion:
            warn "this package is built with '"&depName&"#"&depVersion&"', while the system has '"&depName&"#"&db.version&"'"
            warn "installing anyway, but issues may occur"
            warn "this may be an error in the future"

      # Phase 3b..6 hold the ownership lock: the plan reads disk and committed
      # File rows, so no other install worker may write or commit an aliasing
      # path between this package's plan and its DB commit.
      withOwnershipLock:
        # Phase 3b: Resolve ownership across path aliases (bin -> usr/bin ...).
        # A symlink must not replace a real file another package owns, and an
        # entry that replaces another package's symlink takes that file over.
        var entries: seq[OwnershipEntry]
        for f in filesToInstall:
          if not f.isDir:
            entries.add((relPath: f.relPath, isSymlink: f.isSymlink))
        let ownership = planOwnership(root, package, entries,
            loadOwnerIndex(root))
        for m in ownership.warnings:
          warn m
        for m in ownership.notes:
          info m
        if ownership.skip.len > 0:
          filesToInstall = filesToInstall.filterIt(it.relPath notin ownership.skip)

        # Phase 4: Backup existing files that will be replaced
        backupExistingFiles(tx, filesToInstall, root, pkg)

        # Phase 5: Install files with transaction recording
        installFilesAtomic(tx, filesToInstall, kpkgInstallTemp, root, pkg.backup)

        installProgress(progressIndex, 72, progressStart)

        # Phase 6: Update database (after all files are installed)
        var mI = false
        if package in manualInstallList:
          debug "Setting as manually installed"
          mI = true

        # Use database transaction for atomicity
        beginTransaction(root)
        try:
          var pkgType = newPackage(package, pkgVersion, pkg.release, pkg.epoch,
                  pkg.deps.join("!!k!!"), pkg.bdeps.join("!!k!!"),
                  pkg.backup.join("!!k!!"), pkg.replaces.join("!!k!!"),
                  pkg.license.join("!!k!!"), pkg.desc,
                  mI, pkg.isGroup, basePackage, root)

          # Add file entries to database, minus entries we declined to write,
          # and hand over files this package replaced from other packages.
          pkgSumsToSQL(kpkgInstallTemp&"/pkgsums.ini", pkgType, root,
              ownership.skip)
          dropFileOwnership(ownership.drops, root)

          commitTransaction(root)
        except:
          rollbackTransaction(root)
          tx.rollback()
          raise

      installProgress(progressIndex, 86, progressStart)

    else:
      # Register group packages in the database
      var mI = false
      if package in manualInstallList:
        debug "Setting as manually installed"
        mI = true

      beginTransaction(root)
      try:
        discard newPackage(package, pkgVersion, pkg.release, pkg.epoch,
                pkg.deps.join("!!k!!"), pkg.bdeps.join("!!k!!"),
                pkg.backup.join("!!k!!"), pkg.replaces.join("!!k!!"),
                pkg.license.join("!!k!!"), pkg.desc,
                mI, pkg.isGroup, basePackage, root)
        commitTransaction(root)
      except:
        rollbackTransaction(root)
        tx.rollback()
        raise

      installProgress(progressIndex, 86, progressStart)

    installProgress(progressIndex, 91, progressStart)

    # Run ldconfig afterwards for any new libraries.
    ensureValidCwd()
    let ldconfigCmd = if root == "/": "ldconfig" else: "ldconfig -r " & root
    discard execProcess(ldconfigCmd)

    # Phase 7: Run postinstall (BEFORE cleanup so rollback is possible)
    configureHookRoot(ctx, root)
    runDeferredPostinstalls(root)
    let postinstallFunc = resolveHookFunction(pkg.run3Data.parsed,
        "postinstall", package)
    if not deferPostInstall and postinstallFunc != "" and
        isForeignRootWithoutShell(root):
      deferPostinstall(root, package)
    elif not deferPostInstall and postinstallFunc != "":
      if executeRun3Stage(ctx, pkg.run3Data.parsed, postinstallFunc) != 0:
        if ignorePostInstall:
          warn "postinstall failed"
        else:
          tx.rollback()
          rollbackTransaction(root)
          if keepTransaction:
            raise newException(IOError, "postinstall failed")
          fatal("postinstall failed")

    # Phase 8: Run postupgrade
    if isUpgradeActual:
      let postupgradeFunc = resolveHookFunction(pkg.run3Data.parsed,
          "postupgrade", package)
      if postupgradeFunc != "":
        if executeRun3Stage(ctx, pkg.run3Data.parsed, postupgradeFunc) != 0:
          tx.rollback()
          rollbackTransaction(root)
          if keepTransaction:
            raise newException(IOError, "postupgrade failed")
          fatal("postupgrade failed")

    # Hooks can generate files or rewrite package-owned metadata. Refresh
    # their authoritative SQLite checksums before the package is exposed to
    # sandbox validation.
    refreshPackageChecksums(package, root)

    # Phase 9: Commit transaction (removes backups, deletes journal). In a
    # batch install, leave the journal and backups active until every package
    # succeeds; the batch coordinator then finalizes all transactions.
    if keepTransaction:
      debug "Transaction staged: " & tx.id
    else:
      finishHistory(historySession, @[tx], historyReason)
      tx.commit()

    # Phase 10: Cleanup temp directories (AFTER successful commit)
    when defined(release):
      # Remove only this installation's extraction directory.  kpkgTempDir1
      # also contains the active sandbox mounts and must never be deleted by
      # the package installer.
      if dirExists(kpkgInstallTemp):
        removeDir(kpkgInstallTemp)

    for i in pkg.optdeps:
      info(i)

  except CatchableError:
    # Rollback on any error
    error "Installation failed, rolling back..."
    tx.rollback()
    raise

proc installPkg*(repo: string, package: string, root: string, runf = runFile(
        isParsed: false), manualInstallList: seq[string], isUpgrade = false,
                kTarget = kpkgTarget(root), ignorePostInstall = false,
                disablePkgInfo = false, ignorePreInstall = false,
                basePackage = false, version = "", tarballPath = "",
                keepTransaction = false, progressIndex = -1,
                progressStart = 0, deferPostInstall = false) =
  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if root == "": "/" else: root)

  telemetry.withSpan("kpkg.install", {
    "package.name": package,
    "package.version": version
  }.toTable):
    installPkgImpl(repo, package, root, runf, manualInstallList, isUpgrade,
        kTarget, ignorePostInstall, disablePkgInfo, ignorePreInstall,
        basePackage, version, tarballPath, keepTransaction, progressIndex,
        progressStart, deferPostInstall)

proc canDownloadBinary*(package: string, version: string, binrepos: seq[string],
        kTarget: string): bool =
  ## Check if a binary is downloadable from any mirror (without actually
  ## downloading). Uses a native HTTP HEAD request with a short timeout
  ## instead of spawning curl.

  let tarball = package & "-" & version & ".kpkg"

  for binrepo in binrepos:
    if isEmptyOrWhitespace(binrepo):
      continue
    let url = "https://" & binrepo & "/archives/system/" & kTarget & "/" & tarball
    try:
      var client = newHttpClient(timeout = 10, userAgent = "kpkg")
      defer: client.close()
      let resp = client.request(url, HttpHead)
      if resp.code.is2xx:
        debug "canDownloadBinary: Binary '" & tarball & "' found at " & binrepo
        return true
    except CatchableError:
      debug "canDownloadBinary: HEAD request to " & binrepo & " failed: " &
          getCurrentExceptionMsg()
      continue

  debug "canDownloadBinary: Binary '" & tarball & "' not found on any mirror"
  return false

proc down_bin*(package: string, binrepos: seq[string], root: string,
        offline: bool, forceDownload = false, ignoreDownloadErrors = false,
                kTarget = kpkgTarget(root), version = "", customPath = "",
                ignoreErrors = false, commit = "") =
  ## Downloads binaries.
  ##
  ## For commit-based installs, the version should be the version at that commit.
  ## If commit is specified and binary not found, returns without error (caller handles it).

  discard existsOrCreateDir("/var/")
  discard existsOrCreateDir("/var/cache")
  discard existsOrCreateDir("/var/cache/kpkg")
  discard existsOrCreateDir(kpkgArchivesDir)
  discard existsOrCreateDir(kpkgArchivesDir&"/system")
  discard existsOrCreateDir(kpkgArchivesDir&"/system/"&kTarget)

  var downSuccess: bool

  var binreposFinal = binrepos.filterIt(not isEmptyOrWhitespace(it))

  var override: Config

  if fileExists("/etc/kpkg/override/"&package&".conf"):
    override = loadConfig("/etc/kpkg/override/"&package&".conf")
  else:
    override = newConfig() # So we don't get storage access errors

  let binreposOverride = override.getSectionValue("Mirror", "binaryMirrors")

  if not isEmptyOrWhitespace(binreposOverride):
    binreposFinal = binreposOverride.split(" ").filterIt(
            not isEmptyOrWhitespace(it))

  var pkgVersion = version

  if isEmptyOrWhitespace(pkgVersion):
    var repo = findPkgRepo(package)
    var pkg: runFile

    try:
      debug "parseRunfile ran, down_bin"
      pkg = runparser.parseRunfile(repo&"/"&package)
    except CatchableError:
      const msg = "Unknown error while trying to parse package on repository, possibly broken repo?"
      if ignoreErrors:
        debug msg
        return
      else:
        fatal(msg)

    if pkg.isGroup:
      return

    pkgVersion = pkg.versionString

  let tarball = package&"-"&pkgVersion&".kpkg"
  var path = kpkgArchivesDir&"/system/"&kTarget&"/"&tarball
  if not isEmptyOrWhitespace(customPath):
    path = customPath

  if fileExists(path) and (not forceDownload):
    debug "Tarball already exists for '"&package&"', not gonna download again"
    downSuccess = true
  elif not offline:
    # Ask the mirrors whether the binary exists before attempting a download.
    # On a target with no published binaries (e.g. a new arch during
    # bootstrap) this replaces a chain of failed downloads with one clear
    # message, and lets ignoreDownloadErrors callers fall back to source.
    if commit == "" and not canDownloadBinary(package, pkgVersion,
            binreposFinal, kTarget):
      const hint = "use 'kpkg build' to build it from source, or check Repositories.binRepos"
      if ignoreErrors or ignoreDownloadErrors:
        debug "down_bin: no binary for '" & package & "' on target '" &
            kTarget & "'; " & hint
        return
      fatal("no binary of '" & package & "' for target '" & kTarget &
          "' exists on any mirror; " & hint)

    for binrepo in binreposFinal:
      try:
        download("https://"&binrepo&"/archives/system/"&kTarget&"/"&tarball, path)
        downSuccess = true
        break
      except:
        debug "down_bin: Failed to download from " & binrepo
        continue

    if not downSuccess and commit != "":
      debug "down_bin: Binary for commit '" & commit & "' not found, returning (caller will handle)"
      return
  else:
    const msg = "attempted to download tarball from binary repository in offline mode"
    debug path
    if ignoreErrors:
      debug msg
      return
    else:
      if commit != "":
        debug "down_bin: Offline mode, commit package not cached"
        return
      fatal(msg)

  if not downSuccess and not ignoreDownloadErrors and commit == "":
    fatal("couldn't download the binary")

proc getMirrorList(package: string, binrepos: seq[string]): seq[string] =
  ## Returns the mirror list for a package, honoring per-package overrides.
  var binreposFinal = binrepos
  if fileExists("/etc/kpkg/override/"&package&".conf"):
    let override = loadConfig("/etc/kpkg/override/"&package&".conf")
    let binreposOverride = override.getSectionValue("Mirror", "binaryMirrors")
    if not isEmptyOrWhitespace(binreposOverride):
      binreposFinal = binreposOverride.split(" ")
  return binreposFinal

proc downloadBatch(packages: seq[string], binrepos: seq[string],
                   versions: Table[string, string], kTarget: string,
                   offline: bool, forceDownloadPackages: seq[string],
                   forceDownload: bool, ignoreDownloadErrors: bool,
                   combinedProgress = false,
                   progressRows = initTable[string, int](),
                   skipPackages: seq[string] = @[],
                   renderUpdates = true,
                   onTick: proc() {.closure.} = nil): bool =
  ## Downloads all package tarballs in parallel using worker threads.
  ## Packages with a cached tarball are skipped. `versions` maps package
  ## name -> version (may be empty for repo lookup); `commit` maps
  ## package name -> commit hash (for logging only).

  result = true
  let threads = kpkgConfig.getDownloadThreads()

  var jobs: seq[DownloadJob] = @[]
  var skipped = 0
  var queuedPaths: seq[string] = @[]
  var jobProgressRows: seq[int] = @[]

  for pkg in packages:
    if pkg in skipPackages:
      if combinedProgress and progressRows.hasKey(pkg):
        progressUpdate(progressRows[pkg], 45, detail = "ready")
      continue
    var version = versions.getOrDefault(pkg, "")
    if isEmptyOrWhitespace(version):
      # Resolve version from the repository runfile
      try:
        let repo = findPkgRepo(pkg)
        let rf = runparser.parseRunfile(repo & "/" & pkg)
        if rf.isGroup:
          debug "downloadBatch: '" & pkg & "' is a group, skipping"
          continue
        version = rf.versionString
      except CatchableError:
        debug "downloadBatch: could not resolve version for '" & pkg & "', leaving to serial path"
        continue
    if isEmptyOrWhitespace(version):
      continue

    let tarball = pkg & "-" & version & ".kpkg"
    let path = kpkgArchivesDir & "/system/" & kTarget & "/" & tarball

    let fdownload = forceDownload or (pkg in forceDownloadPackages)
    if fileExists(path) and not fdownload:
      debug "downloadBatch: tarball already cached for '" & pkg & "'"
      if combinedProgress and progressRows.hasKey(pkg):
        progressUpdate(progressRows[pkg], 45, detail = "downloaded")
      inc skipped
      continue

    # A package may appear multiple times in the resolved set (e.g. as a
    # dependency and as an explicit reinstall target); only download once.
    if path in queuedPaths:
      debug "downloadBatch: duplicate tarball for '" & pkg & "', skipping"
      inc skipped
      continue
    queuedPaths.add(path)

    var urls: seq[string] = @[]
    for binrepo in getMirrorList(pkg, binrepos):
      urls.add("https://" & binrepo & "/archives/system/" & kTarget & "/" & tarball)

    if urls.len == 0:
      debug "downloadBatch: no mirror URL for '" & pkg & "'"
      inc skipped
      continue

    discard existsOrCreateDir(kpkgArchivesDir)
    discard existsOrCreateDir(kpkgArchivesDir & "/system")
    discard existsOrCreateDir(kpkgArchivesDir & "/system/" & kTarget)

    jobs.add(DownloadJob(label: pkg, urls: urls, destPath: path))
    jobProgressRows.add(if progressRows.hasKey(pkg): progressRows[pkg]
        else: jobs.high)

  if jobs.len == 0:
    # Nothing was queued because every archive was already cached (the only
    # other `continue` that skips a job is a package with no mirror URL, which
    # is counted below). Report success only when something was actually
    # skipped as cached; otherwise a caller that asked for a download receives
    # nothing and must not be told it worked.
    if skipped > 0:
      debug "downloadBatch: nothing to download (all archives already cached)"
      return
    error "no archive could be queued for download: no mirror URL for '" &
        packages.join(" ") & "'"
    return false

  if not offline:
    if combinedProgress:
      debug "downloading " & $jobs.len & " package(s) using " & $threads & " thread(s)"
    else:
      info "downloading " & $jobs.len & " package(s) using " & $threads & " thread(s)"
    let results = downloadParallel(jobs, threads,
        manageProgress = not combinedProgress,
        progressIndices = jobProgressRows,
        progressStart = 0,
        progressEnd = if combinedProgress: 45 else: 100,
        renderUpdates = renderUpdates, onTick = onTick)

    for r in results:
      if not r.ok and not ignoreDownloadErrors:
        if not combinedProgress:
          error "failed to download '" & r.label & "'"
        result = false
  else:
    const msg = "attempted to download tarball from binary repository in offline mode"
    for j in jobs:
      debug msg & " (" & j.label & ")"
    if not ignoreDownloadErrors:
      result = false


type
  InstallWorkItem = object
    name: string
    repo: string
    root: string
    kTarget: string
    version: string
    basePackage: bool
    manual: bool
    deps: seq[string]
    conflicts: seq[string]
    replaces: seq[string]
    isGroup: bool
    keepTransaction: bool
    progressIndex: int
    progressStart: int
    idx: int

  InstallResult = object
    idx: int
    ok: bool
    errorMsg: string
    deferredLogs: seq[string]

type
  InstallChannelState = object
    workChan: Channel[InstallWorkItem]
    resultChan: Channel[InstallResult]

proc openInstallChannels(state: var InstallChannelState, jobs, workers: int) =
  ## Initialize a zeroed, batch-owned channel state in place. Never return or
  ## copy this object: Channel contains synchronization/storage handles.
  state.workChan.open(jobs + workers + 4)
  state.resultChan.open(jobs + 4)

proc closeInstallChannels(state: var InstallChannelState,
        workers: var seq[Thread[ptr InstallChannelState]], started: int) =
  ## Stop workers before closing batch-owned channels. The caller must invoke
  ## this from a defer as well as its normal path; `started` handles partial
  ## thread creation during exceptional setup.
  for _ in 0 ..< started:
    state.workChan.send(InstallWorkItem(name: "\x00quit"))
  for i in 0 ..< started:
    joinThread(workers[i])
  # Channel.close releases the raw queue storage without running payload
  # destructors. Drain both queues before closing on exceptional paths.
  while state.workChan.peek() > 0:
    discard state.workChan.recv()
  while state.resultChan.peek() > 0:
    discard state.resultChan.recv()
  state.workChan.close()
  state.resultChan.close()

proc installWorkerThread(state: ptr InstallChannelState) {.thread.} =
  {.cast(gcsafe).}:
    try:
      while true:
        let item = state[].workChan.recv()
        if item.name == "\x00quit":
          break
        setProgressInfoSuppressed(true)
        try:
          # run3 parsing has process-global mutable state. Parse under a lock,
          # then execute the package outside it.
          var parsedRunf: runFile
          parsedRunf = runparser.parseRunfile(item.repo & "/" & item.name)
          progressUpdate(item.progressIndex, item.progressStart,
              detail = "installing")
          installPkg(item.repo, item.name, item.root, runf = parsedRunf,
              manualInstallList = if item.manual: @[item.name] else: @[],
              kTarget = item.kTarget, basePackage = item.basePackage,
              version = item.version, keepTransaction = item.keepTransaction,
              progressIndex = item.progressIndex,
              progressStart = item.progressStart)
          progressUpdate(item.progressIndex, 100, finished = true, ok = true,
              detail = "done")
          state[].resultChan.send(InstallResult(idx: item.idx, ok: true,
              deferredLogs: takeDeferredProgressLogs()))
        except CatchableError:
          let errorMsg = getCurrentExceptionMsg()
          progressUpdate(item.progressIndex, 100, finished = true, ok = false,
              detail = "failed")
          state[].resultChan.send(InstallResult(idx: item.idx, ok: false,
              errorMsg: errorMsg,
              deferredLogs: takeDeferredProgressLogs()))
        finally:
          setProgressInfoSuppressed(false)
    finally:
      # Flush this thread's WAL connection before it exits.
      closeDb()


when defined(kpkgInstallChannelTest):
  proc installChannelProbeWorker(state: ptr InstallChannelState) {.thread.} =
    while true:
      let item = state[].workChan.recv()
      if item.name == "\x00quit":
        break
      # Return string payload data too, so the probe covers ownership and
      # destruction on both queue directions rather than only scalar fields.
      state[].resultChan.send(InstallResult(idx: item.idx, ok: item.name.len >
          0, deferredLogs: @[item.name & "-owned-result"]))

  proc probeInstallChannelLifecycle*(batches: int): bool =
    ## Exercise the installer channel ownership pattern without package I/O.
    ## Each batch owns fresh channels and joins workers before closing them.
    result = true
    for batch in 0 ..< max(0, batches):
      const jobs = 4
      const workersCount = 2
      var channelState: InstallChannelState
      openInstallChannels(channelState, jobs, workersCount)
      var workers = newSeq[Thread[ptr InstallChannelState]](workersCount)
      for worker in workers.mitems:
        createThread(worker, installChannelProbeWorker, addr channelState)
      var seen = newSeq[bool](jobs)
      for idx in 0 ..< jobs:
        channelState.workChan.send(InstallWorkItem(name: "probe-" & $batch &
            "-" & $idx, idx: idx))
      for _ in 0 ..< jobs:
        let itemResult = channelState.resultChan.recv()
        if not itemResult.ok or itemResult.idx < 0 or itemResult.idx >= jobs or
            seen[itemResult.idx] or itemResult.deferredLogs.len != 1 or
            itemResult.deferredLogs[0].len <= 0:
          result = false
        else:
          seen[itemResult.idx] = true
      for found in seen:
        if not found:
          result = false
      closeInstallChannels(channelState, workers, workersCount)

  proc probeInstallChannelUnwind*(): bool =
    ## Inject a coordinator exception after queueing work. The scoped defer
    ## must join started workers and drain/close both queues before state dies.
    const jobs = 4
    const workersCount = 2
    var cleaned = false
    try:
      block:
        var channelState: InstallChannelState
        openInstallChannels(channelState, jobs, workersCount)
        var workers = newSeq[Thread[ptr InstallChannelState]](workersCount)
        var startedWorkers = 0
        var channelsOpen = true
        defer:
          if channelsOpen:
            closeInstallChannels(channelState, workers, startedWorkers)
            channelsOpen = false
            cleaned = true
        for worker in workers.mitems:
          createThread(worker, installChannelProbeWorker, addr channelState)
          inc startedWorkers
        for idx in 0 ..< jobs:
          channelState.workChan.send(InstallWorkItem(name: "unwind-" & $idx,
              idx: idx))
        raise newException(IOError, "injected coordinator failure")
    except IOError:
      result = cleaned

proc installLayerParallel(layer: seq[InstallWorkItem], workerLimit: int,
        manageProgress = true): seq[InstallResult] =
  ## Installs an independent dependency layer concurrently. Each worker has
  ## its own SQLite connection; filesystem changes are journaled per package.
  result = @[]
  if layer.len == 0:
    return

  let workerCount = max(1, min(workerLimit, layer.len))
  var progressLabels: seq[string] = @[]
  for item in layer:
    progressLabels.add(item.name)
  if manageProgress:
    progressBegin(progressLabels, "")
  var channelState: InstallChannelState
  openInstallChannels(channelState, layer.len, workerCount)

  var workers = newSeq[Thread[ptr InstallChannelState]](workerCount)
  var startedWorkers = 0
  var channelsOpen = true
  defer:
    if channelsOpen:
      closeInstallChannels(channelState, workers, startedWorkers)
  for i in 0 ..< workerCount:
    createThread(workers[i], installWorkerThread, addr channelState)
    inc startedWorkers

  for item in layer:
    channelState.workChan.send(item)

  var completed = 0
  var deferredLogs: seq[string] = @[]
  while completed < layer.len:
    while channelState.resultChan.peek() > 0:
      let itemResult = channelState.resultChan.recv()
      result.add(itemResult)
      deferredLogs.add(itemResult.deferredLogs)
      inc completed
    progressRender()
    if completed < layer.len:
      sleep(100)

  closeInstallChannels(channelState, workers, startedWorkers)
  channelsOpen = false
  if manageProgress:
    progressFinish()
    # Print worker warnings/errors only after the cursor is below the completed
    # progress block, preventing stderr from overwriting an active row.
    for line in deferredLogs:
      stderr.writeLine(line)
    if deferredLogs.len > 0:
      stderr.flushFile()


type
  BatchInstallState = object
    root: string
    dbPath: string
    dbBackupPath: string
    journalPath: string
    hadDatabase: bool
    historySession: HistorySession

proc beginBatchInstall(root: string): BatchInstallState =
  ## Snapshot metadata before staging the linked package transactions. The database is restored only after all workers
  ## have stopped, so no SQLite connection is copied while it is in use.
  result.root = root
  result.historySession = beginHistory(root)
  result.dbPath = root & "/" & kpkgDbPath
  result.hadDatabase = fileExists(result.dbPath)
  if result.hadDatabase:
    closeDb()
    result.dbBackupPath = kpkgTempDir2 & "/batch-db-" & $getpid() & "-" &
        $int(epochTime() * 1_000_000)
    createDir(kpkgTempDir2)
    atomicHistoryCopy(result.dbPath, result.dbBackupPath)
  let batchId = $getpid() & "-" & $int(epochTime() * 1_000_000)
  result.journalPath = beginBatchJournal(batchId, root, result.dbPath,
      result.dbBackupPath, result.hadDatabase)

proc isBatchTransaction(state: BatchInstallState, id: string): bool =
  loadTransaction(kpkgJournalDir / (id & ".journal")).historyPath ==
      state.historySession.path

proc rollbackBatchInstall(state: BatchInstallState) =
  ## Roll back all package journals created by this batch, then restore the
  ## exact pre-batch SQLite image. Workers are joined before this is called.
  for tx in getActiveTransactions():
    if state.isBatchTransaction(tx.id):
      tx.rollback()

  closeDb()
  if state.hadDatabase and not fileExists(state.dbBackupPath):
    raise newException(IOError, "missing batch database backup; pending history retained")
  for suffix in ["-wal", "-shm"]:
    let sidecar = state.dbPath & suffix
    if fileExists(sidecar):
      removeFile(sidecar)
  if state.hadDatabase:
    atomicHistoryCopy(state.dbBackupPath, state.dbPath)
  elif fileExists(state.dbPath):
    removeFile(state.dbPath)
  if dirExists(parentDir(state.dbPath)):
    syncAncestors(parentDir(state.dbPath))
  # Pending history also owns the cache snapshot. Recovery restores that state
  # and verifies hook barriers before clearing the pending marker. Do not cancel
  # here merely because the tracked package and database rollback completed.


proc finalizeBatchInstall(state: BatchInstallState) =
  ## Make all staged package journals durable only after the complete batch
  ## has succeeded.
  var transactions: seq[Transaction]
  var reason = ""
  for tx in getActiveTransactions():
    if state.isBatchTransaction(tx.id) and tx.root == state.root:
      transactions.add(tx)
      if fileExists(tx.journalPath & ".reason"):
        reason = readFile(tx.journalPath & ".reason")
  finishHistory(state.historySession, transactions, reason)
  for tx in transactions:
    tx.commit()
  if state.dbBackupPath != "" and fileExists(state.dbBackupPath):
    removeFile(state.dbBackupPath)
  finishBatchJournal(state.journalPath)

proc install_bin(packages: seq[string], binrepos: seq[string], root: string,
        offline: bool, downloadOnly = false, manualInstallList: seq[string],
                kTarget = kpkgTarget(root), forceDownload = false,
                ignoreDownloadErrors = false, forceDownloadPackages = @[""],
                basePackage = false,
                commitContexts: Table[string, InstallCommitContext] = initTable[
                    string, InstallCommitContext]()) =
  ## Downloads and installs binaries.
  ##
  ## For commit-based installs:
  ## - Uses version from commit context for download lookup
  ## - Checks if binary exists before download
  ## - Provides helpful error if binary not found

  withLockfile:
    # Phase 1: resolve versions and validate commit-based installs
    var versions = initTable[string, string]()
    var commits = initTable[string, string]()
    var downloadNames: seq[string] = @[]

    for i in packages:
      let pkgParsed = parsePkgInfo(i)
      var versionToUse = pkgParsed.version
      var commitToUse = ""

      if pkgParsed.commit != "":
        commitToUse = pkgParsed.commit
        if pkgParsed.name in commitContexts and commitContexts[
            pkgParsed.name].commit != "":
          versionToUse = commitContexts[pkgParsed.name].versionAtCommit
          info "Installing '" & pkgParsed.name & "#" & commitToUse &
              "' (version " & versionToUse & ")"

      if pkgParsed.commit != "" and versionToUse != "":
        let tarballPath = kpkgArchivesDir & "/system/" & kTarget & "/" &
            pkgParsed.name & "-" & versionToUse & ".kpkg"

        if not fileExists(tarballPath):
          if offline:
            error("Binary for '" & pkgParsed.name & "#" & commitToUse &
                "' (version " & versionToUse & ") not cached")
            info("Use 'kpkg build " & pkgParsed.name & "#" & commitToUse & "' to build from source at this commit")
            quit(1)

          let canDown = canDownloadBinary(pkgParsed.name, versionToUse,
              binrepos, kTarget)
          if not canDown:
            error("Binary for '" & pkgParsed.name & "#" & commitToUse &
                "' (version " & versionToUse & ") not found on mirrors")
            info("Use 'kpkg build " & pkgParsed.name & "#" & commitToUse & "' to build from source at this commit")
            quit(1)

      if pkgParsed.name notin versions or isEmptyOrWhitespace(versions[
          pkgParsed.name]):
        versions[pkgParsed.name] = versionToUse
      commits[pkgParsed.name] = commitToUse
      downloadNames.add(pkgParsed.name)

    if downloadOnly:
      if not downloadBatch(downloadNames, binrepos, versions, kTarget, offline,
              forceDownloadPackages, forceDownload, ignoreDownloadErrors):
        raise newException(IOError, "one or more package downloads failed")
    else:
      # Resolve installation metadata before starting either pool. This gives
      # the scheduler a dependency graph and exact archive paths while keeping
      # run3 parsing serialized.
      var installItems: seq[InstallWorkItem] = @[]
      var itemNames: seq[string] = @[]
      var groupNames: seq[string] = @[]

      for i in packages:
        let pkgParsed = parsePkgInfo(i)
        if pkgParsed.name in itemNames:
          continue
        let itemRepo = if pkgParsed.repo != "": pkgParsed.repo
                       else: findPkgRepo(pkgParsed.name)
        var itemRunf: runFile
        itemRunf = runparser.parseRunfile(itemRepo & "/" & pkgParsed.name)

        var versionToUse = pkgParsed.version
        if pkgParsed.commit != "" and pkgParsed.name in commitContexts and
            commitContexts[pkgParsed.name].commit != "":
          versionToUse = commitContexts[pkgParsed.name].versionAtCommit
        if isEmptyOrWhitespace(versionToUse):
          versionToUse = itemRunf.versionString
        versions[pkgParsed.name] = versionToUse
        itemNames.add(pkgParsed.name)
        if itemRunf.isGroup:
          groupNames.add(pkgParsed.name)
        elif isEmptyOrWhitespace(versionToUse):
          raise newException(IOError,
              "could not resolve version for '" & pkgParsed.name & "'")

        installItems.add(InstallWorkItem(name: pkgParsed.name,
            repo: itemRepo, root: root, kTarget: kTarget,
            version: versionToUse, basePackage: basePackage,
            manual: pkgParsed.name in manualInstallList,
            deps: itemRunf.deps, conflicts: itemRunf.conflicts,
            replaces: itemRunf.replaces, isGroup: itemRunf.isGroup,
            keepTransaction: true, progressIndex: installItems.len,
            progressStart: 45, idx: installItems.len))

      # A single requested package has no independent work to schedule. Keep
      # this common path on the caller thread: successive rootfs installs must
      # not carry parser/allocator state across a worker-thread teardown.
      if installItems.len == 1:
        let item = installItems[0]
        if not downloadBatch(@[item.name], binrepos, versions, kTarget, offline,
                forceDownloadPackages, forceDownload,
                ignoreDownloadErrors):
          raise newException(IOError, "one or more package downloads failed")
        installPkg(item.repo, item.name, item.root,
            manualInstallList = if item.manual: @[item.name] else: @[],
            kTarget = item.kTarget, basePackage = item.basePackage,
            version = item.version, keepTransaction = false)
        return

      var progressRows = initTable[string, int]()
      for idx, name in itemNames:
        progressRows[name] = idx
      progressBegin(itemNames, "")
      var progressClosed = false
      defer:
        if not progressClosed:
          progressRender()
          progressFinish()

      # Downloads alone do not mutate installed state. Start history lazily
      # when the first package is queued, so download-only failures cannot
      # leave a pending operation that blocks subsequent commands.
      var batchState: BatchInstallState
      var batchStarted = false
      var batchSucceeded = false
      defer:
        if batchStarted:
          if batchSucceeded:
            finalizeBatchInstall(batchState)
          else:
            rollbackBatchInstall(batchState)

      let workerLimit = kpkgConfig.getInstallThreads()
      let workerCount = max(1, min(workerLimit, installItems.len))
      var channelState: InstallChannelState
      openInstallChannels(channelState, installItems.len, workerCount)
      var workers = newSeq[Thread[ptr InstallChannelState]](workerCount)
      var startedWorkers = 0
      var channelsOpen = true
      defer:
        if channelsOpen:
          closeInstallChannels(channelState, workers, startedWorkers)
      for worker in workers.mitems:
        createThread(worker, installWorkerThread, addr channelState)
        inc startedWorkers

      var queued = newSeq[bool](installItems.len)
      var succeeded = newSeq[bool](installItems.len)
      var running: seq[int] = @[]
      var completed = 0
      var inFlight = 0
      var batchFailed = false
      var failureMessage = ""
      var batchDeferredLogs: seq[string] = @[]

      # The scheduler polls every ready item on each download tick. Parsing
      # every dependency's pkginfo on each poll flooded the log with repeated
      # "parsePkgInfo ran" lines and wasted I/O; parse each spec once per batch.
      var depNameCache = initTable[string, string]()
      proc depNameOf(dep: string): string =
        result = depNameCache.getOrDefault(dep)
        if result.len == 0:
          result = parsePkgInfo(dep).name
          depNameCache[dep] = result

      proc archivesReady(item: InstallWorkItem): bool =
        item.isGroup or fileExists(kpkgArchivesDir & "/system/" & kTarget &
            "/" & item.name & "-" & item.version & ".kpkg")

      proc depsSucceeded(item: InstallWorkItem): bool =
        for dep in item.deps:
          let depName = depNameOf(dep)
          if progressRows.hasKey(depName) and depName != item.name and
              not succeeded[progressRows[depName]]:
            return false
        return true

      proc compatibleWithRunning(item: InstallWorkItem): bool =
        for runningIdx in running:
          let other = installItems[runningIdx]
          if item.name in other.conflicts or other.name in item.conflicts or
              item.name in other.replaces or other.name in item.replaces:
            return false
        return true

      proc queueReady(ignoreDependencies = false): int =
        if batchFailed:
          return 0
        for idx, item in installItems:
          if inFlight >= workerCount:
            break
          if queued[idx] or succeeded[idx] or not archivesReady(item):
            continue
          if not ignoreDependencies and not depsSucceeded(item):
            continue
          if not compatibleWithRunning(item):
            continue
          # Snapshot before sending any work: workers must never mutate the
          # root before the batch's history and database backup are durable.
          if not batchStarted:
            batchState = beginBatchInstall(root)
            batchStarted = true
          var work = item
          work.idx = idx
          queued[idx] = true
          running.add(idx)
          inc inFlight
          progressUpdate(work.progressIndex, work.progressStart,
              detail = "installing")
          channelState.workChan.send(work)
          inc result

      proc pumpInstalls() =
        while channelState.resultChan.peek() > 0:
          let itemResult = channelState.resultChan.recv()
          batchDeferredLogs.add(itemResult.deferredLogs)
          dec inFlight
          let runningPos = running.find(itemResult.idx)
          if runningPos >= 0:
            running.delete(runningPos)
          if itemResult.ok:
            succeeded[itemResult.idx] = true
            inc completed
          else:
            batchFailed = true
            failureMessage = "installation failed for '" &
                installItems[itemResult.idx].name & "': " & itemResult.errorMsg
        discard queueReady()
        progressRender()

      # Complete downloads and validate the entire batch before queueing any
      # installation. Otherwise a missing binary can arrive after another
      # package ran hooks, leaving a recovery barrier despite file rollback.
      let downloadOk = downloadBatch(itemNames, binrepos, versions, kTarget,
          offline, forceDownloadPackages, forceDownload,
          ignoreDownloadErrors, combinedProgress = true,
          progressRows = progressRows, skipPackages = groupNames,
          renderUpdates = true)
      if not downloadOk:
        raise newException(IOError, "one or more package downloads failed")
      for item in installItems:
        if not archivesReady(item):
          raise newException(IOError,
              "download batch completed with missing archives: " & item.name)

      while inFlight > 0 or (completed < installItems.len and not batchFailed):
        pumpInstalls()
        if completed >= installItems.len and inFlight == 0:
          break
        if batchFailed:
          if inFlight == 0:
            break
        elif inFlight == 0:
          if not downloadOk:
            batchFailed = true
            failureMessage = "one or more package downloads failed"
            break
          # No ready package with every archive present means a dependency
          # cycle; preserve the previous cycle fallback without deadlocking.
          if queueReady(ignoreDependencies = true) == 0:
            batchFailed = true
            failureMessage = "download pipeline completed with missing archives"
            break
        if inFlight > 0:
          sleep(100)

      # Stop and join installers before committing or rolling back staged
      # filesystem/database transactions.
      closeInstallChannels(channelState, workers, startedWorkers)
      channelsOpen = false

      if not downloadOk and not batchFailed:
        batchFailed = true
        failureMessage = "one or more package downloads failed"
      if batchFailed:
        for idx in 0 ..< installItems.len:
          if succeeded[idx]:
            progressUpdate(idx, 100, finished = true, ok = false,
                detail = "rolled back")
        progressRender()
        progressFinish()
        progressClosed = true
        for line in batchDeferredLogs:
          stderr.writeLine(line)
        if batchDeferredLogs.len > 0:
          stderr.flushFile()
        raise newException(IOError, failureMessage)

      progressRender()
      progressFinish()
      progressClosed = true
      for line in batchDeferredLogs:
        stderr.writeLine(line)
      if batchDeferredLogs.len > 0:
        stderr.flushFile()
      batchSucceeded = true

when defined(kpkgInstallFailureTest):
  proc probeMissingInstallArchives*(packages: seq[string], root: string) =
    ## Exercise the real scheduler with no mirrors or cached archives.
    install_bin(packages, @[], root, offline = true,
        manualInstallList = packages, kTarget = "kpkg-missing-archive-test")

proc install*(promptPackages: seq[string], root = "/", yes: bool = false,
        no: bool = false, forceDownload = false, offline = false,
                downloadOnly = false, ignoreDownloadErrors = false,
                isUpgrade = false, target = "default",
                basePackage = false, exclude: seq[string] = @[],
                disableExcludes: bool = false): int =
  ## Install a package from a binary, from a repository or locally.
  ##
  ## Supports commit-based installation with syntax: package#commit
  ## When a commit hash is specified, the version at that commit is used
  ## to find the binary. If binary not found, suggests using kpkg build.

  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if root == "": "/" else: root)

  if promptPackages.len == 0:
    error("please enter a package name")
    quit(1)

  if not isAdmin():
    error("you have to be root for this action.")
    quit(1)

  # Importing the installer must not replace the caller's signal handler.
  # Its cleanup hook is only appropriate once an install was requested.
  setControlCHook(ctrlc)
  setDisableExcludes(disableExcludes)
  addCliExcludePatterns(exclude)

  var deps: seq[string]
  let init = getInit(root)

  var packages: seq[string]

  let fullRootPath = expandFilename(root)

  withInstallCommitContexts(promptPackages, commitCtxs):
    let hasCommit = hasAnyCommit(commitCtxs)

    for i in promptPackages:
      let pkgInfo = parsePkgInfo(i)
      let rawRepo = if pkgInfo.repo != "": pkgInfo.repo else: findPkgRepo(pkgInfo.name)
      let pkgRepo = lastPathPart(rawRepo)
      if isExcluded(pkgInfo.name, pkgRepo):
        if packageExists(pkgInfo.name, root):
          warn "skipping " & pkgInfo.name & ": excluded in kpkg.conf but already installed"
        else:
          fatal "cannot install " & pkgInfo.name & ": package is excluded"
          quit(1)
      packages = packages & pkgInfo.name
      if findPkgRepo(pkgInfo.name&"-"&init) != "":
        packages = packages & (pkgInfo.name&"-"&init)

    var commitForDeps = ""
    var commitRepoForDeps = ""
    var headCacheForDeps = initTable[string, runFile]()

    if hasCommit:
      for name, ctx in commitCtxs:
        if ctx.commit != "":
          commitForDeps = ctx.commit
          commitRepoForDeps = ctx.commitRepo
          headCacheForDeps = ctx.headRunfileCache
          break

    try:
      deps = dephandler(packages, root = root,
              commit = commitForDeps, commitRepo = commitRepoForDeps,
              headRunfileCache = headCacheForDeps)
    except CatchableError:
      error("Dependency detection failed")
      quit(1)

    printReplacesPrompt(deps, root, true)
    printReplacesPrompt(packages, root)

    let binrepos = getConfigValue("Repositories", "binRepos").split(" ")

    deps = deduplicate(deps&packages)

    var gD = getDependents(deps, root = root)
    if not isEmptyOrWhitespace(gD.join("")):
      deps = deps&gD

    # Excludes (kpkg.conf and -e) also cover what kpkg added on its own:
    # dependencies and dependents scheduled for reinstall.
    let ex = partitionExcluded(deps,
        proc(n: string): string = findPkgRepo(n),
        proc(n: string): bool = packageExists(n, root))
    for n in ex.skipped:
      info "skipping " & n & ": excluded, keeping the installed version"
    if ex.missing.len > 0:
      fatal "cannot install: required but excluded and not installed: " &
          ex.missing.join(", ")
    deps = ex.kept
    gD = gD.filterIt(it in deps)

    printPackagesPrompt(deps.join(" "), yes, no, dependents = gD, binary = true)

    var kTarget = target

    if target == "default":
      kTarget = kpkgTarget(root)

    if not (deps.len == 0 and deps == @[""]):
      install_bin(deps, binrepos, fullRootPath, offline,
              downloadOnly = downloadOnly, manualInstallList = promptPackages,
              kTarget = kTarget, forceDownload = forceDownload,
              ignoreDownloadErrors = ignoreDownloadErrors,
              basePackage = basePackage, commitContexts = commitCtxs)

    staleprocs.printStaleWarning()

    info("done")
    return 0
