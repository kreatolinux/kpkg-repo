import ../modules/transactions/barrier
import os
import sets
import tables
import strutils
import sequtils
import installcmd
import ../modules/sqlite
import ../../common/logging
import ../modules/config
import ../modules/lockfile
import ../modules/runparser
import ../modules/dephandler
import ../modules/commonTasks
import ../modules/commonPaths
import ../modules/gitutils
import ../modules/builder/main
import ../modules/builder/types
import ../modules/builder/cache
import ../modules/builder/sources
import ../modules/builder/context
import ../modules/builder/packager
import ../modules/builder/executor
import ../modules/builder/environment
import ../modules/builder/sandbox
import ../modules/builder/commitctx
import ../modules/builder/soname
import ../modules/telemetry/main as telemetry

proc formatCycleDisplay(cyclePath: seq[string]): string =
  ## Format cycle path for display (use <-> for 2-node cycles, -> for longer)
  if cyclePath.len <= 2:
    return cyclePath.join(" <-> ")
  else:
    return cyclePath.join(" -> ")

proc builderImpl(cfg: var BuildConfig): bool =
  ## Builds a package using the provided configuration.
  ##
  ## This is the main entry point for building a single package.
  ## It handles: path resolution, runfile parsing, cache checking,
  ## source downloading, environment setup, build execution, and packaging.

  # Building changes into kpkgSrcDir (and sometimes an extracted source
  # directory). Always leave callers in the directory from which they invoked
  # the builder. In particular, cache-hit and release cleanup remove
  # kpkgSrcDir; returning while it is still the process CWD makes the next
  # absolutePath/getCurrentDir call fail with ENOENT.
  let originalWorkingDir = getCurrentDir()
  defer: setCurrentDir(originalWorkingDir)

  debug "builder ran, package: '" & cfg.package & "', destdir: '" & cfg.destdir & "' root: '" & kpkgSrcDir & "', useCacheIfAvailable: '" & (
          $cfg.useCacheIfAvailable) & "'"

  # The default source root is the host even for an explicit native variant.
  if cfg.actualRoot == "default" and not isCrossTarget(cfg.target, "/"):
    cfg.actualRoot = "/"
  preliminaryChecks(cfg.target, cfg.actualRoot)

  # Resolve paths (repo, path, actualPackage)
  resolvePaths(cfg, cfg.customRepo)

  # Remove directories if they exist
  removeDir(kpkgBuildRoot)
  removeDir(kpkgSrcDir)

  cfg.arch = getArch(cfg.target)
  cfg.kTarget = getKtarget(cfg.target, cfg.destdir)

  initEnv(cfg.actualPackage, cfg.kTarget)

  # Enter into the source directory
  setCurrentDir(kpkgSrcDir)

  # Initialize build state (parse runfile)
  var state = initBuildState(cfg)

  # Load override config
  cfg.override = loadOverrideConfig(cfg.package)

  # Check cache and install from it if available
  if shouldInstallFromCache(cfg.toCacheConfig(), state.pkg):
    telemetry.setActiveSpanAttribute("package.cache_hit", "true")
    debug "Tarball (and the sum) already exists, going to install"
    if not cfg.skipHostInstall and cfg.destdir != "/" and
        cfg.target == "default":
      installPkg(cfg.repo, cfg.actualPackage, "/", state.pkg,
              cfg.manualInstallList,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = cacheArchivePath(cfg.actualPackage, state.pkg,
                  cfg.kTarget, cfg.isBootstrap))

    if not cfg.skipHostInstall and cfg.kTarget == kpkgTarget(cfg.destdir):
      installPkg(cfg.repo, cfg.actualPackage, cfg.destdir, state.pkg, cfg.manualInstallList,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = cacheArchivePath(cfg.actualPackage, state.pkg,
                  cfg.kTarget, cfg.isBootstrap))
    else:
      info "the package target doesn't match the one on '" & cfg.destdir & "', skipping installation"

    setCurrentDir(originalWorkingDir)
    cleanupAfterCacheInstall()
    return true

  debug "Tarball (and the sum) doesn't exist, going to continue"

  # Handle group packages
  if state.pkg.isGroup:
    debug "Package is a group package"
    installPkg(cfg.repo, cfg.actualPackage, cfg.destdir, state.pkg, cfg.manualInstallList,
            ignorePostInstall = cfg.ignorePostInstall,
            deferPostInstall = cfg.deferPostInstall)
    setCurrentDir(originalWorkingDir)
    removeDir(kpkgBuildRoot)
    removeDir(kpkgSrcDir)
    return true

  createDir(kpkgTempDir2)

  # Detect which build functions exist
  state.exists = detectBuildFunctions(state.pkg, cfg.actualPackage)

  # Download and extract sources
  sourceDownloader(state.pkg, cfg.actualPackage, kpkgSrcDir, cfg.path)

  # Set ownership and count folders
  (state.amountOfFolders, state.folder) = countAndFindSourceFolders(kpkgSrcDir)
  setSourceOwnership(kpkgSrcDir)

  # Resolve source directory (handle autocd)
  cfg.srcDir = resolveSourceDir(state.pkg, kpkgSrcDir, state.folder,
      state.amountOfFolders)

  # Initialize environment variables
  state.envVars = initBuildEnvVars(cfg)

  # Initialize Run3 context
  let ctx = initBuildContext(cfg, state)

  # Execute build steps
  executeBuildSteps(ctx, state, cfg.actualPackage, cfg.tests)

  # SONAME change detection: check if this package installs .so files with
  # different version suffixes than what's currently installed. If so, queue
  # consumers for rebuild.
  # noSandbox bootstrap builds a fresh root: the topo order already places
  # consumers after providers, and the SONAME consumer mechanism (meant for
  # upgrades on a live system) would requeue big packages like gcc for every
  # library whose soname differs from nothing.
  if not cfg.noSandbox and not cfg.dontInstall and not cfg.isBootstrap:
    if hasSonameChanged(kpkgBuildRoot, cfg.actualPackage, cfg.actualRoot):
      cfg.sonameChanged = true
      # Save CWD and change to repo root so getRuntimeDependents' dirExists check works
      let oldCwd = getCurrentDir()
      setCurrentDir(cfg.repo)
      for consumer in getRuntimeDependents(@[cfg.actualPackage],
          cfg.actualRoot):
        if consumer notin cfg.consumersToRebuild:
          cfg.consumersToRebuild.add(consumer)
      for consumer in getElfRuntimeDependents(@[cfg.actualPackage],
          cfg.actualRoot):
        if consumer notin cfg.consumersToRebuild:
          cfg.consumersToRebuild.add(consumer)
      cfg.consumersToRebuild = orderSonameConsumers(cfg.consumersToRebuild,
          proc(pkg: string): seq[string] =
        try:
          return parseRunfile(findPkgRepo(pkg) & "/" & pkg).deps
        except CatchableError:
          debug "could not resolve runtime deps for consumer " & pkg
          return @[])
      setCurrentDir(oldCwd)
      if cfg.consumersToRebuild.len > 0:
        warn "SONAME change detected for " & cfg.actualPackage &
             ", queuing rebuild of: " & cfg.consumersToRebuild.join(", ")

  # Phase 1: Create temp tarball WITHOUT dependency resolution.
  # Written to a temp path so the archives directory never contains an
  # incomplete tarball (without dependency metadata).
  let tempTarball = kpkgTempDir1 & "/" & cfg.actualPackage & "-" &
          state.pkg.versionString & ".kpkg.tmp"

  try:
    discard createPackage(cfg.actualPackage, state.pkg, cfg.kTarget,
            resolveDeps = false, tarballPath = tempTarball)

    # Install to host root (unless skipHostInstall is set, e.g. for SONAME
    # packages whose host install is deferred until consumers are rebuilt).
    if not cfg.skipHostInstall and cfg.destdir != "/" and not packageExists(
            cfg.actualPackage) and (not cfg.dontInstall) and cfg.target == "default":
      installPkg(cfg.repo, cfg.actualPackage, "/", state.pkg, cfg.manualInstallList,
              isUpgrade = cfg.isUpgrade,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = tempTarball)

    if not cfg.skipHostInstall and (not cfg.dontInstall) and (cfg.kTarget ==
        kpkgTarget(cfg.destdir)):
      installPkg(cfg.repo, cfg.actualPackage, cfg.destdir, state.pkg, cfg.manualInstallList,
              isUpgrade = cfg.isUpgrade,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = tempTarball)
    else:
      info "the package target doesn't match the one on '" & cfg.destdir & "', skipping installation"

    # Phase 3: Finalize the tarball with resolved dependencies, written
    # directly to the archives directory. If this fails, the archives
    # directory stays clean (no partial tarball).
    let finalTarball = cacheArchivePath(cfg.actualPackage, state.pkg,
            cfg.kTarget, cfg.isBootstrap)
    createDir(parentDir(finalTarball))
    finalizePackageDeps(cfg.actualPackage, state.pkg, cfg.kTarget,
            outputPath = finalTarball, useBootstrapDeps = cfg.isBootstrap)

  finally:
    removeFile(tempTarball)


  when defined(release):
    setCurrentDir(originalWorkingDir)
    removeDir(kpkgSrcDir)
    removeDir(kpkgTempDir2)

  return false

proc builder*(cfg: var BuildConfig): bool =
  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if cfg.destdir == "": "/" else: cfg.destdir)

  telemetry.withSpan("kpkg.package.build", {
    "package.name": cfg.package,
    "package.bootstrap": $cfg.isBootstrap,
    "package.cache_hit": "false"
  }.toTable):
    return builderImpl(cfg)


# Wrapper procs for sandbox callbacks
proc builderWrapper(cfg: var BuildConfig): bool =
  ## Wrapper for builder() to match BuilderProc signature.
  builder(cfg)

proc installPkgWrapper(cfg: InstallConfig) =
  ## Wrapper for installPkg() to match InstallPkgProc signature.
  debug "installPkgWrapper: kTarget='" & cfg.kTarget & "' root='" & cfg.root &
      "' package='" & cfg.package & "'"
  installPkg(cfg.repo, cfg.package, cfg.root,
             isUpgrade = cfg.isUpgrade, kTarget = cfg.kTarget,
             manualInstallList = cfg.manualInstallList,
             disablePkgInfo = cfg.disablePkgInfo,
             ignorePostInstall = cfg.ignorePostInstall,
             deferPostInstall = cfg.deferPostInstall)


proc build*(no = false, yes = false, root = "/",
    packages: seq[string],
            useCacheIfAvailable = true, forceInstallAll = false,
                    dontInstall = false, tests = true,
                            ignorePostInstall = false, isInstallDir = false,
                            isUpgrade = false, target = "default",
                            bootstrap = false, noSandbox = false,
                            deferPostInstall = false,
                            bootstrapRootfs = false,
                            binCache = false,
                            sandboxTarget = "",
                            exclude: seq[string] = @[]): int =
  ## Build and install packages.
  ##
  ## Use package#commit to build a specific repository revision.
  ## The repository is restored to its original revision afterwards.
  ##
  ## deferPostInstall is for repair: it skips postinstall hooks and sandbox
  ## CA setup. Rebuild normally after repair to initialize the sandbox.
  ## Reinstall affected packages to run hooks skipped outside the sandbox.
  ##
  ## noSandbox builds directly in root without bwrap or overlays.
  ## Use it inside a chroot or seed image that provides its own isolation.
  ##
  ## Circular dependencies with bootstrap dependencies (bsdeps) are
  ## bootstrapped automatically.
  ##
  ## bootstrapRootfs first builds the requested native target variant from a
  ## host-target sandbox, then recreates the sandbox from those local archives.
  ##
  ## binCache makes dependencies prefer a published binary from the binary
  ## repositories over a source build. Binaries are fetched into the local
  ## archive cache only when the exact version-release is available; anything
  ## missing (including the requested package itself) is still built from
  ## source.

  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if root == "": "/" else: root)

  if packages.len == 0:
    error("please enter a package name")
    quit(1)

  if deferPostInstall:
    warn "postinstall hooks deferred for repair; reinstall affected packages without deferPostInstall after repair"

  let fullRootPath = expandFilename(root)
  let init = targetInit(target, fullRootPath)
  let ignoreInit = false

  if bootstrapRootfs:
    if target == "default":
      error("--bootstrapRootfs requires an explicit target")
      return 1
    if isCrossTarget(target, fullRootPath):
      error("--bootstrapRootfs currently supports only native target variants")
      return 1
    if noSandbox:
      error("--bootstrapRootfs requires the build sandbox")
      return 1

    let bootstrapPackages = targetSandboxPackages(target, fullRootPath)
    if bootstrapPackages.len > 0:
      info "Bootstrapping rootfs target packages from source: " &
          bootstrapPackages.join(", ")
      let bootstrapResult = build(no = no, yes = yes, root = root,
        packages = bootstrapPackages, useCacheIfAvailable = useCacheIfAvailable,
        # The complete target initialization closure must exist locally before
        # the target sandbox can be provisioned.
        forceInstallAll = true, dontInstall = true, tests = tests,
        ignorePostInstall = ignorePostInstall,
        deferPostInstall = deferPostInstall, isInstallDir = false,
        isUpgrade = false, target = target, bootstrap = false,
        noSandbox = false, bootstrapRootfs = false,
        sandboxTarget = "default")
      if bootstrapResult != 0:
        return bootstrapResult

      # The bootstrap phase deliberately used the host profile. Recreate the
      # environment so normal setup installs the target archives built above.
      removeDir(kpkgEnvPath)
    else:
      debug "bootstrapRootfs: target sandbox profile is already native"

  withCommitContext(packages):
    # Build dependency context for resolveBuildOrder
    var depCtx = dependencyContext(
      root: fullRootPath,
      isBuild: true,
      useBootstrap: bootstrap,
      ignoreInit: ignoreInit,
      ignoreCircularDeps: false,
      forceInstallAll: forceInstallAll,
      useCacheIfAvailable: useCacheIfAvailable,
      init: init,
      commit: commitCtx.commit,
      commitRepo: commitCtx.commitRepo,
      headRunfileCache: commitCtx.headRunfileCache
    )

    # Resolve complete build order (handles dependents, graph rebuild, bootstrap reordering)
    var (deps, depGraph, allDependents, sortResult) = resolveBuildOrder(
      packages, depCtx, bootstrap, isInstallDir
    )

    # Resolve every bootstrap-capable cycle. The graph reports one cycle at a
    # time, so a successful bootstrap round can expose a separate cycle that
    # also needs a seed before the final build order is acyclic.
    if sortResult.hasCycle and bootstrap:
      fatal "Bootstrap dependency graph is still circular: " &
            formatCycleDisplay(sortResult.cyclePath)
      return 1

    var bootstrapSatisfied = initHashSet[string]()
    var bootstrapSeeds: seq[string] = @[]
    var bootstrapSatisfiedEdges = initHashSet[DependencyEdge]()
    while sortResult.hasCycle:
      let cyclePath = sortResult.cyclePath
      let pkgsWithBsdeps = getPackagesWithBsdeps(depGraph, cyclePath)
      if pkgsWithBsdeps.len == 0:
        fatal "Circular dependency detected: " & formatCycleDisplay(cyclePath) &
              ". Use bootstrap dependencies (bsdeps) to break the cycle."
        return 1

      warn "Circular dependency detected: " & formatCycleDisplay(cyclePath) &
           ". Kpkg will attempt to bootstrap and install its cycle seed."

      var madeProgress = false
      for pkg in pkgsWithBsdeps:
        if pkg in bootstrapSatisfied:
          continue
        let bootstrapSpec = if isInstallDir:
          depGraph.nodes[pkg].repo / pkg
        else:
          pkg
        let bootstrapResult = build(
          no = no, yes = yes, root = root,
          packages = @[bootstrapSpec],
          useCacheIfAvailable = useCacheIfAvailable,
          forceInstallAll = forceInstallAll,
          # The seed must be installed into the build root even when the final
          # requested package is build-only.
          dontInstall = false,
          tests = tests,
          ignorePostInstall = ignorePostInstall,
          deferPostInstall = deferPostInstall,
          isInstallDir = isInstallDir,
          isUpgrade = isUpgrade,
          target = target,
          bootstrap = true,
          noSandbox = noSandbox,
          sandboxTarget = sandboxTarget
        )
        if bootstrapResult != 0:
          fatal "Bootstrap build failed for '" & pkg & "'"
          return bootstrapResult
        bootstrapSatisfied.incl(pkg)
        bootstrapSeeds.add(bootstrapSpec)
        madeProgress = true

      let cycleEdges = getBootstrapEdgesForCycle(cyclePath,
              bootstrapSatisfied)
      for edge in cycleEdges:
        if edge notin bootstrapSatisfiedEdges:
          bootstrapSatisfiedEdges.incl(edge)
          madeProgress = true

      if not madeProgress:
        fatal "Circular dependency bootstrap made no progress: " &
              formatCycleDisplay(cyclePath)
        return 1

      info "Bootstrap build completed, resolving remaining dependency cycles..."
      depCtx.useBootstrap = false
      depCtx.bootstrapSatisfied = bootstrapSatisfied
      depCtx.bootstrapSatisfiedEdges = bootstrapSatisfiedEdges
      let finalPackages = finalRetryPackages(packages, bootstrapSeeds)
      (deps, depGraph, allDependents, sortResult) = resolveBuildOrder(
        finalPackages, depCtx, false, isInstallDir
      )

    # Build package list with init variants
    var p: seq[string]
    for currentPackage in packages:
      p = p & currentPackage
      if findPkgRepo(currentPackage & "-" & init) != "":
        p = p & (currentPackage & "-" & init)

    # Excludes (kpkg.conf and -e) apply to dependents kpkg schedules for a
    # rebuild on its own. Requested packages and their build dependencies are
    # left alone: dropping a dependency would break the build order.
    if exclude.len > 0: addCliExcludePatterns(exclude)
    block:
      # Never drop a package the user asked for, even when it is also a
      # dependent of another requested package (gnome-desktop of
      # gsettings-desktop-schemas, say).
      var requested: seq[string]
      for pkg in packages: requested.add(lastPathPart(parsePkgInfo(pkg).name))
      let ex = partitionExcluded(allDependents.filterIt(it notin requested),
          proc(n: string): string = findPkgRepo(n),
          proc(n: string): bool = packageExists(n, fullRootPath))
      let dropped = ex.skipped & ex.missing
      for n in dropped:
        info "not rebuilding " & n & ": excluded"
      if dropped.len > 0:
        deps = deps.filterIt(it notin dropped)
        allDependents = allDependents.filterIt(it notin dropped)

    # UI prompts
    printReplacesPrompt(deps, fullRootPath, true)
    printReplacesPrompt(p, fullRootPath, isInstallDir = isInstallDir)

    if isInstallDir:
      printPackagesPrompt(deps.join(" "), yes, no, packages,
              dependents = allDependents)
    else:
      printPackagesPrompt(deps.join(" "), yes, no, @[""],
              dependents = allDependents)

    # Normalize package names (strip repo prefix if not isInstallDir)
    let pBackup = p
    p = @[]
    if not isInstallDir:
      for i in pBackup:
        let packageSplit = parsePkgInfo(i)
        p = p & packageSplit.name

    # Build package paths table for isInstallDir mode
    var pkgPaths = initTable[string, string]()
    if isInstallDir:
      for pkg in packages:
        pkgPaths[lastPathPart(pkg)] = absolutePath(pkg)

    # Get build dependents for cache invalidation
    let gD = getDependents(deps)

    # Create sandbox configuration
    var sandboxCfg = initSandboxConfig(
      fullRootPath = fullRootPath,
      target = target,
      bootstrap = bootstrap,
      forceInstallAll = forceInstallAll,
      isInstallDir = isInstallDir,
      ignoreInit = ignoreInit,
      dontInstall = dontInstall,
      useCacheIfAvailable = useCacheIfAvailable,
      binCache = binCache,
      tests = tests,
      isUpgrade = isUpgrade,
      ignorePostInstall = ignorePostInstall,
      deferPostInstall = deferPostInstall,
      manualInstallList = p,
      ignoreUseCacheIfAvailable = gD,
      root = root,
      pkgPaths = pkgPaths,
      commit = commitCtx.commit,
      commitRepo = commitCtx.commitRepo,
      headRunfileCache = commitCtx.headRunfileCache,
      noSandbox = noSandbox,
      sandboxTarget = sandboxTarget
    )

    # Build all packages in sandbox
    result = buildAllPackagesInSandbox(deps, depGraph, sandboxCfg,
            builderWrapper, installPkgWrapper)
