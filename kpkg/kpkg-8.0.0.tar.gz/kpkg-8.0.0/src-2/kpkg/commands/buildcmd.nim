import ../modules/transactions/barrier
import os
import sets
import tables
import strutils
import sequtils
import times
import installcmd
import ../modules/sqlite
import ../../common/logging
import ../modules/config
import ../modules/lockfile
import ../modules/runparser
import ../modules/arch
import ../modules/dephandler
import ../modules/commonTasks
import ../modules/commonPaths
import ../modules/gitutils
import ../modules/builder/main
import ../modules/builder/types
import ../modules/builder/cache
import ../modules/builder/sources
import ../modules/builder/context
import ../modules/builder/packager
import ../modules/builder/executor
import ../modules/builder/environment
import ../modules/builder/sandbox
import ../modules/builder/commitctx
import ../modules/builder/soname
import ../modules/builder/pendingInstalls
import ../modules/telemetry/main as telemetry

proc formatCycleDisplay(cyclePath: seq[string]): string =
  ## Format cycle path for display (use <-> for 2-node cycles, -> for longer)
  if cyclePath.len <= 2:
    return cyclePath.join(" <-> ")
  else:
    return cyclePath.join(" -> ")

proc pendingHooks(deferPostInstall: bool,
        rebuildable: proc(package: string): bool = nil): PendingHooks =
  ## Real operations the deferred install completion needs.
  PendingHooks(
    installedVersion: proc(package, root: string): string =
      if packageExists(package, root): getPackage(package, root).version
      else: "",
    recipePresent: proc(package: string): bool = findPkgRepo(package) != "",
    rebuildable: rebuildable,
    archiveUsable: proc(entry: PendingInstall): bool =
      return archiveUsable(entry.archive),
    installPackage: proc(entry: PendingInstall): bool =
      let repo = findPkgRepo(entry.package)
      if repo.len == 0:
        error "cannot install deferred " & entry.package & ": no recipe"
        return false
      # Only an existing install takes the upgrade hooks; a deferred install
      # into a root that never had the package is a fresh install.
      let upgrade = packageExists(entry.package, entry.root)
      try:
        # keepTransaction raises instead of exiting: an exit in the middle of
        # an install leaves a history marker that refuses every later run.
        installPkg(repo, entry.package, entry.root, manualInstallList = @[],
            kTarget = entry.kTarget, isUpgrade = upgrade,
            version = entry.version, tarballPath = entry.archive,
            ignorePostInstall = true, deferPostInstall = deferPostInstall,
            targetArch = archNameFromTarget(entry.kTarget),
            keepTransaction = true)
        return true
      except CatchableError:
        error "could not complete deferred install of " & entry.package & ": " &
            getCurrentExceptionMsg()
        return false,
    affectedConsumers: proc(entry: PendingInstall): seq[string] =
      # Packages that still need a SONAME the deferred build drops must be
      # rebuilt against it, or they stop working once it is installed. The scan
      # starts from the record and the installed packages that depend on the
      # provider, so it reads only those instead of the whole root.
      if entry.sonames.len == 0:
        return @[]
      var candidates = entry.consumers
      try:
        for package in getListPackages(entry.root):
          if package == entry.package or package in candidates:
            continue
          if entry.package in getPackage(package, entry.root).deps.split("!!k!!"):
            candidates.add(package)
      except CatchableError:
        debug "could not list the installed dependents of " & entry.package
      return runtimeDependentsAmong(candidates, entry.root, entry.sonames)
  )

proc recordDeferredInstall(cfg: BuildConfig, pkg: runFile, archive: string) =
  ## Persist a host install that the SONAME consumer rebuild defers.
  let entry = PendingInstall(package: cfg.actualPackage,
      version: pkg.versionString, kTarget: cfg.kTarget,
      root: canonicalRoot(cfg.destdir),
      archive: archive, reason: pendingInstallsReasonSoname,
      sonames: cfg.removedSonames, consumers: cfg.consumersToRebuild,
      recordedAt: epochTime())
  try:
    upsertPendingInstall(entry)
    warn "install of " & entry.package & " " & entry.version & " deferred until " &
        "its consumers are rebuilt; the next kpkg run completes it if this " &
        "one stops first"
  except CatchableError:
    error "could not record the deferred install of " & entry.package & ": " &
        getCurrentExceptionMsg()

proc reportDeferredPlan(plan: PendingPlan) =
  ## Say what is still deferred after a plan or completion step.
  let summary = pendingSummary(plan)
  if summary.len > 0:
    warn "deferred installs still pending: " & summary

proc builderImpl(cfg: var BuildConfig): bool =
  ## Builds a package using the provided configuration.
  ##
  ## This is the main entry point for building a single package.
  ## It handles: path resolution, runfile parsing, cache checking,
  ## source downloading, environment setup, build execution, and packaging.

  # Building changes into kpkgSrcDir (and sometimes an extracted source
  # directory). Always leave callers in the directory from which they invoked
  # the builder. In particular, cache-hit and release cleanup remove
  # kpkgSrcDir; returning while it is still the process CWD makes the next
  # absolutePath/getCurrentDir call fail with ENOENT.
  let originalWorkingDir = getCurrentDir()
  defer: setCurrentDir(originalWorkingDir)

  debug "builder ran, package: '" & cfg.package & "', destdir: '" & cfg.destdir & "' root: '" & kpkgSrcDir & "', useCacheIfAvailable: '" & (
          $cfg.useCacheIfAvailable) & "'"

  # The default source root is the host even for an explicit native variant.
  if cfg.actualRoot == "default" and not isCrossTarget(cfg.target, "/"):
    cfg.actualRoot = "/"
  preliminaryChecks(cfg.target, cfg.actualRoot)

  # Resolve paths (repo, path, actualPackage)
  resolvePaths(cfg, cfg.customRepo)

  # Remove directories if they exist
  removeDir(kpkgBuildRoot)
  removeDir(kpkgSrcDir)

  cfg.arch = getArch(cfg.target)
  cfg.kTarget = getKtarget(cfg.target, cfg.destdir)

  initEnv(cfg.actualPackage, cfg.kTarget)

  # Enter into the source directory
  setCurrentDir(kpkgSrcDir)

  # Initialize build state (parse runfile)
  var state = initBuildState(cfg)

  # Load override config
  cfg.override = loadOverrideConfig(cfg.package)

  # Check cache and install from it if available
  if shouldInstallFromCache(cfg.toCacheConfig(), state.pkg):
    telemetry.setActiveSpanAttribute("package.cache_hit", "true")
    debug "Tarball (and the sum) already exists, going to install"
    if not cfg.skipHostInstall and cfg.destdir != "/" and
        cfg.target == "default":
      installPkg(cfg.repo, cfg.actualPackage, "/", state.pkg,
              cfg.manualInstallList,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = cacheArchivePath(cfg.actualPackage, state.pkg,
                  cfg.kTarget, cfg.isBootstrap))

    if not cfg.skipHostInstall and cfg.kTarget == kpkgTarget(cfg.destdir):
      installPkg(cfg.repo, cfg.actualPackage, cfg.destdir, state.pkg, cfg.manualInstallList,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = cacheArchivePath(cfg.actualPackage, state.pkg,
                  cfg.kTarget, cfg.isBootstrap))
    else:
      info "the package target doesn't match the one on '" & cfg.destdir & "', skipping installation"

    setCurrentDir(originalWorkingDir)
    cleanupAfterCacheInstall()
    return true

  debug "Tarball (and the sum) doesn't exist, going to continue"

  # Handle group packages
  if state.pkg.isGroup:
    debug "Package is a group package"
    installPkg(cfg.repo, cfg.actualPackage, cfg.destdir, state.pkg, cfg.manualInstallList,
            ignorePostInstall = cfg.ignorePostInstall,
            deferPostInstall = cfg.deferPostInstall)
    setCurrentDir(originalWorkingDir)
    removeDir(kpkgBuildRoot)
    removeDir(kpkgSrcDir)
    return true

  createDir(kpkgTempDir2)

  # Detect which build functions exist
  state.exists = detectBuildFunctions(state.pkg, cfg.actualPackage)

  # Download and extract sources
  sourceDownloader(state.pkg, cfg.actualPackage, kpkgSrcDir, cfg.path)

  # Set ownership and count folders
  (state.amountOfFolders, state.folder) = countAndFindSourceFolders(kpkgSrcDir)
  setSourceOwnership(kpkgSrcDir)

  # Resolve source directory (handle autocd)
  cfg.srcDir = resolveSourceDir(state.pkg, kpkgSrcDir, state.folder,
      state.amountOfFolders)

  # Initialize environment variables
  state.envVars = initBuildEnvVars(cfg)

  # Initialize Run3 context
  let ctx = initBuildContext(cfg, state)

  # Execute build steps
  executeBuildSteps(ctx, state, cfg.actualPackage, cfg.tests)

  # SONAME change detection: check if this package installs .so files with
  # different version suffixes than what's currently installed. If so, queue
  # consumers for rebuild.
  # noSandbox bootstrap builds a fresh root: the topo order already places
  # consumers after providers, and the SONAME consumer mechanism (meant for
  # upgrades on a live system) would requeue big packages like gcc for every
  # library whose soname differs from nothing.
  if not cfg.noSandbox and not cfg.dontInstall and not cfg.isBootstrap:
    let removedSonames = getRemovedSonames(kpkgBuildRoot, cfg.actualPackage,
        cfg.actualRoot)
    if removedSonames.len > 0:
      cfg.sonameChanged = true
      cfg.removedSonames = removedSonames
      # Save CWD and change to repo root so getRuntimeDependents' dirExists check works
      let oldCwd = getCurrentDir()
      setCurrentDir(cfg.repo)
      for consumer in getRuntimeDependents(@[cfg.actualPackage],
          cfg.actualRoot):
        if consumer notin cfg.consumersToRebuild:
          cfg.consumersToRebuild.add(consumer)
      for consumer in getElfRuntimeDependents(@[cfg.actualPackage],
          cfg.actualRoot, removedSonames):
        if consumer notin cfg.consumersToRebuild:
          cfg.consumersToRebuild.add(consumer)
      cfg.consumersToRebuild = orderSonameConsumers(cfg.consumersToRebuild,
          proc(pkg: string): seq[string] =
        try:
          return parseRunfile(findPkgRepo(pkg) & "/" & pkg).deps
        except CatchableError:
          debug "could not resolve runtime deps for consumer " & pkg
          return @[])
      setCurrentDir(oldCwd)
      if cfg.consumersToRebuild.len > 0:
        warn "SONAME change detected for " & cfg.actualPackage &
             ", queuing rebuild of: " & cfg.consumersToRebuild.join(", ")

  # Phase 1: Create temp tarball WITHOUT dependency resolution.
  # Written to a temp path so the archives directory never contains an
  # incomplete tarball (without dependency metadata).
  let tempTarball = kpkgTempDir1 & "/" & cfg.actualPackage & "-" &
          state.pkg.versionString & ".kpkg.tmp"

  try:
    discard createPackage(cfg.actualPackage, state.pkg, cfg.kTarget,
            resolveDeps = false, tarballPath = tempTarball)

    # Install to host root (unless skipHostInstall is set, e.g. for SONAME
    # packages whose host install is deferred until consumers are rebuilt).
    if not cfg.skipHostInstall and cfg.destdir != "/" and not packageExists(
            cfg.actualPackage) and (not cfg.dontInstall) and cfg.target == "default":
      installPkg(cfg.repo, cfg.actualPackage, "/", state.pkg, cfg.manualInstallList,
              isUpgrade = cfg.isUpgrade,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = tempTarball)

    if not cfg.skipHostInstall and (not cfg.dontInstall) and (cfg.kTarget ==
        kpkgTarget(cfg.destdir)):
      installPkg(cfg.repo, cfg.actualPackage, cfg.destdir, state.pkg, cfg.manualInstallList,
              isUpgrade = cfg.isUpgrade,
              ignorePostInstall = cfg.ignorePostInstall,
              deferPostInstall = cfg.deferPostInstall,
              tarballPath = tempTarball)
    else:
      info "the package target doesn't match the one on '" & cfg.destdir & "', skipping installation"

    # Phase 3: Finalize the tarball with resolved dependencies, written
    # directly to the archives directory. If this fails, the archives
    # directory stays clean (no partial tarball).
    let finalTarball = cacheArchivePath(cfg.actualPackage, state.pkg,
            cfg.kTarget, cfg.isBootstrap)
    createDir(parentDir(finalTarball))
    finalizePackageDeps(cfg.actualPackage, state.pkg, cfg.kTarget,
            outputPath = finalTarball, useBootstrapDeps = cfg.isBootstrap)

    # The consumer rebuild holds this install back, so it is the one install a
    # stopped run loses. Record it while the archive exists.
    if cfg.sonameChanged and cfg.skipHostInstall and not cfg.dontInstall and
        cfg.kTarget == kpkgTarget(cfg.destdir):
      recordDeferredInstall(cfg, state.pkg, finalTarball)

  finally:
    removeFile(tempTarball)


  when defined(release):
    setCurrentDir(originalWorkingDir)
    removeDir(kpkgSrcDir)
    removeDir(kpkgTempDir2)

  return false

proc builder*(cfg: var BuildConfig): bool =
  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if cfg.destdir == "": "/" else: cfg.destdir)

  telemetry.withSpan("kpkg.package.build", {
    "package.name": cfg.package,
    "package.bootstrap": $cfg.isBootstrap,
    "package.cache_hit": "false"
  }.toTable):
    return builderImpl(cfg)


# Wrapper procs for sandbox callbacks
proc builderWrapper(cfg: var BuildConfig): bool =
  ## Wrapper for builder() to match BuilderProc signature.
  builder(cfg)

proc installPkgWrapper(cfg: InstallConfig) =
  ## Wrapper for installPkg() to match InstallPkgProc signature.
  debug "installPkgWrapper: kTarget='" & cfg.kTarget & "' root='" & cfg.root &
      "' package='" & cfg.package & "'"
  installPkg(cfg.repo, cfg.package, cfg.root,
             isUpgrade = cfg.isUpgrade, kTarget = cfg.kTarget,
             manualInstallList = cfg.manualInstallList,
             disablePkgInfo = cfg.disablePkgInfo,
             ignorePostInstall = cfg.ignorePostInstall,
             deferPostInstall = cfg.deferPostInstall,
             targetArch = cfg.targetArch)


proc build*(no = false, yes = false, root = "/",
    packages: seq[string],
            useCacheIfAvailable = true, forceInstallAll = false,
                    dontInstall = false, tests = true,
                            ignorePostInstall = false, isInstallDir = false,
                            isUpgrade = false, target = "default",
                            bootstrap = false, noSandbox = false,
                            deferPostInstall = false,
                            bootstrapRootfs = false,
                            binCache = false,
                            sandboxTarget = "",
                            exclude: seq[string] = @[]): int =
  ## Build and install packages.
  ##
  ## Use package#commit to build a specific repository revision.
  ## The repository is restored to its original revision afterwards.
  ##
  ## deferPostInstall is for repair: it skips postinstall hooks and sandbox
  ## CA setup. Rebuild normally after repair to initialize the sandbox.
  ## Reinstall affected packages to run hooks skipped outside the sandbox.
  ##
  ## noSandbox builds directly in root without bwrap or overlays.
  ## Use it inside a chroot or seed image that provides its own isolation.
  ##
  ## Circular dependencies with bootstrap dependencies (bsdeps) are
  ## bootstrapped automatically.
  ##
  ## bootstrapRootfs first builds the requested native target variant from a
  ## host-target sandbox, then recreates the sandbox from those local archives.
  ##
  ## binCache makes dependencies prefer a published binary from the binary
  ## repositories over a source build. Binaries are fetched into the local
  ## archive cache only when the exact version-release is available; anything
  ## missing (including the requested package itself) is still built from
  ## source.

  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if root == "": "/" else: root)

  if packages.len == 0:
    error("please enter a package name")
    quit(1)

  # What this run builds: the request plus the rebuilds a completed deferred
  # install needs.
  var requestedPackages = packages

  if deferPostInstall:
    warn "postinstall hooks deferred for repair; reinstall affected packages without deferPostInstall after repair"

  let fullRootPath = expandFilename(root)
  let init = targetInit(target, fullRootPath)
  let ignoreInit = false

  # Exclude patterns must be known before the plan: a consumer this run is not
  # allowed to rebuild holds the provider.
  if exclude.len > 0:
    addCliExcludePatterns(exclude)
  let consumerRebuildable = proc(package: string): bool =
    ## Whether this run may rebuild an installed consumer.
    let repo = findPkgRepo(package)
    return repo.len > 0 and not isExcluded(package, lastPathPart(repo))

  # A previous run can have built a provider and stopped before installing it.
  # Plan that first so this run rebuilds whatever still needs the removed
  # SONAMEs. Planning also drops settled records from the store; the install
  # itself happens after the package prompt, so declining changes no root.
  var deferredPlan: PendingPlan
  let deferredHooks = pendingHooks(deferPostInstall, consumerRebuildable)
  if not bootstrap:
    try:
      deferredPlan = planPendingInstalls(fullRootPath, deferredHooks,
          allowInstall = not dontInstall)
    except CatchableError:
      warn "could not read the deferred install record: " &
          getCurrentExceptionMsg()
    reportDeferredPlan(deferredPlan)
    if deferredPlan.toInstall.len > 0:
      var completing: seq[string]
      for planned in deferredPlan.toInstall:
        completing.add(planned.entry.package & " " & planned.entry.version)
        info "deferred install to complete after the package prompt: " &
            planned.entry.package & " " & planned.entry.version & " into " &
            planned.entry.root
      if deferredPlan.rebuild.len > 0:
        warn "installing " & completing.join(", ") & " before the rebuilds " &
            "replaces libraries these packages still need until this run " &
            "rebuilds them: " & deferredPlan.rebuild.join(", ")
    if deferredPlan.rebuild.len > 0:
      warn "rebuilding packages that need the removed SONAMEs: " &
          deferredPlan.rebuild.join(", ")

  if bootstrapRootfs:
    if target == "default":
      error("--bootstrapRootfs requires an explicit target")
      return 1
    if isCrossTarget(target, fullRootPath):
      error("--bootstrapRootfs currently supports only native target variants")
      return 1
    if noSandbox:
      error("--bootstrapRootfs requires the build sandbox")
      return 1

    let bootstrapPackages = targetSandboxPackages(target, fullRootPath)
    if bootstrapPackages.len > 0:
      info "Bootstrapping rootfs target packages from source: " &
          bootstrapPackages.join(", ")
      let bootstrapResult = build(no = no, yes = yes, root = root,
        packages = bootstrapPackages, useCacheIfAvailable = useCacheIfAvailable,
        # The complete target initialization closure must exist locally before
        # the target sandbox can be provisioned.
        forceInstallAll = true, dontInstall = true, tests = tests,
        ignorePostInstall = ignorePostInstall,
        deferPostInstall = deferPostInstall, isInstallDir = false,
        isUpgrade = false, target = target, bootstrap = false,
        noSandbox = false, bootstrapRootfs = false,
        sandboxTarget = "default")
      if bootstrapResult != 0:
        return bootstrapResult

      # The bootstrap phase deliberately used the host profile. Recreate the
      # environment so normal setup installs the target archives built above.
      removeDir(kpkgEnvPath)
    else:
      debug "bootstrapRootfs: target sandbox profile is already native"

  # The rebuilds a completed deferred install needs are part of this request:
  # without them the new provider and the installed consumers disagree.
  var forcedRebuilds: seq[string]
  if deferredPlan.rebuild.len > 0 and not bootstrap and not isInstallDir:
    var requestedNames: seq[string]
    for pkg in requestedPackages:
      requestedNames.add(lastPathPart(parsePkgInfo(pkg).name))
    for consumer in deferredPlan.rebuild:
      if consumer in requestedNames:
        continue
      if not consumerRebuildable(consumer):
        warn "cannot rebuild " & consumer & (if findPkgRepo(consumer) == "":
            ": no recipe in the repositories" else: ": excluded")
        continue
      requestedPackages.add(consumer)
      requestedNames.add(consumer)
      forcedRebuilds.add(consumer)

  withCommitContext(requestedPackages):
    # Build dependency context for resolveBuildOrder
    var depCtx = dependencyContext(
      root: fullRootPath,
      isBuild: true,
      useBootstrap: bootstrap,
      ignoreInit: ignoreInit,
      ignoreCircularDeps: false,
      forceInstallAll: forceInstallAll,
      useCacheIfAvailable: useCacheIfAvailable,
      init: init,
      commit: commitCtx.commit,
      commitRepo: commitCtx.commitRepo,
      headRunfileCache: commitCtx.headRunfileCache,
      targetArch: archNameFromTarget(target)
    )

    # Resolve complete build order (handles dependents, graph rebuild, bootstrap reordering)
    var (deps, depGraph, allDependents, sortResult) = resolveBuildOrder(
      requestedPackages, depCtx, bootstrap, isInstallDir
    )

    # Resolve every bootstrap-capable cycle. The graph reports one cycle at a
    # time, so a successful bootstrap round can expose a separate cycle that
    # also needs a seed before the final build order is acyclic.
    if sortResult.hasCycle and bootstrap:
      fatal "Bootstrap dependency graph is still circular: " &
            formatCycleDisplay(sortResult.cyclePath)
      return 1

    var bootstrapSatisfied = initHashSet[string]()
    var bootstrapSeeds: seq[string] = @[]
    var bootstrapSatisfiedEdges = initHashSet[DependencyEdge]()
    while sortResult.hasCycle:
      let cyclePath = sortResult.cyclePath
      let pkgsWithBsdeps = getPackagesWithBsdeps(depGraph, cyclePath)
      if pkgsWithBsdeps.len == 0:
        fatal "Circular dependency detected: " & formatCycleDisplay(cyclePath) &
              ". Use bootstrap dependencies (bsdeps) to break the cycle."
        return 1

      warn "Circular dependency detected: " & formatCycleDisplay(cyclePath) &
           ". Kpkg will attempt to bootstrap and install its cycle seed."

      var madeProgress = false
      for pkg in pkgsWithBsdeps:
        if pkg in bootstrapSatisfied:
          continue
        let bootstrapSpec = if isInstallDir:
          depGraph.nodes[pkg].repo / pkg
        else:
          pkg
        let bootstrapResult = build(
          no = no, yes = yes, root = root,
          packages = @[bootstrapSpec],
          useCacheIfAvailable = useCacheIfAvailable,
          forceInstallAll = forceInstallAll,
          # The seed must be installed into the build root even when the final
          # requested package is build-only.
          dontInstall = false,
          tests = tests,
          ignorePostInstall = ignorePostInstall,
          deferPostInstall = deferPostInstall,
          isInstallDir = isInstallDir,
          isUpgrade = isUpgrade,
          target = target,
          bootstrap = true,
          noSandbox = noSandbox,
          sandboxTarget = sandboxTarget
        )
        if bootstrapResult != 0:
          fatal "Bootstrap build failed for '" & pkg & "'"
          return bootstrapResult
        bootstrapSatisfied.incl(pkg)
        bootstrapSeeds.add(bootstrapSpec)
        madeProgress = true

      let cycleEdges = getBootstrapEdgesForCycle(cyclePath,
              bootstrapSatisfied)
      for edge in cycleEdges:
        if edge notin bootstrapSatisfiedEdges:
          bootstrapSatisfiedEdges.incl(edge)
          madeProgress = true

      if not madeProgress:
        fatal "Circular dependency bootstrap made no progress: " &
              formatCycleDisplay(cyclePath)
        return 1

      info "Bootstrap build completed, resolving remaining dependency cycles..."
      depCtx.useBootstrap = false
      depCtx.bootstrapSatisfied = bootstrapSatisfied
      depCtx.bootstrapSatisfiedEdges = bootstrapSatisfiedEdges
      let finalPackages = finalRetryPackages(requestedPackages, bootstrapSeeds)
      (deps, depGraph, allDependents, sortResult) = resolveBuildOrder(
        finalPackages, depCtx, false, isInstallDir
      )

    # Build package list with init variants. Rebuilds forced by a deferred
    # install are not manual installs, so they stay out of this list.
    var p: seq[string]
    for currentPackage in packages:
      p = p & currentPackage
      if findPkgRepo(currentPackage & "-" & init) != "":
        p = p & (currentPackage & "-" & init)

    # Excludes (kpkg.conf and -e) apply to dependents kpkg schedules for a
    # rebuild on its own. Requested packages and their build dependencies are
    # left alone: dropping a dependency would break the build order.
    block:
      # Never drop a package the user asked for, even when it is also a
      # dependent of another requested package.
      var requested: seq[string]
      for pkg in requestedPackages: requested.add(lastPathPart(parsePkgInfo(pkg).name))
      let ex = partitionExcluded(allDependents.filterIt(it notin requested),
          proc(n: string): string = findPkgRepo(n),
          proc(n: string): bool = packageExists(n, fullRootPath))
      let dropped = ex.skipped & ex.missing
      for n in dropped:
        info "not rebuilding " & n & ": excluded"
      if dropped.len > 0:
        let pruned = pruneExcluded(deps, allDependents, dropped)
        deps = pruned.deps
        allDependents = pruned.dependents

    # UI prompts
    printReplacesPrompt(deps, fullRootPath, true)
    printReplacesPrompt(p, fullRootPath, isInstallDir = isInstallDir)

    if isInstallDir:
      printPackagesPrompt(deps.join(" "), yes, no, requestedPackages,
              dependents = allDependents)
    else:
      printPackagesPrompt(deps.join(" "), yes, no, @[""],
              dependents = allDependents)

    # Normalize package names (strip repo prefix if not isInstallDir)
    let pBackup = p
    p = @[]
    if not isInstallDir:
      for i in pBackup:
        let packageSplit = parsePkgInfo(i)
        p = p & packageSplit.name

    # Build package paths table for isInstallDir mode
    var pkgPaths = initTable[string, string]()
    if isInstallDir:
      for pkg in requestedPackages:
        pkgPaths[lastPathPart(pkg)] = absolutePath(pkg)

    # Install the archives a previous run left behind now that the user has
    # accepted this run, so declining the prompt installs nothing.
    if deferredPlan.toInstall.len > 0:
      try:
        let completion = applyPendingInstalls(fullRootPath, deferredPlan,
            deferredHooks)
        if completion.failed.len > 0:
          warn "could not complete " & $completion.failed.len &
              " deferred install(s); they stay recorded"
      except CatchableError:
        warn "could not complete the deferred installs: " &
            getCurrentExceptionMsg()

    # Get build dependents for cache invalidation
    let gD = getDependents(deps)

    # Create sandbox configuration
    var sandboxCfg = initSandboxConfig(
      fullRootPath = fullRootPath,
      target = target,
      bootstrap = bootstrap,
      forceInstallAll = forceInstallAll,
      isInstallDir = isInstallDir,
      ignoreInit = ignoreInit,
      dontInstall = dontInstall,
      useCacheIfAvailable = useCacheIfAvailable,
      binCache = binCache,
      tests = tests,
      isUpgrade = isUpgrade,
      ignorePostInstall = ignorePostInstall,
      deferPostInstall = deferPostInstall,
      manualInstallList = p,
      ignoreUseCacheIfAvailable = gD & forcedRebuilds,
      root = root,
      pkgPaths = pkgPaths,
      commit = commitCtx.commit,
      commitRepo = commitCtx.commitRepo,
      headRunfileCache = commitCtx.headRunfileCache,
      noSandbox = noSandbox,
      sandboxTarget = sandboxTarget
    )

    # Build all packages in sandbox
    result = buildAllPackagesInSandbox(deps, depGraph, sandboxCfg,
            builderWrapper, installPkgWrapper)

    # The consumer rebuild this run promised has finished, so a record whose
    # provider did not reach the root is installed here.
    if result == 0 and not dontInstall:
      try:
        let settled = planPendingInstalls(fullRootPath, deferredHooks,
            allowInstall = true)
        if settled.toInstall.len > 0:
          discard applyPendingInstalls(fullRootPath, settled, deferredHooks)
        reportDeferredPlan(settled)
      except CatchableError:
        warn "could not settle the deferred installs: " & getCurrentExceptionMsg()
