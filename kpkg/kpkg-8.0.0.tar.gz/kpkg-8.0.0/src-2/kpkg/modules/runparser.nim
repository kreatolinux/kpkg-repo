import os
import ../../common/logging
import ../../kongue/variables
import parsecfg
import sequtils
import strutils
import tables
import std/locks
import arch
import sourcegroups
import run3/run3

type
  SourceEntry* = tuple
    url: string
    sha256sum: string
    sha512sum: string
    b2sum: string

var runfileParseLock: Lock
initLock(runfileParseLock)

type runFile* = object
  pkg*: string
  sources*: seq[SourceEntry]
  version*: string
  release*: string
  extract*: bool = true
  autocd*: bool = true
  epoch*: string
  desc*: string
  versionString*: string
  conflicts*: seq[string]
  deps*: seq[string]
  bdeps*: seq[string]
  bsdeps*: seq[string]
  backup*: seq[string]
  optdeps*: seq[string]
  replaces*: seq[string]
  license*: seq[string]
  noChkupd*: bool
  isGroup*: bool
  isParsed*: bool
  isSemver*: bool = false
  run3Data*: Run3File ## Parsed run3 representation
  functions*: seq[tuple[name: string, body: string]]
  arch*: string ## Normalized target arch this runfile was resolved for
  archSources*: seq[string] ## Arch names that provide a `sources_<arch>` group

proc packageDepsForMetadata*(pkg: runFile, useBootstrapDeps = false): seq[string] =
  if useBootstrapDeps and pkg.bsdeps.len > 0:
    return pkg.bsdeps
  return pkg.deps

proc parseRunfile*(path: string, removeLockfileWhenErr = true,
        arch = ""): runFile =
  ## Parse a run3 file into a runFile object.
  ##
  ## `arch` is the *target* architecture of the build (kpkg's normalized
  ## spelling, see modules/arch.nim). It selects which `sources_<arch>` /
  ## `sha256sum_<arch>` / `depends_<arch>` groups apply. An empty `arch` means
  ## the host architecture, which is what metadata-only callers (info, list,
  ## dependency resolution) want.
  ##
  ## Kongue parsing and variable substitution use process-global runtime state,
  ## so every caller is serialized here.
  acquire(runfileParseLock)
  defer: release(runfileParseLock)

  var ret: runFile
  ret.functions = @[]
  ret.arch = normalizeArch(arch)
  if ret.arch.len == 0:
    ret.arch = hostArch()
  let package = lastPathPart(path)
  var override: Config

  debug "parseRunfile: starting parse for '"&package&"'"

  if fileExists("/etc/kpkg/override/"&package&".conf"):
    override = loadConfig("/etc/kpkg/override/"&package&".conf")
  else:
    override = newConfig()

  try:
    # Use run3 parser
    debug "parseRunfile: calling run3.parseRun3"
    let rf = run3.parseRun3(path)
    debug "parseRunfile: run3.parseRun3 completed"
    ret.run3Data = rf
    debug "parseRunfile: getting all variables"
    let allVars = rf.getAllVariables()
    debug "parseRunfile: got all variables"

    ret.pkg = rf.getVariable("name", override, "runFile", "name")
    ret.desc = rf.getVariable("description", override, "runFile", "description")
    ret.version = rf.getVariable("version", override, "runFile", "version")
    ret.release = rf.getVariable("release", override, "runFile", "release")

    # Parse sources and checksums into SourceEntry tuples.
    #
    # `sources:` is the common list every architecture builds from (local
    # patches, shared tarballs). `sources_<arch>:` is appended after it for the
    # target arch only, with its own parallel checksum lists. Appending keeps
    # shared local patches in one place and lets a recipe add an arch-specific
    # binary next to a common source tarball.
    ret.sources = @[]
    ret.archSources = @[]

    let groups = sourceGroups(rf.parsed)
    for group in groups:
      if group.arch.len > 0:
        ret.archSources.add(group.arch)

    proc appendGroup(group: SourceGroup) =
      ## Append one source group (common or arch-specific) to ret.sources.
      ##
      ## The lists are read through getListVariable so an override config can
      ## still replace a group's URLs and sums. The lookup name is the full
      ## Kongue name, so `sources aarch64:` and `sources_aarch64:` behave
      ## identically here.
      let sourceUrls = rf.getListVariable(group.sourcesLookup, override,
              "runFile", group.sourcesKey)
      let sha256sums = if group.sha256sumLookup.len > 0:
          rf.getListVariable(group.sha256sumLookup, override, "runFile",
              group.sha256sumKey) else: @[]
      let sha512sums = if group.sha512sumLookup.len > 0:
          rf.getListVariable(group.sha512sumLookup, override, "runFile",
              group.sha512sumKey) else: @[]
      let b2sums = if group.b2sumLookup.len > 0:
          rf.getListVariable(group.b2sumLookup, override, "runFile",
              group.b2sumKey) else: @[]

      for i, url in sourceUrls:
        let entry: SourceEntry = (
          url: url,
          sha256sum: if i < sha256sums.len: sha256sums[i] else: "",
          sha512sum: if i < sha512sums.len: sha512sums[i] else: "",
          b2sum: if i < b2sums.len: b2sums[i] else: ""
        )
        ret.sources.add(entry)

    for group in groups:
      if group.arch.len == 0 or group.arch == ret.arch:
        appendGroup(group)

    let noChkupdStr = rf.getVariable("no_chkupd", override, "runFile", "noChkupd")
    if noChkupdStr != "": ret.noChkupd = parseBool(noChkupdStr)

    let isSemverStr = rf.getVariable("is_semver", override, "runFile", "isSemver")
    if isSemverStr != "": ret.isSemver = parseBool(isSemverStr)

    ret.epoch = rf.getVariable("epoch", override, "runFile", "epoch")

    ret.backup = rf.getListVariable("backup", override, "runFile", "backup")

    ret.conflicts = rf.getListVariable("conflicts", override, "runFile", "conflicts")
    ret.deps = rf.getListVariable("depends", override, "runFile", "depends")
    ret.bdeps = rf.getListVariable("build_depends", override, "runFile", "buildDepends")

    # Bootstrap depends logic
    if allVars.hasKey("bootstrap_depends"):
      ret.bsdeps = rf.getListVariable("bootstrap_depends", override, "runFile", "bootstrapDepends")
    else:
      ret.bsdeps = @[]


    # Optdepends

    # Check variable existence order
    var optVarName = ""
    if allVars.hasKey("optdepends"): optVarName = "optdepends"
    elif allVars.hasKey("opt_depends"): optVarName = "opt_depends"
    elif allVars.hasKey("opt-depends"): optVarName = "opt-depends"

    # Construct raw value joined with " ;; " for override check
    var optVal = ""
    if optVarName != "":
      let v = allVars[optVarName]
      if v.kind == vvkList:
        optVal = v.toList().join(" ;; ")
      else:
        optVal = v.toString()

    let optOverridden = override.getSectionValue("runFile", "optDepends", optVal)

    # Use list directly if not overridden
    if optOverridden == optVal and optVarName != "" and allVars[
            optVarName].kind == vvkList:
      var res: seq[string] = @[]
      for item in allVars[optVarName].toList():
        res.add(rf.substituteVariables(item))
      ret.optdeps = res
    else:
      let optSub = rf.substituteVariables(optOverridden)
      if optSub.len > 0:
        ret.optdeps = optSub.split(" ;; ")
        ret.optdeps.keepItIf(it.len > 0)
      else:
        ret.optdeps = @[]

    let isGroupStr = rf.getVariable("is_group", override, "runFile", "isGroup")
    if isGroupStr != "": ret.isGroup = parseBool(isGroupStr)

    let extractStr = rf.getVariable("extract", override, "runFile", "extract")
    if extractStr != "": ret.extract = parseBool(extractStr)
    else: ret.extract = true

    # Parse autocd - defaults to true, but if extract is false and autocd not set, defaults to false
    let autocdStr = rf.getVariable("autocd", override, "runFile", "autocd")
    if autocdStr != "":
      ret.autocd = parseBool(autocdStr)
    else:
      # If autocd not explicitly set, default based on extract
      ret.autocd = ret.extract

    ret.replaces = rf.getListVariable("replaces", override, "runFile", "replaces")

    ret.license = rf.getListVariable("license", override, "runFile", "license")

    # Handle depends_package and depends_arch logic.
    #
    # `depends_<pkg>` adds dependencies for one sub-package.
    # `depends_<arch>` / `build_depends_<arch>` / `bootstrap_depends_<arch>`
    # add dependencies for the target architecture only, which is what
    # arch-specific binaries (vivaldi's .deb, firmware blobs, prebuilt
    # toolchains) need. The qualifier is normalized, so `depends_arm64` and
    # `depends_aarch64` mean the same thing. An unknown qualifier is a
    # sub-package name, so glibc's `depends_aarch64_linux_gnu_glibc` keeps its
    # meaning.
    let p = replace(package, '-', '_')
    let pLower = p.toLowerAscii()
    let targetArch = ret.arch

    proc qualifierMatchesArch(qualifier: string): bool =
      qualifier.len > 0 and targetArch.len > 0 and
        normalizeArch(qualifier) == targetArch

    const depPrefixes = [
      ("bootstrap_depends", "bootstrap"),
      ("bootstrap-depends", "bootstrap"),
      ("bootstrapdepends", "bootstrap"),
      ("build_depends", "build"),
      ("build-depends", "build"),
      ("builddepends", "build"),
      ("depends", "runtime")
    ]

    for varNode in rf.parsed.variables:
      if varNode.kind != nkListVariable:
        continue

      # Recover (base key, qualifier, full Kongue name) for both spellings.
      var baseKey = varNode.listName
      var qualifier = varNode.listQualifier
      var lookup = varNode.listName
      if qualifier.len > 0:
        lookup = varNode.listName & "_" & qualifier
      else:
        for (prefix, prefixKind) in depPrefixes:
          if baseKey.toLowerAscii().startsWith(prefix):
            let rest = baseKey[prefix.len .. ^1]
            if rest.len > 0 and rest[0] in {'_', '-'}:
              baseKey = prefix
              qualifier = rest[1 .. ^1]
            break

      var kind = ""
      for (prefix, prefixKind) in depPrefixes:
        if baseKey.toLowerAscii() == prefix:
          kind = prefixKind
          break
      if kind.len == 0:
        continue

      # A qualifier that names the package itself addresses a sub-package; a
      # qualifier that names the target architecture addresses that arch. Both
      # may be present, and glibc's `depends_aarch64_linux_gnu_glibc` is a
      # sub-package whose name merely starts with an architecture.
      let isPackageQualifier = qualifier.toLowerAscii() == pLower
      if not (isPackageQualifier or qualifierMatchesArch(qualifier)):
        continue

      let extra = rf.getListVariable(lookup)
      case kind
      of "build":
        ret.bdeps.add(extra)
      of "bootstrap":
        ret.bsdeps.add(extra)
      else:
        ret.deps.add(extra)

    # Functions
    for fnName in rf.getAllFunctions():
      ret.functions.add((name: fnName, body: ""))

    # Custom functions
    for fnName in rf.getAllCustomFunctions():
      ret.functions.add((name: fnName, body: ""))

  except IOError:
    if removeLockfileWhenErr:
      fatal(path&" doesn't seem to have a run3 file. possibly a broken package?")
    else:
      error(path&" doesn't seem to have a run3 file. possibly a broken package?")
      quit(1)
  except ParseError as e:
    if removeLockfileWhenErr:
      fatal(path&"/run3 parse error at line "&($e.line)&", column "&(
          $e.col)&": "&e.msg)
    else:
      error(path&"/run3 parse error at line "&($e.line)&", column "&(
          $e.col)&": "&e.msg)
      quit(1)
  except CatchableError:
    if removeLockfileWhenErr:
      fatal(path&" error parsing run3 file: "&getCurrentExceptionMsg())
    else:
      error(path&" error parsing run3 file: "&getCurrentExceptionMsg())
      quit(1)

  # Calculate versionString
  if ret.epoch != "" and ret.epoch != "no":
    ret.versionString = ret.version&"-"&ret.release&"-"&ret.epoch
  else:
    ret.versionString = ret.version&"-"&ret.release
    ret.epoch = "no"

  ret.isParsed = true
  return ret
