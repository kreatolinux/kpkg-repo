#[
This module contains functions for handling source code operations
in the builder-ng module.

It includes the following functions:
    - sourceDownloader
    - extractSources
    - downloadSource
    - verifyChecksum
    - setSourcePermissions
]#

import os
import posix
import osproc
import ../processes
import sequtils
import strutils
import ../../../common/logging
import ../config
import ../runparser
import ../checksums
import ../libarchive
import ../downloader
import ../commonPaths
import ../telemetry/main as telemetry
import tables

proc extractSources*(source: string, sourceDir: string) =
    ## Extracts a source archive
    if isEmptyOrWhitespace(source):
        return

    let filename = extractFilename(source)
    let ext = splitFile(filename).ext.toLowerAscii()

    const archiveExtensions = [".tar", ".gz", ".tgz", ".xz", ".txz", ".bz2",
            ".tbz2", ".zip", ".lz"]

    if ext notin archiveExtensions:
        debug "skipping extraction for "&filename&" (not an archive)"
        return

    debug "trying to extract "&filename
    try:
        discard extract(filename)
    except Exception:
        fatal "extraction failed for " & filename & ": " &
                getCurrentExceptionMsg()

proc downloadSource*(url, filename, pkgName: string) =
    ## Downloads a source file or git repository, falling back to a mirror if necessary
    let mirror = getConfigValue("Options", "sourceMirror", "mirror.krea.to/sources")
    var raiseWhenFail = true

    try:
        if not parseBool(mirror):
            raiseWhenFail = false
    except Exception:
        discard

    if url.startsWith("git::"):
        # Handle git repository
        let gitParts = url.split("::")
        if gitParts.len < 2:
            fatal("Invalid git URL format: " & url)
        let repoUrl = gitParts[1]
        let branch = if gitParts.len > 2: gitParts[2] else: "HEAD"
        let repoName = lastPathPart(repoUrl)
        ensureValidCwd()
        if execCmd("git clone " & repoUrl & " " & repoName & " && cd " &
                repoName & " && git checkout " & branch) != 0:
            fatal("Git clone failed for: " & repoUrl)
        createSymlink(getCurrentDir() / repoName, filename)
    else:
        try:
            debug "downloader ran, filename: "&filename
            download(url, filename, raiseWhenFail = raiseWhenFail)
        except Exception:
            info "download failed through sources listed on the runFile, contacting the source mirror"
            download("https://" & mirror & "/" & pkgName & "/" &
                    extractFilename(url).strip(),

filename, raiseWhenFail = false)

proc stageLocalSource*(sourcePath, sourceDir: string) =
    ## Copy a recipe-local source into writable build storage.
    let stagedPath = sourceDir / lastPathPart(sourcePath)
    if symlinkExists(stagedPath) or fileExists(stagedPath):
        removeFile(stagedPath)
    elif dirExists(stagedPath):
        removeDir(stagedPath)
    if dirExists(sourcePath):
        copyDirWithPermissions(sourcePath, stagedPath)
    else:
        copyFileWithPermissions(sourcePath, stagedPath)

proc verifyChecksum*(relativeFilename: string, filename, sourceUrl: string,
        sourceEntry: SourceEntry, sourceDir: string, localFile: bool) =
    ## Verifies the checksum of a downloaded file
    if sourceUrl.startsWith("git::"):
        # Skip checksum verification for Git sources
        return

    var actualDigest: string
    var expectedDigest: string
    var sumType: string

    # Try BLAKE2 checksum
    if not isEmptyOrWhitespace(sourceEntry.b2sum):
        expectedDigest = sourceEntry.b2sum
        sumType = "b2"

    # Try SHA-512 if BLAKE2 not available
    if sumType != "b2" and not isEmptyOrWhitespace(sourceEntry.sha512sum):
        expectedDigest = sourceEntry.sha512sum
        sumType = "sha512"

    # Try SHA-256 if neither BLAKE2 nor SHA-512 available
    if sumType != "sha512" and sumType != "b2" and not isEmptyOrWhitespace(
            sourceEntry.sha256sum):
        expectedDigest = sourceEntry.sha256sum
        sumType = "sha256"

    # Verify checksum (skip verification for local files explicitly marked as SKIP)
    if not (localFile and dirExists(filename)):
        actualDigest = getSum(filename, sumType)
        if expectedDigest != actualDigest:
            if not (localFile and expectedDigest == "SKIP"):
                removeFile(filename)
                error(sumType & "sum doesn't match for " & sourceUrl &
                    "\nExpected: '" & expectedDigest & "'\nActual: '" &
                    actualDigest & "'")
                quit(1)

    let stagedPath = sourceDir / lastPathPart(filename)
    if localFile:
        # Local recipe sources may live in a read-only repository mount. Copy
        # them into writable build storage because later ownership and mode
        # setup must never mutate the repository through a symlink.
        stageLocalSource(filename, sourceDir)
    else:
        createSymlink(filename, stagedPath)

proc setSourceOwnerNoFollow*(path: string, uid = int(geteuid()),
        gid = int(getegid())) =
    ## Match the process identity inherited by execEnv (root for kpkg builds).
    ## Bubblewrap drops capabilities, so a root build cannot rely on bypassing
    ## write permissions on sources owned by the former build user (999).
    ## Never follow symbolic links into repositories or the source cache.
    discard posix.lchown(cstring(path), Uid(uid), Gid(gid))

proc setSourcePermissions*() =
    ## Sets proper permissions for all source directories and their contents
    for path in toSeq(walkDir(".")):
        if dirExists(path.path) and not symlinkExists(path.path):
            debug "Setting permissions for " & path.path
            setFilePermissions(path.path, {fpUserExec, fpUserWrite, fpUserRead,
                    fpGroupExec, fpGroupRead, fpOthersExec, fpOthersRead})

            try:
                setSourceOwnerNoFollow(path.path)
                # Set permissions for all files in the directory
                for subPath in toSeq(walkDirRec(path.path, {pcFile,
                        pcLinkToFile, pcDir, pcLinkToDir})):
                    setSourceOwnerNoFollow(subPath)
            except:
                debug "Failed to set owner for " & path.path


proc cachedSourceMatches*(path: string, sourceEntry: SourceEntry): bool =
  ## True when the cached archive at `path` already satisfies the recipe's
  ## checksum, so the download can be skipped.
  var sumType = ""
  var expected = ""
  if not isEmptyOrWhitespace(sourceEntry.b2sum):
    (sumType, expected) = ("b2", sourceEntry.b2sum)
  elif not isEmptyOrWhitespace(sourceEntry.sha512sum):
    (sumType, expected) = ("sha512", sourceEntry.sha512sum)
  elif not isEmptyOrWhitespace(sourceEntry.sha256sum):
    (sumType, expected) = ("sha256", sourceEntry.sha256sum)
  if sumType == "" or expected == "SKIP":
    return false
  try:
    return getSum(path, sumType) == expected
  except CatchableError:
    return false

proc sourceDownloaderImpl(runf: runFile, pkgName: string, sourceDir: string,
        runFilePath: string) =
    ## Wrapper function for downloading and extracting sources
    debug "sourceDownloader ran, sourceDir: "&sourceDir&", runFilePath: "&runFilePath

    for sourceEntry in runf.sources:
        let source = sourceEntry.url
        debug "source: "&source
        var filename: string
        if source.startsWith("git::"):
            filename = lastPathPart(source.split("::")[1])
        else:
            filename = extractFilename(source)
        var sourcePath = kpkgSourcesDir & "/" & pkgName & "/" & filename
        let localPath = runFilePath & "/" & source
        var isLocalFile = false
        debug "sourcePath: "&sourcePath
        debug "localPath: "&localPath

        # Check if the source is a local file or directory
        if fileExists(localPath) or dirExists(localPath):
            isLocalFile = true
            debug "source is a local file or directory: " & localPath
            sourcePath = localPath
        else:
            debug "source is not a local file or directory, using sourcePath: " & sourcePath



        if not isLocalFile:
            # Reuse an archive already in the source cache when its checksum
            # matches. The build host may not be able to reach the upstream (or
            # the source mirror may 404 a tarball it never mirrored), and
            # re-downloading a 50 MB archive that is already on disk is pure
            # waste. A mismatch falls through to the normal download path, which
            # reports the real error.
            if not (fileExists(sourcePath) and cachedSourceMatches(
                    sourcePath, sourceEntry)):
                downloadSource(source, sourcePath, pkgName)

        verifyChecksum(filename, sourcePath, source, sourceEntry, sourceDir, isLocalFile)

        # Skip extraction for Git repositories as they're already in the correct format
        # And also skip localfiles
        if runf.extract and not (source.startsWith("git::") or isLocalFile):
            extractSources(sourcePath, sourceDir)

proc sourceDownloader*(runf: runFile, pkgName: string, sourceDir: string,
        runFilePath: string) =
    telemetry.withSpan("kpkg.source.retrieve", {
      "package.name": pkgName
    }.toTable):
        sourceDownloaderImpl(runf, pkgName, sourceDir, runFilePath)


proc setSourceOwnership*(sourceDir: string) =
    ## Sets permissions and ownership (uid/gid 999) for source directory
    ## and all contents recursively.
    ##
    ## This prepares the source directory for building with proper
    ## permissions for the build user.

    setFilePermissions(sourceDir, {fpUserExec, fpUserWrite, fpUserRead,
            fpGroupExec, fpGroupRead, fpOthersExec, fpOthersRead})
    setSourceOwnerNoFollow(sourceDir)

    for path in toSeq(walkDir(sourceDir)):
        if dirExists(path.path) and not symlinkExists(path.path):
            setFilePermissions(path.path, {fpUserExec, fpUserWrite, fpUserRead,
                    fpGroupExec, fpGroupRead, fpOthersExec, fpOthersRead})
        setSourceOwnerNoFollow(path.path)

        if dirExists(path.path) and not symlinkExists(path.path):
            for subPath in toSeq(walkDirRec(path.path, {pcFile, pcLinkToFile,
                    pcDir, pcLinkToDir})):
                setSourceOwnerNoFollow(subPath)


proc countAndFindSourceFolders*(baseDir: string): tuple[count: int,
        folder: string] =
    ## Walks baseDir, counts directories, returns count and last folder path.
    ##
    ## Used for autocd logic - if exactly one folder exists, autocd will
    ## change into it.
    ##
    ## Returns:
    ##   count: Number of directories found
    ##   folder: Absolute path to the last directory found (or empty if none)

    result.count = 0
    result.folder = ""

    for item in toSeq(walkDir(baseDir)):
        debug "countAndFindSourceFolders: " & item.path
        if dirExists(item.path):
            result.folder = absolutePath(item.path)
            result.count = result.count + 1
            if not symlinkExists(result.folder):
                setFilePermissions(result.folder, {fpUserExec, fpUserWrite,
                        fpUserRead, fpGroupExec, fpGroupRead, fpOthersExec,
                        fpOthersRead})
        setSourceOwnerNoFollow(result.folder)

        if dirExists(result.folder) and not symlinkExists(result.folder):
            for subPath in toSeq(walkDirRec(result.folder, {pcFile,
                    pcLinkToFile, pcDir, pcLinkToDir})):
                setSourceOwnerNoFollow(subPath)
