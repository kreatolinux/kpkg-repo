import ../transactions/barrier
import ../lockfile
#[
  This module handles sandbox/overlay setup and package building loop.
  
  Extracted from buildcmd.nim to provide a clean interface for
  building packages in an isolated sandbox environment.
]#

import os
import sets
import tables
import strutils
import sequtils
import ./types
import ../../../common/logging
import ../config
import ../isolation
import ../envstate
import ../removeInternal
import ../rootfs/finalize as rootfsFinalize
import ../rootfs/profile as rootfsProfile
import ../rootfs/types
import ../rootfs/provision as rootfsProvision
import ../dephandler
import ../processes
import ../commonPaths
import ../commonTasks
import ../runparser
import ../sqlite
import ../../commands/installcmd
import ../../modules/telemetry/main as telemetry
import ./cache

proc addPackageWithDepsToQueue*(queue: var seq[string], packageName: string,
                                depResolver: proc(pkg: string): seq[string],
                                installedResolver: proc(pkg: string): bool) =
  ## Add packageName to queue, inserting any missing dependencies first.
  ## depResolver must return BOTH build and runtime dependencies so that
  ## transitively-required packages (e.g. the build deps of a runtime dep)
  ## are built and installed before packageName. Without build deps, a
  ## dynamically-added package whose build deps are not yet built/installed
  ## would be built in a sandbox missing those build deps.
  ## Used for packages dynamically appended outside the precomputed dep graph.
  var known = queue
  var ordered: seq[string]
  var visiting: seq[string]

  proc visit(pkg: string) =
    if pkg in known or installedResolver(pkg):
      return
    if pkg in visiting:
      debug "addPackageWithDepsToQueue: dependency cycle at " & pkg
      return

    visiting.add(pkg)
    for dep in depResolver(pkg):
      if not isEmptyOrWhitespace(dep):
        visit(dep)
    discard visiting.pop()

    if pkg notin known:
      ordered.add(pkg)
      known.add(pkg)

  visit(packageName)

  for pkg in ordered:
    queue.add(pkg)

proc shouldRunSandboxPostInstall*(deferPostInstall,
        ignorePostInstall: bool): bool =
  not deferPostInstall and not ignorePostInstall

proc buildPackageInSandboxImpl(pkgName: string, depGraph: dependencyGraph,
                            sandboxCfg: SandboxConfig,
                            builderProc: BuilderProc,
                            installPkgProc: InstallPkgProc): seq[string] =
  ## Sets up sandbox for a single package and builds it.
  ##
  ## Handles overlay mount, dependency installation, postinstall, ldconfig.
  ##
  ## Parameters:
  ##   pkgName: Package name to build
  ##   depGraph: Pre-computed dependency graph
  ##   sandboxCfg: Sandbox configuration
  ##   builderProc: Callback to builder() function
  ##   installPkgProc: Callback for installing packages to overlay

  let pkgTmp = parsePkgInfo(pkgName)

  if sandboxCfg.noSandbox:
    # The root itself (a chroot or seed image) is the isolation boundary.
    # There is no kpkg env to create: createEnv() copies the host system into
    # the sandbox by reading the kpkg SQLite DB, which cannot work on a
    # foreign host and is unnecessary when we already have a populated root.
    debug "noSandbox: skipping sandbox env creation for " & pkgName
  else:
    createOrUpgradeEnv(sandboxCfg.root,
        deferPostInstall = sandboxCfg.deferPostInstall,
        target = sandboxCfg.sandboxTarget)
    # createEnv copies packages installed in the host root. A requested native
    # init variant may not be installed there, so complete the persistent
    # sandbox from that target's binary repository.
    let profileExclusions = @[pkgTmp.name]
    let targetPackages = targetSandboxPackages(sandboxCfg.sandboxTarget,
        sandboxCfg.root, profileExclusions)
    if targetPackages.len > 0:
      # Resolve runtime dependencies as well: installPkg only extracts a cached
      # archive and neither downloads it nor installs its dependency closure.
      let variantDeps = dephandler(targetPackages, root = kpkgEnvPath)
      let missingVariantDeps = variantDeps.filterIt(
          not isEmptyOrWhitespace(it) and not packageExists(it, kpkgEnvPath))
      if missingVariantDeps.len > 0:
        # Do not publish a partly converted sandbox as reusable. Source-profile
        # packages are removed only after every target archive is available.
        invalidateEnvSetup(kpkgEnvPath)
        let desiredProfile = sandboxProfileForTarget(sandboxCfg.sandboxTarget,
            sandboxCfg.root)
        let conversion = RootfsPlan(profile: desiredProfile,
          mode: rmSeeded, acquire: missingVariantDeps,
          remove: targetSandboxReplacedPackages(sandboxCfg.sandboxTarget,
            sandboxCfg.root, profileExclusions),
          install: missingVariantDeps, exclusions: profileExclusions)
        try:
          rootfsProvision.provision(conversion,
            proc(package, target: string) =
              down_bin(package,
                getConfigValue("Repositories", "binRepos").split(" "),
                kpkgEnvPath, offline = false, kTarget = target),
            proc(package: string) =
              if packageExists(package, kpkgEnvPath):
                removeInternal(package, kpkgEnvPath, initCheck = false),
            proc(package: string) =
              installPkgProc(InstallConfig(repo: findPkgRepo(package),
                package: package, root: kpkgEnvPath, isUpgrade: false,
                kTarget: sandboxCfg.sandboxTarget, manualInstallList: @[],
                disablePkgInfo: false, ignorePostInstall: true,
                deferPostInstall: sandboxCfg.deferPostInstall)),
            proc(phase: ProvisionPhase, pending, completed: seq[string]) =
              markEnvProvisioning(kpkgEnvPath, phase, pending, completed))
        except CatchableError:
          markEnvFailed(kpkgEnvPath, "profile_conversion")
          raise
      # Variant installation deliberately skips hooks here. Publish readiness
      # only after profile links/finalizers are complete.
      if sandboxCfg.deferPostInstall:
        markEnvDeferred(kpkgEnvPath)
      else:
        let desiredProfile = sandboxProfileForTarget(sandboxCfg.sandboxTarget,
            sandboxCfg.root)
        let excludedIdentity = profileExclusions.anyIt(it in
            rootfsProfile.sourceProfileRoots(desiredProfile))
        if excludedIdentity:
          markEnvProvisioning(kpkgEnvPath, rpInstalling, profileExclusions)
        else:
          rootfsFinalize.finalizeProfileLinks(kpkgEnvPath, desiredProfile)
          markEnvReady(kpkgEnvPath)


  # Extract sandbox dependencies from the graph
  let sandboxDeps = getSandboxDepsFromGraph(pkgTmp.name, depGraph,
          sandboxCfg.bootstrap, sandboxCfg.fullRootPath,
          sandboxCfg.forceInstallAll, sandboxCfg.isInstallDir,
          sandboxCfg.ignoreInit)

  debug "sandboxDeps for " & pkgTmp.name & " = \"" & sandboxDeps.join(" ") & "\""
  var allInstalledDeps: seq[string]



  # Resolve kTarget for tarball lookup — matches how the builder stores tarballs
  let sandboxKTarget = if sandboxCfg.target == "default" or sandboxCfg.target ==
      kpkgTarget("/"):
    kpkgTarget(sandboxCfg.fullRootPath)
  else:
    sandboxCfg.target

  var overlayMounted = false
  if not sandboxCfg.noSandbox:
    # Prepare the tmpfs backing the overlay.  This procedure owns the entire
    # mount lifetime from this point onward, including dependency installation,
    # overlay mounting, package execution, and early returns.
    let prepareResult = prepareOverlayDirs()
    if prepareResult != 0:
      fatal("preparing overlay directories failed")

    if isCrossTarget(sandboxCfg.target, sandboxCfg.root):
      for d in sandboxDeps:
        if isEmptyOrWhitespace(d):
          continue

        debug "buildPackageInSandbox: installPkg ran for '" & d & "'"
        let installCfg = InstallConfig(
          repo: findPkgRepo(d),
          package: d,
          root: kpkgOverlayPath & "/upperDir",
          isUpgrade: false,
          kTarget: sandboxKTarget,
          manualInstallList: @[],
          disablePkgInfo: true,
          deferPostInstall: sandboxCfg.deferPostInstall
        )
        installPkgProc(installCfg)
    else:
      # Resolve all direct roots first, then copy their union closure once.
      var installRoots = sandboxDeps

      # If the package isn't in the dep graph (e.g. dynamically added consumer),
      # resolve its direct build deps and runtime closure from runfile metadata.
      if sandboxDeps.len == 0:
        try:
          let dynamicDeps = collectDynamicSandboxDeps(pkgTmp.name,
              proc(pkg: string): runFile =
            parseRunfile(findPkgRepo(pkg) & "/" & pkg))
          for dep in dynamicDeps:
            if packageExists(dep, sandboxCfg.root):
              debug "buildPackageInSandbox: adding dynamic sandbox dep '" &
                  dep & "' for '" & pkgTmp.name & "'"
              installRoots.add(dep)
        except:
          debug "buildPackageInSandbox: could not resolve dynamic sandbox deps for '" &
              pkgTmp.name & "'"

      allInstalledDeps = installFromRoot(installRoots, sandboxCfg.root,
              kpkgOverlayPath & "/upperDir", ignorePostInstall = true)

      # Install the package with changed SONAME into the env so consumers
      # build against the new library version. The env is the overlay lower
      # dir — installing there replaces the old library entirely, making
      # pkg-config and the linker find only the new version.
      if sandboxCfg.sonameChangedPackage != "":
        debug "buildPackageInSandbox: installing changed soname package '" &
            sandboxCfg.sonameChangedPackage & "' to env"
        installPkg(findPkgRepo(sandboxCfg.sonameChangedPackage),
                sandboxCfg.sonameChangedPackage, kpkgEnvPath,
                kTarget = sandboxKTarget, manualInstallList = @[],
                ignorePostInstall = true,
                deferPostInstall = sandboxCfg.deferPostInstall)
      # Install rebuilt consumers to upperDir so subsequent builds get updated libs/binaries
      for r in sandboxCfg.rebuiltConsumers:
        if r != pkgName:
          debug "buildPackageInSandbox: installing rebuilt consumer '" & r & "' to overlay"
          installPkgProc(InstallConfig(
            repo: findPkgRepo(r),
            package: r,
            root: kpkgOverlayPath & "/upperDir",
            isUpgrade: false,
            kTarget: sandboxKTarget,
            manualInstallList: @[],
            disablePkgInfo: true,
            ignorePostInstall: true,
            deferPostInstall: sandboxCfg.deferPostInstall
          ))

    # Mount the overlayfs after dependencies are installed.
    let mountResult = mountOverlayFilesystem()
    if mountResult != 0:
      fatal("mounting overlay filesystem failed")

    # Rebuild the loader cache before any postinstall hook runs. Dependencies
    # were just copied into the overlay upper dir, so the cache inherited from
    # the env lower dir does not list them yet: a postinstall that executes a
    # freshly-installed binary fails with "cannot open shared object file"
    # (e.g. json-glib runs glib-compile-schemas, which needs libgio).
    discard runLdconfig(kpkgMergedPath, silentMode = true)

    # Run postinstall scripts in merged overlay
    if shouldRunSandboxPostInstall(sandboxCfg.deferPostInstall,
        sandboxCfg.ignorePostInstall) and
        not isCrossTarget(sandboxCfg.target, sandboxCfg.root):
      debug "builder-ng: postinstall is running"
      for d in deduplicate(allInstalledDeps):
        if not isEmptyOrWhitespace(d):
          runPostInstall(d)

    # Postinstall hooks can install further libraries; refresh once more so the
    # package's own build steps and the final root see a consistent cache.
    discard runLdconfig(kpkgMergedPath, silentMode = true)
    overlayMounted = true
  else:
    # No overlay and no env: the root itself is the isolation boundary. Build
    # dependencies were installed into the root by earlier iterations of the
    # build queue, so only their postinstall scripts and ldconfig are missing.
    var visited = initHashSet[string]()
    allInstalledDeps = deduplicate(collectRuntimeDepsFromGraph(
            sandboxDeps, depGraph, visited))

    if shouldRunSandboxPostInstall(sandboxCfg.deferPostInstall,
        sandboxCfg.ignorePostInstall):
      for d in allInstalledDeps:
        if not isEmptyOrWhitespace(d):
          runPostInstall(d, sandboxCfg.root, passthrough = true)

    discard runLdconfig(sandboxCfg.root, silentMode = true)

  let packageSplit = parsePkgInfo(pkgName)

  # Determine if this is a bootstrap build
  let isBootstrapBuild = sandboxCfg.bootstrap and depGraph.nodes.hasKey(pkgTmp.name) and
          depGraph.nodes[pkgTmp.name].metadata.bsdeps.len > 0

  var customRepo = ""
  var isInstallDirFinal = false
  var actualPkgName: string

  # Try to get repo from graph first
  if depGraph.nodes.hasKey(pkgTmp.name):
    let r = depGraph.nodes[pkgTmp.name].repo
    if r != "local" and r.startsWith("/etc/kpkg/repos/"):
      customRepo = lastPathPart(r)

  if sandboxCfg.isInstallDir and sandboxCfg.pkgPaths.hasKey(pkgTmp.name):
    actualPkgName = sandboxCfg.pkgPaths[pkgTmp.name]
    isInstallDirFinal = true
  else:
    if "/" in packageSplit.nameWithRepo:
      customRepo = lastPathPart(packageSplit.repo)
      actualPkgName = packageSplit.name
    else:
      actualPkgName = packageSplit.name

  if isBootstrapBuild:
    info("Performing bootstrap build for " & pkgName)

  # Create BuildConfig for this package
  var buildCfg = BuildConfig(
    package: actualPkgName,
    destdir: sandboxCfg.fullRootPath,
    offline: false,
    dontInstall: sandboxCfg.dontInstall,
    useCacheIfAvailable: sandboxCfg.useCacheIfAvailable,
    binCache: sandboxCfg.binCache,
    tests: sandboxCfg.tests,
    manualInstallList: sandboxCfg.manualInstallList,
    customRepo: customRepo,
    isInstallDir: isInstallDirFinal,
    isUpgrade: sandboxCfg.isUpgrade,
    target: sandboxCfg.target,
    actualRoot: sandboxCfg.root,
    ignorePostInstall: sandboxCfg.ignorePostInstall,
    deferPostInstall: sandboxCfg.deferPostInstall,
    noSandbox: sandboxCfg.noSandbox,
    ignoreTarget: false,
    ignoreUseCacheIfAvailable: sandboxCfg.ignoreUseCacheIfAvailable,
    isBootstrap: isBootstrapBuild,
    skipHostInstall: true
  )

  discard builderProc(buildCfg)

  # Install to host if not a SONAME-changed package, so rebuilt
  # consumers replace the old system binaries. An explicit target that
  # matches the root's own target is the noSandbox bootstrap case: the
  # root is the target system and the package must be installed there.
  #
  # Exception: the libc itself (glibc, musl, ...). Installing it replaces
  # the libc the build environment is running on - fatal on a foreign
  # bootstrap root regardless of which libc it is (glibc kills processes
  # with GLIBC_PRIVATE mismatches; musl swaps the entire userspace). The
  # rootfs gets its libc through the buildDir install instead.
  if actualPkgName != getLibc(sandboxCfg.root).toLowerAscii() and
      not buildCfg.sonameChanged and not sandboxCfg.dontInstall and
      (sandboxCfg.target == "default" or
       sandboxCfg.target == kpkgTarget(sandboxCfg.root)):
    debug "buildPackageInSandbox: installing " & actualPkgName & " to host"
    let archivePath = if isBootstrapBuild:
      cacheArchivePath(actualPkgName, depGraph.nodes[pkgTmp.name].metadata,
          sandboxKTarget, isBootstrap = true)
    else:
      ""
    installPkg(findPkgRepo(actualPkgName), actualPkgName,
            sandboxCfg.fullRootPath,
            manualInstallList = @[], kTarget = sandboxKTarget,
            ignorePostInstall = true,
            deferPostInstall = sandboxCfg.deferPostInstall,
            tarballPath = archivePath)

  if overlayMounted:
    let cleanupResult = umountOverlay(silentMode = true)
    if cleanupResult != 0:
      fatal("internal: sandbox overlay remained mounted")

  if buildCfg.sonameChanged:
    return buildCfg.consumersToRebuild

  info("built " & pkgName & " successfully")

proc buildPackageInSandbox*(pkgName: string, depGraph: dependencyGraph,
                             sandboxCfg: SandboxConfig,
                             builderProc: BuilderProc,
                             installPkgProc: InstallPkgProc): seq[string] =
  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if sandboxCfg.fullRootPath ==
      "": "/" else: sandboxCfg.fullRootPath)
  assertNoAbandonedHistory(if sandboxCfg.root == "": "/" else: sandboxCfg.root)
  assertNoAbandonedHistory(kpkgEnvPath)
  assertNoAbandonedHistory(kpkgOverlayPath & "/upperDir")

  telemetry.withSpan("kpkg.sandbox.lifecycle", {
    "package.name": parsePkgInfo(pkgName).name,
    "package.bootstrap": $sandboxCfg.bootstrap
  }.toTable):
    return buildPackageInSandboxImpl(pkgName, depGraph, sandboxCfg, builderProc,
        installPkgProc)


proc buildAllPackagesInSandbox*(deps: var seq[string], depGraph: dependencyGraph,
                                sandboxCfg: var SandboxConfig,
                                builderProc: BuilderProc,
                                installPkgProc: InstallPkgProc): int =
  ## Iterates over all packages and builds each in sandbox.
  ##
  ## Returns 0 on success.

  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if sandboxCfg.fullRootPath ==
      "": "/" else: sandboxCfg.fullRootPath)
  assertNoAbandonedHistory(if sandboxCfg.root == "": "/" else: sandboxCfg.root)
  assertNoAbandonedHistory(kpkgEnvPath)
  assertNoAbandonedHistory(kpkgOverlayPath & "/upperDir")

  var sonameSourceMap = initTable[string, string]()
  var sonameSources: seq[string]
  let sandboxKTarget = if sandboxCfg.target == "default" or sandboxCfg.target ==
      kpkgTarget("/"):
    kpkgTarget(sandboxCfg.fullRootPath)
  else:
    sandboxCfg.target
  var i = 0
  while i < deps.len:
    let pkg = deps[i]
    try:
      if sandboxCfg.binCache and not sandboxCfg.isInstallDir:
        # Prefer a published binary for this dependency. seedBinaryArchive
        # populates the local archive cache that builderImpl() consults, so a
        # hit skips the source build entirely; a miss falls through unchanged.
        try:
          let rf = parseRunfile(findPkgRepo(pkg) & "/" & pkg)
          discard seedBinaryArchive(rf, sandboxKTarget)
        except CatchableError:
          debug "binCache: could not seed binary for " & pkg & ": " &
              getCurrentExceptionMsg()
      sandboxCfg.sonameChangedPackage = sonameSourceMap.getOrDefault(pkg, "")
      if sandboxCfg.sonameChangedPackage != "":
        debug "buildAll: " & pkg & " is SONAME consumer of " &
            sandboxCfg.sonameChangedPackage
      let consumers = buildPackageInSandbox(pkg, depGraph, sandboxCfg,
              builderProc, installPkgProc)
      if consumers.len > 0:
        sonameSources.add(pkg)
        sandboxCfg.rebuiltConsumers.add(pkg)
      elif sonameSourceMap.hasKey(pkg):
        sandboxCfg.rebuiltConsumers.add(pkg)
        debug "buildAll: added rebuilt consumer " & pkg & " to rebuiltConsumers"
      for consumer in consumers:
        if consumer notin deps:
          try:
            let pkgDir = findPkgRepo(consumer) & "/" & consumer
            let rf = parseRunfile(pkgDir)
            # A SONAME consumer is rebuilt from source, so both its declared
            # build and runtime dependencies must be present in the sandbox.
            # Runtime dependencies commonly provide development headers (e.g.
            # nss needs nspr); omitting them makes these dynamic rebuilds use
            # an incomplete environment.
            for dep in rf.bdeps & rf.deps:
              let oldLen = deps.len
              let installedRoot = sandboxCfg.root
              addPackageWithDepsToQueue(deps, dep,
                  proc(pkg: string): seq[string] =
                try:
                  let rf = parseRunfile(findPkgRepo(pkg) & "/" & pkg)
                  return rf.bdeps & rf.deps
                except CatchableError:
                  debug "could not resolve deps for dynamic consumer dependency " & pkg
                  return @[],
                  proc(pkg: string): bool = packageExists(pkg, installedRoot))

              for j in oldLen ..< deps.len:
                if deps[j] == dep:
                  info "Added " & dep & " (dependency) to queue for consumer " & consumer
                else:
                  info "Added " & deps[j] &
                      " (transitive dependency) to queue for consumer " & consumer
          except:
            debug "could not resolve bdeps for consumer " & consumer
          deps.add(consumer)
          sonameSourceMap[consumer] = pkg
          sandboxCfg.ignoreUseCacheIfAvailable.add(consumer)
          info "Added " & consumer & " to build queue (SONAME consumer rebuild)"
    except CatchableError:
      # Report which package failed and why. Swallowing the message made
      # release builds abort with a bare "Undefined error occured", which
      # gives nothing to act on.
      when defined(release):
        fatal("build of " & pkg & " failed: " & getCurrentExceptionMsg())
      else:
        raise getCurrentException()
    i.inc

  info("built all packages successfully")

  # Install SONAME-changed source packages to host after all consumers
  # are rebuilt. This provides the new library version (e.g. libssl.so.4)
  # that rebuilt consumers link against.
  for src in sonameSources:
    info "Installing SONAME-changed package '" & src & "' to host"
    installPkg(findPkgRepo(src), src, sandboxCfg.fullRootPath,
            manualInstallList = @[], kTarget = sandboxKTarget,
            isUpgrade = true, ignorePostInstall = true,
            deferPostInstall = sandboxCfg.deferPostInstall)

  return 0
