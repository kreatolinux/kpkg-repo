import ../transactions/barrier
import ../lockfile
#[
  This module handles sandbox/overlay setup and package building loop.
  
  Extracted from buildcmd.nim to provide a clean interface for
  building packages in an isolated sandbox environment.
]#

import os
import sets
import tables
import strutils
import sequtils
import ./types
import ../../../common/logging
import ../config
import ../isolation
import ../envstate
import ../removeInternal
import ../rootfs/finalize as rootfsFinalize
import ../rootfs/profile as rootfsProfile
import ../rootfs/types
import ../rootfs/provision as rootfsProvision
import ../dephandler
import ../processes
import ../commonPaths
import ../commonTasks
import ../runparser
import ../versioncmp
import ../arch
import ../sqlite
import ../../commands/installcmd
import ../../modules/telemetry/main as telemetry
import ./cache

proc addPackageWithDepsToQueue*(queue: var seq[string], packageName: string,
                                depResolver: proc(pkg: string): seq[string],
                                installedResolver: proc(pkg: string): bool) =
  ## Add packageName to queue, inserting any missing dependencies first.
  ## depResolver must return BOTH build and runtime dependencies so that
  ## transitively-required packages (e.g. the build deps of a runtime dep)
  ## are built and installed before packageName. Without build deps, a
  ## dynamically-added package whose build deps are not yet built/installed
  ## would be built in a sandbox missing those build deps.
  ## Used for packages dynamically appended outside the precomputed dep graph.
  var known = queue
  var ordered: seq[string]
  var visiting: seq[string]

  proc visit(pkg: string) =
    if pkg in known or installedResolver(pkg):
      return
    if pkg in visiting:
      debug "addPackageWithDepsToQueue: dependency cycle at " & pkg
      return

    visiting.add(pkg)
    for dep in depResolver(pkg):
      if not isEmptyOrWhitespace(dep):
        visit(dep)
    discard visiting.pop()

    if pkg notin known:
      ordered.add(pkg)
      known.add(pkg)

  visit(packageName)

  for pkg in ordered:
    queue.add(pkg)

proc shouldRunSandboxPostInstall*(deferPostInstall,
        ignorePostInstall: bool): bool =
  not deferPostInstall and not ignorePostInstall

type
  SandboxArchiveDep* = object
    ## A sandbox dependency that must come from a binary archive instead of the
    ## copy taken out of the build root.
    package*: string
    version*: string
    archive*: string

proc planSandboxArchiveDeps*(candidates: seq[string],
        installedVersion: proc(pkg: string): string,
        recipeVersion: proc(pkg: string): string,
        localArchive: proc(pkg, version: string): string,
        fetchArchive: proc(pkg, version: string): string,
        includeStaleInstalled = true): seq[SandboxArchiveDep] =
  ## Decide which sandbox dependencies are installed from their archives.
  ##
  ## Copying a dependency out of the build root freezes it at whatever version
  ## the root has: a dependency whose recipe is newer is upgraded inside the
  ## sandbox, and one that is installed nowhere was built earlier in this run
  ## with --dontInstall, so its archive is the only copy. A newer installed
  ## dependency keeps the root copy. A stale installed dependency may be fetched
  ## from a binary repository; one that is missing entirely is taken from the
  ## local archive cache only, because a build in this run already produces it.
  var seen = initHashSet[string]()
  for candidate in candidates:
    let pkg = dependencyName(candidate)
    if pkg.len == 0 or pkg in seen:
      continue
    seen.incl(pkg)

    let wanted = recipeVersion(pkg)
    if wanted.len == 0:
      continue
    let have = installedVersion(pkg)
    # Only an upgrade replaces the root copy: a recipe that lags behind the
    # installed version must not downgrade the sandbox.
    if have.len > 0 and compareVersions(have, wanted) >= 0:
      continue

    var archive: string
    if have.len == 0:
      archive = localArchive(pkg, wanted)
    elif includeStaleInstalled:
      archive = localArchive(pkg, wanted)
      if archive.len == 0:
        archive = fetchArchive(pkg, wanted)
    if archive.len == 0:
      continue

    result.add(SandboxArchiveDep(package: pkg, version: wanted,
        archive: archive))

proc sandboxRepoRunfile(pkg: string, targetArch: string,
        cache: var Table[string, runFile]): runFile =
  ## Metadata of a package's repository recipe; empty when it has none.
  ##
  ## parseRunfile() exits the process on a broken or absent runfile, so the
  ## recipe file is checked before it is parsed.
  if cache.hasKey(pkg):
    return cache[pkg]
  var rf = runFile(isParsed: false)
  try:
    let repo = findPkgRepo(pkg)
    if repo.len > 0 and (fileExists(repo & "/" & pkg & "/run") or
        fileExists(repo & "/" & pkg & "/run3")):
      rf = parseRunfile(repo & "/" & pkg, arch = targetArch)
  except CatchableError:
    debug "sandbox: could not parse the recipe for " & pkg & ": " &
        getCurrentExceptionMsg()
  cache[pkg] = rf
  return rf

proc removeCopiedFiles(installRoot: string, files: seq[string]) =
  ## Drop the payload of the superseded root copy from the sandbox: files the
  ## new version does not ship would otherwise stay next to it. Directories are
  ## kept, they hold nothing of the old version once its files are gone.
  let base = normalizedPath(absolutePath(installRoot))
  for rel in files:
    if rel.len == 0 or rel.isAbsolute:
      continue
    let path = normalizedPath(base / rel)
    # The list comes from the build root's database, so a `..` entry must not
    # reach outside the overlay.
    if path == base or not path.startsWith(base & "/"):
      continue
    if symlinkExists(path) or fileExists(path):
      removeFile(path)

proc applySandboxArchiveDeps*(plan: seq[SandboxArchiveDep],
        installRoot, kTarget, targetArch: string,
        repoOf: proc(pkg: string): string,
        copiedFiles: proc(pkg: string): seq[string] = nil): seq[string] =
  ## Install planned dependencies from their archives into installRoot.
  ##
  ## installRoot is the overlay upper dir of the build, never the host: the
  ## packages must be visible to this build (and to the dependency metadata
  ## written into its archive) only. copiedFiles returns the files the root
  ## copy of a package wrote there, so an upgrade replaces it instead of
  ## accumulating next to it.
  for dep in plan:
    # The copied old version is the only copy in the sandbox, so the archive is
    # proved readable before anything is touched.
    if not archiveUsable(dep.archive):
      warn "sandbox: keeping the old copy of " & dep.package & ": archive " &
          dep.archive & " is corrupt or truncated"
      continue
    info "sandbox: installing " & dep.package & "-" & dep.version &
        " from its archive"
    let stale = if copiedFiles.isNil: @[] else: copiedFiles(dep.package)
    # Postinstall hooks run for every sandbox dependency in the merged overlay
    # where the environment libraries are visible; defer them here.
    try:
      installPkg(repoOf(dep.package), dep.package, installRoot,
          manualInstallList = @[], kTarget = kTarget, tarballPath = dep.archive,
          ignorePostInstall = true, deferPostInstall = true,
          targetArch = targetArch, keepTransaction = true)
    except CatchableError:
      warn "sandbox: could not install " & dep.package & "-" & dep.version &
          " from " & dep.archive & ": " & getCurrentExceptionMsg()
      continue
    # Drop what the superseded copy shipped and the new version does not: the
    # copy registers package metadata without file rows, so the installer
    # cannot find the old version's files itself.
    let fresh = getListFiles(dep.package, installRoot)
    removeCopiedFiles(installRoot, stale.filterIt(it notin fresh))
    result.add(dep.package)

proc installSandboxArchiveDeps*(pkgName: string, copiedDeps: seq[string],
        sandboxCfg: SandboxConfig, kTarget: string,
        includeStaleInstalled = true,
        skip: seq[string] = @[]): seq[string] =
  ## Install the dependencies the root copy cannot provide correctly from their
  ## archives into the overlay upper dir, and return the packages installed.
  ##
  ## The build root is only read, so the host installation is never touched.
  ## Packages in `skip` are installed by dedicated paths elsewhere in the
  ## sandbox and must not be touched here.
  let root = sandboxCfg.root
  let targetArch = archNameFromTarget(sandboxCfg.sandboxTarget)
  let binrepos = getConfigValue("Repositories", "binRepos").split(" ")
  # A source build only downloads a dependency binary when the run asked for
  # binary packages.
  let useBinaries = sandboxCfg.binCache and
      binrepos.filterIt(it.len > 0).len > 0

  var recipes = initTable[string, runFile]()

  proc installedVersion(pkg: string): string =
    try:
      if packageExists(pkg, root):
        return getPackage(pkg, root).version
    except CatchableError:
      debug "sandbox: could not read the installed version of " & pkg
    return ""

  proc recipeVersion(pkg: string): string =
    let rf = sandboxRepoRunfile(pkg, targetArch, recipes)
    # A group has no archive of its own, only its members do.
    if not rf.isParsed or rf.isGroup or rf.versionString.len == 0:
      return ""
    return rf.versionString

  proc localArchive(pkg, version: string): string =
    let path = archivePathFor(pkg, version, kTarget)
    if fileExists(path):
      return path
    return ""

  proc fetchArchive(pkg, version: string): string =
    if not useBinaries:
      info "sandbox: no local archive of " & pkg & "-" & version &
          ", keeping the older copy from the build root (binary packages are " &
          "not enabled for this build)"
      return ""
    info "sandbox: fetching " & pkg & "-" & version & " from a binary repository"
    down_bin(pkg, binrepos, kpkgEnvPath, offline = false,
        ignoreDownloadErrors = true, kTarget = kTarget, version = version)
    return localArchive(pkg, version)

  var excluded = initHashSet[string]()
  for name in skip & @[pkgName]:
    excluded.incl(dependencyName(name))

  var candidates = copiedDeps
  # A package built earlier in this run is installed nowhere when the caller
  # asked for --dontInstall, so the installed closure cannot list it and the
  # declared dependency closure is the only way to find it. Without that flag
  # every dependency reaches the root during this run, and parsing every recipe
  # again would only be wasted work.
  if sandboxCfg.dontInstall:
    try:
      for dep in collectDynamicSandboxDeps(pkgName,
          proc(pkg: string): runFile = sandboxRepoRunfile(pkg, targetArch,
              recipes)):
        candidates.add(dep)
    except CatchableError:
      debug "sandbox: could not resolve the declared dependencies of " & pkgName

  candidates.keepItIf(dependencyName(it) notin excluded)

  let plan = planSandboxArchiveDeps(candidates, installedVersion,
      recipeVersion, localArchive, fetchArchive, includeStaleInstalled)

  # The installed closure is already in the sandbox by the time this runs, so
  # read the superseded files from the build root first: switching back and
  # forth between the two databases for every package is wasteful.
  var staleFiles = initTable[string, seq[string]]()
  for dep in plan:
    if packageExists(dep.package, root):
      staleFiles[dep.package] = getListFiles(dep.package, root)

  return applySandboxArchiveDeps(plan, kpkgOverlayPath & "/upperDir", kTarget,
      targetArch, findPkgRepo,
      proc(pkg: string): seq[string] = staleFiles.getOrDefault(pkg, @[]))

proc buildPackageInSandboxImpl(pkgName: string, depGraph: dependencyGraph,
                            sandboxCfg: SandboxConfig,
                            builderProc: BuilderProc,
                            installPkgProc: InstallPkgProc): seq[string] =
  ## Sets up sandbox for a single package and builds it.
  ##
  ## Handles overlay mount, dependency installation, postinstall, ldconfig.
  ##
  ## Parameters:
  ##   pkgName: Package name to build
  ##   depGraph: Pre-computed dependency graph
  ##   sandboxCfg: Sandbox configuration
  ##   builderProc: Callback to builder() function
  ##   installPkgProc: Callback for installing packages to overlay

  let pkgTmp = parsePkgInfo(pkgName)

  if sandboxCfg.noSandbox:
    # The root itself (a chroot or seed image) is the isolation boundary.
    # There is no kpkg env to create: createEnv() copies the host system into
    # the sandbox by reading the kpkg SQLite DB, which cannot work on a
    # foreign host and is unnecessary when we already have a populated root.
    debug "noSandbox: skipping sandbox env creation for " & pkgName
  else:
    createOrUpgradeEnv(sandboxCfg.root,
        deferPostInstall = sandboxCfg.deferPostInstall,
        target = sandboxCfg.sandboxTarget)
    # createEnv copies packages installed in the host root. A requested native
    # init variant may not be installed there, so complete the persistent
    # sandbox from that target's binary repository.
    let profileExclusions = @[pkgTmp.name]
    let targetPackages = targetSandboxPackages(sandboxCfg.sandboxTarget,
        sandboxCfg.root, profileExclusions)
    if targetPackages.len > 0:
      # Resolve runtime dependencies as well: installPkg only extracts a cached
      # archive and neither downloads it nor installs its dependency closure.
      let variantDeps = dephandler(targetPackages, root = kpkgEnvPath,
              targetArch = archNameFromTarget(sandboxCfg.sandboxTarget))
      let missingVariantDeps = variantDeps.filterIt(
          not isEmptyOrWhitespace(it) and not packageExists(it, kpkgEnvPath))
      if missingVariantDeps.len > 0:
        # Do not publish a partly converted sandbox as reusable. Source-profile
        # packages are removed only after every target archive is available.
        invalidateEnvSetup(kpkgEnvPath)
        let desiredProfile = sandboxProfileForTarget(sandboxCfg.sandboxTarget,
            sandboxCfg.root)
        let conversion = RootfsPlan(profile: desiredProfile,
          mode: rmSeeded, acquire: missingVariantDeps,
          remove: targetSandboxReplacedPackages(sandboxCfg.sandboxTarget,
            sandboxCfg.root, profileExclusions),
          install: missingVariantDeps, exclusions: profileExclusions)
        try:
          rootfsProvision.provision(conversion,
            proc(package, target: string) =
              down_bin(package,
                getConfigValue("Repositories", "binRepos").split(" "),
                kpkgEnvPath, offline = false, kTarget = target),
            proc(package: string) =
              if packageExists(package, kpkgEnvPath):
                removeInternal(package, kpkgEnvPath, initCheck = false),
            proc(package: string) =
              installPkgProc(InstallConfig(repo: findPkgRepo(package),
                package: package, root: kpkgEnvPath, isUpgrade: false,
                kTarget: sandboxCfg.sandboxTarget, manualInstallList: @[],
                disablePkgInfo: false, ignorePostInstall: true,
                deferPostInstall: sandboxCfg.deferPostInstall,
                targetArch: archNameFromTarget(sandboxCfg.sandboxTarget))),
            proc(phase: ProvisionPhase, pending, completed: seq[string]) =
              markEnvProvisioning(kpkgEnvPath, phase, pending, completed))
        except CatchableError:
          markEnvFailed(kpkgEnvPath, "profile_conversion")
          raise
      # Variant installation deliberately skips hooks here. Publish readiness
      # only after profile links/finalizers are complete.
      if sandboxCfg.deferPostInstall:
        markEnvDeferred(kpkgEnvPath)
      else:
        let desiredProfile = sandboxProfileForTarget(sandboxCfg.sandboxTarget,
            sandboxCfg.root)
        let excludedIdentity = profileExclusions.anyIt(it in
            rootfsProfile.sourceProfileRoots(desiredProfile))
        if excludedIdentity:
          markEnvProvisioning(kpkgEnvPath, rpInstalling, profileExclusions)
        else:
          rootfsFinalize.finalizeProfileLinks(kpkgEnvPath, desiredProfile)
          markEnvReady(kpkgEnvPath)


  # Extract sandbox dependencies from the graph
  let sandboxDeps = getSandboxDepsFromGraph(pkgTmp.name, depGraph,
          sandboxCfg.bootstrap, sandboxCfg.fullRootPath,
          sandboxCfg.forceInstallAll, sandboxCfg.isInstallDir,
          sandboxCfg.ignoreInit, archNameFromTarget(sandboxCfg.sandboxTarget))

  debug "sandboxDeps for " & pkgTmp.name & " = \"" & sandboxDeps.join(" ") & "\""
  var allInstalledDeps: seq[string]



  # Resolve kTarget for tarball lookup — matches how the builder stores tarballs
  let sandboxKTarget = if sandboxCfg.target == "default" or sandboxCfg.target ==
      kpkgTarget("/"):
    kpkgTarget(sandboxCfg.fullRootPath)
  else:
    sandboxCfg.target

  var overlayMounted = false
  if not sandboxCfg.noSandbox:
    # Prepare the tmpfs backing the overlay.  This procedure owns the entire
    # mount lifetime from this point onward, including dependency installation,
    # overlay mounting, package execution, and early returns.
    let prepareResult = prepareOverlayDirs()
    if prepareResult != 0:
      fatal("preparing overlay directories failed")

    if isCrossTarget(sandboxCfg.target, sandboxCfg.root):
      for d in sandboxDeps:
        if isEmptyOrWhitespace(d):
          continue

        debug "buildPackageInSandbox: installPkg ran for '" & d & "'"
        let installCfg = InstallConfig(
          repo: findPkgRepo(d),
          package: d,
          root: kpkgOverlayPath & "/upperDir",
          isUpgrade: false,
          kTarget: sandboxKTarget,
          manualInstallList: @[],
          disablePkgInfo: true,
          deferPostInstall: sandboxCfg.deferPostInstall,
          targetArch: archNameFromTarget(sandboxCfg.sandboxTarget)
        )
        installPkgProc(installCfg)

      # Target-arch dependencies built earlier in this run are installed
      # nowhere yet, so complete the sandbox from their local archives.
      discard installSandboxArchiveDeps(pkgTmp.name, sandboxDeps, sandboxCfg,
          sandboxKTarget, includeStaleInstalled = false,
          skip = sandboxCfg.rebuiltConsumers &
              @[sandboxCfg.sonameChangedPackage])
    else:
      # Resolve all direct roots first, then copy their union closure once.
      var installRoots = sandboxDeps

      # If the package isn't in the dep graph (e.g. dynamically added consumer),
      # resolve its direct build deps and runtime closure from runfile metadata.
      if sandboxDeps.len == 0:
        try:
          let dynamicDeps = collectDynamicSandboxDeps(pkgTmp.name,
              proc(pkg: string): runFile =
            parseRunfile(findPkgRepo(pkg) & "/" & pkg))
          for dep in dynamicDeps:
            if packageExists(dep, sandboxCfg.root):
              debug "buildPackageInSandbox: adding dynamic sandbox dep '" &
                  dep & "' for '" & pkgTmp.name & "'"
              installRoots.add(dep)
        except:
          debug "buildPackageInSandbox: could not resolve dynamic sandbox deps for '" &
              pkgTmp.name & "'"

      allInstalledDeps = installFromRoot(installRoots, sandboxCfg.root,
              kpkgOverlayPath & "/upperDir", ignorePostInstall = true)

      # The root copy freezes a dependency at whatever version the root has and
      # cannot provide one that is installed nowhere. Replace those from their
      # archives so the sandbox matches the recipes the build is made against.
      allInstalledDeps = allInstalledDeps & installSandboxArchiveDeps(
              pkgTmp.name, allInstalledDeps, sandboxCfg, sandboxKTarget,
              skip = sandboxCfg.rebuiltConsumers &
                  @[sandboxCfg.sonameChangedPackage])

      # Install the package with changed SONAME into the env so consumers
      # build against the new library version. The env is the overlay lower
      # dir — installing there replaces the old library entirely, making
      # pkg-config and the linker find only the new version.
      if sandboxCfg.sonameChangedPackage != "":
        debug "buildPackageInSandbox: installing changed soname package '" &
            sandboxCfg.sonameChangedPackage & "' to env"
        installPkg(findPkgRepo(sandboxCfg.sonameChangedPackage),
                sandboxCfg.sonameChangedPackage, kpkgEnvPath,
                kTarget = sandboxKTarget, manualInstallList = @[],
                ignorePostInstall = true,
                deferPostInstall = sandboxCfg.deferPostInstall,
                targetArch = archNameFromTarget(sandboxCfg.sandboxTarget))
      # Install rebuilt consumers to upperDir so subsequent builds get updated libs/binaries
      for r in sandboxCfg.rebuiltConsumers:
        if r != pkgName:
          debug "buildPackageInSandbox: installing rebuilt consumer '" & r & "' to overlay"
          installPkgProc(InstallConfig(
            repo: findPkgRepo(r),
            package: r,
            root: kpkgOverlayPath & "/upperDir",
            isUpgrade: false,
            kTarget: sandboxKTarget,
            manualInstallList: @[],
            disablePkgInfo: true,
            ignorePostInstall: true,
            deferPostInstall: sandboxCfg.deferPostInstall,
            targetArch: archNameFromTarget(sandboxCfg.sandboxTarget)
          ))

    # Mount the overlayfs after dependencies are installed.
    let mountResult = mountOverlayFilesystem()
    if mountResult != 0:
      fatal("mounting overlay filesystem failed")

    # Rebuild the loader cache before any postinstall hook runs. Dependencies
    # were just copied into the overlay upper dir, so the cache inherited from
    # the env lower dir does not list them yet: a postinstall that executes a
    # freshly-installed binary fails with "cannot open shared object file"
    # (e.g. json-glib runs glib-compile-schemas, which needs libgio).
    discard runLdconfig(kpkgMergedPath, silentMode = true)

    # Run postinstall scripts in merged overlay
    if shouldRunSandboxPostInstall(sandboxCfg.deferPostInstall,
        sandboxCfg.ignorePostInstall) and
        not isCrossTarget(sandboxCfg.target, sandboxCfg.root):
      debug "builder-ng: postinstall is running"
      for d in deduplicate(allInstalledDeps):
        if not isEmptyOrWhitespace(d):
          runPostInstall(d)

    # Postinstall hooks can install further libraries; refresh once more so the
    # package's own build steps and the final root see a consistent cache.
    discard runLdconfig(kpkgMergedPath, silentMode = true)
    overlayMounted = true
  else:
    # No overlay and no env: the root itself is the isolation boundary. Build
    # dependencies were installed into the root by earlier iterations of the
    # build queue, so only their postinstall scripts and ldconfig are missing.
    var visited = initHashSet[string]()
    allInstalledDeps = deduplicate(collectRuntimeDepsFromGraph(
            sandboxDeps, depGraph, visited))

    if shouldRunSandboxPostInstall(sandboxCfg.deferPostInstall,
        sandboxCfg.ignorePostInstall):
      for d in allInstalledDeps:
        if not isEmptyOrWhitespace(d):
          runPostInstall(d, sandboxCfg.root, passthrough = true)

    discard runLdconfig(sandboxCfg.root, silentMode = true)

  let packageSplit = parsePkgInfo(pkgName)

  # Determine if this is a bootstrap build
  let isBootstrapBuild = sandboxCfg.bootstrap and depGraph.nodes.hasKey(pkgTmp.name) and
          depGraph.nodes[pkgTmp.name].metadata.bsdeps.len > 0

  var customRepo = ""
  var isInstallDirFinal = false
  var actualPkgName: string

  # Try to get repo from graph first
  if depGraph.nodes.hasKey(pkgTmp.name):
    let r = depGraph.nodes[pkgTmp.name].repo
    if r != "local" and r.startsWith("/etc/kpkg/repos/"):
      customRepo = lastPathPart(r)

  if sandboxCfg.isInstallDir and sandboxCfg.pkgPaths.hasKey(pkgTmp.name):
    actualPkgName = sandboxCfg.pkgPaths[pkgTmp.name]
    isInstallDirFinal = true
  else:
    if "/" in packageSplit.nameWithRepo:
      customRepo = lastPathPart(packageSplit.repo)
      actualPkgName = packageSplit.name
    else:
      actualPkgName = packageSplit.name

  if isBootstrapBuild:
    info("Performing bootstrap build for " & pkgName)

  # Create BuildConfig for this package
  var buildCfg = BuildConfig(
    package: actualPkgName,
    destdir: sandboxCfg.fullRootPath,
    offline: false,
    dontInstall: sandboxCfg.dontInstall,
    useCacheIfAvailable: sandboxCfg.useCacheIfAvailable,
    binCache: sandboxCfg.binCache,
    tests: sandboxCfg.tests,
    manualInstallList: sandboxCfg.manualInstallList,
    customRepo: customRepo,
    isInstallDir: isInstallDirFinal,
    isUpgrade: sandboxCfg.isUpgrade,
    target: sandboxCfg.target,
    actualRoot: sandboxCfg.root,
    ignorePostInstall: sandboxCfg.ignorePostInstall,
    deferPostInstall: sandboxCfg.deferPostInstall,
    noSandbox: sandboxCfg.noSandbox,
    ignoreTarget: false,
    ignoreUseCacheIfAvailable: sandboxCfg.ignoreUseCacheIfAvailable,
    isBootstrap: isBootstrapBuild,
    skipHostInstall: true
  )

  discard builderProc(buildCfg)

  # Install to host if not a SONAME-changed package, so rebuilt
  # consumers replace the old system binaries. An explicit target that
  # matches the root's own target is the noSandbox bootstrap case: the
  # root is the target system and the package must be installed there.
  #
  # Exception: the libc itself (glibc, musl, ...). Installing it replaces
  # the libc the build environment is running on - fatal on a foreign
  # bootstrap root regardless of which libc it is (glibc kills processes
  # with GLIBC_PRIVATE mismatches; musl swaps the entire userspace). The
  # rootfs gets its libc through the buildDir install instead.
  if actualPkgName != getLibc(sandboxCfg.root).toLowerAscii() and
      not buildCfg.sonameChanged and not sandboxCfg.dontInstall and
      (sandboxCfg.target == "default" or
       sandboxCfg.target == kpkgTarget(sandboxCfg.root)):
    debug "buildPackageInSandbox: installing " & actualPkgName & " to host"
    let archivePath = if isBootstrapBuild:
      cacheArchivePath(actualPkgName, depGraph.nodes[pkgTmp.name].metadata,
          sandboxKTarget, isBootstrap = true)
    else:
      ""
    installPkg(findPkgRepo(actualPkgName), actualPkgName,
            sandboxCfg.fullRootPath,
            manualInstallList = @[], kTarget = sandboxKTarget,
            ignorePostInstall = true,
            deferPostInstall = sandboxCfg.deferPostInstall,
            tarballPath = archivePath,
            targetArch = archNameFromTarget(sandboxCfg.sandboxTarget))

  if overlayMounted:
    let cleanupResult = umountOverlay(silentMode = true)
    if cleanupResult != 0:
      fatal("internal: sandbox overlay remained mounted")

  if buildCfg.sonameChanged:
    return buildCfg.consumersToRebuild

  info("built " & pkgName & " successfully")

proc buildPackageInSandbox*(pkgName: string, depGraph: dependencyGraph,
                             sandboxCfg: SandboxConfig,
                             builderProc: BuilderProc,
                             installPkgProc: InstallPkgProc): seq[string] =
  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if sandboxCfg.fullRootPath ==
      "": "/" else: sandboxCfg.fullRootPath)
  assertNoAbandonedHistory(if sandboxCfg.root == "": "/" else: sandboxCfg.root)
  assertNoAbandonedHistory(kpkgEnvPath)
  assertNoAbandonedHistory(kpkgOverlayPath & "/upperDir")

  telemetry.withSpan("kpkg.sandbox.lifecycle", {
    "package.name": parsePkgInfo(pkgName).name,
    "package.bootstrap": $sandboxCfg.bootstrap
  }.toTable):
    return buildPackageInSandboxImpl(pkgName, depGraph, sandboxCfg, builderProc,
        installPkgProc)


proc buildAllPackagesInSandbox*(deps: var seq[string], depGraph: dependencyGraph,
                                sandboxCfg: var SandboxConfig,
                                builderProc: BuilderProc,
                                installPkgProc: InstallPkgProc): int =
  ## Iterates over all packages and builds each in sandbox.
  ##
  ## Returns 0 on success.

  createLockfile()
  defer: removeLockfile()
  assertNoAbandonedHistory(if sandboxCfg.fullRootPath ==
      "": "/" else: sandboxCfg.fullRootPath)
  assertNoAbandonedHistory(if sandboxCfg.root == "": "/" else: sandboxCfg.root)
  assertNoAbandonedHistory(kpkgEnvPath)
  assertNoAbandonedHistory(kpkgOverlayPath & "/upperDir")

  var sonameSourceMap = initTable[string, string]()
  var sonameSources: seq[string]
  let sandboxKTarget = if sandboxCfg.target == "default" or sandboxCfg.target ==
      kpkgTarget("/"):
    kpkgTarget(sandboxCfg.fullRootPath)
  else:
    sandboxCfg.target
  var i = 0
  while i < deps.len:
    let pkg = deps[i]
    try:
      if sandboxCfg.binCache and not sandboxCfg.isInstallDir:
        # Prefer a published binary for this dependency. seedBinaryArchive
        # populates the local archive cache that builderImpl() consults, so a
        # hit skips the source build entirely; a miss falls through unchanged.
        try:
          let rf = parseRunfile(findPkgRepo(pkg) & "/" & pkg,
              arch = archNameFromTarget(sandboxCfg.sandboxTarget))
          discard seedBinaryArchive(rf, sandboxKTarget,
              archNameFromTarget(sandboxCfg.sandboxTarget))
        except CatchableError:
          debug "binCache: could not seed binary for " & pkg & ": " &
              getCurrentExceptionMsg()
      sandboxCfg.sonameChangedPackage = sonameSourceMap.getOrDefault(pkg, "")
      if sandboxCfg.sonameChangedPackage != "":
        debug "buildAll: " & pkg & " is SONAME consumer of " &
            sandboxCfg.sonameChangedPackage
      let consumers = buildPackageInSandbox(pkg, depGraph, sandboxCfg,
              builderProc, installPkgProc)
      if consumers.len > 0:
        sonameSources.add(pkg)
        sandboxCfg.rebuiltConsumers.add(pkg)
      elif sonameSourceMap.hasKey(pkg):
        sandboxCfg.rebuiltConsumers.add(pkg)
        debug "buildAll: added rebuilt consumer " & pkg & " to rebuiltConsumers"
      for consumer in consumers:
        if consumer notin deps:
          try:
            let pkgDir = findPkgRepo(consumer) & "/" & consumer
            let rf = parseRunfile(pkgDir)
            # A SONAME consumer is rebuilt from source, so both its declared
            # build and runtime dependencies must be present in the sandbox.
            # Runtime dependencies commonly provide development headers (e.g.
            # nss needs nspr); omitting them makes these dynamic rebuilds use
            # an incomplete environment.
            for dep in rf.bdeps & rf.deps:
              let oldLen = deps.len
              let installedRoot = sandboxCfg.root
              addPackageWithDepsToQueue(deps, dep,
                  proc(pkg: string): seq[string] =
                try:
                  let rf = parseRunfile(findPkgRepo(pkg) & "/" & pkg)
                  return rf.bdeps & rf.deps
                except CatchableError:
                  debug "could not resolve deps for dynamic consumer dependency " & pkg
                  return @[],
                  proc(pkg: string): bool = packageExists(pkg, installedRoot))

              for j in oldLen ..< deps.len:
                if deps[j] == dep:
                  info "Added " & dep & " (dependency) to queue for consumer " & consumer
                else:
                  info "Added " & deps[j] &
                      " (transitive dependency) to queue for consumer " & consumer
          except:
            debug "could not resolve bdeps for consumer " & consumer
          deps.add(consumer)
          sonameSourceMap[consumer] = pkg
          sandboxCfg.ignoreUseCacheIfAvailable.add(consumer)
          info "Added " & consumer & " to build queue (SONAME consumer rebuild)"
    except CatchableError:
      # Report which package failed and why. Swallowing the message made
      # release builds abort with a bare "Undefined error occured", which
      # gives nothing to act on.
      when defined(release):
        fatal("build of " & pkg & " failed: " & getCurrentExceptionMsg())
      else:
        raise getCurrentException()
    i.inc

  info("built all packages successfully")

  # Install SONAME-changed source packages to host after all consumers
  # are rebuilt. This provides the new library version (e.g. libssl.so.4)
  # that rebuilt consumers link against.
  for src in sonameSources:
    info "Installing SONAME-changed package '" & src & "' to host"
    installPkg(findPkgRepo(src), src, sandboxCfg.fullRootPath,
            manualInstallList = @[], kTarget = sandboxKTarget,
            isUpgrade = true, ignorePostInstall = true,
            deferPostInstall = sandboxCfg.deferPostInstall,
            targetArch = archNameFromTarget(sandboxCfg.sandboxTarget))

  return 0
