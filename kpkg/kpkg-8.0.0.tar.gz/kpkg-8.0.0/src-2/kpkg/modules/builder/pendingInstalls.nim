#[
  Durable record of host installs a SONAME rebuild defers.

  A provider that drops a SONAME is installed only after its consumers are
  rebuilt, so a run that stops in between leaves it built but uninstalled.
  The next kpkg run installs it and rebuilds whatever still needs the old
  SONAMEs, or reports why it cannot.
]#
import std/[json, os, posix, strutils]
import ../commonPaths
import ../versioncmp
import ../../../common/logging

const
  pendingInstallsSchema* = 1
  ## Overrides the store location (tests only).
  pendingInstallsEnvVar* = "KPKG_PENDING_INSTALLS"
  pendingInstallsReasonSoname* = "soname"

type
  PendingInstall* = object
    ## One install a previous run built but did not install.
    package*: string ## Package the deferred install belongs to
    version*: string ## versionString of the built archive
    kTarget*: string ## Target the archive was built for
    root*: string ## Installation root the deferred install targets
    archive*: string ## Archive to install
    reason*: string ## Why the install was deferred
    sonames*: seq[string] ## SONAMEs the new build drops
    consumers*: seq[string] ## Consumers queued for rebuild when deferred
    installed*: bool ## Archive installed, consumer rebuilds outstanding
    recordedAt*: float

  PendingInstalls* = object
    entries*: seq[PendingInstall]

  PendingAction* = enum
    paForgotten ## Nothing left to do: installed and nothing depends on the old SONAMEs
    paRebuild ## Installed, but installed packages still need the removed SONAMEs
    paInstall ## Archive is present and the root still wants it
    paHold ## Cannot complete now

  PlannedInstall* = object
    ## A record that can be installed now, with the packages it affects.
    entry*: PendingInstall
    affected*: seq[string]

  PendingHooks* = object
    ## Real-world operations the completion policy needs; tests inject fakes.
    installedVersion*: proc(package, root: string): string
    recipePresent*: proc(package: string): bool
    rebuildable*: proc(package: string): bool
    archiveUsable*: proc(entry: PendingInstall): bool
    installPackage*: proc(entry: PendingInstall): bool
    affectedConsumers*: proc(entry: PendingInstall): seq[string]

  PendingPlan* = object
    ## What a run has to do about the deferred installs of its root.
    toInstall*: seq[PlannedInstall] ## Archives to install in this run
    rebuild*: seq[string] ## Packages this run must rebuild
    held*: seq[PendingInstall] ## Still pending, with the reason logged
    outstanding*: seq[PendingInstall] ## Installed, consumer rebuild outstanding
    otherRoots*: seq[PendingInstall] ## Pending for a different root

  PendingCompletion* = object
    installed*: seq[PendingInstall] ## Installed by this call
    failed*: seq[PendingInstall] ## Install attempted and failed

proc canonicalRoot*(root: string): string =
  ## Absolute installation root with symlinks resolved, so a record written for
  ## one spelling of the root matches every later run.
  let base = if root.len == 0: "/" else: root
  if dirExists(base):
    return expandFilename(base)
  return normalizedPath(absolutePath(base))

proc pendingInstallsStore*(): string =
  ## Host-side store of deferred installs.
  let override = getEnv(pendingInstallsEnvVar)
  if override.len > 0:
    return override
  return kpkgLibDir & "/pending-installs.json"

proc publish(path, content: string) =
  ## Publish `content` at `path` so a reader never sees a partial file.
  createDir(parentDir(path))
  let temporary = path & ".partial-" & $getpid()
  # A failed write leaves a stale temp file; the rename removes it otherwise.
  defer:
    if fileExists(temporary):
      removeFile(temporary)
  let fd = posix.open(temporary.cstring,
      O_CREAT or O_WRONLY or O_TRUNC, Mode(0o600))
  if fd < 0:
    raise newException(IOError, "cannot open " & temporary & " for writing")
  var payload = content
  if payload.len > 0 and posix.write(fd, addr payload[0], payload.len) !=
      payload.len:
    discard posix.close(fd)
    raise newException(IOError, "cannot write " & temporary)
  if fsync(fd) != 0:
    discard posix.close(fd)
    raise newException(IOError, "cannot sync " & temporary)
  discard posix.close(fd)
  moveFile(temporary, path)
  # Sync the directory as well, so the rename itself survives a power loss.
  let directory = posix.open(parentDir(path).cstring, O_RDONLY)
  if directory >= 0:
    discard fsync(directory)
    discard posix.close(directory)

proc validPackageName(name: string): bool =
  ## Recipe directory names only: no separators, no traversal.
  if name.len == 0 or name.startsWith(".") or name.contains('/'):
    return false
  for c in name:
    if c notin {'a'..'z', 'A'..'Z', '0'..'9', '_', '-', '+', '.', '@'}:
      return false
  return true

proc toJson*(pending: PendingInstalls): JsonNode =
  result = %*{"version": pendingInstallsSchema, "entries": []}
  for entry in pending.entries:
    result["entries"].add(%*{
      "package": entry.package,
      "version": entry.version,
      "kTarget": entry.kTarget,
      "root": entry.root,
      "archive": entry.archive,
      "reason": entry.reason,
      "sonames": entry.sonames,
      "consumers": entry.consumers,
      "installed": entry.installed,
      "recordedAt": entry.recordedAt
    })

proc schemaVersion(node: JsonNode): int =
  ## The store's schema version; 0 for a store written without the field.
  if node.kind == JObject and node.hasKey("version") and
      node["version"].kind == JInt:
    return node["version"].getInt()
  return 0

proc parseEntry(item: JsonNode): PendingInstall =
  ## One entry of the store; raises when a required field is unreadable.
  if item.kind != JObject:
    raise newException(ValueError, "entry is not an object")
  result = PendingInstall(
    package: item{"package"}.getStr(),
    version: item{"version"}.getStr(),
    kTarget: item{"kTarget"}.getStr(),
    root: item{"root"}.getStr(),
    archive: item{"archive"}.getStr(),
    reason: item{"reason"}.getStr(),
    recordedAt: item{"recordedAt"}.getFloat())
  if item.hasKey("installed") and item["installed"].kind == JBool:
    result.installed = item["installed"].getBool()
  if item.hasKey("sonames") and item["sonames"].kind == JArray:
    for soname in item["sonames"]:
      result.sonames.add(soname.getStr())
  if item.hasKey("consumers") and item["consumers"].kind == JArray:
    for consumer in item["consumers"]:
      result.consumers.add(consumer.getStr())

proc fromJson(node: JsonNode): PendingInstalls =
  if node.kind != JObject or not node.hasKey("entries") or
      node["entries"].kind != JArray:
    raise newException(ValueError, "not a pending install record")
  for item in node["entries"]:
    # One broken entry must not discard the records of every other root.
    var entry: PendingInstall
    try:
      entry = parseEntry(item)
    except CatchableError:
      warn "ignoring unreadable deferred install record (" &
          getCurrentExceptionMsg() & ")"
      continue
    # A hand-edited or foreign store must never steer an install: the package
    # becomes a repository path and the archive is installed as root.
    if not validPackageName(entry.package) or not entry.root.isAbsolute or
        (entry.archive.len > 0 and not entry.archive.isAbsolute):
      warn "ignoring invalid deferred install record for '" & entry.package & "'"
      continue
    result.entries.add(entry)

proc loadPendingInstalls*(store = pendingInstallsStore()): PendingInstalls =
  ## Read the store. A missing store is empty; an unreadable one is kept aside
  ## and ignored rather than aborting the build.
  if not fileExists(store):
    return PendingInstalls(entries: @[])
  try:
    let node = parseJson(readFile(store))
    let version = schemaVersion(node)
    if version != pendingInstallsSchema:
      warn "deferred install record '" & store & "' has schema version " &
          $version & ", reading it as " & $pendingInstallsSchema
    return fromJson(node)
  except CatchableError:
    warn "unreadable deferred install record '" & store & "' (" &
        getCurrentExceptionMsg() & "); moved to '" & store & ".corrupt'"
    try:
      moveFile(store, store & ".corrupt")
    except CatchableError:
      discard
    return PendingInstalls(entries: @[])

proc savePendingInstalls*(pending: PendingInstalls,
    store = pendingInstallsStore()) =
  publish(store, $(pending.toJson()))

proc findPendingInstall*(pending: PendingInstalls, package, root: string): int =
  ## Index of the record for `package` at `root`, or -1.
  for i, entry in pending.entries:
    if entry.package == package and entry.root == root:
      return i
  return -1

proc withStoreLock[T](store: string, body: proc(): T): T =
  ## Serialise one read-modify-write of the store.
  ##
  ## Each call takes the lock for its own load/save pair, never across the
  ## package prompt, so two kpkg runs cannot drop or resurrect a record.
  let lockPath = store & ".lock"
  createDir(parentDir(lockPath))
  let fd = posix.open(lockPath.cstring, O_CREAT or O_RDWR, Mode(0o600))
  var lock = Tflock(l_type: cshort(F_WRLCK), l_whence: cshort(SEEK_SET),
      l_start: Off(0), l_len: Off(0))
  try:
    if fd >= 0:
      discard fcntl(fd, F_SETLKW, addr lock)
    result = body()
  finally:
    if fd >= 0:
      lock.l_type = cshort(F_UNLCK)
      discard fcntl(fd, F_SETLK, addr lock)
      discard posix.close(fd)

proc upsertPendingInstall*(entry: PendingInstall,
    store = pendingInstallsStore()) =
  ## Record a deferred install, replacing an older record of the same package.
  discard withStoreLock(store, proc(): bool =
    var pending = loadPendingInstalls(store)
    let index = findPendingInstall(pending, entry.package, entry.root)
    if index >= 0:
      pending.entries[index] = entry
    else:
      pending.entries.add(entry)
    savePendingInstalls(pending, store)
    return true)

proc forgetPendingInstall*(package, root: string,
    store = pendingInstallsStore()) =
  discard withStoreLock(store, proc(): bool =
    var pending = loadPendingInstalls(store)
    let index = findPendingInstall(pending, package, root)
    if index >= 0:
      pending.entries.delete(index)
      savePendingInstalls(pending, store)
    return true)

proc classifyPending*(entry: PendingInstall, installedVersion: string,
                      archivePresent, rootPresent,
                      consumersOutstanding: bool): PendingAction =
  ## What completing this record would do right now.
  if not rootPresent:
    return paForgotten
  if installedVersion.len > 0 and entry.version.len > 0 and
      compareVersions(installedVersion, entry.version) >= 0:
    return if consumersOutstanding: paRebuild else: paForgotten
  if not archivePresent:
    return paHold
  return paInstall

proc describePending*(entry: PendingInstall): string =
  ## One-line description of a deferred install.
  result = entry.package & " "
  if entry.version.len > 0:
    result.add(entry.version & " ")
  result.add("(root " & entry.root)
  if entry.kTarget.len > 0:
    result.add(", " & entry.kTarget)
  result.add(")")
  if entry.installed:
    result.add(" [installed, consumer rebuild outstanding]")
  elif entry.reason.len > 0:
    result.add(" [" & entry.reason & "]")
  if entry.consumers.len > 0:
    result.add(" consumers: " & entry.consumers.join(", "))

proc addRebuild(result: var seq[string], package: string,
                affected: seq[string]) =
  for consumer in affected:
    if consumer != package and consumer notin result:
      result.add(consumer)

proc holdReason*(entry: PendingInstall, rootPresent, recipePresent,
    archivePresent, archiveUsable: bool, affected: seq[string],
    hooks: PendingHooks): string =
  ## Why a deferred install cannot be completed now.
  if not rootPresent:
    return "root " & entry.root & " does not exist"
  if not recipePresent:
    return entry.package & " has no recipe in the repositories any more"
  if not archivePresent:
    return "archive " & entry.archive & " is missing, rebuild " & entry.package
  if not archiveUsable:
    return "archive " & entry.archive & " is corrupt or truncated, rebuild " &
        entry.package
  var blocked: seq[string]
  for consumer in affected:
    if not hooks.rebuildable.isNil and not hooks.rebuildable(consumer):
      blocked.add(consumer)
  if blocked.len > 0:
    return "cannot be installed: " & blocked.join(", ") &
        " still needs the removed SONAMEs and cannot be rebuilt here"
  return "nothing can be done about it right now"

proc planLocked(canonical: string, hooks: PendingHooks, allowInstall: bool,
    store: string): PendingPlan =
  let pending = loadPendingInstalls(store)
  var kept: seq[PendingInstall]
  var changed = false

  for entry in pending.entries:
    if entry.root != canonical:
      # Another root's record is none of this run's business, but never keep
      # one for a root that is gone for good.
      if dirExists(entry.root):
        result.otherRoots.add(entry)
        kept.add(entry)
      else:
        changed = true
        warn "forgetting deferred install of " & describePending(entry) &
            ": its installation root no longer exists"
      continue

    let rootPresent = dirExists(entry.root)
    # Ask the root only when it exists: opening its database would recreate
    # the directory tree of a root that is gone.
    var installed = ""
    if rootPresent:
      installed = hooks.installedVersion(entry.package, entry.root)
    let satisfied = installed.len > 0 and entry.version.len > 0 and
        compareVersions(installed, entry.version) >= 0
    let recipePresent = hooks.recipePresent(entry.package)
    let archivePresent = entry.archive.len > 0 and fileExists(entry.archive)
    # A corrupt archive must be held, not handed to the installer: a failed
    # install exits the process, or leaves a history marker that refuses every
    # later run.
    var archiveUsable = archivePresent
    if archivePresent and not hooks.archiveUsable.isNil:
      archiveUsable = hooks.archiveUsable(entry)
    # Only scan the installed packages when a rebuild could be outstanding.
    var affected: seq[string]
    if entry.sonames.len > 0 and recipePresent and
        (satisfied or (archiveUsable and allowInstall)):
      affected = hooks.affectedConsumers(entry)
    var updated = entry
    if satisfied and updated.installed != (affected.len > 0):
      updated.installed = affected.len > 0
      changed = true

    # A package without a recipe cannot be installed, however complete the
    # record looks: installPkg resolves the runfile through the repository.
    var action = classifyPending(entry, installed, archiveUsable, rootPresent,
        affected.len > 0)
    if action == paInstall and not recipePresent:
      action = paHold
    if action == paInstall and not hooks.rebuildable.isNil:
      # Installing a provider whose old SONAMEs an unrebuildable consumer still
      # needs would leave that consumer broken for good.
      for consumer in affected:
        if not hooks.rebuildable(consumer):
          action = paHold
          break
    case action
    of paForgotten:
      changed = true
      debug "deferred install of " & entry.package & " is already satisfied"
    of paRebuild:
      result.outstanding.add(updated)
      addRebuild(result.rebuild, entry.package, affected)
      kept.add(updated)
      warn "deferred install of " & entry.package & " " & entry.version &
          " is installed into " & entry.root & ", but these packages still " &
          "need the removed SONAMEs: " & affected.join(", ")
    of paHold:
      kept.add(updated)
      result.held.add(updated)
      warn "deferred install of " & entry.package & " " & entry.version &
          " is still pending: " & holdReason(entry, rootPresent, recipePresent,
              archivePresent, archiveUsable, affected, hooks)
    of paInstall:
      if not allowInstall:
        kept.add(updated)
        result.held.add(updated)
        continue
      result.toInstall.add(PlannedInstall(entry: updated, affected: affected))
      addRebuild(result.rebuild, entry.package, affected)
      kept.add(updated)

  if changed:
    var rewritten = PendingInstalls(entries: @[])
    for entry in kept:
      rewritten.entries.add(entry)
    savePendingInstalls(rewritten, store)

proc planPendingInstalls*(root: string, hooks: PendingHooks,
    allowInstall = true, store = pendingInstallsStore()): PendingPlan =
  ## Classify the deferred installs of `root` and forget the settled ones.
  ##
  ## `allowInstall` false only classifies, which is what a build that must not
  ## touch the root does.
  let canonical = canonicalRoot(root)
  return withStoreLock(store, proc(): PendingPlan =
    planLocked(canonical, hooks, allowInstall, store))

proc applyLocked(canonical: string, plan: PendingPlan, hooks: PendingHooks,
    store: string): PendingCompletion =
  var pending = loadPendingInstalls(store)
  for planned in plan.toInstall:
    var index = findPendingInstall(pending, planned.entry.package, canonical)
    if index < 0:
      continue
    if not hooks.archiveUsable.isNil and not hooks.archiveUsable(planned.entry):
      warn "could not complete deferred install of " & planned.entry.package &
          ": archive " & planned.entry.archive & " is corrupt or truncated"
      result.failed.add(planned.entry)
      continue
    if not hooks.installPackage(planned.entry):
      result.failed.add(planned.entry)
      continue
    result.installed.add(planned.entry)
    # The record keeps the consumer rebuilds it still owes; dropping it here
    # would lose them if this run stops before the rebuilds happen.
    if planned.affected.len > 0:
      pending.entries[index].installed = true
    else:
      pending.entries.delete(index)
    info "completed deferred install of " & planned.entry.package & " " &
        planned.entry.version & " into " & planned.entry.root
  savePendingInstalls(pending, store)

proc applyPendingInstalls*(root: string, plan: PendingPlan, hooks: PendingHooks,
    store = pendingInstallsStore()): PendingCompletion =
  ## Install the archives a plan selected and settle their records.
  let canonical = canonicalRoot(root)
  return withStoreLock(store, proc(): PendingCompletion =
    applyLocked(canonical, plan, hooks, store))

proc pendingSummary*(plan: PendingPlan): string =
  ## Report line for a build that has deferred installs outstanding.
  var parts: seq[string]
  for entry in plan.held:
    parts.add(describePending(entry))
  for entry in plan.outstanding:
    parts.add(describePending(entry))
  for entry in plan.otherRoots:
    parts.add(describePending(entry))
  if parts.len == 0:
    return ""
  return parts.join("; ")

proc completePendingInstalls*(root: string, hooks: PendingHooks,
    install = true, store = pendingInstallsStore()): PendingCompletion =
  ## Plan and apply in one step, for callers that do not split the phases.
  let plan = planPendingInstalls(root, hooks, allowInstall = install, store = store)
  if plan.toInstall.len > 0:
    result = applyPendingInstalls(root, plan, hooks, store)
