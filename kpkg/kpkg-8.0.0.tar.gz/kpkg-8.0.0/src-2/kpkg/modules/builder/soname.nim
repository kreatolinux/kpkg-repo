import std/[os, osproc, strutils]
import ../sqlite
import ../../../common/logging
import ../processes

proc parseNeededSonames*(readelfOutput: string): seq[string] =
  for line in readelfOutput.splitLines:
    if "(NEEDED)" notin line:
      continue
    let start = line.find("[")
    let finish = line.find("]", start + 1)
    if start >= 0 and finish > start:
      result.add(line[start + 1 ..< finish])

proc shouldScanElfFile(filePath: string): bool =
  let name = filePath.split('/')[^1]
  return filePath.startsWith("bin/") or
      filePath.startsWith("sbin/") or
      filePath.startsWith("usr/bin/") or
      filePath.startsWith("usr/sbin/") or
      filePath.startsWith("usr/libexec/") or
      ((filePath.startsWith("lib/") or filePath.startsWith("usr/lib/")) and
      ".so" in name)

proc orderSonameConsumers*(consumers: seq[string],
                          depResolver: proc(pkg: string): seq[string]): seq[string] =
  var visiting: seq[string]
  var visited: seq[string]
  var ordered: seq[string]

  proc visit(pkg: string) =
    if pkg in visited:
      return
    if pkg in visiting:
      debug "orderSonameConsumers: dependency cycle at " & pkg
      return

    visiting.add(pkg)
    for dep in depResolver(pkg):
      if dep in consumers:
        visit(dep)
    discard visiting.pop()

    if pkg notin visited:
      visited.add(pkg)
      ordered.add(pkg)

  for consumer in consumers:
    visit(consumer)

  return ordered

proc getNeededSonames*(filePath: string): seq[string] =
  ensureValidCwd()
  let (output, exitCode) = execCmdEx("readelf -d " & quoteShell(filePath) &
      " 2>/dev/null")
  if exitCode != 0:
    return @[]
  return parseNeededSonames(output)

proc getInstalledSonames*(package: string, root: string): seq[string] =
  debug "getInstalledSonames: checking package '" & package & "' at root '" &
      root & "'"
  for filePath in getListFiles(package, root):
    let name = filePath.split('/')[^1]
    if name.startsWith("lib") and ".so." in name:
      debug "getInstalledSonames: found " & name
      result.add(name)
  debug "getInstalledSonames: found " & $result.len & " sonames"

proc getElfRuntimeDependents*(packages: seq[string], root: string,
                             sonames: seq[string] = @[]): seq[string] =
  ## Packages with an ELF file whose DT_NEEDED names one of `sonames`
  ## (default: every library file name `packages` install).
  var changedSonames = sonames
  for package in (if sonames.len > 0: @[] else: packages):
    if not packageExists(package, root):
      continue
    for soname in getInstalledSonames(package, root):
      if soname notin changedSonames:
        changedSonames.add(soname)

  if changedSonames.len == 0:
    debug "getElfRuntimeDependents: no installed sonames found"
    return @[]

  debug "getElfRuntimeDependents: scanning for NEEDED entries: " &
      changedSonames.join(", ")
  for package in getListPackages(root):
    if package in packages:
      continue
    for filePath in getListFiles(package, root):
      if not shouldScanElfFile(filePath):
        continue
      let absolutePath = root / filePath
      if not fileExists(absolutePath) and not symlinkExists(absolutePath):
        continue
      for needed in getNeededSonames(absolutePath):
        if needed in changedSonames:
          debug "getElfRuntimeDependents: " & package & " needs " & needed &
              " via " & filePath
          if package notin result:
            result.add(package)
          break
      if package in result:
        break

  debug "getElfRuntimeDependents: found " & $result.len & " dependents"

proc getBuildSonames*(buildRoot: string): seq[string] =
  debug "getBuildSonames: scanning " & buildRoot
  # Include symlinks: the installed side (getInstalledSonames) lists the
  # libfoo.so.N links too, and walkDirRec yields only regular files by
  # default. Without them every library package looks "changed" and kpkg
  # queues a rebuild of all its consumers.
  for file in walkDirRec(buildRoot, yieldFilter = {pcFile, pcLinkToFile}):
    let name = file.split('/')[^1]
    if name.startsWith("lib") and ".so." in name:
      debug "getBuildSonames: found " & name
      result.add(name)
  debug "getBuildSonames: found " & $result.len & " sonames"

proc parseSoname*(readelfOutput: string): string =
  ## The DT_SONAME of a `readelf -d` dump, or "" when it has none.
  for line in readelfOutput.splitLines:
    if "(SONAME)" notin line:
      continue
    let start = line.find("[")
    let finish = line.find("]", start + 1)
    if start >= 0 and finish > start:
      return line[start + 1 ..< finish]

proc sonameFromFileName*(name: string): string =
  ## Best-effort SONAME for a library file name when it cannot be read from
  ## the ELF header: libfoo.so.1.2400.1 -> libfoo.so.1. "" for anything that
  ## is not a versioned shared library name.
  let i = name.find(".so.")
  if not name.startsWith("lib") or i < 0:
    return ""
  let rest = name[i + 4 .. ^1]
  let major = rest.split('.')[0]
  if major.len == 0 or not major.allCharsInSet(Digits):
    return ""
  return name[0 ..< i + 4] & major

proc sonamesOf*(paths: seq[string]): seq[string] =
  ## The SONAMEs the given library files provide.
  ##
  ## kpkg used to compare library *file names*, so every minor upgrade
  ## (libgtk-4.so.1.2000.4 -> libgtk-4.so.1.2400.1) looked like an ABI break
  ## and queued a rebuild of every consumer -- for gtk4, at-spi2-core or
  ## librsvg that is most of the desktop, WebKitGTK included. Consumers only
  ## care about the DT_SONAME their DT_NEEDED entries name, so compare those.
  ## Symlinks are skipped (they point at a file that is listed too); files
  ## readelf cannot parse fall back to sonameFromFileName.
  for path in paths:
    let name = path.split('/')[^1]
    if not name.startsWith("lib") or ".so" notin name:
      continue
    if symlinkExists(path) or not fileExists(path):
      continue
    var soname = ""
    ensureValidCwd()
    let (output, exitCode) = execCmdEx("readelf -d " & quoteShell(path) &
        " 2>/dev/null")
    if exitCode == 0:
      soname = parseSoname(output)
    if soname.len == 0:
      soname = sonameFromFileName(name)
    if soname.len > 0 and soname notin result:
      result.add(soname)

proc getRemovedSonames*(buildRoot: string, package: string,
                        root: string): seq[string] =
  ## SONAMEs the installed `package` provides that the new build in
  ## `buildRoot` no longer does. Only those can break a consumer; a library
  ## that gains a new SONAME breaks nobody.
  if not packageExists(package, root):
    debug "getRemovedSonames: package not installed"
    return @[]
  var newPaths: seq[string]
  for file in walkDirRec(buildRoot, yieldFilter = {pcFile}):
    newPaths.add(file)
  var oldPaths: seq[string]
  for filePath in getListFiles(package, root):
    oldPaths.add(root / filePath)
  let newSonames = sonamesOf(newPaths)
  let oldSonames = sonamesOf(oldPaths)
  debug "getRemovedSonames: old=" & oldSonames.join(", ") & " new=" &
      newSonames.join(", ")
  for s in oldSonames:
    if s notin newSonames:
      result.add(s)

proc hasSonameChanged*(buildRoot: string, package: string, root: string): bool =
  ## True when the new build drops a SONAME the installed package provides.
  let removed = getRemovedSonames(buildRoot, package, root)
  if removed.len > 0:
    debug "hasSonameChanged: removed " & removed.join(", ")
    return true
  return false
