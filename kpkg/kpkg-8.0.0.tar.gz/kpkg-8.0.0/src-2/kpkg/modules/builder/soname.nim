import std/[os, osproc, strutils, tables]
import ../sqlite
import ../../../common/logging
import ../processes

proc parseNeededSonames*(readelfOutput: string): seq[string] =
  for line in readelfOutput.splitLines:
    if "(NEEDED)" notin line:
      continue
    let start = line.find("[")
    let finish = line.find("]", start + 1)
    if start >= 0 and finish > start:
      result.add(line[start + 1 ..< finish])

proc shouldScanElfFile(filePath: string): bool =
  let name = filePath.split('/')[^1]
  return filePath.startsWith("bin/") or
      filePath.startsWith("sbin/") or
      filePath.startsWith("usr/bin/") or
      filePath.startsWith("usr/sbin/") or
      filePath.startsWith("usr/libexec/") or
      ((filePath.startsWith("lib/") or filePath.startsWith("usr/lib/")) and
      ".so" in name)

proc orderSonameConsumers*(consumers: seq[string],
                          depResolver: proc(pkg: string): seq[string]): seq[string] =
  var visiting: seq[string]
  var visited: seq[string]
  var ordered: seq[string]

  proc visit(pkg: string) =
    if pkg in visited:
      return
    if pkg in visiting:
      debug "orderSonameConsumers: dependency cycle at " & pkg
      return

    visiting.add(pkg)
    for dep in depResolver(pkg):
      if dep in consumers:
        visit(dep)
    discard visiting.pop()

    if pkg notin visited:
      visited.add(pkg)
      ordered.add(pkg)

  for consumer in consumers:
    visit(consumer)

  return ordered

const readelfBatchSize = 32

proc readelfDynamic(paths: seq[string]): Table[string, string] =
  ## `readelf -d` output per file, with a batch of files per invocation.
  ##
  ## The scans below walk every installed file of a root, where one process per
  ## library dominates the run time. A file readelf cannot read makes it exit
  ## non-zero while the other files still print, so the output is split on its
  ## `File:` headers instead of the exit code.
  var start = 0
  while start < paths.len:
    let chunk = paths[start ..< min(start + readelfBatchSize, paths.len)]
    start += chunk.len
    ensureValidCwd()
    var command = "readelf -d"
    for path in chunk:
      command.add(" " & quoteShell(path))
    let (output, _) = execCmdEx(command & " 2>/dev/null")
    var current = ""
    for line in output.splitLines:
      if line.startsWith("File: "):
        current = line["File: ".len .. ^1]
        result[current] = ""
      elif current.len > 0:
        result[current].add(line & "\n")

proc getNeededSonames*(filePath: string): seq[string] =
  ## The DT_NEEDED libraries of one ELF file.
  return parseNeededSonames(readelfDynamic(@[filePath]).getOrDefault(filePath, ""))

proc getInstalledSonames*(package: string, root: string): seq[string] =
  debug "getInstalledSonames: checking package '" & package & "' at root '" &
      root & "'"
  for filePath in getListFiles(package, root):
    let name = filePath.split('/')[^1]
    if name.startsWith("lib") and ".so." in name:
      debug "getInstalledSonames: found " & name
      result.add(name)
  debug "getInstalledSonames: found " & $result.len & " sonames"

proc runtimeDependentsAmong*(packages: seq[string], root: string,
                             sonames: seq[string]): seq[string] =
  ## Packages from `packages` with an ELF file whose DT_NEEDED names one of
  ## `sonames`. Scans only those packages, so a caller that already knows the
  ## candidates does not pay for the whole root.
  var files: Table[string, seq[string]]
  var allFiles: seq[string]
  for package in packages:
    if files.hasKey(package) or not packageExists(package, root):
      continue
    files[package] = @[]
    for filePath in getListFiles(package, root):
      if not shouldScanElfFile(filePath):
        continue
      let absolutePath = root / filePath
      if not fileExists(absolutePath) and not symlinkExists(absolutePath):
        continue
      files[package].add(absolutePath)
      allFiles.add(absolutePath)
  let dynamic = readelfDynamic(allFiles)
  for package in packages:
    if package in result:
      continue
    for absolutePath in files.getOrDefault(package, @[]):
      var found = false
      for needed in parseNeededSonames(dynamic.getOrDefault(absolutePath, "")):
        if needed in sonames:
          debug "runtimeDependentsAmong: " & package & " needs " & needed &
              " via " & absolutePath
          found = true
          break
      if found:
        result.add(package)
        break

proc getElfRuntimeDependents*(packages: seq[string], root: string,
                             sonames: seq[string] = @[]): seq[string] =
  ## Packages with an ELF file whose DT_NEEDED names one of `sonames`
  ## (default: every library file name `packages` install).
  var changedSonames = sonames
  for package in (if sonames.len > 0: @[] else: packages):
    if not packageExists(package, root):
      continue
    for soname in getInstalledSonames(package, root):
      if soname notin changedSonames:
        changedSonames.add(soname)

  if changedSonames.len == 0:
    debug "getElfRuntimeDependents: no installed sonames found"
    return @[]

  var candidates: seq[string]
  for package in getListPackages(root):
    if package notin packages and package notin candidates:
      candidates.add(package)
  debug "getElfRuntimeDependents: scanning for NEEDED entries: " &
      changedSonames.join(", ")
  result = runtimeDependentsAmong(candidates, root, changedSonames)
  debug "getElfRuntimeDependents: found " & $result.len & " dependents"

proc getBuildSonames*(buildRoot: string): seq[string] =
  debug "getBuildSonames: scanning " & buildRoot
  # Include symlinks: the installed side (getInstalledSonames) lists the
  # libfoo.so.N links too, and walkDirRec yields only regular files by default.
  for file in walkDirRec(buildRoot, yieldFilter = {pcFile, pcLinkToFile}):
    let name = file.split('/')[^1]
    if name.startsWith("lib") and ".so." in name:
      debug "getBuildSonames: found " & name
      result.add(name)
  debug "getBuildSonames: found " & $result.len & " sonames"

proc parseSoname*(readelfOutput: string): string =
  ## The DT_SONAME of a `readelf -d` dump, or "" when it has none.
  for line in readelfOutput.splitLines:
    if "(SONAME)" notin line:
      continue
    let start = line.find("[")
    let finish = line.find("]", start + 1)
    if start >= 0 and finish > start:
      return line[start + 1 ..< finish]

proc sonameFromFileName*(name: string): string =
  ## Best-effort SONAME for a library file name when it cannot be read from
  ## the ELF header: libfoo.so.1.2400.1 -> libfoo.so.1. "" for anything that
  ## is not a versioned shared library name.
  let i = name.find(".so.")
  if not name.startsWith("lib") or i < 0:
    return ""
  let rest = name[i + 4 .. ^1]
  let major = rest.split('.')[0]
  if major.len == 0 or not major.allCharsInSet(Digits):
    return ""
  return name[0 ..< i + 4] & major

proc sonamesOf*(paths: seq[string]): seq[string] =
  ## The SONAMEs the given library files provide.
  ##
  ## Consumers match these against their DT_NEEDED entries, not file names.
  ## Symlinks are skipped (they point at a file that is listed too); files
  ## readelf cannot parse fall back to sonameFromFileName.
  var scanned: seq[string]
  for path in paths:
    let name = path.split('/')[^1]
    if not name.startsWith("lib") or ".so" notin name:
      continue
    if symlinkExists(path) or not fileExists(path):
      continue
    scanned.add(path)
  let dynamic = readelfDynamic(scanned)
  for path in scanned:
    var soname = parseSoname(dynamic.getOrDefault(path, ""))
    if soname.len == 0:
      soname = sonameFromFileName(path.split('/')[^1])
    if soname.len > 0 and soname notin result:
      result.add(soname)

proc getRemovedSonames*(buildRoot: string, package: string,
                        root: string): seq[string] =
  ## SONAMEs the installed `package` provides that the new build in
  ## `buildRoot` no longer does. Only removals can break a consumer.
  if not packageExists(package, root):
    debug "getRemovedSonames: package not installed"
    return @[]
  var newPaths: seq[string]
  for file in walkDirRec(buildRoot, yieldFilter = {pcFile}):
    newPaths.add(file)
  var oldPaths: seq[string]
  for filePath in getListFiles(package, root):
    oldPaths.add(root / filePath)
  let newSonames = sonamesOf(newPaths)
  let oldSonames = sonamesOf(oldPaths)
  debug "getRemovedSonames: old=" & oldSonames.join(", ") & " new=" &
      newSonames.join(", ")
  for s in oldSonames:
    if s notin newSonames:
      result.add(s)

proc hasSonameChanged*(buildRoot: string, package: string, root: string): bool =
  ## True when the new build drops a SONAME the installed package provides.
  let removed = getRemovedSonames(buildRoot, package, root)
  if removed.len > 0:
    debug "hasSonameChanged: removed " & removed.join(", ")
    return true
  return false
