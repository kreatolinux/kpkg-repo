## File ownership across path aliases.
##
## Merged-/usr roots make one file reachable under several spellings
## (`bin/passwd`, `sbin/passwd`, `usr/bin/passwd`). Package manifests record
## whichever spelling the package used, so a plain string comparison cannot
## see that two packages own the same file. This module canonicalizes paths
## against the directory symlinks that actually exist in the target root and
## decides, per incoming archive entry, who owns the file afterwards.
##
## Policy:
## * An incoming symlink never replaces a regular file that another package
##   owns. The entry is skipped and not registered for the incoming package.
## * Any incoming entry that replaces a symlink owned by another package takes
##   ownership: the other package's rows for that file are dropped, so removing
##   it later cannot delete the replacement.
## * Removal keeps a path when another package owns what is on disk there
##   (a checksummed row for a regular file, a checksum-less row for a
##   symlink). This also keeps real files two packages both list, such as
##   `usr/share/info/dir`, until the last owner is removed.
import std/[os, strutils, tables, sets, algorithm, locks]

var ownershipLock: Lock
initLock(ownershipLock)

template withOwnershipLock*(body: untyped) =
  ## Serializes plan -> write -> DB commit (install) and check -> delete
  ## (removal) across the threaded installer. Not reentrant.
  withLock(ownershipLock):
    body

type
  FileOwner* = tuple[name: string, id: int64, isLink: bool]
    ## `isLink` is true for rows without a checksum (symlinks; directories are
    ## never consulted). Regular-file rows always carry a checksum.
  OwnerIndex* = Table[string, seq[FileOwner]]
    ## Root-relative, unquoted path -> packages that list it.

  OwnershipEntry* = tuple[relPath: string, isSymlink: bool]

  OwnershipDrop* = tuple[path: string, owner: FileOwner]
    ## A File row (as spelled in the database) to delete from `owner`.

  OwnershipPlan* = object
    skip*: HashSet[string]
      ## Incoming relPaths that must be neither installed nor registered.
    drops*: seq[OwnershipDrop]
      ## Rows of other packages that the incoming package takes over.
    warnings*: seq[string]
      ## Entries that were skipped to protect another package's file.
    notes*: seq[string]
      ## Files whose ownership moved to the incoming package.

  DirAliases* = seq[tuple[link, target: string]]

const maxSymlinkHops = 40
const maxAliases = 64

proc fsRoot(root: string): string =
  ## kpkg treats "" as "/" (callers build paths as root & "/" & rel); never
  ## resolve against the process working directory.
  if root.len == 0: "/" else: root

proc stripQuotes*(path: string): string =
  ## Database rows store paths as `"usr/bin/x"`; manifests may or may not.
  result = path
  if result.len >= 2 and result[0] == '"' and result[^1] == '"':
    result = result[1 ..^ 2]

proc normalizeRel(parts: seq[string]): seq[string] =
  for part in parts:
    case part
    of "", ".": discard
    of "..":
      if result.len > 0: result.setLen(result.len - 1)
    else: result.add(part)

proc relParts(path: string): seq[string] =
  normalizeRel(path.stripQuotes.replace('\\', '/').split('/'))

proc resolveDirs(root: string, parts: seq[string]): seq[string] =
  ## Resolve every component of `parts` that is a symlink inside `root`.
  ## Absolute link targets are interpreted relative to `root`, so a sandbox
  ## root never escapes to the host. Unresolvable components are kept as-is.
  var pending = parts
  var hops = 0
  while pending.len > 0:
    let part = pending[0]
    pending.delete(0)
    let candidate = result & part
    let full = root / candidate.join("/")
    if hops < maxSymlinkHops and symlinkExists(full):
      inc hops
      var target: string
      try:
        target = expandSymlink(full)
      except OSError:
        result.add(part)
        continue
      let targetParts = target.replace('\\', '/').split('/')
      if target.startsWith("/"):
        result = @[]
      pending = normalizeRel(result & targetParts) & pending
      result = @[]
    else:
      result.add(part)
  result = normalizeRel(result)

proc canonicalRelPath*(root, relPath: string): string =
  ## Root-relative path with symlinked *parent* directories resolved.
  ## The final component is not followed: `bin/passwd` -> `usr/bin/passwd`
  ## even when `usr/bin/passwd` is itself a symlink.
  let parts = relParts(relPath)
  if parts.len == 0:
    return ""
  let parent = resolveDirs(fsRoot(root), parts[0 ..^ 2])
  result = (parent & parts[^1]).join("/")

proc dirAliases*(root: string): DirAliases =
  ## Directory symlinks at the top level and directly under `usr/`, with
  ## their canonical targets. This covers every merged-/usr layout.
  let root = fsRoot(root)
  for base in ["", "usr"]:
    let dir = if base == "": root else: root / base
    if not dirExists(dir) or symlinkExists(dir):
      continue
    for kind, full in walkDir(dir):
      # walkDir classifies a link by following it on the *host*, which is
      # wrong for absolute targets inside a non-/ root. Resolve in-root.
      if kind notin {pcLinkToDir, pcLinkToFile}:
        continue
      let link = if base == "": lastPathPart(full) else: base & "/" & lastPathPart(full)
      let target = resolveDirs(root, relParts(link)).join("/")
      # Skip links into their own ancestry (usr/X11R6 -> .): expanding them
      # would generate usr/X11R6/X11R6/... without bound.
      if target.len > 0 and target != link and dirExists(root / target) and
          not (link & "/").startsWith(target & "/"):
        result.add((link, target))

proc pathAliases*(links: DirAliases, canonical: string): seq[string] =
  ## Every root-relative spelling that resolves to `canonical`, itself first.
  result = @[canonical]
  var i = 0
  while i < result.len:
    let current = result[i]
    for (link, target) in links:
      if current.startsWith(target & "/"):
        let alias = link & current[target.len .. ^1]
        if alias notin result and result.len < maxAliases:
          result.add(alias)
    inc i

proc pathAliases*(root, canonical: string): seq[string] =
  pathAliases(dirAliases(root), canonical)

proc ownersOf*(index: OwnerIndex, aliases: seq[string],
               exclude = ""): seq[OwnershipDrop] =
  ## Rows of packages other than `exclude` listing any alias.
  for alias in aliases:
    for owner in index.getOrDefault(alias):
      if owner.name != exclude:
        result.add((alias, owner))

proc planOwnership*(root, package: string, entries: seq[OwnershipEntry],
                    index: OwnerIndex): OwnershipPlan =
  ## Decide ownership for every non-directory archive entry of `package`.
  ## Must run before any file is written: it inspects what is on disk now.
  result.skip = initHashSet[string]()
  let links = dirAliases(root)
  for entry in entries:
    let canonical = canonicalRelPath(root, entry.relPath)
    if canonical.len == 0:
      continue
    var aliases = pathAliases(links, canonical)
    let spelled = relParts(entry.relPath).join("/")
    if spelled notin aliases: aliases.add(spelled)
    let others = ownersOf(index, aliases, package)
    if others.len == 0:
      continue
    let onDisk = fsRoot(root) / canonical
    # Directory symlinks (bin, lib, usr/sbin) collide with other packages'
    # directory rows, which also have no checksum. Not a file: leave alone.
    if dirExists(onDisk):
      continue
    let diskIsSymlink = symlinkExists(onDisk)
    let diskIsRegular = fileExists(onDisk) and not diskIsSymlink
    var names: seq[string]
    for o in others:
      if o.owner.name notin names: names.add(o.owner.name)
    names.sort()
    let ownerList = names.join(", ")
    var realOwner = false
    for o in others:
      if not o.owner.isLink: realOwner = true
    if entry.isSymlink and diskIsRegular and realOwner:
      result.skip.incl(entry.relPath)
      result.warnings.add("'" & package & "' would replace '" & canonical &
          "' (owned by " & ownerList & ") with a symlink; keeping the real file")
    elif diskIsSymlink:
      # A regular file takes over from every owner. A symlink only takes over
      # from other symlink owners: a package that records a real file here
      # keeps its claim, so its next install restores the file (this is the
      # state an old busybox install leaves behind).
      var taken: seq[string]
      for o in others:
        if entry.isSymlink and not o.owner.isLink:
          continue
        result.drops.add(o)
        if o.owner.name notin taken: taken.add(o.owner.name)
      if taken.len > 0:
        taken.sort()
        result.notes.add("'" & canonical & "' was a symlink owned by " &
            taken.join(", ") & "; '" & package & "' now owns it")

proc removalProtected*(root, package, relPath: string,
                       index: OwnerIndex, links: DirAliases): bool =
  ## True when another package owns what is on disk at `relPath`, so removing
  ## `package` must leave it in place. "Owns what is on disk" means a row of
  ## the same kind: a checksummed row for a regular file, a checksum-less row
  ## for a symlink. A stale applet-symlink row therefore never pins a real
  ## binary, and a stale real-file row never pins a symlink.
  let canonical = canonicalRelPath(root, relPath)
  if canonical.len == 0:
    return false
  let full = fsRoot(root) / canonical
  let isLink = symlinkExists(full)
  if dirExists(full) or (not isLink and not fileExists(full)):
    # Directories and directory symlinks are never deleted by the file pass
    # (tryRemoveFileCustom follows them); keep pre-change behaviour.
    return false
  var aliases = pathAliases(links, canonical)
  let spelled = relParts(relPath).join("/")
  if spelled notin aliases: aliases.add(spelled)
  for o in ownersOf(index, aliases, package):
    if o.owner.isLink == isLink:
      return true
  false
