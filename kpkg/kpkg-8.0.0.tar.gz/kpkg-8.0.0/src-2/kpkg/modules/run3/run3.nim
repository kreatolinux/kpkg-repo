## Main entry point for run3 module (kpkg integration)
## Provides a unified interface for parsing and executing run3 runfiles
## Uses Kongue as the underlying scripting language with kpkg-specific extensions

import os
import parsecfg
import sequtils
import strutils
import tables
import ../telemetry/main as telemetry

# Import Kongue modules
import ../../../kongue/ast
import ../../../kongue/lexer
import ../../../kongue/parser
import ../../../kongue/variables
import ../../../kongue/utils as kongueUtils
import ../../../kongue/context
import ../../../kongue/builtins
import ../../../kongue/executor

# Import kpkg-specific modules
import macros as run3macros
import ../processes
import ../commonPaths
import ../../../common/logging

# Re-export kongue modules for backward compatibility (but not utils to avoid conflict)
export ast, lexer, parser, variables, context, builtins, executor, run3macros

type
    Run3Context* = ref object of ExecutionContext
        ## Extended execution context with kpkg-specific fields
        passthrough*: bool   ## Passthrough execution (no sandbox)
        sandboxPath*: string ## Sandbox root path
        remount*: bool       ## Remount sandbox
        asRoot*: bool        ## Run as root in sandbox (for postinstall)

    Run3File* = object
        ## Represents a parsed and ready-to-execute run3 file
        parsed*: ParsedScript
        path*: string
        isParsed*: bool

proc resolveMacroArgs*(ctx: ExecutionContext, args: seq[string]): seq[string] =
    ## Resolve the arguments of a `macro` statement before the macro turns them
    ## into shell words.
    ##
    ## Macro arguments are Kongue text, not shell text: `${extraArgs}` in
    ## `macro build --libdir=/usr/lib ${extraArgs}` must become the value of the
    ## recipe's `extraArgs`, and an argument that refers to a name the recipe
    ## never defines must disappear (polkit only sets `extraArgs` when systemctl
    ## exists, and its `if` is false on a systemd-less host). This is the same
    ## semantics as any other Kongue expression, so an unknown name resolves to
    ## the empty string -- it is deliberately NOT the shell mode used for `exec`
    ## (see kongue/builtins.resolveVariables), where an unknown name is left for
    ## the shell. An argument that resolves to nothing is dropped, so an unset
    ## variable leaves no stray empty word in the command line.
    result = @[]
    for arg in args:
        let resolved = stripQuotes(ctx.resolveVariables(arg))
        if resolved.len > 0:
            result.add(resolved)

proc initRun3Context*(destDir: string = "", srcDir: string = "",
        buildRoot: string = "", packageName: string = ""): Run3Context =
    ## Initialize a new Run3 execution context with kpkg-specific defaults
    result = Run3Context()
    result.variables = initTable[string, string]()
    result.listVariables = initTable[string, seq[string]]()
    result.localVars = initTable[string, string]()
    result.envVars = initTable[string, string]()
    result.customFuncs = initTable[string, seq[AstNode]]()
    # Use srcDir for currentDir if provided (supports autocd from buildcmd)
    if srcDir != "":
        result.currentDir = srcDir
    else:
        result.currentDir = getCurrentDir()
    result.previousDir = result.currentDir
    result.destDir = destDir
    result.srcDir = srcDir
    result.buildRoot = buildRoot
    result.packageName = packageName
    result.silent = false
    # Kongue call-depth guard. This context is built directly rather than
    # via initExecutionContext, so the fields need setting here too or
    # kpkg would run without the recursion ceiling.
    result.callDepth = 0
    result.maxCallDepth = kongueUtils.defaultMaxCallDepth
    # kpkg-specific fields
    result.passthrough = false
    result.sandboxPath = kpkgMergedPath
    result.remount = false
    result.asRoot = false

    # Recipe commands are shell text: a `$name` the recipe does not define is
    # left for the shell to expand instead of being replaced by an empty
    # string (`sh -c 'X=1 && echo "$X"'`, `for f in ...; do ... $f`, awk's
    # `$1`). Kongue variables, kpkg's own variables and the host environment
    # still resolve (see kongue/builtins.resolveVariables). This is a recipe
    # (kpkg_run(5)) context; jumpstart's manifest mode keeps the strict
    # unknown -> empty semantics that kongue(5) MANIFEST MODE requires.
    result.shellVariables = true

    # Set up kpkg execution hook for sandboxed execution
    result.execHook = proc(ctx: ExecutionContext, command: string,
            silent: bool): tuple[output: string, exitCode: int] =
        let run3ctx = Run3Context(ctx)
        logging.debug "run3 execHook: sandboxPath=" & run3ctx.sandboxPath &
                ", passthrough=" &
            $run3ctx.passthrough & ", asRoot=" & $run3ctx.asRoot
        return execEnv(command, "none", run3ctx.passthrough, silent,
                run3ctx.sandboxPath, run3ctx.remount, run3ctx.asRoot)

    # Set up macro hook for kpkg macros
    result.macroHook = proc(ctx: ExecutionContext, name: string, args: seq[string]): int =
        return run3macros.executeMacro(ctx, name, resolveMacroArgs(ctx, args))

# Wire up Kongue logging to kpkg logging
kongueUtils.debugProc = proc(msg: string) = logging.debug(msg)
kongueUtils.warnProc = proc(msg: string) = logging.warn(msg)
kongueUtils.errorProc = proc(msg: string) = logging.error(msg)

proc parseRun3*(path: string): Run3File =
    ## Parse a run3 file from a package directory
    ## Expects path to be the package directory containing run3 file
    logging.debug "parseRun3: starting for path '"&path&"'"
    result.path = path
    result.isParsed = true
    var run3Path = path / "run3"

    if not fileExists(run3Path):
        if fileExists(path / "run"):
            run3Path = path / "run"
        else:
            raise newException(IOError, "run3 file not found at: " & run3Path)

    logging.debug "parseRun3: calling parseFile for '"&run3Path&"'"
    result.parsed = parseFile(run3Path)
    logging.debug "parseRun3: parseFile completed"

proc getVariableRaw(rf: Run3File, name: string): string =
    ## Get a raw variable value from the parsed runfile (no substitution)
    ## Internal use only - use getVariable for public API
    ## Supports both qualified names (e.g., "depends_test2") and base names
    for varNode in rf.parsed.variables:
        case varNode.kind
        of nkVariable:
            let fullName = getFullVarName(varNode)
            if fullName == name or varNode.varName == name:
                return varNode.varValue
        else:
            discard
    return ""

proc getListVariableRaw(rf: Run3File, name: string): seq[string] =
    ## Get a raw list variable value from the parsed runfile (no substitution)
    ## Internal use only - use getListVariable for public API
    ## Supports both qualified names (e.g., "depends_test2") and base names
    for varNode in rf.parsed.variables:
        case varNode.kind
        of nkListVariable:
            let fullName = getFullVarName(varNode)
            if fullName == name or varNode.listName == name:
                return varNode.listItems
        else:
            discard
    return @[]

proc getAllVariablesRaw(rf: Run3File): Table[string, VarValue] =
    ## Get all raw variables as a table (no substitution)
    ## Internal use only
    ## Uses full variable names (with qualifier if present)
    result = initTable[string, VarValue]()
    for varNode in rf.parsed.variables:
        case varNode.kind
        of nkVariable:
            let fullName = getFullVarName(varNode)
            result[fullName] = newStringValue(varNode.varValue)
        of nkListVariable:
            let fullName = getFullVarName(varNode)
            result[fullName] = newListValue(varNode.listItems)
        else:
            discard

proc resolveManipulationWithTable(vars: Table[string, VarValue],
        expr: string): string =
    ## Resolve a complex variable manipulation expression using a variables table
    ## expr is the content inside ${...}
    ## Supports interleaved methods and indexing: ${version.split('.')[0:2].join('.')}
    let tokens = tokenize(expr)
    var p = 0

    proc peek(): Token =
        if p < tokens.len: tokens[p] else: Token(kind: tkEof)

    proc advance(): Token =
        result = peek()
        p += 1

    # Parse base variable name
    var val: VarValue
    var iterations = 0

    let varName = advance().value
    if vars.hasKey(varName):
        val = vars[varName]
    else:
        let upperName = varName.toUpperAscii()
        if vars.hasKey(upperName):
            val = vars[upperName]
        else:
            val = newStringValue("")

    # Parse and apply operations (methods and indexing interleaved)
    while peek().kind == tkDot or peek().kind == tkLBracket:
        iterations += 1
        if iterations > kongueUtils.maxIterations:
            break

        if peek().kind == tkDot:
            discard advance() # .
            let methodName = peek().value
            discard advance()

            var args: seq[string] = @[]
            if peek().kind == tkLParen:
                discard advance() # (
                while peek().kind != tkRParen and peek().kind != tkEof:
                    iterations += 1
                    if iterations > kongueUtils.maxIterations:
                        break
                    if peek().kind == tkString or peek().kind == tkIdentifier or
                            peek().kind == tkNumber:
                        args.add(advance().value)
                    elif peek().kind == tkComma:
                        discard advance()
                    else:
                        discard advance()
                discard advance() # )

            try:
                val = applyMethod(val, methodName, args)
            except ValueError:
                return ""

        elif peek().kind == tkLBracket:
            discard advance() # [
            var indexExpr = ""
            while peek().kind != tkRBracket and peek().kind != tkEof:
                iterations += 1
                if iterations > kongueUtils.maxIterations:
                    break
                indexExpr.add(advance().value)
            discard advance() # ]

            try:
                val = applyIndex(val, indexExpr)
            except ValueError:
                return ""

    return val.toString()

proc substituteVariablesWithTable(rf: Run3File, vars: Table[string, VarValue],
        value: string): string =
    ## Core variable substitution logic using a provided variables table
    ## Handles complex ${...} expressions and simple $variable references
    result = value

    # First, handle complex ${...} expressions that contain method calls or indexing
    var i = 0
    while i < result.len:
        if i < result.len - 1 and result[i] == '$' and result[i+1] == '{':
            # Find the closing }
            var j = i + 2
            var braceCount = 1
            while j < result.len and braceCount > 0:
                if result[j] == '{':
                    braceCount += 1
                elif result[j] == '}':
                    braceCount -= 1
                j += 1

            if braceCount == 0:
                let varExpr = result[i+2..<j-1]
                # Check if it contains method calls or indexing
                if '.' in varExpr or '[' in varExpr:
                    let resolvedValue = resolveManipulationWithTable(vars, varExpr)
                    result = result[0..<i] & resolvedValue & result[j..^1]
                    i += resolvedValue.len
                else:
                    # Simple variable reference, handle below
                    i += 1
            else:
                i += 1
        else:
            i += 1

    # Replace ${variable} style references (simple ones remaining)
    for varName, varValue in vars:
        let valStr = varValue.toString()
        result = result.replace("${" & varName & "}", valStr)
        result = result.replace("${" & varName.toUpperAscii() & "}", valStr)

    # Replace $variable style references (case variations)
    for varName, varValue in vars:
        let valStr = varValue.toString()
        result = result.replace("$" & varName, valStr)
        result = result.replace("$" & varName.toUpperAscii(), valStr)
        # Also handle capitalized version
        if varName.len > 0:
            let capitalized = varName[0].toUpperAscii() & varName[1..^1]
            result = result.replace("$" & capitalized, valStr)

proc substituteVariables*(rf: Run3File, value: string): string =
    ## Substitute $variable and ${variable} references in a string
    ## Substitutes all variables defined in the runfile
    ## Handles complex expressions like ${version.split('.')[0:2].join('.')}
    ##
    ## The result is package metadata (a name, a version, a source URL), so the
    ## ``\\$`` escape marker is restored here. The header accessors below
    ## (``getVariable``, ``getListVariable``, ``getSources``, ...) all funnel
    ## through this proc and never call ``resolveVariables``, which is what
    ## normally restores the marker: without this, a recipe with
    ## ``description: "costs \\$5"`` produced a description holding a literal
    ## 0x01 byte, and ``sources: ".../\\${version}.tar.xz"`` produced a URL
    ## with 0x01 where the ``$`` belonged.
    kongueUtils.restoreEscapedDollars(
        rf.substituteVariablesWithTable(rf.getAllVariablesRaw(), value))

proc getVariable*(rf: Run3File, name: string): string =
    ## Get a variable value from the parsed runfile (with substitution)
    rf.substituteVariables(rf.getVariableRaw(name))

proc getVariable*(rf: Run3File, name: string, override: Config, section,
        key: string): string =
    ## Get a variable value with override support
    ## 1. Gets raw value
    ## 2. Checks override
    ## 3. Substitutes variables
    let raw = rf.getVariableRaw(name)
    let overridden = if override != nil: override.getSectionValue(section, key, raw) else: raw
    return rf.substituteVariables(overridden)

proc getListVariable*(rf: Run3File, name: string): seq[string] =
    ## Get a list variable value from the parsed runfile (with substitution)
    let rawList = rf.getListVariableRaw(name)
    result = @[]
    for item in rawList:
        result.add(rf.substituteVariables(item))

proc getListVariable*(rf: Run3File, name: string, override: Config, section,
        key: string): seq[string] =
    ## Get a list variable with override support
    ## Preserves list structure for items with spaces if not overridden

    # 1. Get all variables to check type
    let allVars = rf.getAllVariablesRaw()

    # 2. Get raw string representation
    var rawString = ""
    var isList = false
    var rawList: seq[string] = @[]

    if allVars.hasKey(name):
        let v = allVars[name]
        if v.kind == vvkList:
            isList = true
            rawList = v.toList()
            rawString = v.toString()
        else:
            rawString = v.toString()

    # 3. Check override
    let overriddenString = if override != nil: override.getSectionValue(section,
            key, rawString) else: rawString

    # 4. If NOT overridden and is native list, preserve structure
    if overriddenString == rawString and isList:
        result = @[]
        for item in rawList:
            result.add(rf.substituteVariables(item))
        return result

    # 5. If overridden or string, treat as string and split
    let substitutedString = rf.substituteVariables(overriddenString)
    if substitutedString.len == 0: return @[]

    result = substitutedString.split(" ")
    result.keepItIf(it.len > 0)

proc hasFunction*(rf: Run3File, name: string): bool =
    ## Check if a function exists in the runfile
    return ast.hasFunction(rf.parsed, name)

proc initRun3ContextFromParsed*(parsed: ParsedScript, destDir: string = "",
        srcDir: string = "", buildRoot: string = ""): Run3Context =
    ## Initialize Run3Context from a parsed script
    result = initRun3Context(destDir, srcDir, buildRoot, "")
    result.loadVariablesFromParsed(parsed)
    result.loadAllFunctions(parsed)

    # Set package name if available
    if result.variables.hasKey("name"):
        result.packageName = result.variables["name"]

proc executeRun3Stage*(ctx: ExecutionContext, parsed: ParsedScript,
        stage: string): int =
    ## Execute a Run3 stage.
    executeFunctionByName(ctx, parsed, stage)

proc executeFunction*(rf: Run3File, functionName: string, destDir: string = "",
        srcDir: string = "", buildRoot: string = ""): int =
    ## Execute a specific function from the run3 file
    let span = telemetry.startSpan("kpkg.run3.execute", {
      "package.name": rf.getVariable("name"),
      "package.version": rf.getVariable("version") & "-" & rf.getVariable("release")
    }.toTable)
    try:
        let ctx = initRun3ContextFromParsed(rf.parsed, destDir, srcDir, buildRoot)
        result = executeRun3Stage(ctx, rf.parsed, functionName)
        if result != 0:
            telemetry.endSpan(span, newException(ExecutionError, "Run3 execution failed"))
    except CatchableError as failure:
        telemetry.endSpan(span, failure)
        raise
    finally:
        telemetry.endSpan(span)

proc getAllFunctions*(rf: Run3File): seq[string] =
    ## Get a list of all function names defined in the runfile
    ## Returns full names (with qualifier if present, e.g., "package_test2")
    result = @[]
    for funcNode in rf.parsed.functions:
        if funcNode.kind == nkFunction:
            result.add(getFullFuncName(funcNode))

proc getAllCustomFunctions*(rf: Run3File): seq[string] =
    ## Get a list of all custom function names defined in the runfile
    result = @[]
    for funcNode in rf.parsed.customFuncs:
        if funcNode.kind == nkCustomFunc:
            result.add(funcNode.customFuncName)

proc getAllVariables*(rf: Run3File): Table[string, VarValue] =
    ## Get all variables as a table, without substitution on values themselves
    ## (returns raw structure).
    ##
    ## The ``\\$`` escape marker is still restored: this is a public accessor,
    ## and a caller that uses a value without going through
    ## ``substituteVariables`` (krep's autoupdater, runparser's optdepends)
    ## would otherwise carry a literal 0x01 byte into a package description or
    ## a download URL.
    result = rf.getAllVariablesRaw()
    for key, value in result.mpairs:
        case value.kind
        of vvkString:
            value.strVal = kongueUtils.restoreEscapedDollars(value.strVal)
        of vvkList:
            for item in value.listVal.mitems:
                item = kongueUtils.restoreEscapedDollars(item)
        of vvkObject:
            discard

# Convenience procs for common runfile variables

proc getName*(rf: Run3File): string =
    ## Get the package name
    rf.getVariable("name")

proc getVersion*(rf: Run3File): string =
    ## Get the package version
    rf.getVariable("version")

proc getRelease*(rf: Run3File): string =
    ## Get the package release
    rf.getVariable("release")

proc getDescription*(rf: Run3File): string =
    ## Get the package description
    rf.getVariable("description")

proc getSources*(rf: Run3File): seq[string] =
    ## Get the package sources
    rf.getListVariable("sources")

proc getSourcesRaw*(rf: Run3File): seq[string] =
    ## Get the raw package sources without variable substitution.
    ##
    ## ``\\$`` is still restored (see getAllVariables): the autoupdater feeds
    ## these strings to a URL fetcher, where a 0x01 marker would be a broken URL.
    result = @[]
    for item in rf.getListVariableRaw("sources"):
        result.add(kongueUtils.restoreEscapedDollars(item))

proc substituteVariablesWithVersion*(rf: Run3File, value: string,
        newVersion: string): string =
    ## Substitute variables in a string, but override the version variable with newVersion
    ## This is useful for autoupdating source URLs with a new version
    var modifiedVars = rf.getAllVariables()
    modifiedVars["version"] = newStringValue(newVersion)
    kongueUtils.restoreEscapedDollars(
        rf.substituteVariablesWithTable(modifiedVars, value))

proc getSourcesWithVersion*(rf: Run3File, newVersion: string): seq[string] =
    ## Get the package sources with a different version substituted
    ## This properly handles expressions like ${version.split('.')[0:2].join('.')}
    let rawSources = rf.getSourcesRaw()
    result = @[]
    for source in rawSources:
        result.add(rf.substituteVariablesWithVersion(source, newVersion))

proc getDepends*(rf: Run3File): seq[string] =
    ## Get the package dependencies
    rf.getListVariable("depends")

proc getBuildDepends*(rf: Run3File): seq[string] =
    ## Get the package build dependencies
    rf.getListVariable("build_depends")

proc getSha256sum*(rf: Run3File): seq[string] =
    ## Get the SHA256 checksums
    rf.getListVariable("sha256sum")

proc getSha512sum*(rf: Run3File): seq[string] =
    ## Get the SHA512 checksums
    rf.getListVariable("sha512sum")

proc getB2sum*(rf: Run3File): seq[string] =
    ## Get the BLAKE2 checksums
    rf.getListVariable("b2sum")

proc getExtract*(rf: Run3File): bool =
    ## Get the extract flag (defaults to true)
    let extract = rf.getVariable("extract")
    if extract == "":
        return true # Default
    return kongueUtils.isTrueBoolean(extract)

proc getAutocd*(rf: Run3File): bool =
    ## Get the autocd flag
    ## Defaults to true, but if extract is explicitly false and autocd is not set,
    ## autocd defaults to false
    let autocd = rf.getVariable("autocd")
    let extract = rf.getVariable("extract")

    if autocd == "":
        # If autocd not set, default based on extract setting
        # If extract is explicitly false, autocd defaults to false
        if extract != "" and not kongueUtils.isTrueBoolean(extract):
            return false
        return true # Default
    return kongueUtils.isTrueBoolean(autocd)

proc getVersionString*(rf: Run3File): string =
    ## Get the full version string (version-release or version-release-epoch)
    let version = rf.getVersion()
    let release = rf.getRelease()
    let epoch = rf.getVariable("epoch")

    if epoch != "" and epoch != "no":
        return version & "-" & release & "-" & epoch
    else:
        return version & "-" & release

# Compatibility wrapper for parseRunfile
proc parseRunfile*(path: string, removeLockfileWhenErr = true): Run3File =
    ## Parse a run3 file (compatibility wrapper)
    ## Expects path to be the package directory containing run3 file
    return parseRun3(path)
