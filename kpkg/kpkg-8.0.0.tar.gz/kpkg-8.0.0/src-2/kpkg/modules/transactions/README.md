# Transactions

- `main.nim`: file-operation journals, backups, atomic file replacement, and
  crash recovery for installs and history restoration. A journal is recovery
  evidence only: recovery classifies journals from their header and last state
  record, settles committed and rolled-back ones, and keeps active ones.
- `history.nim`: persistent package history, undo/rollback planning, and cleanup.
  Each committed transaction's operations are archived in
  `<history entry>/members/<id>.json` before the entry is published, so undo
  reads them from there and the crash journal can be deleted at commit time.
- `barrier.nim`: pending-history ownership checks shared by mutation callers.

`history` depends on `main` and `barrier`. `main` also uses `barrier`; keeping
ownership checks separate avoids a circular dependency.

SQLite connection guards and snapshot validation live in `../sqlite.nim`.
Package mutation locking lives in `../lockfile.nim`.
