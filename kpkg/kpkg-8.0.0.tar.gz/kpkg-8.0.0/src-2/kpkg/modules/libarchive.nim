import os
import ../../common/logging
import strutils
import sequtils
import telemetry/main as telemetry
import tables
import std/locks

# Archive-root transport metadata, not installed package payload.
const archiveRootMetadata* = ["pkgsums.ini", "pkgInfo.ini"]

proc isArchiveRootMetadata*(path: string): bool =
  ## True only for archive-root metadata entries (no directory component).
  result = path in archiveRootMetadata

# libarchive's disk writer reads the process umask by setting it to 0 and
# back (libarchive issue #1876 / CVE-2023-30571). Parallel install workers can
# interleave and leave it at 0, so every directory kpkg creates is 0777.
var diskWriterLock: Lock
initLock(diskWriterLock)

# libarchive bindings
{.passL: "-larchive".}

type
  structArchive* {.importc: "struct archive", header: "<archive.h>".} = object
  structArchiveEntry* {.importc: "struct archive_entry",
      header: "<archive_entry.h>".} = object

const
  ARCHIVE_EOF* = 1
  ARCHIVE_OK* = 0
  ARCHIVE_WARN* = -20
  ARCHIVE_FAILED* = -25
  ARCHIVE_FATAL* = -30
  ARCHIVE_EXTRACT_TIME* = 0x0004
  ARCHIVE_EXTRACT_PERM* = 0x0002
  ARCHIVE_EXTRACT_ACL* = 0x0020
  ARCHIVE_EXTRACT_FFLAGS* = 0x0040
  ARCHIVE_EXTRACT_OWNER* = 0x0001

# LC_ALL varies by platform
when defined(macosx):
  const LC_ALL* = 0
else:
  const LC_ALL* = 6

# libc functions
proc setlocale*(category: cint, locale: cstring): cstring {.importc,
    header: "<locale.h>".}
proc chdir*(path: cstring): cint {.importc, header: "<unistd.h>".}

# Archive core
proc archiveReadNew*(): ptr structArchive {.importc: "archive_read_new",
    header: "<archive.h>".}
proc archiveWriteNew*(): ptr structArchive {.importc: "archive_write_new",
    header: "<archive.h>".}
proc archiveWriteDiskNew*(): ptr structArchive {.importc: "archive_write_disk_new",
    header: "<archive.h>".}
proc archiveReadDiskNew*(): ptr structArchive {.importc: "archive_read_disk_new",
    header: "<archive.h>".}

# Read operations
proc archiveReadSupportFormatAll*(a: ptr structArchive): cint {.importc: "archive_read_support_format_all",
    header: "<archive.h>".}
proc archiveReadSupportFilterAll*(a: ptr structArchive): cint {.importc: "archive_read_support_filter_all",
    header: "<archive.h>".}
proc archiveReadOpenFilename*(a: ptr structArchive, filename: cstring,
    blocksize: csize_t): cint {.importc: "archive_read_open_filename",
    header: "<archive.h>".}
proc archiveReadNextHeader*(a: ptr structArchive,
    entry: ptr ptr structArchiveEntry): cint {.importc: "archive_read_next_header",
    header: "<archive.h>".}
proc archiveReadNextHeader2*(a: ptr structArchive,
    entry: ptr structArchiveEntry): cint {.importc: "archive_read_next_header2",
    header: "<archive.h>".}
proc archiveReadDataBlock*(a: ptr structArchive, buff: pointer,
    size: ptr csize_t,
    offset: ptr int64): cint {.importc: "archive_read_data_block",
    header: "<archive.h>".}
proc archiveReadClose*(a: ptr structArchive): cint {.importc: "archive_read_close",
    header: "<archive.h>".}
proc archiveReadFree*(a: ptr structArchive): cint {.importc: "archive_read_free",
    header: "<archive.h>".}
proc archiveReadSetOptions*(a: ptr structArchive, 
    opts: cstring): cint {.importc: "archive_read_set_options",
    header: "<archive.h>".}

# Read disk operations
proc archiveReadDiskSetStandardLookup*(a: ptr structArchive): cint {.importc: "archive_read_disk_set_standard_lookup",
    header: "<archive.h>".}
proc archiveReadDiskOpen*(a: ptr structArchive,
    path: cstring): cint {.importc: "archive_read_disk_open",
    header: "<archive.h>".}
proc archiveReadDiskDescend*(a: ptr structArchive): cint {.importc: "archive_read_disk_descend",
    header: "<archive.h>".}
proc archiveReadDiskSetSymlinkPhysical*(
  a: ptr structArchive): cint {.importc: "archive_read_disk_set_symlink_physical",
    header: "<archive.h>".}

# Write operations
proc archiveWriteDiskSetOptions*(a: ptr structArchive,
    flags: cint): cint {.importc: "archive_write_disk_set_options",
    header: "<archive.h>".}
proc archiveWriteDiskSetStandardLookup*(
  a: ptr structArchive): cint {.importc: "archive_write_disk_set_standard_lookup",
    header: "<archive.h>".}
proc archiveWriteOpenFilename*(a: ptr structArchive,
    filename: cstring): cint {.importc: "archive_write_open_filename",
    header: "<archive.h>".}
proc archiveWriteSetFormatFilterByExt*(a: ptr structArchive,
    filename: cstring): cint {.importc: "archive_write_set_format_filter_by_ext",
    header: "<archive.h>".}
proc archiveWriteSetFormatGnutar*(a: ptr structArchive): cint {.importc: "archive_write_set_format_gnutar",
    header: "<archive.h>".}
proc archiveWriteAddFilterGzip*(a: ptr structArchive): cint {.importc: "archive_write_add_filter_gzip",
    header: "<archive.h>".}
proc archiveWriteAddFilterXz*(a: ptr structArchive): cint {.importc: "archive_write_add_filter_xz",
    header: "<archive.h>".}
proc archiveWriteAddFilterZstd*(a: ptr structArchive): cint {.importc: "archive_write_add_filter_zstd",
    header: "<archive.h>".}
proc archiveWriteHeader*(a: ptr structArchive,
    entry: ptr structArchiveEntry): cint {.importc: "archive_write_header",
    header: "<archive.h>".}
proc archiveWriteData*(a: ptr structArchive, buff: pointer,
    len: csize_t): csize_t {.importc: "archive_write_data",
    header: "<archive.h>".}
proc archiveWriteDataBlock*(a: ptr structArchive, buff: pointer, size: csize_t,
    offset: int64): cint {.importc: "archive_write_data_block",
    header: "<archive.h>".}
proc archiveWriteFinishEntry*(a: ptr structArchive): cint {.importc: "archive_write_finish_entry",
    header: "<archive.h>".}
proc archiveWriteClose*(a: ptr structArchive): cint {.importc: "archive_write_close",
    header: "<archive.h>".}
proc archiveWriteFree*(a: ptr structArchive): cint {.importc: "archive_write_free",
    header: "<archive.h>".}

# libc getcwd for saving working directory
proc getcwd*(buf: cstring, size: csize_t): cstring {.importc, header: "<unistd.h>".}

# Entry operations
proc archiveEntryNew*(): ptr structArchiveEntry {.importc: "archive_entry_new",
    header: "<archive_entry.h>".}
proc archiveEntryFree*(entry: ptr structArchiveEntry) {.importc: "archive_entry_free",
    header: "<archive_entry.h>".}
proc archiveEntryPathname*(entry: ptr structArchiveEntry): cstring {.importc: "archive_entry_pathname",
    header: "<archive_entry.h>".}
proc archiveEntrySetPathname*(entry: ptr structArchiveEntry, path: cstring) {.
    importc: "archive_entry_set_pathname", header: "<archive_entry.h>".}
proc archiveEntryPathnameUtf8*(entry: ptr structArchiveEntry): cstring {.importc: "archive_entry_pathname_utf8",
    header: "<archive_entry.h>".}
proc archiveEntrySourcepath*(entry: ptr structArchiveEntry): cstring {.importc: "archive_entry_sourcepath",
    header: "<archive_entry.h>".}

# Error handling
proc archiveErrorString*(a: ptr structArchive): cstring {.importc: "archive_error_string",
    header: "<archive.h>".}

type
  LibarchiveError* = object of CatchableError

proc debugWarn(f: string, err: string) =
  when not defined(release):
    echo f&" failed: "&err

proc getEntryPathname(entry: ptr structArchiveEntry): string =
  ## Get pathname from archive entry, preferring UTF-8 version to avoid locale conversion issues
  let utf8Path = archiveEntryPathnameUtf8(entry)
  if utf8Path != nil and utf8Path[0] != '\0':
    return $utf8Path
  let regularPath = archiveEntryPathname(entry)
  if regularPath != nil:
    return $regularPath
  return ""

proc copyData(ar: ptr structArchive, aw: ptr structArchive): cint =
  # Function copy_data(), gotten from untar.c
  var r: cint
  var size: csize_t

  # Is a const in the original untar.c, but idk how to do immutable pointers, lmk if there is a way
  var buff: pointer

  var offset: int64
  while true:
    r = archiveReadDataBlock(ar, cast[pointer](addr(buff)), addr(size), addr(offset))
    if r == ARCHIVE_EOF:
      return ARCHIVE_OK
    if r != ARCHIVE_OK:
      return r
    r = archiveWriteDataBlock(aw, buff, size, offset)
    if r != ARCHIVE_OK:
      debugWarn("archiveWriteDataBlock()", $archiveErrorString(aw))
      return r

# Try to set a UTF-8 locale for proper handling of international filenames
# First try empty string (use environment), then explicit UTF-8 locales
if setlocale(LC_ALL, "") == nil:
  if setlocale(LC_ALL, "C.UTF-8") == nil:
    if setlocale(LC_ALL, "en_US.UTF-8") == nil:
      # Fall back to C locale as last resort (may have issues with non-ASCII filenames)
      if setlocale(LC_ALL, "C") == nil:
        raise newException(OSError, "setlocale failed")

proc extractImpl(fileName: string, path = getCurrentDir(), ignoreFiles = @[""],
    getFiles = @[""]): seq[string] =
  # Extracts a file to a directory.
  # Based on untar.c in libarchive/examples

  if not isAdmin():
    raise newException(OSError, "You need to be root to continue")

  if not dirExists(path):
    raise newException(OSError, '`'&path&"` doesn't exist")

  if not fileExists(fileName):
    raise newException(OSError, '`'&fileName&"` doesn't exist")

  var resultStr: seq[string]
  var a: ptr structArchive
  var ext: ptr structArchive
  var entry: ptr structArchiveEntry
  var r: cint

  a = archiveReadNew()
  withLock(diskWriterLock):
    ext = archiveWriteDiskNew()
  discard archiveWriteDiskSetOptions(ext, ARCHIVE_EXTRACT_TIME +
      ARCHIVE_EXTRACT_FFLAGS + ARCHIVE_EXTRACT_PERM + ARCHIVE_EXTRACT_ACL + ARCHIVE_EXTRACT_OWNER)
  discard archiveReadSupportFormatAll(a)
  discard archiveReadSupportFilterAll(a)
  # Read filenames as raw bytes to avoid charset conversion issues with non-ASCII filenames
  discard archiveReadSetOptions(a, "hdrcharset=binary")
  discard archiveWriteDiskSetStandardLookup(ext)
  r = archiveReadOpenFilename(a, filename, 10240)
  if r != ARCHIVE_OK:
    let message = if archiveErrorString(a) == nil: "could not open archive"
                  else: $archiveErrorString(a)
    discard archiveReadFree(a)
    discard archiveWriteFree(ext)
    raise newException(LibarchiveError, message)

  try:
    # Do not chdir here: cwd is process-global and makes concurrent extraction
    # unsafe. Each archive entry is rewritten to an absolute path below `path`.
    let pathPrefix = if path.endsWith("/"): path else: path & "/"

    while true:
      r = archiveReadNextHeader(a, addr(entry))

      if r == ARCHIVE_EOF:
        break

      # Only fail on ARCHIVE_FAILED or ARCHIVE_FATAL, continue on ARCHIVE_WARN
      if r < ARCHIVE_WARN:
        raise newException(LibarchiveError, $archiveErrorString(a))
      
      if r != ARCHIVE_OK:
        debugWarn("archiveReadNextHeader()", $archiveErrorString(a))

      let entryPath = getEntryPathname(entry)
      # Reject traversal before constructing the absolute destination.
      let normalizedEntry = entryPath.replace("\\", "/")
      if normalizedEntry == ".." or normalizedEntry.startsWith("../") or
          normalizedEntry.contains("/../"):
        raise newException(LibarchiveError, "archive entry escapes extraction directory: " & entryPath)
      let fullEntryPath = pathPrefix & normalizedEntry
      # Keep fullEntryPath alive until archiveWriteFinishEntry.
      archiveEntrySetPathname(entry, fullEntryPath.cstring)

      if not (entryPath in resultStr):
        resultStr.add(entryPath)

      if not (isEmptyOrWhitespace(getFiles.join(""))) and (entryPath notin getFiles):
        continue

      if entryPath in ignoreFiles and fileExists(path & "/" & entryPath):
        debug(entryPath & " in ignoreFiles, ignoring")
        continue

      # Some published Klinux archives contain repeated entries. The
      # manifest describes the final occurrence, so remove an earlier
      # non-directory payload before asking libarchive to write the entry.
      if (fileExists(fullEntryPath) or symlinkExists(fullEntryPath)) and
          not dirExists(fullEntryPath):
        removeFile(fullEntryPath)

      withLock(diskWriterLock):
        r = archiveWriteHeader(ext, entry)
      if r != ARCHIVE_OK:
        # A failed header leaves libarchive's disk writer in its header state;
        # calling archiveWriteDataBlock after that is invalid and can corrupt
        # the surrounding threaded installer. Skip this entry instead.
        debugWarn("archiveWriteHeader()", $archiveErrorString(ext))
        continue
      discard copyData(a, ext)
      r = archiveWriteFinishEntry(ext)
      if r != ARCHIVE_OK:
        raise newException(LibarchiveError, $archiveErrorString(ext))
  finally:
    discard archiveReadClose(a)
    discard archiveReadFree(a)
    discard archiveWriteClose(ext)
    discard archiveWriteFree(ext)

  return resultStr

proc extract*(fileName: string, path = getCurrentDir(), ignoreFiles = @[""],
    getFiles = @[""]): seq[string] =
  telemetry.withSpan("kpkg.archive.extract", {
    "source.filename": extractFilename(fileName)
  }.toTable):
    return extractImpl(fileName, path, ignoreFiles, getFiles)

proc createArchive*(fileName: string, path = getCurrentDir(), format = "auto",
    filter = "gzip") =
  ## Creates an archive from the contents of a directory.
  ## Based on minitar.c
  ##
  ## Parameters:
  ##   fileName: Output archive path
  ##   path: Directory to archive (contents will be archived, not the directory itself)
  ##   format: Archive format - "auto" (detect from extension), "gnutar"
  ##   filter: Compression filter - "gzip" (default), "xz", "zstd", "auto" (detect from extension)

  if not dirExists(path):
    raise newException(OSError, '`'&path&"` doesn't exist")

  var archive: ptr structArchive
  var entry: ptr structArchiveEntry
  var r: cint
  var file: File
  var length: csize_t
  var buffer: pointer = alloc(16384)

  # Save current working directory
  var savedCwd: array[4096, char]
  if getcwd(cast[cstring](addr savedCwd[0]), 4096) == nil:
    dealloc(buffer)
    raise newException(OSError, "Failed to get current working directory")

  archive = archiveWriteNew()

  try:
    # Set format and filter
    if format == "auto" and filter == "auto":
      # Detect both from extension
      if archiveWriteSetFormatFilterByExt(archive, fileName) != ARCHIVE_OK:
        raise newException(LibarchiveError, "Couldn't guess file format by extension")
    else:
      # Set format
      if format == "auto" or format == "gnutar":
        if archiveWriteSetFormatGnutar(archive) != ARCHIVE_OK:
          raise newException(LibarchiveError, "Failed to set gnutar format")
      else:
        raise newException(LibarchiveError, "Unsupported format: " & format)

      # Set filter
      case filter
      of "gzip":
        if archiveWriteAddFilterGzip(archive) != ARCHIVE_OK:
          raise newException(LibarchiveError, "Failed to add gzip filter")
      of "xz":
        if archiveWriteAddFilterXz(archive) != ARCHIVE_OK:
          raise newException(LibarchiveError, "Failed to add xz filter")
      of "zstd":
        if archiveWriteAddFilterZstd(archive) != ARCHIVE_OK:
          raise newException(LibarchiveError, "Failed to add zstd filter")
      else:
        raise newException(LibarchiveError, "Unsupported filter: " & filter)

    if archiveWriteOpenFilename(archive, filename) != ARCHIVE_OK:
      raise newException(LibarchiveError, "Failed to open archive for writing: " &
          $archiveErrorString(archive))

    discard chdir(path)

    for i in toSeq(walkDirRec(path, {pcFile, pcLinkToFile, pcDir, pcLinkToDir})):

      var disk = archiveReadDiskNew()

      discard archiveReadDiskSetStandardLookup(disk)

      r = archiveReadDiskOpen(disk, cstring(relativePath(i, getCurrentDir())))

      if r != ARCHIVE_OK:
        discard archiveReadFree(disk)
        raise newException(LibarchiveError, $archiveErrorString(disk))

      discard archiveReadDiskSetSymlinkPhysical(disk)

      while true:
        entry = archiveEntryNew()
        r = archiveReadNextHeader2(disk, entry)

        if r == ARCHIVE_EOF:
          archiveEntryFree(entry)
          break

        if r != ARCHIVE_OK:
          archiveEntryFree(entry)
          discard archiveReadClose(disk)
          discard archiveReadFree(disk)
          raise newException(LibarchiveError, $archiveErrorString(disk))

        discard archiveReadDiskDescend(disk)

        r = archiveWriteHeader(archive, entry)

        if r == ARCHIVE_FATAL:
          archiveEntryFree(entry)
          discard archiveReadClose(disk)
          discard archiveReadFree(disk)
          raise newException(LibarchiveError, "Fatal error writing archive header: " &
              $archiveErrorString(archive))

        if r < ARCHIVE_OK:
          debugWarn("archiveWriteHeader", $archiveErrorString(archive))

        if r > ARCHIVE_FAILED and fileExists(i):
          file = open($archiveEntrySourcepath(entry))
          length = csize_t(readBuffer(file, buffer, sizeof(buffer)))
          while length > 0:
            discard archiveWriteData(archive, buffer, length)
            length = csize_t(readBuffer(file, buffer, sizeof(buffer)))
          close(file)
        archiveEntryFree(entry)
      discard archiveReadClose(disk)
      discard archiveReadFree(disk)

  finally:
    discard archiveWriteClose(archive)
    discard archiveWriteFree(archive)
    dealloc(buffer)
    # Restore working directory
    discard chdir(cast[cstring](addr savedCwd[0]))
