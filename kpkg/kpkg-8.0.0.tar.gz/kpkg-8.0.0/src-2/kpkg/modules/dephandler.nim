# dephandler v3
import os
import sets
import config
import tables
import sqlite
import ../../common/logging
import sequtils
import strutils
import runparser
import arch
import commonTasks
import commonPaths
import algorithm
import std/json
import versioncmp
import gitutils
import telemetry/main as telemetry

type
    repoInfo = tuple[repo: string, name: string, version: string]

    SortResult* = object
        order*: seq[string]
        hasCycle*: bool
        cyclePath*: seq[string]

    DependencyEdge* = tuple[dependency: string, dependent: string]

    dependencyContext* = object
        root*: string
        isBuild*: bool
        useBootstrap*: bool
        ignoreInit*: bool
        ignoreCircularDeps*: bool
        forceInstallAll*: bool
        useCacheIfAvailable*: bool
        init*: string
        # Commit-based build fields
        commit*: string     ## Commit hash for commit-based builds
        commitRepo*: string ## The repo that was checked out to the commit
        headRunfileCache*: Table[string, runFile] ## Cached runfiles at HEAD (before checkout)
        targetArch*: string ## Normalized target arch for per-arch runfile keys
        bootstrapSatisfied*: HashSet[string]
        bootstrapSatisfiedEdges*: HashSet[DependencyEdge]

    resolvedPackage* = object
        name*: string
        repo*: string
        metadata*: runFile

    dependencyGraph* = object
        nodes*: Table[string, resolvedPackage]
        edges*: Table[string, seq[string]]

proc effectiveArch*(targetArch: string): string =
    ## Empty means "host architecture"; anything else is normalized so
    ## `amd64`/`x86_64` and `arm64`/`aarch64` compare equal.
    if targetArch.len == 0:
        return hostArch()
    normalizeArch(targetArch)

proc packageToRunFile(package: Package): runFile =
    ## Converts package to runFile. Not all variables are available.
    return runFile(pkg: package.name, version: package.version,
            versionString: package.version, release: package.release,
            epoch: package.epoch, deps: package.deps.split("!!k!!"),
            bdeps: package.bdeps.split("!!k!!"), bsdeps: @[])

proc hasCachedBuild(pkg: string, repo: string, root: string,
        targetArch = ""): bool =
    ## Check if a package has a cached build tarball available
    try:
        let target = kpkgTarget(root)
        let pkgrf = parseRunfile(repo&"/"&pkg, arch = effectiveArch(targetArch))
        let cachePath = kpkgArchivesDir&"/system/"&target&"/"&pkg&"-"&pkgrf.versionString&".kpkg"
        let exists = fileExists(cachePath)
        debug "dephandler: hasCachedBuild for '"&pkg&"': target="&target&", version="&pkgrf.versionString&", path="&cachePath&", exists="&($exists)
        return exists
    except:
        debug "dephandler: hasCachedBuild for '"&pkg&"' failed with exception"
        return false


### Helper functions for package resolution

proc resolvePackageRepo(pkg: string, chkInstalledDirInstead: bool,
        isInstallDir: bool): repoInfo =
    ## Resolve package name and repository from specifier

    var name = pkg
    var repo: string
    var version = ""

    if isInstallDir:
        repo = absolutePath(pkg).parentDir()
        name = lastPathPart(pkg)
    elif chkInstalledDirInstead:
        repo = "local"
        name = pkg
    else:
        let pkgSplit = parsePkgInfo(pkg)
        name = pkgSplit.name
        repo = pkgSplit.repo
        version = pkgSplit.version

    return (repo: repo, name: name, version: version)

proc loadPackageMetadata(name: string, repo: string, root: string,
        targetArch = ""): runFile =
    ## Load package metadata from repository or installed database

    if repo == "local":
        debug "dephandler: packageToRunFile ran, loadPackageMetadata, pkg: '"&name&"' root: '"&root&"'"
        return packageToRunFile(getPackage(name, root))
    else:
        debug "dephandler: parseRunfile ran, loadPackageMetadata, repo: '"&repo&"', pkg: '"&name&"'"
        return parseRunfile(repo&"/"&name, arch = effectiveArch(targetArch))

proc loadPackageMetadataCommitAware*(name: string, repo: string,
                                      ctx: dependencyContext): runFile =
    ## Load package metadata considering commit context.
    ##
    ## For packages in the same repo as the commit:
    ## - Compare version at commit vs HEAD
    ## - Use whichever is newer
    ##
    ## For packages in different repos:
    ## - Use HEAD version (current state)

    if repo == "local":
        debug "dephandler: packageToRunFile ran, loadPackageMetadataCommitAware, pkg: '"&name&"' root: '"&ctx.root&"'"
        return packageToRunFile(getPackage(name, ctx.root))

    # If no commit context, use normal loading
    if ctx.commit == "" or ctx.commitRepo == "":
        debug "dephandler: No commit context, using normal loadPackageMetadata"
        return parseRunfile(repo&"/"&name, arch = ctx.targetArch)

    # If package is in a different repo than the commit repo, use HEAD version
    if repo != ctx.commitRepo:
        debug "dephandler: Package '"&name&"' is in different repo ('"&repo&"' vs commit repo '"&ctx.commitRepo&"'), using HEAD"
        return parseRunfile(repo&"/"&name, arch = ctx.targetArch)

    # Package is in the commit repo - compare versions
    # Current state is at commit (repo is checked out)
    let commitRf = parseRunfile(repo&"/"&name, arch = ctx.targetArch)
    let commitVersion = commitRf.versionString

    # Get HEAD version from cache
    if name in ctx.headRunfileCache:
        let headRf = ctx.headRunfileCache[name]
        let headVersion = headRf.versionString

        if isNewer(headVersion, commitVersion):
            info "Using '"&name&"' version "&headVersion&" (HEAD) instead of "&commitVersion&" (commit)"
            return headRf
        else:
            if headVersion != commitVersion:
                info "Using '"&name&"' version "&commitVersion&" (commit) instead of "&headVersion&" (HEAD)"
            return commitRf
    else:
        # Package doesn't exist at HEAD (new package at commit, or was deleted)
        debug "dephandler: Package '"&name&"' not in HEAD cache, using commit version"
        return commitRf

proc selectDependencyList(pkgrf: runFile, bdeps: bool, useBootstrap: bool): seq[string] =
    ## Select appropriate dependency list based on flags

    if useBootstrap and pkgrf.bsdeps.len > 0:
        return pkgrf.bsdeps
    elif bdeps:
        return pkgrf.bdeps
    else:
        return pkgrf.deps

proc validatePackage(pkg: string, repo: string, root: string): bool =
    ## Validate package exists in repository

    if repo == "":
        error("Package '"&pkg&"' doesn't exist in any configured repository")
        quit(1)
    elif repo == "local":
        if not packageExists(pkg, root):
            debug "dephandler: Package '"&pkg&"' doesn't exist in local database at '"&root&"'"
            return false
        return true
    elif not dirExists(repo):
        error("The repository '"&repo&"' doesn't exist at path: "&repo)
        quit(1)
    elif not fileExists(repo&"/"&pkg&"/run") and not fileExists(
            repo&"/"&pkg&"/run3"):
        error("The package '"&pkg&"' doesn't exist in repository "&repo&" (expected: "&repo&"/"&pkg&"/run or "&repo&"/"&pkg&"/run3)")
        quit(1)

    return true

proc checkVersions(root: string, dependency: string, repo: string,
        targetArch = "", split = @[
        "<=", ">=", "<", ">", "="]): seq[string] =
    ## Check version requirements on dependency

    for i in split:
        if i in dependency:

            let dSplit = dependency.split(i)
            var deprf: string

            if packageExists(dSplit[0], root):
                deprf = getPackage(dSplit[0], root).version
            else:
                var r = repo

                if repo == "local":
                    r = findPkgRepo(r)

                debug "dephandler: parseRunfile ran, checkVersions"
                deprf = parseRunfile(r&"/"&dSplit[0], arch = effectiveArch(targetArch)).versionString

            let warnName = "Required dependency version for "&dSplit[
                    0]&" not found, upgrading"
            let errName = "Required dependency version for "&dSplit[
                    0]&" not found on repositories, cannot continue"


            case i:
                of "<=":
                    if not (deprf <= dSplit[1]):
                        if packageExists(dSplit[0], root):
                            warn(warnName)
                            return @["upgrade", dSplit[0]]
                        else:
                            error(errName)
                            quit(1)
                of ">=":
                    if not (deprf >= dSplit[1]):
                        if packageExists(dSplit[0], root):
                            warn(warnName)
                            return @["upgrade", dSplit[0]]
                        else:
                            error(errName)
                            quit(1)
                of "<":
                    if not (deprf < dSplit[1]):
                        if packageExists(dSplit[0], root):
                            warn(warnName)
                            return @["upgrade", dSplit[0]]
                        else:
                            error(errName)
                            quit(1)
                of ">":
                    if not (deprf > dSplit[1]):
                        if packageExists(dSplit[0], root):
                            warn(warnName)
                            return @["upgrade", dSplit[0]]
                        else:
                            error(errName)
                            quit(1)
                of "=":
                    if deprf != dSplit[1]:
                        if packageExists(dSplit[0], root):
                            warn(warnName)
                            return @["upgrade", dSplit[0]]
                        else:
                            error(errName)
                            quit(1)

            return @["noupgrade", dSplit[0]]

    return @["noupgrade", dependency]


proc initDependencyGraph*(): dependencyGraph =
    ## Initialize an empty dependency graph
    result.nodes = initTable[string, resolvedPackage]()
    result.edges = initTable[string, seq[string]]()

proc addNode(graph: var dependencyGraph, pkg: resolvedPackage) =
    ## Add a package node to the graph
    graph.nodes[pkg.name] = pkg
    if not graph.edges.hasKey(pkg.name):
        graph.edges[pkg.name] = @[]

proc addEdge(graph: var dependencyGraph, fromPkg: string, toPkg: string) =
    ## Add a dependency edge from one package to another
    if not graph.edges.hasKey(fromPkg):
        graph.edges[fromPkg] = @[]
    if toPkg notin graph.edges[fromPkg]:
        graph.edges[fromPkg].add(toPkg)

proc shouldSkipInstalledDependency*(isInstalled: bool, versionAction: string,
        depName, dependentName: string, rootPkgNames: HashSet[string],
        forceInstallAll: bool,
        bootstrapSatisfiedEdges: HashSet[DependencyEdge]): bool =
    ## Omit only an edge that was explicitly broken by a successful bootstrap
    ## build. Other consumers of the seed must retain their ordering edge so
    ## they build after the final, non-bootstrap package.
    if (dependency: depName, dependent: dependentName) in bootstrapSatisfiedEdges:
        return true
    return isInstalled and versionAction != "upgrade" and
            depName notin rootPkgNames and not forceInstallAll

proc buildDependencyGraph*(pkgs: seq[string], ctx: dependencyContext,
                          ignoreDeps: seq[string] = @["  "],
                          chkInstalledDirInstead = false,
                          isInstallDir = false,
                          prevPkgName = ""): dependencyGraph =
    ## Build dependency graph by traversing all dependencies

    var graph = initDependencyGraph()
    var toProcess = pkgs
    var processed: HashSet[string]

    # Identify root packages by name so we don't skip them if they appear as dependencies
    var rootPkgNames = initHashSet[string]()
    for p in pkgs:
        if not isEmptyOrWhitespace(p) and p notin ignoreDeps:
            let info = resolvePackageRepo(p, chkInstalledDirInstead, isInstallDir)
            rootPkgNames.incl(info.name)

    while toProcess.len > 0:
        let p = toProcess.pop()

        if p in processed or p in ignoreDeps or isEmptyOrWhitespace(p):
            debug "dephandler: Skipping '"&p&"' (processed="&($(p in
                    processed))&", ignoreDeps="&($(p in
                    ignoreDeps))&", empty="&($(isEmptyOrWhitespace(p)))&")"
            continue
        debug "dephandler: Processing package '"&p&"'"
        processed.incl(p)

        # Resolve package info
        let pkgInfo = resolvePackageRepo(p, chkInstalledDirInstead, isInstallDir)
        let pkg = pkgInfo.name
        var repo = pkgInfo.repo

        # Validate package exists
        if not validatePackage(pkg, repo, ctx.root):
            # Local-only resolution is used while copying the build
            # environment from an existing root.  A dependency that is not
            # installed in that root cannot be loaded with getPackage(); it
            # will be handled by the normal repository dependency resolver
            # when needed.  Do not turn this expected absence into an
            # unhandled database exception.
            debug "dephandler: Package '"&pkg&"' validation failed (repo: '"&repo&"'), skipping"
            continue

        let pkgrf = loadPackageMetadataCommitAware(pkg, repo, ctx)

        # Create resolved package node
        let resolvedPkg = resolvedPackage(
            name: pkg,
            repo: repo,
            metadata: pkgrf
        )

        # Add to graph
        debug "dephandler: Adding node '"&pkg&"' to graph (repo: '"&repo&"')"
        addNode(graph, resolvedPkg)

        # Handle init-specific packages
        if not ctx.ignoreInit and not isEmptyOrWhitespace(ctx.init):
            let initPkg = pkg&"-"&ctx.init
            let initPkgExists = if isInstallDir: dirExists(
                    repo&"/"&initPkg) else: findPkgRepo(initPkg) != ""
            debug "dephandler: Checking init package '"&initPkg&"' for '"&pkg&"' (exists: "&(
                    $initPkgExists)&")"
            if initPkgExists:
                let initPkgToAdd = if isInstallDir: repo&"/"&initPkg else: initPkg
                if initPkgToAdd notin processed and initPkgToAdd notin toProcess:
                    debug "dephandler: Adding init package '"&initPkgToAdd&"' to processing queue"
                    toProcess.add(initPkgToAdd)
                    addEdge(graph, initPkg, pkg) # Edge from dependency to dependent
        
        # Process build dependencies first if this is a build
        # Use bootstrap deps if in bootstrap mode and they exist, otherwise use regular build deps
        # Skip build deps if useCacheIfAvailable is true and cached build exists
        let buildDeps = selectDependencyList(pkgrf, true, ctx.useBootstrap)
        #let skipBuildDeps = ctx.useCacheIfAvailable and repo != "local" and hasCachedBuild(pkg, repo, ctx.root)
        #if skipBuildDeps:
        #    debug "dephandler: Package '"&pkg&"' has cached build, skipping build dependencies"

        if ctx.isBuild and not isEmptyOrWhitespace(buildDeps.join()): #and not skipBuildDeps:
            debug "dephandler: Processing "&(
                    $buildDeps.len)&" build dependencies for '"&pkg&"': "&buildDeps.join(", ")
            for bdep in buildDeps:
                if isEmptyOrWhitespace(bdep) or bdep in ignoreDeps:
                    debug "dephandler: Skipping build dep '"&bdep&"' (empty or in ignoreDeps)"
                    continue

                # Check version requirements
                let chkVer = checkVersions(ctx.root, bdep, repo, ctx.targetArch)
                let depName = chkVer[1]

                # Preserve installed-package behavior, except for an exact edge
                # explicitly removed after a successful bootstrap build.
                if shouldSkipInstalledDependency(packageExists(depName,
                        ctx.root), chkVer[0], depName, pkg, rootPkgNames,
                                ctx.forceInstallAll,
                        ctx.bootstrapSatisfiedEdges):
                    debug "dephandler: Package '"&depName&"' already installed, skipping"
                    continue

                # Update repo for dependency
                if not chkInstalledDirInstead:
                    let depRepo = findPkgRepo(depName)
                    debug "dephandler: findPkgRepo('"&depName&"') returned '"&depRepo&"' for build dep"
                    if depRepo != "":
                        repo = depRepo
                    else:
                        debug "dephandler: Build dep '"&depName&"' not found in any repository!"

                # Skip self-dependency if the package is already installed
                # (e.g., gmake requiring gmake to build - use the installed gmake)
                if depName == pkg and packageExists(depName, ctx.root):
                    debug "dephandler: Skipping self-dependency '"&depName&"' (already installed)"
                    continue

                # Add edge and schedule for processing (edge from dependency to dependent)
                debug "dephandler: Adding edge '"&depName&"' -> '"&pkg&"' for build dep"
                addEdge(graph, depName, pkg)
                # Add to processing queue if not already there
                # When forceInstallAll=true, we may re-add packages that were processed but skipped due to being installed
                # When isInstallDir=true, add full path so dependency resolution works correctly
                let depToAdd = if isInstallDir: repo&"/"&depName else: depName
                if depToAdd notin toProcess:
                    if ctx.forceInstallAll or depToAdd notin processed:
                        toProcess.add(depToAdd)

        # Process runtime dependencies (use bootstrap if requested)
        let runtimeDeps = selectDependencyList(pkgrf, false, ctx.useBootstrap)

        if not isEmptyOrWhitespace(runtimeDeps.join()):
            debug "dephandler: Processing "&(
                    $runtimeDeps.len)&" runtime dependencies for '"&pkg&"': "&runtimeDeps.join(", ")
            for dep in runtimeDeps:
                if isEmptyOrWhitespace(dep) or dep in ignoreDeps:
                    debug "dephandler: Skipping runtime dep '"&dep&"' (empty or in ignoreDeps)"
                    continue

                # Check version requirements
                let chkVer = checkVersions(ctx.root, dep, repo, ctx.targetArch)
                let depName = chkVer[1]

                # Preserve installed-package behavior, except for an exact edge
                # explicitly removed after a successful bootstrap build.
                if shouldSkipInstalledDependency(packageExists(depName,
                        ctx.root), chkVer[0], depName, pkg, rootPkgNames,
                                ctx.forceInstallAll,
                        ctx.bootstrapSatisfiedEdges):
                    debug "Package '"&depName&"' already installed, skipping"
                    continue

                # Update repo for dependency
                if not chkInstalledDirInstead:
                    let depRepo = findPkgRepo(depName)
                    if depRepo != "":
                        repo = depRepo

                # Skip self-dependency if the package is already installed
                # (e.g., gmake requiring gmake to build - use the installed gmake)
                if depName == pkg and packageExists(depName, ctx.root):
                    debug "dephandler: Skipping self-dependency '"&depName&"' (already installed)"
                    continue

                # Add edge and schedule for processing (edge from dependency to dependent)
                addEdge(graph, depName, pkg)
                # Add to processing queue if not already there
                # When forceInstallAll=true, we may re-add packages that were processed but skipped due to being installed
                # When isInstallDir=true, add full path so dependency resolution works correctly
                let depToAdd = if isInstallDir: repo&"/"&depName else: depName
                if depToAdd notin toProcess:
                    if ctx.forceInstallAll or depToAdd notin processed:
                        debug "dephandler: Adding runtime dep '"&depToAdd&"' to processing queue"
                        toProcess.add(depToAdd)
                    else:
                        debug "dephandler: Runtime dep '"&depToAdd&"' already processed and not forcing, skipping"
                else:
                    debug "dephandler: Runtime dep '"&depToAdd&"' already in processing queue"

    debug "dephandler: Finished building dependency graph with "&(
            $graph.nodes.len)&" nodes"
    return graph

proc topologicalSort(graph: dependencyGraph,
        ignoreCircularDeps: bool = false): SortResult =
    ## Perform topological sort using DFS to determine installation order
    ## Returns SortResult with packages in order where dependencies come before dependents
    ##
    ## Graph structure: edges go FROM dependency TO dependent
    ## Example: graph.edges["openssl"] = ["python"] means python depends on openssl
    ##
    ## If a cycle is detected:
    ## - hasCycle will be true and cyclePath will contain the cycle
    ## - If ignoreCircularDeps is true, a warning is shown but processing continues
    ## - If ignoreCircularDeps is false, caller should handle the cycle (e.g., auto-bootstrap)

    var visited = initTable[string, bool]()
    var visiting = initTable[string, bool]()
    var sortResult: seq[string] = @[]
    var visitStack: seq[string] = @[] # Track the current DFS path for cycle reporting
    var cycleDetected = false
    var cyclePath: seq[string] = @[]

    proc visit(node: string) =
        # Stop processing if cycle already detected
        if cycleDetected:
            return

        # Check for cycles - if we're visiting a node that's already in progress,
        # we've found a cycle
        if visiting.getOrDefault(node, false):
            # Extract the cycle from visitStack
            let cycleStart = visitStack.find(node)
            if cycleStart >= 0:
                cyclePath = visitStack[cycleStart .. ^1]
                cyclePath.add(node) # Close the cycle
            else:
                cyclePath = @[node]
            cycleDetected = true
            return

        # Skip if already processed
        if visited.getOrDefault(node, false):
            return

        # Mark as currently being visited (for cycle detection)
        visiting[node] = true
        visitStack.add(node)

        # Recursively visit all nodes this node points to (dependents)
        # We visit dependents first so they get added to result first
        if graph.edges.hasKey(node):
            for dependent in graph.edges[node]:
                visit(dependent)
                if cycleDetected:
                    return

        # Pop from stack and mark as fully visited
        visitStack.setLen(visitStack.len - 1)
        visiting[node] = false
        visited[node] = true

        # Add to result AFTER visiting all dependents (post-order DFS)
        # This means dependents are earlier in the list
        sortResult.add(node)

    # Visit all nodes (handles disconnected components)
    for node in graph.nodes.keys:
        if not visited.getOrDefault(node, false):
            visit(node)
            if cycleDetected:
                break

    # Handle cycle detection result
    if cycleDetected:
        debug "which came first, the chicken or the egg?"
        let cycleMsg = "circular dependency detected: " & cyclePath.join(
                " -> ") &
            ". Use bootstrap dependencies (bsdeps) to break the cycle."
        if ignoreCircularDeps:
            warn(cycleMsg)

    # Reverse: since we added dependents before dependencies in post-order,
    # reversing gives us dependencies before dependents
    reverse(sortResult)

    return SortResult(order: sortResult, hasCycle: cycleDetected,
            cyclePath: cyclePath)

proc flattenDependencyOrder*(graph: dependencyGraph,
        ignoreCircularDeps: bool = false): SortResult =
    ## Convert graph to installation order (dependencies first)
    ## Returns SortResult with order and cycle information

    # Topological sort now gives us the correct order directly
    # (dependencies before dependents) since edges go from dependency to dependent
    let sorted = topologicalSort(graph, ignoreCircularDeps)
    debug "dephandler: Topological sort result ("&(
            $sorted.order.len)&" packages): "&sorted.order.join(", ")
    return sorted

proc generateMermaidChart*(graph: dependencyGraph, rootPackages: seq[
        string]): string =
    ## Generate Mermaid flowchart from dependency graph

    var output = "graph TD\n"
    var nodeIds = initTable[string, string]()
    var nodeCounter = 0

    # Generate unique IDs for each package node
    for node in graph.nodes.keys:
        let nodeId = "N" & $nodeCounter
        nodeIds[node] = nodeId
        nodeCounter += 1

    # Create nodes with labels
    for node, pkg in graph.nodes.pairs:
        let nodeId = nodeIds[node]
        let label = node

        # Highlight root packages differently
        if node in rootPackages:
            output &= "    " & nodeId & "[\"" & label & "\"]\n"
            output &= "    style " & nodeId & " fill:#4a9eff,stroke:#2d7dd2,stroke-width:3px,color:#fff\n"
        else:
            output &= "    " & nodeId & "[\"" & label & "\"]\n"

    # Create edges (dependency relationships)
    for fromNode, toNodes in graph.edges.pairs:
        if nodeIds.hasKey(fromNode):
            let fromId = nodeIds[fromNode]
            for toNode in toNodes:
                if nodeIds.hasKey(toNode):
                    let toId = nodeIds[toNode]
                    output &= "    " & fromId & " --> " & toId & "\n"

    return output


proc generateDependencyJson*(graph: dependencyGraph, rootPackages: seq[
        string]): string =
    ## Generate the stable, machine-readable dependency graph schema.
    ## Edges use the graph's native dependency -> dependent direction.
    var roots = rootPackages
    roots.sort()
    roots = roots.deduplicate()

    var nodeNames = toSeq(graph.nodes.keys)
    nodeNames.sort()
    var nodes = newJArray()
    for name in nodeNames:
        let pkg = graph.nodes[name]
        let runtimeDependencies = pkg.metadata.deps.sorted()
        let buildDependencies = pkg.metadata.bdeps.sorted()
        let bootstrapDependencies = pkg.metadata.bsdeps.sorted()
        nodes.add(%*{
            "name": name,
            "repo": pkg.repo,
            "depends": runtimeDependencies,
            "build_depends": buildDependencies,
            "bootstrap_depends": bootstrapDependencies
        })

    var dependencyEdges: seq[DependencyEdge] = @[]
    for dependency, dependents in graph.edges.pairs:
        if graph.nodes.hasKey(dependency):
            for dependent in dependents:
                if graph.nodes.hasKey(dependent):
                    dependencyEdges.add((dependency: dependency,
                            dependent: dependent))
    dependencyEdges.sort(proc(a, b: DependencyEdge): int =
        result = cmp(a.dependency, b.dependency)
        if result == 0:
            result = cmp(a.dependent, b.dependent)
    )

    var edges = newJArray()
    for edge in dependencyEdges:
        edges.add(%*{"dependency": edge.dependency,
                "dependent": edge.dependent})

    let document = %*{
        "schema_version": 1,
        "roots": roots,
        "nodes": nodes,
        "edges": edges
    }
    return $document


proc dephandler*(pkgs: seq[string], ignoreDeps = @["  "],
        isBuild = false, root: string, prevPkgName = "",
                forceInstallAll = false, chkInstalledDirInstead = false,
                        isInstallDir = false, ignoreInit = false,
                        useBootstrap = false, ignoreCircularDeps = false,
                        useCacheIfAvailable = false,
                        commit = "", commitRepo = "",
                        headRunfileCache = initTable[string, runFile](),
                        targetArch = ""): seq[string] =
    ## Takes packages and returns what to install in correct dependency order
    ## When isBuild = true, returns both build dependencies and runtime dependencies in correct order
    ##
    ## Commit-based build parameters:
    ## - commit: The commit hash being built from
    ## - commitRepo: The repo path that was checked out to the commit
    ## - headRunfileCache: Cached runfiles from HEAD (before checkout)
    ##
    ## targetArch selects `depends_<arch>` / `build_depends_<arch>` groups; an
    ## empty value means the host architecture.

    # Build dependency context
    var init = ""
    if not ignoreInit:
        init = getInit(root)

    let ctx = dependencyContext(
        root: root,
        isBuild: isBuild,
        useBootstrap: useBootstrap,
        ignoreInit: ignoreInit,
        ignoreCircularDeps: ignoreCircularDeps,
        forceInstallAll: forceInstallAll,
        useCacheIfAvailable: useCacheIfAvailable,
        init: init,
        commit: commit,
        commitRepo: commitRepo,
        headRunfileCache: headRunfileCache,
        targetArch: effectiveArch(targetArch)
    )

    # Build the dependency graph
    let graph = buildDependencyGraph(
        pkgs, ctx, ignoreDeps,
        chkInstalledDirInstead, isInstallDir, prevPkgName
    )

    # Flatten to installation order
    let sortResult = flattenDependencyOrder(graph, ctx.ignoreCircularDeps)

    # Filter out root packages (the packages being built/installed) and empty strings
    # We only want the dependencies, not the target packages themselves
    let rootPkgSet = pkgs.toHashSet()
    debug "dephandler: Root packages to filter out: "&pkgs.join(", ")
    let filtered = sortResult.order.filterIt(it.len != 0 and it notin rootPkgSet)
    debug "dephandler: After filtering root packages: "&filtered.join(", ")

    # Deduplicate and return
    let finalResult = deduplicate(filtered)
    debug "dephandler: Final dependency list ("&(
            $finalResult.len)&" packages): "&finalResult.join(", ")
    return finalResult

proc dephandlerWithGraph*(pkgs: seq[string], ignoreDeps = @["  "],
        isBuild = false, root: string, prevPkgName = "",
                forceInstallAll = false, chkInstalledDirInstead = false,
                        isInstallDir = false, ignoreInit = false,
                        useBootstrap = false, ignoreCircularDeps = false,
                         useCacheIfAvailable = false,
                         commit = "", commitRepo = "",
                         headRunfileCache = initTable[string, runFile](),
                         bootstrapSatisfied = initHashSet[string](),
                         bootstrapSatisfiedEdges = initHashSet[DependencyEdge](),
                         targetArch = ""): (seq[
                                string],
                        dependencyGraph, SortResult) =
    ## Takes packages and returns what to install in correct dependency order PLUS the dependency graph
    ## This allows reusing the graph structure instead of recalculating dependencies
    ##
    ## Returns: (deps, graph, sortResult) where sortResult contains cycle information
    ##
    ## Commit-based build parameters:
    ## - commit: The commit hash being built from
    ## - commitRepo: The repo path that was checked out to the commit
    ## - headRunfileCache: Cached runfiles from HEAD (before checkout)
    ##
    ## targetArch selects `depends_<arch>` / `build_depends_<arch>` groups; an
    ## empty value means the host architecture.

    # Build dependency context
    var init = ""
    if not ignoreInit:
        init = getInit(root)

    let ctx = dependencyContext(
        root: root,
        isBuild: isBuild,
        useBootstrap: useBootstrap,
        ignoreInit: ignoreInit,
        ignoreCircularDeps: ignoreCircularDeps,
        forceInstallAll: forceInstallAll,
        useCacheIfAvailable: useCacheIfAvailable,
        init: init,
        commit: commit,
        commitRepo: commitRepo,
        headRunfileCache: headRunfileCache,
        targetArch: effectiveArch(targetArch),
        bootstrapSatisfied: bootstrapSatisfied,
        bootstrapSatisfiedEdges: bootstrapSatisfiedEdges
    )

    # Build the dependency graph
    let graph = buildDependencyGraph(
        pkgs, ctx, ignoreDeps,
        chkInstalledDirInstead, isInstallDir, prevPkgName
    )

    # Flatten to installation order
    let sortResult = flattenDependencyOrder(graph, ctx.ignoreCircularDeps)

    # Filter out root packages (the packages being built/installed) and empty strings
    let rootPkgSet = pkgs.toHashSet()
    debug "dephandler: Root packages to filter out: "&pkgs.join(", ")
    let filtered = sortResult.order.filterIt(it.len != 0 and it notin rootPkgSet)
    debug "dephandler: After filtering root packages: "&filtered.join(", ")

    # Return both the dependency list and the graph
    let finalResult = deduplicate(filtered)
    debug "dephandler: Final dependency list ("&(
            $finalResult.len)&" packages): "&finalResult.join(", ")
    return (finalResult, graph, sortResult)

proc finalRetryPackages*(requestedPackages, bootstrapPackages: seq[
        string]): seq[string] =
    ## Bootstrap seeds must remain explicit roots for the normal retry. This
    ## preserves their normal build-dependency edges while bootstrapSatisfied
    ## suppresses only the cycle-closing back-edge.
    deduplicate(requestedPackages & bootstrapPackages)

proc computeBuildQueue*(depGraph: dependencyGraph,
                        requestedPackages: seq[string],
                        bootstrap: bool,
                        bootstrapSatisfied = initHashSet[string]()): seq[string]

proc collectRuntimeDepsFromGraph*(pkgs: seq[string], graph: dependencyGraph,
        visited: var HashSet[string]): seq[string] =
    ## Recursively collect all runtime dependencies from the graph (exported for reuse)
    result = @[]

    for pkg in pkgs:
        if pkg in visited or pkg notin graph.nodes:
            continue
        visited.incl(pkg)
        result.add(pkg)

        # Recursively get runtime deps
        let runtimeDeps = graph.nodes[pkg].metadata.deps
        let transitiveDeps = collectRuntimeDepsFromGraph(runtimeDeps, graph, visited)
        result = result & transitiveDeps

proc collectDynamicSandboxDeps*(packageName: string,
        metadataResolver: proc(pkg: string): runFile): seq[string] =
    ## Resolve the sandbox closure when a package was queued after graph creation.
    let metadata = metadataResolver(packageName)
    var deps = metadata.bdeps
    var visited = initHashSet[string]()

    proc addRuntimeDeps(pkg: string) =
        if pkg in visited:
            return
        visited.incl(pkg)
        deps.add(pkg)
        for dep in metadataResolver(pkg).deps:
            addRuntimeDeps(dep)

    for dep in metadata.deps:
        addRuntimeDeps(dep)
    return deduplicate(deps)

proc resolveBuildOrderImpl(packages: seq[string], ctx: dependencyContext,
                        bootstrap: bool, isInstallDir: bool): (seq[string],
                                dependencyGraph, seq[string], SortResult) =
    ## Resolve the complete build order for packages.
    ##
    ## This handles:
    ## - Building the initial dependency graph
    ## - Finding packages that depend on what we're building (dependents)
    ## - Rebuilding graph with dependents included
    ## - Flattening to correct build order
    ## - Moving bootstrap deps to end when not in bootstrap mode
    ##
    ## Returns: (orderedDeps, graph, allDependents, sortResult)

    # Build the initial dependency graph
    var deps: seq[string]
    var depGraph: dependencyGraph
    var sortResult: SortResult
    (deps, depGraph, sortResult) = dephandlerWithGraph(packages,
            isBuild = ctx.isBuild, root = ctx.root,
            forceInstallAll = ctx.forceInstallAll,
            isInstallDir = isInstallDir, ignoreInit = ctx.ignoreInit,
            useBootstrap = ctx.useBootstrap,
            useCacheIfAvailable = ctx.useCacheIfAvailable,
            commit = ctx.commit, commitRepo = ctx.commitRepo,
            headRunfileCache = ctx.headRunfileCache,
            bootstrapSatisfied = ctx.bootstrapSatisfied,
            bootstrapSatisfiedEdges = ctx.bootstrapSatisfiedEdges)

    # Get packages that depend on what we're building (build dependents)
    let gD = getDependents(deps)

    # Get runtime dependents
    var runtimeDependents: seq[string]
    for pkg in packages:
        let pkgSplit = parsePkgInfo(pkg)
        runtimeDependents = runtimeDependents & getRuntimeDependents(@[
                pkgSplit.name], ctx.root)

    # Remove duplicates and packages already in build dependents
    runtimeDependents = deduplicate(runtimeDependents).filterIt(it notin gD)

    # Combine all dependents
    let allDependents = deduplicate(gD & runtimeDependents)

    # NOTE: allDependents are informational and used by callers for prompts/cache
    # invalidation. They must not be mixed into the execution queue graph,
    # otherwise root filtering can drop required build dependencies.
    #
    # Build queue must be derived strictly from the dependency graph of the
    # originally requested packages.
    deps = computeBuildQueue(depGraph, packages, bootstrap,
            ctx.bootstrapSatisfied)

    return (deps, depGraph, allDependents, sortResult)

proc resolveBuildOrder*(packages: seq[string], ctx: dependencyContext,
                        bootstrap: bool, isInstallDir: bool): (seq[string],
                                dependencyGraph, seq[string], SortResult) =
    var attributes = initTable[string, string]()
    if packages.len > 0:
        attributes["package.name"] = parsePkgInfo(packages[0]).name
    telemetry.withSpan("kpkg.dependency.resolve", attributes):
        return resolveBuildOrderImpl(packages, ctx, bootstrap, isInstallDir)

proc computeBuildQueue*(depGraph: dependencyGraph,
                        requestedPackages: seq[string],
                        bootstrap: bool,
                        bootstrapSatisfied: HashSet[string]): seq[string] =
    ## Compute the build execution queue from dependency graph.
    ## Queue ordering is dependencies first, dependents later.
    ##
    ## The queue is derived from graph topology for the originally requested
    ## package closure only.

    result = flattenDependencyOrder(depGraph).order.filterIt(it.len != 0)

    # For packages with bootstrap deps in non-bootstrap mode,
    # move them to the end to ensure full BUILD_DEPENDS are available.
    if not bootstrap:
        for pkg in requestedPackages:
            let pkgInfo = parsePkgInfo(pkg)
            let pkgName = pkgInfo.name
            if depGraph.nodes.hasKey(pkgName) and depGraph.nodes[
                    pkgName].metadata.bsdeps.len > 0 and
                    pkgName notin bootstrapSatisfied:
                result = result.filterIt(it != pkgName) & pkgName

proc collectInstalledDirectRuntimeDeps*(deps: seq[string],
        depNameResolver: proc(dep: string): string,
        installedResolver: proc(pkg: string): bool): seq[string] =
    ## Installed dependencies can be omitted from the rebuild graph, but an
    ## isolated sandbox still needs the package's declared runtime inputs.
    for dep in deps:
        let depName = depNameResolver(dep)
        if not isEmptyOrWhitespace(depName) and installedResolver(depName):
            result.add(depName)
    return deduplicate(result)

proc getSandboxDepsFromGraph*(pkg: string, graph: dependencyGraph,
        bootstrap: bool, root: string, forceInstallAll: bool,
        isInstallDir: bool, ignoreInit: bool,
        targetArch = ""): seq[string] =
    ## Extract sandbox dependencies for a package from the dependency graph
    ## This avoids recalculating dependencies that were already resolved

    if pkg notin graph.nodes:
        debug "dephandler: Package '"&pkg&"' not found in dependency graph"
        return @[]

    let node = graph.nodes[pkg]
    let isBootstrapBuild = bootstrap and node.metadata.bsdeps.len > 0
    let baseDeps = if isBootstrapBuild: node.metadata.bsdeps else: node.metadata.bdeps

    # Filter baseDeps to only include packages that are already installed locally.
    # Dependencies that need to be built will be handled by the normal build order,
    # not by trying to install them from the local database into the sandbox.
    var sandboxDeps: seq[string] = baseDeps.filterIt(packageExists(it, root))
    var visited = initHashSet[string]()

    # For bootstrap builds: only the bootstrap deps and their transitive runtime deps
    # For regular builds: build deps + package's transitive runtime deps
    if isBootstrapBuild:
        # Bootstrap: get all transitive runtime deps of the bootstrap deps themselves
        let transitiveDeps = collectRuntimeDepsFromGraph(baseDeps, graph, visited)
        sandboxDeps = sandboxDeps & transitiveDeps
    else:
        # Regular build: include the package runtime closure from the graph.
        let transitiveDeps = collectRuntimeDepsFromGraph(@[pkg], graph, visited)
        # Filter out the package itself from its transitive deps.
        sandboxDeps = sandboxDeps & transitiveDeps.filterIt(it != pkg)

        # Installed dependencies are intentionally omitted from a rebuild graph,
        # but they are still required inside this package's isolated sandbox.
        # Add direct installed runtime dependencies explicitly. installFromRoot()
        # will copy each one's registered runtime closure as well.
        sandboxDeps = sandboxDeps & collectInstalledDirectRuntimeDeps(
                node.metadata.deps,
                proc(dep: string): string = checkVersions(root, dep, node.repo, targetArch)[
                        1],
                proc(dep: string): bool = packageExists(dep, root))

    # Add optional dependencies if they're installed
    for optDep in node.metadata.optdeps:
        let optDepName = optDep.split(":")[0]
        if packageExists(optDepName, root):
            sandboxDeps.add(optDepName)

    return deduplicate(sandboxDeps)

proc getBootstrapEdgesForCycle*(cyclePath: seq[string],
        bootstrapPackages: HashSet[string]): HashSet[DependencyEdge] =
    ## Return only the dependency edges in this cycle that originate at a
    ## successfully bootstrapped seed. Suppressing these exact edges breaks the
    ## cycle without dropping ordering constraints for unrelated consumers.
    if cyclePath.len < 2:
        return
    for i in 0 ..< cyclePath.len - 1:
        let dependency = cyclePath[i]
        if dependency in bootstrapPackages:
            result.incl((dependency: dependency, dependent: cyclePath[i + 1]))

proc getPackagesWithBsdeps*(graph: dependencyGraph, cyclePath: seq[
        string]): seq[string] =
    ## Returns packages in the cycle that have bootstrap dependencies
    ## These packages can be bootstrapped to break the circular dependency
    result = @[]

    for pkg in cyclePath:
        if graph.nodes.hasKey(pkg) and graph.nodes[pkg].metadata.bsdeps.len > 0:
            if pkg notin result:
                result.add(pkg)
