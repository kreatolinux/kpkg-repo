## Architecture names shared by the builder, the runfile parser and krep.
##
## kpkg exposes one architecture spelling: the normalized name in `KPKG_ARCH`
## (builder/environment.nim), in `cfg.arch` (builder/main.nim getArch) and in
## the per-architecture runfile keys (`sources_<arch>`, `depends_<arch>`, ...).
## Upstream projects spell the same architecture differently (`amd64`, `arm64`,
## `x86-64`), so recipes may use those aliases; normalizing them here is what
## makes `sources_arm64:` and `sources_aarch64:` the same key.

import strutils
import posix_utils

const knownArchNames* = [
  ## Canonical architecture names. Anything else in a `sources_<arch>` key is a
  ## typo as far as krep lint is concerned (kpkg itself only ever looks up the
  ## normalized target arch, so an unknown suffix is simply never selected).
  "x86_64",
  "aarch64",
  "armv7l",
  "armv6l",
  "riscv64",
  "ppc64le",
  "ppc64",
  "s390x",
  "loongarch64",
  "x86"
]

proc normalizeArch*(arch: string): string =
  ## Normalize an architecture name to kpkg's canonical spelling.
  ##
  ## Accepts the uname machine name (`aarch64`, `x86_64`, `armv7l`), the target
  ## triplet's first component (`amd64`) and the common upstream aliases
  ## (`arm64`, `x64`, `x86-64`, `i686`). An empty input stays empty so callers
  ## can use "" as "not specified".
  var name = arch.strip().toLowerAscii()
  if name.len == 0:
    return ""
  # `x86-64` and `armv8-l` style spellings; triplet components never contain a
  # dash otherwise.
  name = name.replace('-', '_')

  case name
  of "amd64", "x64", "x86_64", "x86_64_v2", "x86_64_v3":
    "x86_64"
  of "arm64", "armv8", "armv8l", "armv8a", "aarch64":
    "aarch64"
  of "i386", "i486", "i586", "i686", "x86", "ia32":
    "x86"
  of "armv7", "armv7l", "armv7hl":
    "armv7l"
  of "armv6", "armv6l":
    "armv6l"
  of "riscv64", "riscv64gc":
    "riscv64"
  of "ppc64le", "powerpc64le":
    "ppc64le"
  of "ppc64", "powerpc64":
    "ppc64"
  of "s390x":
    "s390x"
  of "loongarch64", "loong64":
    "loongarch64"
  else:
    name

proc isKnownArch*(arch: string): bool =
  ## True when `arch` normalizes to a canonical architecture name.
  normalizeArch(arch) in knownArchNames

proc hostArch*(): string =
  ## The host architecture in kpkg's canonical spelling.
  normalizeArch(uname().machine)

proc archNameFromTarget*(target: string): string =
  ## Architecture component of a build target.
  ##
  ## `default` means "build for the host", so it resolves to the host arch; an
  ## explicit target uses its first component (`aarch64-linux-gnu-...` ->
  ## `aarch64`).
  if target == "" or target == "default":
    return hostArch()
  normalizeArch(target.split("-")[0])
