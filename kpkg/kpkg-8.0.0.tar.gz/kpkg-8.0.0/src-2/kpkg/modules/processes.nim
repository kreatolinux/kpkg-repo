import os
import ../../common/logging
import osproc
import streams
import strutils
import commonPaths

proc ensureValidCwd*() =
  ## Ensures the current working directory exists before spawning processes.
  ## osproc (startProcess, execProcess, execCmd, execCmdEx) resolves the cwd
  ## even when no workingDir is given.  A failed transaction can delete that
  ## directory (for example during overlay cleanup or rollback), which makes
  ## every spawn fail with ENOENT and abort cleanup.  Fall back to "/":
  ## every kpkg command uses absolute paths, so the cwd is irrelevant.
  try:
    discard getCurrentDir()
  except OSError:
    debug "current working directory is gone, falling back to /"
    try:
      setCurrentDir("/")
    except OSError:
      discard

proc execCmdKpkg*(command: string, error = "none", silentMode = false): tuple[
    output: string, exitCode: int] =
  # Like execCmdKpkg, but captures output instead of printing (unless not silent).
  debug "execCmdKpkg: command: "&command
  ensureValidCwd()
  let process = startProcess(command, options = {poEvalCommand,
      poStdErrToStdOut, poUsePath})

  # Close stdin to prevent the child process from waiting for input
  close(inputStream(process))

  var line: string
  var output = ""

  let outp = outputStream(process)
  while outp.readLine(line):
    output.add(line & "\n")
    if not silentMode:
      echo line

  let res = waitForExit(process)

  # Release the pipe descriptors: kpkg runs thousands of commands over a
  # bootstrap and never closing the Process leaked fds until the process
  # hit its nofile limit ('Too many open files') mid-run.
  process.close()

  if error != "none" and res != 0:
    fatal error&" failed"

  return (output.strip(), res)

proc getPidKpkg(): string =
  # Gets current pid from /proc/self.
  return lastPathPart(expandSymlink("/proc/self"))

proc isZombie(procPath: string): bool =
  ## True when the /proc entry is a process that has already exited but whose
  ## parent has not reaped it.  Field 3 of /proc/<pid>/stat is the state, but
  ## field 2 (comm) is parenthesised and may itself contain spaces or ')', so
  ## parse from the last ')' rather than splitting on whitespace.
  try:
    let stat = readFile(procPath & "/stat")
    let closeParen = stat.rfind(')')
    if closeParen < 0: return false
    let rest = stat[closeParen + 1 .. ^1].strip()
    return rest.len > 0 and rest[0] in {'Z', 'X'}
  except CatchableError:
    # Entry vanished while we were looking at it; treat as not running.
    return true

proc isRunningFromName(name: string): bool =
  # Allows you to check if it is running from name.
  # Ignores the current process.
  #
  # Zombies must be skipped.  Containers frequently run with a PID 1 that does
  # not reap (the builder image uses `sleep infinity`), so a killed kpkg stays
  # in /proc/<pid>/comm as a zombie forever.  Counting those made every later
  # run abort with "another instance of kpkg is running" until the container
  # was restarted.
  setCurrentDir("/proc")
  for i in walkDir("."):
    try:
      if readFile(i.path&"/comm") == name&"\n" and lastPathPart(i.path) !=
          getPidKpkg():

        debug "proc path: "&lastPathPart(i.path)
        debug getPidKpkg()
        if symlinkExists(i.path):
          if lastPathPart(expandSymlink(i.path)) == getPidKpkg():
            continue
        if isZombie(i.path):
          debug "ignoring zombie: "&lastPathPart(i.path)
          continue
        debug "returning true"
        return true
    except Exception:
      continue

  debug "returning false"
  return false

proc isKpkgRunning*() =
  if isRunningFromName("kpkg"):
    error("another instance of kpkg is running, will not proceed")
    quit(1)

proc runLdconfig*(root: string, silentMode = false): int =
  ## Refresh the dynamic linker cache for the given root.
  ## For non-root paths, runs ldconfig inside a bwrap sandbox to ensure
  ## the cache is generated correctly for the sandbox environment.
  if isEmptyOrWhitespace(root):
    warn "runLdconfig: empty root, skipping"
    return 0

  let cmd = if root == "/": "ldconfig"
            else: "bwrap --bind " & root & " / /bin/sh -c ldconfig"
  debug "runLdconfig: running '" & cmd & "'"
  var res: tuple[output: string, exitCode: int]
  try:
    res = execCmdKpkg(cmd, silentMode = silentMode)
  except CatchableError as e:
    # A missing ldconfig (e.g. not on PATH in a minimal chroot) must not
    # abort the whole build; report it and let the caller decide.
    warn "runLdconfig: could not run '" & cmd & "': " & e.msg
    return 1
  if res.exitCode != 0:
    warn "ldconfig failed (cmd: " & cmd & ", exitCode: " & $res.exitCode & ")"
    debug "ldconfig output: " & res.output
  else:
    debug "runLdconfig: success"
  return res.exitCode

proc execEnv*(command: string, error = "none", passthrough = false,
        silentMode = false, path = kpkgMergedPath, remount = false,
        asRoot = false): tuple[
        output: string, exitCode: int] =
  ## Wrapper of execCmdKpkg and Bubblewrap that runs a command in the sandbox and captures output.
  ## If asRoot is false (default), sets FORCE_UNSAFE_CONFIGURE=1 for build scripts.
  var envPrefix = "LC_ALL=C.UTF-8 LC_CTYPE=C.UTF-8 LANG=C.UTF-8 "
  let pathEnv = getEnv("PATH")
  if pathEnv != "":
    envPrefix = envPrefix & "PATH=" & quoteShell(pathEnv) & " "
  debug "execEnv: entered with path=" & path & ", passthrough=" & $passthrough &
      ", asRoot=" & $asRoot
  if passthrough:
    # Use single quotes for the sh -c argument to avoid escaping issues
    let escapedCmd = command.replace("'", "'\\''")
    # Match the sandbox behavior: as of coreutils 8.68+ (and newer autoconf),
    # running ./configure as root needs this or it refuses to run. Passthrough
    # runs the same build scripts, so it needs the same escape hatch.
    var unsafePrefix = envPrefix
    if not asRoot:
      unsafePrefix = "FORCE_UNSAFE_CONFIGURE=1 " & envPrefix
    return execCmdKpkg(unsafePrefix&"/bin/sh -c '"&escapedCmd&"'", error,
            silentMode = silentMode)
  else:
    debug "execEnv: checking if path exists: " & path
    if not dirExists(path):
      fatal("internal: you have to use mountOverlay() before running execEnv")

    if remount and path == kpkgMergedPath:
      discard execCmdKpkg("mount -o remount "&path,
              silentMode = silentMode)

    # Create dirs so that bwrap doesn't complain
    debug "execEnv: creating dirs"
    createDir(kpkgTempDir1)
    createDir(kpkgTempDir2)
    discard existsOrCreateDir(kpkgCacheDir)
    discard existsOrCreateDir(kpkgSourcesDir)

    # Create bind target directories inside the sandbox path if they don't exist
    debug "execEnv: creating bind target dirs in sandbox"
    debug "execEnv: creating " & path & kpkgTempDir1
    createDir(path & kpkgTempDir1)
    debug "execEnv: creating " & path & kpkgTempDir2
    createDir(path & kpkgTempDir2)
    debug "execEnv: creating " & path & "/etc/kpkg/repos"
    try:
      createDir(path & "/etc/kpkg/repos")
    except OSError as e:
      debug "execEnv: OSError creating " & path & "/etc/kpkg/repos: " & e.msg
      raise
    except CatchableError as e:
      debug "execEnv: CatchableError creating " & path & "/etc/kpkg/repos: " & e.msg
      raise
    debug "execEnv: creating " & path & kpkgSourcesDir
    createDir(path & kpkgSourcesDir)

    debug "execEnv: about to run bwrap with path: " & path & ", command: " & command

    # Set FORCE_UNSAFE_CONFIGURE=1 to allow configure scripts to run as root
    # This is needed because we run as root inside the sandbox for write access
    let forceUnsafeConfigure = if asRoot: "" else: "FORCE_UNSAFE_CONFIGURE=1 "

    # Build bwrap command with proper quoting
    # Use single quotes for the sh -c argument to avoid escaping issues
    # Need to replace any single quotes in command with '\''
    let escapedCmd = command.replace("'", "'\\''")
    let bwrapArgs = [
      "--bind " & path & " /",
      "--bind " & kpkgTempDir1 & " " & kpkgTempDir1,
      "--bind /etc/kpkg/repos /etc/kpkg/repos",
      "--bind " & kpkgTempDir2 & " " & kpkgTempDir2,
      "--bind " & kpkgSourcesDir & " " & kpkgSourcesDir,
      "--dev /dev",
      "--proc /proc",
      "--perms 1777",
      "--tmpfs /dev/shm",
      "--ro-bind /etc/resolv.conf /etc/resolv.conf",
      "/bin/sh -c '" & escapedCmd & "'"
    ]
    let bwrapCmd = "bwrap " & bwrapArgs.join(" ")
    return execCmdKpkg(envPrefix & forceUnsafeConfigure & bwrapCmd,
            error, silentMode = silentMode)

