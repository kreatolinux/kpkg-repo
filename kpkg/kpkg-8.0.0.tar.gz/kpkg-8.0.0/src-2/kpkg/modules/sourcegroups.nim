## Per-architecture source groups of a run3 recipe.
##
## A recipe may declare sources per architecture:
##
##     sources:                     # common: local patches, shared tarballs
##       - "fix-build.patch"
##     sources_aarch64:             # appended after the common list
##       - "https://example.com/tool-${version}-arm64.tar.gz"
##     sha256sum_aarch64:
##       - "...."
##
## kpkg appends the group matching the *target* architecture after the common
## `sources:` entries (see runparser.parseRunfile), so a cross build downloads
## the target's file and nothing else.
##
## This module is the single place that knows how those keys are spelled. It
## works on the Kongue AST only, so the parser (kpkg) and the recipe tooling
## (krep autoupdater, lint, fmt) agree on what a group is. Kongue parses
## `sources_aarch64:` and `sources aarch64:` identically, so the exact
## spelling is recovered from the node.

import algorithm
import strutils
import tables
import ../../kongue/ast
import arch

const
  sourcesBaseKey* = "sources"
  checksumBaseKeys* = ["sha256sum", "sha512sum", "b2sum"]

type
  SourceGroup* = object
    ## One `sources:` list, either the common one or one architecture's.
    arch*: string ## Normalized arch, "" for the common list
    sourcesKey*: string ## Exact key spelling in the recipe
    sourcesLookup*: string ## Full Kongue name used to read the list back
    sha256sumKey*: string ## Exact key spelling, "" when the list is absent
    sha512sumKey*: string
    b2sumKey*: string
    sha256sumLookup*: string
    sha512sumLookup*: string
    b2sumLookup*: string
    sources*: seq[string] ## Items exactly as written (unsubstituted)
    sha256sum*: seq[string]
    sha512sum*: seq[string]
    b2sum*: seq[string]

proc sumKeyFor*(arch: string, base: string): string =
  ## The key a checksum list for `arch` would use, in the underscore spelling.
  ## `arch` must be the exact qualifier spelling used by the recipe's
  ## `sources_<arch>` list.
  if arch.len == 0:
    return base
  base & "_" & arch

proc splitKey(node: AstNode): tuple[base, qualifier, spelling, lookup: string] =
  ## Decompose a list-variable key.
  ##
  ## Kongue accepts `sources_aarch64:` (listName "sources_aarch64") and
  ## `sources aarch64:` (listName "sources" plus qualifier) as the same key;
  ## `spelling` is what the recipe wrote, `lookup` the full Kongue name both
  ## spellings share.
  let name = node.listName
  let qualifier = node.listQualifier
  if qualifier.len > 0:
    return (name, qualifier, name & " " & qualifier, name & "_" & qualifier)

  for base in @[sourcesBaseKey] & @checksumBaseKeys:
    if name.len > base.len and name.startsWith(base) and name[base.len] == '_':
      let suffix = name[base.len + 1 .. ^1]
      return (base, suffix, name, name)
  return (name, "", name, name)

proc sourceGroups*(parsed: ParsedScript): seq[SourceGroup] =
  ## Every source group of a recipe, common list first and then one entry per
  ## architecture, sorted by normalized architecture name.
  ##
  ## A group is only reported when the recipe declares its `sources` list; a
  ## stray `sha256sum_aarch64:` without `sources_aarch64:` is a lint error.
  var byArch = initTable[string, SourceGroup]()
  var order: seq[string] = @[]

  for varNode in parsed.variables:
    if varNode.kind != nkListVariable:
      continue
    let key = splitKey(varNode)
    if key.base != sourcesBaseKey:
      continue
    let arch = if key.qualifier.len == 0: "" else: normalizeArch(key.qualifier)
    if arch.len > 0 and not byArch.hasKey(arch):
      order.add(arch)
    var group = byArch.getOrDefault(arch)
    group.arch = arch
    group.sourcesKey = key.spelling
    group.sourcesLookup = key.lookup
    group.sources = varNode.listItems
    byArch[arch] = group

  for varNode in parsed.variables:
    if varNode.kind != nkListVariable:
      continue
    let key = splitKey(varNode)
    if key.base notin checksumBaseKeys:
      continue
    let arch = if key.qualifier.len == 0: "" else: normalizeArch(key.qualifier)
    if not byArch.hasKey(arch):
      continue
    var group = byArch[arch]
    case key.base
    of "sha256sum":
      group.sha256sumKey = key.spelling
      group.sha256sumLookup = key.lookup
      group.sha256sum = varNode.listItems
    of "sha512sum":
      group.sha512sumKey = key.spelling
      group.sha512sumLookup = key.lookup
      group.sha512sum = varNode.listItems
    of "b2sum":
      group.b2sumKey = key.spelling
      group.b2sumLookup = key.lookup
      group.b2sum = varNode.listItems
    else:
      discard
    byArch[arch] = group

  order.sort()
  if byArch.hasKey(""):
    result.add(byArch[""])
  for arch in order:
    result.add(byArch[arch])

proc archGroups*(parsed: ParsedScript): seq[SourceGroup] =
  ## Only the architecture-specific groups.
  for group in sourceGroups(parsed):
    if group.arch.len > 0:
      result.add(group)

proc archNames*(parsed: ParsedScript): seq[string] =
  ## Normalized names of every architecture that has a `sources_<arch>` list.
  for group in archGroups(parsed):
    result.add(group.arch)

proc checksumFamily*(group: SourceGroup): string =
  ## The single checksum family a group uses ("sha256", "sha512" or "b2").
  ##
  ## "" when the group declares none; raises when it declares more than one,
  ## because the builder prefers b2 over sha512 over sha256 and would silently
  ## ignore the other.
  var families: seq[string] = @[]
  if group.b2sum.len > 0: families.add("b2")
  if group.sha512sum.len > 0: families.add("sha512")
  if group.sha256sum.len > 0: families.add("sha256")
  if families.len > 1:
    raise newException(ValueError, "source group '" & group.sourcesKey &
      "' declares more than one checksum family: " & families.join(", "))
  if families.len == 0:
    return ""
  return families[0]

proc checksumItems*(group: SourceGroup, family: string): seq[string] =
  ## The checksum list of `group` for `family`.
  case family
  of "b2": group.b2sum
  of "sha512": group.sha512sum
  of "sha256": group.sha256sum
  else: @[]

proc checksumKey*(group: SourceGroup, family: string): string =
  ## The exact key spelling of `group`'s checksum list for `family`.
  case family
  of "b2": group.b2sumKey
  of "sha512": group.sha512sumKey
  of "sha256": group.sha256sumKey
  else: ""

proc checksumLookup*(group: SourceGroup, family: string): string =
  ## The Kongue name of `group`'s checksum list for `family`.
  case family
  of "b2": group.b2sumLookup
  of "sha512": group.sha512sumLookup
  of "sha256": group.sha256sumLookup
  else: ""
