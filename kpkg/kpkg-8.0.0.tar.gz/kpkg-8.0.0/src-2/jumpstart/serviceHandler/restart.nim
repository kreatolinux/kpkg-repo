## Automatic restarts of native services (jumpstart_dec(5), Appendix A).
##
## A service whose main process exits on its own is started again after
## `restart_delay` when its unit's `restart` policy says so. The daemon drives
## this from its event loop: `runDueRestarts` performs what is due and
## `nextRestartInMs` tells the loop how long it may sleep. Restarts never run
## inside a reaper callback, and a service restarted more than
## RestartStartLimitBurst times inside RestartStartLimitWindowMs is given up on,
## so a service that cannot stay up cannot spin.
import std/tables
import ../../common/logging
import globalVariables, start

proc restartDue(ctx: NativeContext; name: string; record: ServiceRecord) =
  ## Start `name` again, or give up when its rate window is full.
  let now = restartNowMs()
  record.restartDueMs = 0
  ctx.pruneRestartAttempts(name, now)
  if ctx.restartAttempts.getOrDefault(name).len >= RestartStartLimitBurst:
    error "Not restarting " & name & ": " & $RestartStartLimitBurst &
      " restarts in " & $(RestartStartLimitWindowMs div 1000) &
      " seconds; run jumpctl start to try again"
    return
  # The attempt is counted before it runs: a start that always fails must not
  # be retried faster than the limit allows.
  ctx.noteRestartAttempt(name, now)
  info "Restarting " & name
  try:
    ctx.startService(name, automatic = true)
  except CatchableError as e:
    warn "Restart of " & name & " failed: " & e.msg
    # `startService` leaves the old record in place when the start fails, so a
    # later attempt still has this service's policy.
    let failed = ctx.findService(name)
    if not failed.isNil and not failed.requestedStop:
      failed.restartDueMs = restartNowMs() + int64(failed.restartDelayMs)

proc runDueRestarts*(ctx: NativeContext) =
  ## Perform every restart whose delay expired. Called once per daemon loop
  ## turn, never from a reaper callback.
  let now = restartNowMs()
  var due: seq[string]
  for name, record in ctx.services:
    if record.restartDueMs > 0 and record.restartDueMs <= now: due.add name
  for name in due:
    let record = ctx.findService(name)
    if record.isNil or record.restartDueMs == 0: continue
    if record.running or record.requestedStop:
      record.restartDueMs = 0
      continue
    if record.postRunning:
      # execPost is not cut short: try again after one more delay.
      record.restartDueMs = now + int64(record.restartDelayMs)
      continue
    ctx.restartDue(name, record)

proc nextRestartInMs*(ctx: NativeContext): int =
  ## Milliseconds until the next due restart, or -1 when none is pending.
  var next = high(int64)
  for _, record in ctx.services:
    if record.restartDueMs > 0 and record.restartDueMs < next:
      next = record.restartDueMs
  if next == high(int64): return -1
  let now = restartNowMs()
  if next <= now: 0 else: int(next - now)
