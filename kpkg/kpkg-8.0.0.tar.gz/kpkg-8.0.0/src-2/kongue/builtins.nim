## Built-in commands for Kongue scripting language
## Implements: exec, print, cd, env, local, global, write, append

import os
when not defined(js):
  # No process table in a browser. `exec` is served by ctx.execHook there.
  import osproc
import regex
import strutils
import tables
import ast
import context
import lexer
import variables
import utils

export context
export utils.stripQuotes

when defined(js):
  import jscompat

  # ``quoteShell`` is posix-only in the JS target. POSIX quoting is what we want
  # here, since Kongue commands are POSIX shell strings.
  template quoteShell(s: string): string = quoteShellPosix(s)

proc resolveVariables*(ctx: ExecutionContext, text: string,
    depth: int = 0, shellVariables: bool = false): string

proc defaultExec(ctx: ExecutionContext, command: string, silent: bool): tuple[
    output: string, exitCode: int] =
  ## Default command execution using osproc
  ## This is used when no execHook is set
  when defined(js):
    # Nothing can be spawned in a browser. Callers that want real behaviour
    # must install ctx.execHook; embedders supply a sandboxed one there.
    return ("exec is unavailable in this target", 126)
  else:
    try:
      let (output, exitCode) = execCmdEx(command)
      return (output.strip(), exitCode)
    except OSError as e:
      return ("Error: " & e.msg, 1)

proc reportCommandResult(ctx: ExecutionContext, output: string, exitCode: int) =
  if ctx.commandResultHook != nil:
    try:
      ctx.commandResultHook(output, exitCode)
    except CatchableError:
      warn("command result callback failed")
  if ctx.commandResultContextHook != nil:
    try:
      ctx.commandResultContextHook(ctx, output, exitCode)
    except CatchableError:
      warn("command result callback failed")

proc execCapture(ctx: ExecutionContext, command: string, depth: int = 0): tuple[output: string,
        exitCode: int] =
  ## Execute a command and capture output
  if depth > 10:
    warn("execCapture: maximum recursion depth exceeded, returning empty")
    return ("", 1)

  # The text is a shell command, so names the script does not define are left
  # for the shell unless ctx.shellVariables asked for exact resolution.
  let resolvedCmd = ctx.resolveVariables(command, depth + 1,
      shellVariables = ctx.shellVariables)
  if not ctx.silent:
    echo "[exec capture] " & resolvedCmd

  # Build environment variable exports for the command
  var cmdParts: seq[string] = @[]

  # Add custom environment variables
  for key, val in ctx.envVars:
    cmdParts.add("export " & key & "=" & quoteShell(val))

  # Add standard build variables
  if ctx.destDir != "":
    cmdParts.add("export DESTDIR=" & quoteShell(ctx.destDir))
    if ctx.buildRoot != "":
      cmdParts.add("export ROOT=" & quoteShell(ctx.buildRoot))
  if ctx.srcDir != "":
    cmdParts.add("export SRCDIR=" & quoteShell(ctx.srcDir))
  if ctx.packageName != "":
    cmdParts.add("export PACKAGENAME=" & quoteShell(ctx.packageName))

  # Add cd command
  cmdParts.add("cd " & quoteShell(ctx.currentDir))

  # Add the actual command
  cmdParts.add(resolvedCmd)

  # Combine environment setup with the actual command using &&
  let fullCmd = cmdParts.join(" && ")

  # Use hook if available, otherwise use default execution
  result = if ctx.execHook != nil:
    ctx.execHook(ctx, fullCmd, ctx.silent)
  else:
    defaultExec(ctx, fullCmd, ctx.silent)
  ctx.reportCommandResult(result.output, result.exitCode)


proc resolveManipulation(ctx: ExecutionContext, expr: string,
    depth: int = 0): string =
  ## Resolve the body of one `${...}`: a literal string, a variable, or an
  ## `exec(...)` call, followed by property access, method calls and one index
  ## (kongue(5), VARIABLE MANIPULATION). A method that cannot be applied, a call
  ## that cannot be resolved and an `exec` without `.output()`/`.exit()` are
  ## reported: answering with the empty string would hide the mistake.
  if depth > 10:
    warn("resolveManipulation: maximum recursion depth exceeded, returning empty")
    return ""

  let tokens = tokenize(expr)
  var p = 0

  proc peek(): Token =
    if p < tokens.len: tokens[p] else: Token(kind: tkEof)

  proc advance(): Token =
    result = peek()
    p += 1

  proc source(tok: Token): string =
    ## One token's text as written; a string literal contributes its value.
    if tok.kind in {tkString, tkRegexString}: tok.value
    elif tok.raw.len > 0: tok.raw
    else: tok.value

  proc callArgs(): seq[string] =
    ## The arguments of a call or a method call: each top-level comma-separated
    ## group, with a lone quoted string taken verbatim and a group holding a
    ## reference resolved.
    result = @[]
    if peek().kind != tkLParen:
      return
    discard advance() # (
    var current = ""
    var nesting = 0
    var literal = true
    var iterations = 0
    while true:
      iterations += 1
      if iterations > maxIterations:
        warn("too many iterations in resolveManipulation call arguments, aborting")
        break
      let tok = peek()
      if tok.kind == tkEof:
        break
      elif tok.kind == tkComma and nesting == 0:
        discard advance()
        result.add(if literal: current
                   else: ctx.resolveVariables(current, depth + 1))
        current = ""
        literal = true
        continue
      elif tok.kind == tkRParen and nesting == 0:
        discard advance()
        break
      if tok.kind in {tkLBrace, tkLBracket, tkLParen}: inc nesting
      elif tok.kind in {tkRBrace, tkRBracket, tkRParen}: dec nesting
      if tok.kind != tkString or current.len > 0: literal = false
      if current.len > 0 and tok.spaceBefore: current.add ' '
      current.add source(tok)
      discard advance()
    if current.len > 0:
      result.add(if literal: current else: ctx.resolveVariables(current, depth + 1))

  var baseValue: VarValue
  var execResult: tuple[output: string, exitCode: int]
  var execPending = false

  case peek().kind
  of tkString:
    baseValue = newStringValue(advance().value) # ${"literal"}
  of tkExec:
    discard advance() # exec
    let argv = callArgs()
    if argv.len == 0:
      error("exec(...) in ${" & expr & "} needs a command")
      return ""
    # One argument is a shell command as written; several are words of one
    # command, each quoted so an argument keeps its own spacing.
    var command = ""
    for i, arg in argv:
      if i > 0: command.add ' '
      command.add(if argv.len == 1: arg else: quoteShell(arg))
    execResult = ctx.execCapture(command, depth + 1)
    baseValue = newStringValue(execResult.output)
    execPending = true
  of tkIdentifier:
    let varName = advance().value
    if peek().kind == tkLParen:
      # The only call a `${...}` can run is `exec(...)`; a manifest's calls are
      # rewritten before the script is parsed, so this one cannot run.
      error("unsupported function call in ${" & expr & "}: " & varName & "(...)")
      return ""
    if ctx.hasObjectVariable(varName):
      baseValue = ctx.getObjectVariable(varName)
    elif ctx.hasListVariable(varName):
      baseValue = newListValue(ctx.getListVariable(varName))
    else:
      baseValue = newStringValue(ctx.getVariable(varName))
  else:
    error("unsupported expression in ${" & expr & "}")
    return ""

  var methods: seq[VarManipMethod] = @[]
  var indexExpr = ""
  var iterations = 0

  while true:
    iterations += 1
    if iterations > maxIterations:
      warn("too many iterations in resolveManipulation, aborting")
      break
    let tok = peek()
    if tok.kind == tkDot:
      discard advance() # .
      let methodName = advance().value
      let hasArgs = peek().kind == tkLParen
      if execPending:
        # `exec(...)` is followed by `.output()` or `.exit()`; anything else is
        # a mistake, not an output string that silently loses the suffix.
        execPending = false
        if methodName == "output" and hasArgs:
          baseValue = newStringValue(execResult.output)
        elif methodName == "exit" and hasArgs:
          baseValue = newStringValue($execResult.exitCode)
        else:
          error("exec(...) in ${" & expr &
              "} must be followed by .output() or .exit(), not ." & methodName)
          return ""
        discard callArgs()
        continue
      let args = if hasArgs: callArgs() else: newSeq[string]()
      if baseValue.kind == vvkObject and args.len == 0:
        # An object's members are read as properties.
        if baseValue.objVal.hasKey(methodName):
          baseValue = baseValue.objVal[methodName]
        else:
          baseValue = newStringValue("")
        continue
      methods.add(VarManipMethod(name: methodName, args: args))
    elif tok.kind == tkLBracket:
      discard advance() # [
      indexExpr = ""
      var nesting = 0
      while true:
        iterations += 1
        if iterations > maxIterations:
          warn("too many iterations in resolveManipulation index, aborting")
          break
        let t = peek()
        if t.kind == tkEof:
          break
        elif t.kind == tkRBracket and nesting == 0:
          discard advance()
          break
        if t.kind in {tkLBrace, tkLBracket, tkLParen}: inc nesting
        elif t.kind in {tkRBrace, tkRBracket, tkRParen}: dec nesting
        if indexExpr.len > 0 and t.spaceBefore: indexExpr.add ' '
        indexExpr.add source(t)
        discard advance()
      # The index may itself be a reference, as in `${v[${i}]}`.
      indexExpr = ctx.resolveVariables(indexExpr, depth + 1)
    else:
      break

  try:
    return evaluateVarManipulation(baseValue, methods, indexExpr).toString()
  except ValueError as e:
    error("${" & expr & "}: " & e.msg)
    return ""

proc isShellVariableName(name: string): bool =
  ## True for a name the POSIX shell itself owns: a positional or special
  ## parameter ($1, $2, ...) or a plain identifier; a method call, an index or
  ## an object property is Kongue syntax, never handed to the shell.
  if name.len == 0:
    return false
  if name[0].isDigit():
    for c in name:
      if not c.isDigit():
        return false
    return true
  for c in name:
    if not (c.isAlphaNumeric() or c == '_'):
      return false
  true

proc isShellPositional(expr: string): bool =
  ## True for a shell positional parameter: ``1``, ``2``, ... or one of the
  ## special parameters ``@ * # ? $ ! -``. These stay the shell's even when a
  ## Kongue `func` bound ``localVars["1"]`` to its own first argument.
  if expr.len == 0:
    return false
  if expr in ["@", "*", "#", "?", "$", "!", "-"]:
    return true
  for c in expr:
    if not c.isDigit():
      return false
  true

proc shellBraceBaseName(expr: string): string =
  ## The leading identifier of a ``${...}`` body, or "" when it does not start
  ## with one (``${1}``, ``${@}``, ``${#name}``, ...).
  var i = 0
  while i < expr.len and (expr[i].isAlphaNumeric() or expr[i] == '_'):
    inc i
  if i == 0 or not (expr[0].isAlphaAscii() or expr[0] == '_'):
    return ""
  expr[0 ..< i]

proc isShellBraceExpr(expr: string): bool =
  ## True for the inside of a ``${...}`` that only the shell can interpret:
  ## the special parameters (``${@}``, ``${?}``, ``${#}``, ...), the length and
  ## indirect forms, and parameter expansion such as ``${name:-default}``.
  ## ``.`` and ``[`` are Kongue method/property/index syntax, never shell syntax.
  if expr.len == 0:
    return false
  if expr[0] in {'@', '*', '#', '?', '$', '!', '-'}:
    return true
  var i = 0
  while i < expr.len and (expr[i].isAlphaNumeric() or expr[i] == '_'):
    inc i
  if i == 0:
    return false
  if i == expr.len:
    return true # a plain name
  # Something follows the name: a shell expansion operator, or a Kongue method
  # call or index ('.', '['), which is not in this set.
  expr[i] in {':', '-', '=', '?', '+', '#', '%', '/'}

proc shellBraceOperator(expr: string): char =
  ## The operator character that follows the base name in a ``${...}`` body, or
  ## ``\0`` when the body is just a name. ``${name:-x}`` yields ``:``.
  var i = 0
  while i < expr.len and (expr[i].isAlphaNumeric() or expr[i] == '_'):
    inc i
  if i == 0 or i >= expr.len:
    return '\0'
  expr[i]

proc resolveVariables*(ctx: ExecutionContext, text: string,
    depth: int = 0, shellVariables: bool = false): string =
  ## Resolve variable references in text
  ## Handles $var and ${var} syntax
  ##
  ## ``shellVariables`` selects the semantics for command text a shell runs
  ## afterwards (``exec``): an undefined name is left as written for the shell.
  ## Without it an undefined name resolves to the empty string, as lifecycle
  ## variables, conditions and manifest mode require.
  if depth > maxRecursionDepth:
    warn("resolveVariables: maximum recursion depth exceeded, returning original text")
    return text

  result = text

  # First pass: Replace ${...} expressions (may contain methods/indexing)
  var i = 0
  while i < result.len:
    if i < result.len - 1 and result[i] == '$' and result[i+1] == '{':
      let (varExpr, endPos) = extractBraceExpr(result, i)
      if varExpr.len > 0:
        let positional = isShellPositional(varExpr)
        # A name the script defines normally wins over the shell, so
        # `${version:-unknown}` resolves to the version. A shell operator other
        # than ':' (`${version-2.0}`, `${name=default}`) Kongue cannot evaluate,
        # so the shell gets it.
        let baseWins = ctx.hasVariable(shellBraceBaseName(varExpr)) and
            (shellBraceOperator(varExpr) in {'\0', ':'})
        if shellVariables and (positional or (not ctx.hasVariable(varExpr) and
            (isShellVariableName(varExpr) or isShellBraceExpr(varExpr)) and
            not baseWins)):
          # A shell positional parameter (``${1}``) is always the shell's, even
          # inside a Kongue `func` where localVars["1"] holds the function's own
          # argument: a `func` body running `awk '{print $1}'` must not have it
          # rewritten. An undefined plain name or `${name:-default}` is the
          # shell's too.
          i = endPos
          continue
        let value = ctx.resolveManipulation(varExpr, depth + 1)
        result = result[0 ..< i] & value & result[endPos .. ^1]
        i += value.len
      else:
        i += 1
    else:
      i += 1

  # Second pass: Replace simple $varname references using regex helper
  result = replaceSimpleVars(result, proc(
      name: string): string = ctx.getVariable(name),
      if shellVariables:
        proc(name: string): bool =
          # A positional parameter (``$1``) is always the shell's, even inside
          # a Kongue `func` whose localVars["1"] holds its own argument.
          isShellPositional(name) or
            (isShellVariableName(name) and not ctx.hasVariable(name))
      else:
        nil)

  # Resolve bare object property/bracket access (e.g., kpkg["isBootstrap"], obj.prop)
  #
  # An identifier that follows the ``\$`` marker byte is escaped text, not a
  # reference: ``\$kpkg["key"]`` must reach the shell as ``$kpkg["key"]``. The
  # marker is not an identifier character, so the scan below would match it.
  var j = 0
  while j < result.len:
    # Check if we have an identifier followed by [ or .
    if result[j].isAlphaAscii() or result[j] == '_':
      # Read the identifier
      var identStart = j
      while j < result.len and (result[j].isAlphaNumeric() or result[j] ==
          '_' or result[j] == '-'):
        j += 1
      let ident = result[identStart ..< j]
      if identStart > 0 and result[identStart - 1] == escapedDollar:
        # Escaped: leave the identifier exactly as written.
        continue

      # Check for [ after identifier.
      # Bare dot access (ident.prop) is intentionally NOT resolved here: it is
      # undocumented (the manpage mandates ${object.key}) and collides with
      # dotted filenames (e.g. kpkg.nim). Dot access must use ${object.key},
      # which the first pass resolves via resolveManipulation.
      if j < result.len and ident.len > 0 and ctx.hasObjectVariable(ident):
        if result[j] == '[':
          # Bracket access: ident["key"]
          j += 1 # skip [
          if j < result.len and result[j] == '"':
            j += 1 # skip opening "
            var keyEnd = j
            while keyEnd < result.len and result[keyEnd] != '"':
              keyEnd += 1
            let key = result[j ..< keyEnd]
            j = keyEnd + 1 # skip closing "
            if j < result.len and result[j] == ']':
              j += 1 # skip ]
              let obj = ctx.getObjectVariable(ident)
              if obj.kind == vvkObject and obj.objVal.hasKey(key):
                let val = obj.objVal[key].toString()
                result = result[0 ..< identStart] & val & result[j .. ^1]
                j = identStart + val.len
              else:
                result = result[0 ..< identStart] & "" & result[j .. ^1]
              continue
    j += 1

  # Last pass: restore the literal dollars written as ``\$``. Nothing may
  # inspect the text after this point, or the restored ``$`` would look like a
  # reference again.
  result = restoreEscapedDollars(result)

proc builtinExec*(ctx: ExecutionContext, command: string): int =
  ## Execute a shell command
  # Strip outer quotes if the parser wrapped the command in quotes
  # This happens when exec "command" is parsed - the parser adds quotes
  # but the shell wrapper in execEnv will add its own quotes.
  # The command is shell text: a name the script does not define is left for
  # the shell to expand. Exact resolution (jumpstart's manifest mode, where
  # kongue(5) MANIFEST MODE requires unknown -> empty) leaves the flag off.
  let resolvedCmd = stripQuotes(ctx.resolveVariables(command,
      shellVariables = ctx.shellVariables))

  # Execute command
  if not ctx.silent:
    debug "exec: " & resolvedCmd

  # Build environment variable exports for the command
  var cmdParts: seq[string] = @[]

  # Helper to escape values for use within double quotes
  # Need to escape: $ ` " \ and newlines
  proc escapeForDoubleQuote(s: string): string =
    result = ""
    for c in s:
      case c
      of '$', '`', '"', '\\':
        result.add('\\')
        result.add(c)
      of '\n':
        result.add("\\n")
      else:
        result.add(c)

  # Add custom environment variables
  for key, val in ctx.envVars:
    cmdParts.add("export " & key & "=\"" & escapeForDoubleQuote(val) & "\"")

  # Add standard build variables
  if ctx.destDir != "":
    cmdParts.add("export DESTDIR=\"" & escapeForDoubleQuote(ctx.destDir) & "\"")
    if ctx.buildRoot != "":
      cmdParts.add("export ROOT=\"" & escapeForDoubleQuote(ctx.buildRoot) & "\"")
  if ctx.srcDir != "":
    cmdParts.add("export SRCDIR=\"" & escapeForDoubleQuote(ctx.srcDir) & "\"")
  if ctx.packageName != "":
    cmdParts.add("export PACKAGENAME=\"" & escapeForDoubleQuote(
        ctx.packageName) & "\"")

  # Add cd command
  cmdParts.add("cd \"" & escapeForDoubleQuote(ctx.currentDir) & "\"")

  # Add the actual command
  cmdParts.add(resolvedCmd)

  # Combine environment setup with the actual command using &&
  let fullCmd = cmdParts.join(" && ")

  debug("builtinExec: fullCmd=" & fullCmd)

  # Use hook if available, otherwise use default execution
  let execResult = if ctx.execHook != nil:
    ctx.execHook(ctx, fullCmd, ctx.silent)
  else:
    defaultExec(ctx, fullCmd, ctx.silent)

  debug("builtinExec: exitCode=" & $execResult.exitCode)
  ctx.reportCommandResult(execResult.output, execResult.exitCode)
  result = execResult.exitCode

proc resolveContent(ctx: ExecutionContext, content: string): string

proc builtinPrint*(ctx: ExecutionContext, text: string) =
  ## Print text to stdout.
  ##
  ## ``text`` is expression source, so a quoted literal is decoded before it is
  ## resolved: `print "$target"` writes the value, not the quotes.
  let resolved = ctx.resolveContent(text)
  if not ctx.silent:
    echo resolved

proc builtinCd*(ctx: ExecutionContext, path: string): bool =
  ## Change current directory
  ## Supports: - (previous directory), ~ (home directory), relative and absolute paths
  let resolvedPath = stripQuotes(ctx.resolveVariables(path))

  var fullPath: string

  # Handle special cases
  if resolvedPath == "-":
    # Go to previous directory
    if ctx.previousDir == "":
      echo "Error: No previous directory"
      return false
    fullPath = ctx.previousDir
  elif resolvedPath.startsWith("~"):
    # Home directory expansion
    let homeDir = getHomeDir()
    if resolvedPath == "~":
      fullPath = homeDir
    else:
      # ~/path or ~/ case
      fullPath = homeDir / resolvedPath[2..^1]
  elif not isAbsolute(resolvedPath):
    # Handle relative paths
    fullPath = ctx.currentDir / resolvedPath
  else:
    fullPath = resolvedPath

  # Normalize the path to resolve .. and .
  fullPath = normalizedPath(fullPath)

  if dirExists(fullPath):
    # Save current directory as previous before changing
    ctx.previousDir = ctx.currentDir
    ctx.currentDir = fullPath
    return true
  else:
    echo "Error: Directory does not exist: " & fullPath
    return false

proc builtinEnv*(ctx: ExecutionContext, varName: string, value: string) =
  ## Set an environment variable for subsequent exec commands
  let resolvedValue = stripQuotes(ctx.resolveVariables(value))
  ctx.envVars[varName] = resolvedValue

proc builtinLocal*(ctx: ExecutionContext, varName: string, value: string) =
  ## Set a local variable (function scope)
  let resolvedValue = stripQuotes(ctx.resolveVariables(value))
  ctx.localVars[varName] = resolvedValue

proc builtinGlobal*(ctx: ExecutionContext, varName: string, value: string) =
  ## Set a global variable
  let resolvedValue = stripQuotes(ctx.resolveVariables(value))
  ctx.variables[varName] = resolvedValue

proc resolveContent(ctx: ExecutionContext, content: string): string =
  ## Resolve write/append content to the exact bytes to put in the file.
  ## String literals are decoded (parser re-escaping undone) BEFORE variable
  ## resolution: `"a\nb"` yields a real newline, interpolated values verbatim.
  let (decoded, quoted) = decodeStringExpr(content)
  if quoted:
    return ctx.resolveVariables(decoded)
  # Raw (non-literal) content, e.g. a bare $VAR or a direct API call.
  return stripQuotes(ctx.resolveVariables(content))

proc builtinWrite*(ctx: ExecutionContext, path: string, content: string) =
  ## Write content to a file
  let resolvedPath = stripQuotes(ctx.resolveVariables(path))
  let resolvedContent = ctx.resolveContent(content)

  # Determine full path
  var fullPath = resolvedPath
  if not isAbsolute(resolvedPath):
    fullPath = ctx.currentDir / resolvedPath

  when defined(js):
    # Record the write in the virtual filesystem instead of touching a disk
    # that is not there.
    jscompat.writeFile(fullPath, resolvedContent)
    if not ctx.silent:
      echo "[write] " & fullPath
  else:
    try:
      writeFile(fullPath, resolvedContent)
      if not ctx.silent:
        echo "[write] " & fullPath
    except IOError as e:
      echo "Error writing to file " & fullPath & ": " & e.msg

proc builtinAppend*(ctx: ExecutionContext, path: string, content: string) =
  ## Append content to a file
  let resolvedPath = stripQuotes(ctx.resolveVariables(path))
  let resolvedContent = ctx.resolveContent(content)

  # Determine full path
  var fullPath = resolvedPath
  if not isAbsolute(resolvedPath):
    fullPath = ctx.currentDir / resolvedPath

  when defined(js):
    jscompat.writeFile(fullPath, jscompat.readFile(fullPath) & resolvedContent)
    if not ctx.silent:
      echo "[append] " & fullPath
  else:
    try:
      var f = open(fullPath, fmAppend)
      f.write(resolvedContent)
      f.close()
      if not ctx.silent:
        echo "[append] " & fullPath
    except IOError as e:
      echo "Error appending to file " & fullPath & ": " & e.msg

proc evaluateSingleCondition(ctx: ExecutionContext, condition: string): bool =
  ## Evaluate a single condition (no || or &&)
  ## Supports: ==, !=, =~ (regex), boolean literals, existence checks
  let resolved = ctx.resolveVariables(condition).strip()

  # Parse condition using regex pattern
  let parts = parseConditionOperator(resolved)
  if parts.valid:
    let leftVal = stripQuotes(parts.left)
    case parts.op
    of "=~":
      let pattern = stripPatternWrapper(parts.right)
      try:
        return leftVal.match(re2("^(" & pattern & ")$"))
      except:
        warn("Invalid regex pattern: " & pattern)
        return false
    of "==":
      return leftVal == stripQuotes(parts.right)
    of "!=":
      return leftVal != stripQuotes(parts.right)
    else:
      discard

  # Check for boolean-like values
  if isTrueBoolean(resolved):
    return true
  if isFalseBoolean(resolved):
    return false

  # Check if non-empty string
  return resolved.len > 0

proc evaluateCondition*(ctx: ExecutionContext, condition: string): bool =
  ## Evaluate a condition for if statements
  ## Supports: || (OR), && (AND), ==, !=, =~ (regex), boolean literals
  let resolved = ctx.resolveVariables(condition).strip()

  # Handle || (OR)
  if "||" in resolved:
    for part in splitLogicalOr(resolved):
      if ctx.evaluateSingleCondition(part):
        return true
    return false

  # Handle && (AND)
  if "&&" in resolved:
    for part in splitLogicalAnd(resolved):
      if not ctx.evaluateSingleCondition(part):
        return false
    return true

  # Single condition
  return ctx.evaluateSingleCondition(resolved)
