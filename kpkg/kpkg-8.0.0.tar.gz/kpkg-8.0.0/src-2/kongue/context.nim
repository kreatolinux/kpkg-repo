## Execution context for Kongue scripting language
## Contains the ExecutionContext type and variable management procs

when not defined(js):
  # Only the native branches below touch the host environment.
  import os
import tables
import ast
import utils
import variables
when defined(js):
  import jscompat

type
  ## Hook types for extensibility - allows consumers to customize execution behavior
  ExecHook* = proc(ctx: ExecutionContext, command: string, silent: bool): tuple[
      output: string, exitCode: int] {.nimcall.}
  CommandResultHook* = proc(output: string, exitCode: int) {.nimcall.}
  CommandResultContextHook* = proc(ctx: ExecutionContext, output: string,
      exitCode: int) {.nimcall.}
  MacroHook* = proc(ctx: ExecutionContext, name: string, args: seq[
      string]): int {.nimcall.}

  ExecutionContext* = ref object of RootObj
    ## Context for executing Kongue code
    ## Inherit from RootObj to allow subclassing for extended contexts
    variables*: Table[string, string] ## Global variables from header
    listVariables*: Table[string, seq[string]] ## List variables
    objectVariables*: Table[string, VarValue] ## Object variables (e.g., kpkg)
    localVars*: Table[string, string] ## Function-local variables
    envVars*: Table[string, string] ## Environment variable overrides
    customFuncs*: Table[string, seq[AstNode]] ## Custom function bodies
    currentDir*: string ## Current working directory
    previousDir*: string ## Previous directory (for cd -)
    destDir*: string ## DESTDIR for installation
    srcDir*: string ## Source directory
    buildRoot*: string ## Build root directory
    packageName*: string ## Package name
    silent*: bool ## Suppress output
    callDepth*: int ## Current custom-function nesting depth
    maxCallDepth*: int ## Ceiling for callDepth; see utils.defaultMaxCallDepth
    # Hooks for extensibility
    execHook*: ExecHook ## Custom command execution hook
    commandResultHook*: CommandResultHook ## Legacy captured command callback
    commandResultContextHook*: CommandResultContextHook ## Context-aware callback
    macroHook*: MacroHook ## Custom macro execution hook

proc initExecutionContext*(destDir: string = "", srcDir: string = "",
        buildRoot: string = "", packageName: string = ""): ExecutionContext =
  ## Initialize a new execution context
  result = ExecutionContext()
  result.variables = initTable[string, string]()
  result.listVariables = initTable[string, seq[string]]()
  result.objectVariables = initTable[string, VarValue]()
  result.localVars = initTable[string, string]()
  result.envVars = initTable[string, string]()
  result.customFuncs = initTable[string, seq[AstNode]]()
  result.callDepth = 0
  result.maxCallDepth = defaultMaxCallDepth
  # Use srcDir for currentDir if provided (supports autocd from buildcmd)
  if srcDir != "":
    result.currentDir = srcDir
  else:
    when defined(js):
      # A browser has no working directory. Use a fixed absolute root so
      # relative paths in a script still resolve predictably.
      result.currentDir = playgroundDir
    else:
      result.currentDir = getCurrentDir()
  result.previousDir = result.currentDir
  result.destDir = destDir
  result.srcDir = srcDir
  result.buildRoot = buildRoot
  result.packageName = packageName
  result.silent = false
  result.execHook = nil
  result.commandResultHook = nil
  result.commandResultContextHook = nil
  result.macroHook = nil

proc setVariable*(ctx: ExecutionContext, name: string, value: string) =
  ## Set a global variable
  ctx.variables[name] = value

proc setListVariable*(ctx: ExecutionContext, name: string, items: seq[string]) =
  ## Set a list variable
  ctx.listVariables[name] = items

proc setObjectVariable*(ctx: ExecutionContext, name: string, value: VarValue) =
  ## Set an object variable
  ctx.objectVariables[name] = value

proc getVariable*(ctx: ExecutionContext, name: string): string =
  ## Get a variable value (checks local, then global, then built-in)
  if ctx.localVars.hasKey(name):
    return ctx.localVars[name]
  if ctx.variables.hasKey(name):
    return ctx.variables[name]
  # Check environment variables
  if ctx.envVars.hasKey(name):
    return ctx.envVars[name]
  # Check built-in variables
  case name
  of "ROOT":
    return ctx.buildRoot
  of "DESTDIR":
    return ctx.destDir
  of "SRCDIR":
    return ctx.srcDir
  of "PACKAGENAME":
    return ctx.packageName
  else:
    when defined(js):
      # No host environment in a browser.
      return ""
    else:
      # Fallback to system environment variables
      return getEnv(name)

proc getObjectVariable*(ctx: ExecutionContext, name: string): VarValue =
  ## Get an object variable
  if ctx.objectVariables.hasKey(name):
    return ctx.objectVariables[name]
  return newStringValue("")

proc getListVariable*(ctx: ExecutionContext, name: string): seq[string] =
  ## Get a list variable
  if ctx.listVariables.hasKey(name):
    return ctx.listVariables[name]
  return @[]

proc hasVariable*(ctx: ExecutionContext, name: string): bool =
  ## Check if a variable exists
  if ctx.localVars.hasKey(name) or ctx.variables.hasKey(name) or
          ctx.envVars.hasKey(name):
    return true
  # Check built-in variables
  case name
  of "ROOT", "DESTDIR", "SRCDIR", "PACKAGENAME":
    return true
  else:
    when defined(js):
      return false
    else:
      return existsEnv(name)

proc hasObjectVariable*(ctx: ExecutionContext, name: string): bool =
  ## Check if an object variable exists
  return ctx.objectVariables.hasKey(name)

proc hasListVariable*(ctx: ExecutionContext, name: string): bool =
  ## Check if a list variable exists
  return ctx.listVariables.hasKey(name)

proc clearLocalVars*(ctx: ExecutionContext) =
  ## Clear all local variables (called when exiting a function)
  ctx.localVars.clear()
