## Parser for Kongue scripting language
## Converts tokens into an AST

import strutils
import ast
import lexer
import utils

when defined(js):
  # ``readFile`` technically exists in the JS target, but it cannot read a
  # browser disk. Route file reads to the virtual filesystem instead.
  # ``except readFile`` avoids clashing with the auto-imported ``std/syncio``.
  import jscompat except readFile
elif not declared(readFile):
  import os

proc escapeStringForOutput(s: string): string =
  ## Escape special characters in a string for output
  ## Preserves existing escapes inside ${} expressions
  result = ""
  var i = 0
  while i < s.len:
    let c = s[i]
    if c == '$' and i + 1 < s.len and s[i + 1] == '{':
      # Inside ${} expression - copy everything until matching }
      # These already have escapes preserved by the lexer
      var braceDepth = 0
      while i < s.len:
        if s[i] == '{':
          braceDepth += 1
        elif s[i] == '}':
          braceDepth -= 1
          if braceDepth == 0:
            result.add(s[i])
            i += 1
            break
        result.add(s[i])
        i += 1
    else:
      # Outside ${} - need to escape special chars
      case c
      of '\n': result.add("\\n")
      of '\t': result.add("\\t")
      of '\r': result.add("\\r")
      of '\\': result.add("\\\\")
      of '"': result.add("\\\"")
      else: result.add(c)
      i += 1

type
  Parser* = object
    ## Parser state
    tokens*: seq[Token]
    pos*: int
    strict*: bool ## manifest mode: reject text outside function blocks

  ParseError* = object of CatchableError
    ## Parse error with line information
    line*: int
    col*: int

proc raiseParseError(msg: string, line, col: int) {.noreturn.} =
  ## Raise a ParseError with line and column information
  var err = newException(ParseError, msg)
  err.line = line
  err.col = col
  raise err

proc initParser*(tokens: seq[Token]): Parser =
  ## Initialize a new parser
  result.tokens = tokens
  result.pos = 0

proc peek*(p: Parser, offset: int = 0): Token =
  ## Peek at a token without consuming it
  let pos = p.pos + offset
  if pos >= p.tokens.len:
    return Token(kind: tkEof, value: "", line: 0, col: 0)
  return p.tokens[pos]

proc advance*(p: var Parser): Token =
  ## Consume and return the current token
  if p.pos >= p.tokens.len:
    return Token(kind: tkEof, value: "", line: 0, col: 0)
  result = p.tokens[p.pos]
  p.pos += 1

proc expect(p: var Parser, kind: TokenKind): Token =
  ## Expect a specific token kind, raise error if not found
  let tok = p.advance()
  if tok.kind != kind:
    raiseParseError("Expected " & $kind & " but got " & $tok.kind, tok.line, tok.col)
  return tok

proc skipNewlines(p: var Parser) =
  ## Skip newline tokens
  while p.peek().kind == tkNewline:
    discard p.advance()

proc skipCommentsAndNewlines(p: var Parser) =
  ## Skip comment and newline tokens
  while p.peek().kind in {tkNewline, tkComment}:
    discard p.advance()

proc parseString(p: var Parser): string =
  ## Parse a string value (with variable substitution support)
  let tok = p.peek()
  if tok.kind == tkString:
    discard p.advance()
    return tok.value
  elif tok.kind == tkIdentifier or tok.kind == tkNumber:
    discard p.advance()
    return tok.value
  else:
    raiseParseError("Expected string but got " & $tok.kind, tok.line, tok.col)

proc parseStringValue(p: var Parser): string =
  ## Parse a string value, concatenating multiple unquoted tokens
  ## This handles cases where unquoted values like hex checksums
  ## are split into multiple tokens by the lexer
  var parts: seq[string] = @[]

  while true:
    let tok = p.peek()
    case tok.kind
    of tkString:
      parts.add(tok.value)
      discard p.advance()
      break # Quoted strings are complete
    of tkIdentifier, tkNumber:
      parts.add(tok.value)
      discard p.advance()
      # Check if next token should be part of this value
      let nextTok = p.peek()
      if nextTok.kind notin {tkIdentifier, tkNumber}:
        break
    else:
      break

  return parts.join("")

proc parseListItems(p: var Parser): seq[string] =
  ## Parse list items (lines starting with -)
  ## Comment lines may appear anywhere between items.
  result = @[]
  p.skipCommentsAndNewlines()

  var itemCount = 0

  while p.peek().kind == tkDash:
    itemCount += 1
    if itemCount > maxItems:
      raiseParseError("List exceeded maximum items - possible infinite loop",
          p.peek().line, p.peek().col)
    let dash = p.advance() # Skip -
    # The value belongs to the item's own line: taking the next line's token
    # would swallow a following `name {` block as an item value.
    if p.peek().kind in {tkNewline, tkComment, tkEof}:
      raiseParseError("List item '-' needs a value on the same line", dash.line,
          dash.col)
    result.add(p.parseStringValue())
    p.skipCommentsAndNewlines()

proc parseInlineObjectProperties(p: var Parser): seq[tuple[key: string,
    value: string]] =
  ## Parse inline object properties (key: value pairs under a name:)
  ## Ends when we see a token that isn't an identifier followed by a colon
  result = @[]
  p.skipNewlines()

  var propCount = 0
  while propCount < maxItems:
    let tok = p.peek()
    if tok.kind != tkIdentifier:
      break
    # Check if this identifier is followed by a colon (key: value pattern)
    let nextTok = p.peek(1)
    if nextTok.kind notin {tkColon, tkPlusColon, tkMinusColon}:
      break
    # It's a property: key: value
    let key = p.advance().value # consume identifier
    discard p.advance() # consume colon
    p.skipNewlines()
    let value = p.parseStringValue()
    result.add((key: key, value: value))
    propCount += 1
    p.skipNewlines()

proc parseVariableDeclaration(p: var Parser): AstNode =
  ## Parse a variable declaration (name: value or name qualifier: value or name:\n  - item)
  ## Supports space-separated qualifiers: "depends test2:" parses as name="depends", qualifier="test2"
  let nameToken = p.expect(tkIdentifier)
  let name = nameToken.value
  var qualifier = ""

  # Check if next token is an identifier (qualifier) before the colon
  if p.peek().kind == tkIdentifier:
    let nextTok = p.peek(1)
    if nextTok.kind in {tkColon, tkPlusColon, tkMinusColon}:
      # We have a qualifier: "name qualifier:"
      qualifier = p.advance().value

  var op = opSet
  let opTok = p.peek()
  if opTok.kind == tkColon:
    discard p.advance()
  elif opTok.kind == tkPlusColon:
    op = opAppend
    discard p.advance()
  elif opTok.kind == tkMinusColon:
    op = opRemove
    discard p.advance()
  else:
    raiseParseError("Expected :, +: or -: but got " & $opTok.kind, opTok.line, opTok.col)

  p.skipNewlines()

  # A comment line is never a value: skip comment lines after the key and the
  # line breaks that end them, so a comment may stand between `key:` and its
  # list, inline object or value.
  while p.peek().kind == tkComment:
    discard p.advance()
    p.skipNewlines()

  # Check what follows: list, inline object, or single value
  if p.peek().kind == tkDash:
    # List variable
    let items = p.parseListItems()
    return newListVariableNode(name, items, op, nameToken.line, qualifier)
  elif p.peek().kind == tkIdentifier and p.peek(1).kind in {tkColon,
      tkPlusColon, tkMinusColon}:
    # Inline object: name: \n  key: value\n  key2: value2
    let properties = p.parseInlineObjectProperties()
    return newObjectNode(name, properties, nameToken.line)
  elif p.peek().kind == tkEof:
    # Nothing after the key at all (comments only, or the end of the file).
    return newVariableNode(name, "", op, nameToken.line, qualifier)
  else:
    # Single value variable
    let value = p.parseString()
    return newVariableNode(name, value, op, nameToken.line, qualifier)

proc parseExecCommand(p: var Parser): string =
  ## Parse an exec command - returns raw string value without re-quoting
  ## This preserves the original quoting for shell commands
  let tok = p.peek()
  if tok.kind == tkString:
    discard p.advance()
    return tok.value
  elif tok.kind == tkIdentifier or tok.kind == tkNumber:
    discard p.advance()
    return tok.value
  else:
    raiseParseError("Expected string for exec command but got " & $tok.kind,
        tok.line, tok.col)

proc tokenSource(tok: Token): string =
  ## Exact source text of a token (``raw`` is set by ``tokenize``).
  if tok.raw.len > 0: tok.raw else: tok.value

proc utf8SeqLen(b: char): int =
  ## Bytes in the UTF-8 sequence that starts with ``b``; 1 for a stray byte.
  let c = int(uint8(b))
  if c < 0x80: 1
  elif c shr 5 == 0b110: 2
  elif c shr 4 == 0b1110: 3
  elif c shr 3 == 0b11110: 4
  else: 1

proc tokenExcerpt(tok: Token, limit = 24): string =
  ## Short printable form of a token's text for a warning: at most ``limit``
  ## characters, cut between runes so a UTF-8 sequence is never split, control
  ## bytes written as escapes.
  let s = tok.value
  var i = 0
  var chars = 0
  while i < s.len and chars < limit:
    let b = uint8(s[i])
    if b < 0x20 or b == 0x7F:
      case s[i]
      of '\n': result.add("\\n")
      of '\t': result.add("\\t")
      of '\r': result.add("\\r")
      else: result.add("\\x" & toHex(int(b), 2))
      inc i
    else:
      let n = min(utf8SeqLen(s[i]), s.len - i)
      result.add(s[i ..< i + n])
      i += n
    inc chars
  if i < s.len:
    result.add("...")

proc warnStrayText(tok: Token, place: string, warned: var bool) =
  ## Warn, once per script, about text the parser steps over; ``place`` names
  ## what that text stands outside of.
  if warned:
    return
  warn("ignoring text outside " & place & " at line " & $tok.line & ": '" &
      tokenExcerpt(tok) & "'")
  warned = true

proc parseBraceBody(p: var Parser): string =
  ## Text inside a ``${...}``, up to (not including) the closing ``}``, kept
  ## verbatim so a literal in it keeps its quotes for the run-time parser. A
  ## nested brace does not end it and the line break does: an unclosed ``${``
  ## is an error, never a block that silently loses its remaining statements.
  var depth = 0
  var iterations = 0
  while true:
    iterations += 1
    if iterations > maxIterations:
      raiseParseError("Brace expression parsing exceeded maximum iterations",
          p.peek().line, p.peek().col)
    let tok = p.peek()
    # A ``${...}`` closes on the line it opens (no in-tree recipe or manifest
    # spans one), so name the line break rather than the brace that goes
    # missing further down.
    if tok.kind == tkNewline:
      raiseParseError("Unterminated ${...} expression: it must close with '}' " &
          "before the end of the line", tok.line, tok.col)
    if tok.kind == tkEof:
      raiseParseError("Unterminated ${...} expression: it must close with '}' " &
          "before the end of the file", tok.line, tok.col)
    if tok.kind == tkLBrace:
      inc depth
    elif tok.kind == tkRBrace:
      if depth == 0:
        return
      dec depth
    result.add(tokenSource(tok))
    discard p.advance()

proc parseBraceExpression(p: var Parser): string =
  ## Consume a whole ``${...}`` expression as one value.
  discard p.advance() # $
  discard p.advance() # {
  result = "${" & p.parseBraceBody()
  discard p.expect(tkRBrace)
  result.add("}")

proc parseExpression(p: var Parser): string =
  ## Parse an expression (for conditions, arguments, etc.)
  ## Handles variable references and basic expressions
  var parts: seq[string] = @[]
  var iterations = 0

  while true:
    iterations += 1
    if iterations > maxIterations:
      raiseParseError("Expression parsing exceeded maximum iterations - possible infinite loop",
          p.peek().line, p.peek().col)

    let tok = p.peek()
    case tok.kind
    of tkIdentifier, tkNumber:
      parts.add(tok.value)
      discard p.advance()
    of tkDollar:
      discard p.advance()
      if p.peek().kind == tkLBrace:
        discard p.advance() # Skip {

        var baseExpr = ""
        # Check for exec command
        if p.peek().kind == tkExec:
          discard p.advance()
          baseExpr = "exec"
          if p.peek().kind == tkLParen:
            baseExpr.add("(")
            discard p.advance()
            baseExpr.add("\"" & p.parseString() & "\"")
            discard p.expect(tkRParen)
            baseExpr.add(")")
        else:
          let varName = p.expect(tkIdentifier).value
          baseExpr = varName

        # Method chain, index or property access.
        parts.add("${" & baseExpr)
        if p.peek().kind == tkDot or p.peek().kind == tkLBracket:
          parts.add(p.parseBraceBody())
        discard p.expect(tkRBrace)
        parts.add("}")
      else:
        let varName = p.expect(tkIdentifier).value
        parts.add("$" & varName)
    of tkString:
      parts.add("\"" & escapeStringForOutput(tok.value) & "\"")
      discard p.advance()
    of tkRegexString:
      # Regex string e"pattern" - preserve with special marker
      parts.add("e\"" & escapeStringForOutput(tok.value) & "\"")
      discard p.advance()
    of tkEquals, tkLBrace, tkRBrace:
      # Stop at these delimiters
      break
    of tkNotEquals:
      # Include != operator in expression
      parts.add(tok.value)
      discard p.advance()
    of tkDoubleEquals:
      # Include == operator in expression
      parts.add(tok.value)
      discard p.advance()
    of tkRegexMatch:
      # Include =~ operator in expression
      parts.add(tok.value)
      discard p.advance()
    of tkOr:
      # Include || operator in expression
      parts.add(tok.value)
      discard p.advance()
    of tkAnd:
      # Include && operator in expression
      parts.add(tok.value)
      discard p.advance()
    of tkDot, tkLParen, tkRParen, tkLBracket, tkRBracket:
      # Allow method chaining, function calls, and bracket access in expressions
      parts.add(tok.value)
      discard p.advance()
    else:
      break

  return parts.join(" ").strip()

proc parseAssignmentValue(p: var Parser): string =
  ## Parse a single assignment value for env/local/global.
  ## Unlike general expressions, assignment values are token-concatenated so
  ## path-like values such as /nodepmod/here and $ROOT/usr are preserved.
  var parts: seq[string] = @[]
  var iterations = 0

  while true:
    iterations += 1
    if iterations > maxIterations:
      raiseParseError("Assignment parsing exceeded maximum iterations - possible infinite loop",
          p.peek().line, p.peek().col)

    let tok = p.peek()
    case tok.kind
    of tkNewline, tkRBrace, tkEof:
      break
    of tkString:
      parts.add("\"" & escapeStringForOutput(tok.value) & "\"")
      discard p.advance()
    of tkRegexString:
      parts.add("e\"" & escapeStringForOutput(tok.value) & "\"")
      discard p.advance()
    of tkDollar:
      # ``${...}`` is one value, and its ``}`` is not the end of the block.
      if p.peek(1).kind == tkLBrace:
        parts.add(p.parseBraceExpression())
      else:
        parts.add(tok.value)
        discard p.advance()
    else:
      parts.add(tok.value)
      discard p.advance()

  return parts.join("").strip()

proc parseCondition(p: var Parser): string =
  ## Parse a condition expression for if statements
  ## Handles ||, &&, ==, !=, =~, and regex strings e"pattern"
  var parts: seq[string] = @[]
  var iterations = 0

  while true:
    iterations += 1
    if iterations > maxIterations:
      raiseParseError("Condition parsing exceeded maximum iterations",
          p.peek().line, p.peek().col)

    let tok = p.peek()
    case tok.kind
    of tkIdentifier, tkNumber:
      parts.add(tok.value)
      discard p.advance()
    of tkDollar:
      discard p.advance()
      if p.peek().kind == tkLBrace:
        discard p.advance() # Skip {
        var baseExpr = ""
        if p.peek().kind == tkExec:
          discard p.advance()
          baseExpr = "exec"
          if p.peek().kind == tkLParen:
            baseExpr.add("(")
            discard p.advance()
            baseExpr.add("\"" & p.parseString() & "\"")
            discard p.expect(tkRParen)
            baseExpr.add(")")
        else:
          let varName = p.expect(tkIdentifier).value
          baseExpr = varName

        parts.add("${" & baseExpr)
        if p.peek().kind == tkDot or p.peek().kind == tkLBracket:
          parts.add(p.parseBraceBody())
        discard p.expect(tkRBrace)
        parts.add("}")
      else:
        let varName = p.expect(tkIdentifier).value
        parts.add("$" & varName)
    of tkString:
      parts.add("\"" & escapeStringForOutput(tok.value) & "\"")
      discard p.advance()
    of tkRegexString:
      # Regex string e"pattern"
      parts.add("e\"" & escapeStringForOutput(tok.value) & "\"")
      discard p.advance()
    of tkDoubleEquals:
      parts.add("==")
      discard p.advance()
    of tkNotEquals:
      parts.add("!=")
      discard p.advance()
    of tkRegexMatch:
      parts.add("=~")
      discard p.advance()
    of tkOr:
      parts.add("||")
      discard p.advance()
    of tkAnd:
      parts.add("&&")
      discard p.advance()
    of tkLBrace, tkRBrace, tkNewline, tkEof:
      # End of condition
      break
    of tkDot, tkLParen, tkRParen, tkLBracket, tkRBracket:
      parts.add(tok.value)
      discard p.advance()
    else:
      break

  return parts.join(" ").strip()

proc parseMacroArgValue(p: var Parser, requireAdjacentStart = false): string =
  ## Parse one macro argument: the tokens written next to each other.
  ## Handles paths like /usr/share/man, variables like $var, and quoted strings
  ##
  ## A value is one shell word, so it ends at the first token that is separated
  ## from the previous one by whitespace (``spaceBefore``). Only adjacency joins
  ## tokens: ``-Dprefix=/usr${suffix}`` is one word, ``-Dadmin_group=wheel
  ## ${extraArgs}`` is two.
  ##
  ## ``requireAdjacentStart`` is for the text after ``--flag=``, where the value
  ## must also start right after the ``=`` so ``-Ddocumentation=
  ## --wrap-mode=nodownload`` keeps an empty value.
  var parts: seq[string] = @[]
  var iterations = 0

  while p.peek().kind notin {tkNewline, tkRBrace, tkEof}:
    iterations += 1
    if iterations > maxIterations:
      raiseParseError("Macro argument value parsing exceeded maximum iterations",
          p.peek().line, p.peek().col)

    let tok = p.peek()

    # Whitespace separates arguments: the next token starts a new one.
    if tok.spaceBefore and (parts.len > 0 or requireAdjacentStart):
      break

    # Handle different token types
    case tok.kind
    of tkString:
      parts.add(tok.value)
      discard p.advance()
    of tkIdentifier, tkNumber:
      parts.add(tok.value)
      discard p.advance()
    of tkDollar:
      # Variable reference
      discard p.advance()
      if p.peek().kind == tkLBrace:
        discard p.advance() # Skip {
        parts.add("${" & p.parseBraceBody() & "}")
        discard p.expect(tkRBrace)
      else:
        let varName = p.expect(tkIdentifier).value
        parts.add("$" & varName)
    of tkDash:
      # Single dash (not --), include it
      parts.add(tok.value)
      discard p.advance()
    of tkDot, tkColon, tkEquals:
      # Path separators and special chars
      parts.add(tok.value)
      discard p.advance()
    else:
      # Any other token, include its value
      parts.add(tok.value)
      discard p.advance()

  return parts.join("")

proc parseMacroFlagName(p: var Parser): string =
  ## Parse a macro flag name after --
  ## The lexer already handles dash-containing identifiers like enable-pc-files
  ## So we just need to read a single identifier token
  if p.peek().kind == tkIdentifier:
    return p.advance().value
  else:
    return ""

proc parseSingleTokenOrVar(p: var Parser): string =
  ## Parse a single token (string/identifier) or variable reference
  let tok = p.peek()
  case tok.kind
  of tkString, tkIdentifier, tkNumber:
    discard p.advance()
    return tok.value
  of tkDollar:
    discard p.advance()
    if p.peek().kind == tkLBrace:
      discard p.advance() # Skip {

      var baseExpr = ""
      if p.peek().kind == tkExec:
        discard p.advance()
        baseExpr = "exec"
        if p.peek().kind == tkLParen:
          baseExpr.add("(")
          discard p.advance()
          baseExpr.add("\"" & p.parseString() & "\"")
          discard p.expect(tkRParen)
          baseExpr.add(")")
      else:
        baseExpr = p.expect(tkIdentifier).value

      var res = "${" & baseExpr
      if p.peek().kind == tkDot or p.peek().kind == tkLBracket:
        res.add(p.parseBraceBody())
      discard p.expect(tkRBrace)
      res.add("}")
      return res
    else:
      let varName = p.expect(tkIdentifier).value
      return "$" & varName
  else:
    raiseParseError("Expected string, identifier or variable, got " &
        $tok.kind & " '" & tok.value & "'", tok.line, tok.col)

# Forward declaration for mutual recursion
proc parseStatement*(p: var Parser): AstNode

proc parseStatementBlock(p: var Parser, blockName: string): seq[AstNode] =
  ## Parse a block of statements until }
  ## Used by if, for, and function body parsing
  result = @[]
  var stmtCount = 0
  while p.peek().kind != tkRBrace and p.peek().kind != tkEof:
    stmtCount += 1
    if stmtCount > maxStatements:
      raiseParseError(blockName & " exceeded maximum statements - possible infinite loop",
          p.peek().line, p.peek().col)
    result.add(p.parseStatement())
    p.skipCommentsAndNewlines()

proc parseMacroStatement(p: var Parser, line: int): AstNode =
  ## Parse a macro statement: macro name --flag1 --flag2=value arg1
  let macroName = p.expect(tkIdentifier).value
  var args: seq[string] = @[]

  # Parse macro arguments until newline or }
  # Supports: positional args, variable refs (${var}), -flag and --flag style args
  var argCount = 0
  while p.peek().kind notin {tkNewline, tkRBrace, tkEof}:
    argCount += 1
    if argCount > maxArgs:
      raiseParseError("Macro exceeded maximum arguments", p.peek().line, p.peek().col)

    let currentTok = p.peek()

    # Handle --flag and --flag=value style arguments
    if currentTok.kind == tkDash and p.peek(1).kind == tkDash:
      discard p.advance() # First -
      discard p.advance() # Second -
      let argName = p.parseMacroFlagName()
      var argValue = argName
      if p.peek().kind == tkEquals:
        discard p.advance()
        argValue = argName & "=" & p.parseMacroArgValue(requireAdjacentStart = true)
      args.add("--" & argValue)
    # Handle -flag and -flag=value or -flagVALUE style arguments (single dash)
    elif currentTok.kind == tkDash:
      discard p.advance() # Single -
      # Read the flag and any attached value (like -j4 or -O2)
      let flagArg = p.parseMacroArgValue()
      args.add("-" & flagArg)
    # Handle variable references and other expressions (including compound args like install.prefix=/usr)
    elif currentTok.kind in {tkDollar, tkString, tkIdentifier, tkNumber}:
      # Use parseMacroArgValue to handle compound expressions with dots, equals, etc.
      args.add(p.parseMacroArgValue())
    # Handle dots at start of path (like ../foo or ./bar)
    elif currentTok.kind == tkDot:
      args.add(p.parseMacroArgValue())
    else:
      # Unknown token type in macro args - skip it to avoid infinite loop
      raiseParseError("Unexpected token in macro arguments: " &
          $currentTok.kind & " '" & currentTok.value & "'",

currentTok.line, currentTok.col)

  return newMacroNode(macroName, args, line)

proc parseIfStatement(p: var Parser, line: int): AstNode =
  ## Parse an if statement: if condition { } else { }
  let condition = p.parseCondition()
  discard p.expect(tkLBrace)
  p.skipNewlines()

  let thenBranch = p.parseStatementBlock("If body")
  discard p.expect(tkRBrace)

  var elseBranch: seq[AstNode] = @[]
  p.skipNewlines()
  if p.peek().kind == tkElse:
    discard p.advance()
    discard p.expect(tkLBrace)
    p.skipNewlines()
    elseBranch = p.parseStatementBlock("Else body")
    discard p.expect(tkRBrace)

  return newIfNode(condition, thenBranch, elseBranch, line)

proc parseForStatement(p: var Parser, line: int): AstNode =
  ## Parse a for loop: for var in list { }
  let iterVar = p.expect(tkIdentifier).value
  discard p.expect(tkIn)

  # Check if it's an inline list literal, variable expression, or variable name
  var listVar = ""
  var listLiteral: seq[string] = @[]

  if p.peek().kind == tkLBracket:
    # Inline list literal: ["item1", "item2", ...]
    discard p.advance() # Skip [
    p.skipNewlines()
    while p.peek().kind != tkRBracket and p.peek().kind != tkEof:
      listLiteral.add(p.parseString())
      p.skipNewlines()
      if p.peek().kind == tkComma:
        discard p.advance() # Skip comma
        p.skipNewlines()
    discard p.expect(tkRBracket)
  elif p.peek().kind == tkDollar or p.peek().kind == tkString:
    # Variable expression: ${expr} or "$expr" - store as listVar for runtime resolution
    listVar = p.parseSingleTokenOrVar()
  else:
    # Plain variable name
    listVar = p.expect(tkIdentifier).value

  discard p.expect(tkLBrace)
  p.skipNewlines()

  let body = p.parseStatementBlock("For body")
  discard p.expect(tkRBrace)

  return newForNode(iterVar, listVar, body, line, listLiteral)

proc parseFuncCallStatement(p: var Parser, name: string, line: int): AstNode =
  ## Parse a function call: funcname arg1 arg2
  var args: seq[string] = @[]
  var argCount = 0
  while p.peek().kind notin {tkNewline, tkRBrace, tkEof}:
    argCount += 1
    if argCount > maxArgs:
      raiseParseError("Function call exceeded maximum arguments - possible parse error at token: " &
          $p.peek().kind, p.peek().line, p.peek().col)
    if p.peek().kind == tkEquals and args.len > 0 and not p.peek().spaceBefore:
      # A bare `KEY=VALUE` argument, such as `respond-item units name=x.y`
      # (jumpstart-cores §16.3): `=` joins the word before it with the value
      # written directly after it. The value is the exact source text of the
      # tokens that follow without whitespace (quotes and `${…}` included),
      # so it is split and interpolated like any other argument.
      discard p.advance()
      var value = ""
      var braces = 0
      while p.peek().kind notin {tkNewline, tkEof} and not p.peek().spaceBefore:
        let tok = p.peek()
        if tok.kind == tkRBrace:
          if braces == 0: break
          dec braces
        elif tok.kind == tkLBrace: inc braces
        value.add(tok.raw)
        discard p.advance()
      args[^1].add("=" & value)
      continue
    let startPos = p.pos
    let expr = p.parseExpression()
    # If parseExpression didn't consume anything and returned empty, we're stuck
    if p.pos == startPos and expr.len == 0:
      raiseParseError("Unexpected token in function call arguments: " & $p.peek(
        ).kind & " '" & p.peek().value & "'", p.peek().line, p.peek().col)
    if expr.len > 0:
      args.add(expr)
    if p.peek().kind == tkNewline or p.peek().kind == tkRBrace:
      break
  return newFuncCallNode(name, args, line)

proc parseObjectDeclaration(p: var Parser, line: int): AstNode =
  ## Parse an object declaration: object name { key: "value" ... }
  discard p.advance() # Skip 'object' keyword
  let objectName = p.expect(tkIdentifier).value
  discard p.expect(tkLBrace)
  p.skipNewlines()

  var properties: seq[tuple[key: string, value: string]] = @[]

  while p.peek().kind != tkRBrace and p.peek().kind != tkEof:
    # Parse key: value pair
    let key = p.expect(tkIdentifier).value
    discard p.expect(tkColon)
    let value = p.parseStringValue()
    properties.add((key: key, value: value))
    p.skipNewlines()

  discard p.expect(tkRBrace)
  return newObjectNode(objectName, properties, line)

proc isObjectDeclarationStart(p: Parser): bool =
  ## Check if current position starts an object declaration
  ## Matches: "object identifier {"
  if p.peek().kind != tkObject:
    return false
  if p.peek(1).kind != tkIdentifier:
    return false
  if p.peek(2).kind != tkLBrace:
    return false
  return true

proc parseStatement*(p: var Parser): AstNode =
  ## Parse a single statement inside a function
  p.skipCommentsAndNewlines()
  let tok = p.peek()

  case tok.kind
  of tkExec:
    discard p.advance()
    return newExecNode(p.parseExecCommand(), tok.line)

  of tkMacro:
    discard p.advance()
    return p.parseMacroStatement(tok.line)

  of tkPrint, tkEcho:
    discard p.advance()
    return newPrintNode(p.parseExpression(), tok.line)

  of tkCd:
    discard p.advance()
    return newCdNode(p.parseExpression(), tok.line)

  of tkEnv:
    discard p.advance()
    let varName = p.expect(tkIdentifier).value
    discard p.expect(tkEquals)
    return newEnvNode(varName, p.parseAssignmentValue(), tok.line)

  of tkLocal:
    discard p.advance()
    let varName = p.expect(tkIdentifier).value
    discard p.expect(tkEquals)
    return newLocalNode(varName, p.parseAssignmentValue(), tok.line)

  of tkGlobal:
    discard p.advance()
    let varName = p.expect(tkIdentifier).value
    discard p.expect(tkEquals)
    return newGlobalNode(varName, p.parseAssignmentValue(), tok.line)

  of tkWrite:
    discard p.advance()
    let path = p.parseSingleTokenOrVar()
    return newWriteNode(path, p.parseExpression(), tok.line)

  of tkAppend:
    discard p.advance()
    let path = p.parseSingleTokenOrVar()
    return newAppendNode(path, p.parseExpression(), tok.line)

  of tkIf:
    discard p.advance()
    return p.parseIfStatement(tok.line)

  of tkFor:
    discard p.advance()
    return p.parseForStatement(tok.line)

  of tkContinue:
    discard p.advance()
    return newContinueNode(tok.line)

  of tkBreak:
    discard p.advance()
    return newBreakNode(tok.line)

  of tkObject:
    return p.parseObjectDeclaration(tok.line)

  of tkIdentifier:
    # Could be a custom function call
    let name = p.advance().value
    return p.parseFuncCallStatement(name, tok.line)

  else:
    # Unknown token - report error with location
    raiseParseError("Unexpected token at start of statement: " &
        $tok.kind & " '" & tok.value & "'", tok.line, tok.col)

proc parseFunctionBody(p: var Parser): seq[AstNode] =
  ## Parse a function body (statements between { })
  discard p.expect(tkLBrace)
  p.skipNewlines()
  result = p.parseStatementBlock("Function body")
  discard p.expect(tkRBrace)

proc parseFunction*(p: var Parser, isCustom: bool = false): AstNode =
  ## Parse a function definition
  ## Supports space-separated qualifiers: "build test2 {}" parses as name="build", qualifier="test2"
  let tok = p.peek()

  if isCustom:
    discard p.expect(tkFunc)

  let funcName = p.expect(tkIdentifier).value
  var qualifier = ""

  # Check if next token is an identifier (qualifier) before the brace
  if p.peek().kind == tkIdentifier and p.peek(1).kind == tkLBrace:
    qualifier = p.advance().value

  let body = p.parseFunctionBody()

  if isCustom:
    return newCustomFuncNode(funcName, body, tok.line)
  else:
    return newFunctionNode(funcName, body, tok.line, qualifier)

proc isVariableDeclarationStart(p: Parser): bool =
  ## Check if current position starts a variable declaration
  ## Matches: "identifier :" or "identifier identifier :" (with qualifier)
  ## Also matches +: and -: variants
  if p.peek().kind != tkIdentifier:
    return false

  let next = p.peek(1)
  # Direct: "name:"
  if next.kind in {tkColon, tkPlusColon, tkMinusColon}:
    return true

  # With qualifier: "name qualifier:"
  if next.kind == tkIdentifier:
    let afterQualifier = p.peek(2)
    if afterQualifier.kind in {tkColon, tkPlusColon, tkMinusColon}:
      return true

  return false

proc isFunctionDefinitionStart(p: Parser): bool =
  ## Check if current position starts a function definition
  ## Matches: "identifier {" or "identifier identifier {" (with qualifier)
  if p.peek().kind != tkIdentifier:
    return false

  let next = p.peek(1)
  # Direct: "name {"
  if next.kind == tkLBrace:
    return true

  # With qualifier: "name qualifier {"
  if next.kind == tkIdentifier:
    let afterQualifier = p.peek(2)
    if afterQualifier.kind == tkLBrace:
      return true

  return false

proc parse*(p: var Parser): ParsedScript =
  ## Parse a complete Kongue script
  result.variables = @[]
  result.functions = @[]
  result.customFuncs = @[]

  var iterations = 0
  var warnedStray = false

  debug "parse: starting variable declarations"
  # Parse variable declarations (header)
  while p.peek().kind notin {tkEof, tkFunc} and
              p.peek().kind != tkIdentifier or
              p.isVariableDeclarationStart() or
              p.peek().kind == tkObject:
    iterations += 1
    if iterations > maxTokens:
      raise newException(ParseError, "Parser exceeded maximum iterations - possible infinite loop")

    p.skipCommentsAndNewlines()

    if p.isVariableDeclarationStart():
      result.variables.add(p.parseVariableDeclaration())
      p.skipNewlines()
    elif p.isObjectDeclarationStart():
      result.variables.add(p.parseObjectDeclaration(p.peek().line))
      p.skipNewlines()
    elif p.peek().kind in {tkFunc, tkIdentifier}:
      break
    elif p.peek().kind == tkEof:
      break
    else:
      warnStrayText(p.peek(), "a header field or function block", warnedStray)
      discard p.advance()

  debug "parse: finished variable declarations, parsed "&(
      $result.variables.len)&" variables"
  # Parse functions
  p.skipCommentsAndNewlines()
  debug "parse: starting function parsing"
  while p.peek().kind != tkEof:
    iterations += 1
    if iterations > maxTokens:
      raise newException(ParseError, "Parser exceeded maximum iterations - possible infinite loop")

    debug "parse: function loop iteration "&($iterations)&", token kind: "&(
        $p.peek().kind)
    if p.peek().kind == tkFunc:
      debug "parse: parsing custom function"
      result.customFuncs.add(p.parseFunction(isCustom = true))
    elif p.isFunctionDefinitionStart():
      debug "parse: parsing function '"&p.peek().value&"'"
      result.functions.add(p.parseFunction(isCustom = false))
    elif p.strict:
      # Manifest mode rejects stray top-level text (kongue(5), MANIFEST MODE);
      # ordinary Kongue only warns about it.
      let tok = p.peek()
      if p.isVariableDeclarationStart():
        raiseParseError("header fields must precede the first function block",
          tok.line, tok.col)
      raiseParseError("unexpected text outside a function block", tok.line, tok.col)
    else:
      # Ordinary Kongue tolerates text outside a function block, but not
      # silently: a block that ended early (an unclosed `${...}`, a stray `}`)
      # leaves its remaining statements here.
      warnStrayText(p.peek(), "a function block", warnedStray)
      discard p.advance()
    p.skipCommentsAndNewlines()

  debug "parse: completed, "&($result.functions.len)&" functions, "&(
      $result.customFuncs.len)&" custom functions"

proc parseFile*(path: string): ParsedScript =
  ## Parse a Kongue script file from disk
  debug "parseFile: reading file '"&path&"'"
  when defined(js):
    let content = jscompat.readFile(path)
  else:
    let content = readFile(path)
  debug "parseFile: file read, size: "&($content.len)&" bytes"
  debug "parseFile: tokenizing"
  let tokens = tokenize(content)
  debug "parseFile: tokenized, "&($tokens.len)&" tokens"
  var parser = initParser(tokens)
  debug "parseFile: parsing"
  result = parser.parse()
  debug "parseFile: parsing completed"
